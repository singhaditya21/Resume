#!/usr/bin/env node
/**
 * WSR Agent Swarm Runner
 * Entry point for the agent-based pipeline
 * Usage: node src/agents/swarm-runner.js [--dateFrom=YYYY-MM-DD] [--dateTo=YYYY-MM-DD] [--hermes]
 */
const { AgentOrchestrator } = require('./core/orchestrator');
const eventBus = require('./core/event-bus');
const { ADOAgent } = require('./sources/ado-agent');
const { createBNAgents, releaseBNSession, closeBNSession } = require('./sources/bn-agent');
const { createPSAgents } = require('./sources/ps-agent');
const { AnalysisAgent } = require('./compute/analysis-agent');
const { PPTXAgent, agentNameForSource } = require('./generate/pptx-agent');
const { EmailAgent } = require('./generate/email-agent');
const { WhatsAppAgent } = require('./generate/whatsapp-agent');
const { runDeliveryAgents } = require('./generate/delivery-runner');
const { HermesOrchestrator } = require('../hermes/orchestrator');
const { finalizeHermesLearning } = require('../hermes/run-learning');
const { buildSourceEvidence } = require('../services/source-evidence');
const { makeLogger } = require('../services/logger');
const config = require('../config');
const fs = require('fs');
const path = require('path');

function resolveDateKeyword(value) {
  if (!value) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  switch (value.toUpperCase()) {
    case 'TODAY':
      return today.toISOString().split('T')[0];
    case 'YESTERDAY':
      const yest = new Date(today);
      yest.setDate(yest.getDate() - 1);
      return yest.toISOString().split('T')[0];
    case 'LAST_MONDAY': {
      const d = new Date(today);
      const day = d.getDay();
      const diff = day === 0 ? 6 : day - 1;
      d.setDate(d.getDate() - diff - 7);
      return d.toISOString().split('T')[0];
    }
    case 'LAST_FRIDAY': {
      const d = new Date(today);
      const day = d.getDay();
      const diff = day === 0 ? 2 : day + 2;
      d.setDate(d.getDate() - diff);
      return d.toISOString().split('T')[0];
    }
    default:
      return value;
  }
}

function assertDateRange(dateFrom, dateTo) {
  const re = /^\d{4}-\d{2}-\d{2}$/;
  if (!re.test(dateFrom) || !re.test(dateTo)) {
    throw new Error('dateFrom and dateTo must resolve to YYYY-MM-DD');
  }
  if (new Date(dateFrom) > new Date(dateTo)) {
    throw new Error('dateFrom must be on or before dateTo');
  }
}

function parseArgs() {
  const args = process.argv.slice(2);
  const rawFrom = args.find(a => a.startsWith('--dateFrom='))?.split('=')[1];
  const rawTo = args.find(a => a.startsWith('--dateTo='))?.split('=')[1];
  const rawDeckMode = args.find(a => a.startsWith('--deck-mode='))?.split('=')[1] || process.env.PPTX_DECK_MODE || 'ops';
  const jobId = args.find(a => a.startsWith('--jobId='))?.split('=')[1] || process.env.WSR_JOB_ID || null;
  const hermesMode = args.includes('--hermes');
  const forceRefresh = args.includes('--force-refresh');
  const dateFrom = resolveDateKeyword(rawFrom) || new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];
  const dateTo = resolveDateKeyword(rawTo) || new Date().toISOString().split('T')[0];
  const deckMode = String(rawDeckMode).toLowerCase() === 'executive' ? 'executive' : 'ops';
  assertDateRange(dateFrom, dateTo);
  // deckMode flows through context — do not mutate process.env here
  return { dateFrom, dateTo, hermesMode, forceRefresh, jobId, deckMode };
}

function getCriticalFailures(result) {
  const failures = [];
  const errors = result?.errors || {};
  const results = result?.results || {};

  if (!results.pptx?.filepath) failures.push('pptx was not generated');
  if (errors.analysis) failures.push(`analysis failed: ${errors.analysis}`);
  if (errors.pptx) failures.push(`pptx failed: ${errors.pptx}`);

  if (!config.allowEmptyReport) {
    for (const source of config.requiredLiveSources || []) {
      const agentName = agentNameForSource(source);
      if (!agentName) continue;
      if (errors[agentName]) failures.push(`${source} failed: ${errors[agentName]}`);
      if (!results[agentName]) failures.push(`${source} did not return live data`);
    }
  }

  return Array.from(new Set(failures));
}

function writeRunManifest({ jobId, dateFrom, dateTo, hermesMode, forceRefresh, deckMode, result, criticalFailures, startedAt, status, sourceEvidence, hermesLearning }) {
  const manifestPath = process.env.WSR_RUN_MANIFEST;
  if (!manifestPath) return;
  const pptx = result?.results?.pptx || {};
  const evidence = sourceEvidence || pptx.evidence || buildSourceEvidence({
    config,
    dependencies: result?.results || {},
    dependencyErrors: result?.errors || {},
    generatedAt: new Date().toISOString(),
  });
  const payload = {
    id: jobId,
    status,
    dateFrom,
    dateTo,
    hermesMode,
    forceRefresh,
    deckMode,
    startedAt,
    completedAt: new Date().toISOString(),
    durationMs: Date.now() - new Date(startedAt).getTime(),
    enabledSources: config.enabledSources,
    requiredLiveSources: config.requiredLiveSources,
    summary: result?.summary || null,
    errors: result?.errors || {},
    criticalFailures,
    files: { pptx: pptx.filepath || null, json: pptx.jsonPath || null },
    sourceEvidence: evidence,
    hermesLearning: hermesLearning || null,
    delivery: {
      email: result?.results?.email || null,
      whatsapp: result?.results?.whatsapp || null,
    },
  };
  fs.mkdirSync(path.dirname(manifestPath), { recursive: true });
  fs.writeFileSync(manifestPath, JSON.stringify(payload, null, 2));
}

async function runPipeline() {
  const { dateFrom, dateTo, hermesMode, forceRefresh, jobId, deckMode } = parseArgs();
  const log = makeLogger(jobId || 'cli');
  const context = { dateFrom, dateTo, forceRefresh, deckMode, log };
  const startedAt = new Date().toISOString();
  log.info('Runner', 'Pipeline started', { dateFrom, dateTo, deckMode, hermesMode });

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('  WSR Agent Swarm — Weekly Status Report');
  console.log('  ' + new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }));
  console.log('  Date Range: ' + dateFrom + ' → ' + dateTo);
  console.log('  Deck Mode: ' + deckMode.toUpperCase());
  if (hermesMode) {
    console.log('  Mode: 🤖 HERMES AI-ENHANCED (Deep Integration)');
  }
  console.log('═══════════════════════════════════════════════════════════════\n');

  // ── Event Listeners ──
  eventBus.onAllAgents((event) => {
    const ts = new Date(event.timestamp).toISOString().split('T')[1].slice(0, 8);
    if (event.type === 'start') {
      console.log(`[${ts}] [${event.agent}] ▶ Started`);
    } else if (event.type === 'complete') {
      console.log(`[${ts}] [${event.agent}] ✅ Complete (${event.duration}ms)`);
    } else if (event.type === 'error') {
      console.log(`[${ts}] [${event.agent}] ❌ Error (attempt ${event.attempt}): ${event.error}`);
    } else if (event.type === 'progress') {
      const msg = event.message || JSON.stringify(event);
      console.log(`[${ts}] [${event.agent}] ⏳ ${msg}`);
    } else if (event.type === 'circuit-open') {
      console.log(`[${ts}] [${event.agent}] 🔴 Circuit breaker OPEN`);
    }
  });

  eventBus.onPipeline((event) => {
    const ts = new Date(event.timestamp).toISOString().split('T')[1].slice(0, 8);
    if (event.type === 'start') {
      console.log(`[${ts}] [Pipeline] 🚀 Started (${event.agentCount} agents)`);
    } else if (event.type === 'level:start') {
      console.log(`[${ts}] [Pipeline] ▶ Level ${event.level}: ${event.agents.join(', ')}`);
    } else if (event.type === 'level:complete') {
      console.log(`[${ts}] [Pipeline] ✅ Level ${event.level} complete`);
    } else if (event.type === 'complete') {
      console.log(`[${ts}] [Pipeline] 🏁 Finished: ${event.succeeded}/${event.total} succeeded in ${event.duration}ms`);
    }
  });

  const startTime = Date.now();

  try {
    let result;

    if (hermesMode) {
      // ═══════════════════════════════════════════════════════════════
      // HERMES DEEP INTEGRATION MODE
      // ═══════════════════════════════════════════════════════════════
      const hermesOrchestrator = new HermesOrchestrator({ maxConcurrency: 5 });
      const hermesResult = await hermesOrchestrator.run(dateFrom, dateTo, null, { forceRefresh });

      if (!hermesResult) {
        console.log('[Hermes] Orchestrator returned null, falling back to standard pipeline');
        return runStandardPipeline(context, startTime);
      }

      // Merge Hermes agent results into dependency map for PPTX generation
      const allResults = hermesResult.agentResults.results;
      const allErrors = hermesResult.agentResults.errors;

      // Build analysis object from Hermes AI output
      const hermesAnalysis = hermesResult.hermesAnalysis;
      const analysis = {
        hermes: hermesAnalysis,
        executiveVerdict: {
          status: hermesAnalysis.executiveVerdict?.status || 'yellow',
          text: hermesAnalysis.executiveVerdict?.summary || 'AI analysis completed.',
        },
        actions: (hermesAnalysis.recommendations || []).map((r, i) => ({
          priority: r.priority || 'medium',
          action: r.text || r,
          owner: 'PORTFOLIO_REDACTED',
          due: 'Next week',
        })),
        rootCauses: {
          summary: hermesAnalysis.rootCauses?.summary || 'No root causes identified.',
          causes: (hermesAnalysis.rootCauses?.items || []).map(c => ({
            factor: c.factor || c,
            impact: c.impact || 'medium',
            evidence: c.evidence || '',
          })),
        },
        forecast: {
          canFinish: hermesAnalysis.forecast?.canFinish ?? true,
          probability: hermesAnalysis.forecast?.probability || 70,
          confidence: hermesAnalysis.forecast?.confidence || 'medium',
        },
        hygiene: {
          grade: hermesAnalysis.hygiene?.grade || 'B',
          score: hermesAnalysis.hygiene?.score || 75,
          issues: hermesAnalysis.hygiene?.issues || [],
        },
        trends: {
          velocityTrend: hermesAnalysis.trends?.velocity || 0,
          peakDay: hermesAnalysis.trends?.peakDay || 'N/A',
          prev7Closed: allResults.ado?.stats?.closedThisWeek || 0,
        },
        delta: { scopeAdded: allResults.ado?.stats?.scopeAdded || 0 },
        opsMaturity: {
          grade: hermesAnalysis.opsMaturity?.grade || 'B',
          overall: hermesAnalysis.opsMaturity?.score || 75,
        },
        orgHealth: {
          grade: hermesAnalysis.orgHealth?.grade || 'B',
          overall: hermesAnalysis.orgHealth?.score || 75,
        },
        cycleTimeDist: allResults.ado?.stats?.cycleTimeDist || {},
        wipSnapshot: allResults.ado?.stats?.wipSnapshot || {},
        loadBalance: allResults.ado?.stats?.loadBalance || {},
        dailyBurn: allResults.ado?.stats?.dailyBurn || {},
        effortVariance: allResults.ado?.stats?.effortVariance || {},
        priorityDistribution: allResults.ado?.stats?.priorityDistribution || {},
        boardColumnDistribution: allResults.ado?.stats?.boardColumnDistribution || {},
        leadTimeByType: allResults.ado?.stats?.leadTimeByType || [],
        blockedAge: allResults.ado?.stats?.blockedAge || {},
        throughputVar: allResults.ado?.stats?.throughputVar || {},
      };

      // Run standard AnalysisAgent for full metrics, then merge Hermes insights
      console.log('[Hermes] Running standard analysis for complete metrics...');
      const normDeps = normalizeResultsMap(allResults);
      const analysisAgent = new AnalysisAgent();
      const standardAnalysisResult = await analysisAgent.run({
        dateFrom, dateTo,
        dependencies: normDeps,
      });

      // Merge: standard analysis provides full metrics, Hermes adds AI insights
      const mergedAnalysis = {
        ...standardAnalysisResult.analysis,
        hermes: hermesAnalysis,
        executiveVerdict: {
          status: hermesAnalysis.executiveVerdict?.status || standardAnalysisResult.analysis?.executiveVerdict?.status || 'yellow',
          text: hermesAnalysis.executiveVerdict?.summary || standardAnalysisResult.analysis?.executiveVerdict?.text || 'Analysis completed.',
        },
      };

      // Run PPTX generation with merged analysis — same dep map, re-used
      console.log('[Hermes] Generating PPTX with AI-enhanced content...');
      const pptxAgent = new PPTXAgent();
      const pptxResult = await pptxAgent.run({
        dateFrom, dateTo, deckMode,
        dependencies: {
          ...normDeps,
          analysis: { analysis: mergedAnalysis, hermes: true },
        },
      });

      const delivery = await runDeliveryAgents({ dateFrom, dateTo, pptxResult, mergedAnalysis });
      const deliveryFailed = Object.keys(delivery.errors).length;
      const deliveryTotal = Object.keys(delivery.results).length;

      // Cleanup shared browser sessions
      await releaseBNSession();

      result = {
        results: { ...allResults, pptx: pptxResult, analysis: { analysis: mergedAnalysis }, ...delivery.results },
        errors: { ...allErrors, ...delivery.errors },
        summary: {
          succeeded: Object.keys(allResults).length + 2 + deliveryTotal - deliveryFailed,
          failed: Object.keys(allErrors).length + deliveryFailed,
          total: Object.keys(allResults).length + Object.keys(allErrors).length + 2 + deliveryTotal,
          duration: Date.now() - startTime,
        }
      };

    } else {
      // ═══════════════════════════════════════════════════════════════
      // STANDARD PIPELINE MODE
      // ═══════════════════════════════════════════════════════════════
      result = await runStandardPipeline(context, startTime);
    }

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log(`  ✅ Pipeline Complete`);
    console.log(`  ⏱️  Total time: ${elapsed}s`);
    console.log(`  📊 Agents: ${result.summary.succeeded}/${result.summary.total} succeeded`);
    if (result.summary.failed > 0) {
      console.log(`  ⚠️  Failed: ${result.summary.failed}`);
      for (const [name, err] of Object.entries(result.errors)) {
        console.log(`     - ${name}: ${err}`);
      }
    }
    if (result.results.pptx) {
      console.log(`  📁 PPTX: ${result.results.pptx.filepath}`);
    }
    if (hermesMode) {
      console.log(`  🤖 Hermes: AI-enhanced analysis applied`);
    }
    const criticalFailures = getCriticalFailures(result);
    const sourceEvidence = result?.results?.pptx?.evidence || buildSourceEvidence({
      config,
      dependencies: result?.results || {},
      dependencyErrors: result?.errors || {},
      generatedAt: new Date().toISOString(),
    });
    const hermesLearning = finalizeHermesLearning({
      jobId,
      dateFrom,
      dateTo,
      hermesMode,
      result,
      sourceEvidence,
      startedAt,
      outputDir: config.output?.dir,
    });
    writeRunManifest({
      jobId,
      dateFrom,
      dateTo,
      hermesMode,
      forceRefresh,
      deckMode,
      result,
      criticalFailures,
      startedAt,
      status: criticalFailures.length ? 'error' : 'completed',
      sourceEvidence,
      hermesLearning,
    });
    if (criticalFailures.length) {
      console.log('  ❌ Critical live-data checks failed:');
      for (const failure of criticalFailures) {
        console.log(`     - ${failure}`);
      }
    }
    console.log('═══════════════════════════════════════════════════════════════\n');

    process.exit(criticalFailures.length ? 1 : 0);
  } catch (err) {
    console.error('\n[Pipeline] Fatal error:', err.message);
    if (err.stack) console.error(err.stack.split('\n').slice(0, 4).join('\n'));
    writeRunManifest({
      jobId,
      dateFrom,
      dateTo,
      hermesMode,
      forceRefresh,
      deckMode,
      result: { results: {}, errors: { fatal: err.message }, summary: { succeeded: 0, failed: 1, total: 1, duration: Date.now() - startTime } },
      criticalFailures: [err.message],
      startedAt,
      status: 'error',
    });
    await releaseBNSession();
    process.exit(1);
  }
}

/**
 * Normalise a raw agent-results map into the canonical dependency keys
 * expected by AnalysisAgent and PPTXAgent.  The `wsr_incident` /
 * `wsr-incident` dual-key issue is resolved here once, not scattered
 * across multiple call sites.
 */
function normalizeResultsMap(allResults = {}) {
  return {
    ado:                  allResults.ado,
    'bn-mpr':             allResults['bn-mpr'],
    'bn-headcount':       allResults['bn-headcount'],
    'bn-headcount2':      allResults['bn-headcount2'],
    'bn-itsm':            allResults['bn-itsm'],
    'bn-oeg':             allResults['bn-oeg'],
    'bn-cloud':           allResults['bn-cloud'],
    'bn-legal':           allResults['bn-legal'],
    'bn-itdesk':          allResults['bn-itdesk'],
    'bn-wsr_incident':    allResults['bn-wsr_incident']    || allResults['bn-wsr-incident'],
    'bn-wsr_requirement': allResults['bn-wsr_requirement'] || allResults['bn-wsr-requirement'],
    'ps-employees':       allResults['ps-employees'],
  };
}

async function runStandardPipeline(context, startTime) {
  const orchestrator = new AgentOrchestrator({ maxConcurrency: 5 });
  // Use config.sourceEnabled so normalisation (underscore/hyphen, bn- prefix)
  // is consistent with every other call site — fixes the P1-2 silent-skip bug.
  const fetcherNames = [];

  // ── Level 0: Fetchers (parallel) ──
  if (config.sourceEnabled('ado')) {
    const adoAgent = new ADOAgent();
    orchestrator.register(adoAgent, []);
    fetcherNames.push(adoAgent.name);
  }

  const bnAgents = createBNAgents();
  const hasMprAgent = bnAgents.some(agent => agent.name === 'bn-mpr');
  for (const agent of bnAgents) {
    // MPR must run before other BN reports to avoid browser session race condition
    const deps = agent.name === 'bn-mpr' || !hasMprAgent ? [] : ['bn-mpr'];
    orchestrator.register(agent, deps);
    fetcherNames.push(agent.name);
  }

  const psAgents = createPSAgents();
  for (const agent of psAgents) {
    orchestrator.register(agent, []);
    fetcherNames.push(agent.name);
  }

  // ── Level 1: Analysis (depends on all fetchers) ──
  const analysisAgent = new AnalysisAgent();
  orchestrator.register(analysisAgent, fetcherNames);

  // ── Level 2: Generation (depends on analysis) ──
  const pptxAgent = new PPTXAgent();
  orchestrator.register(pptxAgent, ['analysis', ...fetcherNames]);

  const emailAgent = new EmailAgent();
  orchestrator.register(emailAgent, ['pptx', 'analysis']);

  const whatsappAgent = new WhatsAppAgent();
  orchestrator.register(whatsappAgent, ['pptx', 'analysis']);

  // ── Run ──
  const result = await orchestrator.run(context);

  // Cleanup shared browser sessions
  await releaseBNSession();

  return result;
}

// ── Graceful Shutdown ──
let shutdownInProgress = false;
async function gracefulShutdown(signal) {
  if (shutdownInProgress) return;
  shutdownInProgress = true;
  console.log(`\n[Pipeline] Received ${signal}, shutting down gracefully...`);
  // Force-close shared sessions regardless of ref count
  await closeBNSession();
  console.log('[Pipeline] Cleanup complete. Exiting.');
  process.exit(0);
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Only auto-run when executed directly (not when imported)
if (require.main === module) {
  runPipeline();
}

module.exports = { runPipeline, runStandardPipeline, parseArgs };
