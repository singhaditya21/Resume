import { useEffect, useState } from 'react';

export function useControlTowerInsights(refreshKey = 0) {
  const [insights, setInsights] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    const load = () => fetch('/api/control-tower/insights')
      .then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`)))
      .then(data => {
        if (!active) return;
        setInsights(data);
        setError(null);
      })
      .catch(err => {
        if (!active) return;
        setError(err.message);
      });
    load();
    const timer = setInterval(load, 30000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [refreshKey]);

  return { insights, error };
}
