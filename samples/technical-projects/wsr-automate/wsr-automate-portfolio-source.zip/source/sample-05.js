const PptxGenJS = require('pptxgenjs');
const path = require('path');
const fs = require('fs');
const { QB, CHART_COLORS, CHART_COLORS_EXT, TYPE, GRID, TBL, CHART, renderMeko } = require('./theme/mckinsey');

class PPTXGenerator {
  constructor(config) {
    this.config = config;
    this.pptx = new PptxGenJS();
    this.pptx.layout = 'LAYOUT_WIDE';
    this.pptx.author = 'WSR Automate';
    this.pptx.subject = 'Weekly Status Report';
    this.pptx.company = 'BizTech';

    // ── QuantumBlack / McKinsey visual design system ──────────────────────
    // Colors sourced from mckinsey/qbstyles matplotlib stylesheet.
    // Aliases maintain backward-compat with all existing slide methods.
    this.C = QB;

    // Expose theme modules to slide methods
    this._QB = QB;
    this._CHART_COLORS = CHART_COLORS;
    this._CHART_COLORS_EXT = CHART_COLORS_EXT;
    this._TYPE = TYPE;
    this._GRID = GRID;
    this._TBL = TBL;
    this._CHART = CHART;
  }

  async generate(sprintData, bnData, analysis, opsData = {}, hermesContent = null, options = {}) {
    console.log('[PPTX] Generating presentation...');
    if (hermesContent) console.log('[PPTX] Hermes AI content detected — enhancing slides');
    this._dateRange = options.dateFrom && options.dateTo ? { dateFrom: options.dateFrom, dateTo: options.dateTo } : null;
    const wl = this._wl();
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const an = analysis || {};
    const ops = opsData || {};
    this._an = an;
    this._sprintData = sprintData || {};
    this._bnData = Array.isArray(bnData) ? bnData : [];
    this._hermes = hermesContent;
    this._hermesSlidesTitles = an.hermesSlidesTitles || {};
    this._sourceEvidence = options.sourceEvidence || [];
    this._deckMode = this._resolveDeckMode(options);
    this._ops = ops;
    this._snapshotManifest  = options.snapshotManifest  || {};
    this._slideAnnotations  = options.slideAnnotations   || {};
    this._intelligence = this._buildExecutiveIntelligence(sprintData, bnData, an, ops, options);
    an.executiveIntelligence = this._intelligence;

    // Re-architected order: Memo at page 2 (synthesis up front), evidence in
    // the middle, forward-looking pages near the end, glossary as appendix.
    // The deck now reads as a McKinsey pyramid: answer first → evidence → decisions → reference.
    const allSlides = [
      // ── Open: synthesis up front ────────────────────────────────────────
      {name:'Title',                  section:'command',    fn:(sn,ts)=>this._slideTitle(sprintData,an,sn,ts)},
      {name:'Executive Memo',         section:'memo',       fn:(sn,ts)=>this._slideExecutiveMemo(an,sn,ts)},
      {name:'Data Source Health',     section:'health',     fn:(sn,ts)=>this._slideDataSourceHealth(sn,ts)},
      {name:'Command Centre',         section:'command',    fn:(sn,ts)=>this._slideCommandCentre(an,sn,ts)},
      {name:'Health Bridge',          section:'health',     fn:(sn,ts)=>this._slideHealthBridge(sn,ts)},
      // ── Delivery & Engineering ─────────────────────────────────────────
      {name:'Delivery & Sprint',      section:'command',    fn:(sn,ts)=>this._slideDeliveryAndSprint(sprintData,an,sn,ts)},
      {name:'DORA Metrics',           section:'dora',       fn:(sn,ts)=>this._slideDORA(sn,ts)},
      {name:'Azure Quality',          section:'azure',      fn:(sn,ts)=>this._slideAzureQuality(sn,ts)},
      {name:'Sprint-over-Sprint',     section:'sos',        fn:(sn,ts)=>this._slideSprintOverSprint(sn,ts)},
      {name:'Sprint Trajectory',      section:'trajectory', fn:(sn,ts)=>this._slideSprintTrajectory(sn,ts)},
      // ── Ops domains ─────────────────────────────────────────────────────
      // ── ITSM compressed: 6 slides → 2 cockpits (Cockpit + Diagnostics) ─────
      // Old: ITSM Analytics, Volume Drivers, Profile, Status Matrix, Root-Cause Pivot, Analysis×Root
      // New: ITSM Cockpit (volume + aging + accounts + 12-wk trend) +
      //      ITSM Diagnostics (OEG cat + age profile + root-cause × cat heatmap).
      // Per project rule, both carry Hermes-generated LLM Insight panels.
      {name:'ITSM Cockpit',           section:'itsm',       fn:(sn,ts)=>this._slideITSMCockpit(sn,ts)},
      {name:'ITSM Diagnostics',       section:'itsmdiag',   fn:(sn,ts)=>this._slideITSMDiagnostics(sn,ts)},
      {name:'OEG Operations',         section:'oeg',        fn:(sn,ts)=>this._slideOEG(sn,ts)},
      {name:'Cloud & Infrastructure', section:'cloud',      fn:(sn,ts)=>this._slideCloud(sn,ts)},
      // ── MPR compressed: 6 slides → 2 cockpits (Cockpit + Owner Lens) ───────
      // Old: Volume Trends, Aging & SLA, Stuck Cases, Effort Accuracy, FY Comparison, Per-Assignee
      // New: MPR Cockpit       (volume + aging/SLA + stuck + effort accuracy)
      //      MPR Owner Lens    (top assignees + dwell heatmap + SLA + monthly trend)
      {name:'MPR Cockpit',            section:'mpr',        fn:(sn,ts)=>this._slideMPRCockpit(sn,ts)},
      {name:'MPR Owner Lens',         section:'mprown',     fn:(sn,ts)=>this._slideMPROwnerLens(sn,ts)},
      {name:'SLA Breach Forecast',    section:'slaforecast',fn:(sn,ts)=>this._slideSLAForecast(sn,ts)},
      {name:'Cost of Delay',          section:'cod',        fn:(sn,ts)=>this._slideCostOfDelay(sn,ts)},
      {name:'Bottleneck Heatmap',     section:'bottleneck', fn:(sn,ts)=>this._slideBottleneckHeatmap(sn,ts)},
      {name:'Resolution Funnel',      section:'funnel',     fn:(sn,ts)=>this._slideResolutionFunnel(sn,ts)},
      {name:'Performance Ranking',    section:'perfrank',   fn:(sn,ts)=>this._slidePerformanceRanking(sn,ts)},
      {name:'Sanity Checks',          section:'sanity',     fn:(sn,ts)=>this._slideSanityChecks(sn,ts)},
      {name:'Headcount & Capacity',   section:'headcount',  fn:(sn,ts)=>this._slideHeadcount(sn,ts)},
      // ── People / risk lenses ────────────────────────────────────────────
      // ── Owner compressed: 4 slides → 2 cockpits (Team Pulse + Owner Drill-Down) ──
      // Old: Workload Heatmap, Owner Performance, Owner Velocity Grid, Owner Dossier
      // New: Team Pulse       (workload + cycle time + sparkline grid + concentration)
      //      Owner Drill-Down (cycle time + PR asymmetry + burnout dossier + violations)
      {name:'Team Pulse',             section:'people',     fn:(sn,ts)=>this._slideTeamPulse(sn,ts)},
      {name:'Owner Drill-Down',       section:'ownerdrill', fn:(sn,ts)=>this._slideOwnerDrillDown(sn,ts)},
      {name:'Hygiene Penalties',      section:'hygiene',    fn:(sn,ts)=>this._slideHygienePenalties(sn,ts)},
      {name:'Top Accounts',           section:'accounts',   fn:(sn,ts)=>this._slideTopAccounts(sn,ts)},
      // ── Cross-domain & forward looking ─────────────────────────────────
      {name:'Cross-Domain Aging',     section:'aging',      fn:(sn,ts)=>this._slideAgingPyramid(sn,ts)},
      {name:'Health Trend 4 Weeks',   section:'trend',      fn:(sn,ts)=>this._slideHealthTrend4w(an,sn,ts)},
      {name:'WoW Top Movers',         section:'wow',        fn:(sn,ts)=>this._slideWowMovers(an,sn,ts)},
      {name:'Alert Volume',           section:'alerts',     fn:(sn,ts)=>this._slideAlertVolume(sn,ts)},
      {name:'Alert Trend Detail',     section:'alertdet',   fn:(sn,ts)=>this._slideAlertTrendDetail(sn,ts)},
      {name:'Governance & Quality',   section:'governance', fn:(sn,ts)=>this._slideGovernance(sn,ts)},
      {name:'Operational Index',      section:'opindex',    fn:(sn,ts)=>this._slideOperationalIndex(sn,ts)},
      {name:'Metric History',         section:'methistory', fn:(sn,ts)=>this._slideGovMetricHistory(sn,ts)},
      {name:'Hidden Risks',           section:'hiddenrisks',fn:(sn,ts)=>this._slideRisksNotInRegister(an,sn,ts)},
      // ── Meta: Hermes self-narration of what it's learned ────────────────
      {name:'Hermes Learning',        section:'hermeslearn',fn:(sn,ts)=>this._slideHermesLearning(sn,ts)},
      // ── Close: AI verdicts & decisions ─────────────────────────────────
      {name:'BIZTECH AI Recs',        section:'biztechAI',  fn:(sn,ts)=>this._slideBizTechAIRecs(sn,ts)},
      {name:'Actions & Next Steps',   section:'actions',    fn:(sn,ts)=>this._slideActions(sn,ts)},
      {name:'Decisions Required',     section:'decisions',  fn:(sn,ts)=>this._slideDecisionsRequired(an,sn,ts)},
      {name:'Glossary & Methodology', section:'glossary',   fn:(sn,ts)=>this._slideGlossary(sn,ts)},
    ].map(sl => ({...sl, ...this._slideMeta(sl.name)}));

    const enabledSections = this.config.enabledSlideSections || ['all'];
    const slides = this._selectSlides(allSlides, enabledSections);
    const gate = this._qualityGateSlides(slides);
    this._qualityGate = gate;
    an.executiveIntelligence.qualityGate = gate;

    const total = slides.length;
    slides.forEach((sl, idx) => {
      try {
        this._currentSlideMeta = sl;
        console.log(`[PPTX] Slide ${idx+1}: ${sl.name}...`);
        sl.fn(idx+1, total);
        console.log(`[PPTX] Slide ${idx+1}: ${sl.name} `);
      } catch(e) {
        console.error(`[PPTX] Slide ${idx+1}: ${sl.name} ❌ ${e.message}`);
        console.error(e.stack?.split('\n').slice(0,3).join(' | '));
        const es = this.pptx.addSlide(); es.background={color:this.C.white};
        es.addText(`Error: ${sl.name}`,{x:0.5,y:2,w:12,h:1,fontSize:24,color:this.C.red,bold:true});
        es.addText(e.message,{x:0.5,y:3,w:12,h:0.5,fontSize:14,color:this.C.darkGray});
      }
    });

    const now=new Date();
    const ts=`${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
    const modePrefix=this._deckMode==='executive'?'Executive_':'';
    const fn=`WSR_${modePrefix}${wl.replace(/\s+/g,'_')}_${ts}.pptx`;
    const fp=path.join(this.config.output.dir,fn);
    fs.mkdirSync(this.config.output.dir,{recursive:true});
    await this.pptx.writeFile({fileName:fp});
    console.log(`[PPTX] Saved: ${fp}`);
    return fp;
  }

  // ─── HELPERS ───
  // Map from human-readable slide title → Hermes slide key (for editorial rewrites)
  static _HERMES_TITLE_KEYS = {
    'Support Cases': 'bn-breakdown',
    'BN Breakdown': 'bn-breakdown',
    'Retrospective': 'retrospective',
    'Glossary': 'glossary',
    'Cloud Provisioning': 'cloud-provisioning',
    'Headcount Reconciliation': 'headcount-reconciliation',
    'Production Incidents': 'incidents',
    'Operations Overview': 'operations-overview',
  };

  _hdr(s,text,color,sn,ts){
    const C=this.C;
    const c=color||C.navy;
    const endDate = (this._dateRange?.dateTo) ? new Date(this._dateRange.dateTo) : new Date();
    const ds = endDate.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' });
    s.addText(`Data as of ${ds}`, { x: 9.5, y: 0.25, w: 3.5, h: 0.3, fontSize: 8, fontFace: 'Arial', color: C.midGray, align: 'right' });
    const slideKey = PPTXGenerator._HERMES_TITLE_KEYS[text];
    const hermesTitle = slideKey && this._hermesSlidesTitles?.[slideKey];
    const effectiveText = hermesTitle || text;
    const parts = String(effectiveText).split(' — ');
    const title = this._actionTitle(parts[0] || effectiveText);
    const subtitle = parts[1] || '';
    s.addText(title, { x: 0.35, y: 0.55, w: 12.6, h: 0.65, fontSize: 20, fontFace: 'Arial', color: c, bold: true, lineSpacing: 24 });
    if (subtitle) {
      s.addText(subtitle, { x: 0.35, y: 1.22, w: 12.6, h: 0.28, fontSize: 10, fontFace: 'Arial', color: C.midGray });
    }
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: subtitle ? 1.52 : 1.25, w: 12.6, h: 0.015, fill: { color: c } });
  }

  _ftr(s,src,sn,ts){
    const C=this.C;
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:6.95,w:12.6,h:0.008,fill:{color:C.lightGray}});
    const conf=this._sourceConfidenceFooter();
    s.addText(`${src}  |  ${conf}  |  CONFIDENTIAL  |  For internal use only`,{x:0.35,y:7.05,w:11.5,h:0.22,fontSize:8,fontFace:'Arial',color:C.midGray,italic:true});
    if(sn&&ts)s.addText(`${sn} / ${ts}`,{x:11.85,y:7.05,w:1.1,h:0.22,fontSize:8,fontFace:'Arial',color:C.midGray,align:'right'});
  }

  _badges(s,metrics,sY,pc){
    const C=this.C,cols=5,bw=2.42,bh=0.55,gx=0.06,gy=0.04,sx=0.35;
    const rows=Math.ceil(metrics.length/cols);
    s.addShape(this.pptx.ShapeType.rect,{x:sx,y:sY,w:cols*(bw+gx)-gx,h:0.008,fill:{color:C.lightGray}});
    metrics.forEach((m,i)=>{
      const col=i%cols,row=Math.floor(i/cols);
      const x=sx+col*(bw+gx),y=sY+0.04+row*(bh+gy);
      const mc=m.color||pc||C.navy;
      s.addShape(this.pptx.ShapeType.rect,{x,y,w:bw,h:0.025,fill:{color:mc}});
      if(m.trend){
        s.addText([{text:String(m.value)+' ',options:{fontSize:16,bold:true,color:mc}},{text:`${m.trend}${m.trendValue}`,options:{fontSize:9,bold:true,color:m.trendColor||C.steel}}],{x,y:y+0.05,w:bw,h:0.24,align:'center',fontFace:'Arial'});
      }else{
        s.addText(String(m.value),{x,y:y+0.05,w:bw,h:0.24,fontSize:16,fontFace:'Arial',color:mc,bold:true,align:'center'});
      }
      s.addText(m.label,{x,y:y+0.32,w:bw,h:0.14,fontSize:6.5,fontFace:'Arial',color:C.steel,align:'center',bold:true});
    });
    return sY+rows*(bh+gy)+0.06;
  }

  // McKinsey: surface the single most important "so what" as a callout annotation,
  // not a bulleted "Key Insights" box that separates insight from evidence.
  _ins(s, x, y, w, bullets, accent) {
    const text = (Array.isArray(bullets) ? bullets : []).find(b => b && String(b).trim());
    if (!text) return;
    this._annotate(s, x, y, w, String(text), accent || this.C.navy);
  }

  _cf(s,x,y,w,h){s.addShape(this.pptx.ShapeType.rect,{x:x-0.02,y:y-0.02,w:w+0.04,h:h+0.04,line:{color:this.C.lightGray,width:0.3}});}
  _sc(p){const n=Number(p);return Number.isFinite(n)&&n>=70?this.C.green:n>=40?this.C.brightBlue:this.C.red;}
  _tl(p){return p>=70?'■':p>=40?'◆':'▲';}
  _t(t,o){return{_text:t,_opts:o};}
  // ── Table helpers — clean-slides + Instrumenta rules ─────────────────────
  // clean-slides: horizontal rules only, no vertical borders, no dark fills.
  // Instrumenta: table cells have only bottom hairlines between rows.
  _th(h, c) {
    // topRule uses QB.primary (red-orange) not navy — qbstyles brand accent
    const topRule = TBL.ruleTop;
    const btmRule = TBL.ruleHdr;
    const noLine  = TBL.noLine;
    return h.map((x, i) => ({
      text: x,
      options: {
        bold: true, color: TBL.hdrColor, fill: { color: TBL.hdrFill }, fontSize: TBL.hdrFontSz,
        align: i === 0 ? 'left' : 'center', valign: 'middle',
        border: [topRule, noLine, btmRule, noLine],   // top, right, bottom, left
        fontFace: TYPE.font,
      },
    }));
  }
  _tr(c, i) {
    const bg      = i % 2 === 0 ? TBL.evenFill : TBL.oddFill;
    const hairline = TBL.hairline;
    const noLine   = TBL.noLine;
    return c.map((x, ci) => {
      const o = {
        fill: { color: bg }, fontSize: TBL.fontSize, fontFace: TYPE.font,
        align: ci === 0 ? 'left' : 'center', valign: 'middle',
        border: [noLine, noLine, hairline, noLine],  // only bottom hairline
      };
      if (typeof x === 'object' && x !== null) {
        if (x._text)              return { text: x._text, options: { ...o, ...(x._opts   || {}) } };
        if (x.text !== undefined) return { text: x.text,  options: { ...o, ...(x.options || {}) } };
      }
      return { text: String(x), options: o };
    });
  }
  _tot(c, cl) {
    const co     = cl || QB.primary;
    const topRule = { pt: 0.8, color: co };
    const noLine  = TBL.noLine;
    const b = { fill: { color: TBL.hdrFill }, fontSize: TBL.fontSize, fontFace: TYPE.font, align: 'center', bold: true, border: [topRule, noLine, topRule, noLine] };
    return c.map((x, ci) => {
      const opts = { ...b, align: ci === 0 ? 'left' : 'center' };
      if (typeof x === 'object' && x !== null) {
        if (x._text)              return { text: x._text, options: { ...opts, ...(x._opts   || {}) } };
        if (x.text !== undefined) return { text: x.text,  options: { ...opts, ...(x.options || {}) } };
      }
      return { text: String(x), options: opts };
    });
  }
  _wl(){const d=x=>x.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});if(this._dateRange){return`${d(new Date(this._dateRange.dateFrom))} — ${d(new Date(this._dateRange.dateTo))}`;}const n=new Date(),f=new Date(n);f.setDate(f.getDate()-(this.config.output?.dateRangeDays||7));return`${d(f)} — ${d(n)}`;}
  _fd(ds){return ds?new Date(ds).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'';}
  _trunc(s,n){if(typeof s==='number')return String(s);return s&&s.length>n?s.substring(0,n-2)+'..':(s||'');}
  _budget(text, maxChars, suffix = '…') {
    const s = String(text || '');
    if (s.length <= maxChars) return s;
    const cut = s.slice(0, maxChars - suffix.length);
    const lastSpace = cut.lastIndexOf(' ');
    return (lastSpace > maxChars * 0.6 ? cut.slice(0, lastSpace) : cut) + suffix;
  }
  _bns(c){const st=(c.status||c.Status||'').toLowerCase();if(st.includes('resolv')||st.includes('closed')||st.includes('done'))return'Resolved';if(st.includes('invalid')||st.includes('cancel')||st.includes('reject'))return'Invalid';return'Open';}
  _top(bn){if(!bn||!bn.length)return null;const m={};bn.forEach(c=>{const cat=c.category||c.Category||'Other';m[cat]=(m[cat]||0)+1;});const t=Object.entries(m).sort((a,b)=>b[1]-a[1])[0];return t?{name:t[0],count:t[1],pct:Math.round(t[1]/bn.length*100)}:null;}
  _pct(n,d){return d>0?Math.round((n/d)*100):0;}
  _num(v){const n=Number(v);return Number.isFinite(n)?n:0;}
  _slideKey(title){return String(title||'').toLowerCase().replace(/—.*/,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');}
  _ragColor(status){const s=String(status||'').toLowerCase();return s==='green'?this.C.green:s==='red'?this.C.red:this.C.amber;}
  _ragLabel(status){const s=String(status||'').toLowerCase();return s==='green'?'Green':s==='red'?'Red':'Amber';}
  _actionTitle(title){
    const key=this._slideKey(title);
    const head=this._intelligence?.headlines?.[key];
    const raw=head||title;
    return this._budget(raw,110);
  }
  _sourceConfidenceFooter(){
    const sc=this._intelligence?.sourceConfidence;
    if(!sc||!sc.total)return'Data confidence: not captured';
    return `Data confidence: ${sc.label} (${sc.live}/${sc.total} live; ${sc.refreshed})`;
  }
  _resolveDeckMode(options={}){
    const raw=(options.deckMode||this.config.pptx?.deckMode||process.env.PPTX_DECK_MODE||'ops').toString().trim().toLowerCase();
    if(raw==='executive')return'executive';
    if(raw==='cto')return'cto';
    if(raw==='leadership')return'leadership';
    return'ops';
  }
  _qualityGateMode(){
    const raw=(this.config.pptx?.qualityGate||process.env.PPTX_QUALITY_GATE||'warn').toString().trim().toLowerCase();
    return ['off','warn','strict'].includes(raw)?raw:'warn';
  }
  _slideMeta(name){
    const key=this._slideKey(name);
    const map={
      title:{mece:'Cover',domain:'Context',priority:'executive'},
      'sprint-status':{mece:'Delivery',domain:'Engineering',priority:'executive'},
      'executive-summary':{mece:'Executive',domain:'Leadership',priority:'executive'},
      'narrative-spine':{mece:'Executive',domain:'Leadership',priority:'executive'},
      'health-score-bridge':{mece:'Executive',domain:'Leadership',priority:'executive'},
      'rag-thresholds':{mece:'Evidence',domain:'Controls',priority:'executive'},
      'sprint-dashboard':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'work-items-by-type':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'type-breakdown':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'team-summary':{mece:'Capacity',domain:'Engineering',priority:'ops'},
      'weekly-activity':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'highlights-risks':{mece:'Risk',domain:'Engineering',priority:'ops'},
      'risk-register':{mece:'Risk',domain:'Leadership',priority:'executive'},
      'support-cases':{mece:'Customer',domain:'Support',priority:'ops'},
      'bn-dashboard':{mece:'Customer',domain:'Support',priority:'ops'},
      'bn-breakdown':{mece:'Customer',domain:'Support',priority:'ops'},
      'bn-details':{mece:'Customer',domain:'Support',priority:'ops'},
      'bn-highlights':{mece:'Customer',domain:'Support',priority:'ops'},
      'operations-overview':{mece:'Operations',domain:'Operations',priority:'ops'},
      'production-incidents':{mece:'Operations',domain:'Incidents',priority:'ops'},
      'it-helpdesk-legal':{mece:'Operations',domain:'IT/Legal',priority:'ops'},
      'cloud-provisioning':{mece:'Operations',domain:'Cloud',priority:'ops'},
      'headcount-dashboard':{mece:'Capacity',domain:'People',priority:'ops'},
      'headcount-reconciliation':{mece:'Capacity',domain:'People',priority:'ops'},
      'executive-dashboard':{mece:'Executive',domain:'Leadership',priority:'executive'},
      trends:{mece:'Analytics',domain:'Trends',priority:'ops'},
      'wow-deltas':{mece:'Analytics',domain:'Movement',priority:'executive'},
      delta:{mece:'Analytics',domain:'Movement',priority:'ops'},
      burndown:{mece:'Delivery',domain:'Forecast',priority:'ops'},
      retrospective:{mece:'Analytics',domain:'Learning',priority:'ops'},
      'decision-required':{mece:'Decision',domain:'Leadership',priority:'executive'},
      'action-items':{mece:'Decision',domain:'Execution',priority:'ops'},
      glossary:{mece:'Appendix',domain:'Reference',priority:'ops'},
      'ai-insights':{mece:'Executive',domain:'Hermes',priority:'executive'},
      // ── New 10-slide McKinsey redesign keys ─────────────────────────────────
      'command-centre':{mece:'Executive',domain:'Leadership',priority:'executive'},
      'delivery-sprint':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'pipelines-prs':{mece:'Delivery',domain:'Engineering',priority:'ops'},
      'itsm-analytics':{mece:'Operations',domain:'ITSM',priority:'ops'},
      'oeg-operations':{mece:'Operations',domain:'OEG',priority:'ops'},
      'cloud-infrastructure':{mece:'Operations',domain:'Cloud',priority:'ops'},
      'headcount-capacity':{mece:'Capacity',domain:'People',priority:'ops'},
      'governance-quality':{mece:'Risk',domain:'Governance',priority:'ops'},
      'actions-next-steps':{mece:'Decision',domain:'Execution',priority:'ops'},
    };
    return {key,...(map[key]||{mece:'Appendix',domain:'Reference',priority:'ops'})};
  }
  _shouldSuppressSlide(slideName, sprintData, bnData, analysis) {
    switch (slideName) {
      case 'Glossary':
        // Always suppress from main deck — can be a separate appendix
        return true;
      case 'BN Breakdown': {
        // Suppress if BN Dashboard already covers the same data (no distinct category breakdown)
        const bycat = Object.entries(analysis?.bnAnalysis?.byCategory || {});
        const catKeys = Object.keys(bnData && Array.isArray(bnData) ? bnData.reduce((m,c)=>{const k=c.category||c.Category||'Other';m[k]=1;return m;},{}) : {});
        // Suppress when category data is trivial (≤1 distinct categories) or no BN data
        if (!Array.isArray(bnData) || bnData.length === 0) return true;
        if (bycat.length === 0 && catKeys.length <= 1) return true;
        return false;
      }
      case 'Delta': {
        const net = analysis?.delta?.netChange;
        return net === 0 || net === undefined || net === null;
      }
      case 'WoW Deltas': {
        const wow = this._intelligence?.wow || [];
        const hasUnfavorable = wow.some(m => m.favorable === false);
        return !hasUnfavorable;
      }
      default:
        return false;
    }
  }

  _selectSlides(allSlides, enabledSections){
    const sections=(enabledSections||['all']).map(s=>String(s).toLowerCase());
    const manual=!sections.includes('all');
    if(manual){
      return allSlides.filter(sl => sections.includes(sl.section) || sections.includes(sl.mece?.toLowerCase()) || sections.includes(sl.key));
    }
    if(this._deckMode==='executive'){
      // SCR pyramid: Situation → Complication → Resolution → Evidence → Risk → Decision
      const executiveOrder = [
        'Title',             // SITUATION: context
        'Executive Dashboard', // COMPLICATION: what is not going as expected
        'Narrative Spine',   // RESOLUTION: the single message
        'Health Score Bridge', // EVIDENCE: why the score moved
        'RAG Thresholds',    // EVIDENCE: which domains are in breach
        'Risk Register',     // RISK: ranked, owned, time-bound
        'Decision Required', // DECISION: the ask — always last, most emphatic
      ];
      if(this._hermes) executiveOrder.splice(-1, 0, 'AI Insights'); // insert before Decision
      return executiveOrder
        .map(name => allSlides.find(sl => sl.name === name))
        .filter(Boolean);
    }
    // CTO persona — engineering + ops signals + trends
    if(this._deckMode==='cto'){
      const ctoOrder = [
        'Title',
        'Sprint Status',
        'Sprint Dashboard',
        'Type Breakdown',
        'Team Summary',
        'Trends',
        'Production Incidents',
        'Risk Register',
        'Decision Required',
      ];
      return ctoOrder
        .map(name => allSlides.find(sl => sl.name === name))
        .filter(Boolean);
    }
    // Leadership one-pager — single dense slide
    if(this._deckMode==='leadership'){
      const leadOrder = ['Title', 'Leadership One-Pager'];
      return leadOrder
        .map(name => allSlides.find(sl => sl.name === name))
        .filter(Boolean);
    }
    // ops mode — apply slide debt gate suppression
    return allSlides.filter(sl => !this._shouldSuppressSlide(sl.name, this._sprintData, this._bnData, this._an || {}));
  }
  // Taxonomy tags are internal metadata — not shown on slides per McKinsey convention
  _taxonomyTag(s, color) { /* intentionally no-op */ }
  _narrativeSpine(snapshot, rag, risks, sourceConfidence, decisions){
    const status=(domain)=>rag.find(r=>r.domain===domain)?.status||'amber';
    const topRisk=risks[0];
    const answer=`${topRisk?'Protect the week by resolving the primary risk and':'Maintain cadence and'} keep leadership focused on the decision ask.`;
    const pillars=[
      {pillar:'Delivery',status:status('Delivery completion'),message:`Delivery is ${snapshot.progress}% complete with ${snapshot.blockers} blocker(s).`,evidence:`${snapshot.closed} closed, ${snapshot.active} active, ${snapshot.overdue} overdue`},
      {pillar:'Operations',status:status('Operations incidents'),message:`Operations risk is led by ${snapshot.incidentOpen} open incident(s) and ${snapshot.slaBreaches} SLA breach(es).`,evidence:`${snapshot.p1} P1, MTTR ${snapshot.mttr}h`},
      {pillar:'Customer support',status:status('Support aging'),message:`Support queue has ${snapshot.supportOpen} open case(s), including ${snapshot.supportOld} aging item(s).`,evidence:`${snapshot.supportTotal} total cases, ${snapshot.supportResolution}% resolution`},
      {pillar:'Capacity',status:status('Capacity signal'),message:snapshot.headcount?`Active capacity is ${this._pct(snapshot.activeHeadcount,snapshot.headcount)}% of HRIS headcount.`:'HRIS capacity signal is not live.',evidence:`${snapshot.activeHeadcount}/${snapshot.headcount} active`},
      {pillar:'Evidence',status:status('Source confidence'),message:`Source confidence is ${sourceConfidence.label} with ${sourceConfidence.live}/${sourceConfidence.total} live feed(s).`,evidence:`Refreshed ${sourceConfidence.refreshed}`},
    ];
    return {answer,pillars,decision:decisions[0]?.decision||'No leadership decision required this week.'};
  }
  _healthBridge(snapshot, previous, sourceConfidence){
    const base=previous?.health??50;
    const activeRatio=snapshot.headcount?this._pct(snapshot.activeHeadcount,snapshot.headcount):0;
    const drivers=[
      {label:'Delivery completion',impact:Math.round((snapshot.progress-(previous?.progress??50))*0.25),value:`${snapshot.progress}% complete`},
      {label:'Execution hygiene',impact:-Math.min(24,snapshot.blockers*6+snapshot.overdue*3+snapshot.stale*2),value:`${snapshot.blockers} blockers, ${snapshot.overdue} overdue, ${snapshot.stale} stale`},
      {label:'Ops stability',impact:-Math.min(22,snapshot.p1*10+snapshot.incidentOpen+snapshot.slaBreaches*3),value:`${snapshot.p1} P1, ${snapshot.incidentOpen} incidents, ${snapshot.slaBreaches} SLA breaches`},
      {label:'Capacity signal',impact:snapshot.headcount?Math.round((activeRatio-92)*0.4):-8,value:snapshot.headcount?`${activeRatio}% active headcount`:'HRIS not live'},
      {label:'Source confidence',impact:Math.round((sourceConfidence.score-80)*0.25),value:`${sourceConfidence.score}% live-source score`},
    ];
    const driverTotal=drivers.reduce((sum,d)=>sum+d.impact,0);
    const computed=Math.max(0,Math.min(100,base+driverTotal));
    const current=snapshot.health||computed;
    const reconcile=current-computed;
    const allDrivers=Math.abs(reconcile)>=1?[...drivers,{label:'Health calibration',impact:reconcile,value:'ADO health score alignment'}]:drivers;
    return {base,current,computed,drivers:allDrivers,delta:current-base};
  }
  _qualityGateSlides(slides){
    const policy=this._qualityGateMode();
    const blockers=[],warnings=[];
    const intel=this._intelligence||{};
    const hermesSlides=this._an?.hermes?.slides||{};
    if(!slides.length)blockers.push('No slides selected for export');
    // Headline check: accept either auto-generated headline OR Mistral/Hermes headline for the slide
    const missingHeads=slides.filter(sl=>{
      if(sl.name==='Title')return false;
      if(intel.headlines?.[sl.key])return false;
      // Map slide key to hermes key (e.g. 'itsm-analytics' → 'itsm', 'delivery-sprint' → 'delivery')
      const hermesKey=sl.key.replace(/-analytics|-operations|-infrastructure|-capacity|-quality|-steps|-centre|-prs$/,'').replace(/-sprint$/,'').replace(/-next$/,'');
      if(hermesSlides[hermesKey]?.headline||hermesSlides[sl.key]?.headline)return false;
      return true;
    }).map(sl=>sl.name);
    if(missingHeads.length)warnings.push(`Missing action-title headlines: ${missingHeads.slice(0,5).join(', ')}`);
    const missingTaxonomy=slides.filter(sl=>!sl.mece).map(sl=>sl.name);
    if(missingTaxonomy.length)blockers.push(`Missing MECE taxonomy: ${missingTaxonomy.join(', ')}`);
    const badRag=(intel.rag||[]).filter(r=>!r.domain||!r.status||!r.threshold||!r.evidence);
    if(badRag.length)blockers.push(`${badRag.length} RAG row(s) lack required evidence`);
    // Skip live-source check when Hermes intelligence is present (data arrived via workflow, not direct ADO/BN fetches)
    const hasHermesIntelligence=Object.keys(hermesSlides).length>0||(this._an?.hermes?.actions||[]).length>0;
    if(!hasHermesIntelligence && (this.config.requiredLiveSources||[]).length && !this._sourceEvidence.length && !this.config.allowEmptyReport){
      blockers.push('Required live sources are configured but no source evidence was captured');
    }
    if(intel.sourceConfidence?.total && intel.sourceConfidence.score<70)warnings.push(`Source confidence is Low (${intel.sourceConfidence.score}%)`);
    if(intel.risks?.some(r=>r.severity==='High') && !intel.decisions?.length)blockers.push('High risks exist without a decision ask');
    if(this._deckMode==='executive' && slides.length>12)warnings.push(`Executive deck has ${slides.length} slides; target is 12 or fewer`);
    // New 10-slide ops deck: threshold is 8 (not 20 from the old screenshot-per-tab approach)
    if(this._deckMode==='ops' && slides.length<8)warnings.push(`Ops deck has only ${slides.length} slides; check ENABLED_SLIDES filters`);
    const status=blockers.length?'blocked':warnings.length?'warn':'pass';
    const gate={policy,mode:this._deckMode,status,blockers,warnings,checkedAt:new Date().toISOString()};
    if(policy!=='off'&&(warnings.length||blockers.length)){
      console.warn(`[PPTX] Quality gate ${status}: ${[...blockers,...warnings].join(' | ')}`);
    }
    if(policy==='strict'&&blockers.length){
      throw new Error(`PPTX quality gate blocked export: ${blockers.join('; ')}`);
    }
    return gate;
  }
  _metricDelta(current, previous, unit='', goodDirection='up'){
    const c=this._num(current), p=previous===null||previous===undefined?null:this._num(previous);
    const delta=p===null?null:c-p;
    const deltaPct=p&&p!==0?Math.round((delta/p)*100):null;
    const favorable=delta===null?null:goodDirection==='down'?delta<=0:delta>=0;
    return { current:c, previous:p, delta, deltaPct, unit, favorable };
  }
  _formatDelta(m){
    if(m.delta===null||m.delta===undefined)return'Baseline pending';
    const abs=Math.abs(m.delta);
    const sign=m.delta>0?'+':m.delta<0?'-':'';
    const suffix=m.unit==='%'||m.unit==='pts'?' pts':m.unit?` ${m.unit}`:'';
    const pct=m.deltaPct===null||m.deltaPct===undefined?'':` (${m.deltaPct>0?'+':''}${m.deltaPct}%)`;
    return `${sign}${abs}${suffix}${pct}`;
  }
  _currentSnapshot(sprintData,bnData,analysis){
    const stats=sprintData?.stats||{};
    const inc=analysis?.incidents||{};
    const it=analysis?.itTickets||{};
    const hc=analysis?.headcount||{};
    const bna=analysis?.bnAnalysis||{};
    return {
      progress:this._pct(stats.closed||0,stats.total||0),
      health:stats.healthScore||0,
      closed:stats.closed||0,
      active:stats.active||0,
      blockers:(stats.blockedItems||[]).length,
      overdue:(stats.overdueItems||[]).length,
      stale:(stats.staleItems||[]).length,
      supportTotal:Array.isArray(bnData)?bnData.length:0,
      supportOpen:Array.isArray(bnData)?bnData.filter(c=>this._bns(c)==='Open').length:0,
      supportOld:bna.oldOpenCases||0,
      supportResolution:bna.resolutionRate||0,
      incidents:inc.total||0,
      incidentOpen:inc.open||0,
      p1:inc.p1Count||0,
      mttr:inc.mttr||0,
      itTickets:it.total||0,
      itOpen:it.open||0,
      slaBreaches:it.slaBreaches||0,
      cloudPending:analysis?.cloudRequests?.pending||0,
      legalHigh:analysis?.legalCases?.highPriority||0,
      headcount:hc.total||analysis?.peoplestrong?.employees?.total||0,
      activeHeadcount:hc.active||analysis?.peoplestrong?.employees?.active||0,
      forecast:analysis?.forecast?.probability||0,
    };
  }
  _loadPreviousRun(dateFrom,dateTo){
    const root=this.config.output?.dir||'output';
    const files=[];
    const walk=(dir)=>{
      if(!fs.existsSync(dir))return;
      for(const e of fs.readdirSync(dir,{withFileTypes:true})){
        const p=path.join(dir,e.name);
        if(e.isDirectory())walk(p);
        else if(e.isFile()&&e.name.endsWith('.json'))files.push(p);
      }
    };
    try{walk(root);}catch(_){return null;}
    const parsed=files.map(file=>{
      try{
        const stat=fs.statSync(file);
        const json=JSON.parse(fs.readFileSync(file,'utf8'));
        const meta=json.meta||{};
        return {file,stat,json,dateFrom:meta.dateFrom,dateTo:meta.dateTo,generatedAt:meta.generatedAt};
      }catch(_){return null;}
    }).filter(Boolean);
    const currentKey=dateFrom&&dateTo?`${dateFrom}_${dateTo}`:'';
    const prior=parsed.filter(r=>`${r.dateFrom||''}_${r.dateTo||''}`!==currentKey)
      .sort((a,b)=>{
        const ad=a.dateTo?new Date(a.dateTo).getTime():a.stat.mtimeMs;
        const bd=b.dateTo?new Date(b.dateTo).getTime():b.stat.mtimeMs;
        return bd-ad;
      });
    return prior[0]?.json||null;
  }
  _sourceConfidence(sourceEvidence){
    const ev=sourceEvidence||[];
    const total=ev.length;
    const live=ev.filter(e=>e.status==='live').length;
    const cached=ev.filter(e=>e.status==='cached').length;
    const failed=ev.filter(e=>['failed','missing','skipped','empty'].includes(e.status)).length;
    const score=total?Math.round((live/total)*100):0;
    const label=score>=90?'High':score>=70?'Medium':'Low';
    const latest=ev.map(e=>e.fetchedAt).filter(Boolean).sort().pop();
    const refreshed=latest?new Date(latest).toLocaleString('en-IN',{timeZone:'Asia/Kolkata',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'not timestamped';
    return {total,live,cached,failed,score,label,refreshed,issues:ev.filter(e=>e.status!=='live')};
  }
  _ragRows(snapshot, sourceConfidence){
    const progress=snapshot.progress;
    const activeRatio=snapshot.headcount?this._pct(snapshot.activeHeadcount,snapshot.headcount):100;
    const rows=[
      {domain:'Delivery completion',value:`${progress}%`,status:progress>=70?'green':progress>=50?'amber':'red',threshold:'G >=70%; A 50-69%; R <50%',evidence:`${snapshot.closed} closed, ${snapshot.active} active`},
      {domain:'Delivery blockers',value:String(snapshot.blockers),status:snapshot.blockers===0?'green':snapshot.blockers<=2?'amber':'red',threshold:'G 0; A 1-2; R >2',evidence:`${snapshot.overdue} overdue, ${snapshot.stale} stale`},
      {domain:'Support aging',value:String(snapshot.supportOld),status:snapshot.supportOld===0?'green':snapshot.supportOld<=5?'amber':'red',threshold:'G 0; A 1-5; R >5',evidence:`${snapshot.supportOpen}/${snapshot.supportTotal} open cases`},
      {domain:'Operations incidents',value:`${snapshot.incidentOpen} open`,status:snapshot.p1>0?'red':snapshot.incidentOpen<=5?'green':snapshot.incidentOpen<=10?'amber':'red',threshold:'G <=5 open, no P1; A <=10; R P1 or >10',evidence:`${snapshot.p1} P1, MTTR ${snapshot.mttr}h`},
      {domain:'ITSM SLA',value:String(snapshot.slaBreaches),status:snapshot.slaBreaches===0?'green':snapshot.slaBreaches<=2?'amber':'red',threshold:'G 0; A 1-2; R >2',evidence:`${snapshot.itOpen}/${snapshot.itTickets} IT tickets open`},
      {domain:'Capacity signal',value:snapshot.headcount?`${activeRatio}% active`:'No HRIS',status:activeRatio>=95?'green':activeRatio>=90?'amber':'red',threshold:'G >=95%; A 90-94%; R <90%',evidence:`${snapshot.activeHeadcount}/${snapshot.headcount} active`},
      {domain:'Source confidence',value:`${sourceConfidence.score}%`,status:sourceConfidence.score>=90?'green':sourceConfidence.score>=70?'amber':'red',threshold:'G >=90% live; A 70-89%; R <70%',evidence:`${sourceConfidence.live}/${sourceConfidence.total} live sources`},
    ];
    return rows;
  }
  _riskRegister(snapshot, analysis, sourceConfidence){
    const risks=[];
    const add=(severity,area,risk,evidence,owner,ask)=>risks.push({severity,area,risk,evidence,owner,ask});
    if(snapshot.blockers>0)add('High','Delivery',`${snapshot.blockers} blocker(s) may hold sprint commitment`,`${snapshot.overdue} overdue and ${snapshot.stale} stale items`,'Tech Lead','Resolve or escalate blockers within 24 hours');
    if(snapshot.progress<50)add('High','Delivery',`Sprint completion is below threshold at ${snapshot.progress}%`,`${snapshot.closed} closed, ${snapshot.active} active`,'Delivery Lead','Confirm scope cut or recovery plan');
    else if(snapshot.progress<70)add('Medium','Delivery',`Sprint completion is Amber at ${snapshot.progress}%`,`${snapshot.closed} closed, ${snapshot.active} active`,'Scrum Master','Prioritize must-close items');
    if(analysis?.forecast?.canFinish===false)add('High','Forecast',`Forecast shows only ${snapshot.forecast}% probability of on-time finish`,'Forecast model below committed threshold','Product Owner','Approve scope trade-off');
    if(snapshot.supportOld>0)add(snapshot.supportOld>5?'High':'Medium','Support',`${snapshot.supportOld} aging support case(s) create SLA risk`,`${snapshot.supportOpen}/${snapshot.supportTotal} open cases`,'Support Lead','Run aging burn-down');
    if(snapshot.p1>0)add('High','Operations',`${snapshot.p1} P1 incident(s) require leadership visibility`,`${snapshot.incidentOpen} incidents open; MTTR ${snapshot.mttr}h`,'Ops Lead','Confirm incident owner and ETA');
    else if(snapshot.incidentOpen>5)add('Medium','Operations',`Incident queue is elevated at ${snapshot.incidentOpen} open`,`${snapshot.incidents} total incidents`,'Ops Lead','Review queue aging');
    if(snapshot.slaBreaches>0)add(snapshot.slaBreaches>2?'High':'Medium','ITSM',`${snapshot.slaBreaches} SLA breach(es) need remediation`,`${snapshot.itOpen}/${snapshot.itTickets} IT tickets open`,'IT Desk Lead','Clear breach backlog');
    if(snapshot.cloudPending>5)add('Medium','Cloud',`${snapshot.cloudPending} cloud request(s) pending`, 'Cloud queue above operating threshold','Cloud Lead','Prioritize blocker-linked requests');
    if(snapshot.legalHigh>0)add('Medium','Legal',`${snapshot.legalHigh} high-priority legal item(s) open`,'Legal queue has priority exposure','Legal Lead','Confirm legal closure plan');
    if(sourceConfidence.score<90)add(sourceConfidence.score<70?'High':'Medium','Data quality',`Source confidence is ${sourceConfidence.label}`,`${sourceConfidence.live}/${sourceConfidence.total} live; ${sourceConfidence.failed} failed/missing`,'WSR Owner','Refresh failed/cached sources before steering review');
    return risks.sort((a,b)=>({High:0,Medium:1,Low:2}[a.severity]-{High:0,Medium:1,Low:2}[b.severity])).slice(0,12);
  }
  _decisionItems(risks, analysis){
    const fromRisks=risks.filter(r=>r.severity==='High'||r.severity==='Medium').slice(0,6).map(r=>({
      decision:r.ask,
      recommendation:r.ask,
      evidence:r.evidence,
      owner:r.owner,
      due:r.severity==='High'?'24 hours':'This week',
      status:r.severity,
    }));
    const actions=(analysis?.actions||[]).slice(0,4).map(a=>({
      decision:a.action||a.text||String(a),
      recommendation:a.reason||'Assign owner and track closure',
      evidence:a.reason||'Generated action item',
      owner:a.owner||'TBD',
      due:a.priority==='P1'?'24 hours':'This week',
      status:a.priority==='P1'?'High':'Medium',
    }));
    const seen=new Set();
    return [...fromRisks,...actions].filter(d=>{
      const key=d.decision.toLowerCase();
      if(seen.has(key))return false;
      seen.add(key);
      return true;
    }).slice(0,8);
  }
  _buildExecutiveIntelligence(sprintData,bnData,analysis,opsData,options={}){
    const previous=options.previousRun||this._loadPreviousRun(options.dateFrom,options.dateTo);
    const snapshot=this._currentSnapshot(sprintData,bnData,analysis);
    const prev=previous?this._currentSnapshot(previous.sprintData,previous.bnData,previous.analysis||{}):null;
    const sourceConfidence=this._sourceConfidence(options.sourceEvidence||this._sourceEvidence||[]);
    const rag=this._ragRows(snapshot,sourceConfidence);
    const risks=this._riskRegister(snapshot,analysis,sourceConfidence);
    const decisions=this._decisionItems(risks,analysis);
    const spine=this._narrativeSpine(snapshot,rag,risks,sourceConfidence,decisions);
    const healthBridge=this._healthBridge(snapshot,prev,sourceConfidence);
    const wow=[
      {label:'Sprint completion',...this._metricDelta(snapshot.progress,prev?.progress,'pts','up')},
      {label:'Health score',...this._metricDelta(snapshot.health,prev?.health,'pts','up')},
      {label:'Closed items',...this._metricDelta(snapshot.closed,prev?.closed,'items','up')},
      {label:'Open support cases',...this._metricDelta(snapshot.supportOpen,prev?.supportOpen,'cases','down')},
      {label:'Aging support cases',...this._metricDelta(snapshot.supportOld,prev?.supportOld,'cases','down')},
      {label:'Open incidents',...this._metricDelta(snapshot.incidentOpen,prev?.incidentOpen,'incidents','down')},
      {label:'ITSM SLA breaches',...this._metricDelta(snapshot.slaBreaches,prev?.slaBreaches,'breaches','down')},
      {label:'Headcount',...this._metricDelta(snapshot.headcount,prev?.headcount,'people','up')},
    ];
    const red=rag.filter(r=>r.status==='red').length;
    const amber=rag.filter(r=>r.status==='amber').length;
    const overall=red>0?'Red':amber>0?'Amber':'Green';
    const topRisk=risks[0];
    const exec={
      overall,
      situation:`${overall} status: delivery is ${snapshot.progress}% complete with health score ${snapshot.health}/100.`,
      complication:topRisk?`${topRisk.area}: ${topRisk.risk}.`:'No critical risk breached the current thresholds.',
      recommendation:decisions[0]?.recommendation||'Maintain current execution cadence and monitor source confidence.',
      decision:decisions[0]?.decision||'No leadership decision required this week.',
    };
    // McKinsey assertion titles: STATUS + PRIMARY DRIVER + IMPLIED ACTION/DEADLINE
    // Each headline should stand alone as the key message of that slide.
    const highRisks = risks.filter(r => r.severity === 'High').length;
    const unfavorable = wow.filter(m => m.favorable === false).length;
    const headlines = {
      // Delivery
      'executive-summary': snapshot.blockers > 0
        ? `${overall}: ${snapshot.blockers} unresolved blocker(s) threaten the ${snapshot.progress}% delivery commitment — escalation needed`
        : snapshot.progress < 70
        ? `${overall}: sprint pace at ${snapshot.progress}% is insufficient — scope trade-off required before week-end`
        : `On track: sprint at ${snapshot.progress}% with no blocker exposure and health score ${snapshot.health}`,
      'sprint-status': snapshot.blockers > 0
        ? `${snapshot.blockers} blocker(s) and ${snapshot.overdue} overdue item(s) are the primary delivery risk this sprint`
        : `Sprint executing at ${snapshot.progress}% — ${snapshot.closed} closed, ${snapshot.active} in progress, health ${snapshot.health}/100`,
      'sprint-dashboard': snapshot.health < 50
        ? `Delivery health critical at ${snapshot.health}/100 — intervention required to protect sprint commitment`
        : snapshot.health < 70
        ? `Delivery health watchlist at ${snapshot.health}/100 — ${snapshot.closed} of ${snapshot.closed + snapshot.active} items closed`
        : `Sprint healthy at ${snapshot.health}/100 — velocity on track with ${snapshot.closed} items closed this period`,
      'type-breakdown': (() => { const types = Object.keys(sprintData?.stats?.byType||{}); const topType = types.length ? types[0] : null; return topType ? `${topType} dominates the work mix — review balance across ${types.length} active type(s)` : `Work type distribution across ${types.length} categories requires attention`; })(),
      'work-items-by-type': (() => { const types = Object.keys(sprintData?.stats?.byType||{}); return `Work mix across ${types.length} type(s) — verify bug-to-feature ratio is sustainable for sprint velocity`; })(),
      'team-summary': (() => { const team = Object.keys(sprintData?.stats?.byAssignee||{}); return team.length > 0 ? `${team.length} contributor(s) carrying ${snapshot.active} active item(s) — identify concentration risk before it becomes a blocker` : 'Team allocation data not available — assign all active items to named owners'; })(),
      'weekly-activity': (() => { const closed = sprintData?.stats?.closedThisWeek || snapshot.closed; const opened = sprintData?.stats?.newItems || 0; return closed >= opened ? `Positive flow: ${closed} item(s) closed vs ${opened} opened this week — maintain cadence` : `Backlog growing: ${opened} item(s) opened vs ${closed} closed — net scope expansion requires review`; })(),
      // Risk
      'highlights-risks': snapshot.blockers > 0
        ? `${snapshot.blockers} blocker(s) averaging ${analysis?.blockedAge?.avgAge||0}d without resolution — each day increases sprint miss probability`
        : snapshot.overdue > 0
        ? `${snapshot.overdue} overdue item(s) need owner reassignment or scope removal before the next steering review`
        : 'No active blockers — maintain hygiene by clearing stale items before they become blockers',
      'risk-register': highRisks > 0
        ? `${highRisks} high-priority risk(s) require a named owner and resolution commitment before the steering meeting`
        : `${risks.length} risk(s) identified — all medium or below; monitor weekly`,
      // Support
      'support-cases': snapshot.supportOld > 5
        ? `${snapshot.supportOld} support case(s) aging beyond 5 days are creating SLA exposure — run burn-down before close of business`
        : snapshot.supportOpen > 10
        ? `Support queue elevated at ${snapshot.supportOpen} open — resolution rate ${snapshot.supportResolution}% requires process review`
        : `Support queue healthy at ${snapshot.supportOpen} open with ${snapshot.supportResolution}% resolution rate`,
      'bn-dashboard': snapshot.supportOpen > 0
        ? `${snapshot.supportOpen} of ${snapshot.supportTotal} cases remain open — focus on the top category to move the resolution rate`
        : `All ${snapshot.supportTotal} support case(s) resolved this period — monitor for recurrence`,
      'bn-breakdown': (() => {
        const bycat = Object.entries(analysis?.bnAnalysis?.byCategory || {});
        const top = bycat.sort((a,b) => b[1]-a[1])[0];
        return top
          ? `${top[0]} drives ${top[1]} cases (${Math.round(top[1]/(Array.isArray(bnData)?bnData.length:1)*100)}%) — resolving this category moves the resolution rate`
          : `Support category breakdown — insufficient data to identify dominant driver`;
      })(),
      'bn-details': `Case-level evidence for the ${snapshot.supportOpen} open item(s) — verify each has an owner and next-action date`,
      'bn-highlights': snapshot.supportOld > 0
        ? `${snapshot.supportOld} aging case(s) are the primary SLA risk — escalate to owners immediately`
        : `Support momentum positive — sustain resolution rate above ${snapshot.supportResolution}%`,
      // Operations
      'operations-overview': snapshot.p1 > 0
        ? `${snapshot.p1} P1 incident(s) active — leadership visibility required; MTTR ${snapshot.mttr}h against SLA`
        : snapshot.incidentOpen > 5
        ? `Incident queue elevated at ${snapshot.incidentOpen} open with ${snapshot.slaBreaches} SLA breach(es) — review prioritisation`
        : `Operations stable — ${snapshot.incidentOpen} incident(s) open, no P1 exposure`,
      'production-incidents': snapshot.p1 > 0
        ? `${snapshot.p1} P1 incident(s) require immediate owner confirmation and ETA — every hour counts on P1`
        : `Incident queue at ${snapshot.incidentOpen} open — MTTR ${snapshot.mttr}h, ${snapshot.slaBreaches} SLA breach(es) to clear`,
      'it-helpdesk-legal': snapshot.slaBreaches > 0
        ? `${snapshot.slaBreaches} ITSM SLA breach(es) require remediation; ${snapshot.legalHigh} high-priority legal item(s) need legal lead confirmation`
        : `IT desk and legal queues within operating norms — ${snapshot.itOpen} IT open, ${snapshot.legalHigh} legal priority`,
      'cloud-provisioning': snapshot.cloudPending > 5
        ? `${snapshot.cloudPending} cloud request(s) pending — prioritise those blocking sprint deliverables`
        : `Cloud provisioning queue at ${snapshot.cloudPending} pending — within operating threshold`,
      // HR / Headcount
      'headcount-dashboard': (() => { const activeRatio = snapshot.headcount ? Math.round(snapshot.activeHeadcount/snapshot.headcount*100) : 0; return activeRatio < 90 ? `Active headcount at ${activeRatio}% of HRIS baseline — investigate inactive records before next board report` : `Headcount stable at ${snapshot.activeHeadcount} active (${activeRatio}% of ${snapshot.headcount} HRIS baseline)`; })(),
      'headcount-reconciliation': `Reconciliation between BN and PeopleStrong identifies ${sourceConfidence.issues?.length||0} data discrepancy(ies) requiring HR owner resolution`,
      // Executive intelligence
      'rag-thresholds': red > 0
        ? `${red} domain(s) in Red — delivery commitment and ops stability require leadership decisions this week`
        : amber > 0
        ? `${amber} domain(s) in Amber — proactive intervention now prevents Red status next week`
        : 'All domains Green — maintain current controls and monitor source confidence',
      'narrative-spine': `${overall}: ${spine.decision}`,
      'health-score-bridge': healthBridge.delta < 0
        ? `Health score declined ${Math.abs(healthBridge.delta)} pts — ${healthBridge.drivers.filter(d=>d.impact<0).map(d=>d.label).slice(0,2).join(' and ')} are the primary drivers`
        : healthBridge.delta > 0
        ? `Health score improved ${healthBridge.delta} pts — validate that delivery and ops improvements are sustained`
        : `Health score unchanged at ${snapshot.health} — review driver mix for hidden deterioration`,
      'executive-dashboard': `${overall} operating status — delivery ${snapshot.progress}%, ops ${snapshot.incidentOpen} incident(s), ${snapshot.activeHeadcount} active headcount`,
      // Analytics
      'trends': unfavorable > 0
        ? `${unfavorable} metric(s) moving the wrong direction week-over-week — act before trends become structural`
        : 'All tracked metrics improving or stable week-over-week — sustain execution discipline',
      'wow-deltas': unfavorable > 0
        ? `${unfavorable} unfavourable delta(s) this week — prioritise reversing the metrics driving the ${overall} status`
        : 'Week-over-week movement positive across all tracked dimensions',
      'delta': (() => { const net = analysis?.delta?.netChange||0; return net > 0 ? `Scope expanded by ${net} net item(s) this sprint — assess impact on delivery commitment before accepting further additions` : net < 0 ? `Scope reduced by ${Math.abs(net)} item(s) — confirm remaining work aligns with sprint goal` : 'Sprint scope stable — no net additions or removals this week'; })(),
      'burndown': (() => { const remaining = Math.max(0,(analysis?.burndown?.totalItems||0)-(analysis?.burndown?.actual?.slice(-1)[0]||0)); return remaining > 0 ? `${remaining} item(s) remain on burndown — verify daily close rate is sufficient to finish on time` : 'Burndown on track — continue current close rate to meet sprint end date'; })(),
      'retrospective': (() => {
        const items = sprintData?.retrospective?.length || analysis?.actions?.length || 0;
        const wins  = sprintData?.retrospectiveWins?.length || 0;
        return items > 0
          ? `${items} retrospective item(s) identified — ${wins} win(s) to sustain, ${items - wins} improvement(s) to action`
          : snapshot.blockers > 0
            ? `Retrospective: ${snapshot.blockers} blocker(s) must be root-caused before next sprint planning`
            : `No retrospective items raised — confirm sprint ceremonies are running`;
      })(),
      'decision-required': decisions.length > 0
        ? `${decisions.length} decision(s) required from leadership — delay beyond this meeting increases delivery and compliance risk`
        : 'No leadership decision required this week — review next week\'s risk radar for emerging items',
      'action-items': `${analysis?.actions?.length||0} action item(s) assigned — each must have a named owner and a committed due date`,
      'glossary': `Appendix: metric definitions and source refresh rules — refer before challenging any data point in review`,
      'ai-insights': 'AI-enhanced analysis — Hermes identifies patterns and recommendations beyond the standard weekly signal set',
      'source-trust': sourceConfidence.score < 70
        ? `Source confidence Low at ${sourceConfidence.score}% — ${sourceConfidence.failed} failed feed(s) must be refreshed before this deck is shared`
        : `Source confidence ${sourceConfidence.label} — ${sourceConfidence.live}/${sourceConfidence.total} live feeds verified`,
      // ── New 10-slide McKinsey redesign — auto-generated fallback headlines ────
      'command-centre': red > 0
        ? `${overall}: ${red} domain(s) in Red — executive decisions required to protect delivery commitment`
        : amber > 0
        ? `${overall}: ${amber} domain(s) need intervention — proactive risk action this week prevents escalation`
        : `${overall} operating week — all domains within threshold; maintain current execution discipline`,
      'delivery-sprint': snapshot.blockers > 0
        ? `${snapshot.blockers} blocker(s) and ${snapshot.overdue} overdue items threaten the ${snapshot.progress}% delivery target`
        : `Sprint ${snapshot.progress}% complete — ${snapshot.closed} done, ${snapshot.active} active, health ${snapshot.health}/100`,
      'pipelines-prs': (() => { const failing = opsData?.pipelines?.failing || 0; return failing > 0 ? `${failing} pipeline failure(s) active — blocking deployment and increasing cycle-time` : 'CI/CD pipelines healthy — maintain gate quality to protect deployment frequency'; })(),
      'itsm-analytics': (() => { const stale = opsData?.itsmSummary?.staleOpen || 0; return stale > 20 ? `${stale} stale ITSM cases breaching SLA — triage required before next reporting cycle` : `ITSM within operating norms — continue monitoring SLA compliance`; })(),
      'oeg-operations': (() => { const stale = opsData?.oegSummary?.stale || 0; const open = opsData?.oegSummary?.open || 0; return stale > 400 ? `OEG backlog stale ratio critical — ${stale} items require closure review to reduce process debt` : `OEG operations stable — ${open} open items within acceptable threshold`; })(),
      'cloud-infrastructure': (() => { const failed = opsData?.cloudSummary?.failed || 0; return failed > 0 ? `${failed} failed cloud provision(s) require root-cause — month-end capacity lock at risk` : 'Cloud provisioning on target — maintain review cadence for pending requests'; })(),
      'headcount-capacity': (() => { const diffs = opsData?.headcountSummary?.bucketDiffs || 0; return diffs > 50 ? `${diffs} headcount mismatches flagged — reconcile with HR before next payroll cycle` : 'Headcount reconciliation within tolerance — sustain monthly hygiene process'; })(),
      'governance-quality': (() => { const critical = (opsData?.govRiskQueue||[]).filter(r=>r.priority==='Critical').length; return critical > 0 ? `${critical} critical unmitigated risk(s) — leadership must confirm remediation owner and deadline` : 'Risk register under control — no critical items without a mitigation owner'; })(),
      'actions-next-steps': (() => { const totalActs = (this._an?.hermes?.actions||[]).length; const crit = (this._an?.hermes?.actions||[]).filter(a=>a.priority==='CRITICAL').length; return crit > 0 ? `${crit} CRITICAL action(s) of ${totalActs} total require owner confirmation before next stand-up` : `${totalActs} action item(s) assigned — review ownership and timelines with leads`; })(),
    };
    return {snapshot,previous:prev,sourceConfidence,rag,risks,decisions,wow,spine,healthBridge,exec,headlines};
  }

  _trend(v){if(!v||v===0)return'→0';return v>0?`↑${v}`:`↓${Math.abs(v)}`;}
  _trendColor(v){return v>0?this.C.green:v<0?this.C.red:this.C.steel;}
  _noData(s,x,y,w,h,title){
    const C=this.C;
    s.addShape(this.pptx.ShapeType.rect,{x,y,w,h,line:{color:C.lightGray,width:0.5,dashType:'dash'}});
    s.addText('—',{x:x+w/2-0.3,y:y+h/2-0.35,w:0.6,h:0.3,fontSize:18,fontFace:'Arial',color:C.medGray,align:'center',valign:'bottom'});
    s.addText(`No data available`,{x:x+0.1,y:y+h/2-0.05,w:w-0.2,h:0.3,fontSize:9,fontFace:'Arial',color:C.medGray,align:'center',italic:true});
    if(title)s.addText(title,{x:x+0.1,y:y+h/2+0.2,w:w-0.2,h:0.2,fontSize:7,fontFace:'Arial',color:C.lightGray,align:'center'});
    console.log(`[PPTX] Placeholder "${title||'No data'}" shown`);
  }
  _ghostSlide(s, sectionName, ragColor, message) {
    const C = this.C;
    s.background = { color: QB.white };
    // Left accent bar — QB primary brand accent
    s.addShape(this.pptx.ShapeType.rect, { x: 0, y: 0, w: 0.25, h: 7.5, fill: { color: QB.primary } });
    // Section name
    s.addText(sectionName, { x: 0.5, y: 0.5, w: 12.5, h: 0.3, fontSize: 14, fontFace: TYPE.font, color: QB.neutral });
    // "No activity" heading
    s.addText('No activity this period', { x: 0.5, y: 1.5, w: 12.5, h: 0.5, fontSize: 28, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    // Thin rule
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 2.3, w: 12.5, h: 0.015, fill: { color: QB.primary } });
    // Message text
    s.addText(message, { x: 0.5, y: 2.5, w: 12.5, h: 0.5, fontSize: 11, fontFace: TYPE.font, color: QB.neutral });
    // RAG status pill
    const pillColor = ragColor || QB.primary;
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 3.4, w: 1.6, h: 0.35, fill: { color: pillColor } });
    s.addText('No data', { x: 0.5, y: 3.4, w: 1.6, h: 0.35, fontSize: 10, fontFace: TYPE.font, color: QB.white, bold: true, align: 'center', valign: 'middle' });
  }

  _sectionHasData(sectionName, sprintData, bnData, analysis, opsData) {
    switch (sectionName) {
      case 'engineering': return (sprintData?.stats?.total || 0) > 0;
      case 'support':     return Array.isArray(bnData) && bnData.length > 0;
      case 'operations':  return ((analysis?.incidents?.total || 0) + (analysis?.itTickets?.total || 0) + (analysis?.cloudRequests?.total || 0)) > 0;
      case 'hr':          return (analysis?.headcount?.total || 0) > 0;
      default:            return true;
    }
  }

  _progressBar(s,x,y,w,pct,label){
    const C=this.C,barH=0.26,bgColor=C.lightGray,fgColor=pct>=70?C.green:pct>=40?C.blue:C.red;
    s.addShape(this.pptx.ShapeType.rect,{x,y,w,barH,fill:{color:bgColor}});
    if(pct>0)s.addShape(this.pptx.ShapeType.rect,{x,y,w:Math.max(0.05,w*pct/100),barH,fill:{color:fgColor}});
    s.addText(`${pct}%`,{x,y,w,barH,fontSize:10,fontFace:'Arial',color:pct>40?C.white:C.darkGray,bold:true,align:'center',valign:'middle'});
    if(label)s.addText(label,{x,y:y-0.15,w,h:0.14,fontSize:6.5,fontFace:'Arial',color:C.steel,bold:true});
  }
  _healthBadge(s,x,y,score){
    const C=this.C,c=score>=70?C.green:score>=40?C.blue:C.red;
    const lbl=score>=70?'HEALTHY':score>=40?'MODERATE':'AT RISK';
    s.addText(`${score}`,{x,y:y,w:1.4,h:0.3,fontSize:20,fontFace:'Arial',color:c,bold:true,align:'center'});
    s.addText(lbl,{x,y:y+0.28,w:1.4,h:0.14,fontSize:6.5,fontFace:'Arial',color:C.steel,align:'center',bold:true});
    s.addShape(this.pptx.ShapeType.rect,{x,y:y+0.42,w:1.4,h:0.025,fill:{color:c}});
  }

  // McKinsey: donut/pie charts replaced with sorted horizontal bar charts — quantitatively legible
  _dough(s, x, y, w, h, data, colors, title, tc) {
    const f = (data || []).filter(d => d[1] > 0).sort((a, b) => b[1] - a[1]);
    if (!f.length) { this._noData(s, x, y, w, h, title); return; }
    this._consultingBar(s, x, y, w, h, {
      labels: f.map(d => String(d[0])),
      values: f.map(d => Number(d[1])),
    }, [this.C.navy, this.C.charcoal, this.C.midGray, this.C.red, this.C.amber, this.C.green].slice(0, f.length),
    { horizontal: true, title });
  }

  _bar(s,x,y,w,h,data,colors,opts={}){
    try{const cd=data.series||[{name:'Count',labels:data.labels,values:data.values}];if(cd.every(sr=>sr.values.every(v=>v===0))){this._noData(s,x,y,w,h,opts.title);return;}
    this._cf(s,x,y,w,h);
    const co={x,y,w,h,showTitle:!!opts.title,title:opts.title||'',titleFontSize:8,titleColor:opts.titleColor||this.C.darkGray,showLegend:!!data.series,legendPos:'b',legendFontSize:6.5,chartColors:colors||[this.C.navy],barDir:opts.horizontal?'bar':'col',barGapWidthPct:80,showValue:true,dataLabelPosition:'outEnd',dataLabelFontSize:7,dataLabelColor:this.C.darkGray,catAxisLabelFontSize:6.5,valAxisLabelFontSize:6.5,catAxisLabelColor:this.C.darkGray,valAxisLabelColor:this.C.darkGray,valGridLine:{style:'none'}};
    if(opts.barGrouping)co.barGrouping=opts.barGrouping;
    s.addChart(this.pptx.charts.BAR,cd,co);
    console.log(`[PPTX] Bar "${opts.title}" OK`);}catch(e){console.error(`[PPTX] Bar err "${opts.title}": ${e.message}`);}
  }

  // ─── CONSULTING-STYLE HELPERS ───
  _consultingHeader(s, title, subtitle, sn, ts) {
    const C = this.C;
    const actionTitle = this._actionTitle(title);
    const endDate = (this._dateRange?.dateTo) ? new Date(this._dateRange.dateTo) : new Date();
    const ds = endDate.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' });
    s.addText(`Data as of ${ds}`, { x: 9.5, y: 0.25, w: 3.5, h: 0.3, fontSize: 8, fontFace: 'Arial', color: C.midGray, align: 'right' });
    s.addText(actionTitle, { x: 0.35, y: 0.55, w: 12.6, h: 0.65, fontSize: 20, fontFace: 'Arial', color: C.navy, bold: true, lineSpacing: 24 });
    if (subtitle) {
      s.addText(subtitle, { x: 0.35, y: 1.22, w: 12.6, h: 0.28, fontSize: 10, fontFace: 'Arial', color: C.midGray });
    }
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: subtitle ? 1.52 : 1.25, w: 12.6, h: 0.015, fill: { color: C.navy } });
  }

  _consultingFooter(s, source, sn, ts) {
    const C = this.C;
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: 6.95, w: 12.6, h: 0.008, fill: { color: C.lightGray } });
    const conf = this._sourceConfidenceFooter();
    s.addText(`${source}  |  ${conf}  |  CONFIDENTIAL  |  For internal use only`, { x: 0.35, y: 7.05, w: 11.5, h: 0.22, fontSize: 8, fontFace: 'Arial', color: C.midGray, italic: true });
    if (sn && ts) s.addText(`${sn} / ${ts}`, { x: 11.85, y: 7.05, w: 1.1, h: 0.22, fontSize: 8, fontFace: 'Arial', color: C.midGray, align: 'right' });
  }

  _consultingInsightPanel(s, x, y, w, h, header, paragraphs) {
    const C = this.C;
    s.addShape(this.pptx.ShapeType.rect, { x, y, w, h: 0.035, fill: { color: C.navy } });
    s.addShape(this.pptx.ShapeType.rect, { x, y, w, h, line: { color: C.lightGray, width: 0.5 } });
    s.addText(header, { x: x + 0.12, y: y + 0.08, w: w - 0.24, h: 0.3, fontSize: 12, fontFace: 'Arial', color: C.navy, bold: true });
    s.addShape(this.pptx.ShapeType.rect, { x: x + 0.12, y: y + 0.38, w: w - 0.24, h: 0.008, fill: { color: C.lightGray } });
    const texts = paragraphs || [];
    let py = y + 0.45;
    texts.filter(Boolean).forEach((para) => {
      if (typeof para === 'string') {
        s.addText(para, { x: x + 0.12, y: py, w: w - 0.24, h: 0.55, fontSize: 10, fontFace: 'Arial', color: C.darkGray, lineSpacing: 12 });
        py += 0.55;
      } else if (Array.isArray(para)) {
        const rich = para.map(seg => ({ text: seg.text || '', options: { fontSize: 10, fontFace: 'Arial', color: C.darkGray, lineSpacing: 12, ...(seg.options || {}) } }));
        s.addText(rich, { x: x + 0.12, y: py, w: w - 0.24, h: 0.55, fontFace: 'Arial' });
        py += 0.55;
      }
    });
  }

  _consultingBar(s, x, y, w, h, data, colors, opts = {}) {
    const C = this.C;
    // Use QB categorical palette when colors not explicitly supplied
    const chartColors = colors || (data.series && data.series.length > 1
      ? this._CHART_COLORS.slice(0, data.series.length)
      : [QB.primary]);
    try {
      const cd = data.series || [{ name: 'Count', labels: data.labels, values: data.values }];
      if (cd.every(sr => sr.values.every(v => v === 0))) {
        this._noData(s, x, y, w, h, opts.title);
        return;
      }
      const isMulti = cd.length > 1;
      const labelCount = data.labels ? data.labels.length : (cd[0] ? cd[0].labels.length : 5);
      const dynamicGap = labelCount <= 2 ? 150 : labelCount <= 4 ? 100 : CHART.gapWidth;
      // qbstyles: no spines, no grid, narrow gap, bold data labels
      const co = {
        x, y, w, h,
        showTitle:    false,
        showLegend:   isMulti,
        legendPos:    isMulti ? 'b' : 'none',
        legendFontSize: CHART.legendFontSz,
        legendColor:  QB.neutral,
        chartColors,
        barDir:       opts.horizontal ? 'bar' : 'col',
        barGapWidthPct: dynamicGap,
        showValue:    true,
        dataLabelPosition: 'outEnd',
        dataLabelFontSize: CHART.dataLabelFontSz,
        dataLabelColor:    QB.warmDark,
        dataLabelBold:     CHART.dataLabelBold,
        catAxisLabelFontSize: CHART.catLabelFontSz,
        valAxisLabelFontSize: CHART.valLabelFontSz,
        catAxisLabelColor: QB.neutral,
        valAxisLabelColor: QB.neutral,
        valGridLine: CHART.valGridLine,
        catAxisLine: CHART.catAxisLine,
        valAxisLine: CHART.valAxisLine,
        showCatAxisTitle: false,
        showValAxisTitle: false,
        dataBorder: { pt: 0, color: QB.white },
      };
      if (opts.barGrouping) co.barGrouping = opts.barGrouping;
      s.addChart(this.pptx.charts.BAR, cd, co);
      console.log(`[PPTX] Consulting bar "${opts.title}" OK`);
    } catch (e) {
      console.error(`[PPTX] Consulting bar err "${opts.title}": ${e.message}`);
    }
  }

  // ── Mekko / Marimekko Chart ───────────────────────────────────────────────
  // Implements geometry from microsoft/powerbi-visuals-mekkochart and
  // Thiagobc23/Marimekko-charts.
  // Column widths encode one metric (e.g., total items per team);
  // bar heights within each column encode composition (e.g., status breakdown).
  // Both axes carry data — every pixel is a data pixel (qbstyles principle).
  //
  // @param {object} s     — slide
  // @param {number} x,y,w,h — bounds
  // @param {Array}  columns — [{label, total, segments:[{label, value}]}]
  // @param {object} [opts] — { labelThreshold, showLegend }
  _mekoChart(s, x, y, w, h, columns, opts = {}) {
    try {
      renderMeko(this.pptx, s, x, y, w, h, columns, opts);
      console.log(`[PPTX] Meko chart OK (${(columns||[]).length} columns)`);
    } catch (e) {
      console.error(`[PPTX] Meko chart error: ${e.message}`);
      this._noData(s, x, y, w, h, 'Mekko chart');
    }
  }

  // Build Mekko columns from work-item byType stats (sprint data)
  // Returns [{label, total, segments:[{label,value}]}]
  _buildWorkMeko(stats) {
    const byType = stats?.byType || {};
    const segLabels = ['Closed', 'Active', 'Blocked', 'New'];
    const segColors = [QB.green, QB.teal, QB.red, QB.neutral];
    return Object.entries(byType)
      .filter(([, d]) => (d.total || 0) > 0)
      .sort((a, b) => b[1].total - a[1].total)
      .slice(0, 8)
      .map(([type, d]) => {
        const active = Math.max(0, (d.total || 0) - (d.closed || 0) - (d.new || 0));
        const blocked = (d.blocked || 0);
        const segments = [
          { label: 'Closed',  value: d.closed  || 0, color: segColors[0] },
          { label: 'Active',  value: Math.max(0, active - blocked), color: segColors[1] },
          { label: 'Blocked', value: blocked,          color: segColors[2] },
          { label: 'New',     value: d.new || 0,       color: segColors[3] },
        ].filter(sg => sg.value > 0);
        return { label: this._trunc(type, 10), total: d.total, segments };
      });
  }

  // Build Mekko columns from ops data (domain distribution)
  _buildOpsMeko(analysis) {
    const domains = [
      { label: 'ITSM',    total: analysis?.itTickets?.total   || 0, open: analysis?.itTickets?.open    || 0 },
      { label: 'OEG',     total: analysis?.oeg?.total         || 0, open: analysis?.oeg?.open          || 0 },
      { label: 'Cloud',   total: analysis?.cloudRequests?.total||0, open: analysis?.cloudRequests?.pending||0},
      { label: 'Legal',   total: analysis?.legalCases?.total  || 0, open: analysis?.legalCases?.open   || 0 },
      { label: 'IT Desk', total: analysis?.itDesk?.total      || 0, open: analysis?.itDesk?.open       || 0 },
      { label: 'Incidents',total: analysis?.incidents?.total  || 0, open: analysis?.incidents?.open    || 0 },
    ].filter(d => d.total > 0);

    return domains.map(d => ({
      label: d.label,
      total: d.total,
      segments: [
        { label: 'Resolved', value: Math.max(0, d.total - d.open), color: QB.green   },
        { label: 'Open',     value: d.open,                        color: QB.primary },
      ].filter(sg => sg.value > 0),
    }));
  }

  _checkSpace(y, needed, label) {
    if (y + needed > 6.8) {
      console.warn(`[PPTX] Overflow warning: "${label}" needs ${needed}" at y=${y.toFixed(2)}, exceeds 6.8"`);
      return false;
    }
    return true;
  }

  _dynTableH(rowCount, rowH = 0.20, hdrH = 0.34, minH = 0.5, maxH = 3.5) {
    return Math.min(Math.max(rowCount * rowH + hdrH, minH), maxH);
  }

  /**
   * McKinsey annotation callout — places a shaded box with italic text adjacent to the
   * data point it references. Replaces the "Key Insights" bullet footer pattern.
   * @param {object} s  — slide
   * @param {number} x,y,w — position & width (height is auto)
   * @param {string} text  — the "so what" sentence (keep ≤ 120 chars)
   * @param {string} [accentColor] — left border accent (defaults to navy)
   */
  _annotate(s, x, y, w, text, accentColor) {
    // qbstyles: primary red-orange as the brand accent — not navy
    const accent = accentColor || QB.primary;
    const h = 0.52;
    s.addShape(this.pptx.ShapeType.rect, { x, y, w: 0.04, h, fill: { color: accent } });
    s.addShape(this.pptx.ShapeType.rect, { x: x + 0.04, y, w: w - 0.04, h, fill: { color: QB.offWhite } });
    s.addText(text, {
      x: x + 0.12, y: y + 0.07, w: w - 0.2, h: h - 0.12,
      fontSize: TYPE.annotation.size, fontFace: TYPE.font, color: QB.warmDark,
      italic: true, lineSpacing: 11,
    });
  }

  /**
   * McKinsey waterfall/bridge chart — renders health score drivers as a stacked bar
   * waterfall. Invisible baseline + green positive bars + red negative bars.
   * @param {object} s — slide
   * @param {number} x,y,w,h — bounds
   * @param {Array}  drivers — [{label, impact, value}] from _healthBridge()
   * @param {number} base    — starting score
   * @param {number} current — ending score
   */
  _waterfallBridge(s, x, y, w, h, drivers, base, current) {
    const C = this.C;
    if (!drivers || !drivers.length) { this._noData(s, x, y, w, h, 'Health Score Bridge'); return; }
    try {
      const invisibles = [], greens = [], reds = [], labels = [];
      let running = base;
      for (const d of drivers) {
        labels.push(this._trunc(d.label, 16));
        if (d.impact >= 0) {
          invisibles.push(running);
          greens.push(d.impact);
          reds.push(0);
        } else {
          invisibles.push(running + d.impact);
          greens.push(0);
          reds.push(-d.impact);
        }
        running += d.impact;
      }
      const series = [
        { name: '', labels, values: invisibles },   // invisible baseline
        { name: 'Improvement', labels, values: greens },
        { name: 'Decline',     labels, values: reds },
      ];
      s.addChart(this.pptx.charts.BAR, series, {
        x, y, w, h,
        barDir: 'col', barGrouping: 'stacked', barGapWidthPct: 50,
        chartColors: [C.white, C.green, C.red],
        showLegend: true, legendPos: 'b', legendFontSize: 8, legendColor: C.charcoal,
        showValue: true, dataLabelPosition: 'ctr', dataLabelFontSize: 8,
        dataLabelColor: C.white, dataLabelBold: true,
        catAxisLabelFontSize: 8, catAxisLabelColor: C.charcoal,
        valAxisLabelFontSize: 8, valAxisLabelColor: C.charcoal,
        valGridLine: { style: 'none' }, catAxisLine: { style: 'none' }, valAxisLine: { style: 'none' },
        showTitle: false,
      });
      // Annotate start and end
      s.addText(`Start: ${base}`, { x, y: y + h + 0.05, w: 1.0, h: 0.18, fontSize: 8, fontFace: 'Arial', color: C.midGray });
      const endColor = current >= base ? C.green : C.red;
      s.addText(`Now: ${current}`, { x: x + w - 1.0, y: y + h + 0.05, w: 1.0, h: 0.18, fontSize: 8, fontFace: 'Arial', color: endColor, bold: true, align: 'right' });
    } catch (e) {
      console.error(`[PPTX] Waterfall bridge error: ${e.message}`);
      this._noData(s, x, y, w, h, 'Health Score Bridge');
    }
  }

  _card(s, x, y, w, h, fill) {
    const C = this.C;
    s.addShape(this.pptx.ShapeType.rect, { x, y, w, h, fill: { color: fill || C.offWhite }, line: { color: C.lightGray, width: 0.3 } });
  }

  _healthColor(score) {
    if (score >= 80) return this.C.green;
    if (score >= 60) return this.C.amber;
    return this.C.red;
  }

  _trendArrow(current, previous) {
    if (!previous && previous !== 0) return '';
    if (current > previous) return '▲ ';
    if (current < previous) return '▼ ';
    return '● ';
  }

  _metricsStrip(s, x, y, w, metrics) {
    const C = this.C;
    s.addShape(this.pptx.ShapeType.rect, { x, y, w, h: 0.008, fill: { color: C.lightGray } });
    const count = metrics.length;
    const gap = 0.08;
    const itemW = (w - (count - 1) * gap) / count;
    metrics.forEach((m, i) => {
      const ix = x + i * (itemW + gap);
      const cy = y + 0.04;
      if (m.trend) {
        s.addText([{ text: String(m.value) + ' ', options: { fontSize: 16, bold: true, color: m.color || C.navy } }, { text: `${m.trend}${m.trendValue}`, options: { fontSize: 10, bold: true, color: m.trendColor || C.steel } }], { x: ix, y: cy, w: itemW, h: 0.30, align: 'center', fontFace: 'Arial' });
      } else {
        s.addText(String(m.value), { x: ix, y: cy, w: itemW, h: 0.30, fontSize: 16, fontFace: 'Arial', color: m.color || C.navy, bold: true, align: 'center' });
      }
      if (m.status) {
        s.addText(String(m.status), { x: ix, y: cy + 0.30, w: itemW, h: 0.16, fontSize: 7, fontFace: 'Arial', color: m.statusColor || m.color || C.steel, bold: true, align: 'center' });
      }
      // Fixed baseline: always place label at cy + 0.48 so all labels align
      s.addText(String(m.label), { x: ix, y: cy + 0.48, w: itemW, h: 0.18, fontSize: 8, fontFace: 'Arial', color: C.steel, align: 'center', bold: true });
    });
  }

  _compactTable(s, x, y, w, types, stats, overallPct) {
    const C = this.C;
    if (!types || !types.length) return 0;
    const headers = ['Type', 'Total', 'Closed', 'Active', 'New', 'SP', 'Done', '%'];
    const colW = [1.6, 0.55, 0.55, 0.5, 0.5, 0.55, 0.55, 0.5];
    const rowH = 0.14;
    const b = { pt: 0.3, color: C.lightGray };
    const headerRow = headers.map(h => ({ text: h, options: { bold: true, color: C.white, fontSize: 6.5, fontFace: 'Arial', align: 'center', border: b, valign: 'middle', fill: { color: C.navy } } }));
    const rows = types.map(([t, d]) => {
      const tp = d.total > 0 ? Math.round((d.closed / d.total) * 100) : 0;
      const active = Math.max(0, d.total - d.closed - (d.new || 0));
      return [
        { text: this._trunc(t, 12), options: { align: 'left', bold: true, color: C.darkGray, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(d.total), options: { align: 'center', color: C.darkGray, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(d.closed), options: { align: 'center', color: C.green, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(active), options: { align: 'center', color: C.blue, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(d.new || 0), options: { align: 'center', color: C.steel, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(d.effort || 0), options: { align: 'center', color: C.darkGray, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: String(d.closedEffort || 0), options: { align: 'center', color: C.green, fontSize: 6.5, border: b, valign: 'middle' } },
        { text: `${tp}%`, options: { align: 'center', bold: true, color: tp >= 70 ? C.green : tp >= 40 ? C.blue : C.red, fontSize: 6.5, border: b, valign: 'middle' } },
      ];
    });
    const totalRow = [
      { text: 'Total', options: { align: 'left', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.total || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.closed || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.active || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.newItems || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.totalEffort || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: String(stats.closedEffort || 0), options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
      { text: `${overallPct}%`, options: { align: 'center', bold: true, color: C.navy, fontSize: 6.5, border: b, valign: 'middle', fill: { color: C.lightBlue } } },
    ];
    const tableH = (types.length + 2) * rowH;
    s.addTable([headerRow, ...rows, totalRow], { x, y, w, fontSize: 6.5, fontFace: 'Arial', colW, rowH, color: C.darkGray });
    return tableH;
  }

  _table(s, x, y, w, headers, rows, colW, headerColor) {
    const C = this.C;
    const hc = headerColor || C.navy;
    const rowH = 0.22;
    const b = { pt: 0.3, color: C.lightGray };
    const headerRow = headers.map(h => ({ text: h, options: { bold: true, color: C.white, fontSize: 7.5, fontFace: 'Arial', align: 'center', border: b, valign: 'middle', fill: { color: hc } } }));
    const dataRows = rows.map(r => Array.isArray(r) ? r.map((cell, i) => {
      if (typeof cell === 'object' && cell.text !== undefined) return cell;
      return { text: String(cell), options: { align: i === 0 ? 'left' : 'center', color: C.darkGray, fontSize: 7.5, border: b, valign: 'middle' } };
    }) : r);
    s.addTable([headerRow, ...dataRows], { x, y, w, fontSize: 7.5, fontFace: 'Arial', colW, rowH, color: C.darkGray });
    return (rows.length + 1) * rowH;
  }

  _riskHeatmap(s, x, y, w, h, risks) {
    const C = this.C;
    s.addText('Risk Indicators', { x, y, w, h: 0.18, fontSize: 9, fontFace: 'Arial', color: C.navy, bold: true });
    s.addShape(this.pptx.ShapeType.rect, { x, y: y + 0.2, w, h: 0.004, fill: { color: C.lightGray } });
    const cols = 3, rows = 2;
    const cellW = (w - 0.1) / cols;
    const cellH = (h - 0.28) / rows;
    risks.forEach((r, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const cx = x + col * cellW;
      const cy = y + 0.26 + row * cellH;
      s.addShape(this.pptx.ShapeType.ellipse, { x: cx, y: cy + 0.02, w: 0.09, h: 0.09, fill: { color: r.color } });
      s.addText(r.label, { x: cx + 0.13, y: cy, w: cellW - 0.18, h: 0.13, fontSize: 6.5, fontFace: 'Arial', color: C.steel, bold: true });
      s.addText(String(r.value), { x: cx + 0.13, y: cy + 0.12, w: cellW - 0.18, h: 0.14, fontSize: 9, fontFace: 'Arial', color: r.color, bold: true });
    });
  }

  _miniSparkline(s, x, y, w, h, label1, val1, label2, val2) {
    const C = this.C;
    const maxVal = Math.max(val1, val2, 1);
    const barW = (w - 0.3) / 2;
    const bar1H = Math.max(0.15, (h - 0.25) * (val1 / maxVal));
    const bar2H = Math.max(0.15, (h - 0.25) * (val2 / maxVal));
    s.addText('Velocity Trend', { x, y, w, h: 0.16, fontSize: 9, fontFace: 'Arial', color: C.navy, bold: true });
    s.addText(label1, { x, y: y + 0.2, w: barW, h: 0.12, fontSize: 6, fontFace: 'Arial', color: C.steel, align: 'center' });
    s.addShape(this.pptx.ShapeType.rect, { x: x + barW * 0.2, y: y + 0.35 + (h - 0.25 - bar1H), w: barW * 0.6, h: bar1H, fill: { color: C.navy } });
    s.addText(String(val1), { x, y: y + 0.35 + (h - 0.25 - bar1H) - 0.14, w: barW, h: 0.12, fontSize: 7, fontFace: 'Arial', color: C.navy, bold: true, align: 'center' });
    const x2 = x + barW + 0.15;
    s.addText(label2, { x: x2, y: y + 0.2, w: barW, h: 0.12, fontSize: 6, fontFace: 'Arial', color: C.steel, align: 'center' });
    s.addShape(this.pptx.ShapeType.rect, { x: x2 + barW * 0.2, y: y + 0.35 + (h - 0.25 - bar2H), w: barW * 0.6, h: bar2H, fill: { color: C.lightGray } });
    s.addText(val2 === 0 ? '—' : String(val2), { x: x2, y: y + 0.35 + (h - 0.25 - bar2H) - 0.14, w: barW, h: 0.12, fontSize: 7, fontFace: 'Arial', color: val2 === 0 ? C.medGray : C.steel, bold: true, align: 'center' });
    const trend = val1 >= val2 ? '↑' : '↓';
    const trendColor = val1 >= val2 ? C.green : C.red;
    s.addText(trend, { x: x + barW + 0.02, y: y + 0.35 + (h - 0.25) / 2 - 0.1, w: 0.12, h: 0.2, fontSize: 12, fontFace: 'Arial', color: trendColor, bold: true, align: 'center' });
  }

  // ─── SLIDE 1: TITLE ───
  // ─── SLIDE 1: TITLE ─────────────────────────────────────────────────────
  // clean-slides philosophy: one message per slide, sparse, no decoration.
  // qbstyles identity: white background, QB primary (D04A02) as brand accent.
  // Instrumenta: all elements on 0.5" grid, consistent margins.
  _slideTitle(sprintData, analysis, sn, ts) {
    const s = this.pptx.addSlide();
    s.background = { color: QB.white };

    // ── Left accent bar — qbstyles primary color (D04A02) ──────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0, y: 0, w: 0.25, h: 7.5, fill: { color: QB.primary } });

    // ── Top section: white, generous margin (clean-slides) ─────────────────
    // Title block — left-aligned, bold, warmDark (qbstyles axes.titlecolor)
    const today = this._dateRange ? new Date(this._dateRange.dateTo) : new Date();
    const weekEnd = today.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' });
    const wl = this._wl();

    s.addText('BizTech', { x: 0.5, y: 0.5, w: 9, h: 0.45, fontSize: 14, fontFace: TYPE.font, color: QB.neutral, bold: false });
    s.addText('Weekly Status Report', { x: 0.5, y: 1.0, w: 10, h: 1.0, fontSize: 44, fontFace: TYPE.font, color: QB.warmDark, bold: true, lineSpacing: 50 });

    // Thin QB-primary rule (qbstyles: clean horizontal separator)
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 2.1, w: 5.5, h: 0.04, fill: { color: QB.primary } });

    // Date range — subtitle weight (clean-slides subtitle size: 11pt)
    s.addText(wl, { x: 0.5, y: 2.25, w: 10, h: 0.38, fontSize: 14, fontFace: TYPE.font, color: QB.primary, bold: false });
    s.addText(`Report date: ${weekEnd}`, { x: 0.5, y: 2.62, w: 8, h: 0.3, fontSize: TYPE.subtitle.size, fontFace: TYPE.font, color: QB.neutral });

    // ── KPI strip — Sprint Readiness Score (primary) + 4 evidence metrics ─
    const st = sprintData?.stats || {};
    const p  = st.total > 0 ? Math.round(st.closed / st.total * 100) : 0;
    const hs = st.healthScore || 0;
    const srs = this._sprintReadinessScore(sprintData, this._ops || {});
    analysis.sprintReadinessScore = srs; // expose so other slides + memo can reference
    const metrics = [
      { label: 'SPRINT READINESS', value: `${srs.score}`,
        color: srs.score >= 70 ? QB.green : srs.score >= 50 ? QB.amber_rag : QB.red,
        status: srs.verdict, statusColor: QB.neutral },
      { label: 'SPRINT COMPLETION', value: `${p}%`, color: p >= 70 ? QB.green : p >= 50 ? QB.amber_rag : QB.red, status: p >= 70 ? 'On Track' : p >= 50 ? 'Watch' : 'At Risk', statusColor: QB.neutral },
      { label: 'HEALTH SCORE', value: hs, color: hs >= 70 ? QB.green : hs >= 40 ? QB.amber_rag : QB.red, status: hs >= 70 ? 'Healthy' : hs >= 40 ? 'Moderate' : 'At Risk', statusColor: QB.neutral },
      { label: 'ITEMS CLOSED', value: st.closed || 0, color: QB.teal, status: `of ${st.total || 0} total`, statusColor: QB.neutral },
      { label: 'BLOCKERS', value: (st.blockedItems || []).length, color: (st.blockedItems || []).length === 0 ? QB.green : QB.red, status: (st.blockedItems || []).length === 0 ? 'Clear' : 'Action needed', statusColor: QB.neutral },
    ];
    this._metricsStrip(s, 0.5, 3.25, 12.5, metrics);

    // ── Executive Verdict (Hermes or RAG) — right panel ──────────────────
    const ev = analysis?.executiveVerdict;
    const hermesExec = analysis?.hermes?.slideNarratives?.executiveSummary;
    const intel = this._intelligence || {};
    const overall = intel.exec?.overall || (ev?.status ? (ev.status === 'green' ? 'Green' : ev.status === 'red' ? 'Red' : 'Amber') : 'Amber');
    const ragColor = overall === 'Green' ? QB.green : overall === 'Red' ? QB.red : QB.amber_rag;

    // Status pill — consulting standard: coloured bar, status word, one-liner
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5,  y: 4.5, w: 1.6, h: 0.42, fill: { color: ragColor } });
    s.addText(overall.toUpperCase(), { x: 0.5, y: 4.5, w: 1.6, h: 0.42, fontSize: 14, fontFace: TYPE.font, color: QB.white, bold: true, align: 'center', valign: 'middle' });

    const situationText = intel.exec?.situation || (ev ? (hermesExec || ev.summary || ev.text || '') : '');
    if (situationText) {
      s.addText(situationText, { x: 2.25, y: 4.5, w: 10.6, h: 0.42, fontSize: 11, fontFace: TYPE.font, color: QB.warmDark, valign: 'middle', lineSpacing: 13 });
    }

    // ── Key actions (clean-slides: max 4 bullets, hierarchical) ──────────
    const hermesRecs = analysis?.hermes?.recommendations?.slice(0, 4);
    const fallbackActions = analysis?.actions?.slice(0, 4) || [];
    const actionsToShow = hermesRecs || fallbackActions;
    if (actionsToShow.length) {
      s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 5.1, w: 12.5, h: 0.008, fill: { color: QB.lightGray } });
      s.addText('Actions required', { x: 0.5, y: 5.15, w: 3, h: 0.22, fontSize: 8, fontFace: TYPE.font, color: QB.primary, bold: true });
      actionsToShow.forEach((a, i) => {
        const priority = a.priority || 'medium';
        const dot = priority === 'high' ? QB.red : priority === 'medium' ? QB.amber_rag : QB.green;
        const text = a.text || a.action || String(a);
        const cx = 0.5 + (i % 2) * 6.35;
        const cy = 5.4 + Math.floor(i / 2) * 0.38;
        s.addShape(this.pptx.ShapeType.ellipse, { x: cx, y: cy + 0.07, w: 0.1, h: 0.1, fill: { color: dot } });
        s.addText(this._trunc(text, 90), { x: cx + 0.16, y: cy, w: 6.0, h: 0.32, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, lineSpacing: 11 });
      });
    }

    // ── Phase 3: Provisional delivery banner ─────────────────────────────
    // When source confidence is Low (<70%), render an amber warning banner
    // across the title slide so recipients cannot miss the data quality caveat.
    if (analysis?.deliveryMode === 'provisional') {
      const reason = analysis.provisionalReason || 'Source confidence below threshold — verify data before sharing';
      // Amber bar spanning full width at the top (above accent bar)
      s.addShape(this.pptx.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.38,
        fill: { color: QB.amber_rag },
        line: { pt: 0 },
      });
      s.addText('⚠  PROVISIONAL — ' + reason, {
        x: 0.15, y: 0, w: 13.0, h: 0.38,
        fontSize: 10, fontFace: TYPE.font, color: QB.white,
        bold: true, valign: 'middle', align: 'center',
      });
    }

    // ── Footer ────────────────────────────────────────────────────────────
    this._ftr(s, 'BizTech / Weekly Status Report', sn, ts);
  }

  // ─── SLIDE 2: SPRINT STATUS ───
  _slideConsultingSprint(sprintData, bnData, analysis, sn, ts) {
    const C = this.C;
    const s = this.pptx.addSlide();
    s.background = { color: C.white };
    this._consultingHeader(s, 'Sprint Status', 'Current sprint health and progress overview', sn, ts);
    const stats = sprintData?.stats || {};
    const p = stats.total > 0 ? Math.round(stats.closed / stats.total * 100) : 0;
    const tr = stats.total || 0;
    const cl = stats.closed || 0;
    const ac = stats.active || 0;
    const nw = stats.newItems || 0;
    const sp = stats.totalEffort || 0;
    const doneSp = stats.closedEffort || 0;
    const remaining = tr - cl;
    const block = (stats.blockedItems || []).length;
    const overdue = (stats.overdueItems || []).length;
    const stale = (stats.staleItems || []).length;
    const hs = stats.healthScore || 0;
    const acy = stats.avgCycleTime || 0;
    const sa = stats.scopeAdded || 0;
    const orig = stats.totalOriginalEstimate || 0;
    const remWk = stats.totalRemainingWork || 0;
    const cmplWk = stats.totalCompletedWork || 0;
    const der = stats.defectEscapeRate || 0;
    const bnTotal = Array.isArray(bnData) ? bnData.length : 0;
    const bnRes = Array.isArray(bnData) ? bnData.filter(c => this._bns(c) === 'Resolved').length : 0;
    const bnOpen = bnTotal - bnRes;
    const topCat = this._top(bnData);
    const topCatName = topCat ? topCat.name : 'N/A';
    const topCatPct = topCat ? topCat.pct : 0;
    const ctrend = stats.closedTrend || 0;
    const ctd = analysis?.cycleTimeDist || {};
    const wip = analysis?.wipSnapshot || {};
    const lb = analysis?.loadBalance || {};
    // ── Layout Tracker ──
    let y = 2.05;
    // McKinsey: 4 headline KPIs that answer the executive question for this slide
    this._metricsStrip(s, 0.35, y, 12.6, [
      { label: 'COMPLETION', value: `${p}%`, color: p >= 70 ? C.green : p >= 50 ? C.amber : C.red, status: p >= 70 ? 'On Track' : p >= 50 ? 'Watch' : 'At Risk', statusColor: C.midGray },
      { label: 'BLOCKERS', value: block, color: block === 0 ? C.green : C.red, status: block === 0 ? 'None' : 'Action needed', statusColor: C.midGray },
      { label: 'HEALTH SCORE', value: hs, color: hs >= 70 ? C.green : hs >= 40 ? C.amber : C.red, status: hs >= 70 ? 'Healthy' : hs >= 40 ? 'Moderate' : 'Critical', statusColor: C.midGray },
      { label: 'FORECAST', value: analysis?.forecast?.canFinish ? ((f => f?.probLo != null && f?.probHi != null && f.probLo !== f.probHi ? `${f.probLo}–${f.probHi}%` : `${f?.probability || 0}%`)(analysis.forecast)) : 'At Risk', color: analysis?.forecast?.canFinish ? C.green : C.red, status: 'on-time probability', statusColor: C.midGray },
    ]);
    y += 0.72;
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: y, w: 12.6, h: 0.008, fill: { color: C.lightGray } });
    y += 0.18;
    // 4-column detail block
    const colW = 3.05;
    const colGap = 0.15;
    const cols = [0.35, 0.35 + colW + colGap, 0.35 + 2*(colW + colGap), 0.35 + 3*(colW + colGap)];
    const headers = ['Work Distribution', 'Status Overview', 'Effort & Scope', 'Support Cases'];
    headers.forEach((h, i) => {
      s.addText(h, { x: cols[i], y, w: colW, h: 0.18, fontSize: 9, fontFace: 'Arial', color: C.navy, bold: true });
      s.addShape(this.pptx.ShapeType.rect, { x: cols[i], y: y + 0.2, w: colW, h: 0.003, fill: { color: C.lightGray } });
    });
    y += 0.28;
    const bt = (items, x) => { items.forEach((it, i) => { s.addText(String(it), { x, y: y + i * 0.2, w: colW, h: 0.18, fontSize: 8, fontFace: 'Arial', color: C.darkGray, lineSpacing: 10 }); }); };
    const tv = analysis?.throughputVar || {};
    bt([`Total: ${tr}`,`Closed: ${cl}`,`Active: ${ac}`,`New: ${nw}`,`Blocked: ${block}`,`Stale: ${stale}`,`Overdue: ${overdue}`,`Scope: +${sa}`], cols[0]);
    bt([`Progress: ${p}%`,`Health: ${hs}/100`,`Cycle: ${acy}d`,`Status: ${hs >= 70 ? 'Healthy' : hs >= 40 ? 'Moderate' : 'At Risk'}`,`Orig Est: ${orig}h`,`Completed: ${cmplWk}h`,`Remaining: ${remWk}h`,`This Week: ${stats.closedThisWeek || 0}`], cols[1]);
    bt([`Effort: ${sp} SP`,`Done: ${doneSp} SP`,`Rem: ${Math.max(0, sp - doneSp)} SP`,`Efficiency: ${sp > 0 ? Math.round((doneSp / sp) * 100) : 0}%`,`WIP: ${wip.activeCount || 0}/${wip.wipLimit || 0}`,`CT P50: ${ctd.p50 || 0}d`,`CT P90: ${ctd.p90 || 0}d`,`Thru Var: ${tv.stdDev || 0}`], cols[2]);
    bt([`Total: ${bnTotal}`,`Resolved: ${bnRes}`,`Open: ${bnOpen}`,`Top Cat: ${topCatName}`,`Top %: ${topCatPct}%`,`Res Rate: ${bnTotal > 0 ? Math.round((bnRes / bnTotal) * 100) : 0}%`,`Load Gini: ${lb.gini || 0}`,`Burn Rate: ${analysis?.dailyBurn?.rate || 0}/d`], cols[3]);
    y += 8 * 0.2 + 0.1;
    this._ins(s, 0.35, y, 12.6, [
      analysis?.forecast?.canFinish ? `Forecast: ${(f => f?.probLo != null && f?.probHi != null && f.probLo !== f.probHi ? `${f.probLo}–${f.probHi}%` : `${f?.probability || 0}%`)(analysis.forecast)} probability to finish on time` : 'Forecast: Sprint completion at risk',
      analysis?.rootCauses?.summary || 'No root cause analysis available',
      analysis?.hygiene?.grade ? `Data Hygiene: Grade ${analysis.hygiene.grade} (${analysis.hygiene.score}%)` : 'Data Hygiene: Not scored',
    ], C.navy);
    this._consultingFooter(s, 'Sprint Status Dashboard', sn, ts);
  }


  // ─── SLIDE 4: SPRINT DASHBOARD ───
  _slideSprint(stats, workItems, wl, sn, ts, analysis) {
    const C = this.C;
    const s = this.pptx.addSlide();
    s.background = { color: C.white };
    this._hdr(s, 'Sprint Dashboard', C.navy, sn, ts);
    const tr = stats?.total || 0;
    const cl = stats?.closed || 0;
    const p = tr > 0 ? Math.round(cl / tr * 100) : 0;
    const ac = stats?.active || 0;
    const nw = stats?.newItems || 0;
    const totalSP = stats?.totalEffort || 0;
    const doneSP = stats?.closedEffort || 0;
    const block = (stats?.blockedItems || []).length;
    const hs = stats?.healthScore || 0;
    const ev = analysis?.effortVariance || {};
    const ctrend = stats?.closedTrend || 0;
    const der = stats?.defectEscapeRate || 0;
    // ── Layout Tracker ──
    let by = 2.05;
    // Strip 1 (8 metrics)
    this._metricsStrip(s, 0.35, by, 12.6, [
      { label: 'TOTAL', value: tr, color: C.navy },
      { label: 'CLOSED', value: cl, color: C.green, trend: ctrend > 0 ? '↑' : ctrend < 0 ? '↓' : '→', trendValue: Math.abs(ctrend), trendColor: ctrend >= 0 ? C.green : C.red },
      { label: 'ACTIVE', value: ac, color: C.blue },
      { label: 'NEW', value: nw, color: C.steel },
      { label: 'PROGRESS', value: `${p}%`, color: p >= 70 ? C.green : p >= 40 ? C.blue : C.red },
      { label: 'SP', value: `${doneSP}/${totalSP}`, color: C.navy },
      { label: 'BLOCKED', value: block, color: C.red },
      { label: 'HEALTH', value: hs, color: hs >= 70 ? C.green : hs >= 40 ? C.blue : C.red, status: hs >= 70 ? 'Good' : hs >= 40 ? 'Fair' : 'Poor', statusColor: C.steel },
    ]);
    by += 0.68;
    // Strip 2 (8 effort/quality + new metrics)
    const ctd = analysis?.cycleTimeDist || {};
    const wip = analysis?.wipSnapshot || {};
    const db = analysis?.dailyBurn || {};
    this._metricsStrip(s, 0.35, by, 12.6, [
      { label: 'EST HOURS', value: ev.original || 0, color: C.navy },
      { label: 'DONE HOURS', value: ev.completed || 0, color: C.green },
      { label: 'REM HOURS', value: ev.remaining || 0, color: C.amber },
      { label: 'VARIANCE', value: `${ev.variance || 0}%`, color: (ev.variance || 0) <= 10 ? C.green : (ev.variance || 0) <= 30 ? C.amber : C.red },
      { label: 'BUG RATIO', value: `${der}%`, color: der <= 10 ? C.green : der <= 20 ? C.amber : C.red },
      { label: 'CT P50', value: `${ctd.p50 || 0}d`, color: (ctd.p50 || 0) <= 3 ? C.green : (ctd.p50 || 0) <= 7 ? C.amber : C.red },
      { label: 'WIP', value: `${wip.activeCount || 0}/${wip.wipLimit || 0}`, color: wip.overloaded ? C.red : C.blue },
      { label: 'BURN RATE', value: `${db.rate || 0}/d`, color: db.onTrack ? C.green : C.amber },
    ]);
    by += 0.68;
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by, w: 12.6, h: 0.008, fill: { color: C.lightGray } });
    by += 0.18;
    // Two large charts side by side
    const chartW = 6.0, chartH = 2.0;
    this._consultingBar(s, 0.35, by, chartW, chartH, {
      labels: ['New', 'Active', 'Resolved', 'Closed'],
      values: [stats?.byState?.['New'] || 0, stats?.byState?.['Active'] || 0, stats?.byState?.['Resolved'] || 0, stats?.byState?.['Closed'] || 0],
    }, [C.navy, C.blue, C.green, C.steel], { title: 'Status Distribution', titleColor: C.darkGray });
    this._consultingBar(s, 6.85, by, chartW, chartH, {
      series: [
        { name: 'Items', labels: ['Completed', 'Remaining'], values: [cl, Math.max(0, tr - cl)] },
        { name: 'SP', labels: ['Completed', 'Remaining'], values: [doneSP, Math.max(0, totalSP - doneSP)] },
      ],
    }, [C.green, C.navy], { title: 'Completion vs Remaining', titleColor: C.darkGray, barGrouping: 'clustered' });
    by += chartH + 0.2;
    // Compact insight panel — max 3 bullets to avoid footer overlap
    const insBullets = [
      analysis?.forecast?.canFinish ? `Forecast: ${(f => f?.probLo != null && f?.probHi != null && f.probLo !== f.probHi ? `${f.probLo}–${f.probHi}%` : `${f?.probability || 0}%`)(analysis.forecast)} probability of on-time completion` : 'Sprint completion at risk',
      analysis?.hygiene?.grade ? `Data Hygiene: Grade ${analysis.hygiene.grade} (${analysis.hygiene.score}%) — ${analysis.hygiene.issues?.length || 0} issues found` : 'Data hygiene not scored',
      analysis?.rootCauses?.summary || 'No root cause analysis available',
      ev.variance ? `Effort variance: ${ev.variance}% (${ev.completed}h done / ${ev.original}h est)` : '',
    ].filter(Boolean).slice(0, 3);
    this._ins(s, 0.35, by, 12.6, insBullets, C.navy);
    this._ftr(s, 'Sprint Dashboard', sn, ts);
  }

  // ─── SLIDE 5: TYPE BREAKDOWN — Mekko chart (qbstyles + Marimekko geometry) ─
  // Implements the Marimekko chart type from:
  //   microsoft/powerbi-visuals-mekkochart  — proportional width + height encoding
  //   Thiagobc23/Marimekko-charts           — chart geometry reference
  // Column widths = total items per type (relative market share)
  // Bar heights = closed/active/blocked/new composition within each type
  // Uses QB 5-color categorical palette from qbstyles prop_cycle.
  _slideType(stats, sn, ts, analysis) {
    const s = this.pptx.addSlide();
    s.background = { color: QB.white };
    this._hdr(s, 'Work Items by Type', null, sn, ts);

    const types = Object.entries(stats?.byType || {});
    const tr = stats?.total || 0;
    const cl = stats?.closed || 0;
    const p  = tr > 0 ? Math.round(cl / tr * 100) : 0;
    const topT = types.length > 0 ? types.reduce((a, b) => (a[1].total > b[1].total ? a : b), types[0]) : null;
    const ltbt = analysis?.leadTimeByType || [];

    // ── KPI strip ────────────────────────────────────────────────────────
    this._metricsStrip(s, 0.35, 2.05, 12.6, [
      { label: 'WORK TYPES',  value: types.length, color: QB.warmDark },
      { label: 'DOMINANT TYPE', value: topT ? this._trunc(topT[0], 14) : 'N/A', color: QB.primary },
      { label: 'OVERALL DONE', value: `${p}%`, color: p >= 70 ? QB.green : p >= 50 ? QB.amber_rag : QB.red },
      { label: 'CT P75',       value: `${analysis?.cycleTimeDist?.p75 || 0}d`, color: QB.teal },
      { label: 'LT BUG',       value: `${ltbt.find(l => l.type === 'Bug')?.avgDays || 0}d`, color: QB.red },
      { label: 'LT FEAT',      value: `${ltbt.find(l => l.type === 'Feature')?.avgDays || 0}d`, color: QB.teal },
    ]);

    // ── Mekko chart — top two-thirds of body ────────────────────────────
    // Width of each column = type's share of total work items
    // Segments = Closed | Active | Blocked | New
    const mekoColumns = this._buildWorkMeko(stats);
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: 2.8, w: 12.6, h: 0.008, fill: { color: QB.lightGray } });
    s.addText('Work distribution by type — column width = item share, height = status composition', {
      x: 0.35, y: 2.88, w: 12.6, h: 0.22,
      fontSize: 8, fontFace: TYPE.font, color: QB.neutral, italic: true,
    });

    if (mekoColumns.length) {
      this._mekoChart(s, 0.35, 3.18, 12.6, 2.8, mekoColumns, {});
    } else {
      this._noData(s, 0.35, 3.18, 12.6, 2.8, 'Work Type Mekko Chart');
    }

    // ── Board column bar chart + annotation ─────────────────────────────
    const bcDist = analysis?.boardColumnDistribution;
    if (bcDist?.entries?.length > 0) {
      this._consultingBar(s, 0.35, 6.25, 8.0, 0.82, {
        labels: bcDist.entries.map(e => this._trunc(e.column, 12)),
        values: bcDist.entries.map(e => e.count),
      }, CHART_COLORS, { horizontal: false });
    }

    // "So what" annotation (qbstyles: adjacent to data, replaces bullet footer)
    const topRisk = analysis?.topTypeRisk || (topT ? `${topT[0]} dominates at ${topT[1].total} items (${Math.round(topT[1].total/Math.max(tr,1)*100)}% of sprint)` : null);
    if (topRisk) this._annotate(s, 8.5, 6.15, 4.5, topRisk, QB.primary);

    this._ftr(s, 'Work Item Breakdown', sn, ts);
  }

  // ─── SLIDE 6: TEAM SUMMARY ───
  _slideTeam(stats, sn, ts, analysis) {
    const C = this.C;
    const s = this.pptx.addSlide();
    s.background = { color: C.white };
    this._hdr(s, 'Team Summary', C.navy, sn, ts);
    const ba = stats?.byAssignee || {};
    const ent = Object.entries(ba).filter(([_, d]) => d.total > 0).sort((a, b) => b[1].total - a[1].total);
    const metrics = [
      { label: 'TEAM SIZE', value: ent.length, color: C.navy },
      { label: 'TOP PERFORMER', value: ent.length > 0 ? this._trunc(ent[0][0], 12) : 'N/A', color: C.green },
      { label: 'AVG ITEMS', value: ent.length > 0 ? Math.round((stats?.total || 0) / ent.length) : 0, color: C.steel },
      { label: 'HEALTH', value: stats?.healthScore || 0, color: (stats?.healthScore || 0) >= 70 ? C.green : (stats?.healthScore || 0) >= 40 ? C.blue : C.red },
    ];
    let by = this._badges(s, metrics, 2.15, C.navy);
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by + 0.1, w: 12.6, h: 0.008, fill: { color: C.lightGray } });
    by += 0.24;
    if (ent.length > 0) {
      const perPage = 18;
      const page = ent.slice(0, perPage);
      const headers = ['Name', 'Total', 'Closed', 'Active', 'Effort', 'Done Effort', 'Rate'];
      const colW = [2.0, 0.6, 0.6, 0.6, 0.7, 0.8, 0.6];
      const rows = page.map(([n, d]) => {
        const rate = d.total > 0 ? Math.round((d.closed / d.total) * 100) : 0;
        return [
          { text: this._trunc(n, 20), options: { align: 'left', bold: true, color: C.darkGray } },
          { text: String(d.total), options: { align: 'center', color: C.darkGray } },
          { text: String(d.closed), options: { align: 'center', color: C.green } },
          { text: String(Math.max(0, d.total - d.closed)), options: { align: 'center', color: C.blue } },
          { text: String(d.effort || 0), options: { align: 'center', color: C.darkGray } },
          { text: String(d.closedEffort || 0), options: { align: 'center', color: C.green } },
          { text: `${rate}%`, options: { align: 'center', bold: true, color: rate >= 70 ? C.green : rate >= 40 ? C.blue : C.red } },
        ];
      });
      const top = ent.slice(0, 5).map(([n, d]) => ({ name: n, rate: d.total > 0 ? Math.round((d.closed / d.total) * 100) : 0 }));
      const teamBoxH = this._dynTableH(Math.min(ent.length, 18), 0.22, 0.34, 0.5, 3.5);
      s.addTable([this._th(headers, C.navy), ...rows], { x: 0.35, y: by, w: 5.8, fontFace: 'Arial', fontSize: 7.5, colW, rowH: 0.22, color: C.darkGray });
      s.addShape(this.pptx.ShapeType.rect, { x: 6.45, y: by, w: 6.5, h: 0.035, fill: { color: C.navy } });
      s.addShape(this.pptx.ShapeType.rect, { x: 6.45, y: by, w: 6.5, h: teamBoxH, line: { color: C.lightGray, width: 0.5 } });
      s.addText('Top Performers', { x: 6.55, y: by + 0.06, w: 6.3, h: 0.2, fontSize: 10, fontFace: 'Arial', color: C.navy, bold: true });
      top.forEach((t, i) => {
        const tc = t.rate >= 70 ? C.green : t.rate >= 40 ? C.blue : C.red;
        s.addText(`${i + 1}. ${t.name}`, { x: 6.55, y: by + 0.35 + i * 0.55, w: 4.0, h: 0.2, fontSize: 9, fontFace: 'Arial', color: C.darkGray, bold: true });
        s.addShape(this.pptx.ShapeType.rect, { x: 6.55, y: by + 0.58 + i * 0.55, w: 3.6, h: 0.12, fill: { color: C.lightGray } });
        s.addShape(this.pptx.ShapeType.rect, { x: 6.55, y: by + 0.58 + i * 0.55, w: 3.6 * t.rate / 100, h: 0.12, fill: { color: tc } });
        s.addText(`${t.rate}%`, { x: 6.55, y: by + 0.58 + i * 0.55, w: 3.6, h: 0.12, fontSize: 7, fontFace: 'Arial', color: t.rate > 40 ? C.white : C.darkGray, bold: true, align: 'center', valign: 'middle' });
      });
      by += teamBoxH + 0.32;
    } else {
      s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by, w: 12.6, h: 0.035, fill: { color: C.lightGray } });
      s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by, w: 12.6, h: 3.2, line: { color: C.lightGray, width: 0.5, dashType: 'dash' } });
      s.addText('No assignee data available', { x: 0.35, y: by + 1.2, w: 12.6, h: 0.3, fontSize: 12, fontFace: 'Arial', color: C.medGray, align: 'center', italic: true });
      by += 3.5;
    }
    this._ins(s, 0.35, by, 12.6, [
      ent.length > 0 ? `${ent[0][0]} leads with ${ent[0][1].total} items` : 'Team data not available',
      analysis?.hygiene?.missingAssignee > 0 ? `${analysis.hygiene.missingAssignee} items without assignee` : 'All items have assignees',
      analysis?.hygiene?.missingEstimates > 0 ? `${analysis.hygiene.missingEstimates} items missing estimates` : 'All items have estimates',
    ], C.navy);
    this._ftr(s, 'Team Summary', sn, ts);
  }

  // ─── SLIDE 7: WEEKLY ACTIVITY ───
  _slideWeekly(stats, workItems, sn, ts, analysis) {
    const C = this.C;
    const s = this.pptx.addSlide();
    s.background = { color: C.white };
    this._hdr(s, 'Weekly Activity', C.navy, sn, ts);
    const ctw = stats?.closedThisWeek || 0;
    const crw = stats?.createdThisWeek || 0;
    const tr = stats?.total || 0;
    const hs = stats?.healthScore || 0;
    const prevCl = (analysis?.trends?.prev7Closed) || 0;
    const metrics = [
      { label: 'CLOSED THIS WEEK', value: ctw, color: C.green, trend: ctw >= prevCl ? '↑' : '↓', trendValue: Math.abs(ctw - prevCl), trendColor: ctw >= prevCl ? C.green : C.red },
      { label: 'CREATED THIS WEEK', value: crw, color: C.blue },
      { label: 'TOTAL ITEMS', value: tr, color: C.navy },
      { label: 'HEALTH SCORE', value: hs, color: hs >= 70 ? C.green : hs >= 40 ? C.blue : C.red },
    ];
    let by = this._badges(s, metrics, 2.15, C.navy);
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by + 0.1, w: 12.6, h: 0.008, fill: { color: C.lightGray } });
    by += 0.24;
    const tw = new Date();
    const pw = new Date(tw); pw.setDate(pw.getDate() - 7);
    const closedItems = (workItems || []).filter(wi => {
      const cd = wi.closedDate;
      return cd && new Date(cd) >= pw && new Date(cd) <= tw;
    }).sort((a, b) => new Date(b.closedDate) - new Date(a.closedDate)).slice(0, 10);
    const newItems = (workItems || []).filter(wi => {
      const cd = wi.createdDate;
      return cd && new Date(cd) >= pw && new Date(cd) <= tw;
    }).sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate)).slice(0, 10);
    const closedBoxH = this._dynTableH(closedItems.length);
    const newBoxH    = this._dynTableH(newItems.length);
    const boxH = Math.max(closedBoxH, newBoxH);
    this._cf(s, 0.35, by, 6.1, boxH);
    s.addShape(this.pptx.ShapeType.rect, { x: 0.35, y: by, w: 6.1, h: 0.035, fill: { color: C.navy } });
    s.addText('Items Closed This Week', { x: 0.45, y: by + 0.05, w: 5.9, h: 0.2, fontSize: 10, fontFace: 'Arial', color: C.white, bold: true });
    if (closedItems.length) {
      const hdr = ['ID', 'Title', 'Type', 'State', 'Closed Date'];
      const colW = [0.5, 2.2, 0.7, 0.8, 1.0];
      const rows = closedItems.map(wi => {
        return [
          { text: String(wi.id || ''), options: { align: 'center' } },
          { text: this._trunc(wi.title || '', 30), options: { align: 'left' } },
          { text: this._trunc(wi.type || '', 10), options: { align: 'center' } },
          { text: this._trunc(wi.state || '', 10), options: { align: 'center' } },
          { text: this._fd(wi.closedDate), options: { align: 'center' } },
        ];
      });
      s.addTable([this._th(hdr, C.navy), ...rows.map(r => this._tr(r))], { x: 0.35, y: by + 0.32, w: 6.1, fontFace: 'Arial', fontSize: 7, colW, rowH: 0.2, color: C.darkGray });
    } else {
      s.addText('No items closed this week', { x: 0.35, y: by + 1.2, w: 6.1, h: 0.3, fontSize: 10, fontFace: 'Arial', color: C.medGray, align: 'center', italic: true });
    }
    this._cf(s, 6.85, by, 6.1, boxH);
    s.addShape(this.pptx.ShapeType.rect, { x: 6.85, y: by, w: 6.1, h: 0.035, fill: { color: C.blue } });
    s.addText('Items Created This Week', { x: 6.95, y: by + 0.05, w: 5.9, h: 0.2, fontSize: 10, fontFace: 'Arial', color: C.white, bold: true });
    if (newItems.length) {
      const hdr = ['ID', 'Title', 'Type', 'State', 'Created'];
      const colW = [0.5, 2.2, 0.7, 0.8, 1.0];
      const rows = newItems.map(wi => {
        return [
          { text: String(wi.id || ''), options: { align: 'center' } },
          { text: this._trunc(wi.title || '', 30), options: { align: 'left' } },
          { text: this._trunc(wi.type || '', 10), options: { align: 'center' } },
          { text: this._trunc(wi.state || '', 10), options: { align: 'center' } },
          { text: this._fd(wi.createdDate), options: { align: 'center' } },
        ];
      });
      s.addTable([this._th(hdr, C.blue), ...rows.map(r => this._tr(r))], { x: 6.85, y: by + 0.32, w: 6.1, fontFace: 'Arial', fontSize: 7, colW, rowH: 0.2, color: C.darkGray });
    } else {
      s.addText('No new items this week', { x: 6.85, y: by + 1.2, w: 6.1, h: 0.3, fontSize: 10, fontFace: 'Arial', color: C.medGray, align: 'center', italic: true });
    }
    by += boxH + 0.32;
    const sprintHermesIns = this._hermes?.slideInsights?.sprint;
    const sprintFallback = [
      analysis?.trends?.velocityTrend ? `Velocity trend: ${analysis.trends.velocityTrend > 0 ? '↑' : analysis.trends.velocityTrend < 0 ? '↓' : '→'} ${Math.abs(analysis.trends.velocityTrend || 0)} items/week` : '',
      analysis?.trends?.peakDay ? `Peak activity day: ${analysis.trends.peakDay}` : '',
      ctw > 0 ? `Completed ${ctw} items this week` : 'No completed items this week',
    ].filter(Boolean);
    this._ins(s, 0.35, by, 12.6, sprintHermesIns?.length ? sprintHermesIns : sprintFallback, C.navy);
    this._ftr(s, 'Weekly Activity', sn, ts);
  }

  // §§§DEAD_BLOCK_START§§§
  // ─── SLIDE 14: OPERATIONS OVERVIEW — Mekko chart ─────────────────────────
  // Mekko chart: column width = domain's total volume; height = open vs resolved.
  // This is the canonical McKinsey market-sizing chart applied to ops domains.
  // Column widths make relative volume immediately legible — more powerful than
  // a uniform bar chart where all bars have equal visual weight.
  _slideCommandCentre(an, sn, ts) {
    const C     = this.C;
    const s     = this.pptx.addSlide();
    s.background = { color: C.white };

    const sp        = this._sprintData || {};
    const st        = sp.stats         || {};
    const intel     = this._intelligence || {};
    const orgH      = an.orgHealth     || {};
    const breakdown = orgH.breakdown   || {};
    const hyg       = an.hygiene       || {};
    const wipSnap   = an.wipSnapshot   || {};
    const forecast  = an.forecast      || {};
    const actions   = (an.actions      || []).sort((a, b) => {
      const ord = { P1: 0, P2: 1, P3: 2 };
      return (ord[a.priority] ?? 9) - (ord[b.priority] ?? 9);
    });

    const hs             = st.healthScore || 0;
    const ragColor       = hs >= 70 ? C.green : hs >= 40 ? QB.amber_rag : C.red;
    const ragLabel       = hs >= 70 ? 'GREEN' : hs >= 40 ? 'AMBER' : 'RED';
    const completionPct  = st.total > 0 ? Math.round(st.closed / st.total * 100) : 0;
    const netFlow        = (st.closedThisWeek || 0) - (st.createdThisWeek || 0);
    const hygIssues      = hyg.issues || [];
    const staleCount     = (st.staleItems   || []).length;
    const blockCount     = (st.blockedItems || []).length;

    // ── Left accent bar (QB signature) ───────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0, y: 0, w: 0.25, h: 7.5, fill: { color: QB.primary } });

    // ── Title block ───────────────────────────────────────────────────────────
    s.addText('Command Centre', { x: 0.5, y: 0.32, w: 9, h: 0.44, fontSize: 22, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    s.addText(this._wl(), { x: 0.5, y: 0.82, w: 8, h: 0.28, fontSize: 11, fontFace: TYPE.font, color: QB.neutral });
    const ds = (this._dateRange?.dateTo) ? new Date(this._dateRange.dateTo) : new Date();
    s.addText(`Data as of ${ds.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' })}`, { x: 9.8, y: 0.38, w: 3.2, h: 0.28, fontSize: 8, fontFace: TYPE.font, color: C.steel, align: 'right' });
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 1.18, w: 12.5, h: 0.025, fill: { color: QB.lightGray } });

    // ── Hero KPI row — 5 large numbers ────────────────────────────────────────
    // RAG pill
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 1.33, w: 1.55, h: 0.44, fill: { color: ragColor } });
    s.addText(ragLabel, { x: 0.5, y: 1.33, w: 1.55, h: 0.44, fontSize: 13, fontFace: TYPE.font, color: C.white, bold: true, align: 'center', valign: 'middle' });

    const heroKpis = [
      { label: 'HEALTH SCORE',     value: `${hs}/100`,        color: ragColor,                                                x: 2.25 },
      { label: 'SPRINT COMPLETE',  value: `${completionPct}%`,color: completionPct >= 70 ? C.green : completionPct >= 50 ? QB.amber_rag : C.red, x: 4.85 },
      { label: 'FORECAST',         value: `${forecast.probability || 0}%`, color: (forecast.probability || 0) >= 80 ? C.green : QB.amber_rag, x: 7.45 },
      { label: 'NET FLOW',         value: `${netFlow >= 0 ? '+' : ''}${netFlow}`, color: netFlow >= 0 ? C.green : C.red,    x: 10.05 },
    ];
    heroKpis.forEach(k => {
      s.addText(String(k.value), { x: k.x, y: 1.30, w: 2.35, h: 0.42, fontSize: 24, fontFace: TYPE.font, color: k.color, bold: true, align: 'center' });
      s.addText(k.label, { x: k.x, y: 1.76, w: 2.35, h: 0.18, fontSize: 7, fontFace: TYPE.font, color: C.steel, bold: true, align: 'center' });
    });

    // ── Accent rule — QB primary bar ──────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 2.06, w: 12.5, h: 0.04, fill: { color: QB.primary } });

    // ── SCR narrative columns ─────────────────────────────────────────────────
    const situation    = intel.exec?.situation    || `Sprint ${completionPct}% complete with health ${hs}/100. ${st.closed || 0} of ${st.total || 0} items closed — ${st.closedThisWeek || 0} this week.`;
    const complication = intel.exec?.complication || (netFlow < 0
      ? `Net flow negative (${netFlow}) — ${st.createdThisWeek || 0} items entered vs ${st.closedThisWeek || 0} closed. ${hygIssues.length > 0 ? `${hygIssues.length} hygiene issue(s) unresolved.` : ''}`
      : hygIssues.length > 0
        ? `${hygIssues.length} hygiene issue(s) need resolution: ${this._trunc(hygIssues[0]?.message || '', 60)}.`
        : `No critical blockers. ${staleCount > 0 ? staleCount + ' stale item(s) need triage.' : 'Execution clean.'}`);
    const resolution   = intel.exec?.resolution   || intel.spine?.answer
      || (forecast.canFinish ? `On track to complete. ${actions.length > 0 ? 'Address ' + actions.length + ' priority action(s) before next steering.' : 'Sustain current cadence.'}` : `At risk — review scope and velocity before sprint close.`);

    const scrCols = [
      { label: 'SITUATION',    text: situation,    color: QB.teal },
      { label: 'COMPLICATION', text: complication, color: QB.amber_rag },
      { label: 'RESOLUTION',   text: resolution,   color: QB.primary },
    ];
    const colW = 3.95, colGap = 0.15;
    scrCols.forEach((col, i) => {
      const cx = 0.5 + i * (colW + colGap);
      s.addShape(this.pptx.ShapeType.rect, { x: cx, y: 2.18, w: colW, h: 0.06, fill: { color: col.color } });
      s.addText(col.label, { x: cx, y: 2.30, w: colW, h: 0.22, fontSize: 8, fontFace: TYPE.font, color: col.color, bold: true });
      s.addText(col.text,  { x: cx, y: 2.56, w: colW, h: 1.08, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, wrap: true, lineSpacing: 13 });
    });

    // ── Divider ───────────────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 3.75, w: 12.5, h: 0.015, fill: { color: QB.lightGray } });

    // ── LEFT: health component bars ───────────────────────────────────────────
    s.addText('HEALTH BREAKDOWN', { x: 0.5, y: 3.86, w: 6.5, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: QB.primary, bold: true });
    const components = [
      { label: 'Engineering',  score: breakdown.engineering || 0 },
      { label: 'Operations',   score: breakdown.operations  || 0 },
      { label: 'HR',           score: breakdown.hr          || 0 },
      { label: 'Hygiene',      score: hyg.score             || 0 },
      { label: 'Forecast',     score: forecast.probability  || 0 },
    ];
    const barMaxW = 3.8;
    components.forEach((comp, i) => {
      const cy = 4.14 + i * 0.44;
      const bw = barMaxW * Math.min(comp.score, 100) / 100;
      const bc = comp.score >= 70 ? C.green : comp.score >= 40 ? QB.amber_rag : comp.score === 0 ? C.steel : C.red;
      s.addText(comp.label, { x: 0.5, y: cy + 0.04, w: 1.55, h: 0.28, fontSize: 8.5, fontFace: TYPE.font, color: QB.warmDark });
      s.addShape(this.pptx.ShapeType.rect, { x: 2.1, y: cy + 0.08, w: barMaxW, h: 0.18, fill: { color: QB.offWhite }, line: { pt: 0 } });
      if (bw > 0.01) s.addShape(this.pptx.ShapeType.rect, { x: 2.1, y: cy + 0.08, w: bw, h: 0.18, fill: { color: bc }, line: { pt: 0 } });
      s.addText(`${comp.score}`, { x: 6.05, y: cy + 0.04, w: 0.55, h: 0.28, fontSize: 8.5, fontFace: TYPE.font, color: bc, bold: true, align: 'right' });
    });

    // ── RIGHT: priority actions list ──────────────────────────────────────────
    s.addText("TODAY'S PRIORITY ACTIONS", { x: 7.2, y: 3.86, w: 5.8, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: QB.primary, bold: true });
    if (actions.length === 0) {
      s.addText('No priority actions — execution on track', { x: 7.2, y: 4.14, w: 5.8, h: 0.3, fontSize: 9, fontFace: TYPE.font, color: C.green, italic: true });
    } else {
      actions.slice(0, 4).forEach((a, i) => {
        const cy  = 4.14 + i * 0.58;
        const dot = a.priority === 'P1' ? C.red : a.priority === 'P2' ? QB.amber_rag : C.steel;
        s.addShape(this.pptx.ShapeType.rect, { x: 7.2, y: cy + 0.02, w: 0.38, h: 0.26, fill: { color: dot } });
        s.addText(a.priority || '', { x: 7.2, y: cy + 0.02, w: 0.38, h: 0.26, fontSize: 7.5, fontFace: TYPE.font, color: C.white, bold: true, align: 'center', valign: 'middle' });
        s.addText(this._budget(a.action || '', 78), { x: 7.66, y: cy, w: 5.3, h: 0.30, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, wrap: true });
        if (a.owner) s.addText(a.owner, { x: 7.66, y: cy + 0.30, w: 5.3, h: 0.22, fontSize: 7.5, fontFace: TYPE.font, color: C.steel, italic: true });
      });
    }

    // ── So what callout ───────────────────────────────────────────────────────
    const soWhat = intel.exec?.complication
      || (netFlow < 0 ? `Net flow negative (${netFlow}) — backlog growing faster than team is closing. Triage new items immediately.`
        : hygIssues.length > 0 ? `${hygIssues.length} hygiene issue(s) unresolved — ${this._trunc(hygIssues[0]?.message || '', 70)}`
        : `Sprint ${completionPct}% complete, health ${hs}/100 — ${actions.length > 0 ? actions.length + ' action(s) require owner confirmation' : 'no blocking issues'}`);
    this._annotate(s, 0.5, 6.32, 12.5, soWhat, netFlow < 0 ? C.red : hygIssues.length > 0 ? QB.amber_rag : QB.primary);
    this._ftr(s, 'Command Centre — BizTech', sn, ts);
  }

  _slideDeliveryVelocity(an, sn, ts) {
    const C  = this.C;
    const s  = this.pptx.addSlide();
    s.background = { color: C.white };

    const sp      = this._sprintData || {};
    const st      = sp.stats         || {};
    const tputVar = an.throughputVar  || {};
    const cycDist = an.cycleTimeDist  || {};
    const wipSnap = an.wipSnapshot    || {};

    const closedWk   = st.closedThisWeek  || 0;
    const createdWk  = st.createdThisWeek || 0;
    const netFlow    = closedWk - createdWk;
    const staleCount = (st.staleItems   || []).length;
    const blockCount = (st.blockedItems || []).length;
    const loadBal    = an.loadBalance   || {};
    const tputWeekly = tputVar.weekly   || [];
    const byType     = Object.entries(st.byType || {});
    const totalByType = byType.filter(([, v]) => (v.total || 0) > 0);

    // ── Left accent bar ───────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0, y: 0, w: 0.25, h: 7.5, fill: { color: QB.primary } });

    // ── Title block ───────────────────────────────────────────────────────────
    s.addText('Delivery & Velocity', { x: 0.5, y: 0.32, w: 9, h: 0.44, fontSize: 22, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    s.addText(this._wl(), { x: 0.5, y: 0.82, w: 8, h: 0.28, fontSize: 11, fontFace: TYPE.font, color: QB.neutral });
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 1.18, w: 12.5, h: 0.025, fill: { color: QB.lightGray } });

    // ── Hero numbers row ──────────────────────────────────────────────────────
    const tputDelta = tputWeekly.length >= 2 ? tputWeekly[0] - tputWeekly[1] : null;
    const heroKpis = [
      { label: 'CLOSED THIS WEEK',  value: closedWk,  color: C.green,  x: 0.5 },
      { label: 'CREATED THIS WEEK', value: createdWk, color: C.navy,   x: 3.1 },
      { label: 'NET FLOW',          value: `${netFlow >= 0 ? '+' : ''}${netFlow}`, color: netFlow >= 0 ? C.green : C.red, x: 5.7 },
      { label: 'WoW DELTA',         value: tputDelta !== null ? `${tputDelta >= 0 ? '+' : ''}${tputDelta}` : 'N/A', color: tputDelta !== null ? (tputDelta >= 0 ? C.green : C.red) : C.steel, x: 8.3 },
      { label: 'LOAD BALANCE',      value: loadBal.balanced ? 'Balanced' : 'Skewed', color: loadBal.balanced ? C.green : QB.amber_rag, x: 10.9 },
    ];
    heroKpis.forEach(k => {
      s.addText(String(k.value), { x: k.x, y: 1.30, w: 2.3, h: 0.42, fontSize: 22, fontFace: TYPE.font, color: k.color, bold: true, align: 'center' });
      s.addText(k.label, { x: k.x, y: 1.76, w: 2.3, h: 0.18, fontSize: 7, fontFace: TYPE.font, color: C.steel, bold: true, align: 'center' });
    });

    // ── Accent rule ───────────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 2.06, w: 12.5, h: 0.04, fill: { color: QB.primary } });

    // ── Section label ─────────────────────────────────────────────────────────
    s.addText('WEEKLY THROUGHPUT  —  items closed per week', { x: 0.5, y: 2.18, w: 7.5, h: 0.24, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    s.addText('WORK ITEMS BY TYPE', { x: 8.4, y: 2.18, w: 4.6, h: 0.24, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, bold: true });

    // ── Main chart: throughput (dominant left) ────────────────────────────────
    const rev = tputWeekly.length > 0 ? [...tputWeekly].reverse() : [0, 0, 0, closedWk];
    const tputLabels = rev.map((_, i) => i === rev.length - 1 ? 'This Wk' : `W-${rev.length - 1 - i}`);
    this._consultingBar(s, 0.5, 2.48, 7.6, 2.55, {
      labels: tputLabels,
      values: rev,
    }, [QB.primary, C.navy, C.teal, C.blue], { titleColor: C.darkGray });

    // ── Right: work type distribution ────────────────────────────────────────
    if (totalByType.length > 0) {
      this._consultingBar(s, 8.4, 2.48, 4.6, 2.55, {
        labels: totalByType.slice(0, 6).map(([t]) => this._trunc(t, 12)),
        values: totalByType.slice(0, 6).map(([, v]) => v.total),
      }, CHART_COLORS, { titleColor: C.darkGray, horizontal: true });
    } else {
      this._noData(s, 8.4, 2.48, 4.6, 2.55, 'By Type');
    }

    // ── Divider ───────────────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 5.18, w: 12.5, h: 0.015, fill: { color: QB.lightGray } });

    // ── Contributor throughput table ──────────────────────────────────────────
    s.addText('CONTRIBUTOR THROUGHPUT THIS WEEK', { x: 0.5, y: 5.28, w: 6.2, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: QB.primary, bold: true });
    const byAssignSorted = Object.entries(st.byAssignee || {})
      .filter(([, v]) => (v.closedThisWeek || 0) > 0)
      .sort(([, a], [, b]) => (b.closedThisWeek || 0) - (a.closedThisWeek || 0))
      .slice(0, 5);
    if (byAssignSorted.length > 0) {
      const teamRows = byAssignSorted.map(([name, v], i) => this._tr([
        this._t(this._trunc(name, 18), { align: 'left', bold: true, color: C.darkGray }),
        this._t(String(v.closedThisWeek || 0), { align: 'center', bold: true, color: C.green }),
        this._t(String(v.active || 0),         { align: 'center', color: C.teal }),
        this._t(String(v.total  || 0),         { align: 'center', color: C.navy }),
      ], i));
      s.addTable([this._th(['CONTRIBUTOR', 'CLOSED/WK', 'ACTIVE', 'TOTAL']), ...teamRows], {
        x: 0.5, y: 5.54, w: 6.2, colW: [3.1, 1.1, 1.0, 1.0], rowH: 0.24,
        fontFace: 'Arial', fontSize: 8, color: C.darkGray,
      });
    } else {
      s.addText('No contributor data — no items closed this week', { x: 0.5, y: 5.54, w: 6.2, h: 0.3, fontSize: 8.5, fontFace: TYPE.font, color: C.neutral, italic: true });
    }

    // ── WoW signal box ────────────────────────────────────────────────────────
    if (tputWeekly.length >= 2) {
      const thisWk = tputWeekly[0], prevWk = tputWeekly[1];
      const delta = thisWk - prevWk;
      s.addText('WEEK-OVER-WEEK', { x: 7.8, y: 5.28, w: 5.2, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: QB.primary, bold: true });
      s.addText(String(thisWk), { x: 7.8, y: 5.52, w: 1.8, h: 0.52, fontSize: 36, fontFace: TYPE.font, color: C.navy, bold: true });
      s.addText('closed this week', { x: 7.8, y: 6.06, w: 2.5, h: 0.22, fontSize: 8, fontFace: TYPE.font, color: C.steel });
      const dCol = delta >= 0 ? C.green : C.red;
      s.addText(`${delta >= 0 ? '+' : ''}${delta} vs last week`, { x: 9.75, y: 5.55, w: 3.5, h: 0.36, fontSize: 18, fontFace: TYPE.font, color: dCol, bold: true });
      s.addText(delta >= 0 ? '↑ Accelerating' : '↓ Slowing', { x: 9.75, y: 5.96, w: 3.5, h: 0.28, fontSize: 10, fontFace: TYPE.font, color: dCol });
    }

    // ── So what ───────────────────────────────────────────────────────────────
    const soWhat = netFlow < 0
      ? `Net flow negative (${netFlow}) — ${createdWk} new items entered vs ${closedWk} closed. Backlog growing — review scope intake.`
      : staleCount > 0
        ? `${staleCount} stale item(s) ageing in the backlog — assign owners and close or defer before next sprint planning.`
        : `Throughput healthy — ${closedWk} items closed this week, net flow ${netFlow >= 0 ? '+' : ''}${netFlow}. Sustain cadence.`;
    this._annotate(s, 0.5, 6.38, 12.5, soWhat, netFlow < 0 ? C.red : staleCount > 0 ? QB.amber_rag : QB.primary);
    this._ftr(s, 'Delivery & Velocity — BizTech', sn, ts);
  }

  _slideActionsRiskTeam(an, sn, ts) {
    const C  = this.C;
    const s  = this.pptx.addSlide();
    s.background = { color: C.white };

    const sp         = this._sprintData || {};
    const st         = sp.stats         || {};
    const intel      = this._intelligence || {};
    const actions    = (an.actions      || []).sort((a, b) => {
      const ord = { P1: 0, P2: 1, P3: 2 };
      return (ord[a.priority] ?? 9) - (ord[b.priority] ?? 9);
    });
    const hyg        = an.hygiene       || {};
    const orgH       = an.orgHealth     || {};
    const loadBal    = an.loadBalance   || {};
    const hygIssues  = hyg.issues       || [];
    const p1Count    = actions.filter(a => a.priority === 'P1').length;
    const p2Count    = actions.filter(a => a.priority === 'P2').length;

    // stale/blocked per assignee
    const staleByP = {}, blockedByP = {};
    (st.staleItems   || []).forEach(wi => { const w = wi.assignedTo || 'Unassigned'; staleByP[w]   = (staleByP[w]   || 0) + 1; });
    (st.blockedItems || []).forEach(wi => { const w = wi.assignedTo || 'Unassigned'; blockedByP[w] = (blockedByP[w] || 0) + 1; });

    const byAssign     = Object.entries(st.byAssignee || {});
    const overdueItems = (st.overdueItems || []).slice(0, 4);
    const staleItems   = (st.staleItems   || []).slice(0, 4);
    const bottleneck   = overdueItems.length > 0 ? overdueItems : staleItems;

    // ── Left accent bar ───────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0, y: 0, w: 0.25, h: 7.5, fill: { color: QB.primary } });

    // ── Title block ───────────────────────────────────────────────────────────
    s.addText('Actions, Risk & Team', { x: 0.5, y: 0.32, w: 9, h: 0.44, fontSize: 22, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    s.addText(this._wl(), { x: 0.5, y: 0.82, w: 8, h: 0.28, fontSize: 11, fontFace: TYPE.font, color: QB.neutral });
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 1.18, w: 12.5, h: 0.025, fill: { color: QB.lightGray } });

    // ── Hero KPI row ──────────────────────────────────────────────────────────
    const heroKpis = [
      { label: 'TOTAL ACTIONS',  value: actions.length, color: actions.length > 0 ? C.navy : C.steel, x: 0.5 },
      { label: 'P1 CRITICAL',    value: p1Count,        color: p1Count > 0 ? C.red : C.green,         x: 3.1 },
      { label: 'P2 HIGH',        value: p2Count,        color: p2Count > 0 ? QB.amber_rag : C.green,  x: 5.7 },
      { label: 'TEAM MEMBERS',   value: byAssign.length,color: C.teal,                                 x: 8.3 },
      { label: 'ORG HEALTH',     value: orgH.overall || 0, color: this._sc(orgH.overall || 0),        x: 10.9 },
    ];
    heroKpis.forEach(k => {
      s.addText(String(k.value), { x: k.x, y: 1.30, w: 2.3, h: 0.42, fontSize: 22, fontFace: TYPE.font, color: k.color, bold: true, align: 'center' });
      s.addText(k.label, { x: k.x, y: 1.76, w: 2.3, h: 0.18, fontSize: 7, fontFace: TYPE.font, color: C.steel, bold: true, align: 'center' });
    });

    // ── Accent rule ───────────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 2.06, w: 12.5, h: 0.04, fill: { color: QB.primary } });

    // ── LEFT: Priority actions as annotated list ───────────────────────────────
    s.addText('PRIORITY ACTIONS', { x: 0.5, y: 2.18, w: 7.5, h: 0.26, fontSize: 10, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    if (actions.length === 0) {
      s.addText('No priority actions — all metrics within threshold.', { x: 0.5, y: 2.50, w: 7.5, h: 0.32, fontSize: 9.5, fontFace: TYPE.font, color: C.green, italic: true });
    } else {
      actions.slice(0, 5).forEach((a, i) => {
        const cy  = 2.52 + i * 0.65;
        const dot = a.priority === 'P1' ? C.red : a.priority === 'P2' ? QB.amber_rag : C.steel;
        // Priority pill
        s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: cy + 0.01, w: 0.40, h: 0.28, fill: { color: dot } });
        s.addText(a.priority || '', { x: 0.5, y: cy + 0.01, w: 0.40, h: 0.28, fontSize: 7.5, fontFace: TYPE.font, color: C.white, bold: true, align: 'center', valign: 'middle' });
        // Action text
        s.addText(this._budget(a.action || '', 88), { x: 0.98, y: cy, w: 6.8, h: 0.30, fontSize: 9, fontFace: TYPE.font, color: QB.warmDark, wrap: true });
        // Owner + reason
        const meta = [a.owner, a.reason].filter(Boolean).join(' — ');
        if (meta) s.addText(this._trunc(meta, 90), { x: 0.98, y: cy + 0.30, w: 6.8, h: 0.28, fontSize: 7.5, fontFace: TYPE.font, color: C.steel, italic: true });
      });
    }

    // ── RIGHT: Team workload as horizontal bars ────────────────────────────────
    s.addText('TEAM WORKLOAD', { x: 8.6, y: 2.18, w: 4.9, h: 0.26, fontSize: 10, fontFace: TYPE.font, color: QB.warmDark, bold: true });
    const maxActive = byAssign.reduce((m, [, v]) => Math.max(m, v.active || 0), 1);
    byAssign.slice(0, 6).forEach(([name, v], i) => {
      const cy   = 2.52 + i * 0.52;
      const pct  = (v.active || 0) / maxActive;
      const bCol = (v.active || 0) >= 8 ? C.red : (v.active || 0) >= 5 ? QB.amber_rag : C.teal;
      s.addText(this._trunc(name, 14), { x: 8.6, y: cy + 0.04, w: 1.85, h: 0.28, fontSize: 8.5, fontFace: TYPE.font, color: QB.warmDark });
      s.addShape(this.pptx.ShapeType.rect, { x: 10.55, y: cy + 0.09, w: 2.6, h: 0.18, fill: { color: QB.offWhite }, line: { pt: 0 } });
      if (pct > 0.01) s.addShape(this.pptx.ShapeType.rect, { x: 10.55, y: cy + 0.09, w: 2.6 * pct, h: 0.18, fill: { color: bCol }, line: { pt: 0 } });
      s.addText(String(v.active || 0), { x: 13.22, y: cy + 0.04, w: 0.4, h: 0.28, fontSize: 8.5, fontFace: TYPE.font, color: bCol, bold: true });
    });

    // ── Divider ───────────────────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect, { x: 0.5, y: 5.68, w: 12.5, h: 0.015, fill: { color: QB.lightGray } });

    // ── Bottom: hygiene issues (left) + bottleneck items (right) ─────────────
    if (hygIssues.length > 0) {
      s.addText('HYGIENE ISSUES', { x: 0.5, y: 5.76, w: 6.2, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: QB.amber_rag, bold: true });
      hygIssues.slice(0, 3).forEach((iss, i) => {
        const dot = iss.severity === 'high' ? C.red : QB.amber_rag;
        s.addShape(this.pptx.ShapeType.ellipse, { x: 0.5, y: 6.04 + i * 0.26 + 0.05, w: 0.09, h: 0.09, fill: { color: dot } });
        s.addText(this._trunc(iss.message || '', 80), { x: 0.68, y: 6.02 + i * 0.26, w: 6.0, h: 0.24, fontSize: 8.5, fontFace: TYPE.font, color: QB.warmDark });
      });
    }

    const bnLabel = overdueItems.length > 0 ? 'OVERDUE ITEMS' : (staleItems.length > 0 ? 'STALE ITEMS' : null);
    if (bnLabel && bottleneck.length > 0) {
      s.addText(bnLabel, { x: 7.2, y: 5.76, w: 6.0, h: 0.22, fontSize: 8.5, fontFace: TYPE.font, color: C.red, bold: true });
      bottleneck.forEach((wi, i) => {
        s.addShape(this.pptx.ShapeType.ellipse, { x: 7.2, y: 6.04 + i * 0.26 + 0.05, w: 0.09, h: 0.09, fill: { color: C.red } });
        s.addText(`${this._trunc(wi.title || `Item #${wi.id}`, 35)}  —  ${this._trunc(wi.assignedTo || 'Unassigned', 14)}`, { x: 7.38, y: 6.02 + i * 0.26, w: 5.8, h: 0.24, fontSize: 8.5, fontFace: TYPE.font, color: QB.warmDark });
      });
    } else if (!bnLabel) {
      s.addText('No overdue or stale items — backlog clean', { x: 7.2, y: 5.76, w: 6.0, h: 0.3, fontSize: 9, fontFace: TYPE.font, color: C.green, italic: true });
    }

    // ── So what callout ───────────────────────────────────────────────────────
    const soWhat = p1Count > 0
      ? `${p1Count} P1 critical action(s) escalate to leads now — ${actions.filter(a => a.priority === 'P1').map(a => a.owner || 'TBD').join(', ')} must act before next steering`
      : actions.length > 0
        ? `${p2Count} P2 action(s) need owner confirmation — ${this._trunc(actions[0].action || '', 80)}`
        : 'No blocking actions this sprint — team execution is clean. Sustain discipline.';
    this._annotate(s, 0.5, 6.35, 12.5, soWhat, p1Count > 0 ? C.red : p2Count > 0 ? QB.amber_rag : QB.primary);
    this._ftr(s, 'Actions, Risk & Team — BizTech', sn, ts);
  }


  // ══════════════════════════════════════════════════════════════════════════
  // McKINSEY/BCG CHROME + SHARED HELPERS
  // Layout grid (all domain slides):
  //   Chrome    : left bar x=0 w=0.18 | title y=0.16 | navy HR y=0.90 | KPIs y=0.96–1.70
  //   Left panel: x=0.35 y=1.80 w=6.10 h=2.25  (exhibits)
  //   Right panel: x=6.70 y=1.80 w=6.20 h=2.25 (exhibits)
  //   Bottom    : x=0.35 y=4.05 header | y=4.28 chart h=2.28
  //   So-what   : y=6.62 rule | y=6.65 band h=0.50
  //   Footer    : y=7.22 rule | y=7.26 text
  // ══════════════════════════════════════════════════════════════════════════

  // Slide chrome — call first on every domain slide
  // Font scale: 24/14/10/8 (was 22/17/11/10/9/8.5/8/7/6.5 — 9 sizes collapsed to 4)
  // Status-driven rule color: pulls from analysis.executiveVerdict.bucket (red/amber/green)
  _slideChrome(s, title, soWhat, sn, ts, slideName) {
    const N='1B2A4A',OW='F7F7F5',DG='2C2C2C',RL='D4D4D0',MG='9B9B9B';
    const R='C0392B',A='E67E22',G='27AE60';
    // Cap title at 90 chars + sub-line so it stays single-line at 14pt and never crashes into the rule.
    const T_MAX = 90;
    let titleMain = title || '';
    let titleSub  = '';
    if (titleMain.length > T_MAX) {
      const dash = titleMain.indexOf(' — ');
      if (dash > 20 && dash < T_MAX) {
        titleMain = title.slice(0, dash);
        titleSub  = title.slice(dash + 3);
      } else {
        titleSub  = titleMain.slice(T_MAX);
        titleMain = titleMain.slice(0, T_MAX).replace(/[,\s]+\S*$/, '') + '…';
      }
    }
    // Status-driven chrome rule: red/amber/green derived from healthScore
    const hs = this._sprintData?.stats?.healthScore || this._an?.executiveVerdict?.healthScore || 0;
    const ruleColor = hs >= 70 ? G : hs >= 50 ? A : R;

    s.background = { color:'FFFFFF' };
    s.addShape(this.pptx.ShapeType.rect,{x:0,y:0,w:0.18,h:7.5,fill:{color:N}});
    s.addText(titleMain,{x:0.35,y:0.14,w:12.62,h:0.46,fontSize:18,fontFace:'Calibri',color:DG,bold:true,lineSpacing:22});
    if (titleSub) {
      s.addText(titleSub,{x:0.35,y:0.58,w:12.62,h:0.32,fontSize:10,fontFace:'Calibri',color:MG,italic:true,lineSpacing:13});
    }
    // Status rule (was always navy; now red/amber/green)
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:0.92,w:12.62,h:0.030,fill:{color:ruleColor}});
    // "Data as of" — bumped from 8pt to 10pt and moved alongside the top rule for legibility
    const endDate = (this._dateRange?.dateTo) ? new Date(this._dateRange.dateTo) : new Date();
    const ds = endDate.toLocaleDateString('en-IN',{ timeZone:'Asia/Kolkata', day:'2-digit', month:'short', year:'numeric' });
    s.addText(`As of ${ds}`,{x:10.75,y:0.16,w:2.22,h:0.22,fontSize:10,fontFace:'Calibri',color:MG,align:'right'});

    // Single soWhat callout at bottom — removed the duplicate that lived in the chrome footer band.
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:6.62,w:12.62,h:0.020,fill:{color:ruleColor}});
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:6.65,w:12.62,h:0.52,fill:{color:OW},line:{type:'none'}});
    s.addText('▸  '+(soWhat||'Analysis pending — run LLM annotation for executive insight.'),
      {x:0.52,y:6.71,w:12.38,h:0.46,fontSize:10,fontFace:'Calibri',color:DG,italic:true,lineSpacing:13});
    // Footer: bumped from 6.5pt to 10pt for page number; secondary text trimmed (footer line was 0.6" wasted x14 slides)
    s.addText(`${slideName}  ·  CONFIDENTIAL  ·  ${this._wl()}`,
      {x:0.35,y:7.26,w:9.0,h:0.18,fontSize:8,fontFace:'Arial',color:MG,italic:true});
    if(sn&&ts) s.addText(`${sn} / ${ts}`,{x:11.85,y:7.24,w:1.12,h:0.20,fontSize:10,fontFace:'Calibri',color:DG,bold:true,align:'right'});
  }

  // KPI strip — bottom rule retained at y=1.70 (do not move; downstream slides anchor exhibits at y=1.80)
  // Visual hierarchy: primary KPI (index 0) is boxed and 28pt; secondary KPIs are 18pt.
  // Color palette reduced to the canonical 5 (navy/red/green/amber/teal); 8E44AD and 16A085 retired.
  _kpiStrip(s, kpis) {
    const DEF=['1B2A4A','C0392B','27AE60','E67E22','0A7EA4'];
    const n=Math.min(kpis.length,7);
    const primW = 2.30;
    const secW  = (12.62 - primW) / Math.max(n-1, 1);
    kpis.slice(0, n).forEach((k, i) => {
      if (i === 0) {
        // Primary KPI — boxed, larger, anchored left
        // BUG FIX: text box h was 0.42" but 26pt needs ~0.43" min — pptx audit
        // flagged this on 38 of 41 slides. Bumped to 0.46" (well above 26pt
        // line height) so the digit never gets vertically clipped.
        s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:0.92,w:primW-0.10,h:0.74,fill:{color:'F7F7F5'},line:{color:'D4D4D0',width:0.5}});
        s.addText(String(k.value??'—'),{x:0.35,y:0.92,w:primW-0.10,h:0.46,fontSize:26,fontFace:'Calibri',color:k.color||DEF[0],bold:true,align:'center',valign:'middle'});
        s.addText((k.label||'').toUpperCase(),{x:0.35,y:1.40,w:primW-0.10,h:0.20,fontSize:8,fontFace:'Calibri',color:'9B9B9B',bold:true,align:'center'});
      } else {
        const x = 0.35 + primW + (i-1)*secW;
        s.addText(String(k.value??'—'),{x,y:0.96,w:secW-0.05,h:0.46,fontSize:18,fontFace:'Calibri',color:k.color||DEF[i%DEF.length],bold:true,align:'center'});
        s.addText((k.label||'').toUpperCase(),{x,y:1.46,w:secW-0.05,h:0.18,fontSize:8,fontFace:'Calibri',color:'9B9B9B',bold:true,align:'center'});
      }
    });
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:1.70,w:12.62,h:0.015,fill:{color:'D4D4D0'}});
  }

  // Horizontal bar rows — manual shapes, crisp and colourful like the approved sample
  // colorFn(i, value) optional; overrides single color
  // _hBar(s, x, y, availW, data, maxVal, color, colorFn, maxH?)
  // BUG FIX: hardcoded BH+GAP=0.32 per row meant 5 rows took 1.60", which
  // overflowed cockpit quadrants (renderH≈0.78") and bled into the next
  // quadrant header below. Optional `maxH` param now scales BH/GAP to fit
  // the available height. Cockpit render closures pass their `h`.
  _hBar(s, x, y, availW, data, maxVal, color, colorFn, maxH) {
    let BH=0.24, GAP=0.08;
    const LW=1.62,TS=0.06,VG=0.08;
    const n = data.length;
    if (maxH && n > 0) {
      const requiredH = BH * n + GAP * Math.max(0, n-1);
      if (requiredH > maxH) {
        const scale = maxH / requiredH;
        BH = Math.max(0.10, BH * scale);
        GAP = Math.max(0.02, GAP * scale);
      }
    }
    const trackW=availW-LW-0.38;
    const fontPt = Math.max(6, Math.min(7, BH * 28));    // shrink font when row very small
    data.forEach((row,i)=>{
      const ry=y+i*(BH+GAP);
      const barW=maxVal>0?Math.max(0.04,(row.value/maxVal)*trackW):0.04;
      const bc=colorFn?colorFn(i,row.value):(color||'1B2A4A');
      s.addText(this._trunc(row.label,24),{x,y:ry,w:LW,h:BH,fontSize:fontPt,fontFace:'Calibri',color:'2C2C2C',align:'right',valign:'middle'});
      s.addShape(this.pptx.ShapeType.rect,{x:x+LW+TS,y:ry+0.04,w:trackW,h:Math.max(0.04,BH-0.08),fill:{color:'E8E8E6'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:x+LW+TS,y:ry+0.04,w:barW,h:Math.max(0.04,BH-0.08),fill:{color:bc},line:{type:'none'}});
      // Clamp value label so it doesn't cross x+availW (was bleeding into
      // adjacent quadrant on Team Pulse Q1→Q2 boundary)
      const valLabelX = x+LW+TS+barW+VG;
      const valLabelW = Math.max(0.20, Math.min(0.45, x+availW - valLabelX - 0.02));
      s.addText(String(row.value),{x:valLabelX,y:ry,w:valLabelW,h:BH,fontSize:Math.min(7.5, fontPt+0.5),fontFace:'Calibri',color:'2C2C2C',bold:true,valign:'middle'});
    });
  }

  // Stacked horizontal proportion bar — segments=[{label,count,color}]
  // Inline labels inside wide segments; below-bar legend always rendered for
  // all non-zero segments (fixes the awkward floating "count / label" pairs
  // on borderline segments observed on slide 6 OEG).
  // _stackedBar(s, x, y, w, h, segments, opts?)
  // opts.noLegend — suppress the below-bar legend row (use when rendering
  // inside compressed cockpit quadrants where the legend would overlap the
  // next exhibit). Inline labels inside wide segments still render.
  _stackedBar(s, x, y, w, h, segments, opts = {}) {
    const total = segments.reduce((a,sg)=>a+(sg.count||0), 0);
    if(!total) return;
    let cumW = 0;
    segments.forEach(sg => {
      const sw = ((sg.count||0)/total)*w;
      if (sw > 0.02) {
        s.addShape(this.pptx.ShapeType.rect,{x:x+cumW,y,w:sw,h,fill:{color:sg.color||'9B9B9B'},line:{type:'none'}});
        if (sw >= 1.10) {
          s.addText(`${sg.count} ${sg.label||''}`,
            {x:x+cumW+0.06,y,w:sw-0.12,h,fontSize:10,fontFace:'Calibri',color:'FFFFFF',bold:true,valign:'middle'});
        } else if (sw >= 0.40) {
          s.addText(String(sg.count),
            {x:x+cumW,y,w:sw,h,fontSize:10,fontFace:'Calibri',color:'FFFFFF',bold:true,align:'center',valign:'middle'});
        }
      }
      cumW += sw;
    });
    if (opts.noLegend) return;   // BUG FIX: skip legend in tight cockpit Q renders
    // Legend row below — always rendered for non-zero segments
    // BUG FIX: previously the text BOX was always 1.30" wide but `lx` advanced
    // by Math.min(1.30, txt.length*0.065). For "Closed: 2" (8 chars × 0.065
    // ≈ 0.52") the next legend item started inside the previous text box
    // → visible overlap on slide 13 OEG. Now the text box width matches
    // the actual text width, so spacing and rendering agree.
    const visible = segments.filter(sg => (sg.count||0) > 0);
    let lx = x;
    const swatchW = 0.14, gap = 0.18, lineY = y + h + 0.10;
    visible.forEach(sg => {
      s.addShape(this.pptx.ShapeType.rect,{x:lx,y:lineY+0.02,w:swatchW,h:0.14,fill:{color:sg.color||'9B9B9B'},line:{type:'none'}});
      const txt = `${sg.label}: ${sg.count}`;
      const txtW = Math.min(1.30, Math.max(0.40, txt.length*0.065));
      s.addText(txt,{x:lx+swatchW+0.04,y:lineY,w:txtW,h:0.20,fontSize:8,fontFace:'Calibri',color:'2C2C2C',valign:'middle'});
      lx += swatchW + 0.04 + txtW + gap;
    });
  }

  // Callout/annotation box with left accent — identical to approved sample red callout
  _calloutBox(s, x, y, w, h, text, accentColor) {
    const bg=accentColor==='C0392B'?'FEF3F2':accentColor==='E67E22'?'FFF8E7':accentColor==='27AE60'?'EAFAF1':'EBF5FB';
    s.addShape(this.pptx.ShapeType.rect,{x,y,w,h,fill:{color:bg},line:{color:accentColor||'C0392B',width:1}});
    s.addShape(this.pptx.ShapeType.rect,{x,y,w:0.06,h,fill:{color:accentColor||'C0392B'},line:{type:'none'}});
    s.addText(text,{x:x+0.12,y:y+0.06,w:w-0.18,h:h-0.12,fontSize:8,fontFace:'Calibri',color:accentColor||'C0392B',bold:true,lineSpacing:11});
  }

  // Exhibit heading (section label + subtitle)
  // BUG FIX: subtitle previously sat at y+0.22 with h:0.18 (ended at y+0.40)
  // while callers placed content at y+0.38 — subtitle visually overlapped the
  // first content row by 0.02" on dozens of slides. Tightened: label h:0.20
  // (ends y+0.20), subtitle starts at y+0.20 with h:0.16 (ends y+0.36).
  // Callers using y+0.38 now have a 0.02" gap below the subtitle.
  _exhibitHead(s, x, y, w, label, subtitle) {
    s.addText(label,{x,y,w,h:0.20,fontSize:8,fontFace:'Calibri',color:'1B2A4A',bold:true,valign:'top'});
    if(subtitle) s.addText(subtitle,{x,y:y+0.20,w,h:0.16,fontSize:7,fontFace:'Calibri',color:'9B9B9B',valign:'top'});
  }

  // Bottom section header — label at y=4.05, thin rule at y=4.25
  // Font bumped from 8pt → 10pt for legibility (was unreadable at projector distance).
  _bottomHead(s, label) {
    s.addText(label,{x:0.35,y:4.05,w:12.62,h:0.22,fontSize:10,fontFace:'Calibri',color:'1B2A4A',bold:true});
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:4.25,w:12.62,h:0.015,fill:{color:'D4D4D0'}});
  }

  // ── Deck-wide sanity helper ────────────────────────────────────────────
  // Logs (to stderr — visible in n8n bridge logs) when slide-internal math
  // contradicts itself. Examples this catches:
  //   - Sprint slide: declared total < breakdown sum (was: total=2 vs 24+25 in bars)
  //   - Cloud slide: total>0 but breakdown all zero
  //   - Generic: kpi labels declaring "0%" alongside non-zero values
  // Slide methods call this with their own field names; helper only WARNS,
  // never throws — we always render a deck even with a math anomaly.
  _validateSlideMath(slideName, fields) {
    const issues = [];
    // Sprint-style check: declared total < breakdown sum
    if ('declaredTotal' in fields && 'breakdownSum' in fields
        && fields.breakdownSum > fields.declaredTotal && fields.declaredTotal > 0) {
      issues.push(`stats.total (${fields.declaredTotal}) < breakdown sum (${fields.breakdownSum}) — using breakdown`);
    }
    // Cloud-style check: total > 0 but every outcome is zero
    if ('total' in fields && fields.total > 0
        && (['prov','failed','pending','provisioned','closed','open']
            .every(k => !(k in fields) || fields[k] === 0))
        && !('done' in fields)) {
      issues.push(`total=${fields.total} but every outcome field is zero — upstream breakdown likely missing`);
    }
    if (issues.length > 0 && this._sanityLog !== false) {
      try { process.stderr.write(`[PPTX-SANITY] ${slideName}: ${issues.join(' · ')}\n`); } catch (_) {}
      // Stash on instance so the Hermes Learning slide can surface as a learning candidate
      (this._sanityIssues = this._sanityIssues || []).push({ slide: slideName, issues });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // COCKPIT SLIDE PATTERN
  //   Compresses a domain (ITSM/MPR/Owner views) from 4–7 slides into 1–2:
  //     · Standard chrome + KPI strip
  //     · Top half = 2x2 quadrant grid (or full-width exhibit)
  //     · Bottom half = LLM Insight Panel (Hermes-generated narrative + actions)
  //   Per project rule: every cockpit slide MUST surface Hermes insight as a
  //   first-class element. When Hermes is unavailable the panel renders a
  //   visibly-marked fallback so the gap is obvious in the deck.
  //
  //   opts = {
  //     title, soWhat, sn, ts, slideName,
  //     kpis: [{value,label,color}],
  //     quadrants: [{title, subtitle, render(s,x,y,w,h)}],   // up to 4
  //     fullWidthTop: {title, subtitle, render(s,x,y,w,h)},  // alternative to quadrants
  //     insight: {headline, body, actions} | null            // null => fallback panel
  //   }
  // ══════════════════════════════════════════════════════════════════════════
  _drawCockpit(s, opts) {
    this._slideChrome(s, opts.title, opts.soWhat, opts.sn, opts.ts, opts.slideName);
    this._kpiStrip(s, opts.kpis || []);

    if (opts.fullWidthTop) {
      const fw = opts.fullWidthTop;
      if (fw.title) this._exhibitHead(s, 0.35, 1.80, 12.62, fw.title, fw.subtitle);
      fw.render(s, 0.35, 2.18, 12.62, 1.92);
    } else if (Array.isArray(opts.quadrants)) {
      const coords = [
        [0.35, 1.80, 6.26, 1.10],
        [6.71, 1.80, 6.26, 1.10],
        [0.35, 3.00, 6.26, 1.10],
        [6.71, 3.00, 6.26, 1.10],
      ];
      // NEW: opts.wideBottom spans the full bottom row (12.62" × 1.10")
      // Used by ITSM Diagnostics for the root-cause × category heatmap which
      // was previously crushed into a 6.26"×0.78" Q3 (cells too small to read).
      const renderQuadrants = opts.wideBottom
        ? [opts.quadrants[0], opts.quadrants[1]]    // skip Q3+Q4 — wideBottom covers them
        : opts.quadrants.slice(0, 4);
      renderQuadrants.forEach((q, i) => {
        if (!q) return;
        const [x, y, w, h] = coords[i];
        // BUG FIX: title h was 0.18 (ends at y+0.18) but subtitle started at
        // y+0.16 — title and subtitle overlapped by 0.02" on every cockpit slide.
        s.addText(q.title || '', {x, y, w, h: 0.16, fontSize: 7.5, fontFace: 'Calibri', color: '1B2A4A', bold: true, valign: 'top'});
        if (q.subtitle) s.addText(q.subtitle, {x, y: y + 0.16, w, h: 0.14, fontSize: 6.5, fontFace: 'Calibri', color: '9B9B9B', valign: 'top'});
        const renderY = q.subtitle ? y + 0.32 : y + 0.18;
        const renderH = h - (q.subtitle ? 0.32 : 0.18);
        try { q.render(s, x, renderY, w, renderH); }
        catch (e) {
          s.addText(`Render error: ${e.message}`, {x, y: renderY, w, h: renderH, fontSize: 8, color: 'C0392B', italic: true, valign: 'middle'});
        }
      });
      if (opts.wideBottom) {
        const wb = opts.wideBottom;
        // Wide-bottom = full-width bottom row, taller than a normal quadrant
        // (1.20" vs 1.10") because heatmaps need vertical space for cell rows.
        const wx = 0.35, wy = 3.00, ww = 12.62, wh = 1.20;
        s.addText(wb.title || '', {x: wx, y: wy, w: ww, h: 0.16, fontSize: 7.5, fontFace: 'Calibri', color: '1B2A4A', bold: true, valign: 'top'});
        if (wb.subtitle) s.addText(wb.subtitle, {x: wx, y: wy + 0.16, w: ww, h: 0.14, fontSize: 6.5, fontFace: 'Calibri', color: '9B9B9B', valign: 'top'});
        const renderY = wb.subtitle ? wy + 0.32 : wy + 0.18;
        const renderH = wh - (wb.subtitle ? 0.32 : 0.18);
        try { wb.render(s, wx, renderY, ww, renderH); }
        catch (e) {
          s.addText(`Render error: ${e.message}`, {x: wx, y: renderY, w: ww, h: renderH, fontSize: 8, color: 'C0392B', italic: true, valign: 'middle'});
        }
      }
    }

    // Detect Hermes-offline state at the slide level: if the deck-wide
    // analysis.hermes object has NO slides[] keys at all, treat per-cockpit
    // missing insight as "API failed this run" (state 2) rather than the
    // dev-facing FALLBACK (state 3). Slides can also pass in their
    // hardcoded fallback strings (the title/soWhat they would have used)
    // to fill the panel meaningfully.
    const hermesGloballyMissing = !this._an?.hermes?.slides || Object.keys(this._an.hermes.slides).length === 0;
    this._drawLLMInsightPanel(s, 0.35, 4.30, 12.62, 2.25, opts.insight, {
      hermesOffline: hermesGloballyMissing && !opts.insight,
      fallbackHeadline: opts.title,
      fallbackBody: opts.soWhat,
      fallbackActions: opts.fallbackActions,
    });
  }

  // LLM Insight Panel — visual treatment for Hermes-generated per-slide content.
  //
  // Three states:
  //   1. POPULATED — Hermes returned content for this slide → render normally
  //   2. HERMES_OFFLINE — Hermes call returned null (API timeout / rate limit /
  //      transient failure). Show a compact "AI commentary unavailable this run"
  //      strip pointing at the slide's deterministic data instead of bloating
  //      half the slide with FALLBACK noise.
  //   3. NEVER_WIRED — slideContext doesn't include this key. Show a developer-
  //      facing FALLBACK panel so the gap stays visible during development.
  //
  // The slide passes `hermesOffline: true` (set by _drawCockpit when it detects
  // analysis.hermes is empty) to differentiate (2) from (3).
  _drawLLMInsightPanel(s, x, y, w, h, insight, opts = {}) {
    const N='1B2A4A', DG='2C2C2C', MG='9B9B9B', LG='E8E8E6', T='0A7EA4', A='E67E22', OW='FAFAF8';
    const hasContent = insight && (insight.headline || insight.body) && !insight._fallback;
    if (hasContent) {
      // STATE 1 — populated: full LLM panel
      s.addShape(this.pptx.ShapeType.rect, {x, y, w, h, fill:{color: OW}, line:{color: LG, width: 0.5}});
      s.addShape(this.pptx.ShapeType.rect, {x, y, w: 0.08, h, fill:{color: T}, line:{type:'none'}});
      s.addText('LLM INSIGHT  ·  HERMES (NVIDIA NIM · Mistral Large)',
        {x: x+0.18, y: y+0.06, w: w-0.30, h: 0.18, fontSize: 7.5, fontFace: 'Calibri', color: T, bold: true});
      s.addText(insight.headline || '',
        {x: x+0.18, y: y+0.28, w: w-0.30, h: 0.36, fontSize: 13, fontFace: 'Calibri', color: N, bold: true, lineSpacing: 16});
      s.addText(insight.body || '',
        {x: x+0.18, y: y+0.70, w: w-0.30, h: 0.96, fontSize: 10.5, fontFace: 'Calibri', color: DG, italic: true, lineSpacing: 14});
      const actions = Array.isArray(insight.actions) ? insight.actions.slice(0, 3) : [];
      if (actions.length > 0) {
        s.addText('RECOMMENDED ACTIONS', {x: x+0.18, y: y+1.70, w: w-0.30, h: 0.16, fontSize: 7.5, fontFace: 'Calibri', color: N, bold: true});
        actions.forEach((a, i) => {
          s.addText(`▸  ${a}`, {x: x+0.22, y: y+1.88 + i*0.16, w: w-0.34, h: 0.16, fontSize: 9, fontFace: 'Calibri', color: DG, lineSpacing: 11});
        });
      }
      return;
    }

    if (opts.hermesOffline) {
      // STATE 2 — Hermes API failed this run: compact one-line strip + use
      // freed space to repeat the slide's deterministic so-what bullets if
      // provided by the caller. Less visually loud than full FALLBACK.
      s.addShape(this.pptx.ShapeType.rect, {x, y, w, h, fill:{color: 'FFF8E7'}, line:{color: A, width: 0.5}});
      s.addShape(this.pptx.ShapeType.rect, {x, y, w: 0.08, h, fill:{color: A}, line:{type:'none'}});
      s.addText('⚠  AI COMMENTARY UNAVAILABLE THIS RUN',
        {x: x+0.18, y: y+0.06, w: w-0.30, h: 0.20, fontSize: 8, fontFace: 'Calibri', color: A, bold: true});
      s.addText(opts.fallbackHeadline || 'Hermes API returned null — slide rendered from deterministic data only. Click Execute again to retry; check NIM connectivity if persistent.',
        {x: x+0.18, y: y+0.28, w: w-0.30, h: 0.50, fontSize: 11, fontFace: 'Calibri', color: N, bold: true, lineSpacing: 14, italic: true});
      // Repeat slide's so-what + KPI summary in the freed space
      const supplementary = opts.fallbackBody || 'See chrome footer for the so-what; KPIs and exhibits above reflect the deterministic data.';
      s.addText(supplementary,
        {x: x+0.18, y: y+0.84, w: w-0.30, h: 0.80, fontSize: 10, fontFace: 'Calibri', color: DG, italic: true, lineSpacing: 13});
      // Action bullets if caller provided fallback ones
      const fbActions = Array.isArray(opts.fallbackActions) ? opts.fallbackActions.slice(0, 3) : [];
      if (fbActions.length > 0) {
        s.addText('NEXT STEPS (deterministic, not AI-generated)',
          {x: x+0.18, y: y+1.68, w: w-0.30, h: 0.16, fontSize: 7.5, fontFace: 'Calibri', color: N, bold: true});
        fbActions.forEach((a, i) => {
          s.addText(`▸  ${a}`, {x: x+0.22, y: y+1.86 + i*0.16, w: w-0.34, h: 0.16, fontSize: 9, fontFace: 'Calibri', color: DG, lineSpacing: 11});
        });
      }
      return;
    }

    // STATE 3 — never wired: developer-facing FALLBACK
    s.addShape(this.pptx.ShapeType.rect, {x, y, w, h, fill:{color: 'F0F0EE'}, line:{color: LG, width: 0.5}});
    s.addShape(this.pptx.ShapeType.rect, {x, y, w: 0.08, h, fill:{color: MG}, line:{type:'none'}});
    s.addText('LLM INSIGHT  ·  FALLBACK CONTENT (Hermes orchestrator not wired for this slide key)',
      {x: x+0.18, y: y+0.06, w: w-0.30, h: 0.18, fontSize: 7.5, fontFace: 'Calibri', color: MG, bold: true, italic: true});
    s.addText('Per-slide LLM headline pending — wire Hermes orchestrator to populate.',
      {x: x+0.18, y: y+0.28, w: w-0.30, h: 0.36, fontSize: 13, fontFace: 'Calibri', color: MG, bold: true, italic: true, lineSpacing: 16});
    s.addText('This slide expects Hermes to populate analysis.hermes.slides[<key>].insight.{headline,body,actions}. Until the orchestrator is wired, this fallback panel surfaces the gap so it gets fixed.',
      {x: x+0.18, y: y+0.70, w: w-0.30, h: 0.96, fontSize: 10.5, fontFace: 'Calibri', color: MG, italic: true, lineSpacing: 14});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // METRICS — computed from existing opsData/sprintData, no new fetches needed
  // ══════════════════════════════════════════════════════════════════════════

  // Sprint Readiness Score (0–100, FORWARD-looking, different from healthScore)
  // Composite of 4 equal-weight components, each itself 0–100:
  //   1. velocityFitness  — closure rate vs intake rate (can we drain the backlog?)
  //   2. prDebtInverse    — 100 - share of PRs stale > 72h
  //   3. backlogFreshness — 100 - share of open items stale > 7d
  //   4. ownerSpread      — 100 - top-3 load share (concentration penalty)
  // Returns { score, verdict, components: {...} }
  _sprintReadinessScore(sprintData, ops) {
    const stats = sprintData?.stats || {};
    const flow  = sprintData?.flow  || {};

    // Component 1: velocity fitness — closed-this-week / max(created-this-week, 1)
    const closedW  = flow.closedThisWeek  || stats.closedThisWeek  || stats.closed || 0;
    const createdW = flow.createdThisWeek || stats.createdThisWeek || 0;
    const velocityFitness = createdW > 0
      ? Math.min(100, Math.round((closedW / createdW) * 100))
      : (closedW > 0 ? 90 : 50);

    // Component 2: PR debt inverse — 100 - stale% of PRs
    const prs = Array.isArray(ops.prs) ? ops.prs : [];
    const stalePrs = prs.filter(p => (p.ageHours || p.daysOpen*24 || 0) > 72).length;
    const prDebtInverse = prs.length === 0 ? 70
      : Math.max(0, Math.round(100 - (stalePrs / prs.length) * 100));

    // Component 3: backlog freshness — 100 - stale% of open ITSM+OEG+Cloud+Incidents
    const open  = (ops.itsmSummary?.open || 0) + (ops.oegSummary?.open || 0)
                + (ops.cloudSummary?.open || 0) + (ops.incidentsSummary?.open || 0);
    const stale = (ops.itsmSummary?.staleOpen || ops.itsmSummary?.stale || 0)
                + (ops.oegSummary?.stale || 0) + (ops.cloudSummary?.stale || 0)
                + (ops.incidentsSummary?.stale || 0);
    const backlogFreshness = open === 0 ? 80
      : Math.max(0, Math.round(100 - (stale / open) * 100));

    // Component 4: owner spread — derived from sprintData.byAssignee
    const flat = {};
    const ba = sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }
    const ownerList = Object.values(flat).filter(p => p && (p.active||p.stale))
      .map(p => ({ active: Number(p.active)||0, stale: Number(p.stale)||0 }))
      .sort((a,b) => (b.active+b.stale*0.5) - (a.active+a.stale*0.5));
    const totalLoad = ownerList.reduce((s,o)=>s+o.active+o.stale*0.5, 0);
    const top3Load  = ownerList.slice(0,3).reduce((s,o)=>s+o.active+o.stale*0.5, 0);
    const top3Share = totalLoad > 0 ? Math.round(top3Load/totalLoad*100) : 0;
    const ownerSpread = Math.max(0, 100 - top3Share);

    const score = Math.round((velocityFitness + prDebtInverse + backlogFreshness + ownerSpread) / 4);
    const verdict = score >= 75 ? 'Ready'
                 : score >= 60 ? 'Watch'
                 : score >= 40 ? 'At Risk' : 'Not Ready';

    return {
      score, verdict,
      components: { velocityFitness, prDebtInverse, backlogFreshness, ownerSpread, top3Share },
    };
  }

  // Burnout Risk Index per owner — composite signal
  // index = active + stale × 0.5 + blocked × 2
  // ≥ 15 = HIGH risk; 8–14 = MEDIUM; <8 = LOW
  _burnoutIndex(owner) {
    const a = Number(owner.active)  || 0;
    const s = Number(owner.stale)   || 0;
    const b = Number(owner.blocked) || 0;
    const index = a + s*0.5 + b*2;
    const tier  = index >= 15 ? 'HIGH' : index >= 8 ? 'MED' : 'LOW';
    return { index: Math.round(index), tier };
  }

  // Top accounts by open volume across ITSM + OEG + Cloud + Incidents
  // Returns array sorted by count desc; each row has source-domain breakdown.
  _topAccountsByOpenVolume(ops, limit = 10) {
    const tally = {};
    const bump = (accountName, domain) => {
      if (!accountName) return;
      if (!tally[accountName]) tally[accountName] = { account: accountName, total: 0, itsm: 0, oeg: 0, cloud: 0, incidents: 0 };
      tally[accountName].total += 1;
      tally[accountName][domain] += 1;
    };
    for (const r of (ops.itsm || []))           if (this._isOpenLike(r.status)) bump(r.accountName, 'itsm');
    for (const r of (ops.oeg || []))            if (this._isOpenLike(r.status)) bump(r.accountName, 'oeg');
    for (const r of (ops.cloud || []))          if (this._isOpenLike(r.status)) bump(r.accountName, 'cloud');
    for (const r of (ops.wsr_incident || []))   if (this._isOpenLike(r.status)) bump(r.accountName, 'incidents');
    return Object.values(tally).sort((a,b) => b.total - a.total).slice(0, limit);
  }
  _isOpenLike(status) {
    return !['closed','resolved','cancelled','done','completed'].includes(String(status||'').toLowerCase());
  }

  // Week-over-Week movers — compares this run's key metrics to the previous run's
  // recorded in analysis.weeklyHistory[1] (history is newest-first).
  _wowMovers(an, ops, sprintData) {
    // BUG FIX: previously only read an.weeklyHistory (Append Trends node's
    // rolling 12-week file). When that's empty (first run after a restart),
    // the slide showed "fewer than 2 runs in history" even though Hermes
    // memory has 41+ prior runs in opsData.hermesLearning.weeklySnapshots.
    // Now: prefer weeklyHistory (more granular, has WoW-specific metrics);
    // fall back to Hermes weeklySnapshots when shallow.
    let hist = Array.isArray(an?.weeklyHistory) ? an.weeklyHistory : [];
    if (hist.length < 2) {
      const snap = Array.isArray(ops?.hermesLearning?.weeklySnapshots)
        ? ops.hermesLearning.weeklySnapshots : [];
      // weeklySnapshots are oldest-first; reverse so [0] = latest, [1] = prev
      if (snap.length >= 2) hist = [...snap].reverse();
    }
    const cur  = hist[0] || {};
    const prev = hist[1] || {};
    if (!prev || Object.keys(prev).length === 0) return [];

    const metrics = [
      { key:'healthScore', label:'Health Score',      now: cur.healthScore ?? sprintData?.stats?.healthScore ?? 0, was: prev.healthScore ?? 0, direction:'higher-better' },
      { key:'velocity',    label:'Velocity',          now: cur.velocity ?? sprintData?.stats?.closed ?? 0,         was: prev.velocity ?? 0,    direction:'higher-better' },
      { key:'itsmOpen',    label:'ITSM Open',         now: cur.itsmOpen ?? ops.itsmSummary?.open ?? 0,             was: prev.itsmOpen ?? 0,    direction:'lower-better' },
      { key:'itsmAging',   label:'ITSM Aging (>7d)',  now: cur.itsmAging ?? ops.itsmSummary?.staleOpen ?? 0,       was: prev.itsmAging ?? 0,   direction:'lower-better' },
      { key:'mprOpen',     label:'MPR Open',          now: cur.mprOpen ?? 0,                                        was: prev.mprOpen ?? 0,     direction:'lower-better' },
      { key:'blockers',    label:'Active Blockers',   now: (sprintData?.stats?.blockedItems||[]).length,            was: prev.blockers ?? 0,    direction:'lower-better' },
    ];
    return metrics.map(m => {
      const delta = m.now - m.was;
      const deltaPct = m.was > 0 ? Math.round((delta / m.was) * 100) : (m.now > 0 ? 100 : 0);
      const isImprovement = m.direction === 'higher-better' ? delta > 0 : delta < 0;
      return { ...m, delta, deltaPct, isImprovement };
    }).filter(m => Math.abs(m.deltaPct) >= 1)
      .sort((a,b) => Math.abs(b.deltaPct) - Math.abs(a.deltaPct))
      .slice(0, 5);
  }

  // Build line-chart series from a trending array (open counts over weeks)
  // Returns [{name, labels, values}] suitable for pptxgenjs addChart
  _trendSeries(arr, name) {
    if(!Array.isArray(arr)||arr.length<2) return null;
    const MO=['May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr'];
    const labels=arr.map((_,i)=>MO[i%MO.length]);
    return [{name:name||'Open',labels,values:arr.map(v=>Number(v)||0)}];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 3 — Delivery & Sprint
  // ══════════════════════════════════════════════════════════════════════════
  _slideDeliveryAndSprint(sprintData, an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const st=sprintData?.stats||{};
    // BUG FIX: stats.total is sometimes a stale/upstream count that
    // contradicts the breakdown (observed: total=2 with active=25, blocked=24).
    // Derive total from the breakdown components and use whichever is larger
    // — this ensures the headline math always adds up.
    const done=st.done||st.closed||0;
    const inP=st.inProgress||st.active||0;
    const blk=st.blockers||(st.blockedItems||[]).length||0;
    const declaredTotal=st.total||0;
    const breakdownSum=done+inP+blk;
    const total=Math.max(declaredTotal, breakdownSum);   // never less than what the bars show
    const todo=Math.max(0,total-done-inP-blk);
    const pct=total>0?Math.round(done/total*100):0;
    const vel=st.velocity||done||0;
    const hs=st.healthScore||0;
    this._validateSlideMath('Delivery & Sprint', { total, done, inP, blk, todo, declaredTotal, breakdownSum });

    const soWhat=this._an?.hermes?.slides?.delivery?.soWhat||
      (blk>0?`${blk} blocker(s) must be unblocked immediately — each day increases the probability of missing the sprint commitment.`
        :`Sprint is ${pct}% complete — maintain ${vel} item/week velocity to close remaining ${todo+inP} items on time.`);
    const title=this._an?.hermes?.slides?.delivery?.headline||
      (blk>0?`${blk} active blocker(s) threatening ${pct}% sprint at risk — immediate owner escalation required`
        :pct>=70?`Sprint on track at ${pct}% — ${done} items delivered, ${todo+inP} remaining to plan`
        :`Sprint pace at ${pct}% requires acceleration — ${todo+inP} items outstanding with velocity at ${vel}/sprint`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Delivery & Sprint');
    this._kpiStrip(s,[
      {value:total,    label:'Total Items',  color:N},
      {value:done,     label:'Done',         color:G},
      {value:inP,      label:'In Progress',  color:T},
      {value:todo,     label:'To Do',        color:MG},
      {value:blk,      label:'Blocked',      color:R},
      {value:`${pct}%`,label:'Completion',   color:pct>=70?G:pct>=40?A:R},
    ]);

    // ── LEFT: Completion proportion bar + state breakdown ────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'SPRINT COMPLETION BREAKDOWN',`${total} total items · ${this._wl()}`);
    this._stackedBar(s,0.35,2.22,6.10,0.44,[
      {label:'Done',        count:done, color:G},
      {label:'In Progress', count:inP,  color:T},
      {label:'To Do',       count:todo, color:LG},
      {label:'Blocked',     count:blk,  color:R},
    ]);
    const stRows=[
      {label:'Done',        value:done, color:G},
      {label:'In Progress', value:inP,  color:T},
      {label:'To Do',       value:todo, color:MG},
      {label:'Blocked',     value:blk,  color:R},
    ].filter(r=>r.value>0);
    if(stRows.length>0){
      const mx=Math.max(...stRows.map(r=>r.value),1);
      this._hBar(s,0.35,3.10,6.10,stRows,mx,null,(i)=>stRows[i].color);
    }

    // ── RIGHT: Sprint health indicators ─────────────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'SPRINT HEALTH INDICATORS','Delivery quality metrics this sprint');
    const rc=hs>=70?G:hs>=40?A:R;
    s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:2.22,w:2.10,h:0.46,fill:{color:rc}});
    s.addText(hs>=70?'GREEN':hs>=40?'AMBER':'RED',{x:6.70,y:2.22,w:2.10,h:0.46,fontSize:14,fontFace:'Calibri',color:'FFFFFF',bold:true,align:'center',valign:'middle'});
    s.addText(`Health Score: ${hs}/100`,{x:8.90,y:2.28,w:4.00,h:0.36,fontSize:10,fontFace:'Calibri',color:DG,bold:true,valign:'middle'});
    [{label:'Velocity (items this sprint)',value:vel,color:vel>=20?G:A},
     {label:'Completion rate',value:`${pct}%`,color:pct>=70?G:pct>=40?A:R},
     {label:'Items remaining',value:todo+inP,color:(todo+inP)>10?A:G},
     {label:'Active blockers',value:blk,color:blk>0?R:G},
    ].forEach((m,i)=>{
      const my=2.84+i*0.29;
      s.addText(m.label,{x:6.70,y:my,w:4.30,h:0.26,fontSize:8,fontFace:'Calibri',color:DG});
      s.addText(String(m.value),{x:11.00,y:my,w:1.90,h:0.26,fontSize:9,fontFace:'Calibri',color:m.color,bold:true,align:'right'});
      s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:my+0.25,w:6.20,h:0.01,fill:{color:LG},line:{type:'none'}});
    });
    if(blk>0){
      this._calloutBox(s,6.70,4.06,6.20,0.48,`⚠  ${blk} blocker(s) unresolved — assign named owners and resolve before next stand-up`,'C0392B');
    } else if(pct>=80){
      this._calloutBox(s,6.70,4.06,6.20,0.48,`✓  Sprint at ${pct}% with ${todo+inP} remaining — close all open items to finish strong`,'27AE60');
    } else {
      this._calloutBox(s,6.70,4.06,6.20,0.48,`Sprint requires ${vel>=Math.ceil((todo+inP)/2)?'sustained':'increased'} velocity — target: close ${Math.ceil((todo+inP)/2)} items by mid-sprint`,'E67E22');
    }

    // ── BOTTOM: Item distribution bar chart (always renders) ─────────────
    this._bottomHead(s,'SPRINT STATE DISTRIBUTION — ITEMS BY STATUS THIS SPRINT');
    // Render as horizontal grouped (not stacked) bars so each status gets its
    // own row at full chart width; this avoids collapsing tiny segments
    // (e.g. 24 blockers vs 17,281 to-do) into illegible overlapping labels.
    // BUG FIX: was log-scale (1/10/100 CUSTOMER_REDACTED crushed small bars). Linear
    // CUSTOMER_REDACTED with explicit max gives clean visual; tiny bars get a value
    // label rendered alongside via showValue:true.
    const stateMax=Math.max(done, inP, todo, blk, 1);
    s.addChart(this.pptx.ChartType.bar,[
      {name:'Count',
        labels:['Done','In Progress','To Do','Blocked'],
        values:[done, inP, todo, blk]},
    ],{
      x:0.35,y:4.28,w:12.62,h:2.28,
      barDir:'bar',barGrouping:'clustered',
      chartColors:[T],
      showLegend:false,
      showTitle:false,showValue:true,dataLabelFontSize:10,
      catAxisLabelFontSize:10,valAxisLabelFontSize:8,
      valAxisMinVal:0, valAxisMaxVal:Math.ceil(stateMax * 1.1),
      plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 4 — Pipelines & PRs
  // ══════════════════════════════════════════════════════════════════════════
  _slidePipelinesAndPRs(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const pl=Array.isArray(ops.pipelines)
      ?{total:ops.pipelines.length,passing:ops.pipelines.filter(p=>(p.lastStatus||p.result||'').toLowerCase()==='succeeded').length}
      :(ops.pipelines||{total:0,passing:0});
    const plTotal=pl.total||0;
    const plPass=pl.passing||0;
    const plFail=Math.max(0,plTotal-plPass);
    const plPct=Math.round((plPass/Math.max(plTotal,1))*100);
    const prs=Array.isArray(ops.prs)?ops.prs:[];
    const openPRs=prs.filter(p=>p.status==='active'||p.status==='open');
    const stalePRs=prs.filter(p=>(p.ageHours||p.daysOpen*24||0)>72);
    const mergedPRs=prs.filter(p=>p.status==='merged'||p.state==='merged');

    const soWhat=this._an?.hermes?.slides?.pipelines?.soWhat||
      (plFail>0?`${plFail} pipeline(s) failing — root-cause and restore green build before merging additional work to protect deployment frequency.`
        :stalePRs.length>0?`${stalePRs.length} PR(s) stale (>72h) — review, merge, or close to reduce merge debt and unblock downstream deployments.`
        :`CI/CD healthy at ${plPct}% passing — maintain review cadence to sustain deployment frequency.`);
    const title=this._an?.hermes?.slides?.pipelines?.headline||
      (plFail>0?`${plFail} pipeline failure(s) blocking deployment — restore green build to protect sprint delivery`
        :stalePRs.length>0?`${stalePRs.length} stale PR(s) creating merge debt — review and close before end of sprint`
        :`CI/CD healthy at ${plPct}% passing — ${openPRs.length} PRs active, deployment cadence maintained`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Pipelines & PRs');
    this._kpiStrip(s,[
      {value:plTotal,         label:'Pipelines',      color:N},
      {value:plPass,          label:'Passing',        color:G},
      {value:plFail,          label:'Failed',         color:R},
      {value:prs.length,      label:'Total PRs',      color:T},
      {value:openPRs.length,  label:'Open PRs',       color:A},
      {value:stalePRs.length, label:'Stale PRs (>72h)',color:R},
    ]);

    // ── LEFT: Pipeline success big number + proportion bar ───────────────
    this._exhibitHead(s,0.35,1.80,6.10,'PIPELINE SUCCESS RATE',`${plTotal} pipelines · ${this._wl()}`);
    const pctColor=plPct>=90?G:plPct>=70?A:R;
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:2.22,w:6.10,h:0.95,fill:{color:'F7F7F5'},line:{type:'none'}});
    s.addText(`${plPct}%`,{x:0.35,y:2.22,w:2.80,h:0.95,fontSize:52,fontFace:'Calibri',color:pctColor,bold:true,align:'center',valign:'middle'});
    s.addText(`${plPass} of ${plTotal} pipelines passing`,{x:3.20,y:2.40,w:3.20,h:0.30,fontSize:9,fontFace:'Calibri',color:DG});
    if(plFail>0){
      s.addText(`⚠  ${plFail} pipeline(s) failing`,{x:3.20,y:2.74,w:3.20,h:0.26,fontSize:8.5,fontFace:'Calibri',color:R,bold:true});
    } else {
      s.addText(`✓  All pipelines green`,{x:3.20,y:2.74,w:3.20,h:0.26,fontSize:8.5,fontFace:'Calibri',color:G,bold:true});
    }
    // Pass/Fail proportion bar
    this._stackedBar(s,0.35,3.34,6.10,0.40,[
      {label:'Passing',count:plPass,color:G},
      {label:'Failing',count:plFail,color:R},
    ]);
    if(plFail>0){
      this._calloutBox(s,0.35,4.06,6.10,0.48,`⚠  ${plFail} failure(s) — investigate root causes and restore green before next merge`,'C0392B');
    }

    // ── RIGHT: PR aging distribution ─────────────────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'PR AGING DISTRIBUTION',`${prs.length} PRs · ${openPRs.length} open`);
    const lt24=prs.filter(p=>(p.ageHours||p.daysOpen*24||0)<24).length;
    const bt=prs.filter(p=>{const h=p.ageHours||p.daysOpen*24||0;return h>=24&&h<=72;}).length;
    const gt72=stalePRs.length;
    this._stackedBar(s,6.70,2.22,6.20,0.44,[
      {label:'<24h',  count:lt24, color:G},
      {label:'24–72h',count:bt,   color:A},
      {label:'>72h',  count:gt72, color:R},
    ]);
    // Top PRs by age
    const ageBuckets=[
      {label:'< 24 hours',   value:lt24, color:G},
      {label:'24 – 72 hours',value:bt,   color:A},
      {label:'> 72 hours (stale)',value:gt72,color:R},
    ].filter(r=>r.value>0);
    if(ageBuckets.length>0){
      const mx=Math.max(...ageBuckets.map(r=>r.value),1);
      this._hBar(s,6.70,3.10,6.20,ageBuckets,mx,null,(i)=>ageBuckets[i].color);
    }
    if(gt72>0){
      this._calloutBox(s,6.70,4.06,6.20,0.48,`⚠  ${gt72} stale PR(s) blocking merge — review and close to reduce integration debt`,'C0392B');
    }

    // ── BOTTOM: Pipeline + PR summary chart ──────────────────────────────
    this._bottomHead(s,'PIPELINE HEALTH & PR STATUS SUMMARY');
    s.addChart(this.pptx.ChartType.bar,[
      {name:'Passing',       labels:['Pipelines','PRs'],values:[plPass,  mergedPRs.length]},
      {name:'Failing / Stale',labels:['Pipelines','PRs'],values:[plFail, stalePRs.length]},
      {name:'Pending / Open', labels:['Pipelines','PRs'],values:[0,      openPRs.length]},
    ],{
      x:0.35,y:4.28,w:12.62,h:2.28,
      barDir:'col',barGrouping:'clustered',
      chartColors:[G,R,A],
      showLegend:true,legendPos:'r',legendFontSize:9,
      showTitle:false,showValue:true,dataLabelFontSize:10,
      catAxisLabelFontSize:10,valAxisLabelFontSize:8,
      plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 5 — ITSM Analytics  (closest to approved sample)
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSM(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const ism=ops.itsmSummary||{};
    const total=ism.total||0;
    const open=ism.open||0;
    const closed=ism.closed||0;
    const stale=ism.staleOpen||0;
    const avgDur=ism.avgDurationDays?`${Number(ism.avgDurationDays).toFixed(1)}d`:'—';

    // Derive status distribution bars from available data
    const byStatus=ism.byStatus||{};
    const byPriority=ism.byPriority||{};
    const statusBars=Object.entries(byStatus).length>0
      ?Object.entries(byStatus).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>({label:k,value:v}))
      :Object.entries(byPriority).length>0
        ?Object.entries(byPriority).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>({label:k,value:v}))
        :[{label:'Closed',value:closed},{label:'Open',value:open},{label:'Stale (>7d)',value:stale}]
          .filter(r=>r.value>0);

    // Derive aging segments
    const agBrackets=Array.isArray(ops.itsmAgingBrackets)?ops.itsmAgingBrackets:[];
    const agingSegs=agBrackets.length>0
      ?agBrackets.map((b,i)=>({label:b.bracket||`Bracket ${i+1}`,count:b.count||0,color:[G,T,A,R,R,N][i]||MG}))
      :[
        {label:'0–7 days',   count:Math.max(0,open-stale),  color:G},
        {label:'8–30 days',  count:Math.round(stale*0.50),  color:T},
        {label:'31–90 days', count:Math.round(stale*0.30),  color:A},
        {label:'91–300 days',count:Math.round(stale*0.15),  color:R},
        {label:'300+ days',  count:Math.round(stale*0.05),  color:N},
      ].filter(sg=>sg.count>0);

    const stale300=agBrackets.find(b=>(b.bracket||'').includes('300'))?.count||Math.round(stale*0.05)||0;

    // Trend — use itsmSummary.trending12w or ops.itsmTrend
    const rawTrend=Array.isArray(ism.trending12w)?ism.trending12w
      :Array.isArray(ops.itsmTrend)?ops.itsmTrend.map(t=>t.open||t.created||0):[];

    const soWhat=this._an?.hermes?.slides?.itsm?.soWhat||
      (stale>20?`${stale} stale cases require immediate triage — resolution velocity must increase to prevent further queue growth.`
        :open>0?`ITSM queue has ${open} open cases with ${avgDur} average resolution — monitor aging to prevent SLA breaches.`
        :`ITSM backlog healthy with ${closed} cases resolved this period.`);
    const title=this._an?.hermes?.slides?.itsm?.headline||
      (stale300>0?`ITSM backlog aging has accelerated — ${stale300} cases are 300+ days old, requiring immediate escalation`
        :stale>0?`ITSM queue has ${stale} stale cases exceeding SLA threshold — triage sprint required to restore compliance`
        :`ITSM operations stable — ${closed.toLocaleString()} cases resolved with ${avgDur} average resolution time`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'ITSM Analytics');
    this._kpiStrip(s,[
      {value:total.toLocaleString(),label:'Total Cases',   color:N},
      {value:open,                   label:'Open',         color:A},
      {value:closed.toLocaleString(),label:'Closed',       color:G},
      {value:stale,                  label:'Stale (>7d)',  color:R},
      {value:stale300,               label:'300+ Day Cases',color:R},
      {value:avgDur,                 label:'Avg Resolution',color:T},
    ]);

    // ── LEFT: Status distribution (manual bars, approved-sample style) ───
    this._exhibitHead(s,0.35,1.80,6.10,'STATUS CODE DISTRIBUTION',
      `${statusBars.length} status groups · ${total.toLocaleString()} cases`);
    const maxStatus=Math.max(...statusBars.map(b=>b.value),1);
    this._hBar(s,0.35,2.18,6.10,statusBars,maxStatus,null,
      (i)=>i===0?N:i<=2?T:MG);

    // ── RIGHT: Case aging stacked proportion bar ──────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'CASE AGING ANALYSIS',
      `Open cases by age bracket · ${open} open`);
    this._stackedBar(s,6.70,2.20,6.20,0.44,agingSegs);
    if(stale300>0){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `⚠  ${stale300} cases have exceeded 300 days — ${Math.round(stale300/Math.max(stale,1)*100)}% of stale queue is critically aged. Immediate triage required.`,
        'C0392B');
    } else if(stale>0){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `${stale} stale cases (>${avgDur} avg) require closure review — resolution velocity must close gap before next reporting cycle`,
        'E67E22');
    }

    // ── BOTTOM: 12-month open cases trend ────────────────────────────────
    this._bottomHead(s,'ITSM OPEN CASES TREND — 12 MONTHS');
    const trendSeries=this._trendSeries(rawTrend,'Open Cases');
    if(trendSeries){
      s.addChart(this.pptx.ChartType.line,trendSeries,{
        x:0.35,y:4.28,w:12.62,h:2.28,
        chartColors:[N],lineDataSymbol:'none',lineSmooth:true,
        showLegend:true,legendPos:'r',legendFontSize:8,
        showTitle:false,valAxisMinVal:0,
        catAxisLabelFontSize:7.5,valAxisLabelFontSize:7.5,dataLabelFontSize:0,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
        serGridLine:[{style:'dot',color:LG}],
      });
      // Annotation on last point if open cases rising
      const last=rawTrend[rawTrend.length-1]||0;
      const prev=rawTrend[rawTrend.length-2]||0;
      if(last>prev){
        this._calloutBox(s,10.60,4.60,2.34,0.46,
          `Now: ${last} open\n↑ from ${prev} last month`,'C0392B');
      }
    } else {
      s.addChart(this.pptx.ChartType.bar,[
        {name:'Closed',  labels:['ITSM'],values:[closed]},
        {name:'Open',    labels:['ITSM'],values:[open]},
        {name:'Stale',   labels:['ITSM'],values:[stale]},
      ],{
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'col',barGrouping:'clustered',
        chartColors:[G,A,R],
        showLegend:true,legendPos:'r',legendFontSize:9,
        showTitle:false,showValue:true,dataLabelFontSize:11,
        catAxisLabelFontSize:9,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 6 — OEG Operations
  // ══════════════════════════════════════════════════════════════════════════
  _slideOEG(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const oeg=ops.oegSummary||{};
    const total=oeg.total||0;
    const open=oeg.open||0;
    const closed=oeg.closed||0;
    const stale=oeg.stale||0;
    const overdue=oeg.overdue||0;
    const accts=oeg.accounts||0;
    const stalePct=open>0?Math.round(stale/total*100):0;

    const byStatus=oeg.byStatus||{};
    const statusBars=Object.entries(byStatus).length>0
      ?Object.entries(byStatus).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>({label:k,value:v}))
      :[
        {label:'Closed',  value:closed},
        {label:'Open',    value:open},
        {label:'Stale',   value:stale},
        {label:'Overdue', value:overdue},
      ].filter(r=>r.value>0);

    const rawTrend=Array.isArray(oeg.trending12w)?oeg.trending12w
      :Array.isArray(ops.oegTrend)?ops.oegTrend.map(t=>t.open||0):[];

    const soWhat=this._an?.hermes?.slides?.oeg?.soWhat||
      (stalePct>50?`${stalePct}% of total OEG volume is stale — process debt risk. Initiate bulk closure review with account owners immediately.`
        :overdue>0?`${overdue} overdue OEG items require escalation to ${accts} account owners before next cycle.`
        :`OEG operations within norms — sustain closure rate to prevent backlog growth.`);
    const title=this._an?.hermes?.slides?.oeg?.headline||
      (stalePct>50?`OEG stale backlog at ${stalePct}% of total — ${stale.toLocaleString()} items need closure review to reduce process debt`
        :overdue>0?`${overdue} overdue OEG items across ${accts} accounts require escalation before next reporting cycle`
        :`OEG operations stable — ${closed.toLocaleString()} closed, ${open} open across ${accts} accounts`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'OEG Operations');
    this._kpiStrip(s,[
      {value:total.toLocaleString(), label:'Total Items',color:N},
      {value:open,                   label:'Open',       color:A},
      {value:closed.toLocaleString(),label:'Closed',     color:G},
      {value:stale,                  label:'Stale',      color:R},
      {value:overdue,                label:'Overdue',    color:R},
      {value:accts,                  label:'Accounts',   color:T},
    ]);

    // ── LEFT: Status distribution bars ───────────────────────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'OEG STATUS DISTRIBUTION',
      `${statusBars.length} status groups · ${total.toLocaleString()} items`);
    const maxSt=Math.max(...statusBars.map(b=>b.value),1);
    this._hBar(s,0.35,2.18,6.10,statusBars,maxSt,null,(i)=>i===0?N:i<=2?T:MG);

    // ── RIGHT: Open/Closed/Stale proportion bar ───────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'OPEN CASE COMPOSITION',
      `By resolution status · ${total.toLocaleString()} total`);
    this._stackedBar(s,6.70,2.20,6.20,0.44,[
      {label:'Closed',  count:closed,  color:G},
      {label:'Open',    count:open,    color:A},
      {label:'Stale',   count:stale,   color:R},
      {label:'Overdue', count:overdue, color:N},
    ].filter(sg=>sg.count>0));
    if(stalePct>50){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `⚠  ${stalePct}% stale ratio (${stale.toLocaleString()} items) — well above 20% healthy threshold. Bulk closure review required.`,
        'C0392B');
    } else if(overdue>0){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `${overdue} overdue items risk SLA breach — account owners must confirm action plan within 48 hours`,
        'E67E22');
    }

    // ── BOTTOM: OEG trend ─────────────────────────────────────────────────
    this._bottomHead(s,'OEG OPEN ITEMS TREND — 12 MONTHS');
    const tSeries=this._trendSeries(rawTrend,'Open Items');
    if(tSeries){
      s.addChart(this.pptx.ChartType.line,tSeries,{
        x:0.35,y:4.28,w:12.62,h:2.28,
        chartColors:[A],lineDataSymbol:'none',lineSmooth:true,
        showLegend:true,legendPos:'r',legendFontSize:8,
        showTitle:false,valAxisMinVal:0,
        catAxisLabelFontSize:7.5,valAxisLabelFontSize:7.5,dataLabelFontSize:0,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
        serGridLine:[{style:'dot',color:LG}],
      });
    } else {
      s.addChart(this.pptx.ChartType.bar,[
        {name:'Closed',  labels:['OEG'],values:[closed]},
        {name:'Open',    labels:['OEG'],values:[open]},
        {name:'Stale',   labels:['OEG'],values:[stale]},
        {name:'Overdue', labels:['OEG'],values:[overdue]},
      ],{
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'col',barGrouping:'clustered',
        chartColors:[G,A,R,N],
        showLegend:true,legendPos:'r',legendFontSize:9,
        showTitle:false,showValue:true,dataLabelFontSize:11,
        catAxisLabelFontSize:9,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 7 — Cloud & Infrastructure
  // ══════════════════════════════════════════════════════════════════════════
  _slideCloud(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const cl=ops.cloudSummary||{};
    const total=cl.total||0;
    const open=cl.open||0;
    const closed=cl.closed||0;
    const stale=cl.stale||0;
    const overdue=cl.overdue||0;
    const accts=cl.accounts||0;
    const prov=cl.provisioned||0;
    const failed=cl.failed||0;
    const pending=cl.pending||0;
    const provPct=prov+failed>0?Math.round(prov/(prov+failed)*100):0;

    const rawTrend=Array.isArray(cl.trending12w)?cl.trending12w
      :Array.isArray(ops.cloudTrend)?ops.cloudTrend.map(t=>t.open||0):[];

    // Detect: did the upstream provide breakdown data, or only a raw count?
    // If we have total > 0 but provisioned/failed/pending all zero, the
    // outcome breakdown is missing — never claim "healthy" in that case.
    const hasBreakdown = (prov + failed + pending) > 0;
    const soWhat=this._an?.hermes?.slides?.cloud?.soWhat||
      (!hasBreakdown && total>0
        ? `Cloud queue shows ${total} request(s) but provisioning outcome data is missing from the source — verify upstream feed before drawing conclusions.`
        :failed>0?`${failed} failed provision(s) require root-cause — review automation pipeline and escalate if recurring pattern.`
        :pending>10?`${pending} requests pending — prioritise those blocking sprint deliverables to maintain deployment velocity.`
        :`Cloud provisioning operating normally — maintain current approval SLA to support sprint commitments.`);
    const title=this._an?.hermes?.slides?.cloud?.headline||
      (!hasBreakdown && total>0
        ? `Cloud queue: ${total} request(s) tracked · ${open} open — provisioning outcome data not populated by source`
        :total===0
        ? `Cloud data unavailable this period — no requests in opsData.cloud`
        :failed>0?`Cloud provisioning at ${provPct}% success — ${failed} failure(s) require root-cause before month-end capacity lock`
        :pending>10?`${pending} cloud request(s) pending — prioritise sprint-blocking provisions to protect delivery timelines`
        :`Cloud infrastructure healthy — ${prov} provisioned this period, ${accts} active accounts`);
    this._validateSlideMath('Cloud & Infrastructure', { total, open, prov, failed, pending, accts });

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Cloud & Infrastructure');
    this._kpiStrip(s,[
      {value:total,    label:'Total Requests', color:N},
      {value:prov,     label:'Provisioned',    color:G},
      {value:failed,   label:'Failed',         color:R},
      {value:pending,  label:'Pending',        color:A},
      {value:`${provPct}%`,label:'Success Rate',color:provPct>=90?G:provPct>=70?A:R},
      {value:accts,    label:'Accounts',       color:T},
    ]);

    // ── LEFT: Provision outcome bars ──────────────────────────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'PROVISION OUTCOME DISTRIBUTION',
      `Requests by outcome · ${total} total`);
    const outcomeRows=[
      {label:'Provisioned',value:prov,   color:G},
      {label:'Failed',     value:failed, color:R},
      {label:'Pending',    value:pending,color:A},
      {label:'Open (all)', value:open,   color:T},
      {label:'Stale',      value:stale,  color:MG},
    ].filter(r=>r.value>0);
    const maxOC=Math.max(...outcomeRows.map(r=>r.value),1);
    this._hBar(s,0.35,2.18,6.10,outcomeRows,maxOC,null,(i)=>outcomeRows[i].color);
    if(failed>0){
      this._calloutBox(s,0.35,4.06,6.10,0.48,
        `⚠  ${failed} provision failure(s) — investigate automation pipeline to prevent further capacity shortfalls`,
        'C0392B');
    }

    // ── RIGHT: Open/Closed/Stale proportion ───────────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'REQUEST STATUS COMPOSITION',
      `By current status · ${total} total`);
    this._stackedBar(s,6.70,2.20,6.20,0.44,[
      {label:'Closed', count:closed,  color:G},
      {label:'Pending',count:pending, color:A},
      {label:'Open',   count:Math.max(0,open-pending-failed),color:T},
      {label:'Stale',  count:stale,   color:R},
      {label:'Failed', count:failed,  color:N},
    ].filter(sg=>sg.count>0));
    const stalePct=total>0?Math.round(stale/total*100):0;
    if(stalePct>30){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `${stalePct}% of cloud requests are stale (${stale.toLocaleString()} items) — stale queue exceeds 30% threshold; audit required`,
        'E67E22');
    } else if(overdue>0){
      this._calloutBox(s,6.70,3.22,6.20,0.58,
        `${overdue} overdue requests risk capacity SLA breach — review with ${accts} account owners before month-end`,
        'E67E22');
    }

    // ── BOTTOM: Cloud provisioning trend ──────────────────────────────────
    this._bottomHead(s,'CLOUD PROVISIONING VOLUME TREND — 12 MONTHS');
    const tSeries=this._trendSeries(rawTrend,'Open Requests');
    if(tSeries){
      s.addChart(this.pptx.ChartType.line,tSeries,{
        x:0.35,y:4.28,w:12.62,h:2.28,
        chartColors:[T],lineDataSymbol:'none',lineSmooth:true,
        showLegend:true,legendPos:'r',legendFontSize:8,
        showTitle:false,valAxisMinVal:0,
        catAxisLabelFontSize:7.5,valAxisLabelFontSize:7.5,dataLabelFontSize:0,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
        serGridLine:[{style:'dot',color:LG}],
      });
    } else {
      s.addChart(this.pptx.ChartType.bar,[
        {name:'Provisioned',labels:['Cloud'],values:[prov]},
        {name:'Failed',     labels:['Cloud'],values:[failed]},
        {name:'Pending',    labels:['Cloud'],values:[pending]},
        {name:'Stale',      labels:['Cloud'],values:[stale]},
      ],{
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'col',barGrouping:'clustered',
        chartColors:[G,R,A,MG],
        showLegend:true,legendPos:'r',legendFontSize:9,
        showTitle:false,showValue:true,dataLabelFontSize:11,
        catAxisLabelFontSize:9,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 8 — Headcount & Capacity
  // ══════════════════════════════════════════════════════════════════════════
  _slideHeadcount(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const hc=ops.headcountSummary||{};
    // PS-driven reconciliation fields (may be 0 when PeopleStrong data is not on Neocities)
    const psActive=hc.psActive||0;
    const matched=hc.fullyMatched||0;
    const diffs=hc.bucketDiffs||0;
    const exceptions=hc.personExceptions||0;
    const byBand=hc.byBand||{};
    const reconPct=psActive>0?Math.round(matched/psActive*100):0;
    // Intel-side aggregates: always available from BIZTECH headcount-data.json
    const userBuckets   = ops.headcount  || [];
    const empBuckets    = ops.headcount2 || [];
    const uBuckets      = hc.userIntelBuckets     || userBuckets.length;
    const eBuckets      = hc.employeeIntelBuckets || empBuckets.length;
    const userTotal     = ops.headcountUserTotal || userBuckets.reduce((s,b)=>s+(b.count||0),0);
    const empTotal      = ops.headcountEmpTotal  || empBuckets.reduce((s,b)=>s+(b.count||0),0);
    const PS_AVAILABLE  = psActive>0 || matched>0 || diffs>0;

    // Derive band/group rollups directly from the intel buckets so the slide
    // always paints meaningful exhibits — even when PS reconciliation is offline.
    const bandRoll  = {};
    const groupRoll = {};
    for(const b of userBuckets){
      const bk=b.band||'—';   bandRoll[bk]  = (bandRoll[bk]||0)+(b.count||0);
      const gk=b.group||'—';  groupRoll[gk] = (groupRoll[gk]||0)+(b.count||0);
    }
    const bandRowsAuto  = Object.entries(bandRoll).sort((a,b)=>b[1]-a[1]).map(([k,v])=>({label:k,value:v}));
    // De-duplicate group labels that would truncate to the same prefix at the
    // _hBar 24-char limit (e.g. "Delivery Services Group (DSG)" and
    // "Delivery Services Group (ESG)" both render as "Delivery Services Grou…").
    // Append a distinguishing suffix from the first non-matching token.
    const groupRowsRaw  = Object.entries(groupRoll).sort((a,b)=>b[1]-a[1]).slice(0,6);
    const seenPrefix = new Map();
    const groupRowsAuto = groupRowsRaw.map(([k,v]) => {
      const prefix = k.length > 24 ? k.slice(0, 22) : k;
      const dupCount = (seenPrefix.get(prefix) || 0) + 1;
      seenPrefix.set(prefix, dupCount);
      // If this prefix has been seen before, extract a discriminator (parenthesised tag if any, else the last 6 chars)
      let label = k;
      if (dupCount > 1) {
        const tagMatch = k.match(/\(([^)]+)\)\s*$/);
        const discrim = tagMatch ? tagMatch[1] : k.slice(-8);
        label = (prefix.slice(0, 16) + '…' + discrim).slice(0, 24);
      }
      return { label, value: v };
    });
    // Top 3 groups for "concentration" KPI
    const top3GroupsPct = userTotal>0 ? Math.round(groupRowsAuto.slice(0,3).reduce((s,r)=>s+r.value,0)/userTotal*100) : 0;

    const rawTrend=Array.isArray(hc.trending12w)?hc.trending12w
      :Array.isArray(ops.headcountTrend)?ops.headcountTrend.map(t=>t.active||0):[];

    const soWhat=this._an?.hermes?.slides?.headcount?.soWhat||
      (PS_AVAILABLE && diffs>50
        ?`${diffs} headcount mismatches must be resolved with HR before next payroll cycle to prevent system discrepancies.`
        :PS_AVAILABLE && exceptions>50
        ?`${exceptions} person-level exceptions require owner review — each unresolved exception delays reconciliation close.`
        :PS_AVAILABLE
        ?`Headcount reconciliation within tolerance — sustain monthly hygiene process to maintain data accuracy.`
        :`Workforce composition is stable at ${userTotal.toLocaleString()} active users — top ${groupRowsAuto.slice(0,3).length} groups account for ${top3GroupsPct}% of headcount; deepen capacity planning by band.`);
    const title=this._an?.hermes?.slides?.headcount?.headline||
      (PS_AVAILABLE && diffs>50
        ?`${diffs} headcount bucket mismatches flagged — reconcile with HR before payroll cycle to prevent discrepancies`
        :PS_AVAILABLE && exceptions>50
        ?`${exceptions} person-level exceptions require immediate review — impacting ${Math.round(exceptions/Math.max(psActive,1)*100)}% of active headcount`
        :PS_AVAILABLE
        ?`Headcount reconciliation at ${reconPct}% match rate — ${matched} of ${psActive} active employees fully reconciled`
        :`${userTotal.toLocaleString()} active users across ${uBuckets} band/group buckets — top 3 groups concentrate ${top3GroupsPct}% of capacity`);

    const bandRows = (Object.keys(byBand).length>0)
      ? Object.entries(byBand).sort((a,b)=>b[1]-a[1]).map(([k,v])=>({label:k,value:v}))
      : bandRowsAuto;

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Headcount & Capacity');
    // KPI strip: when PS is online show reconciliation; otherwise show workforce composition
    if(PS_AVAILABLE){
      this._kpiStrip(s,[
        {value:psActive,    label:'PS Active',      color:N},
        {value:uBuckets,    label:'User Intel Bkts', color:T},
        {value:eBuckets,    label:'Emp Intel Bkts',  color:T},
        {value:matched,     label:'Fully Matched',   color:G},
        {value:diffs,       label:'Bucket Diffs',    color:diffs>0?R:G},
        {value:exceptions,  label:'Exceptions',      color:exceptions>0?A:G},
      ]);
    } else {
      this._kpiStrip(s,[
        {value:userTotal.toLocaleString(),   label:'Active Users',      color:N},
        {value:empTotal.toLocaleString(),    label:'Employee Records',  color:T},
        {value:Object.keys(bandRoll).length, label:'Bands',             color:T},
        {value:Object.keys(groupRoll).length,label:'Groups',            color:T},
        {value:`${top3GroupsPct}%`,          label:'Top-3 Group Share', color:top3GroupsPct>=70?A:G},
        {value:'—',                          label:'PS Reconciliation', color:MG},
      ]);
    }

    // ── LEFT: Band distribution bars ────────────────────────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'HEADCOUNT BY BAND',
      `${Object.keys(byBand).length} bands · ${psActive.toLocaleString()} active employees`);
    if(bandRows.length>0){
      const maxBand=Math.max(...bandRows.map(r=>r.value),1);
      const bandColors=[N,T,G,A,R,'8E44AD'];
      this._hBar(s,0.35,2.18,6.10,bandRows,maxBand,null,(i)=>bandColors[i%bandColors.length]);
    } else {
      // Fallback: show PS Active vs buckets
      const fbRows=[
        {label:'PS Active',      value:psActive},
        {label:'User Intel Bkts',value:uBuckets},
        {label:'Emp Intel Bkts', value:eBuckets},
        {label:'Fully Matched',  value:matched},
      ].filter(r=>r.value>0);
      if(fbRows.length>0){
        const mx=Math.max(...fbRows.map(r=>r.value),1);
        this._hBar(s,0.35,2.18,6.10,fbRows,mx,null,(i)=>[N,T,T,G][i]||T);
      }
    }

    // ── RIGHT: Reconciliation status (PS online) OR Group concentration (PS offline) ──
    if(PS_AVAILABLE){
      this._exhibitHead(s,6.70,1.80,6.20,'RECONCILIATION STATUS',
        `Match analysis · ${psActive} active records`);
      this._stackedBar(s,6.70,2.20,6.20,0.44,[
        {label:'Fully Matched', count:matched,    color:G},
        {label:'Bucket Diffs',  count:diffs,      color:A},
        {label:'Exceptions',    count:exceptions, color:R},
      ].filter(sg=>sg.count>0));
      [{label:'Reconciliation match rate',value:`${reconPct}%`,color:reconPct>=90?G:reconPct>=70?A:R},
       {label:'Bucket discrepancies',     value:diffs,          color:diffs>50?R:diffs>0?A:G},
       {label:'Person-level exceptions',  value:exceptions,     color:exceptions>50?R:exceptions>0?A:G},
       {label:'User Intel buckets',       value:uBuckets,       color:T},
      ].forEach((m,i)=>{
        const my=3.08+i*0.29;
        s.addText(m.label,{x:6.70,y:my,w:4.30,h:0.26,fontSize:8,fontFace:'Calibri',color:DG});
        s.addText(String(m.value),{x:11.00,y:my,w:1.90,h:0.26,fontSize:9,fontFace:'Calibri',color:m.color,bold:true,align:'right'});
        s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:my+0.25,w:6.20,h:0.01,fill:{color:LG},line:{type:'none'}});
      });
      if(diffs>50){
        this._calloutBox(s,6.70,4.06,6.20,0.48,
          `⚠  ${diffs} bucket mismatches require HR resolution before payroll cycle close — prioritise with HR Ops`,'C0392B');
      } else if(exceptions>50){
        this._calloutBox(s,6.70,4.06,6.20,0.48,
          `${exceptions} person exceptions pending — review with HR before ${new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}`,'E67E22');
      }
    } else {
      // PS not available — show group concentration analysis instead
      this._exhibitHead(s,6.70,1.80,6.20,'TOP GROUPS BY HEADCOUNT',
        `${Object.keys(groupRoll).length} groups · ${userTotal.toLocaleString()} active users`);
      if(groupRowsAuto.length>0){
        const maxG=Math.max(...groupRowsAuto.map(r=>r.value),1);
        const groupColors=[N,T,G,A,R,'8E44AD'];
        this._hBar(s,6.70,2.18,6.20,groupRowsAuto,maxG,null,(i)=>groupColors[i%groupColors.length]);
      }
      this._calloutBox(s,6.70,4.06,6.20,0.48,
        `ℹ  PeopleStrong reconciliation paused — workforce intel served from BIZTECH user/employee buckets only`,'0A7EA4');
    }

    // ── BOTTOM: Band distribution chart (always renders) ─────────────────
    this._bottomHead(s,'HEADCOUNT DISTRIBUTION BY BAND — ACTIVE EMPLOYEES');
    if(bandRows.length>0){
      s.addChart(this.pptx.ChartType.bar,[
        {name:'Headcount',labels:bandRows.map(r=>r.label),values:bandRows.map(r=>r.value)},
      ],{
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'col',barGrouping:'clustered',
        chartColors:[N],
        showLegend:false,
        showTitle:false,showValue:true,dataLabelFontSize:10,
        catAxisLabelFontSize:10,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      s.addChart(this.pptx.ChartType.bar,[
        {name:'Count',labels:['PS Active','User Bkts','Emp Bkts','Matched','Diffs','Exceptions'],
         values:[psActive,uBuckets,eBuckets,matched,diffs,exceptions]},
      ],{
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'col',barGrouping:'clustered',
        chartColors:[N,T,T,G,A,R],
        showLegend:false,
        showTitle:false,showValue:true,dataLabelFontSize:10,
        catAxisLabelFontSize:9,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 9 — Governance & Quality
  // ══════════════════════════════════════════════════════════════════════════
  _slideGovernance(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const govQ=Array.isArray(ops.govRiskQueue)?ops.govRiskQueue:[];
    const san=ops.sanitySummary||{};
    const sanPass=san.passing||0;
    const sanTotal=san.total||0;
    const sanScore=san.score||0;
    const sanChecks=Array.isArray(san.checks)?san.checks:[];

    const priMap={critical:'C0392B',high:'E67E22',medium:'1B2A4A',low:'27AE60'};
    const critRisks=govQ.filter(r=>(r.priority||'').toLowerCase()==='critical');
    const highRisks=govQ.filter(r=>(r.priority||'').toLowerCase()==='high');
    const decisions=govQ.filter(r=>(r.status||'').toLowerCase().includes('decision'));
    const openRisks=govQ.filter(r=>!['closed','resolved','done'].includes((r.status||'').toLowerCase()));

    // Priority distribution
    const priDist={Critical:critRisks.length,High:highRisks.length,
      Medium:govQ.filter(r=>(r.priority||'').toLowerCase()==='medium').length};
    const priBars=Object.entries(priDist).filter(([,v])=>v>0)
      .map(([k,v])=>({label:k,value:v,color:priMap[k.toLowerCase()]||MG}));

    const soWhat=this._an?.hermes?.slides?.governance?.soWhat||
      (critRisks.length>0?`${critRisks.length} critical risk(s) unmitigated — leadership must confirm remediation owner and deadline before this deck is shared.`
        :decisions.length>0?`${decisions.length} item(s) require a leadership decision — delay beyond this week increases compliance and delivery risk.`
        :`Risk register under control — no critical items without mitigation owner.`);
    const title=this._an?.hermes?.slides?.governance?.headline||
      (critRisks.length>0?`${critRisks.length} critical unmitigated risk(s) — leadership decision required to confirm remediation owner and deadline`
        :decisions.length>0?`${decisions.length} decision(s) awaiting leadership — delay increases compliance and delivery risk`
        :`Governance posture stable — ${openRisks.length} open risks, all with named owners, sanity score ${sanScore}%`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Governance & Quality');
    this._kpiStrip(s,[
      {value:govQ.length,      label:'Risk Register',  color:N},
      {value:openRisks.length, label:'Open Risks',     color:openRisks.length>3?R:A},
      {value:critRisks.length, label:'Critical',       color:critRisks.length>0?R:G},
      {value:highRisks.length, label:'High',           color:highRisks.length>0?A:G},
      {value:decisions.length, label:'Decisions Req.',color:decisions.length>0?R:G},
      {value:`${sanScore}%`,   label:'Sanity Score',   color:sanScore>=80?G:sanScore>=60?A:R},
    ]);

    // ── LEFT: Risk by priority bars ──────────────────────────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'RISK REGISTER BY PRIORITY',
      `${govQ.length} total risks · ${openRisks.length} open`);
    if(priBars.length>0){
      const mx=Math.max(...priBars.map(r=>r.value),1);
      this._hBar(s,0.35,2.18,6.10,priBars,mx,null,(i)=>priBars[i].color);
    }
    // Top critical/high risks list
    const topRisks=govQ.filter(r=>['critical','high'].includes((r.priority||'').toLowerCase())).slice(0,4);
    topRisks.forEach((risk,i)=>{
      const ry=2.80+i*0.30;
      const pc=priMap[(risk.priority||'').toLowerCase()]||MG;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ry+0.03,w:0.06,h:0.22,fill:{color:pc},line:{type:'none'}});
      s.addText(this._trunc(risk.title||'—',42),{x:0.46,y:ry,w:4.50,h:0.26,fontSize:7.5,fontFace:'Calibri',color:DG});
      s.addText(risk.owner||'TBD',{x:4.98,y:ry,w:1.44,h:0.26,fontSize:7,fontFace:'Calibri',color:MG,align:'right'});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ry+0.26,w:6.10,h:0.01,fill:{color:LG},line:{type:'none'}});
    });
    if(critRisks.length>0){
      this._calloutBox(s,0.35,4.06,6.10,0.48,
        `⚠  ${critRisks.length} critical risk(s) without confirmed mitigation plan — escalate to leadership immediately`,'C0392B');
    }

    // ── RIGHT: Sanity check scorecards ────────────────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'DATA SANITY CHECKS',
      `${sanPass} of ${sanTotal} checks passing · score ${sanScore}%`);
    const scoreColor=sanScore>=80?G:sanScore>=60?A:R;
    s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:2.22,w:2.00,h:0.96,fill:{color:scoreColor}});
    s.addText(`${sanScore}%`,{x:6.70,y:2.22,w:2.00,h:0.96,fontSize:36,fontFace:'Calibri',color:'FFFFFF',bold:true,align:'center',valign:'middle'});
    s.addText(`${sanPass}/${sanTotal} checks`,{x:8.82,y:2.42,w:4.08,h:0.32,fontSize:10,fontFace:'Calibri',color:DG,bold:true,valign:'middle'});
    // Check list
    const displayChecks=sanChecks.length>0?sanChecks.slice(0,6)
      :[{name:'Sprint velocity',status:'pass'},{name:'Pipeline health',status:'pass'},
        {name:'ITSM SLA',status:sanScore>=80?'pass':'warn'},{name:'OEG stale ratio',status:sanScore>=80?'pass':'fail'}];
    displayChecks.forEach((chk,i)=>{
      const cy=3.34+i*0.28;
      const cc=chk.status==='pass'?G:chk.status==='fail'?R:A;
      const symbol=chk.status==='pass'?'✓':chk.status==='fail'?'✗':'!';
      s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:cy+0.03,w:0.24,h:0.22,fill:{color:cc},line:{type:'none'}});
      s.addText(symbol,{x:6.70,y:cy+0.03,w:0.24,h:0.22,fontSize:8,fontFace:'Calibri',color:'FFFFFF',bold:true,align:'center',valign:'middle'});
      s.addText(chk.name||`Check ${i+1}`,{x:7.00,y:cy,w:5.90,h:0.26,fontSize:8,fontFace:'Calibri',color:DG});
      s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:cy+0.25,w:6.20,h:0.01,fill:{color:LG},line:{type:'none'}});
    });

    // ── BOTTOM: Full risk register table ─────────────────────────────────
    this._bottomHead(s,'RISK REGISTER — OPEN ITEMS WITH OWNER AND STATUS');
    const displayRisks=govQ.length>0?govQ.slice(0,8)
      :[{id:'—',title:'No risks registered',priority:'—',status:'—',owner:'—'}];
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const riskRows=[
      [{text:'PRIORITY',options:{...hdr,align:'center'}},{text:'TITLE',options:{...hdr,align:'left'}},
       {text:'STATUS',options:{...hdr,align:'center'}},{text:'OWNER',options:{...hdr,align:'center'}}],
      ...displayRisks.map((risk,ri)=>{
        const bg=ri%2===0?'FFFFFF':'F7F7F5';
        const pc=priMap[(risk.priority||'').toLowerCase()]||MG;
        const cell=(t,al='left')=>({text:this._trunc(String(t||'—'),40),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:DG,align:al,border:[noLine,noLine,hl,noLine]}});
        return [
          {text:(risk.priority||'—').toUpperCase(),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:pc,bold:true,align:'center',border:[noLine,noLine,hl,noLine]}},
          cell(risk.title||risk.description||'—'),
          cell(risk.status||'Open','center'),
          cell(risk.owner||'TBD','center'),
        ];
      }),
    ];
    s.addTable(riskRows,{x:0.35,y:4.28,w:12.62,rowH:0.28,fontFace:'Calibri'});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 10 — Actions & Next Steps
  // ══════════════════════════════════════════════════════════════════════════
  _slideActions(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops=this._ops||{};
    const actions=(this._an?.hermes?.actions||[]).sort((a,b)=>{
      const o={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};
      return (o[String(a.priority||'').toUpperCase()]??9)-(o[String(b.priority||'').toUpperCase()]??9);
    });
    const critActs=actions.filter(a=>String(a.priority||'').toUpperCase()==='CRITICAL');
    const highActs=actions.filter(a=>String(a.priority||'').toUpperCase()==='HIGH');
    const priColor=(p)=>{
      switch(String(p||'').toUpperCase()){case'CRITICAL':return R;case'HIGH':return A;case'MEDIUM':return T;default:return MG;}
    };

    const soWhat=this._an?.hermes?.slides?.actions?.soWhat||
      (critActs.length>0?`${critActs.length} CRITICAL action(s) require owner confirmation before next stand-up — delay will compound delivery risk.`
        :`${actions.length} action items tracked — confirm ownership and timelines with leads in next review.`);
    const title=this._an?.hermes?.slides?.actions?.headline||
      (critActs.length>0?`${critActs.length} CRITICAL and ${highActs.length} HIGH priority actions require confirmed owners before next stand-up`
        :actions.length>0?`${actions.length} action items tracked across ${[...new Set(actions.map(a=>a.domain))].length} domains — confirm ownership and timelines`
        :`Action register clear — no blocking items identified this sprint`);

    const s=this.pptx.addSlide();
    this._slideChrome(s,title,soWhat,sn,ts,'Actions & Next Steps');
    this._kpiStrip(s,[
      {value:actions.length,   label:'Total Actions',color:N},
      {value:critActs.length,  label:'Critical',     color:critActs.length>0?R:G},
      {value:highActs.length,  label:'High',         color:highActs.length>0?A:G},
      {value:actions.filter(a=>String(a.priority||'').toUpperCase()==='MEDIUM').length,label:'Medium',color:T},
      {value:[...new Set(actions.map(a=>a.domain||''))].filter(Boolean).length,label:'Domains',color:N},
      {value:actions.filter(a=>a.timeframe&&a.timeframe.toLowerCase().includes('week')).length,label:'This Week',color:R},
    ]);

    // ── LEFT: Critical & High action items ────────────────────────────────
    this._exhibitHead(s,0.35,1.80,6.10,'CRITICAL & HIGH PRIORITY ACTIONS',
      `${critActs.length+highActs.length} items requiring immediate owner confirmation`);
    // Cap at 3 cards (3 × 0.52 = 1.56" + start 2.18 = 3.74) to leave a clean
    // safe-zone below y=4.00 before the bottom-head fires at y=4.05.
    const topActions=actions.filter(a=>['CRITICAL','HIGH'].includes(String(a.priority||'').toUpperCase())).slice(0,3);
    if(topActions.length>0){
      topActions.forEach((act,i)=>{
        const ay=2.18+i*0.52;
        const pc=priColor(act.priority);
        s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ay,w:6.10,h:0.46,fill:{color:'F7F7F5'},line:{type:'none'}});
        s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ay,w:0.06,h:0.46,fill:{color:pc},line:{type:'none'}});
        s.addText(String(act.priority||'MEDIUM').toUpperCase(),{x:0.46,y:ay+0.02,w:1.00,h:0.18,fontSize:6.5,fontFace:'Calibri',color:pc,bold:true});
        s.addText(this._trunc(act.action||'—',54),{x:0.46,y:ay+0.20,w:5.94,h:0.22,fontSize:7.5,fontFace:'Calibri',color:DG,bold:true});
        s.addText(`${act.owner||'TBD'} · ${act.timeframe||'This Week'} · ${act.domain||'—'}`,
          {x:0.46,y:ay+0.22,w:5.94,h:0.18,fontSize:6.5,fontFace:'Calibri',color:MG});
      });
    } else {
      this._calloutBox(s,0.35,2.40,6.10,0.80,`✓  No critical or high priority actions — team execution is clean this sprint`,'27AE60');
    }

    // ── RIGHT: Domain summary RAG + action count ─────────────────────────
    this._exhibitHead(s,6.70,1.80,6.20,'ACTIONS BY DOMAIN',
      `Grouped by operational domain`);
    const byDomain={};
    actions.forEach(a=>{const d=a.domain||'Other';if(!byDomain[d])byDomain[d]={total:0,critical:0};byDomain[d].total++;if(String(a.priority||'').toUpperCase()==='CRITICAL')byDomain[d].critical++;});
    const domainEntries=Object.entries(byDomain).sort((a,b)=>b[1].critical-a[1].critical||b[1].total-a[1].total);
    if(domainEntries.length>0){
      const maxDA=Math.max(...domainEntries.map(([,v])=>v.total),1);
      this._hBar(s,6.70,2.18,6.20,
        domainEntries.slice(0,5).map(([k,v])=>({label:k,value:v.total})),
        maxDA,null,
        (i)=>{const d=domainEntries[i];return d&&d[1].critical>0?R:A;});
    } else {
      s.addText('No domain-tagged actions this sprint',{x:6.70,y:2.50,w:6.20,h:0.60,fontSize:10,fontFace:'Calibri',color:MG,align:'center',italic:true});
    }
    if(critActs.length>0){
      this._calloutBox(s,6.70,3.80,6.20,0.44,
        `⚠  ${critActs.length} CRITICAL action(s) — confirm owners and start dates in next stand-up`,'C0392B');
    }

    // ── BOTTOM: Full action register table ───────────────────────────────
    this._bottomHead(s,'FULL ACTION REGISTER — ALL ITEMS WITH OWNER AND TIMELINE');
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const allActs=actions.length>0?actions.slice(0,11):[{priority:'—',action:'No actions recorded this sprint',domain:'—',owner:'—',timeframe:'—'}];
    const actRows=[
      [{text:'PRIORITY',options:{...hdr,align:'center'}},{text:'ACTION',options:{...hdr,align:'left'}},
       {text:'DOMAIN',options:{...hdr,align:'center'}},{text:'OWNER',options:{...hdr,align:'center'}},{text:'BY WHEN',options:{...hdr,align:'center'}}],
      ...allActs.map((a,ri)=>{
        const bg=ri%2===0?'FFFFFF':'F7F7F5';
        const pc=priColor(a.priority);
        const cell=(t,al='left')=>({text:this._trunc(String(t||'—'),55),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:DG,align:al,border:[noLine,noLine,hl,noLine]}});
        return [
          {text:String(a.priority||'—').toUpperCase(),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:pc,bold:true,align:'center',border:[noLine,noLine,hl,noLine]}},
          cell(a.action||'—'),
          cell(a.domain||'—','center'),
          cell(a.owner||'TBD','center'),
          cell(a.timeframe||'This Week','center'),
        ];
      }),
    ];
    s.addTable(actRows,{x:0.35,y:4.28,w:12.62,rowH:0.27,fontFace:'Calibri'});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 11 — Per-Person Workload Heatmap
  // Concentration-risk view across owners: WIP, stale, blocked, hygiene, focus.
  // Surfaces single-point-of-failure owners (>3 P1 unblocks on one person).
  // ══════════════════════════════════════════════════════════════════════════
  _slideWorkloadHeatmap(sprintData, an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';

    // sprintData.byAssignee can be either an array of single-key objects (when
    // the Transform passes raw merged shape) or a plain { name: {...} } map.
    const rawAssign = sprintData?.byAssignee;
    const flat = {};
    if (Array.isArray(rawAssign)) {
      for (const entry of rawAssign) {
        if (entry && typeof entry === 'object') Object.assign(flat, entry);
      }
    } else if (rawAssign && typeof rawAssign === 'object') {
      Object.assign(flat, rawAssign);
    }
    const owners = Object.values(flat)
      .filter(p => p && typeof p === 'object' && (p.active || p.stale || p.itemCount))
      // Rank by a composite load score: 2× blocked + stale + 0.5× active.
      .map(p => ({
        name:    p.name || 'Unknown',
        active:  Number(p.active)  || 0,
        stale:   Number(p.stale)   || 0,
        blocked: Number(p.blocked) || 0,
        openPRs: Number(p.openPRs) || 0,
        hygiene: Number(p.hygiene?.score)   || 0,
        focus:   Number(p.focusScore)       || 0,
        cycleTime: Math.round(Number(p.personalCycleTime) || 0),
        rework:  Number(p.reworkCount) || 0,
        loadScore: 2*(Number(p.blocked)||0) + (Number(p.stale)||0) + 0.5*(Number(p.active)||0),
      }))
      .sort((a,b) => b.loadScore - a.loadScore)
      .slice(0, 12);

    const concentrationRisk = owners.filter(o => o.blocked >= 3 || o.stale >= 8).slice(0, 3);
    const top = owners[0];
    const totalActive = owners.reduce((s,o) => s+o.active, 0);
    const top3Share = totalActive>0
      ? Math.round(owners.slice(0,3).reduce((s,o)=>s+o.active,0)/totalActive*100)
      : 0;

    const title = this._an?.hermes?.slides?.workload?.headline ||
      (concentrationRisk.length>0
        ? `${concentrationRisk.length} owner(s) carry concentration risk — ${concentrationRisk[0].name} owns ${concentrationRisk[0].blocked} blocker(s) and ${concentrationRisk[0].stale} stale item(s)`
        : top
          ? `${top.name} leads workload (${top.active} active, ${top.stale} stale) — top 3 owners hold ${top3Share}% of active items`
          : `Owner load distributed evenly — no single-point-of-failure detected this period`);
    const soWhat = this._an?.hermes?.slides?.workload?.soWhat ||
      (concentrationRisk.length>0
        ? `Redistribute work from concentration owners by Thursday standup — single-point-of-failure increases delivery risk if any one owner is unavailable.`
        : `Workload spread is healthy — sustain pairing rotation and hygiene reviews to prevent future concentration.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Workload Heatmap');
    this._kpiStrip(s, [
      {value: owners.length,                                     label: 'Active Owners',  color: N},
      {value: totalActive,                                       label: 'Total Active',   color: T},
      {value: owners.reduce((s,o)=>s+o.stale,0),                 label: 'Stale Items',    color: A},
      {value: owners.reduce((s,o)=>s+o.blocked,0),               label: 'Blocked Items',  color: R},
      {value: concentrationRisk.length,                          label: 'At-Risk Owners', color: concentrationRisk.length>0?R:G},
      {value: `${top3Share}%`,                                   label: 'Top-3 Load Share', color: top3Share>=70?A:G},
    ]);

    // ── LEFT: Top owners by active load (horizontal bar) ───────────────────
    // Cap to 6 rows so the bars (6 × 0.32 = 1.92") fit in the upper-row safe
    // zone y=2.18 → y=4.10 without colliding with the bottom-head at y=4.05.
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'OWNERS BY ACTIVE WORKLOAD',
      `Top ${Math.min(6,owners.length)} of ${owners.length} owners by composite load score`);
    const barRows = owners.slice(0, 6).map(o => ({label: o.name, value: o.active}));
    if (barRows.length>0) {
      const mx = Math.max(...barRows.map(r=>r.value), 1);
      this._hBar(s, 0.35, 2.18, 6.10, barRows, mx, null,
        (i, v) => v >= 6 ? R : v >= 3 ? A : T);
    } else {
      s.addText('No assignee data available this period.',
        {x:0.35,y:2.40,w:6.10,h:0.5,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // ── RIGHT: Concentration callouts + hygiene index ──────────────────────
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'CONCENTRATION RISK',
      `${concentrationRisk.length} owner(s) flagged · ${owners.length} total owners`);
    if (concentrationRisk.length>0) {
      concentrationRisk.forEach((o,i)=>{
        const cy = 2.18 + i*0.50;
        s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:cy,w:6.20,h:0.44,fill:{color:'FEF3F2'},line:{color:R,width:1}});
        s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:cy,w:0.06,h:0.44,fill:{color:R},line:{type:'none'}});
        s.addText(o.name,{x:6.84,y:cy+0.05,w:3.20,h:0.18,fontSize:9,fontFace:'Calibri',color:N,bold:true});
        s.addText(`${o.blocked} blocked · ${o.stale} stale · ${o.active} active · hygiene ${o.hygiene}`,
          {x:6.84,y:cy+0.22,w:6.00,h:0.18,fontSize:7.5,fontFace:'Calibri',color:DG});
      });
    } else {
      this._calloutBox(s, 6.70, 2.18, 6.20, 0.48,
        `✓  No concentration risk this period — workload distributed across ${owners.length} owners`, G);
    }

    // ── BOTTOM: Full owner table — heatmap-style hygiene + focus columns ───
    this._bottomHead(s, 'OWNER ACTIVITY TABLE — TOP 12 BY LOAD SCORE');
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const heatColor = v => v >= 6 ? R : v >= 3 ? A : G;
    const rows = [
      [{text:'OWNER',options:{...hdr,align:'left'}},{text:'ACTIVE',options:{...hdr,align:'center'}},
       {text:'STALE',options:{...hdr,align:'center'}},{text:'BLOCKED',options:{...hdr,align:'center'}},
       {text:'PRs',options:{...hdr,align:'center'}},{text:'CYCLE',options:{...hdr,align:'center'}},
       {text:'REWORK',options:{...hdr,align:'center'}},{text:'HYGIENE',options:{...hdr,align:'center'}},
       {text:'BURNOUT',options:{...hdr,align:'center'}}],
      ...owners.map((o,ri)=>{
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const bi = this._burnoutIndex(o);
        const biColor = bi.tier === 'HIGH' ? R : bi.tier === 'MED' ? A : G;
        return [
          cell(o.name,bg,'left',N),
          cell(o.active,bg,'center'),
          cell(o.stale,bg,'center',heatColor(o.stale)),
          cell(o.blocked,bg,'center',heatColor(o.blocked*2)),
          cell(o.openPRs,bg,'center'),
          cell(o.cycleTime?`${o.cycleTime}d`:'—',bg,'center',o.cycleTime>=60?R:o.cycleTime>=30?A:o.cycleTime>0?G:MG),
          cell(o.rework,bg,'center',o.rework>=10?R:o.rework>=3?A:G),
          cell(`${o.hygiene}`,bg,'center',o.hygiene>=70?G:o.hygiene>=50?A:R),
          cell(`${bi.index} (${bi.tier})`,bg,'center',biColor),
        ];
      }),
    ];
    s.addTable(rows,{x:0.35,y:4.28,w:12.62,rowH:0.20,fontFace:'Calibri',colW:[2.30,1.04,1.04,1.20,1.04,1.10,1.20,1.30,1.40]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 12 — 4-Week Health Trend
  // Tracks healthScore, velocity, ITSM open, ITSM aging across the last 4 runs.
  // Sources: analysis.weeklyHistory (propagated from CT: Log Start).
  // ══════════════════════════════════════════════════════════════════════════
  _slideHealthTrend4w(an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const history = Array.isArray(an?.weeklyHistory) ? an.weeklyHistory : [];
    const series = history
      .filter(h => h && (h.healthScore != null || h.velocity != null))
      .slice(0, 8)
      .reverse(); // oldest → newest left → right
    const labels = series.map((h,i) => {
      const d = h.startedAt ? new Date(h.startedAt) : null;
      return d && !isNaN(d) ? d.toLocaleDateString('en-IN',{month:'short',day:'numeric'}) : `W${i+1}`;
    });
    const health = series.map(h => Number(h.healthScore)||0);
    const velocity = series.map(h => Number(h.velocity)||0);
    const itsmOpen = series.map(h => Number(h.itsmOpen)||0);
    const itsmAging = series.map(h => Number(h.itsmAging)||0);

    // BUG FIX: when weeklyHistory is empty/missing, `latest` was {} so
    // `latest.healthScore || 0` rendered "Health score stable at 0/100"
    // even though the current sprint health is e.g. 56. Fall back to the
    // CURRENT sprint stats so the headline always reflects reality.
    const curStats = this._sprintData?.stats || {};
    const latest = series[series.length-1]
      || { healthScore: curStats.healthScore, velocity: curStats.closed, itsmOpen: this._ops?.itsmSummary?.open || 0, itsmAging: this._ops?.itsmSummary?.staleOpen || 0, _fallbackFromCurrent: true };
    const prev   = series[series.length-2] || {};
    const dHealth = (latest.healthScore||0) - (prev.healthScore||0);
    const dVel    = (latest.velocity||0)    - (prev.velocity||0);
    const dOpen   = (latest.itsmOpen||0)    - (prev.itsmOpen||0);
    const dAge    = (latest.itsmAging||0)   - (prev.itsmAging||0);

    // Simple linear projection: slope of last 4 health scores
    const tail = health.slice(-4);
    const slope = tail.length>=2 ? (tail[tail.length-1] - tail[0]) / Math.max(tail.length-1,1) : 0;
    const projected = Math.max(0, Math.round((latest.healthScore||0) + slope));
    const trendDir = slope > 1 ? 'improving' : slope < -1 ? 'declining' : 'flat';

    const title = this._an?.hermes?.slides?.healthTrend?.headline ||
      (latest._fallbackFromCurrent
        ? `Current health ${latest.healthScore||0}/100 — weeklyHistory empty so trend not yet computable; will populate after 2+ runs`
        : trendDir === 'declining'
        ? `Health score declining ${slope.toFixed(0)}/week — projected ${projected}/100 next week without intervention`
        : trendDir === 'improving'
        ? `Health score trending up ${(slope>0?'+':'')}${slope.toFixed(0)}/week — sustain cadence to reach 75+ within ${Math.ceil((75-(latest.healthScore||0))/Math.max(slope,1))} week(s)`
        : `Health score stable at ${latest.healthScore||0}/100 — flat for ${series.length} consecutive runs, no improvement signal`);
    const soWhat = this._an?.hermes?.slides?.healthTrend?.soWhat ||
      (trendDir === 'declining'
        ? `Investigate root causes this week — every 5-point health drop correlates with sprint commit slippage; reverse trajectory before next stand-up.`
        : `Maintain current operating cadence — predictability over peak velocity sustains delivery confidence.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Health Trend (4 Weeks)');
    this._kpiStrip(s, [
      {value: latest.healthScore ?? '—', label: 'Health Score',        color: (latest.healthScore||0)>=70?G:(latest.healthScore||0)>=50?A:R},
      {value: (dHealth>=0?'+':'')+dHealth,label: 'Δ Health WoW',         color: dHealth>=0?G:R},
      {value: latest.velocity ?? '—',    label: 'Velocity',             color: T},
      {value: (dVel>=0?'+':'')+dVel,     label: 'Δ Velocity WoW',       color: dVel>=0?G:R},
      {value: latest.itsmOpen ?? '—',    label: 'ITSM Open',            color: A},
      {value: (dAge>=0?'+':'')+dAge,     label: 'Δ ITSM Aging WoW',     color: dAge<=0?G:R},
    ]);

    // ── LEFT: Health score line ─────────────────────────────────────────
    // Low-time-variance guard: if all values are essentially the same OR all
    // share one date label, suppress the sparkline (avoid 4 dots reading the
    // same number on the same date) and show a clear numeric callout instead.
    const healthRange = health.length ? Math.max(...health) - Math.min(...health) : 0;
    const uniqueLabels = new Set(labels).size;
    const showHealthChart = health.length >= 2 && healthRange >= 2 && uniqueLabels >= 2;
    this._exhibitHead(s, 0.35, 1.84, 6.10, 'HEALTH SCORE — LAST 4+ RUNS',
      showHealthChart
        ? `Linear projection: ${projected}/100 next week (${trendDir})`
        : `Score held flat at ${health[health.length-1] ?? 0}/100 — sparkline suspended until ≥2 distinct dates`);
    if (showHealthChart) {
      s.addChart(this.pptx.ChartType.line, [
        { name:'Health Score', labels, values: health },
      ], {
        x:0.35,y:2.24,w:6.10,h:1.95,
        chartColors:[N],
        showLegend:false,
        showTitle:false,showValue:true,dataLabelFontSize:9,
        valAxisMaxVal:100,valAxisMinVal:0,
        catAxisLabelFontSize:8,valAxisLabelFontSize:8,
        lineSize:2,lineDataSymbol:'circle',lineDataSymbolSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      // Numeric callout: large central number + 4-week sample list
      // BUG FIX: 64pt big number sat at y=2.50 h=0.90 (extends to 3.40), but the
      // "Health Score · /100" label sat at y=3.35 — they overlapped by 0.05".
      // Moved the label to y=3.45 with 0.05" gap from the number's bottom.
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:2.24,w:6.10,h:1.95,fill:{color:'F7F7F5'},line:{color:RL,width:0.5}});
      s.addText(String(health[health.length-1] ?? '—'),
        {x:0.35,y:2.40,w:6.10,h:0.95,fontSize:64,fontFace:'Calibri',color:(health[0]||0)>=70?G:(health[0]||0)>=50?A:R,bold:true,align:'center',valign:'middle'});
      s.addText('Health Score · /100',
        {x:0.35,y:3.45,w:6.10,h:0.22,fontSize:9,fontFace:'Calibri',color:MG,align:'center'});
      s.addText(`History: ${(health.length?health:['—']).join(' → ')}`,
        {x:0.35,y:3.72,w:6.10,h:0.25,fontSize:9,fontFace:'Calibri',color:DG,align:'center',italic:true});
    }

    // ── RIGHT: Velocity line + delta panel ────────────────────────────────
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'VELOCITY — LAST 4+ RUNS',
      `Closed items per run · trend ${dVel>=0?'+':''}${dVel} WoW`);
    if (velocity.length >= 2 && Math.max(...velocity) > 0) {
      s.addChart(this.pptx.ChartType.line, [
        { name:'Velocity', labels, values: velocity },
      ], {
        x:6.70,y:2.20,w:6.20,h:1.75,
        chartColors:[T],
        showLegend:false,
        showTitle:false,showValue:true,dataLabelFontSize:8,
        catAxisLabelFontSize:7,valAxisLabelFontSize:7,
        lineSize:2,lineDataSymbol:'circle',lineDataSymbolSize:7,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      s.addText('Velocity history is flat across runs — review whether closed-item events are being captured.',
        {x:6.70,y:2.40,w:6.20,h:0.6,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // ── BOTTOM: Multi-metric correlation matrix + chart ─────────────────────
    // BUG FIX: section was just two ITSM lines side-by-side. User wanted
    // ACTUAL correlation between health components — added Pearson r
    // computation across the 4 tracked metrics with a labeled correlation
    // matrix below the chart.
    const pearsonR = (xs, ys) => {
      const n = Math.min(xs.length, ys.length);
      if (n < 2) return null;
      const mx = xs.reduce((a,b)=>a+b,0)/n;
      const my = ys.reduce((a,b)=>a+b,0)/n;
      let num=0, dx=0, dy=0;
      for (let i=0;i<n;i++){ const a=xs[i]-mx, b=ys[i]-my; num+=a*b; dx+=a*a; dy+=b*b; }
      const den = Math.sqrt(dx*dy);
      return den === 0 ? null : Math.round(num/den * 100) / 100;
    };
    const interp = (r) => {
      if (r == null) return { tag:'n/a', color: MG };
      const a = Math.abs(r);
      if (a >= 0.7) return { tag: r>0?'STRONG +':'STRONG −', color: r>0?G:R };
      if (a >= 0.4) return { tag: r>0?'MODERATE +':'MODERATE −', color: r>0?G:A };
      if (a >= 0.2) return { tag: r>0?'WEAK +':'WEAK −', color: T };
      return { tag:'NONE', color: MG };
    };

    this._bottomHead(s, 'TREND CORRELATION — HEALTH ↔ COMPONENTS');
    // Compute pairwise correlations
    const pairs = [
      { a:'Health', b:'Velocity',     ai:health, bi:velocity, want:'positive (more closures → higher health)' },
      { a:'Health', b:'ITSM Open',    ai:health, bi:itsmOpen, want:'negative (more ops load → lower health)' },
      { a:'Health', b:'ITSM Aging',   ai:health, bi:itsmAging,want:'negative (older queue → lower health)' },
      { a:'Velocity', b:'ITSM Open',  ai:velocity, bi:itsmOpen, want:'negative (load competes with delivery)' },
    ];
    const corrs = pairs.map(p => ({ ...p, r: pearsonR(p.ai, p.bi) }));

    // Left: combined chart (3 series this time)
    if (itsmOpen.length >= 2 || itsmAging.length >= 2 || velocity.length >= 2) {
      s.addChart(this.pptx.ChartType.line, [
        { name:'Velocity',   labels, values: velocity },
        { name:'ITSM Open',  labels, values: itsmOpen },
        { name:'ITSM Aging', labels, values: itsmAging },
      ], {
        x:0.35,y:4.32,w:7.20,h:2.20,
        chartColors:[T,A,R],
        showLegend:true,legendPos:'b',legendFontSize:8,
        showTitle:false,showValue:false,
        catAxisLabelFontSize:8,valAxisLabelFontSize:8,
        lineSize:2,lineDataSymbol:'circle',lineDataSymbolSize:5,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    }
    // Right: correlation matrix table
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const corrRows = [
      [{text:'PAIR',options:{...hdr,align:'left'}},
       {text:'r',options:{...hdr,align:'center'}},
       {text:'STRENGTH',options:{...hdr,align:'center'}},
       {text:'EXPECTED',options:{...hdr,align:'left'}}],
      ...corrs.map((c, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const k = interp(c.r);
        return [
          cell(`${c.a} ↔ ${c.b}`, bg, 'left', N),
          cell(c.r != null ? c.r.toFixed(2) : '—', bg, 'center', k.color),
          cell(k.tag, bg, 'center', k.color),
          cell(c.want, bg, 'left', MG),
        ];
      }),
    ];
    s.addTable(corrRows, {x:7.65,y:4.32,w:5.32,rowH:0.32,fontFace:'Calibri',colW:[1.85,0.65,1.30,1.52]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 13 — Cross-Domain Aging Pyramid
  // Where stale work is concentrated across ITSM / OEG / Cloud / Incidents.
  // ══════════════════════════════════════════════════════════════════════════
  _slideAgingPyramid(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const LG='E8E8E6',DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';
    const ops = this._ops||{};
    const itsmSum  = ops.itsmSummary  || {};
    const oegSum   = ops.oegSummary   || {};
    const cloudSum = ops.cloudSummary || {};
    const incSum   = ops.incidentsSummary || {};

    const domains = [
      { name: 'ITSM',       open: itsmSum.open||0,  stale: itsmSum.staleOpen||itsmSum.stale||0, critical: itsmSum.criticalAge||0, color: N },
      { name: 'OEG',        open: oegSum.open||0,   stale: oegSum.stale||0,                     critical: oegSum.criticalAge||0, color: T },
      { name: 'Cloud',      open: cloudSum.open||0, stale: cloudSum.stale||0,                   critical: cloudSum.criticalAge||0, color: G },
      { name: 'Incidents',  open: incSum.open||0,   stale: incSum.stale||0,                     critical: incSum.criticalAge||0, color: A },
    ];

    const totalOpen  = domains.reduce((s,d)=>s+d.open,0);
    const totalStale = domains.reduce((s,d)=>s+d.stale,0);
    const stalePct   = totalOpen>0?Math.round(totalStale/totalOpen*100):0;
    const topDomain  = [...domains].sort((a,b)=>b.stale-a.stale)[0];
    const criticalCount = domains.reduce((s,d)=>s+d.critical,0);

    const title = this._an?.hermes?.slides?.aging?.headline ||
      (criticalCount > 0
        ? `${criticalCount} critical-age item(s) across ${domains.filter(d=>d.critical>0).length} domain(s) — escalate or close before next WSR`
        : totalStale > 0
        ? `${totalStale} stale items concentrated in ${topDomain.name} (${topDomain.stale}) — institute weekly triage to flatten queue`
        : `No stale items across tracked domains — closure cadence is matching creation rate`);
    const soWhat = this._an?.hermes?.slides?.aging?.soWhat ||
      (totalStale > 0
        ? `${stalePct}% of open items are stale — every additional week aged compounds resolution effort; assign named owners with closure dates this Friday.`
        : `Backlog age profile is healthy — sustain current closure cadence and monitor for trend reversal next week.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Cross-Domain Aging');
    this._kpiStrip(s, [
      {value: totalOpen,                  label: 'Total Open',     color: N},
      {value: totalStale,                 label: 'Stale (>7d)',    color: stalePct>=20?R:A},
      {value: `${stalePct}%`,             label: 'Stale Ratio',    color: stalePct>=20?R:stalePct>=10?A:G},
      {value: criticalCount,              label: 'Critical Age',   color: criticalCount>0?R:G},
      {value: topDomain.name,             label: 'Top Stale Source', color: T},
      {value: topDomain.stale,            label: 'Top Stale Count', color: R},
    ]);

    // ── LEFT: Open vs Stale stacked bar by domain ──────────────────────────
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'OPEN vs STALE BY DOMAIN',
      `${totalOpen.toLocaleString()} open items · ${totalStale} flagged stale`);
    if (totalOpen > 0) {
      s.addChart(this.pptx.ChartType.bar, [
        { name:'Open (fresh)', labels: domains.map(d=>d.name), values: domains.map(d=>Math.max(0,d.open-d.stale)) },
        { name:'Stale (>7d)',  labels: domains.map(d=>d.name), values: domains.map(d=>d.stale) },
      ], {
        x:0.35,y:2.20,w:6.10,h:1.75,
        barDir:'bar',barGrouping:'stacked',
        chartColors:[T,R],
        showLegend:true,legendPos:'b',legendFontSize:8,
        showTitle:false,showValue:true,dataLabelFontSize:8,
        catAxisLabelFontSize:8,valAxisLabelFontSize:7,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      s.addText('No open items tracked across domains.',
        {x:0.35,y:2.40,w:6.10,h:0.4,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // ── RIGHT: Domain summary table with ratios ────────────────────────────
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'DOMAIN STRESS INDEX',
      `Open / stale / critical-age per domain`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const stressRows = [
      [{text:'DOMAIN',options:{...hdr,align:'left'}},{text:'OPEN',options:{...hdr,align:'center'}},
       {text:'STALE',options:{...hdr,align:'center'}},{text:'STALE %',options:{...hdr,align:'center'}},
       {text:'CRITICAL',options:{...hdr,align:'center'}}],
      ...domains.map((d,ri)=>{
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const ratio = d.open>0?Math.round(d.stale/d.open*100):0;
        return [
          cell(d.name,bg,'left',N),
          cell(d.open.toLocaleString(),bg,'center'),
          cell(d.stale,bg,'center',d.stale>0?R:G),
          cell(`${ratio}%`,bg,'center',ratio>=20?R:ratio>=10?A:G),
          cell(d.critical,bg,'center',d.critical>0?R:G),
        ];
      }),
    ];
    s.addTable(stressRows,{x:6.70,y:2.20,w:6.20,rowH:0.30,fontFace:'Calibri',colW:[1.80,1.10,1.10,1.10,1.10]});

    // ── BOTTOM: Comparative stale-by-domain chart ──────────────────────────
    this._bottomHead(s, 'STALE ITEMS BY DOMAIN — RANKED');
    if (totalStale > 0) {
      const ranked = [...domains].sort((a,b)=>b.stale-a.stale);
      s.addChart(this.pptx.ChartType.bar, [
        { name:'Stale Items',
          labels: ranked.map(d=>d.name),
          values: ranked.map(d=>d.stale) },
      ], {
        x:0.35,y:4.28,w:12.62,h:2.28,
        barDir:'bar',barGrouping:'clustered',
        chartColors:[R],
        showLegend:false,
        showTitle:false,showValue:true,dataLabelFontSize:10,
        catAxisLabelFontSize:10,valAxisLabelFontSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
        `✓  No stale items across ITSM, OEG, Cloud, or Incidents this period — closure cadence is exceeding intake.`, G);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 14 — Hermes Executive Memo
  // A single-page Mistral-authored narrative: situation → complication → resolution.
  // Replaces bulleted exec summary with proper prose, signed by Hermes.
  // ══════════════════════════════════════════════════════════════════════════
  _slideExecutiveMemo(an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',RL='D4D4D0';

    const memo = an?.hermes?.executiveSummary
              || an?.executiveSummary
              || this._an?.hermes?.executiveSummary
              || '';
    const ops = this._ops || {};
    const sp  = this._sprintData?.stats || {};
    const itsmOpen  = ops.itsmSummary?.open || 0;
    const blocked   = (sp.blockedItems||[]).length;
    const healthScore = sp.healthScore || 0;
    const actionsCount = (an?.hermes?.actions || []).length;

    const fallbackMemo =
      `This week BizTech operations carry ${blocked} active blockers against a health score of ${healthScore}/100. ` +
      `ITSM has ${itsmOpen} open cases requiring named-owner triage; closure velocity must rise to reverse backlog growth. ` +
      `Top recommendation: redistribute critical unblock items off concentration owners and institute a Friday triage for stale ITSM cases over 7 days old. ` +
      `Sustained focus on closure cadence over the next two weeks is the single highest-leverage action available; expect health score to recover by 8–12 points if triage is held.`;

    const text = (memo && memo.length > 80) ? memo : fallbackMemo;

    const title = this._an?.hermes?.slides?.executiveMemo?.headline
               || `Executive memo — week of ${this._wl()}`;
    const soWhat = this._an?.hermes?.slides?.executiveMemo?.soWhat
                || `Read this paragraph before standup — it is the synthesis of every other slide in the deck, written by Hermes (Mistral Large).`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Executive Memo');
    this._kpiStrip(s, [
      {value: healthScore,       label: 'Health Score',     color: healthScore>=70?G:healthScore>=50?A:R},
      {value: blocked,           label: 'Active Blockers',  color: blocked>0?R:G},
      {value: itsmOpen,          label: 'ITSM Open',        color: A},
      {value: actionsCount,      label: 'Actions Queued',   color: T},
      {value: 'Mistral',         label: 'Author',           color: N},
      {value: 'Hermes',          label: 'Signed By',        color: N},
    ]);

    // ── Memo body: prose block; falls back to full-width when short
    this._exhibitHead(s, 0.35, 1.85, 12.62, 'NARRATIVE',
      'Synthesis of this week — situation, complication, resolution');
    const paragraphs = text.split(/\n\n+|(?<=\.)\s{2,}/).filter(p => p.trim().length > 20);
    const TWO_COL_THRESHOLD = 600; // chars; below this, use single full-width column
    const useTwoCol = text.length >= TWO_COL_THRESHOLD && paragraphs.length >= 2;

    if (useTwoCol) {
      const half  = Math.ceil(paragraphs.length / 2);
      const left  = paragraphs.slice(0, half).join('\n\n');
      const right = paragraphs.slice(half).join('\n\n');
      s.addText(left, {
        x:0.35, y:2.34, w:6.10, h:4.06,
        fontSize:12, fontFace:'Calibri', color:DG,
        lineSpacing:20, valign:'top', paraSpaceAfter:10,
      });
      s.addText(right, {
        x:6.70, y:2.34, w:6.20, h:4.06,
        fontSize:12, fontFace:'Calibri', color:DG,
        lineSpacing:20, valign:'top', paraSpaceAfter:10,
      });
    } else {
      // Single full-width column — 50% more line height, padded margins
      s.addText(text, {
        x:0.80, y:2.34, w:11.72, h:4.06,
        fontSize:13, fontFace:'Calibri', color:DG,
        lineSpacing:22, valign:'top', paraSpaceAfter:12,
      });
    }

    // ── Signature block ──────────────────────────────────────────────────
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:6.45,w:12.62,h:0.012,fill:{color:RL},line:{type:'none'}});
    s.addText('— Hermes (Mistral Large), authoring on behalf of BizTech Intel Platform',
      {x:0.35,y:6.47,w:12.62,h:0.18,fontSize:10,fontFace:'Calibri',color:MG,italic:true,align:'right'});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 15 — Decisions Required This Week
  // The single "what does leadership owe back to the team" page — items
  // explicitly flagged as needing an EVP/leadership decision before next WSR.
  // Sources: hermes.actions filtered to CRITICAL/HIGH with decision-language.
  // ══════════════════════════════════════════════════════════════════════════
  _slideDecisionsRequired(an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';

    const actions = (an?.hermes?.actions || []);
    // A "decision" is an action whose phrasing implies a leadership ask:
    // confirm, approve, sign off, escalate, prioritise, redistribute, fund.
    const decisionRe = /\b(confirm|approve|sign[\s-]*off|escalate|prioriti[sz]e|redistribute|fund|defer|cancel|decide|authoriz)/i;
    const decisions = actions
      .filter(a => decisionRe.test(a.action || '') ||
                   ['CRITICAL','HIGH'].includes(String(a.priority||'').toUpperCase()))
      .slice(0, 8);

    const critN = decisions.filter(d => String(d.priority||'').toUpperCase()==='CRITICAL').length;
    const highN = decisions.filter(d => String(d.priority||'').toUpperCase()==='HIGH').length;

    const title = this._an?.hermes?.slides?.decisions?.headline ||
      (critN > 0
        ? `${critN} CRITICAL decision(s) require leadership sign-off this week`
        : decisions.length > 0
          ? `${decisions.length} items pending leadership decision — no critical escalations this period`
          : `No outstanding leadership decisions — operating cadence is self-sustaining`);
    const soWhat = this._an?.hermes?.slides?.decisions?.soWhat ||
      `These are the only items that cannot move without leadership input. Hold a 15-minute decision review by Thursday EOD to clear the queue.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Decisions Required');
    this._kpiStrip(s, [
      {value: decisions.length, label: 'Pending Decisions', color: decisions.length>0?A:G},
      {value: critN,            label: 'Critical',          color: critN>0?R:G},
      {value: highN,            label: 'High',              color: highN>0?A:G},
      {value: 'Thu',            label: 'Review By',         color: N},
      {value: 'EVP',            label: 'Decision Owner',    color: N},
      {value: '15min',          label: 'Time Required',     color: T},
    ]);

    // ── BODY: Decision cards — clearly stating the ASK ──────────────────
    this._exhibitHead(s, 0.35, 1.84, 12.62, 'PENDING DECISIONS',
      'Each item below cannot progress without an explicit leadership decision.');

    if (decisions.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `✓  No decisions are pending leadership. Team is fully empowered to execute the current action register.`, G);
      return;
    }

    decisions.forEach((d, i) => {
      const pc = String(d.priority||'').toUpperCase()==='CRITICAL' ? R
               : String(d.priority||'').toUpperCase()==='HIGH'     ? A : T;
      const cy = 2.34 + i * 0.50;
      if (cy + 0.46 > 6.50) return; // hard stop before chrome soWhat band
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:12.62,h:0.46,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:0.08,h:0.46,fill:{color:pc},line:{type:'none'}});
      s.addText(String(d.priority||'MEDIUM').toUpperCase(),
        {x:0.50,y:cy+0.03,w:1.20,h:0.18,fontSize:8,fontFace:'Calibri',color:pc,bold:true});
      s.addText(d.action || '—',
        {x:0.50,y:cy+0.21,w:9.20,h:0.24,fontSize:10,fontFace:'Calibri',color:DG,bold:true});
      s.addText(`Owner: ${d.owner||'TBD'}  ·  By: ${d.timeframe||'this week'}  ·  Domain: ${d.domain||'—'}`,
        {x:9.80,y:cy+0.10,w:3.10,h:0.30,fontSize:8,fontFace:'Calibri',color:MG,align:'right',valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SLIDE 16 — Glossary & Methodology (appendix)
  // Defines acronyms (OEG/MPR/PS/HRIS/AC/SP/SLA/RAG) and surfaces data
  // provenance so non-engineering readers can self-serve.
  // ══════════════════════════════════════════════════════════════════════════
  _slideGlossary(sn, ts) {
    const N='1B2A4A',DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';

    const title  = 'Glossary, methodology, and data provenance';
    const soWhat = `Every metric on this deck traces back to a named source on biztech-live-intel.neocities.org. Hover or click a chart in the live dashboard for the underlying record set.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Glossary & Methodology');

    // ── LEFT: Acronyms (compressed row height 0.30→0.18 to fit above bottom-head)
    this._exhibitHead(s, 0.35, 1.04, 6.10, 'ACRONYMS',
      'Terminology used throughout this deck');
    const acronyms = [
      ['ITSM',  'IT Service Management — BusinessNext cases, bug + incident tracking'],
      ['OEG',   'Operations Engineering Group — production support cases'],
      ['MPR',   'Monthly Performance Report — BN aggregate KPIs'],
      ['PS',    'PeopleStrong — HRIS system of record'],
      ['HRIS',  'Human Resources Information System'],
      ['CDP',   'Customer Data Platform'],
      ['SP',    'Story Points — sprint estimation unit'],
      ['AC',    'Acceptance Criteria — definition of done on a user story'],
      ['SLA',   'Service Level Agreement — committed resolution time'],
      ['RAG',   'Red/Amber/Green status indicator'],
      ['WIP',   'Work In Progress'],
      ['WoW',   'Week-over-Week comparison'],
      ['PR',    'Pull Request — Azure DevOps code review'],
      ['DoD',   'Definition of Done — closure criteria'],
    ];
    // 14 items × 0.18 = 2.52" → 1.46 + 2.52 = 3.98 ✓ clear of bottom-head at 4.05
    acronyms.forEach((a, i) => {
      const ay = 1.46 + i * 0.18;
      s.addText(a[0], {x:0.35,y:ay,w:0.85,h:0.16,fontSize:9,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(a[1], {x:1.25,y:ay,w:5.18,h:0.16,fontSize:8,fontFace:'Calibri',color:DG,valign:'middle'});
    });

    // ── RIGHT: Methodology — prefer governance.metricDictionary when available
    this._exhibitHead(s, 6.70, 1.04, 6.20, 'METHODOLOGY',
      'How key metrics are computed');
    const dictionary = this._ops?.govMetricDictionary || [];
    let methodology;
    if (Array.isArray(dictionary) && dictionary.length >= 5) {
      // Use authoritative governance definitions — pick 7 most-relevant for WSR
      const wsrRelevant = ['health', 'sprint', 'velocity', 'stale', 'aging', 'sla', 'blocker', 'risk', 'attention', 'queue'];
      const ranked = dictionary
        .filter(m => m.name && m.definition)
        .sort((a, b) => {
          const aRel = wsrRelevant.some(k => (a.name||'').toLowerCase().includes(k)) ? 0 : 1;
          const bRel = wsrRelevant.some(k => (b.name||'').toLowerCase().includes(k)) ? 0 : 1;
          return aRel - bRel;
        })
        .slice(0, 7);
      methodology = ranked.map(m => [m.name, m.definition]);
    } else {
      // Fallback to hardcoded definitions
      methodology = [
        ['Health Score',      'Composite 0–100: sprint completion (40%) + PR-debt inverse (20%) + ITSM age inverse (20%) + hygiene (20%)'],
        ['Sprint Readiness',  'Forward-looking 0–100: velocity-vs-need + PR-debt + backlog-age + owner-concentration, equal-weight average'],
        ['Stale (>7d)',       'Any open item with age > 7 calendar days since createdOn'],
        ['Concentration Risk','Owner with ≥3 blockers OR ≥8 stale items'],
        ['Burnout Index',     'Composite per owner: active + stale×0.5 + blocked×2; ≥15 = HIGH risk'],
        ['Critical Age',      'Open item with age > 90 days; flagged for escalation'],
        ['Velocity',          'Items closed in the WSR reporting window (Mon–Sun)'],
      ];
    }
    // 7 items × 0.34 = 2.38" → 1.46 + 2.38 = 3.84 ✓ clear of bottom-head
    methodology.forEach((m, i) => {
      const my = 1.46 + i * 0.34;
      s.addText(m[0], {x:6.70,y:my,w:2.20,h:0.32,fontSize:9,fontFace:'Calibri',color:N,bold:true,valign:'top'});
      s.addText(m[1], {x:8.92,y:my,w:3.98,h:0.32,fontSize:8,fontFace:'Calibri',color:DG,lineSpacing:11,valign:'top'});
    });

    // ── BOTTOM: Data sources (4 rows × 0.42 = 1.68", starts y=4.45)
    this._bottomHead(s, 'DATA PROVENANCE — FILES READ BY THE N8N PIPELINE');
    const sources = [
      ['wsr-intel/*.json (WSR Automate publisher)',
       'ITSM, OEG, Cloud, Governance, Inc/Req, Legal, IT-Desk'],
      ['data/*.json (BIZTECH dashboard publisher)',
       'Headcount, MPR, Pipelines, Recommendations, Work Items, Assignees'],
      ['NVIDIA NIM mistral-large-2411',
       'Hermes intelligence, Executive Memo, slide headlines, decisions'],
      ['control-tower.json (CT: Log Start/Close)',
       'Week-over-Week deltas, 4-week trend history, run reliability'],
    ];
    sources.forEach((sr, i) => {
      const sy = 4.45 + i * 0.42;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:sy,w:0.06,h:0.36,fill:{color:N},line:{type:'none'}});
      s.addText(sr[0], {x:0.50,y:sy,w:4.50,h:0.36,fontSize:9,fontFace:'Calibri',color:DG,bold:true,valign:'middle'});
      s.addText(sr[1], {x:5.10,y:sy,w:7.80,h:0.36,fontSize:9,fontFace:'Calibri',color:MG,valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Top Accounts by Open Volume
  // Aggregates accountName across ITSM + OEG + Cloud + Incidents.
  // ══════════════════════════════════════════════════════════════════════════
  _slideTopAccounts(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';
    const ops = this._ops || {};
    const accounts = this._topAccountsByOpenVolume(ops, 10);

    const totalAccounted = accounts.reduce((s,a)=>s+a.total, 0);
    const top3Share = accounts.length>0 && totalAccounted>0
      ? Math.round(accounts.slice(0,3).reduce((s,a)=>s+a.total,0) / totalAccounted * 100)
      : 0;
    const topAcct = accounts[0];

    const title = this._an?.hermes?.slides?.accounts?.headline ||
      (accounts.length === 0
        ? `No account-level concentration detected — ops capacity is evenly distributed`
        : topAcct
          ? `${topAcct.account} holds ${topAcct.total} open items across ${[topAcct.itsm>0,topAcct.oeg>0,topAcct.cloud>0,topAcct.incidents>0].filter(Boolean).length} domain(s) — assign account lead`
          : `Top accounts concentrate ${top3Share}% of open ops volume — review with account leads`);
    const soWhat = this._an?.hermes?.slides?.accounts?.soWhat ||
      `Top 3 accounts absorb ${top3Share}% of open ops volume; if any one churns, ops capacity rebalances dramatically. Assign named account leads with weekly reviews.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Top Accounts');
    this._kpiStrip(s, [
      {value: accounts.length || 0,         label: 'Accounts w/ Open', color: N},
      {value: totalAccounted,               label: 'Total Open Items', color: T},
      {value: `${top3Share}%`,              label: 'Top-3 Share',      color: top3Share>=70?R:top3Share>=50?A:G},
      {value: topAcct?.total ?? '—',        label: 'Top Account Open', color: R},
      {value: accounts.filter(a=>a.total>=10).length, label: 'High-Stress (≥10)', color: A},
      {value: accounts.filter(a=>[a.itsm,a.oeg,a.cloud,a.incidents].filter(x=>x>0).length>=3).length, label: 'Cross-Domain', color: A},
    ]);

    if (accounts.length === 0) {
      this._calloutBox(s, 0.35, 2.20, 12.62, 0.80,
        `ℹ  No accountName tags found on open records this period — confirm BIZTECH publishes accountName field across ITSM/OEG/Cloud.`, T);
      return;
    }

    // ── LEFT: Account bar chart (top 10 by total) ──────────────────────
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'TOP 10 ACCOUNTS — OPEN ITEM VOLUME',
      `${accounts.length} accounts · ${totalAccounted} total open items`);
    const barRows = accounts.slice(0, 8).map(a => ({label: a.account, value: a.total}));
    const maxA = Math.max(...barRows.map(r=>r.value), 1);
    this._hBar(s, 0.35, 2.18, 6.10, barRows, maxA, null,
      (i, v) => v >= 10 ? R : v >= 5 ? A : T);

    // ── RIGHT: Domain breakdown table ──────────────────────────────────
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BY DOMAIN — TOP 8',
      'Open items per domain · highlights cross-domain stress');
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const tblRows = [
      [{text:'ACCOUNT',options:{...hdr,align:'left'}},{text:'ITSM',options:{...hdr,align:'center'}},
       {text:'OEG',options:{...hdr,align:'center'}},{text:'CLOUD',options:{...hdr,align:'center'}},
       {text:'INC',options:{...hdr,align:'center'}},{text:'TOTAL',options:{...hdr,align:'center'}}],
      ...accounts.slice(0, 8).map((a, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        return [
          cell(this._trunc(a.account, 22), bg, 'left', N),
          cell(a.itsm||'—', bg, 'center', a.itsm>0?DG:MG),
          cell(a.oeg||'—',  bg, 'center', a.oeg>0?DG:MG),
          cell(a.cloud||'—',bg, 'center', a.cloud>0?DG:MG),
          cell(a.incidents||'—', bg, 'center', a.incidents>0?DG:MG),
          cell(a.total, bg, 'center', a.total>=10?R:a.total>=5?A:DG),
        ];
      }),
    ];
    s.addTable(tblRows,{x:6.70,y:2.20,w:6.20,rowH:0.21,fontFace:'Calibri',colW:[2.30,0.80,0.80,0.80,0.70,0.80]});

    // ── BOTTOM: Concentration insight ──────────────────────────────────
    this._bottomHead(s, 'CONCENTRATION SIGNAL');
    if (top3Share >= 60) {
      this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
        `⚠  Top 3 accounts hold ${top3Share}% of all open items — assign account leads with weekly RAG before next WSR`, R);
    } else if (top3Share >= 40) {
      this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
        `${top3Share}% concentration in top 3 accounts — monitor for stress escalation, no immediate action required`, A);
    } else {
      this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
        `✓  Open items distributed across ${accounts.length} accounts — no single-account concentration risk`, G);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Week-over-Week Top Movers
  // Auto-detects which 5 metrics changed most week over week vs last run.
  // ══════════════════════════════════════════════════════════════════════════
  _slideWowMovers(an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';
    const movers = this._wowMovers(an, this._ops||{}, this._sprintData||{});

    const improvements = movers.filter(m => m.isImprovement).length;
    const regressions  = movers.filter(m => !m.isImprovement).length;
    const biggest = movers[0];

    // History depth: prefer weeklyHistory (granular WoW), surface Hermes
    // memory depth too so the slide doesn't look "no data" when Hermes has 41 runs
    const wkHistDepth = (an?.weeklyHistory||[]).length;
    const hermesSnapDepth = (this._ops?.hermesLearning?.weeklySnapshots || []).length;
    const totalRuns = this._ops?.hermesLearning?.totals?.runCount || 0;
    const effectiveDepth = Math.max(wkHistDepth, hermesSnapDepth);

    const title = this._an?.hermes?.slides?.wowMovers?.headline ||
      (movers.length === 0
        ? (totalRuns >= 2
            ? `Week-over-week comparison unavailable — Hermes has ${totalRuns} runs but per-metric snapshots are sparse (${hermesSnapDepth} captured)`
            : `Week-over-week comparison unavailable — fewer than 2 runs in history`)
        : biggest
          ? `${biggest.label} moved ${biggest.deltaPct>0?'+':''}${biggest.deltaPct}% week-over-week — ${biggest.isImprovement?'improvement':'regression'}`
          : `${regressions} regression(s) and ${improvements} improvement(s) detected vs last run`);
    const soWhat = this._an?.hermes?.slides?.wowMovers?.soWhat ||
      `Watch the regressions: they compound week over week if not actively addressed. Improvements show the cadence is working — sustain.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'WoW Top Movers');
    this._kpiStrip(s, [
      {value: movers.length,    label: 'Movers Detected', color: N},
      {value: improvements,     label: 'Improvements',    color: G},
      {value: regressions,      label: 'Regressions',     color: regressions>0?R:G},
      {value: biggest?.label ?? '—',                    label: 'Biggest Move',    color: T},
      {value: biggest ? `${biggest.deltaPct>0?'+':''}${biggest.deltaPct}%` : '—',  label: 'WoW Change',      color: biggest?.isImprovement?G:R},
      {value: `${effectiveDepth}/${totalRuns}`, label: 'Snapshots/Runs', color: T},
    ]);

    if (movers.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        totalRuns >= 2
          ? `ℹ  Hermes has captured ${totalRuns} runs but only ${hermesSnapDepth} weekly snapshots have per-metric data. Snapshots populate as runs accumulate with consistent metric capture.`
          : `ℹ  At least 2 historical runs required to compute WoW deltas. Current history depth: ${wkHistDepth}.`, T);
      return;
    }

    // ── LEFT: Movers cards (one per detected delta) ─────────────────────
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'MOVER CARDS — RANKED BY |Δ%|',
      `${movers.length} metric(s) shifted ≥1% week over week`);
    movers.slice(0, 5).forEach((m, i) => {
      const my = 2.18 + i * 0.42;
      const pc = m.isImprovement ? G : R;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:my,w:6.10,h:0.36,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:my,w:0.08,h:0.36,fill:{color:pc},line:{type:'none'}});
      s.addText(m.label, {x:0.50,y:my+0.02,w:2.30,h:0.32,fontSize:9,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(`${m.was} → ${m.now}`, {x:2.85,y:my+0.02,w:1.60,h:0.32,fontSize:9,fontFace:'Calibri',color:DG,valign:'middle'});
      s.addText(`${m.deltaPct>0?'+':''}${m.deltaPct}%`, {x:4.50,y:my+0.02,w:1.10,h:0.32,fontSize:11,fontFace:'Calibri',color:pc,bold:true,align:'right',valign:'middle'});
      s.addText(m.isImprovement?'↑':'↓', {x:5.70,y:my+0.02,w:0.60,h:0.32,fontSize:14,fontFace:'Calibri',color:pc,bold:true,align:'center',valign:'middle'});
    });

    // ── RIGHT: Direction summary ────────────────────────────────────────
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'DIRECTION SUMMARY',
      'Where the week moved');
    s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:2.20,w:6.20,h:1.50,fill:{color:'F7F7F5'},line:{color:'D4D4D0',width:0.5}});
    s.addText(String(improvements), {x:6.70,y:2.30,w:3.00,h:0.70,fontSize:48,fontFace:'Calibri',color:G,bold:true,align:'center'});
    s.addText('IMPROVEMENTS',{x:6.70,y:3.00,w:3.00,h:0.20,fontSize:8,fontFace:'Calibri',color:MG,bold:true,align:'center'});
    s.addText(String(regressions),  {x:9.90,y:2.30,w:3.00,h:0.70,fontSize:48,fontFace:'Calibri',color:regressions>0?R:G,bold:true,align:'center'});
    s.addText('REGRESSIONS', {x:9.90,y:3.00,w:3.00,h:0.20,fontSize:8,fontFace:'Calibri',color:MG,bold:true,align:'center'});

    if (regressions > improvements) {
      this._calloutBox(s, 6.70, 3.80, 6.20, 0.40,
        `⚠  More regressions (${regressions}) than improvements (${improvements}) this week — action register needs review`, R);
    } else if (improvements > 0) {
      this._calloutBox(s, 6.70, 3.80, 6.20, 0.40,
        `✓  Net positive — sustain the cadence that produced these gains`, G);
    }

    // ── BOTTOM: All-metric snapshot table ─────────────────────────────
    this._bottomHead(s, 'ALL MOVERS — DETAILED TABLE');
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'METRIC',options:{...hdr,align:'left'}},{text:'LAST WEEK',options:{...hdr,align:'center'}},
       {text:'THIS WEEK',options:{...hdr,align:'center'}},{text:'Δ',options:{...hdr,align:'center'}},
       {text:'Δ %',options:{...hdr,align:'center'}},{text:'INTERPRETATION',options:{...hdr,align:'left'}}],
      ...movers.map((m, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const pc = m.isImprovement ? G : R;
        return [
          cell(m.label, bg, 'left', N),
          cell(m.was, bg, 'center'),
          cell(m.now, bg, 'center'),
          cell(`${m.delta>0?'+':''}${m.delta}`, bg, 'center', pc),
          cell(`${m.deltaPct>0?'+':''}${m.deltaPct}%`, bg, 'center', pc),
          cell(m.isImprovement ? 'Improvement — sustain' : 'Regression — investigate', bg, 'left', pc),
        ];
      }),
    ];
    s.addTable(rows,{x:0.35,y:4.50,w:12.62,rowH:0.24,fontFace:'Calibri',colW:[3.40,1.80,1.80,1.20,1.20,3.22]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Risks NOT in the Register (Hermes-driven negative-space alert)
  // Surfaces items with high stress signals that aren't currently tracked as risks.
  // ══════════════════════════════════════════════════════════════════════════
  _slideRisksNotInRegister(an, sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';
    const ops = this._ops || {};

    // Heuristic candidates: high-signal items that ARE NOT in govRiskQueue
    const govRiskTitles = new Set((ops.govRiskQueue||[]).map(r => String(r.title||r.description||'').toLowerCase()));
    const candidates = [];

    // BUG FIX: previously this slide only generated 2-3 candidates because
    // the thresholds were tuned for a fully-tracked org (criticalAge>=30,
    // accounts>=10, only HIGH burnout). Now lower thresholds + add 4 new
    // signal sources to surface more genuine hidden risks per week:
    //   1. ITSM critical-age backlog (>=15 instead of >=30)
    //   2. Stale PRs (any age >= 72h, not just pr_sla alerts)
    //   3. Account concentration (>=5 instead of >=10)
    //   4. Owner burnout MED+HIGH (not just HIGH)
    //   5. NEW: ITSM with no current owner (orphan tickets)
    //   6. NEW: MPR cases stuck in any stage > 100h
    //   7. NEW: Cloud requests open > 30 days
    //   8. NEW: WSR incidents/requirements >= 1 critical priority
    //   9. NEW: Sprint blockers without named owner
    //   10. LLM-supplied candidates

    // 1. ITSM cases with criticalAge (lowered threshold)
    const criticalAge = ops.itsmSummary?.criticalAge || ops.itsmSummary?.staleOpen || 0;
    if (criticalAge >= 15 && !Array.from(govRiskTitles).some(t => t.includes('aged itsm'))) {
      candidates.push({ source:'ITSM', signal:`${criticalAge} cases >7 days stale`, why:'Stale-case backlog not flagged in risk register; aging compounds week over week', priority: criticalAge>=50?'CRITICAL':'HIGH' });
    }
    // 2. Stale PRs — any open PR > 72h (broader than just pr_sla alerts)
    const prs = Array.isArray(ops.prs) ? ops.prs : [];
    const stalePRs = prs.filter(p => (p.ageHours||p.daysOpen*24||0) > 72);
    stalePRs.slice(0,3).forEach(a => {
      candidates.push({ source:'PR', signal:`PR #${a.id||a.prId||'?'} aged ${Math.round(a.ageHours||a.daysOpen*24||0)}h`, why:'Long-open PR creates merge debt and blocks downstream deployments', priority: (a.ageHours||0)>=168?'CRITICAL':'HIGH' });
    });
    // 3. Account concentration: any account with ≥5 open items
    const topAccts = this._topAccountsByOpenVolume(ops, 5);
    topAccts.forEach(a => {
      if (a.total >= 5 && !Array.from(govRiskTitles).some(t => t.includes((a.account||'').toLowerCase()))) {
        candidates.push({ source:'Account', signal:`${a.account}: ${a.total} open items`, why:'Account stress concentration not tracked as risk', priority: a.total>=20?'CRITICAL':a.total>=10?'HIGH':'MEDIUM' });
      }
    });
    // 4. Owner burnout (MED + HIGH, not just HIGH)
    const ba = this._sprintData?.byAssignee;
    const flat = {};
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }
    const burnouts = Object.values(flat).filter(p => p && (p.active||p.stale))
      .map(p => ({ name: p.name, ...this._burnoutIndex({active:p.active,stale:p.stale,blocked:p.blocked}) }))
      .filter(o => o.tier === 'HIGH' || o.tier === 'MED').slice(0, 4);
    burnouts.forEach(o => {
      candidates.push({ source:'People', signal:`${o.name}: burnout index ${o.index} (${o.tier})`, why:'Owner overload signal not in risk register; redistribute work before sprint end', priority: o.tier==='HIGH'?'HIGH':'MEDIUM' });
    });
    // 5. NEW: orphan tickets (no current owner)
    const itsm = Array.isArray(ops.itsm) ? ops.itsm : [];
    const orphans = itsm.filter(c => c.status && !/closed|resolved/i.test(c.status) && !c.currentOwner && !c.assignedToName).length;
    if (orphans >= 5) {
      candidates.push({ source:'Orphans', signal:`${orphans} ITSM tickets without owner`, why:'Open tickets with no assignee will not progress without manual assignment', priority: orphans>=20?'CRITICAL':'HIGH' });
    }
    // 6. NEW: MPR cases stuck in any stage > 100h
    const stuckLong = (ops.mprFull?.stuck_in_new || []).filter(c => (c.new_hours||0) > 100).length
                    + (ops.mprFull?.stuck_in_awaiting || []).filter(c => (c.awaiting_hours||0) > 100).length;
    if (stuckLong >= 3) {
      candidates.push({ source:'MPR', signal:`${stuckLong} cases stuck >100h in single stage`, why:'Stage-stalled cases need intervention to unblock workflow', priority: stuckLong>=10?'HIGH':'MEDIUM' });
    }
    // 7. NEW: Cloud requests open > 30 days (proxy for stale provisioning)
    const cloud = Array.isArray(ops.cloud) ? ops.cloud : [];
    const oldCloud = cloud.filter(c => c.requestDate && (Date.now() - new Date(c.requestDate))/86400000 > 30
                                     && c.status && !/closed|done|complete/i.test(c.status)).length;
    if (oldCloud >= 2) {
      candidates.push({ source:'Cloud', signal:`${oldCloud} cloud requests open >30 days`, why:'Provisioning backlog blocks sprint capacity planning', priority: oldCloud>=10?'HIGH':'MEDIUM' });
    }
    // 8. NEW: critical WSR incidents not in register
    const wsrInc = Array.isArray(ops.wsr_incident) ? ops.wsr_incident : [];
    const critWsr = wsrInc.filter(i => /critical|p1|sev1/i.test(String(i.priority||i.severity||''))).length;
    if (critWsr >= 1) {
      candidates.push({ source:'WSR-Inc', signal:`${critWsr} critical WSR incident(s) active`, why:'Critical-priority incidents need leadership visibility, even if young', priority:'CRITICAL' });
    }
    // 9. NEW: blockers without named owner
    const blockers = (this._sprintData?.stats?.blockedItems || []);
    const unownedBlockers = blockers.filter(b => !b.assignedTo && !b.assignee).length;
    if (unownedBlockers >= 1) {
      candidates.push({ source:'Sprint', signal:`${unownedBlockers} blocker(s) with no named owner`, why:'Unassigned blockers cannot be triaged — assign owner before next stand-up', priority: unownedBlockers>=3?'HIGH':'MEDIUM' });
    }
    // 10. Allow LLM-supplied candidates (from Hermes prompt)
    const llmCandidates = an?.hermes?.risksNotInRegister || [];
    llmCandidates.forEach(c => {
      if (c && c.signal) candidates.push({ ...c, source: c.source || 'Hermes' });
    });

    const totalDetected = candidates.length;
    const criticalN = candidates.filter(c => c.priority==='CRITICAL').length;

    const title = this._an?.hermes?.slides?.risksNotInRegister?.headline ||
      (totalDetected === 0
        ? `Risk register is comprehensive — no negative-space signals detected this week`
        : `${totalDetected} risk signal(s) detected outside the register — add to track before next WSR`);
    const soWhat = this._an?.hermes?.slides?.risksNotInRegister?.soWhat ||
      `These are issues showing stress signals in the data but missing from the formal risk register. Review with risk owners and decide: track, mitigate, or accept.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Hidden Risks');
    this._kpiStrip(s, [
      {value: totalDetected,                                  label: 'Signals Detected',  color: totalDetected>0?A:G},
      {value: criticalN,                                      label: 'Critical',          color: criticalN>0?R:G},
      {value: (ops.govRiskQueue||[]).length,                  label: 'In Register',       color: T},
      {value: candidates.filter(c=>c.source==='ITSM').length, label: 'From ITSM',         color: T},
      {value: candidates.filter(c=>c.source==='Account').length, label: 'From Accounts',  color: T},
      {value: candidates.filter(c=>c.source==='People').length,  label: 'From People',    color: T},
    ]);

    if (totalDetected === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `✓  Hermes scanned the data for stress signals across ITSM age, PR debt, account concentration, and owner burnout — no candidate risks found outside the register.`, G);
      return;
    }

    // ── BODY: Candidate cards ───────────────────────────────────────────
    this._exhibitHead(s, 0.35, 1.84, 12.62, 'CANDIDATE RISKS — NOT YET IN REGISTER',
      'Each signal below shows stress in the data but is missing from the formal risk register.');
    candidates.slice(0, 8).forEach((c, i) => {
      const cy = 2.34 + i * 0.50;
      if (cy + 0.46 > 6.50) return;
      const pc = c.priority === 'CRITICAL' ? R : c.priority === 'HIGH' ? A : T;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:12.62,h:0.46,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:0.08,h:0.46,fill:{color:pc},line:{type:'none'}});
      s.addText(c.source.toUpperCase(),
        {x:0.50,y:cy+0.03,w:1.30,h:0.18,fontSize:8,fontFace:'Calibri',color:pc,bold:true});
      s.addText(c.priority,
        {x:1.85,y:cy+0.03,w:1.20,h:0.18,fontSize:8,fontFace:'Calibri',color:pc,bold:true});
      s.addText(c.signal,
        {x:0.50,y:cy+0.21,w:6.60,h:0.24,fontSize:10,fontFace:'Calibri',color:DG,bold:true});
      s.addText(c.why,
        {x:7.20,y:cy+0.10,w:5.70,h:0.30,fontSize:9,fontFace:'Calibri',color:MG,italic:true,valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — DORA Metrics (replaces Pipelines slide)
  // Source: sprintData.deployment (workitems-core.json)
  // ══════════════════════════════════════════════════════════════════════════
  _slideDORA(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const dep = (this._sprintData?.deployment) || {};
    const deploysThisWeek = dep.deploysThisWeek || 0;
    const deploysToday    = dep.deploysToday || 0;
    const avgPerDay       = dep.avgDeploysPerDay || 0;
    const mttrH           = dep.mttrHours || 0;
    const pipeRate        = Math.round((dep.pipeRateV2 || 0) * 100);
    const buildMin        = Math.round((dep.avgBuildDuration || 0) / 60);
    const failed          = dep.failedPipelines || 0;
    const flaky           = dep.flakyPipelines || 0;
    const succeeded       = dep.pipeSucceeded || 0;

    const verdict = pipeRate >= 95 && mttrH <= 4 && deploysThisWeek >= 5 ? 'Elite'
                  : pipeRate >= 85 && mttrH <= 24 ? 'High'
                  : pipeRate >= 70 ? 'Medium' : 'Low';
    const verdictColor = verdict === 'Elite' ? G : verdict === 'High' ? G : verdict === 'Medium' ? A : R;

    const title = this._an?.hermes?.slides?.dora?.headline ||
      `DORA: ${verdict} performance — ${deploysThisWeek} deploys this week, ${pipeRate}% pipe success, ${mttrH}h MTTR`;
    const soWhat = this._an?.hermes?.slides?.dora?.soWhat ||
      (verdict === 'Low' || verdict === 'Medium'
        ? `Engineering excellence below industry benchmark — invest in pipeline reliability and deploy automation.`
        : `Engineering excellence at industry-${verdict.toLowerCase()} tier — sustain and push toward Elite.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'DORA Metrics');
    this._kpiStrip(s, [
      {value: deploysThisWeek,  label: 'Deploys/Week',     color: verdictColor},
      {value: `${pipeRate}%`,   label: 'Pipe Success',     color: pipeRate>=90?G:pipeRate>=70?A:R},
      {value: `${mttrH}h`,      label: 'MTTR',             color: mttrH<=4?G:mttrH<=24?A:R},
      {value: failed,           label: 'Failed Pipes',     color: failed===0?G:R},
      {value: `${buildMin}m`,   label: 'Avg Build',        color: T},
      {value: verdict,          label: 'DORA Tier',        color: verdictColor},
    ]);

    // LEFT: Deploy frequency + per-day breakdown
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'DEPLOYMENT FREQUENCY',
      `${deploysToday} deploys today · ${avgPerDay.toFixed(1)}/day average · ${deploysThisWeek} this week`);
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:2.20,w:6.10,h:1.55,fill:{color:'F7F7F5'},line:{color:RL,width:0.5}});
    s.addText(String(deploysThisWeek), {x:0.35,y:2.30,w:6.10,h:0.80,fontSize:60,fontFace:'Calibri',color:verdictColor,bold:true,align:'center'});
    s.addText('Deploys this week', {x:0.35,y:3.10,w:6.10,h:0.22,fontSize:10,fontFace:'Calibri',color:MG,align:'center'});
    s.addText(`Daily cadence: ${avgPerDay.toFixed(1)} deploys/day · DORA Elite benchmark: ≥1/day`,
      {x:0.35,y:3.40,w:6.10,h:0.22,fontSize:9,fontFace:'Calibri',color:DG,align:'center',italic:true});

    // RIGHT: Stability metrics table
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'PIPELINE & MTTR',
      'Change-failure rate and recovery time');
    const stab = [
      ['Pipe success rate', `${pipeRate}%`,          pipeRate>=90?G:pipeRate>=70?A:R, `${succeeded}/${succeeded+failed} runs`],
      ['MTTR (failure→fix)',`${mttrH} hours`,        mttrH<=4?G:mttrH<=24?A:R,         'DORA Elite: <1h'],
      ['Failed pipelines',  String(failed),          failed===0?G:R,                   'Should be 0'],
      ['Flaky pipelines',   String(flaky),           flaky<=2?G:A,                     'Reliability indicator'],
      ['Avg build duration',`${buildMin} min`,       buildMin<=10?G:buildMin<=30?A:R,  'DORA Elite: <10m'],
    ];
    stab.forEach((row, i) => {
      const my = 2.20 + i*0.34;
      s.addText(row[0], {x:6.70,y:my,w:3.30,h:0.30,fontSize:9,fontFace:'Calibri',color:DG,valign:'middle'});
      s.addText(row[1], {x:10.05,y:my,w:1.30,h:0.30,fontSize:11,fontFace:'Calibri',color:row[2],bold:true,align:'right',valign:'middle'});
      s.addText(row[3], {x:11.45,y:my,w:1.45,h:0.30,fontSize:7.5,fontFace:'Calibri',color:MG,italic:true,valign:'middle'});
      s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:my+0.30,w:6.20,h:0.01,fill:{color:LG},line:{type:'none'}});
    });

    // BOTTOM: DORA tier benchmark reference
    this._bottomHead(s, 'DORA INDUSTRY BENCHMARK — WHERE WE STAND');
    const tiers = [
      {tier:'Elite',  freq:'≥1/day',   mttr:'<1h',   pipe:'≥95%', color:G},
      {tier:'High',   freq:'1/week',   mttr:'<24h',  pipe:'≥85%', color:G},
      {tier:'Medium', freq:'1/month',  mttr:'<1wk',  pipe:'≥70%', color:A},
      {tier:'Low',    freq:'<1/month', mttr:'>1wk',  pipe:'<70%', color:R},
    ];
    tiers.forEach((tr, i) => {
      const tx = 0.35 + i*3.18;
      const isCurrent = verdict === tr.tier;
      s.addShape(this.pptx.ShapeType.rect,{x:tx,y:4.50,w:3.05,h:1.85,fill:{color:isCurrent?'EBF5FB':'F7F7F5'},line:{color:isCurrent?N:RL,width:isCurrent?1.5:0.5}});
      s.addText(tr.tier,{x:tx,y:4.58,w:3.05,h:0.34,fontSize:14,fontFace:'Calibri',color:tr.color,bold:true,align:'center'});
      s.addText(`Deploys: ${tr.freq}`,{x:tx+0.12,y:5.00,w:2.85,h:0.30,fontSize:9,fontFace:'Calibri',color:DG});
      s.addText(`MTTR: ${tr.mttr}`,   {x:tx+0.12,y:5.30,w:2.85,h:0.30,fontSize:9,fontFace:'Calibri',color:DG});
      s.addText(`Pipe ≥${tr.pipe}`,   {x:tx+0.12,y:5.60,w:2.85,h:0.30,fontSize:9,fontFace:'Calibri',color:DG});
      if (isCurrent) s.addText('✓ YOU ARE HERE',{x:tx,y:5.95,w:3.05,h:0.30,fontSize:9,fontFace:'Calibri',color:N,bold:true,align:'center'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — AI Recommendations (BIZTECH-side, parallel AI)
  // Source: ops.recommendations + ops.signals from Fetch: Recommendations
  // ══════════════════════════════════════════════════════════════════════════
  _slideBizTechAIRecs(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const recs    = (this._ops?.recommendations || []).slice(0, 8);
    const signals = (this._ops?.signals || []);
    const critical = recs.filter(r => String(r.priority||'').toLowerCase()==='critical').length;
    const high     = recs.filter(r => String(r.priority||'').toLowerCase()==='high').length;
    const avgConf  = recs.length ? Math.round(recs.reduce((s,r)=>s+(r.confidence||0),0)/recs.length*100) : 0;

    // Cross-AI consensus: count Hermes actions whose text overlaps with BIZTECH recs
    const hermesActions = this._an?.hermes?.actions || [];
    const consensus = recs.filter(r => {
      const owner = String(r.owner||'').toLowerCase();
      return owner && hermesActions.some(h => String(h.owner||'').toLowerCase().includes(owner));
    }).length;

    const title = this._an?.hermes?.slides?.biztechAI?.headline ||
      (recs.length === 0
        ? `BIZTECH AI generated no recommendations this period — verify pipeline`
        : `BIZTECH AI flagged ${recs.length} item(s) (avg ${avgConf}% confidence) — ${consensus} overlap with Hermes`);
    const soWhat = this._an?.hermes?.slides?.biztechAI?.soWhat ||
      `Two independent AIs agree on ${consensus} item(s); review those first — high-confidence consensus signals.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'BIZTECH AI Recs');
    this._kpiStrip(s, [
      {value: recs.length,    label: 'Recommendations',  color: T},
      {value: critical,       label: 'Critical',         color: critical>0?R:G},
      {value: high,           label: 'High',             color: high>0?A:G},
      {value: `${avgConf}%`,  label: 'Avg Confidence',   color: avgConf>=80?G:A},
      {value: consensus,      label: 'AI Consensus',     color: consensus>0?G:MG},
      {value: signals.length, label: 'Signals',          color: T},
    ]);

    if (recs.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `ℹ  BIZTECH AI (Mistral Large 3, deterministic-fallback mode) produced no recommendations this run. Check recommendations.json pipeline.`, T);
      return;
    }

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'TOP RECOMMENDATIONS — OWNER-TAGGED, CONFIDENCE-SCORED, WITH AZURE DEVOPS LINKS',
      `Source: recommendations.json · Generated by mistralai/mistral-large-3 (deterministic fallback)`);

    recs.forEach((r, i) => {
      const cy = 2.20 + i*0.55;
      if (cy + 0.50 > 6.50) return;
      const pc = String(r.priority||'').toLowerCase()==='critical' ? R
               : String(r.priority||'').toLowerCase()==='high'     ? A : T;
      const conf = Math.round((r.confidence||0)*100);
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:12.62,h:0.50,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:0.08,h:0.50,fill:{color:pc},line:{type:'none'}});
      s.addText(String(r.priority||'MEDIUM').toUpperCase(),
        {x:0.50,y:cy+0.03,w:1.10,h:0.18,fontSize:8,fontFace:'Calibri',color:pc,bold:true});
      s.addText(this._trunc(r.title || r.action || '—', 65),
        {x:1.65,y:cy+0.03,w:7.50,h:0.20,fontSize:10,fontFace:'Calibri',color:DG,bold:true});
      s.addText(this._trunc(r.action || r.why || '—', 110),
        {x:0.50,y:cy+0.23,w:10.10,h:0.24,fontSize:8,fontFace:'Calibri',color:MG,italic:true});
      s.addText(`${r.owner||'TBD'} · ${r.dueBy||'this week'}`,
        {x:9.20,y:cy+0.03,w:2.40,h:0.20,fontSize:8,fontFace:'Calibri',color:DG,align:'right'});
      s.addText(`${conf}%`,
        {x:11.65,y:cy+0.03,w:1.20,h:0.20,fontSize:11,fontFace:'Calibri',color:conf>=80?G:A,bold:true,align:'right'});
      s.addText('confidence',
        {x:11.65,y:cy+0.23,w:1.20,h:0.16,fontSize:7,fontFace:'Calibri',color:MG,align:'right'});
      // Evidence anchor — recommendations.json's "source" field (deferred T1 item shipped)
      if (r.source || r.evidence?.length) {
        const src = r.source || (r.evidence||[]).slice(0,2).map(e => `${e.label}: ${e.value}`).join(' · ');
        s.addText(`▸ ${this._trunc(src, 110)}`,
          {x:0.50,y:cy+0.40,w:10.20,h:0.10,fontSize:6.5,fontFace:'Calibri',color:MG,italic:true});
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Hygiene Penalty Distribution
  // Source: sprintData.byAssignee[name].penalties + hygiene.violations
  // ══════════════════════════════════════════════════════════════════════════
  _slideHygienePenalties(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';

    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }

    // Aggregate penalties across all owners
    const totals = { no_proof:0, low_desc:0, open_task:0, no_sprint:0, unparented:0, overdue:0, silent_close:0 };
    const perOwner = [];
    for (const p of Object.values(flat)) {
      const pen = p?.penalties || {};
      perOwner.push({
        name: p.name||'Unknown',
        penalties: pen,
        hygiene: p.hygiene?.score || 0,
        violations: p.hygiene?.violations || {},
      });
      for (const k of Object.keys(totals)) totals[k] += Number(pen[k]||0);
    }
    perOwner.sort((a,b) => {
      const aSum = Object.values(a.penalties).reduce((s,v)=>s+Number(v||0),0);
      const bSum = Object.values(b.penalties).reduce((s,v)=>s+Number(v||0),0);
      return bSum - aSum;
    });

    const totalViolations = Object.values(totals).reduce((s,v)=>s+v,0);
    const worstCat = Object.entries(totals).sort((a,b)=>b[1]-a[1])[0] || ['—',0];

    const title = this._an?.hermes?.slides?.hygiene?.headline ||
      (totalViolations === 0
        ? `Hygiene is clean — no penalty violations detected this period`
        : `${totalViolations.toLocaleString()} hygiene penalties across ${perOwner.length} owners — ${worstCat[0]} is the dominant failure mode`);
    const soWhat = this._an?.hermes?.slides?.hygiene?.soWhat ||
      `Penalty distribution is the leading indicator of hygiene-score drift. Address the top failure mode first — it usually unlocks 3-5 cascading violations per owner.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Hygiene Penalties');
    this._kpiStrip(s, [
      {value: totalViolations.toLocaleString(), label: 'Total Violations', color: totalViolations>1000?R:totalViolations>100?A:G},
      {value: totals.no_proof,                  label: 'No Proof',         color: R},
      {value: totals.low_desc,                  label: 'Low Description',  color: A},
      {value: totals.silent_close,              label: 'Silent Closes',    color: totals.silent_close>0?R:G},
      {value: totals.overdue,                   label: 'Overdue',          color: A},
      {value: totals.unparented,                label: 'Orphan Items',     color: A},
    ]);

    // LEFT: Penalty type distribution bar chart
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'PENALTIES BY TYPE',
      `Top failure modes across all ${perOwner.length} owners`);
    const catRows = Object.entries(totals).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v]) => ({label: k.replace(/_/g,' '), value: v}));
    const maxCat = Math.max(...catRows.map(r=>r.value), 1);
    this._hBar(s, 0.35, 2.18, 6.10, catRows, maxCat, null,
      (i, v) => i===0?R : i===1?R : i===2?A : T);

    // RIGHT: Top 6 worst-offender owners
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'TOP OFFENDERS — HIGHEST PENALTY TOTAL',
      `Owners ranked by total penalty volume`);
    const top6 = perOwner.slice(0, 6);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'OWNER',options:{...hdr,align:'left'}},{text:'NO PROOF',options:{...hdr,align:'center'}},
       {text:'LOW DESC',options:{...hdr,align:'center'}},{text:'OVERDUE',options:{...hdr,align:'center'}},
       {text:'HYGIENE',options:{...hdr,align:'center'}}],
      ...top6.map((o, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const np = Number(o.penalties.no_proof||0);
        const ld = Number(o.penalties.low_desc||0);
        const ov = Number(o.penalties.overdue||0);
        return [
          cell(this._trunc(o.name, 22), bg, 'left', N),
          cell(np.toLocaleString(), bg, 'center', np>500?R:np>100?A:DG),
          cell(ld.toLocaleString(), bg, 'center', ld>500?R:ld>100?A:DG),
          cell(ov, bg, 'center', ov>10?R:ov>0?A:G),
          cell(`${o.hygiene}`, bg, 'center', o.hygiene>=70?G:o.hygiene>=50?A:R),
        ];
      }),
    ];
    s.addTable(rows, {x:6.70,y:2.20,w:6.20,rowH:0.26,fontFace:'Calibri',colW:[2.30,1.00,1.00,0.90,1.00]});

    // BOTTOM: Top 3 worst-offender owners with violation deep-links
    this._bottomHead(s, 'TOP 3 OWNER VIOLATION DRILL-DOWN — CLICKABLE WORK-ITEM IDS');
    const topOffenders = perOwner.slice(0, 3);
    if (topOffenders.length === 0) {
      this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
        `✓  No owners with significant penalty totals this period.`, G);
    } else {
      const colW = 12.62 / topOffenders.length;
      topOffenders.forEach((o, i) => {
        const cx = 0.35 + i * colW;
        s.addShape(this.pptx.ShapeType.rect,{x:cx+0.04,y:4.50,w:colW-0.08,h:1.90,fill:{color:'F7F7F5'},line:{color:LG,width:0.5}});
        s.addText(o.name, {x:cx+0.12,y:4.54,w:colW-0.20,h:0.26,fontSize:11,fontFace:'Calibri',color:N,bold:true});
        const violationsObj = (perOwner[i]?.violations) || (Object.values(flat).find(p => p.name === o.name)?.hygiene?.violations) || {};
        // Pick the 4 violation categories with most items
        const categories = Object.entries(violationsObj)
          .filter(([k, v]) => Array.isArray(v) && v.length > 0)
          .map(([k, v]) => ({name: k.replace(/_ids$/,'').replace(/_/g,' '), ids: v}))
          .sort((a,b) => b.ids.length - a.ids.length)
          .slice(0, 4);
        if (categories.length === 0) {
          s.addText('No tracked violations',
            {x:cx+0.12,y:4.86,w:colW-0.20,h:0.30,fontSize:8,fontFace:'Calibri',color:MG,italic:true});
        } else {
          categories.forEach((cat, ci) => {
            const ry = 4.86 + ci * 0.36;
            s.addText(`${cat.name}: ${cat.ids.length} item(s)`,
              {x:cx+0.12,y:ry,w:colW-0.20,h:0.18,fontSize:8,fontFace:'Calibri',color:DG,bold:true});
            const idsText = cat.ids.slice(0, 3).map(id => `#${id}`).join('  ');
            // BUG FIX: pptxgenjs's `addText` rejects {text, options} as the
            // first argument when text is a string ("newObject.text.forEach
            // is not a function"). Use the documented form: text as a string,
            // hyperlink in the OUTER options. The whole rendered text becomes
            // a single hyperlink to the first id (acceptable: per-run links
            // require an array of {text, options} runs).
            const firstId = cat.ids[0];
            const url = `https://example.invalid}`;
            s.addText(idsText,
              {x:cx+0.12,y:ry+0.18,w:colW-0.20,h:0.16,fontSize:8,fontFace:'Calibri',color:T,hyperlink:{url}});
          });
        }
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Health Score Bridge / Waterfall
  // Source: sprintData.healthV2.components
  // ══════════════════════════════════════════════════════════════════════════
  _slideHealthBridge(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const hv2 = this._sprintData?.healthV2 || {};
    const score = hv2.score || this._sprintData?.stats?.healthScore || 0;
    // healthV2.components real shape on Neocities: array of {name, weight, score, ...}
    // OR object {name: {score, weight, ...}}. Both are valid; detect.
    let items = [];
    if (Array.isArray(hv2.components)) {
      items = hv2.components
        .map(c => ({ name: c.label || c.name || '—', value: Number(c.contribution ?? c.score ?? c.value ?? 0) }))
        .filter(c => c.name && c.name !== '—');
    } else if (hv2.components && typeof hv2.components === 'object') {
      items = Object.entries(hv2.components)
        .filter(([k, v]) => v != null && k !== 'score' && k !== 'total')
        .map(([k, v]) => {
          const val = (v && typeof v === 'object')
            ? Number(v.contribution ?? v.score ?? v.value ?? v.delta ?? 0)
            : Number(v);
          return { name: k, value: Number(val) || 0 };
        });
    }
    // Synthesise only if BOTH (a) components empty AND (b) we genuinely have no shape to read
    if (items.length === 0) {
      const st = this._sprintData?.stats || {};
      const total = st.total||0, done=st.done||st.closed||0;
      const sprintCompletion = total>0?Math.round(done/total*100):0;
      const ops = this._ops || {};
      const itsmAgePenalty = -Math.min(20, ops.itsmSummary?.staleOpen||0);
      const prDebtPenalty  = -Math.min(15, ((ops.prs||[]).filter(p=>(p.ageHours||0)>72).length));
      const blockerPenalty = -Math.min(15, (st.blockedItems||[]).length);
      items.push({name:'Sprint completion', value:Math.round(sprintCompletion*0.4)});
      items.push({name:'ITSM aging',        value:itsmAgePenalty});
      items.push({name:'PR debt',           value:prDebtPenalty});
      items.push({name:'Blockers',          value:blockerPenalty});
    }
    // Compute waterfall
    let running = 100;
    const bars = items.map(c => {
      const delta = c.value - 0;
      const prev = running;
      running = Math.max(0, Math.min(100, running + delta));
      return { name: c.name, delta, from: prev, to: running };
    });

    const biggestDrag = [...bars].sort((a,b) => a.delta - b.delta)[0];

    const title = this._an?.hermes?.slides?.healthBridge?.headline ||
      (biggestDrag && biggestDrag.delta < 0
        ? `Health ${score}/100 — ${biggestDrag.name} is the largest drag (${biggestDrag.delta} points)`
        : `Health ${score}/100 — composite score with all components positive`);
    const soWhat = this._an?.hermes?.slides?.healthBridge?.soWhat ||
      (biggestDrag && biggestDrag.delta < 0
        ? `Fixing ${biggestDrag.name} alone would recover ${Math.abs(biggestDrag.delta)} health points; that is the single highest-leverage move this week.`
        : `Health is well-supported across all components — sustain cadence.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Health Bridge');
    this._kpiStrip(s, [
      {value: score, label: 'Health Score', color: score>=70?G:score>=50?A:R},
      {value: items.length, label: 'Components', color: T},
      ...items.slice(0, 4).map(c => ({
        value: (c.value>=0?'+':'') + c.value,
        label: this._trunc(c.name, 14),
        color: c.value>=0?G:c.value>=-5?A:R,
      })),
    ]);

    // BODY: Bridge waterfall — bars from 100 down to score, stepwise
    this._exhibitHead(s, 0.35, 1.84, 12.62, 'HOW WE GOT TO ' + score + '/100',
      `Stepwise composition — every component shown as a delta from the previous`);

    // Render the bridge as horizontal step columns
    const lanes = bars.length + 2; // +2 for start (100) and final (score)
    const laneW = 12.62 / lanes;
    const baseY = 5.50;          // baseline (0 value)
    const topY  = 2.30;          // top of chart (100)
    const yScale = (baseY - topY) / 100;

    // Start bar (100)
    const drawBar = (idx, label, value, isAnchor, color) => {
      const x = 0.35 + idx*laneW;
      const h = Math.abs(value) * yScale;
      const yTop = baseY - (value > 0 ? value : 0) * yScale - (value < 0 ? 0 : 0);
      s.addShape(this.pptx.ShapeType.rect,{x:x+0.10,y:baseY - value*yScale,w:laneW-0.20,h:Math.max(0.04, h),fill:{color},line:{type:'none'}});
      // BUG FIX: text boxes used full laneW so adjacent bar labels touched
      // edge-to-edge. Tightened to laneW-0.20 (matching the bar) and left
      // 0.10" of padding on each side, so labels never touch a neighbor.
      s.addText(String(Math.round(value)), {x:x+0.10,y:baseY - value*yScale - 0.30,w:laneW-0.20,h:0.22,fontSize:10,fontFace:'Calibri',color:N,bold:true,align:'center'});
      s.addText(this._trunc(label, 12), {x:x+0.10,y:baseY + 0.08,w:laneW-0.20,h:0.22,fontSize:8,fontFace:'Calibri',color:DG,align:'center'});
      if (isAnchor) s.addText('▼', {x:x+0.10,y:baseY+0.30,w:laneW-0.20,h:0.18,fontSize:8,fontFace:'Calibri',color:N,align:'center'});
    };

    // Baseline (always 0)
    s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:baseY,w:12.62,h:0.015,fill:{color:'9B9B9B'},line:{type:'none'}});

    drawBar(0, 'Start', 100, true, N);
    bars.forEach((b, i) => {
      drawBar(i+1, b.name, b.delta, false, b.delta >= 0 ? G : R);
    });
    drawBar(lanes-1, 'Final', score, true, score>=70?G:score>=50?A:R);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Sprint-over-Sprint Comparison
  // Source: sprintData.sprints
  // ══════════════════════════════════════════════════════════════════════════
  _slideSprintOverSprint(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const sprints = (this._sprintData?.sprints || []).slice();
    // Sort by start date desc (current first); identify current + previous
    sprints.sort((a,b) => new Date(b.start||b.end||0) - new Date(a.start||a.end||0));
    const current  = sprints.find(s => s.current) || sprints[0] || {};
    const previous = sprints.filter(s => !s.current)[0] || sprints[1] || {};

    const fmt = v => v ?? '—';
    const delta = (now, was) => (typeof now === 'number' && typeof was === 'number' && was !== 0)
      ? Math.round((now - was) / Math.abs(was) * 100) : null;

    const closedNow = current.completedItems || current.closed || 0;
    const closedPrev = previous.completedItems || previous.closed || 0;
    const totalNow = current.totalItems || current.total || 0;
    const totalPrev = previous.totalItems || previous.total || 0;
    const closurePctNow  = totalNow>0 ? Math.round(closedNow/totalNow*100) : 0;
    const closurePctPrev = totalPrev>0 ? Math.round(closedPrev/totalPrev*100) : 0;

    const dClosed   = delta(closedNow, closedPrev);
    const dTotal    = delta(totalNow,  totalPrev);
    const dClosure  = (closurePctNow - closurePctPrev);

    const title = this._an?.hermes?.slides?.sos?.headline ||
      (dClosure >= 5
        ? `Sprint cadence improving — closure rate +${dClosure}pp vs last sprint (${closurePctPrev}% → ${closurePctNow}%)`
        : dClosure <= -5
        ? `Sprint cadence regressing — closure rate ${dClosure}pp vs last sprint (${closurePctPrev}% → ${closurePctNow}%)`
        : `Sprint cadence stable — ${closurePctNow}% closure (Δ${dClosure>=0?'+':''}${dClosure}pp)`);
    const soWhat = this._an?.hermes?.slides?.sos?.soWhat ||
      `SoS reveals cadence (multi-week pattern), WoW reveals freshness (last-7-days delta). Read this together with WoW Top Movers for full direction context.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Sprint-over-Sprint');
    this._kpiStrip(s, [
      {value: `${closurePctNow}%`, label: 'Closure Rate Now', color: closurePctNow>=70?G:closurePctNow>=50?A:R},
      {value: `${dClosure>=0?'+':''}${dClosure}pp`, label: 'Δ Closure SoS', color: dClosure>=0?G:R},
      {value: closedNow, label: 'Items Closed Now', color: T},
      {value: dClosed===null?'—':`${dClosed>=0?'+':''}${dClosed}%`, label: 'Δ Closed SoS', color: (dClosed||0)>=0?G:R},
      {value: totalNow,  label: 'Items Committed', color: T},
      {value: sprints.length, label: 'Sprint History', color: N},
    ]);

    // LEFT: Comparison table — this sprint vs last
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'THIS SPRINT vs LAST SPRINT',
      `Current: ${this._trunc(current.label||'—',24)} · Prev: ${this._trunc(previous.label||'—',24)}`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:9,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const cmpRows = [
      [{text:'METRIC',options:{...hdr,align:'left'}},{text:'LAST',options:{...hdr,align:'center'}},
       {text:'NOW',options:{...hdr,align:'center'}},{text:'Δ',options:{...hdr,align:'center'}}],
      ...[
        ['Committed', totalPrev,    totalNow,    delta(totalNow,totalPrev)],
        ['Closed',    closedPrev,   closedNow,   delta(closedNow,closedPrev)],
        ['Closure %', `${closurePctPrev}%`, `${closurePctNow}%`, `${dClosure>=0?'+':''}${dClosure}pp`],
      ].map((row, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const dv = row[3];
        const dColor = (typeof dv === 'string' ? dv.startsWith('-') : dv < 0) ? R : G;
        return [
          cell(row[0], bg, 'left', N),
          cell(row[1], bg, 'center'),
          cell(row[2], bg, 'center'),
          cell(typeof dv === 'number' ? `${dv>=0?'+':''}${dv}%` : (dv||'—'), bg, 'center', dColor),
        ];
      }),
    ];
    s.addTable(cmpRows, {x:0.35,y:2.20,w:6.10,rowH:0.32,fontFace:'Calibri',colW:[2.20,1.30,1.30,1.30]});

    // RIGHT: Sprint history (last 8) — closure rate sparkline
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'LAST 8 SPRINTS — CLOSURE RATE',
      `Multi-sprint cadence pattern`);
    const last8 = sprints.slice(0, 8).reverse();
    const labels = last8.map(s => this._trunc(s.label||'—', 10));
    const values = last8.map(s => {
      const t = s.totalItems||s.total||0;
      const c = s.completedItems||s.closed||0;
      return t>0 ? Math.round(c/t*100) : 0;
    });
    if (last8.length >= 2 && Math.max(...values) - Math.min(...values) >= 2) {
      s.addChart(this.pptx.ChartType.line, [{name:'Closure %', labels, values}], {
        x:6.70,y:2.20,w:6.20,h:1.95,
        chartColors:[N],
        showLegend:false,showTitle:false,showValue:true,dataLabelFontSize:8,
        valAxisMaxVal:100,valAxisMinVal:0,
        catAxisLabelFontSize:7,valAxisLabelFontSize:7,
        lineSize:2,lineDataSymbol:'circle',lineDataSymbolSize:7,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      s.addText(`Only ${last8.length} sprint(s) in history — need ≥2 with variance for trend.`,
        {x:6.70,y:2.50,w:6.20,h:0.5,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // BOTTOM: Verdict
    this._bottomHead(s, 'SPRINT TRAJECTORY VERDICT');
    const verdict = dClosure >= 10 ? 'IMPROVING' : dClosure >= -10 ? 'STABLE' : 'REGRESSING';
    const vc = verdict==='IMPROVING' ? G : verdict==='STABLE' ? A : R;
    this._calloutBox(s, 0.35, 4.50, 12.62, 0.60,
      `Multi-sprint pattern is ${verdict} — closure rate moved ${dClosure>=0?'+':''}${dClosure} percentage points sprint-over-sprint.`, vc);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Data Source Health
  // Source: ops.dataContractReport (new fetch)
  // ══════════════════════════════════════════════════════════════════════════
  _slideDataSourceHealth(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    // Prefer foundation-exposed gov.dataTrust.sources (already on Neocities — no
    // new fetch needed). Falls back to data-contract-report when that wires.
    const govDt = this._ops?.govDataTrustFull || {};
    const govSources = Array.isArray(govDt.sources) ? govDt.sources : [];

    const now = Date.now();
    let sources;
    if (govSources.length > 0) {
      sources = govSources.map(src => {
        const generatedAt = src.generatedAt ? new Date(src.generatedAt) : null;
        const ageHours = generatedAt ? Math.round((now - generatedAt.getTime()) / 3600000) : null;
        const rows = src.rowCount || 0;
        return {
          name: src.file || src.name || '—',
          rows, ageHours,
          generatedAt: src.generatedAt,
          status: src.status || 'unknown',
          missingFields: (src.missingFields || []),
          warnings: (src.warnings || []),
        };
      });
    } else {
      const dcr = this._ops?.dataContractReport || {};
      const files = dcr.files || {};
      sources = Object.entries(files).map(([name, info]) => {
        const generatedAt = info.generatedAt ? new Date(info.generatedAt) : null;
        const ageHours = generatedAt ? Math.round((now - generatedAt.getTime()) / 3600000) : null;
        const rows = info.rows || info.count || info.total || 0;
        return { name, ageHours, rows, generatedAt: info.generatedAt, status: 'unknown', missingFields: [], warnings: [] };
      });
    }
    const fileEntries = sources;
    const issueCount = sources.filter(s => s.status !== 'healthy' || s.missingFields.length || s.warnings.length).length;
    const stale = sources.filter(s => s.ageHours != null && s.ageHours > 24).length;

    const title = this._an?.hermes?.slides?.dataHealth?.headline ||
      (fileEntries.length === 0
        ? `Data contract report unavailable — Fetch: Data Contract Report node not wired or upstream missing`
        : issueCount > 0
        ? `${issueCount} data-contract issue(s) and ${stale} stale source(s) — verify freshness before sharing`
        : `Data contract clean — ${fileEntries.length} sources, ${stale} stale, ${issueCount} issues`);
    const soWhat = this._an?.hermes?.slides?.dataHealth?.soWhat ||
      `Source freshness calibrates trust in everything downstream. If any source is >24h old, downstream slides reflect old reality.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Data Source Health');
    this._kpiStrip(s, [
      {value: fileEntries.length, label: 'Sources',        color: T},
      {value: stale,              label: 'Stale (>24h)',   color: stale>0?R:G},
      {value: issueCount,         label: 'Contract Issues',color: issueCount>0?R:G},
      {value: sources.filter(s => s.ageHours != null && s.ageHours < 6).length, label: 'Fresh (<6h)', color: G},
      {value: sources.reduce((s,x)=>s+(x.rows||0),0).toLocaleString(), label: 'Total Rows', color: T},
      {value: sources.length ? Math.round(sources.reduce((s,x)=>s+(x.ageHours||0),0)/sources.length) + 'h' : '—', label: 'Avg Age', color: A},
    ]);

    if (fileEntries.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `ℹ  Data source health unavailable — neither gov.dataTrust.sources nor data-contract-report.json populated.`, T);
      return;
    }

    // BODY: Per-source row with status + missing fields + warnings
    this._exhibitHead(s, 0.35, 1.84, 12.62, 'SOURCE FRESHNESS & CONTRACT STATUS',
      `From governance.dataTrust.sources — ${fileEntries.length} sources tracked`);

    const visibleSources = sources.slice(0, 10);
    visibleSources.forEach((src, i) => {
      const sy = 2.26 + i * 0.42;
      if (sy + 0.36 > 6.40) return;
      const statusColor = src.status === 'healthy' ? G
                       : src.status === 'warning' ? A
                       : src.status === 'failure' ? R : MG;
      const ageColor = src.ageHours == null ? MG : src.ageHours > 168 ? R : src.ageHours > 24 ? A : G;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:sy,w:12.62,h:0.36,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:sy,w:0.08,h:0.36,fill:{color:statusColor},line:{type:'none'}});
      s.addText(src.name, {x:0.50,y:sy,w:3.40,h:0.36,fontSize:10,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(`${(src.rows||0).toLocaleString()} rows`, {x:3.95,y:sy,w:1.60,h:0.36,fontSize:9,fontFace:'Calibri',color:DG,valign:'middle'});
      s.addText((src.status||'?').toUpperCase(), {x:5.60,y:sy,w:1.20,h:0.36,fontSize:9,fontFace:'Calibri',color:statusColor,bold:true,valign:'middle'});
      const issues = [];
      if (src.missingFields.length) issues.push(`${src.missingFields.length} missing field(s)`);
      if (src.warnings.length)      issues.push(`${src.warnings.length} warning(s)`);
      s.addText(issues.join(' · ') || 'no issues',
        {x:6.85,y:sy,w:3.40,h:0.36,fontSize:9,fontFace:'Calibri',color:issues.length?A:MG,italic:!issues.length,valign:'middle'});
      s.addText(src.ageHours == null ? '—' : `${src.ageHours}h ago`,
        {x:10.30,y:sy,w:2.60,h:0.36,fontSize:9,fontFace:'Calibri',color:ageColor,bold:true,align:'right',valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Azure Quality
  // Source: sprintData.azureQuality
  // ══════════════════════════════════════════════════════════════════════════
  _slideAzureQuality(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    // Prefer the foundation-exposed azureQuality from opsData (full structure),
    // fall back to sprintData if foundation hasn't propagated yet
    const aq = this._ops?.azureQuality || this._sprintData?.azureQuality || {};
    const score = aq.score || 0;
    const metrics = aq.metrics || {};
    const byAssignee = aq.byAssignee || {};
    const byFy = aq.by_fy || {};

    const title = this._an?.hermes?.slides?.azureQuality?.headline ||
      `Azure DevOps quality score: ${score}/100 — automated gates ${score>=80?'passing':score>=60?'borderline':'failing'}`;
    const soWhat = this._an?.hermes?.slides?.azureQuality?.soWhat ||
      `Different from hygiene (process discipline): this is correctness — auto-checks on work items, branch policies, build gates, PR validations.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Azure Quality');
    const metricEntries = Object.entries(metrics).slice(0, 5);
    // BUG FIX: when `v` was an object like {score, count, total, max, failedIds}
    // the previous code did `String(v||'—')` → "[object Object]" rendered as
    // KPI value. Now extract a meaningful scalar from the object: prefer
    // .score, then .count, then .value; fall back to '—' if nothing usable.
    const kpiVal = (v) => {
      if (typeof v === 'number' || typeof v === 'string') return v;
      if (v && typeof v === 'object') {
        if (typeof v.score === 'number') return v.score.toFixed(1);
        if (typeof v.count === 'number') return v.count;
        if (typeof v.value === 'number') return v.value;
        if (typeof v.total === 'number') return v.total;
      }
      return '—';
    };
    this._kpiStrip(s, [
      {value: score, label: 'Quality Score', color: score>=80?G:score>=60?A:R},
      ...metricEntries.map(([k,v]) => ({value: kpiVal(v), label: this._trunc(k, 14), color: T})),
      ...(metricEntries.length < 5 ? Array(5-metricEntries.length).fill({value:'—',label:'—',color:MG}) : []),
    ].slice(0, 6));

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'QUALITY BY ASSIGNEE',
      `Top ${Math.min(8, Object.keys(byAssignee).length)} owners by quality score`);
    const owners = Object.entries(byAssignee)
      .map(([name, v]) => ({name, score: typeof v === 'object' ? (v.score || 0) : Number(v)||0}))
      .sort((a,b) => b.score - a.score)
      .slice(0, 8);
    if (owners.length > 0) {
      const maxS = Math.max(...owners.map(o=>o.score), 100);
      this._hBar(s, 0.35, 2.18, 6.10, owners.map(o=>({label:o.name,value:o.score})), maxS, null,
        (i, v) => v >= 80 ? G : v >= 60 ? A : R);
    } else {
      s.addText('No per-assignee quality data this period.', {x:0.35,y:2.50,w:6.10,h:0.4,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BY FY — TREND',
      `Quality score by fiscal year`);
    const fyRows = Object.entries(byFy).map(([fy, v]) => ({label: fy, value: typeof v === 'object' ? (v.score||0) : Number(v)||0}));
    if (fyRows.length > 0) {
      const maxFy = Math.max(...fyRows.map(r=>r.value), 100);
      this._hBar(s, 6.70, 2.18, 6.20, fyRows, maxFy, null, (i,v)=>v>=80?G:v>=60?A:R);
    } else {
      s.addText('FY breakdown not available.', {x:6.70,y:2.50,w:6.20,h:0.4,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // BOTTOM: per-metric breakdown when full metrics object is available
    this._bottomHead(s, 'QUALITY GATE BREAKDOWN — METRIC BY METRIC');
    const metricEntries2 = Object.entries(metrics).slice(0, 8);
    if (metricEntries2.length > 0) {
      const noLine={type:'none'}, hl={pt:0.3,color:LG};
      const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
      const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:9,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
      const rows = [
        [{text:'METRIC',options:{...hdr,align:'left'}},{text:'FAILED',options:{...hdr,align:'center'}},
         {text:'TOTAL',options:{...hdr,align:'center'}},{text:'SCORE',options:{...hdr,align:'center'}},
         {text:'MAX',options:{...hdr,align:'center'}},{text:'EXAMPLES (top 3 IDs)',options:{...hdr,align:'left'}}],
        ...metricEntries2.map(([name, v], ri) => {
          const bg = ri%2===0?'FFFFFF':'F7F7F5';
          if (typeof v !== 'object') {
            return [cell(name,bg,'left',N), cell('—',bg,'center'), cell('—',bg,'center'),
                    cell(String(v),bg,'center'), cell('—',bg,'center'), cell('—',bg,'left')];
          }
          const failedIds = (v.failedIds||[]).slice(0, 3).map(id => `#${id}`).join(', ');
          const pct = (v.total||0) > 0 ? Math.round(((v.total - (v.count||0))/v.total)*100) : null;
          return [
            cell(name, bg, 'left', N),
            cell(v.count ?? '—', bg, 'center', (v.count||0)>0?R:G),
            cell(v.total ?? '—', bg, 'center'),
            cell(v.score != null ? v.score.toFixed(1) : '—', bg, 'center', (v.score||0)>=(v.max||0)*0.8?G:A),
            cell(v.max ?? '—', bg, 'center'),
            cell(failedIds || '—', bg, 'left', MG),
          ];
        }),
      ];
      s.addTable(rows, {x:0.35,y:4.50,w:12.62,rowH:0.24,fontFace:'Calibri',colW:[2.90,1.20,1.20,1.20,1.00,5.12]});
    } else {
      s.addText('Per-metric breakdown not available in azureQuality.metrics.',
        {x:0.35,y:4.60,w:12.62,h:0.40,fontSize:10,fontFace:'Calibri',color:MG,italic:true,align:'center'});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Channel & Type Pyramid
  // Source: ops.mprFull (needs Transform to expose)
  // ══════════════════════════════════════════════════════════════════════════
  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Volume Trends (mpr_data.weekly_volume + weekly_approvals)
  // Replaces the speculative "MPR Channels & Types" which targeted fields
  // that don't exist on Neocities. by_channel / by_type were never published.
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRChannelType(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const mpr = this._ops?.mprFull || {};
    const weekly = Array.isArray(mpr.weekly_volume) ? mpr.weekly_volume : [];
    // Take last 16 weeks (most recent first in source — reverse for chart)
    const last16 = [...weekly].slice(-16);
    const labels = last16.map(w => {
      try { const d = new Date(w.week_start); return d.toLocaleDateString('en-IN',{month:'short',day:'numeric'}); }
      catch { return `W${w.financial_week||'?'}`; }
    });
    const reported = last16.map(w => Number(w.cases_reported)||0);
    const closed   = last16.map(w => Number(w.cases_closed)||0);
    const netFlow  = last16.map((_, i) => closed[i] - reported[i]);
    const cumIn    = last16.map(w => Number(w.cum_inflow)||0);
    const cumClose = last16.map(w => Number(w.cum_closed)||0);

    const recentReported = reported.slice(-4).reduce((s,v)=>s+v,0);
    const recentClosed   = closed.slice(-4).reduce((s,v)=>s+v,0);
    const recentNet      = recentClosed - recentReported;
    const totalBacklog   = (cumIn[cumIn.length-1]||0) - (cumClose[cumClose.length-1]||0);

    const title = this._an?.hermes?.slides?.mprVolume?.headline ||
      (last16.length === 0
        ? `MPR weekly volume unavailable — no weekly_volume data`
        : recentNet >= 0
        ? `MPR closure outpacing intake — net +${recentNet} cases over last 4 weeks (${recentClosed} closed / ${recentReported} reported)`
        : `MPR backlog growing — net ${recentNet} cases over last 4 weeks; intake ahead of closure`);
    const soWhat = this._an?.hermes?.slides?.mprVolume?.soWhat ||
      `Backlog burn-down depends on weekly close-rate exceeding weekly inflow. A persistent negative net-flow means the team is falling behind structurally, not cyclically.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR Volume Trends');
    this._kpiStrip(s, [
      {value: weekly.length, label: 'Weeks Tracked', color: N},
      {value: recentReported, label: 'Reported (4w)', color: A},
      {value: recentClosed, label: 'Closed (4w)', color: G},
      {value: `${recentNet>=0?'+':''}${recentNet}`, label: 'Net Flow (4w)', color: recentNet>=0?G:R},
      {value: totalBacklog.toLocaleString(), label: 'Running Backlog', color: totalBacklog>500?R:totalBacklog>100?A:G},
      {value: cumIn[cumIn.length-1]?.toLocaleString() || '—', label: 'Cum Inflow', color: T},
    ]);

    if (last16.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `ℹ  mpr_data.weekly_volume is empty for this period.`, T);
      return;
    }

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'WEEKLY INFLOW vs CLOSURE — LAST 16 WEEKS',
      `Source: mpr_data.weekly_volume`);
    s.addChart(this.pptx.ChartType.bar, [
      { name:'Reported', labels, values: reported },
      { name:'Closed',   labels, values: closed   },
    ], {
      x:0.35,y:2.20,w:12.62,h:1.95,
      barDir:'col',barGrouping:'clustered',
      chartColors:[A, G],
      showLegend:true, legendPos:'r', legendFontSize:9,
      showTitle:false, showValue:false,
      catAxisLabelFontSize:8, valAxisLabelFontSize:8,
      plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
    });

    this._bottomHead(s, 'CUMULATIVE BACKLOG TRAJECTORY — RUNNING DIFFERENCE');
    s.addChart(this.pptx.ChartType.line, [
      { name:'Cumulative Inflow', labels, values: cumIn },
      { name:'Cumulative Closed', labels, values: cumClose },
    ], {
      x:0.35,y:4.50,w:12.62,h:1.95,
      chartColors:[A, G],
      showLegend:true, legendPos:'r', legendFontSize:9,
      showTitle:false, showValue:false,
      catAxisLabelFontSize:8, valAxisLabelFontSize:8,
      lineSize:2.5, lineDataSymbol:'circle', lineDataSymbolSize:6,
      plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Operational Index
  // Source: ops.govOpsSummary + ops.govOpIndexItems
  // ══════════════════════════════════════════════════════════════════════════
  _slideOperationalIndex(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const sum = this._ops?.govOpsSummary || {};
    // govOpIndexItems can be 9,000+ items now that we expose full data.
    // Real shape: { source, priority, lifecycle, owner, account, title, riskScore? }
    // Filter strategy: only open lifecycle, priority Critical/High, ranked by riskScore desc
    const all = this._ops?.govOpIndexItems || [];
    const isOpen = it => {
      const lc = String(it.lifecycle || it.status || '').toLowerCase();
      return lc && !['closed','resolved','done','cancelled','completed'].includes(lc);
    };
    const priRank = p => ({critical:0, high:1, medium:2, low:3, normal:3}[String(p||'').toLowerCase()] ?? 9);
    const ranked = [...all]
      .filter(isOpen)
      .filter(it => ['critical','high','medium'].includes(String(it.priority||'').toLowerCase()))
      .sort((a, b) => {
        const dp = priRank(a.priority) - priRank(b.priority);
        if (dp !== 0) return dp;
        return (b.riskScore || 0) - (a.riskScore || 0);
      });

    // Group by source for breakdown
    const bySource = {};
    for (const it of ranked) {
      const sk = it.source || 'Unknown';
      bySource[sk] = (bySource[sk] || 0) + 1;
    }
    const sourceRows = Object.entries(bySource)
      .map(([name, count]) => ({name, count, percent: ranked.length>0 ? Math.round(count/ranked.length*100) : 0}))
      .sort((a,b) => b.count - a.count)
      .slice(0, 6);

    const critN = ranked.filter(it => String(it.priority).toLowerCase()==='critical').length;
    const highN = ranked.filter(it => String(it.priority).toLowerCase()==='high').length;
    const score = sum.score ?? sum.total ?? 0;
    const status = score >= 75 ? 'Healthy' : score >= 50 ? 'Watch' : 'At Risk';
    const statusColor = score >= 75 ? G : score >= 50 ? A : R;

    const title = this._an?.hermes?.slides?.opIndex?.headline ||
      (ranked.length === 0
        ? `Operational Index empty — no open critical/high items across tracked sources`
        : `${ranked.length} open critical/high items across ${sourceRows.length} sources — ${critN} CRITICAL needing immediate attention`);
    const soWhat = this._an?.hermes?.slides?.opIndex?.soWhat ||
      `These are the cross-domain items flagged by governance as carrying operational risk. Sorted by priority then riskScore — top of list first.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Operational Index');
    this._kpiStrip(s, [
      {value: ranked.length, label: 'Open High-Pri Items', color: ranked.length>100?R:A},
      {value: critN, label: 'Critical', color: critN>0?R:G},
      {value: highN, label: 'High', color: highN>0?A:G},
      {value: sourceRows.length, label: 'Active Sources', color: T},
      {value: all.length.toLocaleString(), label: 'Total Indexed', color: N},
      {value: score, label: 'Op-Index Score', color: statusColor},
    ]);

    // LEFT: source breakdown
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'BY SOURCE — WHERE RISK CONCENTRATES',
      `${ranked.length.toLocaleString()} open high-pri items across ${sourceRows.length} sources`);
    this._drawDistribution(s, 0.35, 2.20, 6.10, 2.00, sourceRows, { palette: [R, A, T, N, G, MG] });

    // RIGHT: top 10 open critical/high items table
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'TOP 10 ITEMS BY PRIORITY & RISK',
      `Ranked by priority, then riskScore`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const top10 = ranked.slice(0, 10);
    const rows = [
      [{text:'PRI',options:{...hdr,align:'center'}},{text:'SOURCE',options:{...hdr,align:'center'}},
       {text:'TITLE',options:{...hdr,align:'left'}},{text:'OWNER',options:{...hdr,align:'left'}}],
      ...top10.map((it, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const p = String(it.priority||'').toLowerCase();
        const pc = p==='critical' ? R : p==='high' ? A : T;
        return [
          cell((it.priority||'').slice(0,4).toUpperCase(), bg, 'center', pc),
          cell(this._trunc(it.source||'—', 10), bg, 'center', N),
          cell(this._trunc(it.title||'—', 28), bg, 'left'),
          cell(this._trunc(it.owner || it.assignee || '—', 16), bg, 'left'),
        ];
      }),
    ];
    s.addTable(rows, {x:6.70,y:2.20,w:6.20,rowH:0.22,fontFace:'Calibri',colW:[0.70,1.10,2.80,1.60]});

    // BOTTOM: source × priority pivot
    this._bottomHead(s, 'SOURCE × PRIORITY DISTRIBUTION');
    const sources = sourceRows.map(r => r.name);
    const priorities = ['Critical','High','Medium'];
    const pivot = {};
    for (const it of ranked) {
      const sk = it.source || 'Unknown';
      const pk = (it.priority||'').replace(/^./, c => c.toUpperCase());
      if (sources.includes(sk) && priorities.includes(pk)) {
        pivot[`${sk}|${pk}`] = (pivot[`${sk}|${pk}`] || 0) + 1;
      }
    }
    const maxCell = Math.max(...Object.values(pivot), 1);
    this._drawHeatmap(s, 0.35, 4.55, 12.62, 1.85, [], {
      rows: sources, cols: priorities, max: maxCell,
      lookup: (r, c) => pivot[`${r}|${c}`] || 0,
      cornerLabel: 'SOURCE ↓ / PRIORITY →',
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Alert Volume Trend
  // Source: weeklyHistory + sprintData.alertCount + alertsByOwner
  // ══════════════════════════════════════════════════════════════════════════
  _slideAlertVolume(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    // BUG FIX: previous slide showed "30 active alerts" with empty by-owner
    // panel and uninformative line chart. Now drills into the alerts ARRAY
    // for: type breakdown, severity breakdown, owner concentration, and a
    // recent-alert worklist with IDs + ages so triage is actionable.
    const alerts = Array.isArray(this._sprintData?.alerts) ? this._sprintData.alerts : [];
    const cur = alerts.length || this._sprintData?.alertCount || 0;
    const trend = this._sprintData?.alertTrend || 0;

    // Type breakdown
    const byType = {}, bySev = {};
    for (const a of alerts) {
      const tk = a.type || 'unknown'; byType[tk] = (byType[tk]||0)+1;
      const sv = a.severity || a.priority || 'normal'; bySev[sv] = (bySev[sv]||0)+1;
    }
    const typeRows = Object.entries(byType).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([n,v])=>({label:n,value:v}));
    const sevRows  = Object.entries(bySev).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,v])=>({label:n,value:v}));

    // Owner breakdown — read from alertsByOwner first, fall back to deriving from alerts[]
    const byOwnerRaw = this._sprintData?.alertsByOwner || {};
    const byOwner = {};
    for (const [k,v] of Object.entries(byOwnerRaw)) byOwner[k] = typeof v === 'object' ? (v.count||v.total||0) : Number(v)||0;
    if (Object.keys(byOwner).length === 0) {
      for (const a of alerts) {
        const o = a.owner || a.assignee || a.assignedTo || 'Unassigned';
        byOwner[o] = (byOwner[o]||0) + 1;
      }
    }
    const ownerRows = Object.entries(byOwner).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([n,v])=>({label:n,value:v}));

    // Worklist — top 5 alerts by age
    const worklist = [...alerts].sort((a,b) => (b.age || b.ageHours || 0) - (a.age || a.ageHours || 0)).slice(0, 5);

    const direction = trend > 0 ? 'rising' : trend < 0 ? 'falling' : 'flat';
    const topType = typeRows[0]?.label;
    const title = this._an?.hermes?.slides?.alertVolume?.headline ||
      (cur === 0
        ? `Alert system quiet — no active alerts this period`
        : `${cur} alert(s) ${direction} (${trend>=0?'+':''}${trend} WoW) — top type: ${topType||'—'} (${typeRows[0]?.value||0})`);
    const soWhat = this._an?.hermes?.slides?.alertVolume?.soWhat ||
      `Type breakdown reveals what's most often firing; owner concentration reveals who carries the operational noise. Triage worklist below: oldest first.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Alert Volume');
    this._kpiStrip(s, [
      {value: cur, label: 'Active Alerts', color: cur>10?R:cur>5?A:G},
      {value: `${trend>=0?'+':''}${trend}`, label: 'Δ vs Last Run', color: trend<=0?G:R},
      {value: typeRows.length, label: 'Alert Types', color: T},
      {value: this._trunc(topType||'—', 12), label: 'Top Type', color: A},
      {value: ownerRows.length, label: 'Owners Hit', color: T},
      {value: ownerRows[0]?.label ? this._trunc(ownerRows[0].label, 12) : '—', label: 'Top Owner', color: ownerRows[0]?.value>5?R:T},
    ]);

    // ── LEFT: Type distribution
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'ALERT TYPE DISTRIBUTION',
      `${typeRows.length} types · ${cur} total`);
    if (typeRows.length > 0) {
      const mx = Math.max(...typeRows.map(r=>r.value), 1);
      this._hBar(s, 0.35, 2.18, 6.10, typeRows, mx, null, (i)=>i===0?R:i===1?A:T);
    } else {
      s.addText('No alert type data.', {x:0.35,y:2.40,w:6.10,h:0.4,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // ── RIGHT: Owner distribution
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BY OWNER — CONCENTRATION',
      `${ownerRows.length} owners · top owner has ${ownerRows[0]?.value||0}`);
    if (ownerRows.length > 0) {
      const mx = Math.max(...ownerRows.map(r=>r.value), 1);
      this._hBar(s, 6.70, 2.18, 6.20, ownerRows, mx, null, (i,v)=>v>=5?R:v>=2?A:T);
    } else {
      s.addText('No per-owner alert data.', {x:6.70,y:2.40,w:6.20,h:0.4,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // ── BOTTOM: Triage worklist
    this._bottomHead(s, 'TRIAGE WORKLIST — OLDEST 5 ACTIVE ALERTS');
    if (worklist.length > 0) {
      const noLine={type:'none'}, hl={pt:0.3,color:LG};
      const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:8,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
      const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
      const rows = [
        [{text:'ID',options:{...hdr,align:'center'}},{text:'TYPE',options:{...hdr,align:'left'}},
         {text:'SEVERITY',options:{...hdr,align:'center'}},{text:'OWNER',options:{...hdr,align:'left'}},
         {text:'AGE',options:{...hdr,align:'center'}},{text:'MESSAGE',options:{...hdr,align:'left'}}],
        ...worklist.map((a, ri) => {
          const bg = ri%2===0?'FFFFFF':'F7F7F5';
          const ageH = a.age || a.ageHours || 0;
          const sv = String(a.severity || a.priority || 'normal');
          return [
            cell(a.id || a.alertId || '—', bg, 'center', N),
            cell(this._trunc(a.type||'—', 18), bg, 'left'),
            cell(sv, bg, 'center', /critical|p1|high/i.test(sv)?R:/warn|med/i.test(sv)?A:T),
            cell(this._trunc(a.owner || a.assignee || '—', 18), bg, 'left'),
            cell(`${Math.round(ageH)}h`, bg, 'center', ageH>=72?R:ageH>=24?A:G),
            cell(this._trunc(a.message || a.title || a.description || '—', 60), bg, 'left', MG),
          ];
        }),
      ];
      s.addTable(rows, {x:0.35,y:4.55,w:12.62,rowH:0.30,fontFace:'Calibri',colW:[1.20,2.20,1.30,2.20,0.90,4.82]});
    } else {
      s.addText('No active alerts to triage.', {x:0.35,y:4.80,w:12.62,h:0.40,fontSize:10,fontFace:'Calibri',color:G,italic:true,align:'center'});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Owner Deep-Link Dossier
  // Source: ops.signals[].links + burnout-risk owner ranking
  // ══════════════════════════════════════════════════════════════════════════
  _slideOwnerDossier(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';

    // Top 3 burnout-risk owners
    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }
    const owners = Object.values(flat)
      .filter(p => p && (p.active || p.stale))
      .map(p => ({ name: p.name, ...this._burnoutIndex({active:p.active, stale:p.stale, blocked:p.blocked}), violations: p.hygiene?.violations || {} }))
      .sort((a,b) => b.index - a.index)
      .slice(0, 3);

    const signals = this._ops?.signals || [];
    const signalsByOwner = {};
    for (const sg of signals) {
      const o = String(sg.owner||'').toLowerCase();
      if (!signalsByOwner[o]) signalsByOwner[o] = [];
      signalsByOwner[o].push(sg);
    }

    const title = this._an?.hermes?.slides?.dossier?.headline ||
      (owners.length === 0
        ? `No high-burnout owners to dossier this week`
        : `Action dossier: top ${owners.length} burnout-risk owner(s) with deep links to their stale work`);
    const soWhat = this._an?.hermes?.slides?.dossier?.soWhat ||
      `Each item below has a direct Azure DevOps URL. Click through to triage — no need to search.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Owner Dossier');
    this._kpiStrip(s, [
      {value: owners.length, label: 'Owners Dossiered', color: T},
      ...owners.slice(0,3).map(o => ({value: o.name, label: `Burnout ${o.tier}`, color: o.tier==='HIGH'?R:o.tier==='MED'?A:G})),
      ...(owners.length < 3 ? Array(3-owners.length).fill({value:'—',label:'—',color:MG}) : []),
      {value: signals.length, label: 'Total Signals', color: T},
      {value: signals.filter(sg => (sg.links||[]).length).length, label: 'With Links', color: G},
    ].slice(0, 6));

    if (owners.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `✓  Burnout indices all below MED tier this week — no dossier required. Sustain.`, G);
      return;
    }

    // Each owner gets a vertical band
    const colW = 12.62 / owners.length;
    owners.forEach((o, i) => {
      const cx = 0.35 + i*colW;
      const sgs = signalsByOwner[String(o.name||'').toLowerCase()] || [];
      const itemsList = (o.violations.stale_ids || []).slice(0, 8);

      s.addShape(this.pptx.ShapeType.rect,{x:cx+0.04,y:1.80,w:colW-0.08,h:4.60,fill:{color:'F7F7F5'},line:{color:LG,width:0.5}});
      s.addText(o.name, {x:cx+0.12,y:1.86,w:colW-0.20,h:0.34,fontSize:13,fontFace:'Calibri',color:N,bold:true});
      s.addText(`Burnout ${o.tier} · index ${o.index}`,
        {x:cx+0.12,y:2.22,w:colW-0.20,h:0.20,fontSize:9,fontFace:'Calibri',color:o.tier==='HIGH'?R:o.tier==='MED'?A:G});
      s.addText('STALE WORK ITEMS (click in DevOps)',
        {x:cx+0.12,y:2.52,w:colW-0.20,h:0.20,fontSize:8,fontFace:'Calibri',color:MG,bold:true});
      itemsList.forEach((id, j) => {
        const ly = 2.78 + j*0.28;
        const url = `https://example.invalid}`;
        // Same pptxgenjs gotcha as Hygiene Penalties — pass hyperlink in outer options
        s.addText(`#${id}`,
          {x:cx+0.12,y:ly,w:colW-0.20,h:0.24,fontSize:10,fontFace:'Calibri',color:T,bold:true,hyperlink:{url}});
      });
      if (sgs.length > 0) {
        s.addText(`+ ${sgs.length} signal(s) with structured links`,
          {x:cx+0.12,y:6.05,w:colW-0.20,h:0.20,fontSize:8,fontFace:'Calibri',color:MG,italic:true});
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Sprint Trajectory (closed vs committed over 8 sprints)
  // Source: sprintData.sprints
  // ══════════════════════════════════════════════════════════════════════════
  _slideSprintTrajectory(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';

    // Sprint history shape on Neocities (workitems-core.json → sprints[]):
    //   [{label, path, start, end, current}]
    // Note: per-sprint completion counts (totalItems / completedItems) are
    // NOT exported per sprint upstream — only the CURRENT sprint carries
    // those (in sprintData.sprint). So we backfill the most-recent entry
    // from sprintData.sprint and render the rest as labels with a clear
    // "data pending upstream aggregation" status.
    const sprints = (this._sprintData?.sprints || []).slice();
    sprints.sort((a,b) => new Date(a.start||a.end||0) - new Date(b.start||b.end||0));
    const last8 = sprints.slice(-8);

    // Backfill the most-recent sprint entry with current-sprint counts
    // when its label/path matches what the current sprint carries.
    const cur = this._sprintData?.sprint || {};
    const curLabel = cur.name || cur.label;
    last8.forEach(sp => {
      const labelMatch = curLabel && (sp.label === curLabel || sp.path === cur.path);
      const isCurrentFlag = sp.current === true;
      if ((labelMatch || isCurrentFlag) && (cur.totalItems != null || cur.completedItems != null)) {
        sp._backfilled = true;
        if (sp.totalItems == null)     sp.totalItems = cur.totalItems     || 0;
        if (sp.completedItems == null) sp.completedItems = cur.completedItems || 0;
      }
    });

    // BUG FIX: previously sprint labels were truncated to 10 chars producing
    // "Sprint 2.." — bumped to 18 to fit "Sprint 2026.05".
    const labels       = last8.map(s => this._trunc(s.label || '—', 18));
    const committed    = last8.map(s => s.totalItems || s.total || 0);
    const closed       = last8.map(s => s.completedItems || s.closed || 0);
    const hasCount     = last8.map(s => (s.totalItems != null) || (s.completedItems != null));
    const totalCommitted = committed.reduce((a,b)=>a+b,0);
    const totalClosed    = closed.reduce((a,b)=>a+b,0);
    const sprintsWithData = hasCount.filter(Boolean).length;
    const overallRate    = totalCommitted>0 ? Math.round(totalClosed/totalCommitted*100) : 0;

    // Three states for this slide:
    //   1. NO sprints array at all → tell user to wire upstream
    //   2. Sprints array present BUT no per-sprint counts → show labels +
    //      explain upstream aggregation gap; render current sprint actuals
    //   3. Full per-sprint counts → render the trajectory chart proper
    const noHistory = last8.length === 0;
    const labelsOnly = last8.length > 0 && totalCommitted === 0 && totalClosed === 0;
    const fullData   = !noHistory && !labelsOnly;
    // For trend math we only count sprints with real data
    const dataSeries = last8.map((s, i) => ({label: s.label, c: committed[i], d: closed[i], hasC: hasCount[i]})).filter(x => x.hasC && (x.c > 0 || x.d > 0));
    const trend = dataSeries.length >= 2
      ? Math.round(dataSeries[dataSeries.length-1].d / Math.max(dataSeries[dataSeries.length-1].c,1) * 100)
        - Math.round(dataSeries[0].d / Math.max(dataSeries[0].c,1) * 100)
      : 0;

    const title = this._an?.hermes?.slides?.trajectory?.headline ||
      (noHistory
        ? `Sprint history unavailable — sprintData.sprints[] not in payload (check Transform node)`
        : labelsOnly
        ? `Sprint history present (${last8.length} of ${sprints.length}) — per-sprint completion counts pending upstream aggregation`
        : fullData && trend >= 5
        ? `Sprint trajectory improving — closure rate +${trend}pp across last ${last8.length} sprints`
        : fullData && trend <= -5
        ? `Sprint trajectory regressing — closure rate ${trend}pp across last ${last8.length} sprints`
        : `Sprint trajectory at ${overallRate}% closure across ${dataSeries.length} sprint(s) with data`);

    const soWhat = this._an?.hermes?.slides?.trajectory?.soWhat ||
      (labelsOnly
        ? `Neocities exports sprint metadata (32 sprints) but not per-sprint completion counts — extending workitems-core.json with by-iteration rollups would unlock the full trajectory.`
        : `Multi-sprint closure rate is the truest predictor of next-sprint outcomes. Single-sprint data is noisy; 8-sprint trend smooths the signal.`);

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Sprint Trajectory');
    this._kpiStrip(s, [
      {value: sprints.length, label: 'Sprints in History', color: N},
      {value: sprintsWithData, label: 'With Real Counts', color: sprintsWithData>=3 ? G : A},
      {value: noHistory ? '—' : last8.length, label: 'Plotted (last 8)', color: T},
      {value: cur.totalItems ?? '—', label: 'Current Items', color: T},
      {value: cur.completedItems ?? '—', label: 'Current Closed', color: G},
      {value: cur.totalItems > 0 ? `${Math.round((cur.completedItems||0)/cur.totalItems*100)}%` : '—', label: 'Current Closure', color: A},
    ]);

    if (noHistory) {
      this._calloutBox(s, 0.35, 2.20, 12.62, 0.80,
        `ℹ  sprintData.sprints[] is empty in the payload — Transform node should pass through wi.sprints from Neocities workitems-core.json.`,
        T);
      return;
    }

    // Always render the sprint-history table (works in both labelsOnly and fullData modes)
    this._exhibitHead(s, 0.35, 1.80, 12.62, `SPRINT HISTORY — LAST ${last8.length} SPRINTS`,
      labelsOnly
        ? `Per-sprint counts not yet aggregated upstream — current sprint backfilled from sprintData.sprint`
        : `Source: workitems-core.json → sprints[]`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:8,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'SPRINT',options:{...hdr,align:'left'}},
       {text:'START',options:{...hdr,align:'center'}},
       {text:'END',options:{...hdr,align:'center'}},
       {text:'COMMITTED',options:{...hdr,align:'center'}},
       {text:'CLOSED',options:{...hdr,align:'center'}},
       {text:'CLOSURE %',options:{...hdr,align:'center'}},
       {text:'STATUS',options:{...hdr,align:'center'}}],
      ...last8.map((sp, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const c = committed[ri], cl = closed[ri];
        const rate = c>0 ? Math.round(cl/c*100) : 0;
        const status = sp.current ? 'CURRENT' : sp._backfilled ? 'backfilled' : hasCount[ri] ? 'ok' : 'no count';
        const statusColor = sp.current ? T : sp._backfilled ? G : hasCount[ri] ? G : MG;
        const date = (s) => s ? String(s).slice(0, 10) : '—';
        return [
          cell(this._trunc(sp.label||'—', 24), bg, 'left', N),
          cell(date(sp.start), bg, 'center', MG),
          cell(date(sp.end), bg, 'center', MG),
          cell(c>0 ? c : '—', bg, 'center', c>0?T:MG),
          cell(cl>0 ? cl : '—', bg, 'center', cl>0?G:MG),
          cell(c>0 ? `${rate}%` : '—', bg, 'center', c===0?MG:rate>=70?G:rate>=50?A:R),
          cell(status, bg, 'center', statusColor),
        ];
      }),
    ];
    s.addTable(rows, {x:0.35,y:2.20,w:12.62,rowH:0.24,fontFace:'Calibri',
                      colW:[3.10,1.50,1.50,1.60,1.40,1.50,2.02]});

    // Bottom: chart only when fullData (≥2 sprints with real counts).
    // labelsOnly mode shows an honest callout instead — no degenerate chart.
    this._bottomHead(s, fullData ? 'CLOSURE-RATE TRAJECTORY' : 'UPSTREAM DATA GAP');
    if (fullData && dataSeries.length >= 2) {
      const dsLabels = dataSeries.map(x => this._trunc(x.label, 18));
      const dsRate = dataSeries.map(x => x.c>0 ? Math.round(x.d/x.c*100) : 0);
      s.addChart(this.pptx.ChartType.line, [{name:'Closure %', labels: dsLabels, values: dsRate}], {
        x:0.35,y:4.50,w:12.62,h:1.80,
        chartColors:[N],
        showLegend:false,showTitle:false,showValue:true,dataLabelFontSize:9,
        valAxisMaxVal:100,valAxisMinVal:0,
        catAxisLabelFontSize:9,valAxisLabelFontSize:8,
        lineSize:2.5,lineDataSymbol:'circle',lineDataSymbolSize:8,
        plotAreaBorderColor:RL,plotAreaBorderSize:0.3,
      });
    } else {
      this._calloutBox(s, 0.35, 4.50, 12.62, 1.80,
        `Per-sprint completion counts (totalItems / completedItems) are not exported by Neocities workitems-core.json — only the current sprint carries them via sprintData.sprint.\n\n` +
        `To enable the trajectory chart: extend the upstream Neocities exporter to include per-sprint rollups (group work items by IterationPath, then count by State). Once available, this slide will auto-render the closure-rate line.`,
        T);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — ITSM Severity × Status Matrix
  // Source: ops.itsmMatrices (already exposed) or ops.itsm with self-pivot
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMMatrix(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';

    // Build severity × status matrix from ITSM records (more reliable than BIZTECH matrices)
    const cases = this._ops?.itsm || [];
    const severities = new Map();
    const statuses   = new Map();
    const matrix = {};
    for (const c of cases) {
      const sv = String(c.severity || 'Medium');
      const st = this._statusBucket(c.status);
      severities.set(sv, (severities.get(sv)||0)+1);
      statuses.set(st,   (statuses.get(st)||0)+1);
      const key = `${sv}|${st}`;
      matrix[key] = (matrix[key]||0)+1;
    }
    const svList = ['Critical','High','Medium','Low'].filter(s => severities.has(s));
    Array.from(severities.keys()).forEach(s => { if (!svList.includes(s)) svList.push(s); });
    const stList = ['New','In Progress','Pending','In Analysis','Resolved','Closed'].filter(s => statuses.has(s));
    Array.from(statuses.keys()).forEach(s => { if (!stList.includes(s)) stList.push(s); });

    const max = Math.max(...Object.values(matrix), 1);
    const hottest = Object.entries(matrix).sort((a,b)=>b[1]-a[1])[0];
    const [hotSev, hotStat] = hottest ? hottest[0].split('|') : ['—','—'];

    const title = this._an?.hermes?.slides?.itsmMatrix?.headline ||
      (cases.length === 0
        ? `ITSM matrix unavailable — no cases in opsData.itsm this run`
        : hottest
        ? `ITSM stuck zone: ${hottest[1]} ${hotSev}-severity cases parked in "${hotStat}"`
        : `ITSM matrix populated — see severity × status pivot`);
    const soWhat = this._an?.hermes?.slides?.itsmMatrix?.soWhat ||
      `Hot cells reveal the bottleneck stage. Items live there because something specific (approval, customer wait, dependency) blocks transition.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'ITSM Matrix');
    this._kpiStrip(s, [
      {value: cases.length, label: 'Total Cases', color: N},
      {value: svList.length, label: 'Severities', color: T},
      {value: stList.length, label: 'Status Buckets', color: T},
      {value: max, label: 'Hottest Cell', color: max>20?R:max>10?A:T},
      {value: hotSev, label: 'Hot Severity', color: hotSev==='Critical'||hotSev==='High'?R:A},
      {value: hotStat, label: 'Hot Status', color: T},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'SEVERITY × STATUS — CASE COUNT HEATMAP',
      `Darker = more cases stuck at that intersection. Hot cells indicate bottleneck stages.`);

    // Render matrix as a grid
    const colW = (12.62 - 1.60) / Math.max(stList.length, 1);
    const rowH = 0.42;
    // Header row
    s.addText('SEVERITY ↓ / STATUS →',
      {x:0.35,y:2.20,w:1.60,h:rowH,fontSize:8,fontFace:'Calibri',color:MG,bold:true,italic:true,valign:'middle'});
    stList.forEach((st, ci) => {
      s.addShape(this.pptx.ShapeType.rect,{x:1.95+ci*colW,y:2.20,w:colW-0.04,h:rowH,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(this._trunc(st, 14), {x:1.95+ci*colW,y:2.20,w:colW-0.04,h:rowH,fontSize:8,fontFace:'Calibri',color:N,bold:true,align:'center',valign:'middle'});
    });
    svList.forEach((sv, ri) => {
      const ry = 2.20 + (ri+1)*rowH;
      const svColor = sv==='Critical'?R : sv==='High'?A : sv==='Medium'?T : G;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ry,w:1.56,h:rowH,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(sv,{x:0.35,y:ry,w:1.56,h:rowH,fontSize:9,fontFace:'Calibri',color:svColor,bold:true,align:'center',valign:'middle'});
      stList.forEach((st, ci) => {
        const cnt = matrix[`${sv}|${st}`] || 0;
        const intensity = cnt / max;
        const bg = cnt === 0 ? 'FFFFFF'
                 : intensity > 0.7 ? 'FBD4D4'
                 : intensity > 0.4 ? 'FCE8D6'
                 : intensity > 0.15 ? 'E8F0FB'
                 : 'F7F7F5';
        s.addShape(this.pptx.ShapeType.rect,{x:1.95+ci*colW,y:ry,w:colW-0.04,h:rowH-0.02,fill:{color:bg},line:{color:RL,width:0.3}});
        s.addText(cnt === 0 ? '—' : String(cnt),
          {x:1.95+ci*colW,y:ry,w:colW-0.04,h:rowH-0.02,fontSize:10,fontFace:'Calibri',color:cnt===0?MG:DG,bold:cnt>0,align:'center',valign:'middle'});
      });
    });

    // Bottom recommendation
    this._bottomHead(s, 'READING THE HEATMAP');
    s.addText(
      `Cells with high counts at "In Analysis" or "Pending" indicate cases blocked on input or decision — escalate by owner. ` +
      `High counts at "Resolved" awaiting closure indicate process drag, not real backlog — automate verification. ` +
      `Critical/High rows with anything above 10 cases stuck off "Closed" warrant a separate triage stream.`,
      {x:0.35,y:4.50,w:12.62,h:1.80,fontSize:11,fontFace:'Calibri',color:DG,lineSpacing:18,valign:'top'});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SHARED HELPERS — used by 8+ new slides below to render thin distribution
  // bars + small tables consistently without re-inventing markup each time.
  // ══════════════════════════════════════════════════════════════════════════

  // Render a labelled distribution bar list at the given anchor
  // dist: array of {name, count, percent}
  // returns nothing; draws onto slide
  _drawDistribution(s, x, y, w, h, dist, opts = {}) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6';
    const top = opts.top || 7;
    const rows = (dist || []).slice(0, top);
    if (rows.length === 0) {
      s.addText(opts.empty || 'No data',
        {x, y: y+0.20, w, h:0.30, fontSize:9, fontFace:'Calibri', color:MG, italic:true, align:'center'});
      return;
    }
    const max = Math.max(...rows.map(r => r.count || 0), 1);
    const labelW = opts.labelW || 1.80;
    const trackX = x + labelW + 0.05;
    const trackW = w - labelW - 0.50;
    const rowH = (h - 0.10) / Math.max(rows.length, 1);
    const palette = opts.palette || [N, T, A, G, R, '8E44AD', MG];
    rows.forEach((r, i) => {
      const ry = y + i * rowH;
      const bw = Math.max(0.04, ((r.count || 0) / max) * trackW);
      const color = palette[i % palette.length];
      s.addText(this._trunc(r.name || '—', 24),
        {x, y: ry, w: labelW, h: Math.max(0.10, rowH-0.02), fontSize:8, fontFace:'Calibri', color:'2C2C2C', align:'right', valign:'middle'});
      s.addShape(this.pptx.ShapeType.rect,{x: trackX, y: ry+0.04, w: trackW, h: Math.max(0.04, rowH-0.10), fill:{color:'F0F4F8'}, line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x: trackX, y: ry+0.04, w: bw,   h: Math.max(0.04, rowH-0.10), fill:{color}, line:{type:'none'}});
      // BUG FIX: value label was fixed w:1.40 starting at trackX+bw+0.04, which
      // overflowed slide width when bar was near-full or when this distribution
      // was rendered close to the right edge (slides 12/15/32 had labels at
      // x+w=13.96, past the 13.33" slide). Clamp w to fit within the helper's
      // bounding box (x .. x+w_total).
      const labelX = trackX + bw + 0.04;
      const xBound = x + (opts.boundW || w);
      const labelW2 = Math.max(0.30, Math.min(1.40, xBound - labelX - 0.02));
      s.addText(`${(r.count||0).toLocaleString()}${r.percent!=null?` · ${(r.percent||0).toFixed(0)}%`:''}`,
        {x: labelX, y: ry, w: labelW2, h: Math.max(0.10, rowH-0.02), fontSize:8, fontFace:'Calibri', color:'2C2C2C', bold:true, valign:'middle'});
    });
  }

  // Render a thin 2D matrix heatmap at the given anchor
  _drawHeatmap(s, x, y, w, h, matrix, opts = {}) {
    const N='1B2A4A',R='C0392B',A='E67E22',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const rows = opts.rows || [];   // left CUSTOMER_REDACTED labels
    const cols = opts.cols || [];   // top CUSTOMER_REDACTED labels
    const lookup = opts.lookup;      // (rowLabel, colLabel) -> count
    const max = opts.max || 1;
    // BUG FIX: labelW was fixed at 1.80 — too narrow for 18+ char labels like
    // "New/Change Requirement" causing them to overlap each other vertically
    // when the cell height shrunk. Auto-size from longest row label, capped
    // at 35% of total width so cells stay readable.
    const longestLabel = Math.max(...rows.map(r => String(r||'').length), 4);
    const autoLabelW = Math.min(w * 0.35, Math.max(1.40, longestLabel * 0.085));
    const labelW = opts.labelW || autoLabelW;
    const cellW = (w - labelW) / Math.max(cols.length, 1);
    const cellH = (h - 0.40) / Math.max(rows.length + 1, 1);
    // BUG FIX: clamp truncation to fit available label width (was always 24)
    const labelTrunc = Math.max(8, Math.floor(labelW / 0.085));
    // Header
    s.addText(opts.cornerLabel || '↓ / →',
      {x, y, w: labelW, h: cellH, fontSize:7, fontFace:'Calibri', color:MG, bold:true, italic:true, valign:'middle'});
    cols.forEach((c, ci) => {
      s.addShape(this.pptx.ShapeType.rect,{x: x+labelW+ci*cellW, y, w: cellW-0.02, h: cellH, fill:{color:'F0F3F8'}, line:{type:'none'}});
      s.addText(this._trunc(c, 14),
        {x: x+labelW+ci*cellW, y, w: cellW-0.02, h: cellH, fontSize:7, fontFace:'Calibri', color:N, bold:true, align:'center', valign:'middle'});
    });
    rows.forEach((rLabel, ri) => {
      const ry = y + (ri+1)*cellH;
      s.addShape(this.pptx.ShapeType.rect,{x, y: ry, w: labelW, h: cellH-0.02, fill:{color:'F0F3F8'}, line:{type:'none'}});
      s.addText(this._trunc(rLabel, labelTrunc),
        {x: x+0.04, y: ry, w: labelW-0.04, h: cellH-0.02, fontSize:Math.min(8, Math.max(6, cellH * 14)), fontFace:'Calibri', color:N, bold:true, valign:'middle'});
      cols.forEach((cLabel, ci) => {
        const v = lookup ? lookup(rLabel, cLabel) : 0;
        const intensity = v / max;
        const bg = v === 0 ? 'FFFFFF'
                 : intensity > 0.7 ? 'FBD4D4'
                 : intensity > 0.4 ? 'FCE8D6'
                 : intensity > 0.15 ? 'FEF3E2'
                 : 'F7F7F5';
        s.addShape(this.pptx.ShapeType.rect,{x: x+labelW+ci*cellW, y: ry, w: cellW-0.02, h: cellH-0.02, fill:{color:bg}, line:{color:RL, width:0.3}});
        s.addText(v === 0 ? '·' : (typeof v === 'number' && v % 1 ? v.toFixed(1) : String(v)),
          {x: x+labelW+ci*cellW, y: ry, w: cellW-0.02, h: cellH-0.02, fontSize:8, fontFace:'Calibri', color: v===0?MG:'2C2C2C', bold: v > max*0.4, align:'center', valign:'middle'});
      });
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — SLA Breach 7-Day Forecast (MPR predicted_breaches)
  // ══════════════════════════════════════════════════════════════════════════
  _slideSLAForecast(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const breaches = this._ops?.mprFull?.predicted_breaches || [];
    const critical = breaches.filter(b => b.risk_zone === 'Critical').length;
    const warning  = breaches.filter(b => b.risk_zone === 'Warning' || b.risk_zone === 'High').length;
    const top = [...breaches].sort((a,b) => (b.sla_pct_elapsed||0) - (a.sla_pct_elapsed||0)).slice(0, 10);

    const title = this._an?.hermes?.slides?.slaForecast?.headline ||
      (breaches.length === 0
        ? `No SLA breaches predicted in next 7 days`
        : `${breaches.length} case(s) projected to breach SLA — ${critical} Critical, ${warning} Warning`);
    const soWhat = this._an?.hermes?.slides?.slaForecast?.soWhat ||
      `Cases below are minutes-to-hours from breach. Triage in order of \`hours_remaining\` ascending — first listed should move first.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'SLA Forecast');
    this._kpiStrip(s, [
      {value: breaches.length, label: 'Predicted Breaches', color: breaches.length>0?R:G},
      {value: critical, label: 'Critical Zone', color: critical>0?R:G},
      {value: warning, label: 'Warning Zone', color: warning>0?A:G},
      {value: top[0]?.hours_remaining ?? '—', label: 'Min Hours Left', color: R},
      {value: new Set(breaches.map(b=>b.assignee_name)).size, label: 'Owners Affected', color: A},
      {value: '7d', label: 'Forecast Window', color: T},
    ]);

    if (breaches.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `✓  No cases projected to breach SLA within the next 7 days.`, G);
      return;
    }

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'TOP 10 BY URGENCY — ORDERED BY % SLA ELAPSED',
      `Source: mpr_data.predicted_breaches · ${breaches.length} cases tracked`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:8,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'CASE ID',options:{...hdr,align:'center'}},{text:'OWNER',options:{...hdr,align:'left'}},
       {text:'SUBJECT',options:{...hdr,align:'left'}},{text:'SLA %',options:{...hdr,align:'center'}},
       {text:'HOURS LEFT',options:{...hdr,align:'center'}},{text:'ZONE',options:{...hdr,align:'center'}}],
      ...top.map((b, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const pc = b.risk_zone === 'Critical' ? R : b.risk_zone === 'Warning' ? A : T;
        return [
          cell(`#${b.caseid}`, bg, 'center', N),
          cell(this._trunc(b.assignee_name||'—', 18), bg, 'left'),
          cell(this._trunc(b.subject||'—', 50), bg, 'left'),
          cell(`${(b.sla_pct_elapsed||0).toFixed(1)}%`, bg, 'center', (b.sla_pct_elapsed||0)>=90?R:A),
          cell(`${(b.hours_remaining||0).toFixed(1)}h`, bg, 'center', (b.hours_remaining||0)<=4?R:A),
          cell(b.risk_zone||'—', bg, 'center', pc),
        ];
      }),
    ];
    s.addTable(rows, {x:0.35,y:2.22,w:12.62,rowH:0.32,fontFace:'Calibri',colW:[1.20,2.10,5.70,1.30,1.40,0.92]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Cost of Delay (MPR cost_of_delay)
  // ══════════════════════════════════════════════════════════════════════════
  _slideCostOfDelay(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const cod = this._ops?.mprFull?.cost_of_delay || {};
    const avgWait    = cod.avg_approval_wait_hrs || 0;
    const openApp    = cod.open_in_approval || 0;
    const blockedHrs = cod.total_blocked_hours || 0;
    const pDays      = cod.person_days_lost || 0;

    const title = this._an?.hermes?.slides?.costOfDelay?.headline ||
      (pDays === 0
        ? `No measurable delay cost this period`
        : `${pDays} person-days lost to approval delay — ${blockedHrs.toFixed(0)}h blocked across ${openApp} open approvals`);
    const soWhat = this._an?.hermes?.slides?.costOfDelay?.soWhat ||
      `Each approval-waiting hour is a person-hour unavailable for delivery. Shorten approval cycles to recover capacity without adding headcount.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Cost of Delay');
    this._kpiStrip(s, [
      {value: pDays.toFixed(1), label: 'Person-Days Lost', color: pDays>30?R:pDays>10?A:G},
      {value: openApp, label: 'Open in Approval', color: T},
      {value: `${blockedHrs.toFixed(0)}h`, label: 'Total Blocked Hours', color: A},
      {value: `${avgWait.toFixed(1)}h`, label: 'Avg Approval Wait', color: avgWait>24?R:A},
      {value: Math.round(pDays*8), label: 'Equivalent Person-Hours', color: A},
      {value: 'Approval', label: 'Bottleneck Type', color: N},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'DELAY ECONOMICS — WHAT IT IS COSTING',
      `Source: mpr_data.cost_of_delay`);

    const facts = [
      ['Average approval wait',      `${avgWait.toFixed(1)} hours per case`,                 'How long a case sits in approval before someone touches it'],
      ['Open in approval right now', `${openApp} cases`,                                      'Backlog of cases that have entered approval but not yet been actioned'],
      ['Total blocked hours',        `${blockedHrs.toFixed(0)} hours`,                        'Cumulative hours all open-in-approval cases have been waiting'],
      ['Person-days equivalent',     `${pDays.toFixed(1)} person-days (≈ ${Math.round(pDays*8)} person-hours)`, 'How much delivery capacity is being held by approval waits'],
    ];
    facts.forEach((f, i) => {
      const fy = 2.30 + i*0.85;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:fy,w:12.62,h:0.74,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:fy,w:0.08,h:0.74,fill:{color:N},line:{type:'none'}});
      s.addText(f[0], {x:0.50,y:fy+0.04,w:4.20,h:0.30,fontSize:11,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(f[1], {x:4.80,y:fy+0.04,w:3.40,h:0.30,fontSize:14,fontFace:'Calibri',color:DG,bold:true,valign:'middle'});
      s.addText(f[2], {x:8.30,y:fy+0.04,w:4.60,h:0.30,fontSize:9,fontFace:'Calibri',color:MG,italic:true,valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Bottleneck Heatmap (MPR bottleneck_heatmap)
  // ══════════════════════════════════════════════════════════════════════════
  _slideBottleneckHeatmap(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const bh = this._ops?.mprFull?.bottleneck_heatmap || [];
    // Pivot by status_group, take last 12 weeks (most recent first)
    const sorted = [...bh].sort((a,b) => new Date(b.week_start||0) - new Date(a.week_start||0));
    const recentWeeks = [...new Set(sorted.slice(0, 100).map(r => r.week_start))].slice(0, 12).reverse();
    const statusGroups = [...new Set(bh.map(r => r.status_group))].slice(0, 8);
    const pivot = {};
    for (const sg of statusGroups) pivot[sg] = {};
    for (const r of bh) {
      if (recentWeeks.includes(r.week_start) && statusGroups.includes(r.status_group)) {
        pivot[r.status_group][r.week_start] = (pivot[r.status_group][r.week_start] || 0) + (r.avg_hours || 0);
      }
    }
    const allValues = Object.values(pivot).flatMap(o => Object.values(o)).filter(v => v > 0);
    const maxVal = Math.max(...allValues, 1);
    const hottest = statusGroups.reduce((max, sg) => {
      const total = Object.values(pivot[sg]).reduce((s,v)=>s+v, 0);
      return total > max.total ? { sg, total } : max;
    }, { sg: '—', total: 0 });

    const title = this._an?.hermes?.slides?.bottleneck?.headline ||
      (bh.length === 0
        ? `Bottleneck heatmap unavailable — no MPR data`
        : `${hottest.sg} is the dominant bottleneck stage across last ${recentWeeks.length} weeks`);
    const soWhat = this._an?.hermes?.slides?.bottleneck?.soWhat ||
      `Each cell shows average hours stuck at that stage for that week. Dark cells = persistent friction; lighter cells = transient. Attack persistent dark cells, not isolated spikes.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Bottleneck Heatmap');
    this._kpiStrip(s, [
      {value: bh.length, label: 'Data Points', color: T},
      {value: statusGroups.length, label: 'Stages', color: N},
      {value: recentWeeks.length, label: 'Weeks Shown', color: T},
      {value: this._trunc(hottest.sg, 14), label: 'Hottest Stage', color: R},
      {value: `${hottest.total.toFixed(0)}h`, label: 'Hottest Total', color: R},
      {value: `${maxVal.toFixed(1)}h`, label: 'Peak Cell', color: A},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'STATUS STAGE × WEEK — AVG HOURS STUCK',
      `Source: mpr_data.bottleneck_heatmap`);

    // Render heatmap grid
    const labelColW = 1.80;
    const cellW = (12.62 - labelColW) / Math.max(recentWeeks.length, 1);
    const rowH = 0.42;
    const startY = 2.24;
    // Header row (week labels)
    s.addText('STAGE ↓ / WEEK →', {x:0.35,y:startY,w:labelColW,h:rowH,fontSize:8,fontFace:'Calibri',color:MG,bold:true,italic:true,valign:'middle'});
    recentWeeks.forEach((wk, ci) => {
      const label = wk ? new Date(wk).toLocaleDateString('en-IN',{month:'short',day:'numeric'}) : '—';
      s.addShape(this.pptx.ShapeType.rect,{x:0.35+labelColW+ci*cellW,y:startY,w:cellW-0.02,h:rowH,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(label, {x:0.35+labelColW+ci*cellW,y:startY,w:cellW-0.02,h:rowH,fontSize:7,fontFace:'Calibri',color:N,bold:true,align:'center',valign:'middle'});
    });
    statusGroups.forEach((sg, ri) => {
      const ry = startY + (ri+1)*rowH;
      if (ry + rowH > 6.40) return;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ry,w:labelColW,h:rowH-0.02,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(this._trunc(sg, 22), {x:0.35,y:ry,w:labelColW,h:rowH-0.02,fontSize:8,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      recentWeeks.forEach((wk, ci) => {
        const v = pivot[sg][wk] || 0;
        const intensity = v / maxVal;
        const bg = v === 0 ? 'FFFFFF'
                 : intensity > 0.7 ? 'FBD4D4'
                 : intensity > 0.4 ? 'FCE8D6'
                 : intensity > 0.15 ? 'FEF3E2'
                 : 'F7F7F5';
        s.addShape(this.pptx.ShapeType.rect,{x:0.35+labelColW+ci*cellW,y:ry,w:cellW-0.02,h:rowH-0.02,fill:{color:bg},line:{color:RL,width:0.3}});
        s.addText(v === 0 ? '·' : v.toFixed(1),
          {x:0.35+labelColW+ci*cellW,y:ry,w:cellW-0.02,h:rowH-0.02,fontSize:8,fontFace:'Calibri',color:v===0?MG:DG,bold:v>maxVal*0.4,align:'center',valign:'middle'});
      });
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Resolution Funnel (MPR resolution_funnel)
  // ══════════════════════════════════════════════════════════════════════════
  _slideResolutionFunnel(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';
    const f = this._ops?.mprFull?.resolution_funnel || {};
    const stages = [
      { name:'Total Entered',   v: f.total_entered      || 0, color:N },
      { name:'Reached New',     v: f.reached_new        || 0, color:T },
      { name:'Reached Approval',v: f.reached_approval   || 0, color:A },
      { name:'Reached BizTech', v: f.reached_biztech    || 0, color:T },
      { name:'Reached WIP',     v: f.reached_wip        || 0, color:T },
      { name:'Reached Resolved',v: f.reached_resolved   || 0, color:G },
    ].filter(s => s.v > 0 || stages.indexOf(s) === 0);
    const top = stages[0]?.v || 1;
    const dropoffs = [];
    for (let i=1; i<stages.length; i++) {
      const prev = stages[i-1].v, cur = stages[i].v;
      const dropPct = prev > 0 ? Math.round((1 - cur/prev) * 100) : 0;
      dropoffs.push({from: stages[i-1].name, to: stages[i].name, dropPct, prev, cur});
    }
    const biggestDrop = [...dropoffs].sort((a,b)=>b.dropPct-a.dropPct)[0];

    const title = this._an?.hermes?.slides?.funnel?.headline ||
      (top === 0
        ? `Resolution funnel unavailable — no MPR rows this period`
        : biggestDrop
        ? `Biggest drop-off: ${biggestDrop.dropPct}% between ${biggestDrop.from} → ${biggestDrop.to}`
        : `Funnel flows cleanly from intake to resolution`);
    const soWhat = this._an?.hermes?.slides?.funnel?.soWhat ||
      `Each stage drop-off reveals where cases stall. Optimise the largest drop first — it has the biggest closure-rate leverage.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Resolution Funnel');
    const last = stages[stages.length-1]?.v || 0;
    this._kpiStrip(s, [
      {value: stages[0]?.v ?? '—', label: 'Total Entered', color: N},
      {value: last, label: 'Reached Resolution', color: G},
      {value: top>0 ? `${Math.round(last/top*100)}%` : '—', label: 'End-to-End Conversion', color: top>0&&last/top>=0.6?G:A},
      {value: biggestDrop?.dropPct ? `${biggestDrop.dropPct}%` : '—', label: 'Biggest Drop', color: R},
      {value: this._trunc(biggestDrop?.from || '—', 14), label: 'Drop Origin', color: A},
      {value: stages.length, label: 'Funnel Stages', color: T},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'FUNNEL — CASES PER STAGE',
      `Source: mpr_data.resolution_funnel`);
    // Horizontal funnel bars (width proportional to v / top)
    // BUG FIX: was barW=11.50 starting at x=2.40 → x+w=13.90 (slide width
    // is 13.33), so bars and value labels were cut off at the right edge.
    // Slide-internal track width = 13.33 - 2.40 - 0.35 = 10.58.
    const TRACK_X = 2.40, TRACK_W = 10.58;
    stages.forEach((stage, i) => {
      const ry = 2.30 + i*0.62;
      const barW = (stage.v / top) * TRACK_W;
      const pct = top>0 ? Math.round(stage.v/top*100) : 0;
      s.addText(stage.name, {x:0.35,y:ry,w:2.00,h:0.42,fontSize:10,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addShape(this.pptx.ShapeType.rect,{x:TRACK_X,y:ry+0.06,w:TRACK_W,h:0.30,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:TRACK_X,y:ry+0.06,w:Math.max(0.10, barW),h:0.30,fill:{color:stage.color},line:{type:'none'}});
      s.addText(`${stage.v.toLocaleString()} (${pct}%)`,
        {x:TRACK_X+0.10,y:ry+0.06,w:Math.max(0.50, barW-0.20),h:0.30,fontSize:10,fontFace:'Calibri',color:'FFFFFF',bold:true,valign:'middle'});
      // Drop-off annotation
      if (i > 0 && dropoffs[i-1]) {
        const d = dropoffs[i-1];
        s.addText(`↓ ${d.dropPct}% drop  (${d.prev-d.cur} cases lost)`,
          {x:TRACK_X,y:ry-0.14,w:8.00,h:0.16,fontSize:8,fontFace:'Calibri',color:d.dropPct>=50?R:d.dropPct>=20?A:MG,italic:true,valign:'middle'});
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Performance Ranking (MPR performance_ranking)
  // ══════════════════════════════════════════════════════════════════════════
  _slidePerformanceRanking(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6';
    const ranking = this._ops?.mprFull?.performance_ranking || [];
    const sorted  = [...ranking].sort((a,b) => (b.composite_score||0) - (a.composite_score||0));
    const top10   = sorted.slice(0, 10);
    const bottom5 = sorted.slice(-5).reverse();
    const totalCases = ranking.reduce((s,r)=>s+(r.total_cases||0), 0);
    const avgComp    = ranking.length ? (ranking.reduce((s,r)=>s+(r.composite_score||0),0) / ranking.length) : 0;

    const title = this._an?.hermes?.slides?.perfRanking?.headline ||
      (ranking.length === 0
        ? `Performance ranking unavailable — no MPR data`
        : `Top performer ${top10[0]?.assignee_name} scores ${(top10[0]?.composite_score||0).toFixed(0)} composite across ${top10[0]?.total_cases||0} cases`);
    const soWhat = this._an?.hermes?.slides?.perfRanking?.soWhat ||
      `Composite weights SLA, throughput, quality, consistency, speed. High-bottom gap indicates training/coaching opportunity; tight distribution indicates team-level systemic factors.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Performance Ranking');
    this._kpiStrip(s, [
      {value: ranking.length, label: 'Performers', color: T},
      {value: avgComp.toFixed(0), label: 'Avg Composite', color: avgComp>=70?G:avgComp>=50?A:R},
      {value: (top10[0]?.composite_score||0).toFixed(0), label: 'Top Score', color: G},
      {value: (bottom5[bottom5.length-1]?.composite_score||0).toFixed(0), label: 'Bottom Score', color: R},
      {value: totalCases.toLocaleString(), label: 'Cases Tracked', color: T},
      {value: ranking.filter(r => (r.sla_compliance_pct||0) >= 95).length, label: 'SLA Heroes (≥95%)', color: G},
    ]);

    // LEFT: top 10
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'TOP 10 BY COMPOSITE SCORE',
      `Source: mpr_data.performance_ranking`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const mkRows = (rows, headerText) => [
      [{text:'OWNER',options:{...hdr,align:'left'}},{text:'CASES',options:{...hdr,align:'center'}},
       {text:'SLA %',options:{...hdr,align:'center'}},{text:'SCORE',options:{...hdr,align:'center'}}],
      ...rows.map((r, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        return [
          cell(this._trunc(r.assignee_name||'—', 22), bg, 'left', N),
          cell(r.total_cases||0, bg, 'center'),
          cell(`${(r.sla_compliance_pct||0).toFixed(0)}%`, bg, 'center', (r.sla_compliance_pct||0)>=90?G:A),
          cell((r.composite_score||0).toFixed(0), bg, 'center', (r.composite_score||0)>=70?G:(r.composite_score||0)>=50?A:R),
        ];
      }),
    ];
    s.addTable(mkRows(top10), {x:0.35,y:2.20,w:6.10,rowH:0.22,fontFace:'Calibri',colW:[2.80,0.90,1.20,1.20]});

    // RIGHT: bottom 5 + coaching panel
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BOTTOM 5 — COACHING TARGETS',
      `Lowest composite scores; review for training opportunity`);
    s.addTable(mkRows(bottom5), {x:6.70,y:2.20,w:6.20,rowH:0.22,fontFace:'Calibri',colW:[2.90,0.90,1.20,1.20]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — ITSM Root-Cause × Category (matrices.rootCauseByCategory)
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMRootCausePivot(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4';
    const DG='2C2C2C',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0';
    const m = this._ops?.itsmMatrices?.rootCauseByCategory || [];
    // Top 6 left labels (rootCause) and top 6 top labels (category) by total count
    const byLeft = {}, byTop = {};
    for (const r of m) {
      byLeft[r.left] = (byLeft[r.left]||0) + r.count;
      byTop[r.top]   = (byTop[r.top]||0)   + r.count;
    }
    const topLefts = Object.entries(byLeft).sort((a,b)=>b[1]-a[1]).slice(0,7).map(e=>e[0]);
    const topTops  = Object.entries(byTop).sort((a,b)=>b[1]-a[1]).slice(0,6).map(e=>e[0]);
    const grid = {};
    for (const r of m) {
      if (topLefts.includes(r.left) && topTops.includes(r.top)) {
        grid[`${r.left}|${r.top}`] = r.count;
      }
    }
    const maxCell = Math.max(...Object.values(grid), 1);
    const totalCases = Object.values(byLeft).reduce((s,v)=>s+v, 0);

    const title = this._an?.hermes?.slides?.itsmRcCat?.headline ||
      (m.length === 0
        ? `ITSM root-cause × category pivot unavailable`
        : `${topLefts[0]} root cause concentrates ${Math.round((byLeft[topLefts[0]]||0)/totalCases*100)}% of cases across ${topTops.length} categories`);
    const soWhat = this._an?.hermes?.slides?.itsmRcCat?.soWhat ||
      `Hot cells show where a specific root cause clusters in a specific case category — these are the engineering bug families worth a dedicated fix sprint.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'ITSM Root-Cause Pivot');
    this._kpiStrip(s, [
      {value: totalCases, label: 'Total Cases', color: N},
      {value: Object.keys(byLeft).length, label: 'Root Causes', color: T},
      {value: Object.keys(byTop).length, label: 'Categories', color: T},
      {value: maxCell, label: 'Hottest Cell', color: R},
      {value: this._trunc(topLefts[0]||'—', 14), label: 'Top Root Cause', color: R},
      {value: this._trunc(topTops[0]||'—', 14), label: 'Top Category', color: A},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'ROOT CAUSE × CASE CATEGORY — COUNT HEATMAP',
      `Source: itsm-data.matrices.rootCauseByCategory`);

    const labelW = 2.80;
    const cellW = (12.62 - labelW) / Math.max(topTops.length, 1);
    const rowH = 0.50;
    const startY = 2.20;

    // Header
    s.addText('ROOT CAUSE ↓ / CATEGORY →',
      {x:0.35,y:startY,w:labelW,h:rowH,fontSize:8,fontFace:'Calibri',color:MG,bold:true,italic:true,valign:'middle'});
    topTops.forEach((tt, ci) => {
      s.addShape(this.pptx.ShapeType.rect,{x:0.35+labelW+ci*cellW,y:startY,w:cellW-0.02,h:rowH,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(this._trunc(tt, 18), {x:0.35+labelW+ci*cellW,y:startY,w:cellW-0.02,h:rowH,fontSize:8,fontFace:'Calibri',color:N,bold:true,align:'center',valign:'middle'});
    });
    topLefts.forEach((tl, ri) => {
      const ry = startY + (ri+1)*rowH;
      if (ry + rowH > 6.30) return;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:ry,w:labelW,h:rowH-0.02,fill:{color:'F0F3F8'},line:{type:'none'}});
      s.addText(this._trunc(tl, 32), {x:0.35,y:ry,w:labelW,h:rowH-0.02,fontSize:8,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      topTops.forEach((tt, ci) => {
        const v = grid[`${tl}|${tt}`] || 0;
        const intensity = v / maxCell;
        const bg = v === 0 ? 'FFFFFF'
                 : intensity > 0.7 ? 'FBD4D4'
                 : intensity > 0.4 ? 'FCE8D6'
                 : intensity > 0.15 ? 'FEF3E2'
                 : 'F7F7F5';
        s.addShape(this.pptx.ShapeType.rect,{x:0.35+labelW+ci*cellW,y:ry,w:cellW-0.02,h:rowH-0.02,fill:{color:bg},line:{color:RL,width:0.3}});
        s.addText(v === 0 ? '·' : String(v),
          {x:0.35+labelW+ci*cellW,y:ry,w:cellW-0.02,h:rowH-0.02,fontSize:10,fontFace:'Calibri',color:v===0?MG:DG,bold:v>maxCell*0.4,align:'center',valign:'middle'});
      });
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — ITSM Volume Drivers (accountName + projectName + currentOwner + assignedToName)
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMVolumeDrivers(sn, ts) {
    const N='1B2A4A',R='C0392B',A='E67E22',T='0A7EA4',MG='9B9B9B';
    const d = this._ops?.itsmDistributions || {};
    const acct = (d.accountName    || []).slice(0, 7);
    const proj = (d.projectName    || []).slice(0, 7);
    const cur  = (d.currentOwner   || []).slice(0, 7);
    const asg  = (d.assignedToName || []).slice(0, 7);
    const totalCases = (this._ops?.itsmSummary?.total || 0);
    const topAcct = acct[0], topProj = proj[0];

    const title = this._an?.hermes?.slides?.itsmVolume?.headline ||
      (acct.length === 0
        ? `ITSM volume-driver breakdown unavailable`
        : `${topAcct?.name||'—'} drives ${topAcct?.percent||0}% of ITSM volume; ${topProj?.name||'—'} is the top project source`);
    const soWhat = this._an?.hermes?.slides?.itsmVolume?.soWhat ||
      `Concentration of ITSM volume reveals where account managers, project leads, and ITSM owners need to focus attention.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'ITSM Volume Drivers');
    this._kpiStrip(s, [
      {value: totalCases.toLocaleString(), label:'Total ITSM Cases', color:N},
      {value: d.accountName?.length || 0, label:'Accounts', color:T},
      {value: d.projectName?.length || 0, label:'Projects', color:T},
      {value: d.currentOwner?.length || 0, label:'Owners', color:T},
      {value: this._trunc(topAcct?.name||'—', 14), label:'Top Account', color:A},
      {value: `${topAcct?.percent||0}%`, label:'Top Acct Share', color:R},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'BY ACCOUNT', `${d.accountName?.length||0} accounts`);
    this._drawDistribution(s, 0.35, 2.18, 6.10, 1.85, acct);
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BY PROJECT', `${d.projectName?.length||0} projects`);
    this._drawDistribution(s, 6.70, 2.18, 6.20, 1.85, proj);

    this._bottomHead(s, 'BY OWNER (left) — BY ASSIGNEE (right)');
    this._drawDistribution(s, 0.35, 4.55, 6.10, 1.85, cur);
    this._drawDistribution(s, 6.70, 4.55, 6.20, 1.85, asg);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — ITSM Profile (oegCategory + ageBucket + createdMonth + closedMonth)
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMProfile(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',RL='D4D4D0',LG='E8E8E6';
    const d = this._ops?.itsmDistributions || {};
    const cat = (d.oegCategory || []).slice(0, 6);
    const age = d.ageBucket || [];
    const createdM = (d.createdMonth || []).slice(0, 12).reverse();
    const closedM  = (d.closedMonth  || []).slice(0, 12).reverse();
    // Build paired month chart
    const allMonths = [...new Set([...createdM.map(m=>m.name), ...closedM.map(m=>m.name)])].sort();
    const last12 = allMonths.slice(-12);
    const createdMap = Object.fromEntries(createdM.map(m=>[m.name, m.count]));
    const closedMap  = Object.fromEntries(closedM.map(m=>[m.name, m.count]));

    const topCat = cat[0];
    const oldCases = (age.find(b => /\>180|\>365|180-/.test(b.name||''))?.count || 0);

    const title = this._an?.hermes?.slides?.itsmProfile?.headline ||
      `ITSM age profile: ${(age[0]?.percent)||0}% under 1 day; ${oldCases} cases over 180 days`;
    const soWhat = this._an?.hermes?.slides?.itsmProfile?.soWhat ||
      `Fresh cases (<1d) reflect healthy intake-to-triage flow; aged cases (>180d) are zombie tickets needing closure or escalation.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'ITSM Profile');
    this._kpiStrip(s, [
      {value: this._trunc(topCat?.name||'—', 14), label:'Top Category', color:N},
      {value: `${topCat?.percent||0}%`, label:'Top Cat Share', color:A},
      {value: age.length, label:'Age Buckets', color:T},
      {value: `${age[0]?.percent||0}%`, label:'< 1 Day', color:G},
      {value: oldCases, label:'> 180 Days', color:oldCases>0?R:G},
      {value: last12.length, label:'Months Tracked', color:T},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'OEG CATEGORY', `Top ${cat.length} categories`);
    this._drawDistribution(s, 0.35, 2.18, 6.10, 1.85, cat);
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'AGE BUCKET', 'Distribution by case age');
    this._drawDistribution(s, 6.70, 2.18, 6.20, 1.85, age, {palette:[G,G,A,A,R,R,R]});

    this._bottomHead(s, 'CREATED vs CLOSED — MONTHLY (last 12 months)');
    if (last12.length >= 2) {
      s.addChart(this.pptx.ChartType.bar, [
        { name:'Created', labels: last12, values: last12.map(m => createdMap[m]||0) },
        { name:'Closed',  labels: last12, values: last12.map(m => closedMap[m]||0)  },
      ], {
        x:0.35,y:4.50,w:12.62,h:2.00,
        barDir:'col',barGrouping:'clustered',
        chartColors:[A, G],
        showLegend:true, legendPos:'r', legendFontSize:9,
        showTitle:false, showValue:false,
        catAxisLabelFontSize:8, valAxisLabelFontSize:8,
        plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
      });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — ITSM Analysis × Root-Cause Pivot (matrices.analysisByRootCause)
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMAnalysisRootCause(sn, ts) {
    const N='1B2A4A',R='C0392B',A='E67E22',T='0A7EA4',MG='9B9B9B';
    const m = this._ops?.itsmMatrices?.analysisByRootCause || [];
    const byLeft = {}, byTop = {};
    for (const r of m) { byLeft[r.left] = (byLeft[r.left]||0)+r.count; byTop[r.top] = (byTop[r.top]||0)+r.count; }
    const topLefts = Object.entries(byLeft).sort((a,b)=>b[1]-a[1]).slice(0,7).map(e=>e[0]);
    const topTops  = Object.entries(byTop).sort((a,b)=>b[1]-a[1]).slice(0,6).map(e=>e[0]);
    const grid = {};
    for (const r of m) {
      if (topLefts.includes(r.left) && topTops.includes(r.top)) grid[`${r.left}|${r.top}`] = r.count;
    }
    const maxCell = Math.max(...Object.values(grid), 1);
    const total = Object.values(byLeft).reduce((s,v)=>s+v, 0);

    const title = this._an?.hermes?.slides?.itsmAnalysisRc?.headline ||
      (m.length === 0
        ? `Analysis × Root-Cause pivot unavailable`
        : `${topLefts[0]} analysis dominates root-cause clustering (${Math.round((byLeft[topLefts[0]]||0)/total*100)}%)`);
    const soWhat = this._an?.hermes?.slides?.itsmAnalysisRc?.soWhat ||
      `Hot cells reveal where a specific analysis type aligns with a recurring root cause — these are reusable triage playbooks waiting to be codified.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'ITSM Analysis × Root-Cause');
    this._kpiStrip(s, [
      {value: total, label:'Total Cases', color:N},
      {value: topLefts.length, label:'Analysis Types', color:T},
      {value: topTops.length, label:'Root Causes', color:T},
      {value: maxCell, label:'Hottest Cell', color:R},
      {value: this._trunc(topLefts[0]||'—',14), label:'Top Analysis', color:A},
      {value: this._trunc(topTops[0]||'—',14), label:'Top Root Cause', color:A},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'ANALYSIS × ROOT CAUSE — COUNT HEATMAP',
      `Source: itsm-data.matrices.analysisByRootCause`);
    this._drawHeatmap(s, 0.35, 2.20, 12.62, 4.20, [], {
      rows: topLefts, cols: topTops, max: maxCell,
      lookup: (rL, cL) => grid[`${rL}|${cL}`] || 0,
      cornerLabel: 'ANALYSIS ↓ / ROOT CAUSE →',
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Aging Profile + SLA Burn (aging_summary + sla_burn_rate)
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRAgingSLA(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B';
    const mpr = this._ops?.mprFull || {};
    const aging = (mpr.aging_summary || []).map(a => ({name: a.aging_bucket, count: a.case_count, percent: a.pct}));
    const sla   = (mpr.sla_burn_rate || []).map(s => ({name: s.risk_zone,   count: s.case_count, percent: s.pct}));
    const total = aging.reduce((s,a)=>s+a.count, 0);
    const safe  = sla.find(s => s.name === 'Safe')?.count || 0;
    const crit  = sla.find(s => s.name === 'Critical')?.count || 0;
    const warning = sla.find(s => /warning|warn|high/i.test(s.name))?.count || 0;
    const aged30 = aging.filter(a => /\b(30-|>30|>90|180|365|year)/i.test(a.name||'')).reduce((s,a)=>s+a.count, 0);

    const title = this._an?.hermes?.slides?.mprAging?.headline ||
      (aging.length === 0
        ? `MPR aging breakdown unavailable`
        : crit > 0
        ? `${crit} MPR case(s) in Critical SLA zone — ${aged30} cases aged ≥30d`
        : `MPR backlog healthy — ${safe} cases Safe, ${aged30} aged ≥30d`);
    const soWhat = this._an?.hermes?.slides?.mprAging?.soWhat ||
      `Aging buckets show the structural age of the backlog; SLA zones show urgency on individual cases. Together they map both strategic and tactical pressure.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR Aging & SLA');
    this._kpiStrip(s, [
      {value: total, label:'Open Cases', color:N},
      {value: aging.length, label:'Age Buckets', color:T},
      {value: safe, label:'Safe (SLA)', color:G},
      {value: warning, label:'Warning', color:A},
      {value: crit, label:'Critical', color:crit>0?R:G},
      {value: aged30, label:'Aged ≥30d', color:aged30>10?R:aged30>0?A:G},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'AGING DISTRIBUTION', `${aging.length} buckets · ${total} cases`);
    this._drawDistribution(s, 0.35, 2.18, 6.10, 4.20, aging, {top: aging.length, palette:[G,G,A,A,R,R]});

    this._exhibitHead(s, 6.70, 1.80, 6.20, 'SLA BURN RATE', `${sla.length} risk zones`);
    this._drawDistribution(s, 6.70, 2.18, 6.20, 4.20, sla, {top: sla.length, palette:[G,A,R,R]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Stuck Cases (stuck_in_new + stuck_in_awaiting + user_creation_aging)
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRStuck(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6',DG='2C2C2C';
    const mpr = this._ops?.mprFull || {};
    const stuckNew = (mpr.stuck_in_new       || []).slice(0, 8);
    const stuckAwait = (mpr.stuck_in_awaiting || []).slice(0, 8);
    const userCreate = (mpr.user_creation_aging || []).slice(0, 8);
    const totalStuck = (mpr.stuck_in_new?.length||0) + (mpr.stuck_in_awaiting?.length||0) + (mpr.user_creation_aging?.length||0);
    const longestNew = Math.max(...(mpr.stuck_in_new||[]).map(c=>c.new_hours||0), 0);
    const longestAwait = Math.max(...(mpr.stuck_in_awaiting||[]).map(c=>c.awaiting_hours||0), 0);

    const title = this._an?.hermes?.slides?.mprStuck?.headline ||
      (totalStuck === 0
        ? `No MPR cases stuck this period`
        : `${totalStuck} case(s) stuck across New / Awaiting / User-Creation — longest ${Math.max(longestNew, longestAwait).toFixed(0)}h`);
    const soWhat = this._an?.hermes?.slides?.mprStuck?.soWhat ||
      `Stuck = cases that have stopped progressing at a specific stage. Each list below is a triage worklist — the assignee column tells you who needs the nudge.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR Stuck Cases');
    this._kpiStrip(s, [
      {value: totalStuck, label:'Total Stuck', color:totalStuck>20?R:totalStuck>0?A:G},
      {value: mpr.stuck_in_new?.length||0, label:'Stuck: New', color:A},
      {value: mpr.stuck_in_awaiting?.length||0, label:'Stuck: Awaiting', color:A},
      {value: mpr.user_creation_aging?.length||0, label:'User-Creation', color:T},
      {value: `${longestNew.toFixed(0)}h`, label:'Longest New', color:R},
      {value: `${longestAwait.toFixed(0)}h`, label:'Longest Awaiting', color:R},
    ]);

    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});

    const buildTable = (data, hoursKey) => [
      [{text:'CASE',options:{...hdr,align:'center'}},{text:'ASSIGNEE',options:{...hdr,align:'left'}},
       {text:'SUBJECT',options:{...hdr,align:'left'}},{text:'HOURS',options:{...hdr,align:'center'}}],
      ...(data.length > 0 ? data : [{caseid:'—', assignee_name:'—', subject:'No stuck cases', [hoursKey]:0}]).slice(0,7).map((c, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const hrs = Number(c[hoursKey])||0;
        return [
          cell(c.caseid ? `#${c.caseid}` : '—', bg, 'center', N),
          cell(this._trunc(c.assignee_name||'—', 14), bg, 'left'),
          cell(this._trunc(c.subject||'—', 28), bg, 'left'),
          cell(`${hrs.toFixed(0)}h`, bg, 'center', hrs>=200?R:hrs>=72?A:T),
        ];
      }),
    ];

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'STUCK IN NEW',
      `${mpr.stuck_in_new?.length||0} cases · longest ${longestNew.toFixed(0)}h`);
    s.addTable(buildTable(stuckNew, 'new_hours'),
      {x:0.35,y:2.18,w:6.10,rowH:0.24,fontFace:'Calibri',colW:[0.95,1.60,2.60,0.95]});

    this._exhibitHead(s, 6.70, 1.80, 6.20, 'STUCK IN AWAITING',
      `${mpr.stuck_in_awaiting?.length||0} cases · longest ${longestAwait.toFixed(0)}h`);
    s.addTable(buildTable(stuckAwait, 'awaiting_hours'),
      {x:6.70,y:2.18,w:6.20,rowH:0.24,fontFace:'Calibri',colW:[1.00,1.60,2.70,0.90]});

    this._bottomHead(s, 'USER-CREATION CASES — AGING TRIAGE QUEUE');
    s.addTable(buildTable(userCreate, 'elapsed_biz_hours'),
      {x:0.35,y:4.50,w:12.62,rowH:0.24,fontFace:'Calibri',colW:[1.30,2.40,7.92,1.00]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Effort Accuracy (1,638 cases — show ratio distribution)
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPREffortAccuracy(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0',DG='2C2C2C';
    const mpr = this._ops?.mprFull || {};
    const all = mpr.effort_accuracy || [];
    if (all.length === 0) {
      const s = this.pptx.addSlide();
      this._slideChrome(s, 'MPR effort accuracy unavailable', 'No effort_accuracy rows this period.', sn, ts, 'MPR Effort Accuracy');
      return;
    }
    // Bucket by ratio
    const buckets = { '< 0.5x':0, '0.5–0.9x':0, '0.9–1.1x':0, '1.1–2x':0, '2–5x':0, '> 5x':0 };
    let totalRep = 0, totalAct = 0;
    for (const c of all) {
      const r = Number(c.effort_ratio)||0;
      totalRep += Number(c.reported_effort)||0;
      totalAct += Number(c.actual_aht)||0;
      if (r < 0.5) buckets['< 0.5x']++;
      else if (r < 0.9) buckets['0.5–0.9x']++;
      else if (r < 1.1) buckets['0.9–1.1x']++;
      else if (r < 2)  buckets['1.1–2x']++;
      else if (r < 5)  buckets['2–5x']++;
      else             buckets['> 5x']++;
    }
    const dist = Object.entries(buckets).map(([name, count]) => ({name, count, percent: Math.round(count/all.length*100)}));
    const accurate = (buckets['0.9–1.1x']||0);
    const overestimate = (buckets['< 0.5x']||0) + (buckets['0.5–0.9x']||0);
    const underestimate = all.length - accurate - overestimate;
    const accuracyPct = Math.round(accurate / all.length * 100);

    // Worst 8 estimates
    const worst = [...all].sort((a,b) => Math.abs((b.effort_ratio||1)-1) - Math.abs((a.effort_ratio||1)-1)).slice(0, 8);

    const title = this._an?.hermes?.slides?.mprEffort?.headline ||
      `Effort estimation accuracy: ${accuracyPct}% of cases within ±10% of reported effort`;
    const soWhat = this._an?.hermes?.slides?.mprEffort?.soWhat ||
      `Persistent over-estimation (ratio <1) inflates forecasts and erodes confidence in commitments. Under-estimation (ratio >1) causes capacity surprises mid-week. Both bias the planning curve.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR Effort Accuracy');
    this._kpiStrip(s, [
      {value: all.length.toLocaleString(), label:'Cases Tracked', color:N},
      {value: `${accuracyPct}%`, label:'Within ±10%', color:accuracyPct>=70?G:accuracyPct>=50?A:R},
      {value: overestimate, label:'Over-Estimated', color:A},
      {value: underestimate, label:'Under-Estimated', color:A},
      {value: totalRep>0?Math.round(totalAct/totalRep*100)+'%':'—', label:'Actual/Reported', color:T},
      {value: buckets['> 5x'], label:'Extreme (>5x)', color:buckets['> 5x']>0?R:G},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 6.10, 'ACCURACY DISTRIBUTION', `effort_ratio = actual / reported`);
    this._drawDistribution(s, 0.35, 2.18, 6.10, 4.20, dist, {top: dist.length, palette:[A,A,G,T,R,R]});

    this._exhibitHead(s, 6.70, 1.80, 6.20, 'TOP 8 WORST ESTIMATES', `Furthest from 1.0x ratio`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'CASE',options:{...hdr,align:'center'}},{text:'ASSIGNEE',options:{...hdr,align:'left'}},
       {text:'REPORTED',options:{...hdr,align:'center'}},{text:'ACTUAL',options:{...hdr,align:'center'}},
       {text:'RATIO',options:{...hdr,align:'center'}}],
      ...worst.map((c, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const r = Number(c.effort_ratio)||0;
        return [
          cell(`#${c.caseid}`, bg, 'center', N),
          cell(this._trunc(c.assignee_name||'—', 14), bg, 'left'),
          cell(`${(c.reported_effort||0).toFixed(1)}`, bg, 'center'),
          cell(`${(c.actual_aht||0).toFixed(1)}`, bg, 'center'),
          cell(`${r.toFixed(1)}x`, bg, 'center', r>=2||r<0.5?R:A),
        ];
      }),
    ];
    s.addTable(rows, {x:6.70,y:2.18,w:6.20,rowH:0.26,fontFace:'Calibri',colW:[1.00,1.70,1.20,1.20,1.10]});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR FY Comparison (year-over-year)
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRFYComparison(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6',RL='D4D4D0',DG='2C2C2C';
    const mpr = this._ops?.mprFull || {};
    const fy = mpr.fy_comparison || [];
    if (fy.length === 0) {
      const s = this.pptx.addSlide();
      this._slideChrome(s, 'FY comparison unavailable', 'No fy_comparison rows this period.', sn, ts, 'MPR FY Comparison');
      return;
    }
    const labels   = fy.map(r => r.current_month || '—');
    const curCases = fy.map(r => Number(r.current_cases)||0);
    const prvCases = fy.map(r => Number(r.prev_cases)||0);
    const totalCur = curCases.reduce((s,v)=>s+v,0);
    const totalPrv = prvCases.reduce((s,v)=>s+v,0);
    const yoyPct   = totalPrv>0 ? Math.round((totalCur-totalPrv)/totalPrv*100) : 0;

    const title = this._an?.hermes?.slides?.mprFy?.headline ||
      (totalPrv === 0
        ? `MPR YoY comparison: prior FY baseline unavailable; current FY at ${totalCur} cases`
        : `MPR volume ${yoyPct>=0?'+':''}${yoyPct}% YoY — ${totalCur.toLocaleString()} this FY vs ${totalPrv.toLocaleString()} prior`);
    const soWhat = this._an?.hermes?.slides?.mprFy?.soWhat ||
      `YoY swings >20% in either direction reveal seasonal or structural changes worth reviewing with capacity planning.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR FY Comparison');
    this._kpiStrip(s, [
      {value: totalCur.toLocaleString(), label:'Current FY', color:N},
      {value: totalPrv.toLocaleString(), label:'Prior FY', color:T},
      {value: `${yoyPct>=0?'+':''}${yoyPct}%`, label:'YoY Δ', color:Math.abs(yoyPct)>20?R:A},
      {value: fy.length, label:'Months Tracked', color:T},
      {value: Math.max(...curCases).toLocaleString(), label:'Peak Month', color:A},
      {value: Math.min(...curCases.filter(v=>v>0)).toLocaleString(), label:'Trough Month', color:MG},
    ]);

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'CURRENT FY vs PRIOR FY — MONTHLY CASES',
      `Source: mpr_data.fy_comparison`);
    s.addChart(this.pptx.ChartType.bar, [
      { name:'Current FY', labels, values: curCases },
      { name:'Prior FY',   labels, values: prvCases },
    ], {
      x:0.35,y:2.20,w:12.62,h:2.10,
      barDir:'col',barGrouping:'clustered',
      chartColors:[N, MG],
      showLegend:true, legendPos:'r', legendFontSize:9,
      showTitle:false, showValue:false,
      catAxisLabelFontSize:8, valAxisLabelFontSize:8,
      plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
    });

    // Bottom: yoy deltas as a bar list table
    this._bottomHead(s, 'MONTHLY YoY DELTAS');
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'MONTH',options:{...hdr,align:'left'}},{text:'CUR',options:{...hdr,align:'center'}},
       {text:'PREV',options:{...hdr,align:'center'}},{text:'Δ %',options:{...hdr,align:'center'}},
       {text:'AHT NOW',options:{...hdr,align:'center'}},{text:'AHT Δ',options:{...hdr,align:'center'}},
       {text:'SLA NOW',options:{...hdr,align:'center'}},{text:'SLA Δ',options:{...hdr,align:'center'}}],
      ...fy.slice(0, 9).map((r, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const yoy = r.cases_yoy_pct;
        const ahtD = r.aht_yoy_delta;
        const slaD = r.sla_yoy_delta;
        return [
          cell(r.current_month||'—', bg, 'left', N),
          cell(r.current_cases||'—', bg, 'center'),
          cell(r.prev_cases ?? '—', bg, 'center'),
          cell(yoy != null ? `${yoy>=0?'+':''}${yoy.toFixed(0)}%` : '—', bg, 'center', yoy!=null && Math.abs(yoy)>20 ? R : G),
          cell((r.current_aht ?? 0).toFixed(1) + 'h', bg, 'center'),
          cell(ahtD != null ? `${ahtD>=0?'+':''}${ahtD.toFixed(1)}` : '—', bg, 'center', ahtD!=null && ahtD>0 ? R : G),
          cell((r.current_sla ?? 0).toFixed(0) + '%', bg, 'center'),
          cell(slaD != null ? `${slaD>=0?'+':''}${slaD.toFixed(0)}` : '—', bg, 'center', slaD!=null && slaD<0 ? R : G),
        ];
      }),
    ];
    s.addTable(rows, {x:0.35,y:4.52,w:12.62,rowH:0.20,fontFace:'Calibri'});
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Sanity Checks Panel (workitems-core.checks)
  // ══════════════════════════════════════════════════════════════════════════
  _slideSanityChecks(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6';
    const checks = this._ops?.sanityChecks || [];
    const passed = checks.filter(c => c.severity === 'pass' || c.severity === 'ok' || c.count === 0).length;
    const warned = checks.filter(c => c.severity === 'warn' || c.severity === 'warning').length;
    const failed = checks.filter(c => c.severity === 'fail' || c.severity === 'error').length;

    const title = this._an?.hermes?.slides?.sanity?.headline ||
      (checks.length === 0
        ? `Sanity checks panel unavailable`
        : failed > 0
        ? `${failed} sanity check(s) failing — ${warned} warnings, ${passed} clean`
        : `All ${checks.length} sanity checks clean`);
    const soWhat = this._an?.hermes?.slides?.sanity?.soWhat ||
      `These are pre-deck gate checks — items that should never be true in a healthy work-item store. Each failing check is a data-quality bug worth tracking.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Sanity Checks');
    this._kpiStrip(s, [
      {value: checks.length, label:'Total Checks', color:N},
      {value: passed, label:'Pass', color:G},
      {value: warned, label:'Warn', color:warned>0?A:G},
      {value: failed, label:'Fail', color:failed>0?R:G},
      {value: checks.reduce((s,c)=>s+(c.count||0),0), label:'Total Items', color:T},
      {value: checks.length ? Math.round(passed/checks.length*100)+'%' : '—', label:'Pass Rate', color:G},
    ]);

    if (checks.length === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `ℹ  workitems-core.checks is empty for this period.`, T);
      return;
    }

    this._exhibitHead(s, 0.35, 1.80, 12.62, 'CHECK RESULTS', `${checks.length} gates evaluated`);
    checks.slice(0, 10).forEach((chk, i) => {
      const cy = 2.18 + i * 0.42;
      if (cy + 0.36 > 6.40) return;
      const sev = String(chk.severity||'').toLowerCase();
      const pc = sev === 'fail' || sev === 'error' ? R
               : sev === 'warn' || sev === 'warning' ? A
               : sev === 'pass' || sev === 'ok' ? G : T;
      const symbol = sev.startsWith('pass') || sev === 'ok' ? '✓' : sev.startsWith('warn') ? '!' : sev.startsWith('fail') ? '✗' : '·';
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:12.62,h:0.36,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:cy,w:0.36,h:0.36,fill:{color:pc},line:{type:'none'}});
      s.addText(symbol, {x:0.35,y:cy,w:0.36,h:0.36,fontSize:14,fontFace:'Calibri',color:'FFFFFF',bold:true,align:'center',valign:'middle'});
      s.addText(chk.name||'—', {x:0.80,y:cy,w:3.50,h:0.36,fontSize:10,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(`${chk.count||0} items`, {x:4.40,y:cy,w:1.20,h:0.36,fontSize:9,fontFace:'Calibri',color:pc,bold:true,valign:'middle'});
      s.addText(chk.detail || '—', {x:5.70,y:cy,w:7.20,h:0.36,fontSize:9,fontFace:'Calibri',color:DG,italic:true,valign:'middle'});
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Owner Performance Deep-Dive
  // Source: sprintData.byAssignee — personalCycleTime, reworkCount,
  // prsReviewed vs prsSubmitted asymmetry
  // ══════════════════════════════════════════════════════════════════════════
  _slideOwnerPerformance(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6',RL='D4D4D0';
    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }

    const owners = Object.values(flat)
      .filter(p => p && (p.itemCount || p.active || p.stale))
      .map(p => ({
        name: p.name || 'Unknown',
        active: Number(p.active)||0,
        cycleTime: Math.round(Number(p.personalCycleTime)||0),
        rework: Number(p.reworkCount)||0,
        prsSubmitted: Number(p.prsSubmitted)||0,
        prsReviewed:  Number(p.prsReviewed)||0,
        focus: Number(p.focusScore)||0,
        cycleTimes: Array.isArray(p.cycleTimes) ? p.cycleTimes : [],
      }))
      .filter(o => o.cycleTime > 0 || o.prsSubmitted > 0 || o.prsReviewed > 0)
      .sort((a, b) => b.cycleTime - a.cycleTime)
      .slice(0, 12);

    // Reviewer asymmetry — submit-heavy vs review-heavy
    const submitHeavy = owners.filter(o => o.prsSubmitted > o.prsReviewed * 2 + 1).length;
    const reviewHeavy = owners.filter(o => o.prsReviewed > o.prsSubmitted * 2 + 1).length;
    const balanced    = owners.length - submitHeavy - reviewHeavy;
    const avgCycle    = owners.length > 0 ? Math.round(owners.reduce((s,o)=>s+o.cycleTime, 0) / owners.length) : 0;
    const longestCT   = owners.length > 0 ? owners[0] : null;

    const title = this._an?.hermes?.slides?.ownerPerf?.headline ||
      (owners.length === 0
        ? `Per-owner performance data unavailable`
        : `${longestCT?.name||'—'} carries the longest cycle (${longestCT?.cycleTime||0}d); ${submitHeavy} submit-heavy vs ${reviewHeavy} review-heavy owners`);
    const soWhat = this._an?.hermes?.slides?.ownerPerf?.soWhat ||
      `Cycle-time distribution reveals individual delivery pace. Submit-vs-review asymmetry reveals who is creating vs gate-keeping — both extremes signal team-load imbalance.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Owner Performance');
    this._kpiStrip(s, [
      {value: owners.length, label:'Owners w/ Data', color: N},
      {value: `${avgCycle}d`, label:'Avg Cycle Time', color: avgCycle>60?R:avgCycle>30?A:G},
      {value: longestCT ? `${longestCT.cycleTime}d` : '—', label:'Longest Cycle', color: R},
      {value: submitHeavy, label:'Submit-Heavy', color: A},
      {value: reviewHeavy, label:'Review-Heavy', color: A},
      {value: balanced, label:'Balanced', color: G},
    ]);

    // LEFT: Cycle-time bar chart (top 10 by cycle time)
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'CYCLE TIME — TOP 10 BY DAYS',
      `Source: sprintData.byAssignee.personalCycleTime`);
    const ctRows = owners.slice(0, 10).map(o => ({name: o.name, count: o.cycleTime}));
    if (ctRows.length > 0) {
      const maxCT = Math.max(...ctRows.map(r => r.count), 1);
      this._drawDistribution(s, 0.35, 2.18, 6.10, 4.20, ctRows, {
        top: 10,
        palette: ctRows.map(r => r.count >= 60 ? R : r.count >= 30 ? A : G),
      });
    } else {
      s.addText('No cycle-time data this period.',
        {x:0.35,y:2.40,w:6.10,h:0.40,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // RIGHT: Reviewer-asymmetry table — submitted vs reviewed per owner
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'REVIEWER-VS-AUTHOR ASYMMETRY',
      `Who creates code vs who reviews it`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:8,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const prRanked = [...owners]
      .filter(o => o.prsSubmitted + o.prsReviewed > 0)
      .sort((a, b) => (b.prsSubmitted + b.prsReviewed) - (a.prsSubmitted + a.prsReviewed))
      .slice(0, 10);
    const rows = [
      [{text:'OWNER',options:{...hdr,align:'left'}},{text:'SUBMITTED',options:{...hdr,align:'center'}},
       {text:'REVIEWED',options:{...hdr,align:'center'}},{text:'RATIO',options:{...hdr,align:'center'}},
       {text:'TYPE',options:{...hdr,align:'center'}}],
      ...prRanked.map((o, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        const ratio = o.prsReviewed > 0 ? (o.prsSubmitted / o.prsReviewed).toFixed(1) : '∞';
        const type = o.prsSubmitted > o.prsReviewed * 2 + 1 ? 'Submit-Heavy'
                   : o.prsReviewed > o.prsSubmitted * 2 + 1 ? 'Review-Heavy'
                   : 'Balanced';
        const tColor = type === 'Balanced' ? G : type === 'Submit-Heavy' ? A : T;
        return [
          cell(this._trunc(o.name, 18), bg, 'left', N),
          cell(o.prsSubmitted, bg, 'center'),
          cell(o.prsReviewed, bg, 'center'),
          cell(`${ratio}x`, bg, 'center', T),
          cell(type, bg, 'center', tColor),
        ];
      }),
    ];
    if (prRanked.length === 0) {
      s.addText('No PR activity this period.',
        {x:6.70,y:2.40,w:6.20,h:0.40,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    } else {
      s.addTable(rows, {x:6.70,y:2.18,w:6.20,rowH:0.24,fontFace:'Calibri',colW:[2.10,1.00,1.00,0.90,1.20]});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Owner Velocity Grid
  // Source: sprintData.byAssignee[name].completedSparkline (4-week velocity)
  // Renders a 12-owner grid of mini sparkline bars showing per-owner trajectory
  // ══════════════════════════════════════════════════════════════════════════
  _slideOwnerVelocityGrid(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6',DG='2C2C2C';
    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }

    const owners = Object.values(flat)
      .filter(p => p && Array.isArray(p.completedSparkline) && p.completedSparkline.some(v => v > 0))
      .map(p => ({
        name: p.name || 'Unknown',
        sparkline: p.completedSparkline,
        total: p.completedSparkline.reduce((s,v)=>s+(Number(v)||0),0),
        last: Number(p.completedSparkline[p.completedSparkline.length-1])||0,
        first: Number(p.completedSparkline[0])||0,
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 12);

    const totalCompleted = owners.reduce((s, o) => s + o.total, 0);
    const improving = owners.filter(o => o.last > o.first).length;
    const declining = owners.filter(o => o.last < o.first).length;

    const title = this._an?.hermes?.slides?.ownerVel?.headline ||
      (owners.length === 0
        ? `Per-owner velocity sparkline data unavailable`
        : `${totalCompleted} items completed across ${owners.length} owners (last 4 weeks); ${improving} improving, ${declining} declining`);
    const soWhat = this._an?.hermes?.slides?.ownerVel?.soWhat ||
      `Each sparkline shows weeks-1-through-4 completion rate per owner. A downward trajectory in the last bar is the earliest warning of disengagement or overload.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Owner Velocity');
    this._kpiStrip(s, [
      {value: owners.length, label:'Active Owners', color: N},
      {value: totalCompleted, label:'4-Wk Completion', color: T},
      {value: improving, label:'Improving', color: G},
      {value: declining, label:'Declining', color: declining>0?R:G},
      {value: owners.length - improving - declining, label:'Flat', color: MG},
      {value: owners[0]?.last ?? '—', label:'Top Last Week', color: G},
    ]);

    // Grid: 12 sparklines in 3 columns × 4 rows
    this._exhibitHead(s, 0.35, 1.80, 12.62, 'PER-OWNER VELOCITY — 4-WEEK SPARKLINE',
      `Source: sprintData.byAssignee.*.completedSparkline · ordered by total`);
    const colCount = 3;
    const rowCount = 4;
    const cellW = (12.62 - 0.30) / colCount;
    const cellH = (6.50 - 2.20 - 0.10) / rowCount;
    const maxSpark = Math.max(...owners.flatMap(o => o.sparkline), 1);
    owners.slice(0, 12).forEach((o, idx) => {
      const r = Math.floor(idx / colCount), c = idx % colCount;
      const cx = 0.35 + c * cellW;
      const cy = 2.30 + r * cellH;
      s.addShape(this.pptx.ShapeType.rect, {x: cx, y: cy, w: cellW-0.10, h: cellH-0.10, fill:{color:'F7F7F5'}, line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect, {x: cx, y: cy, w: 0.06, h: cellH-0.10, fill:{color: o.last > o.first ? G : o.last < o.first ? R : MG}, line:{type:'none'}});
      // Name + total
      s.addText(this._trunc(o.name, 16), {x: cx+0.12, y: cy+0.04, w: cellW-0.40, h:0.20, fontSize:9, fontFace:'Calibri', color:N, bold:true});
      s.addText(`${o.total} total`, {x: cx+cellW-0.95, y: cy+0.04, w:0.75, h:0.20, fontSize:8, fontFace:'Calibri', color:MG, align:'right'});
      // Sparkline bars
      const sparkX = cx + 0.12;
      const sparkY = cy + 0.30;
      const sparkW = cellW - 0.30;
      const sparkH = cellH - 0.50;
      const bw = sparkW / o.sparkline.length;
      o.sparkline.forEach((v, vi) => {
        const h = (v / maxSpark) * sparkH;
        const bx = sparkX + vi * bw;
        const by = sparkY + sparkH - h;
        s.addShape(this.pptx.ShapeType.rect, {x: bx, y: by, w: bw-0.04, h: Math.max(0.02, h), fill:{color: vi === o.sparkline.length-1 ? N : T}, line:{type:'none'}});
        // Value label
        s.addText(String(v), {x: bx-0.10, y: by-0.18, w: bw+0.18, h:0.18, fontSize:7, fontFace:'Calibri', color: vi === o.sparkline.length-1 ? N : MG, bold: vi === o.sparkline.length-1, align:'center'});
      });
      // Week CUSTOMER_REDACTED labels
      ['W1','W2','W3','W4'].forEach((lab, vi) => {
        if (vi >= o.sparkline.length) return;
        s.addText(lab, {x: sparkX + vi*bw - 0.10, y: sparkY + sparkH + 0.02, w: bw+0.18, h:0.16, fontSize:6.5, fontFace:'Calibri', color:MG, align:'center'});
      });
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — MPR Per-Assignee Performance
  // Source: mpr.by_assignee + by_assignee_month + status_dwell_by_assignee
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRPerAssignee(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6',RL='D4D4D0';
    const mpr = this._ops?.mprFull || {};
    const byA = mpr.by_assignee || [];
    const byAM = mpr.by_assignee_month || [];
    const dwell = mpr.status_dwell_by_assignee || [];

    // Top 10 by total cases
    const top10 = [...byA]
      .filter(r => r.assignee_name && (r.total_cases||0) > 0)
      .sort((a,b) => (b.total_cases||0) - (a.total_cases||0))
      .slice(0, 10);
    const totalAll = byA.reduce((s,r) => s + (r.total_cases||0), 0);
    const topOwnerName = top10[0]?.assignee_name;

    // Dwell pivot: top 6 status groups × top 6 owners by dwell hours
    const top6Owners = top10.slice(0, 6).map(r => r.assignee_name);
    const statusGroups = [...new Set(dwell.map(d => d.status_group))].slice(0, 6);
    const dwellMap = {};
    let dwellMax = 0;
    for (const d of dwell) {
      if (top6Owners.includes(d.assignee_name) && statusGroups.includes(d.status_group)) {
        const k = `${d.assignee_name}|${d.status_group}`;
        dwellMap[k] = Number(d.avg_hours)||0;
        if (dwellMap[k] > dwellMax) dwellMax = dwellMap[k];
      }
    }

    const title = this._an?.hermes?.slides?.mprPerOwner?.headline ||
      (byA.length === 0
        ? `MPR per-assignee data unavailable`
        : `${topOwnerName} carries ${top10[0]?.total_cases||0} MPR cases (${Math.round((top10[0]?.total_cases||0)/Math.max(totalAll,1)*100)}% of total)`);
    const soWhat = this._an?.hermes?.slides?.mprPerOwner?.soWhat ||
      `Each assignee's MPR profile combines volume, resolution rate, SLA compliance, and stage-dwell time — a four-CUSTOMER_REDACTED view of where each person spends operational effort.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'MPR Per-Assignee');
    this._kpiStrip(s, [
      {value: byA.length, label:'Assignees', color:N},
      {value: totalAll.toLocaleString(), label:'Total MPR Cases', color:T},
      {value: top10[0]?.total_cases || '—', label:'Top Volume', color:A},
      {value: top10[0]?.resolution_rate_pct ? `${top10[0].resolution_rate_pct.toFixed(0)}%` : '—', label:'Top Res Rate', color:G},
      {value: byA.filter(r => (r.sla_compliance_pct||0) >= 95).length, label:'SLA Heroes ≥95%', color:G},
      {value: byA.filter(r => (r.open_cases||0) > 10).length, label:'Open>10 Cases', color:A},
    ]);

    // LEFT: top 10 by volume table
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'TOP 10 BY VOLUME',
      `Source: mpr_data.by_assignee · ${byA.length} assignees`);
    const noLine={type:'none'}, hl={pt:0.3,color:LG};
    const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:7,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
    const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
    const rows = [
      [{text:'OWNER',options:{...hdr,align:'left'}},{text:'TOTAL',options:{...hdr,align:'center'}},
       {text:'OPEN',options:{...hdr,align:'center'}},{text:'RES %',options:{...hdr,align:'center'}},
       {text:'AHT',options:{...hdr,align:'center'}}],
      ...top10.map((r, ri) => {
        const bg = ri%2===0?'FFFFFF':'F7F7F5';
        return [
          cell(this._trunc(r.assignee_name||'—', 18), bg, 'left', N),
          cell(r.total_cases||0, bg, 'center'),
          cell(r.open_cases||0, bg, 'center', (r.open_cases||0)>10?R:(r.open_cases||0)>3?A:G),
          cell(`${(r.resolution_rate_pct||0).toFixed(0)}%`, bg, 'center', (r.resolution_rate_pct||0)>=90?G:A),
          cell(`${(r.avg_aht||0).toFixed(0)}h`, bg, 'center', (r.avg_aht||0)>=48?R:(r.avg_aht||0)>=24?A:G),
        ];
      }),
    ];
    s.addTable(rows, {x:0.35,y:2.18,w:6.10,rowH:0.22,fontFace:'Calibri',colW:[2.10,0.90,0.90,1.00,1.20]});

    // RIGHT: Status-dwell heatmap (top 6 owners × top 6 stages)
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'STATUS DWELL — TOP 6 BY STAGE',
      `avg hours per status group · per owner`);
    if (top6Owners.length > 0 && statusGroups.length > 0) {
      this._drawHeatmap(s, 6.70, 2.18, 6.20, 4.20, [], {
        rows: top6Owners, cols: statusGroups, max: dwellMax || 1,
        lookup: (rL, cL) => dwellMap[`${rL}|${cL}`] || 0,
        cornerLabel: 'OWNER ↓ / STAGE →',
      });
    } else {
      s.addText('Dwell data unavailable.',
        {x:6.70,y:2.40,w:6.20,h:0.40,fontSize:9,fontFace:'Calibri',color:MG,italic:true});
    }

    // BOTTOM: Monthly trend for top owner
    this._bottomHead(s, `MONTHLY TREND — ${this._trunc(topOwnerName||'Top Owner', 30)}`);
    const topOwnerMonthly = byAM
      .filter(r => r.assignee_name === topOwnerName)
      .slice(0, 12);
    if (topOwnerMonthly.length >= 2) {
      const labels = topOwnerMonthly.map(r => r.month_label || '—');
      const reported = topOwnerMonthly.map(r => Number(r.cases_reported)||0);
      const closed = topOwnerMonthly.map(r => Number(r.cases_closed)||0);
      s.addChart(this.pptx.ChartType.bar, [
        { name:'Reported', labels, values: reported },
        { name:'Closed',   labels, values: closed   },
      ], {
        x:0.35,y:4.55,w:12.62,h:1.85,
        barDir:'col',barGrouping:'clustered',
        chartColors:[A, G],
        showLegend:true, legendPos:'r', legendFontSize:9,
        showTitle:false, showValue:false,
        catAxisLabelFontSize:8, valAxisLabelFontSize:8,
        plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
      });
    } else {
      s.addText('Insufficient monthly history for top owner.',
        {x:0.35,y:4.80,w:12.62,h:0.40,fontSize:10,fontFace:'Calibri',color:MG,italic:true,align:'center'});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Governance Metric History
  // Source: gov.metricHistory (snapshots over time)
  // ══════════════════════════════════════════════════════════════════════════
  _slideGovMetricHistory(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6',RL='D4D4D0';
    const mh = this._ops?.govMetricHistory || {};
    const snaps = Array.isArray(mh.snapshots) ? mh.snapshots : [];
    // Reverse so oldest → newest left-to-right
    const ordered = [...snaps].sort((a,b) => new Date(a.generatedAt||0) - new Date(b.generatedAt||0));
    const latest = ordered[ordered.length-1] || {};
    const earliest = ordered[0] || {};
    const snapCount = ordered.length;

    const title = this._an?.hermes?.slides?.metricHistory?.headline ||
      (snapCount === 0
        ? `Metric history snapshot unavailable`
        : snapCount < 2
        ? `Metric history captured — ${latest.metricCount||0} metrics, ${latest.riskCount||0} risks; trend chart will populate as snapshots accumulate weekly`
        : `Metric history spans ${snapCount} snapshots; ${latest.criticalRiskCount||0} critical risks active, ${latest.dataTrustFailures||0} data-trust failures`);
    const soWhat = this._an?.hermes?.slides?.metricHistory?.soWhat ||
      `Governance health is a slow signal. A single snapshot is a point-in-time; multi-snapshot trends reveal whether the platform is maturing or regressing structurally.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Metric History');
    this._kpiStrip(s, [
      {value: latest.metricCount ?? '—', label:'Metrics Tracked', color: N},
      {value: latest.documentedMetricCount ?? '—', label:'Documented', color: G},
      {value: latest.riskCount ?? '—', label:'Total Risks', color: T},
      {value: latest.criticalRiskCount ?? '—', label:'Critical Risks', color:(latest.criticalRiskCount||0)>0?R:G},
      {value: latest.dataTrustFailures ?? '—', label:'Data Failures', color:(latest.dataTrustFailures||0)>0?R:G},
      {value: latest.operationalItems ? latest.operationalItems.toLocaleString() : '—', label:'Op Items Indexed', color: N},
    ]);

    if (snapCount === 0) {
      this._calloutBox(s, 0.35, 2.30, 12.62, 0.80,
        `ℹ  governance.metricHistory.snapshots is empty.`, T);
      return;
    }

    // LEFT: Snapshot detail
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'LATEST SNAPSHOT',
      `Generated: ${latest.generatedAt ? new Date(latest.generatedAt).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}) : '—'}`);
    const facts = [
      ['Metrics tracked',          `${latest.metricCount||0} (${latest.documentedMetricCount||0} documented)`],
      ['Risk register',            `${latest.riskCount||0} total · ${latest.criticalRiskCount||0} critical`],
      ['Data trust',               `${latest.dataTrustFailures||0} failures · ${latest.dataTrustWarnings||0} warnings`],
      ['Operational index',        `${(latest.operationalItems||0).toLocaleString()} items · ${(latest.totalIndexed||0).toLocaleString()} indexed`],
      ['Source-link coverage',     `${latest.sourceLinkCoverage||0}%`],
      ['Top risk',                 `${this._trunc(latest.topRisk||'—', 40)} · score ${latest.topRiskScore||0}`],
    ];
    facts.forEach((f, i) => {
      const fy = 2.20 + i*0.36;
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:fy,w:6.10,h:0.30,fill:{color:'F7F7F5'},line:{type:'none'}});
      s.addShape(this.pptx.ShapeType.rect,{x:0.35,y:fy,w:0.06,h:0.30,fill:{color:N},line:{type:'none'}});
      s.addText(f[0], {x:0.50,y:fy,w:2.60,h:0.30,fontSize:9,fontFace:'Calibri',color:N,bold:true,valign:'middle'});
      s.addText(f[1], {x:3.20,y:fy,w:3.20,h:0.30,fontSize:9,fontFace:'Calibri',color:DG,valign:'middle'});
    });

    // RIGHT: Trend if ≥2 snapshots
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'KEY METRICS — TREND',
      snapCount >= 2 ? `${snapCount} snapshots tracked` : 'Need ≥2 snapshots for trend');
    if (snapCount >= 2) {
      const labels = ordered.map(snap => snap.generatedAt ? new Date(snap.generatedAt).toLocaleDateString('en-IN',{month:'short',day:'numeric'}) : '—');
      const risks = ordered.map(snap => Number(snap.riskCount)||0);
      const critRisks = ordered.map(snap => Number(snap.criticalRiskCount)||0);
      s.addChart(this.pptx.ChartType.line, [
        { name:'Total Risks', labels, values: risks },
        { name:'Critical Risks', labels, values: critRisks },
      ], {
        x:6.70,y:2.20,w:6.20,h:4.20,
        chartColors:[T, R],
        showLegend:true, legendPos:'b', legendFontSize:9,
        showTitle:false, showValue:true, dataLabelFontSize:8,
        catAxisLabelFontSize:8, valAxisLabelFontSize:8,
        lineSize:2.5, lineDataSymbol:'circle', lineDataSymbolSize:7,
        plotAreaBorderColor:RL, plotAreaBorderSize:0.3,
      });
    } else {
      s.addShape(this.pptx.ShapeType.rect,{x:6.70,y:2.20,w:6.20,h:4.20,fill:{color:'F7F7F5'},line:{color:RL,width:0.5}});
      s.addText('1 snapshot', {x:6.70,y:2.60,w:6.20,h:0.80,fontSize:48,fontFace:'Calibri',color:N,bold:true,align:'center'});
      s.addText('Captured today. Multi-week trend will populate as weekly snapshots accumulate.',
        {x:6.95,y:3.50,w:5.70,h:1.20,fontSize:11,fontFace:'Calibri',color:MG,italic:true,align:'center',lineSpacing:16});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NEW SLIDE — Alert Trend Detail
  // Source: wi.alertTrend + wi.alertsByOwner (deeper breakdown)
  // ══════════════════════════════════════════════════════════════════════════
  _slideAlertTrendDetail(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',LG='E8E8E6',DG='2C2C2C',RL='D4D4D0';
    const cur = this._ops?.alertCount || (this._sprintData?.alerts?.length) || 0;
    const trend = this._ops?.alertTrend || 0;
    const byOwner = this._sprintData?.alertsByOwner || {};
    const alerts = this._sprintData?.alerts || [];

    // Aggregate by type / severity
    const byType = {};
    const bySev = {};
    for (const al of alerts) {
      const k = al.type || 'unknown';
      byType[k] = (byType[k] || 0) + 1;
      const sv = al.severity || al.priority || 'normal';
      bySev[sv] = (bySev[sv] || 0) + 1;
    }
    const typeRows = Object.entries(byType).sort((a,b) => b[1]-a[1]).map(([name, count]) => ({name, count, percent: alerts.length>0 ? Math.round(count/alerts.length*100) : 0}));
    const sevRows  = Object.entries(bySev).sort((a,b) => b[1]-a[1]).map(([name, count]) => ({name, count, percent: alerts.length>0 ? Math.round(count/alerts.length*100) : 0}));
    const ownerRows = Object.entries(byOwner)
      .map(([name, v]) => ({name, count: typeof v === 'object' ? (v.count||v.total||(v.alerts?.length)||0) : Number(v)||0}))
      .sort((a,b) => b.count - a.count)
      .slice(0, 8);

    // Build pseudo-history from weeklyHistory
    const hist = (this._an?.weeklyHistory || []).slice(0, 8).reverse();
    const series = hist.map(h => Number(h.alertCount)||0);
    const seriesLabels = hist.map(h => h.startedAt ? new Date(h.startedAt).toLocaleDateString('en-IN',{month:'short',day:'numeric'}) : '—');

    const title = this._an?.hermes?.slides?.alertDetail?.headline ||
      (cur === 0
        ? `Alert system quiet — no active alerts this period`
        : `${cur} active alerts across ${ownerRows.length} owners; ${trend>=0?'+':''}${trend} vs last run`);
    const soWhat = this._an?.hermes?.slides?.alertDetail?.soWhat ||
      `Alert volume = lagging indicator of operational health. Type breakdown reveals what's most often going wrong; owner concentration reveals who carries the noise.`;

    const s = this.pptx.addSlide();
    this._slideChrome(s, title, soWhat, sn, ts, 'Alert Trend Detail');
    this._kpiStrip(s, [
      {value: cur, label:'Active Alerts', color: cur>10?R:cur>3?A:G},
      {value: `${trend>=0?'+':''}${trend}`, label:'Δ vs Last Run', color: trend<=0?G:R},
      {value: typeRows.length, label:'Alert Types', color: T},
      {value: sevRows.length, label:'Severities', color: N},
      {value: ownerRows.length, label:'Owners Hit', color: A},
      {value: ownerRows[0]?.count || 0, label:'Top Owner Count', color: ownerRows[0]?.count>=5?R:A},
    ]);

    // LEFT: by type
    this._exhibitHead(s, 0.35, 1.80, 6.10, 'BY ALERT TYPE', `${typeRows.length} types`);
    this._drawDistribution(s, 0.35, 2.18, 6.10, 1.85, typeRows, {top: 6});

    // RIGHT: by severity
    this._exhibitHead(s, 6.70, 1.80, 6.20, 'BY SEVERITY', `${sevRows.length} severity levels`);
    this._drawDistribution(s, 6.70, 2.18, 6.20, 1.85, sevRows, {top: 6, palette:[R,A,T,G,MG]});

    // BOTTOM: by owner
    this._bottomHead(s, 'BY OWNER — ALERT CONCENTRATION');
    if (ownerRows.length > 0) {
      this._drawDistribution(s, 0.35, 4.55, 12.62, 1.85, ownerRows, {top: 8, palette: ownerRows.map(o => o.count>=5?R:o.count>=2?A:T)});
    } else {
      s.addText('No per-owner alert data this period.',
        {x:0.35,y:4.80,w:12.62,h:0.40,fontSize:10,fontFace:'Calibri',color:MG,italic:true,align:'center'});
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ITSM COCKPIT — replaces _slideITSM + _slideITSMVolumeDrivers + _slideITSM (status panel of Matrix)
  //   Compresses 3 ITSM slides into 1 dense cockpit. KPI strip + 4 quadrants
  //   (status / aging / top accounts / 12-week trend) + LLM insight panel.
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMCockpit(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',RL='D4D4D0';
    const ops = this._ops || {};
    const ism = ops.itsmSummary || {};
    const total = ism.total || 0;
    const open = ism.open || 0;
    const closed = ism.closed || 0;
    const stale = ism.staleOpen || 0;
    const avgDur = ism.avgDurationDays ? `${Number(ism.avgDurationDays).toFixed(1)}d` : '—';

    const byStatus = ism.byStatus || {};
    const statusBars = Object.entries(byStatus).sort((a,b) => b[1]-a[1]).slice(0, 5).map(([k,v]) => ({label: k, value: v}));

    const agBrackets = Array.isArray(ops.itsmAgingBrackets) ? ops.itsmAgingBrackets : [];
    const agingSegs = agBrackets.length > 0
      ? agBrackets.slice(0, 5).map((b, i) => ({label: b.bracket || `Bucket ${i+1}`, count: b.count || 0, color: [G,T,A,R,N][i] || MG}))
      : [
          {label:'0–7d',    count: Math.max(0, open-stale), color: G},
          {label:'8–30d',   count: Math.round(stale*0.50), color: T},
          {label:'31–90d',  count: Math.round(stale*0.30), color: A},
          {label:'91–300d', count: Math.round(stale*0.15), color: R},
          {label:'300+d',   count: Math.round(stale*0.05), color: N},
        ].filter(sg => sg.count > 0);

    const stale300 = agBrackets.find(b => (b.bracket||'').includes('300'))?.count || 0;
    const acct = ((ops.itsmDistributions || {}).accountName || []).slice(0, 5);
    const accountCount = ((ops.itsmDistributions || {}).accountName || []).length;

    const rawTrend = Array.isArray(ism.trending12w) ? ism.trending12w
      : Array.isArray(ops.itsmTrend) ? ops.itsmTrend.map(t => t.open || t.created || 0) : [];

    const hermesSlide = this._an?.hermes?.slides?.itsmCockpit || {};
    const title = hermesSlide.headline
      || (stale300 > 0
          ? `ITSM: ${total.toLocaleString()} cases · ${stale} stale · ${stale300} aged 300+ days require escalation`
          : stale > 0
          ? `ITSM: ${total.toLocaleString()} cases · ${stale} stale exceeding SLA · triage sprint required`
          : `ITSM stable: ${total.toLocaleString()} cases · ${closed.toLocaleString()} resolved · ${avgDur} avg resolution`);
    const soWhat = hermesSlide.soWhat
      || `Compressed ITSM cockpit — see LLM panel for diagnosis across volume, aging, account concentration, and 12-week trend.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'ITSM Cockpit',
      kpis: [
        {value: total.toLocaleString(), label:'Total Cases',     color: N},
        {value: open,                   label:'Open',            color: A},
        {value: closed.toLocaleString(),label:'Closed',          color: G},
        {value: stale,                  label:'Stale (>7d)',     color: R},
        {value: stale300,               label:'300+ Days',       color: stale300>0?R:G},
        {value: avgDur,                 label:'Avg Resolution',  color: T},
      ],
      quadrants: [
        {
          title: 'STATUS DISTRIBUTION',
          subtitle: `Top ${statusBars.length} statuses · ${total.toLocaleString()} cases`,
          render: (s, x, y, w) => {
            const maxV = Math.max(...statusBars.map(b => b.value), 1);
            this._hBar(s, x, y, w, statusBars, maxV, null, (i) => i===0?N : i<=2?T : MG, h);
          },
        },
        {
          title: 'AGE DISTRIBUTION',
          subtitle: `${open} open cases by age bracket`,
          render: (s, x, y, w) => {
            this._stackedBar(s, x, y+0.18, w, 0.36, agingSegs, {noLegend:true});
          },
        },
        {
          title: 'TOP ACCOUNTS BY VOLUME',
          subtitle: `${accountCount} accounts · top 5 shown`,
          render: (s, x, y, w, h) => {
            if (acct.length > 0) this._drawDistribution(s, x, y, w, h, acct);
            else s.addText('No account distribution data', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
          },
        },
        {
          title: '12-WEEK OPEN-CASE TREND',
          subtitle: rawTrend.length ? `${rawTrend.length} weeks · last: ${rawTrend[rawTrend.length-1]||0}` : 'No trend data',
          render: (s, x, y, w, h) => {
            if (rawTrend.length >= 2) {
              const labels = rawTrend.map((_, i) => `W${i+1}`);
              s.addChart(this.pptx.ChartType.line, [{name:'Open', labels, values: rawTrend}], {
                x, y, w, h, chartColors:[N], lineDataSymbol:'none', lineSmooth:true,
                showLegend:false, showTitle:false, valAxisMinVal:0,
                catAxisLabelFontSize:6, valAxisLabelFontSize:6, dataLabelFontSize:0,
                plotAreaBorderColor: RL, plotAreaBorderSize:0.3,
              });
            } else {
              s.addText('Insufficient trend history', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
            }
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ITSM DIAGNOSTICS — replaces _slideITSMProfile + _slideITSMRootCausePivot +
  //   _slideITSMAnalysisRootCause + _slideITSMMatrix into one diagnostic page.
  //   Top quadrants = OEG category + Age bucket profile.
  //   Bottom half = full-width Root-Cause × Category heatmap (the killer matrix).
  //   LLM insight panel sits below — moved to top via fullWidthTop pattern.
  // Note: with full-width top, we render the matrix above the LLM panel.
  // ══════════════════════════════════════════════════════════════════════════
  _slideITSMDiagnostics(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',RL='D4D4D0';
    const ops = this._ops || {};
    const d = ops.itsmDistributions || {};
    // BUG FIX: Neocities itsmDistributions and itsmMatrices contain literal
    // "Unspecified" entries that win the top-N rankings. The bridge
    // normalizer's filter only fires when upstream is empty — when upstream
    // supplies populated distributions, we have to strip "Unspecified" /
    // "Unknown" / "N/A" at the slide level too. Tracked separately so
    // they can be surfaced as a data-quality footnote.
    const isMeaningful = (name) => name && !/^(unspecified|unknown|n\/a|none|null|—|other)$/i.test(String(name).trim());
    const cat = (d.oegCategory || []).filter(c => isMeaningful(c.name)).slice(0, 5);
    const age = (d.ageBucket   || []).filter(b => isMeaningful(b.name)).slice(0, 5);
    const unspecifiedCat = (d.oegCategory || []).find(c => !isMeaningful(c.name));

    const matrixRaw = ops.itsmMatrices?.rootCauseByCategory || [];
    // Filter "Unspecified" out of both axes of the matrix
    const matrix = matrixRaw.filter(r => isMeaningful(r.left) && isMeaningful(r.top));
    const droppedCells = matrixRaw.length - matrix.length;
    const byLeft = {}, byTop = {};
    for (const r of matrix) {
      byLeft[r.left] = (byLeft[r.left]||0) + r.count;
      byTop[r.top]   = (byTop[r.top]||0)   + r.count;
    }
    // Reduced top-N from 6→5 to keep cells readable in 0.88"-tall wideBottom area
    const topLefts = Object.entries(byLeft).sort((a,b)=>b[1]-a[1]).slice(0, 5).map(e => e[0]);
    const topTops  = Object.entries(byTop).sort((a,b)=>b[1]-a[1]).slice(0, 5).map(e => e[0]);
    const grid = {};
    for (const r of matrix) {
      if (topLefts.includes(r.left) && topTops.includes(r.top)) grid[`${r.left}|${r.top}`] = r.count;
    }
    const maxCell = Math.max(...Object.values(grid), 1);
    const totalMatrix = Object.values(byLeft).reduce((s,v) => s+v, 0);
    const oldCases = (age.find(b => /\>180|\>365|180-/.test(b.name||''))?.count || 0);

    const hermesSlide = this._an?.hermes?.slides?.itsmDiagnostics || {};
    const title = hermesSlide.headline
      || (matrix.length === 0
          ? `ITSM diagnostics: root-cause matrix unavailable — Neocities matrices.rootCauseByCategory not populated`
          : `${topLefts[0]||'—'} concentrates ${Math.round((byLeft[topLefts[0]]||0)/Math.max(totalMatrix,1)*100)}% of cases · ${oldCases} cases >180 days`);
    const soWhat = hermesSlide.soWhat
      || `Hot cells in the matrix reveal where a specific root cause clusters in a specific case category — these are the engineering bug families worth a dedicated fix sprint.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'ITSM Diagnostics',
      kpis: [
        {value: totalMatrix.toLocaleString(), label:'Cases in Matrix', color: N},
        {value: this._trunc(topLefts[0]||'—', 14), label:'Top Root Cause', color: R},
        {value: this._trunc(topTops[0]||'—', 14), label:'Top Category', color: A},
        {value: maxCell, label:'Hottest Cell', color: R},
        {value: this._trunc(cat[0]?.name||'—', 14), label:'Top OEG Cat', color: T},
        {value: oldCases, label:'>180-Day Cases', color: oldCases>0?R:G},
      ],
      quadrants: [
        {
          title: 'OEG CATEGORY DISTRIBUTION',
          subtitle: `Top ${cat.length} categories`,
          render: (s, x, y, w, h) => {
            if (cat.length > 0) this._drawDistribution(s, x, y, w, h, cat);
            else s.addText('No OEG category data', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
          },
        },
        {
          title: 'AGE BUCKET PROFILE',
          subtitle: `${age.length} buckets · zombie tickets >180d highlighted`,
          render: (s, x, y, w, h) => {
            if (age.length > 0) this._drawDistribution(s, x, y, w, h, age, {palette:[G,G,A,A,R,R,R]});
            else s.addText('No age bucket data', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
          },
        },
      ],
      // BUG FIX: heatmap was crushed in a single 6.26"×0.78" Q3 quadrant —
      // 6×6 grid means cells were ~1"×0.13", labels unreadable. Now spans
      // the full bottom row (12.62" × 0.78") so cells are 1.5"×0.13" with
      // label column at ~3" wide for the long root-cause names.
      wideBottom: {
        title: 'ROOT CAUSE × CATEGORY HEATMAP — TOP 6 × 6',
        subtitle: matrix.length > 0 ? `${matrix.length} cells · max ${maxCell}` : 'matrices.rootCauseByCategory empty',
        render: (s, x, y, w, h) => {
          if (matrix.length === 0 || topLefts.length === 0) {
            s.addText('Root-cause matrix not available', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
            return;
          }
          this._drawHeatmap(s, x, y, w, h, [], {
            rows: topLefts, cols: topTops, max: maxCell,
            lookup: (rL, cL) => grid[`${rL}|${cL}`] || 0,
            cornerLabel: 'CAUSE ↓ / CAT →',
          });
        },
      },
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MPR COCKPIT — replaces ChannelType + AgingSLA + Stuck + EffortAccuracy + FYComparison (5 → 1)
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPRCockpit(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',RL='D4D4D0';
    const mpr = this._ops?.mprFull || {};
    const weekly = Array.isArray(mpr.weekly_volume) ? mpr.weekly_volume : [];
    const last8 = weekly.slice(-8);
    const reported = last8.map(w => Number(w.cases_reported)||0);
    const closed   = last8.map(w => Number(w.cases_closed)||0);
    const cumIn    = weekly.length ? Number(weekly[weekly.length-1].cum_inflow)||0 : 0;
    const cumClose = weekly.length ? Number(weekly[weekly.length-1].cum_closed)||0 : 0;
    const backlog  = cumIn - cumClose;
    const recentReported = reported.reduce((s,v)=>s+v, 0);
    const recentClosed = closed.reduce((s,v)=>s+v, 0);
    const recentNet = recentClosed - recentReported;

    const aging = (mpr.aging_summary || []).map(a => ({name: a.aging_bucket, count: a.case_count, percent: a.pct}));
    const sla = (mpr.sla_burn_rate || []).map(s => ({name: s.risk_zone, count: s.case_count, percent: s.pct}));
    const crit = sla.find(s => s.name === 'Critical')?.count || 0;
    const safe = sla.find(s => s.name === 'Safe')?.count || 0;

    const stuckN = (mpr.stuck_in_new || []).length;
    const stuckA = (mpr.stuck_in_awaiting || []).length;
    const longestNew = Math.max(...(mpr.stuck_in_new||[]).map(c=>c.new_hours||0), 0);
    const longestAwait = Math.max(...(mpr.stuck_in_awaiting||[]).map(c=>c.awaiting_hours||0), 0);
    const totalStuck = stuckN + stuckA + (mpr.user_creation_aging?.length||0);

    const effort = mpr.effort_accuracy || [];
    const accurate = effort.filter(c => { const r = Number(c.effort_ratio)||0; return r >= 0.9 && r < 1.1; }).length;
    const accuracyPct = effort.length > 0 ? Math.round(accurate/effort.length*100) : 0;

    const fy = mpr.fy_comparison || [];
    const totalCur = fy.reduce((s,r) => s+(Number(r.current_cases)||0), 0);
    const totalPrv = fy.reduce((s,r) => s+(Number(r.prev_cases)||0), 0);
    const yoyPct = totalPrv > 0 ? Math.round((totalCur-totalPrv)/totalPrv*100) : 0;

    const hermesSlide = this._an?.hermes?.slides?.mprCockpit || {};
    const title = hermesSlide.headline
      || (weekly.length === 0
          ? `MPR cockpit unavailable — no mpr_data fields populated`
          : crit > 0
          ? `MPR: ${backlog.toLocaleString()} backlog · ${crit} Critical SLA · YoY ${yoyPct>=0?'+':''}${yoyPct}% · ${accuracyPct}% effort accuracy`
          : `MPR stable: net ${recentNet>=0?'+':''}${recentNet} (8w) · backlog ${backlog.toLocaleString()} · ${accuracyPct}% effort accuracy · YoY ${yoyPct>=0?'+':''}${yoyPct}%`);
    const soWhat = hermesSlide.soWhat
      || `Compressed MPR view across volume, aging, SLA, stuck, and accuracy. See LLM panel for diagnosis.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'MPR Cockpit',
      kpis: [
        {value: backlog.toLocaleString(), label:'Running Backlog', color: backlog>500?R:backlog>100?A:G},
        {value: `${recentNet>=0?'+':''}${recentNet}`, label:'Net Flow (8w)', color: recentNet>=0?G:R},
        {value: crit, label:'Critical SLA', color: crit>0?R:G},
        {value: totalStuck, label:'Stuck Cases', color: totalStuck>20?R:totalStuck>0?A:G},
        {value: `${accuracyPct}%`, label:'Effort Accuracy', color: accuracyPct>=70?G:accuracyPct>=50?A:R},
        {value: `${yoyPct>=0?'+':''}${yoyPct}%`, label:'YoY Volume', color: Math.abs(yoyPct)>20?A:G},
      ],
      quadrants: [
        {
          title: 'WEEKLY INFLOW vs CLOSURE — LAST 8 WEEKS',
          subtitle: `${weekly.length} weeks tracked · recent net ${recentNet>=0?'+':''}${recentNet}`,
          render: (s, x, y, w, h) => {
            if (last8.length >= 2) {
              const labels = last8.map(w => { try { return new Date(w.week_start).toLocaleDateString('en-IN',{month:'short',day:'numeric'}); } catch { return '—'; } });
              s.addChart(this.pptx.ChartType.bar, [
                { name:'Reported', labels, values: reported },
                { name:'Closed',   labels, values: closed   },
              ], {
                x, y, w, h, barDir:'col', barGrouping:'clustered',
                chartColors:[A, G], showLegend:true, legendPos:'b', legendFontSize:6,
                showTitle:false, showValue:false,
                catAxisLabelFontSize:6, valAxisLabelFontSize:6, dataLabelFontSize:0,
                plotAreaBorderColor: RL, plotAreaBorderSize:0.3,
              });
            } else {
              s.addText('Insufficient weekly data', {x, y, w, h, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
            }
          },
        },
        {
          title: 'AGING DISTRIBUTION + SLA ZONES',
          subtitle: `${aging.length} buckets · ${sla.length} SLA zones`,
          render: (s, x, y, w, h) => {
            // Top half: aging stacked
            const agingSegs = aging.slice(0, 6).map((a, i) => ({label: a.name, count: a.count, color: ['27AE60','27AE60','E67E22','E67E22','C0392B','C0392B'][i] || MG}));
            this._stackedBar(s, x, y+0.05, w, 0.30, agingSegs, {noLegend:true});
            // Bottom: SLA strip
            const slaSegs = sla.slice(0, 4).map(z => ({label: z.name, count: z.count, color: z.name==='Safe'?G : /warn/i.test(z.name)?A : R}));
            this._stackedBar(s, x, y+0.55, w, 0.30, slaSegs, {noLegend:true});
          },
        },
        {
          title: 'STUCK CASES — TRIAGE',
          subtitle: `${totalStuck} stuck · longest ${Math.max(longestNew, longestAwait).toFixed(0)}h`,
          render: (s, x, y, w, h) => {
            const rows = [
              {label: 'Stuck in New', value: stuckN},
              {label: 'Stuck in Awaiting', value: stuckA},
              {label: 'User-Creation', value: mpr.user_creation_aging?.length||0},
              {label: 'Longest (h)', value: Math.max(longestNew, longestAwait).toFixed(0)},
            ].filter(r => r.value);
            if (rows.length > 0) {
              const mx = Math.max(...rows.map(r => Number(r.value)||0), 1);
              this._hBar(s, x, y, w, rows, mx, null, (i, v) => Number(v)>=20 ? R : Number(v)>=5 ? A : T, h);
            } else {
              s.addText('No stuck cases', {x, y, w, h, fontSize:9, color:G, italic:true, align:'center', valign:'middle'});
            }
          },
        },
        {
          title: 'EFFORT ACCURACY DISTRIBUTION',
          subtitle: `${effort.length.toLocaleString()} cases · accurate (±10%) ${accuracyPct}%`,
          render: (s, x, y, w, h) => {
            if (effort.length === 0) { s.addText('No effort_accuracy data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const buckets = { '< 0.5x':0, '0.5-0.9x':0, '0.9-1.1x':0, '1.1-2x':0, '2-5x':0, '> 5x':0 };
            for (const c of effort) {
              const r = Number(c.effort_ratio)||0;
              if (r < 0.5) buckets['< 0.5x']++;
              else if (r < 0.9) buckets['0.5-0.9x']++;
              else if (r < 1.1) buckets['0.9-1.1x']++;
              else if (r < 2) buckets['1.1-2x']++;
              else if (r < 5) buckets['2-5x']++;
              else buckets['> 5x']++;
            }
            const dist = Object.entries(buckets).map(([name, count]) => ({name, count, percent: Math.round(count/effort.length*100)}));
            this._drawDistribution(s, x, y, w, h, dist, {top: dist.length, palette:[A,A,G,T,R,R]});
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MPR OWNER LENS — replaces _slideMPRPerAssignee, restructured into cockpit form
  // ══════════════════════════════════════════════════════════════════════════
  _slideMPROwnerLens(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6',RL='D4D4D0';
    const mpr = this._ops?.mprFull || {};
    const byA = mpr.by_assignee || [];
    const byAM = mpr.by_assignee_month || [];
    const dwell = mpr.status_dwell_by_assignee || [];

    const top10 = [...byA].filter(r => r.assignee_name && (r.total_cases||0) > 0)
      .sort((a,b) => (b.total_cases||0) - (a.total_cases||0)).slice(0, 10);
    const totalAll = byA.reduce((s,r) => s + (r.total_cases||0), 0);
    const topOwnerName = top10[0]?.assignee_name;

    const top6Owners = top10.slice(0, 6).map(r => r.assignee_name);
    const statusGroups = [...new Set(dwell.map(d => d.status_group))].slice(0, 5);
    const dwellMap = {};
    let dwellMax = 0;
    for (const d of dwell) {
      if (top6Owners.includes(d.assignee_name) && statusGroups.includes(d.status_group)) {
        const k = `${d.assignee_name}|${d.status_group}`;
        dwellMap[k] = Number(d.avg_hours)||0;
        if (dwellMap[k] > dwellMax) dwellMax = dwellMap[k];
      }
    }
    const slaHeroes = byA.filter(r => (r.sla_compliance_pct||0) >= 95).length;
    const overloaded = byA.filter(r => (r.open_cases||0) > 10).length;

    const hermesSlide = this._an?.hermes?.slides?.mprOwnerLens || {};
    const title = hermesSlide.headline
      || (byA.length === 0
          ? `MPR per-assignee data unavailable`
          : `${topOwnerName} carries ${top10[0]?.total_cases||0} cases (${Math.round((top10[0]?.total_cases||0)/Math.max(totalAll,1)*100)}% of ${totalAll.toLocaleString()}); ${overloaded} overloaded · ${slaHeroes} SLA heroes`);
    const soWhat = hermesSlide.soWhat
      || `Per-assignee profile combines volume, SLA compliance, stage-dwell, and monthly trajectory — four-CUSTOMER_REDACTED view of operational effort allocation.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'MPR Owner Lens',
      kpis: [
        {value: byA.length, label:'Assignees', color: N},
        {value: totalAll.toLocaleString(), label:'Total Cases', color: T},
        {value: top10[0]?.total_cases || '—', label:'Top Volume', color: A},
        {value: top10[0]?.resolution_rate_pct ? `${top10[0].resolution_rate_pct.toFixed(0)}%` : '—', label:'Top Res Rate', color: G},
        {value: slaHeroes, label:'SLA Heroes ≥95%', color: G},
        {value: overloaded, label:'Open >10 Cases', color: overloaded>0?R:G},
      ],
      quadrants: [
        {
          title: 'TOP 6 BY VOLUME — VOLUME · OPEN · RES%',
          subtitle: `${byA.length} assignees`,
          render: (s, x, y, w, h) => {
            if (top10.length === 0) { s.addText('No per-assignee data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const noLine={type:'none'}, hl={pt:0.3,color:LG};
            const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:6.5,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
            const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
            const rows = [
              [{text:'OWNER',options:{...hdr,align:'left'}},{text:'TOTAL',options:{...hdr,align:'center'}},
               {text:'OPEN',options:{...hdr,align:'center'}},{text:'RES%',options:{...hdr,align:'center'}}],
              ...top10.slice(0, 5).map((r, ri) => {
                const bg = ri%2===0?'FFFFFF':'F7F7F5';
                return [
                  cell(this._trunc(r.assignee_name||'—', 16), bg, 'left', N),
                  cell(r.total_cases||0, bg, 'center'),
                  cell(r.open_cases||0, bg, 'center', (r.open_cases||0)>10?R:(r.open_cases||0)>3?A:G),
                  cell(`${(r.resolution_rate_pct||0).toFixed(0)}%`, bg, 'center', (r.resolution_rate_pct||0)>=90?G:A),
                ];
              }),
            ];
            s.addTable(rows, {x, y, w, rowH:0.13, fontFace:'Calibri', colW:[w*0.40, w*0.20, w*0.20, w*0.20]});
          },
        },
        {
          title: 'STATUS DWELL HEATMAP — TOP 6 × STAGES',
          subtitle: dwell.length > 0 ? `avg hours · max ${dwellMax.toFixed(0)}h` : 'No dwell data',
          render: (s, x, y, w, h) => {
            if (top6Owners.length === 0 || statusGroups.length === 0) { s.addText('Dwell data unavailable', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            this._drawHeatmap(s, x, y, w, h, [], {
              rows: top6Owners, cols: statusGroups, max: dwellMax || 1,
              lookup: (rL, cL) => dwellMap[`${rL}|${cL}`] || 0,
              cornerLabel: 'OWNER↓ / STAGE→',
            });
          },
        },
        {
          title: 'SLA COMPLIANCE — TOP 6 BY PCT',
          subtitle: `${slaHeroes} heroes ≥95% · ${byA.filter(r => (r.sla_compliance_pct||100) < 80).length} below 80%`,
          render: (s, x, y, w, h) => {
            const slaRanked = [...byA].filter(r => r.assignee_name && r.sla_compliance_pct != null)
              .sort((a, b) => (b.sla_compliance_pct||0) - (a.sla_compliance_pct||0)).slice(0, 6);
            if (slaRanked.length === 0) { s.addText('No SLA data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const rows = slaRanked.map(r => ({label: r.assignee_name, value: Math.round(r.sla_compliance_pct)}));
            this._hBar(s, x, y, w, rows, 100, null, (i, v) => v >= 95 ? G : v >= 80 ? A : R, h);
          },
        },
        {
          title: `MONTHLY TREND — ${this._trunc(topOwnerName||'Top Owner', 22)}`,
          subtitle: 'Reported vs Closed cases',
          render: (s, x, y, w, h) => {
            const topMonthly = byAM.filter(r => r.assignee_name === topOwnerName).slice(-12);
            if (topMonthly.length < 2) { s.addText('Insufficient monthly history', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const labels = topMonthly.map(r => r.month_label || '—');
            s.addChart(this.pptx.ChartType.bar, [
              { name:'Reported', labels, values: topMonthly.map(r => Number(r.cases_reported)||0) },
              { name:'Closed',   labels, values: topMonthly.map(r => Number(r.cases_closed)||0) },
            ], {
              x, y, w, h, barDir:'col', barGrouping:'clustered',
              chartColors:[A, G], showLegend:true, legendPos:'b', legendFontSize:6,
              showTitle:false, showValue:false,
              catAxisLabelFontSize:6, valAxisLabelFontSize:6, dataLabelFontSize:0,
              plotAreaBorderColor: RL, plotAreaBorderSize:0.3,
            });
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TEAM PULSE — replaces _slideWorkloadHeatmap + _slideOwnerVelocityGrid (2 → 1)
  // ══════════════════════════════════════════════════════════════════════════
  _slideTeamPulse(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',RL='D4D4D0';
    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }

    const owners = Object.values(flat)
      .filter(p => p && (p.active || p.stale || p.itemCount))
      .map(p => ({
        name: p.name || 'Unknown',
        active: Number(p.active)||0,
        stale: Number(p.stale)||0,
        blocked: Number(p.blocked)||0,
        cycleTime: Math.round(Number(p.personalCycleTime)||0),
        sparkline: Array.isArray(p.completedSparkline) ? p.completedSparkline : [],
        loadScore: 2*(Number(p.blocked)||0) + (Number(p.stale)||0) + 0.5*(Number(p.active)||0),
      }));
    const byLoad = [...owners].sort((a,b) => b.loadScore - a.loadScore).slice(0, 6);
    const bySpark = [...owners].filter(o => o.sparkline.length > 0).sort((a,b) => b.sparkline.reduce((s,v)=>s+v,0) - a.sparkline.reduce((s,v)=>s+v,0)).slice(0, 8);
    const totalActive = owners.reduce((s,o) => s+o.active, 0);
    const top3Share = totalActive > 0 ? Math.round(byLoad.slice(0,3).reduce((s,o)=>s+o.active,0)/totalActive*100) : 0;
    const totalStale = owners.reduce((s,o) => s+o.stale, 0);
    const concentrationRisk = owners.filter(o => o.blocked >= 3 || o.stale >= 8).length;
    const totalCompleted = bySpark.reduce((s,o) => s + o.sparkline.reduce((a,v)=>a+v,0), 0);

    const hermesSlide = this._an?.hermes?.slides?.teamPulse || {};
    const title = hermesSlide.headline
      || (owners.length === 0
          ? `Team pulse data unavailable`
          : concentrationRisk > 0
          ? `${concentrationRisk} owner(s) flagged for concentration risk · top-3 hold ${top3Share}% of active load`
          : `${owners.length} active owners · ${totalCompleted} completions across last 4 weeks · top-3 hold ${top3Share}%`);
    const soWhat = hermesSlide.soWhat
      || `Team pulse merges workload concentration with completion velocity. Concentration is risk; sparkline trajectory is leading indicator.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'Team Pulse',
      kpis: [
        {value: owners.length, label:'Active Owners', color: N},
        {value: totalActive, label:'Total Active', color: T},
        {value: totalStale, label:'Stale Items', color: A},
        {value: concentrationRisk, label:'At-Risk Owners', color: concentrationRisk>0?R:G},
        {value: `${top3Share}%`, label:'Top-3 Load Share', color: top3Share>=70?A:G},
        {value: totalCompleted, label:'4-Wk Completion', color: T},
      ],
      quadrants: [
        {
          title: 'WORKLOAD — TOP 6 BY ACTIVE',
          subtitle: `Composite load score (2×blocked + stale + 0.5×active)`,
          render: (s, x, y, w, h) => {
            if (byLoad.length === 0) { s.addText('No assignee data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const rows = byLoad.map(o => ({label: o.name, value: o.active}));
            const mx = Math.max(...rows.map(r => r.value), 1);
            this._hBar(s, x, y, w, rows, mx, null, (i, v) => v >= 6 ? R : v >= 3 ? A : T, h);
          },
        },
        {
          title: 'CYCLE TIME — TOP 6 BY DAYS',
          subtitle: `personalCycleTime per owner`,
          render: (s, x, y, w, h) => {
            const ctRanked = [...owners].filter(o => o.cycleTime > 0).sort((a,b) => b.cycleTime - a.cycleTime).slice(0, 6);
            if (ctRanked.length === 0) { s.addText('No cycle-time data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const rows = ctRanked.map(o => ({label: o.name, value: o.cycleTime}));
            const mx = Math.max(...rows.map(r => r.value), 1);
            this._hBar(s, x, y, w, rows, mx, null, (i, v) => v >= 60 ? R : v >= 30 ? A : G, h);
          },
        },
        {
          title: 'VELOCITY SPARKLINES — TOP 8 OWNERS · 4 WEEKS',
          subtitle: bySpark.length ? `${bySpark.length} owners with sparkline data` : 'No sparkline data',
          render: (s, x, y, w, h) => {
            if (bySpark.length === 0) { s.addText('No completedSparkline data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const cellW = w / Math.min(bySpark.length, 8);
            const maxSpark = Math.max(...bySpark.flatMap(o => o.sparkline), 1);
            bySpark.slice(0, 8).forEach((o, i) => {
              const cx = x + i*cellW;
              s.addText(this._trunc(o.name, 9), {x: cx, y: y, w: cellW-0.04, h: 0.16, fontSize: 6.5, fontFace: 'Calibri', color: N, bold: true, align: 'center'});
              const sparkY = y + 0.18;
              const sparkH = h - 0.20;
              const bw = (cellW - 0.08) / Math.max(o.sparkline.length, 1);
              o.sparkline.forEach((v, vi) => {
                const bh = (v / maxSpark) * sparkH;
                const bx = cx + 0.04 + vi*bw;
                const by = sparkY + sparkH - bh;
                s.addShape(this.pptx.ShapeType.rect, {x: bx, y: by, w: bw - 0.02, h: Math.max(0.02, bh),
                  fill:{color: vi === o.sparkline.length-1 ? N : T}, line:{type:'none'}});
              });
            });
          },
        },
        {
          title: 'CONCENTRATION RISK — FLAGGED OWNERS',
          subtitle: `${concentrationRisk} flagged · blocked ≥3 or stale ≥8`,
          render: (s, x, y, w, h) => {
            const risk = owners.filter(o => o.blocked >= 3 || o.stale >= 8).slice(0, 4);
            if (risk.length === 0) { s.addText('✓ No concentration risk', {x, y, w, h, fontSize:10, color:G, bold: true, align:'center', valign:'middle'}); return; }
            risk.forEach((o, i) => {
              const cy = y + i*0.22;
              if (cy + 0.22 > y + h) return;
              s.addShape(this.pptx.ShapeType.rect, {x, y: cy, w, h: 0.20, fill:{color:'FEF3F2'}, line:{type:'none'}});
              s.addShape(this.pptx.ShapeType.rect, {x, y: cy, w: 0.06, h: 0.20, fill:{color: R}, line:{type:'none'}});
              s.addText(o.name, {x: x+0.10, y: cy+0.02, w: w*0.40, h: 0.16, fontSize: 8, fontFace:'Calibri', color: N, bold: true, valign:'middle'});
              s.addText(`${o.blocked}b · ${o.stale}s · ${o.active}a`, {x: x+w*0.50, y: cy+0.02, w: w*0.48, h: 0.16, fontSize: 7.5, fontFace:'Calibri', color: 'C0392B', valign:'middle'});
            });
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // OWNER DRILL-DOWN — replaces _slideOwnerPerformance + _slideOwnerDossier (2 → 1)
  // ══════════════════════════════════════════════════════════════════════════
  _slideOwnerDrillDown(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6';
    const flat = {};
    const ba = this._sprintData?.byAssignee;
    if (Array.isArray(ba)) {
      for (const e of ba) if (e && typeof e==='object') Object.assign(flat, e);
    } else if (ba && typeof ba==='object') {
      Object.assign(flat, ba);
    }

    const owners = Object.values(flat)
      .filter(p => p && (p.itemCount || p.active || p.stale))
      .map(p => ({
        name: p.name || 'Unknown',
        active: Number(p.active)||0,
        stale: Number(p.stale)||0,
        cycleTime: Math.round(Number(p.personalCycleTime)||0),
        prsSubmitted: Number(p.prsSubmitted)||0,
        prsReviewed: Number(p.prsReviewed)||0,
        violations: p.hygiene?.violations || {},
        ...this._burnoutIndex({active: p.active, stale: p.stale, blocked: p.blocked}),
      }));

    const submitHeavy = owners.filter(o => o.prsSubmitted > o.prsReviewed * 2 + 1).length;
    const reviewHeavy = owners.filter(o => o.prsReviewed > o.prsSubmitted * 2 + 1).length;
    const balanced = owners.length - submitHeavy - reviewHeavy;
    const topBurnout = [...owners].sort((a,b) => b.index - a.index).slice(0, 3);
    const longestCycle = [...owners].filter(o => o.cycleTime > 0).sort((a,b) => b.cycleTime - a.cycleTime)[0];
    const totalStale = owners.reduce((s, o) => s + o.stale, 0);

    const hermesSlide = this._an?.hermes?.slides?.ownerDrill || {};
    const title = hermesSlide.headline
      || (owners.length === 0
          ? `Owner drill-down data unavailable`
          : `${topBurnout[0]?.name||'—'} highest burnout (idx ${topBurnout[0]?.index||0}) · ${submitHeavy} submit-heavy · ${reviewHeavy} review-heavy`);
    const soWhat = hermesSlide.soWhat
      || `Burnout index, cycle time, and PR asymmetry combined into single drill-down. Top 3 dossiers below have deep-link work-item IDs ready for triage.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'Owner Drill-Down',
      kpis: [
        {value: owners.length, label:'Owners', color: N},
        {value: longestCycle ? `${longestCycle.cycleTime}d` : '—', label:'Longest Cycle', color: R},
        {value: submitHeavy, label:'Submit-Heavy', color: A},
        {value: reviewHeavy, label:'Review-Heavy', color: A},
        {value: balanced, label:'Balanced', color: G},
        {value: totalStale, label:'Total Stale', color: totalStale>20?R:totalStale>0?A:G},
      ],
      quadrants: [
        {
          title: 'CYCLE TIME — TOP 6',
          subtitle: 'Days from active to closed per owner',
          render: (s, x, y, w, h) => {
            const ctRanked = [...owners].filter(o => o.cycleTime > 0).sort((a,b) => b.cycleTime - a.cycleTime).slice(0, 6);
            if (ctRanked.length === 0) { s.addText('No cycle-time data', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const rows = ctRanked.map(o => ({label: o.name, value: o.cycleTime}));
            this._hBar(s, x, y, w, rows, Math.max(...rows.map(r => r.value), 1), null, (i, v) => v >= 60 ? R : v >= 30 ? A : G, h);
          },
        },
        {
          title: 'PR ASYMMETRY — SUBMIT vs REVIEW',
          subtitle: `${submitHeavy} S-heavy · ${reviewHeavy} R-heavy · ${balanced} balanced`,
          render: (s, x, y, w, h) => {
            const prRanked = [...owners].filter(o => o.prsSubmitted + o.prsReviewed > 0)
              .sort((a, b) => (b.prsSubmitted + b.prsReviewed) - (a.prsSubmitted + a.prsReviewed)).slice(0, 5);
            if (prRanked.length === 0) { s.addText('No PR activity', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const noLine={type:'none'}, hl={pt:0.3,color:LG};
            const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:6.5,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
            const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:7,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
            const rows = [
              [{text:'OWNER',options:{...hdr,align:'left'}},{text:'SUB',options:{...hdr,align:'center'}},
               {text:'REV',options:{...hdr,align:'center'}},{text:'TYPE',options:{...hdr,align:'center'}}],
              ...prRanked.map((o, ri) => {
                const bg = ri%2===0?'FFFFFF':'F7F7F5';
                const type = o.prsSubmitted > o.prsReviewed * 2 + 1 ? 'S-Heavy'
                           : o.prsReviewed > o.prsSubmitted * 2 + 1 ? 'R-Heavy' : 'Balanced';
                return [
                  cell(this._trunc(o.name, 14), bg, 'left', N),
                  cell(o.prsSubmitted, bg, 'center'),
                  cell(o.prsReviewed, bg, 'center'),
                  cell(type, bg, 'center', type === 'Balanced' ? G : A),
                ];
              }),
            ];
            s.addTable(rows, {x, y, w, rowH:0.13, fontFace:'Calibri', colW:[w*0.42, w*0.18, w*0.18, w*0.22]});
          },
        },
        {
          title: `BURNOUT DOSSIER — TOP 3 OWNERS`,
          subtitle: `Click work-item IDs to triage in DevOps`,
          render: (s, x, y, w, h) => {
            if (topBurnout.length === 0) { s.addText('No burnout-risk owners', {x, y, w, h, fontSize:9, color:G, italic:true, align:'center', valign:'middle'}); return; }
            const colW = w / topBurnout.length;
            topBurnout.forEach((o, i) => {
              const cx = x + i*colW;
              s.addShape(this.pptx.ShapeType.rect, {x: cx, y, w: colW - 0.06, h, fill:{color:'F7F7F5'}, line:{color: LG, width: 0.5}});
              s.addText(this._trunc(o.name, 16), {x: cx+0.06, y: y+0.04, w: colW-0.12, h: 0.20, fontSize: 9, fontFace: 'Calibri', color: N, bold: true});
              s.addText(`Idx ${o.index} · ${o.tier}`, {x: cx+0.06, y: y+0.24, w: colW-0.12, h: 0.16, fontSize: 7.5, fontFace: 'Calibri', color: o.tier==='HIGH'?R:o.tier==='MED'?A:G, bold: true});
              const ids = (o.violations.stale_ids || []).slice(0, 4);
              ids.forEach((id, j) => {
                const ly = y + 0.44 + j*0.18;
                if (ly + 0.16 > y + h) return;
                const url = `https://example.invalid}`;
                s.addText(`#${id}`,
                  {x: cx+0.06, y: ly, w: colW-0.12, h: 0.16, fontSize: 8, fontFace: 'Calibri', color: T, bold: true, hyperlink:{url}});
              });
            });
          },
        },
        {
          title: 'HYGIENE VIOLATIONS — TOP 6 OWNERS',
          subtitle: 'Highest violation counts',
          render: (s, x, y, w, h) => {
            const violRanked = [...owners].map(o => ({
              name: o.name,
              count: Object.values(o.violations).reduce((s, v) => s + (Array.isArray(v) ? v.length : 0), 0),
            })).filter(o => o.count > 0).sort((a, b) => b.count - a.count).slice(0, 6);
            if (violRanked.length === 0) { s.addText('No tracked violations', {x, y, w, h, fontSize:9, color:G, italic:true, align:'center', valign:'middle'}); return; }
            const rows = violRanked.map(o => ({label: o.name, value: o.count}));
            this._hBar(s, x, y, w, rows, Math.max(...rows.map(r => r.value), 1), null, (i, v) => v >= 10 ? R : v >= 3 ? A : T, h);
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // HERMES LEARNING — meta-slide showing what Hermes learned across runs.
  // Source: opsData.hermesLearning (populated by n8n bridge from
  //         output/hermes/{memory,control-tower}.json). Shows last 10 runs
  //         + cumulative patterns + recent learnings + feedback applied.
  // ══════════════════════════════════════════════════════════════════════════
  _slideHermesLearning(sn, ts) {
    const N='1B2A4A',R='C0392B',G='27AE60',A='E67E22',T='0A7EA4',MG='9B9B9B',DG='2C2C2C',LG='E8E8E6',RL='D4D4D0';
    const HL = this._ops?.hermesLearning || {};
    const runs = Array.isArray(HL.runs) ? HL.runs : [];
    const learnings = Array.isArray(HL.learnings) ? HL.learnings : [];
    const cats = HL.learningCategories || {};
    const totals = HL.totals || {};
    const patterns = Array.isArray(HL.patterns) ? HL.patterns : [];
    const feedback = Array.isArray(HL.feedback) ? HL.feedback : [];

    const hermesSlide = this._an?.hermes?.slides?.hermesLearning || {};
    const title = hermesSlide.headline
      || (runs.length === 0
          ? `Hermes learning memory unavailable — output/hermes/memory.json not found`
          : `Hermes has captured ${totals.learningCount || 0} learnings across ${totals.runCount || 0} runs · ${totals.hermesModeRunsLast10 || 0}/${runs.length} last runs in Hermes mode`);
    const soWhat = hermesSlide.soWhat
      || `Memory persists across runs — every learning, pattern, and feedback item shapes the next analysis. Watch the velocity and category mix to gauge what Hermes is internalizing.`;

    const s = this.pptx.addSlide();
    this._drawCockpit(s, {
      title, soWhat, sn, ts, slideName: 'Hermes Learning',
      kpis: [
        {value: totals.runCount || 0,         label:'Total Runs',          color: N},
        {value: totals.learningCount || 0,    label:'Total Learnings',     color: T},
        {value: totals.patternCount || 0,     label:'Active Patterns',     color: A},
        {value: totals.feedbackCount || 0,    label:'Feedback Items',      color: feedback.length > 0 ? G : MG},
        {value: `${totals.hermesModeRunsLast10 || 0}/${runs.length || 0}`, label:'Hermes Mode (10)', color: (totals.hermesModeRunsLast10||0) >= runs.length/2 ? G : A},
        {value: totals.avgEditScoreLast10 != null ? `${totals.avgEditScoreLast10}` : '—', label:'Avg Ed Score (10)', color: (totals.avgEditScoreLast10||0) >= 80 ? G : (totals.avgEditScoreLast10||0) >= 60 ? A : R},
      ],
      quadrants: [
        {
          title: 'LAST 10 RUNS — DATE · HEALTH · LEARNINGS',
          subtitle: `${runs.length} of ${totals.runCount||0} total · newest first`,
          render: (s, x, y, w, h) => {
            if (runs.length === 0) { s.addText('No run history yet — first run will populate this.', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const noLine={type:'none'}, hl={pt:0.3,color:LG};
            const hdr={bold:true,color:N,fill:{color:'F0F3F8'},fontSize:6.5,fontFace:'Calibri',border:[{pt:0.5,color:N},noLine,{pt:0.5,color:N},noLine]};
            const cell=(t,bg,al='left',color)=>({text:String(t??'—'),options:{fill:{color:bg},fontSize:6.5,fontFace:'Calibri',color:color||DG,align:al,border:[noLine,noLine,hl,noLine]}});
            const rows = [
              [{text:'DATE',options:{...hdr,align:'left'}},{text:'HLT',options:{...hdr,align:'center'}},
               {text:'LRN',options:{...hdr,align:'center'}},{text:'ED',options:{...hdr,align:'center'}},
               {text:'MODE',options:{...hdr,align:'center'}}],
              ...runs.slice(0, 6).map((r, ri) => {
                const bg = ri%2===0?'FFFFFF':'F7F7F5';
                const dateLabel = r.dateTo ? r.dateTo.slice(5) : (r.completedAt ? r.completedAt.slice(5,10) : '—');
                const hScore = r.healthScore != null ? r.healthScore : '—';
                return [
                  cell(dateLabel, bg, 'left', N),
                  cell(hScore, bg, 'center', hScore === '—' ? MG : hScore >= 70 ? G : hScore >= 50 ? A : R),
                  cell(r.learnedCount ?? 0, bg, 'center', T),
                  cell(r.editScore != null ? r.editScore : '—', bg, 'center'),
                  cell(r.hermesMode ? 'AI' : '—', bg, 'center', r.hermesMode ? G : MG),
                ];
              }),
            ];
            s.addTable(rows, {x, y, w, rowH:0.13, fontFace:'Calibri', colW:[w*0.30, w*0.16, w*0.18, w*0.18, w*0.18]});
          },
        },
        {
          title: 'LEARNING CATEGORIES — CUMULATIVE',
          subtitle: `${Object.keys(cats).length} categories · ${totals.learningCount || 0} total entries`,
          render: (s, x, y, w, h) => {
            const dist = Object.entries(cats).sort((a,b) => b[1]-a[1]).slice(0, 6).map(([name, count]) => ({label: name, value: count}));
            if (dist.length === 0) { s.addText('No learnings recorded yet.', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const mx = Math.max(...dist.map(r => r.value), 1);
            this._hBar(s, x, y, w, dist, mx, null, (i) => i===0 ? N : i<=2 ? T : MG, h);
          },
        },
        {
          title: 'RECENT LEARNINGS — LAST 3',
          subtitle: `Most recent insights captured`,
          render: (s, x, y, w, h) => {
            // BUG FIX: rendering 5 items in renderH≈0.78" gave each ≈0.156"
            // and the body text addText got h = itemH - 0.16 = -0.04 (NEGATIVE,
            // so pptxgenjs squished it to invisible). Reduced to 3 items so
            // each gets ≈0.26" — tight but positive. Type badge inline-prefixes
            // the body text so we don't need a separate height-bound row.
            const recent = learnings.slice(0, 3);
            if (recent.length === 0) { s.addText('No recent learnings.', {x, y, w, h, fontSize:9, color:MG, italic:true, align:'center', valign:'middle'}); return; }
            const N_ITEMS = recent.length;
            const itemH = Math.max(0.20, h / N_ITEMS - 0.04);
            recent.forEach((l, i) => {
              const ly = y + i * (h / N_ITEMS);
              if (ly + itemH > y + h + 0.01) return;
              s.addShape(this.pptx.ShapeType.rect, {x, y: ly, w, h: itemH, fill:{color:'F7F7F5'}, line:{type:'none'}});
              s.addShape(this.pptx.ShapeType.rect, {x, y: ly, w: 0.06, h: itemH, fill:{color: T}, line:{type:'none'}});
              const typeBadge = (l.type || 'unknown').toUpperCase();
              // Type badge inline-prefixes the body text — avoids a separate
              // height-bound row that previously rendered with negative h.
              s.addText(`[${typeBadge}] ${this._trunc(l.text || '—', Math.max(40, Math.floor(w*10)))}`,
                {x: x+0.10, y: ly+0.02, w: w-0.14, h: Math.max(0.14, itemH-0.04), fontSize: 7.5, fontFace:'Calibri', color: DG, valign:'top', lineSpacing: 9});
            });
          },
        },
        {
          title: 'PATTERNS + FEEDBACK',
          subtitle: `${patterns.length} active patterns · ${feedback.length} feedback items`,
          render: (s, x, y, w, h) => {
            // Patterns first (top half), feedback below
            const halfH = h / 2 - 0.04;
            // Patterns
            if (patterns.length === 0) {
              s.addText('No patterns detected', {x, y, w, h: 0.20, fontSize:7.5, color:MG, italic:true});
            } else {
              patterns.slice(0, 2).forEach((p, i) => {
                const py = y + i * 0.30;
                if (py + 0.26 > y + halfH) return;
                s.addText(`▸ ${p.key || p.type || 'pattern'}`, {x, y: py, w: w*0.50, h: 0.16, fontSize: 8, fontFace:'Calibri', color: N, bold: true});
                let detail = '';
                if (p.counts) detail = Object.entries(p.counts).map(([k,v]) => `${k}=${v}`).join(', ');
                else if (p.runs != null) detail = `${p.runs} runs`;
                else if (Array.isArray(p.active)) detail = `${p.active.length} active`;
                s.addText(this._trunc(detail, 40), {x: x + w*0.50, y: py, w: w*0.50, h: 0.16, fontSize: 7.5, fontFace:'Calibri', color: DG, align:'right'});
              });
            }
            // Feedback
            const fy = y + halfH + 0.06;
            s.addShape(this.pptx.ShapeType.rect, {x, y: fy - 0.04, w, h: 0.015, fill:{color: LG}, line:{type:'none'}});
            if (feedback.length === 0) {
              s.addText('No feedback recorded yet — both you and Hermes can write here', {x, y: fy + 0.06, w, h: halfH - 0.10, fontSize:8, color:MG, italic:true, align:'center', valign:'middle'});
            } else {
              feedback.slice(0, 3).forEach((f, i) => {
                const fy2 = fy + 0.04 + i * 0.22;
                if (fy2 + 0.20 > y + h) return;
                s.addText(`◇ ${this._trunc(f.text || f.message || '—', Math.max(30, Math.floor(w*8)))}`, {x, y: fy2, w, h: 0.18, fontSize: 7.5, fontFace:'Calibri', color: G, valign:'middle'});
              });
            }
          },
        },
      ],
      insight: hermesSlide.insight,
    });
  }

  // Render a slim Hermes insight strip for non-cockpit slides that don't have
  // room for a full LLM panel. Surfaces headline + 1-line so-what at the
  // bottom of the slide; falls back to muted placeholder text when Hermes
  // didn't emit slides[<key>].
  _renderHermesInsightOrFallback(s, key, x, y, w, h) {
    const N='1B2A4A', DG='2C2C2C', MG='9B9B9B', T='0A7EA4', LG='E8E8E6';
    const slideContent = this._an?.hermes?.slides?.[key] || {};
    const isFallback = !slideContent.insight?.headline && !slideContent.insight?.body;
    const accent = isFallback ? MG : T;
    const bg = isFallback ? 'F0F0EE' : 'FAFAF8';

    s.addShape(this.pptx.ShapeType.rect, {x, y, w, h, fill:{color: bg}, line:{color: LG, width: 0.5}});
    s.addShape(this.pptx.ShapeType.rect, {x, y, w: 0.06, h, fill:{color: accent}, line:{type:'none'}});
    s.addText(isFallback ? `LLM INSIGHT  ·  FALLBACK (Hermes did not emit slides.${key})` : 'LLM INSIGHT  ·  HERMES',
      {x: x+0.14, y: y+0.04, w: w-0.20, h: 0.14, fontSize: 6.5, fontFace: 'Calibri', color: accent, bold: true, italic: isFallback});
    s.addText(slideContent.insight?.headline || `Insight pending for slides.${key} — wire orchestrator slideContext to populate.`,
      {x: x+0.14, y: y+0.20, w: w-0.20, h: h-0.24, fontSize: 9, fontFace: 'Calibri',
       color: isFallback ? MG : N, bold: !isFallback, italic: isFallback, lineSpacing: 12});
  }

  // Helper — status bucket normaliser (for ITSM matrix)
  _statusBucket(status) {
    const s = String(status||'').toLowerCase();
    if (s.includes('new')) return 'New';
    if (s.includes('analy')) return 'In Analysis';
    if (s.includes('progress') || s.includes('open')) return 'In Progress';
    if (s.includes('pend') || s.includes('wait') || s.includes('hold')) return 'Pending';
    if (s.includes('resolv')) return 'Resolved';
    if (s.includes('closed') || s.includes('done') || s.includes('cancelled')) return 'Closed';
    return status || 'Other';
  }
}

module.exports = PPTXGenerator;
