/**
 * Structured logger with run-correlation ID.
 *
 * Usage:
 *   const { makeLogger } = require('./logger');
 *   const log = makeLogger(context.jobId);
 *   log.info('BN', 'Session started', { url: '...' });
 *   log.warn('ADO', 'No PAT configured');
 *   log.error('PPTX', 'Generation failed', { err: e.message });
 *
 * Output (JSON to stdout/stderr):
 *   {"level":"info","runId":"abc123","tag":"BN","msg":"Session started","url":"...","ts":1715123456789}
 */

function makeLogger(runId = 'unknown') {
  const base = { runId };

  function write(level, stream, tag, msg, data = {}) {
    const entry = JSON.stringify({ level, ...base, tag, msg, ...data, ts: Date.now() });
    stream.write(entry + '\n');
  }

  return {
    info:  (tag, msg, data) => write('info',  process.stdout, tag, msg, data),
    warn:  (tag, msg, data) => write('warn',  process.stderr, tag, msg, data),
    error: (tag, msg, data) => write('error', process.stderr, tag, msg, data),
    debug: (tag, msg, data) => {
      if (process.env.LOG_LEVEL === 'debug') {
        write('debug', process.stdout, tag, msg, data);
      }
    },
  };
}

// Default no-op logger for modules that haven't been wired yet
const noopLogger = {
  info:  () => {},
  warn:  () => {},
  error: () => {},
  debug: () => {},
};

module.exports = { makeLogger, noopLogger };
