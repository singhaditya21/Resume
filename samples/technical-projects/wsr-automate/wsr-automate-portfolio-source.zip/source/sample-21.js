const fs = require('fs');
const { HermesMemory } = require('./memory');

function ts() {
  return new Date().toISOString().split('T')[1].slice(0, 8);
}

function patchRunJson(jsonPath, learning, hermesMode, jobId) {
  if (!jsonPath || !fs.existsSync(jsonPath)) return;
  const data = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
  data.meta = {
    ...(data.meta || {}),
    jobId: jobId || data.meta?.jobId || null,
    hermesMode,
    hermesLearning: learning,
  };
  data.analysis = {
    ...(data.analysis || {}),
    hermesLearning: learning,
  };
  fs.writeFileSync(jsonPath, JSON.stringify(data, null, 2));
}

function finalizeHermesLearning({ jobId, dateFrom, dateTo, hermesMode, result, sourceEvidence, startedAt, outputDir }) {
  const memory = new HermesMemory({ outputDir });
  const pptx = result?.results?.pptx || {};
  const analysis = result?.results?.analysis?.analysis || result?.results?.analysis || {};
  const learning = memory.learnFromRun({
    runId: jobId || `${dateFrom}_${dateTo}`,
    dateFrom,
    dateTo,
    hermesMode,
    startedAt,
    completedAt: new Date().toISOString(),
    sourceEvidence,
    analysis,
    errors: result?.errors || {},
    files: { pptx: pptx.filepath || null, json: pptx.jsonPath || null },
  });

  patchRunJson(pptx.jsonPath, learning, hermesMode, jobId);
  for (const item of learning.learnedThisRun.slice(0, 4)) {
    console.log(`[${ts()}] [Hermes] Learned: ${item.text}`);
  }
  console.log(`[${ts()}] [Hermes] Memory updated: ${learning.learnedCount} learning item(s) stored`);
  return learning;
}

module.exports = { finalizeHermesLearning };
