const { BaseAgent } = require('../core/base-agent');
const eventBus = require('../core/event-bus');
const AzureDevOpsClient = require('../../clients/azure-devops');
const config = require('../../config');

class ADOAgent extends BaseAgent {
  constructor() {
    super({ name: 'ado', role: 'fetcher', timeoutMs: 120000, retries: 3 });
  }

  async execute(context) {
    const { dateFrom, dateTo } = context;
    const ado = new AzureDevOpsClient(config.ado);
    await ado.init();

    const sprint = await ado.getCurrentSprint();
    eventBus.emitAgentEvent(this.name, 'progress', { message: `Sprint: ${sprint?.name || 'None'}` });

    const sprintItems = await ado.getSprintWorkItems(sprint);
    eventBus.emitAgentEvent(this.name, 'progress', { message: `Sprint items: ${sprintItems.length}` });

    const weeklyItems = await ado.getWeeklyWorkItems(dateFrom, dateTo);
    eventBus.emitAgentEvent(this.name, 'progress', { message: `Weekly items: ${weeklyItems.length}` });

    const allItemsMap = new Map();
    for (const item of sprintItems) allItemsMap.set(item.id, item);
    for (const item of weeklyItems) allItemsMap.set(item.id, item);
    const workItems = Array.from(allItemsMap.values());

    const stats = ado.getSprintStats(workItems, sprint?.attributes?.startDate);

    await ado.close?.();

    return { sprint, workItems, stats, count: workItems.length };
  }

  _summarizeResult(result) {
    return {
      sprint: result.sprint?.name,
      workItems: result.count,
      healthScore: result.stats?.healthScore,
      closed: result.stats?.closed,
      active: result.stats?.active,
    };
  }
}

module.exports = { ADOAgent };
