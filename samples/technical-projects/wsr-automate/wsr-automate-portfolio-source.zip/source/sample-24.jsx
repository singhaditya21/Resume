import { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

const CLASS = {
  error: 'border-tower-red/40 bg-tower-red/10 text-tower-red',
  warn: 'border-tower-yellow/40 bg-tower-yellow/10 text-tower-yellow',
  info: 'border-tower-blue/40 bg-tower-blue/10 text-tower-blue',
};

export default function AlertsPanel({ refreshKey }) {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    let active = true;
    const load = () => fetch('/api/alerts')
      .then(r => r.json())
      .then(data => { if (active) setAlerts(data.alerts || []); })
      .catch(() => { if (active) setAlerts([{ level: 'warn', title: 'Alerts unavailable', message: 'Could not read /api/alerts' }]); });
    load();
    const timer = setInterval(load, 30000);
    return () => { active = false; clearInterval(timer); };
  }, [refreshKey]);

  if (!alerts.length) {
    return (
      <section className="border border-tower-green/30 bg-tower-green/10 rounded-lg px-3 py-2 text-tower-green flex items-center gap-2">
        <CheckCircle2 className="w-4 h-4" />
        <span className="text-sm font-medium">No active Control Tower alerts</span>
      </section>
    );
  }

  return (
    <section className="space-y-2">
      {alerts.map((alert, idx) => (
        <div key={`${alert.title}-${idx}`} className={`border rounded-lg px-3 py-2 flex gap-2 ${CLASS[alert.level] || CLASS.info}`}>
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <div>
            <div className="text-sm font-semibold">{alert.title}</div>
            <div className="text-xs opacity-85">{alert.message}</div>
          </div>
        </div>
      ))}
    </section>
  );
}
