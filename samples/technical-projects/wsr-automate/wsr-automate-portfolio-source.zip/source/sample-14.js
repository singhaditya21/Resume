const path = require('path');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    path.join(__dirname, 'src/**/*.{js,jsx,ts,tsx}'),
  ],
  theme: {
    extend: {
      colors: {
        'tower-bg': '#0d1117',
        'tower-bg-secondary': '#161b22',
        'tower-bg-tertiary': '#1c2128',
        'tower-border': '#30363d',
        'tower-text': '#e6edf3',
        'tower-text-secondary': '#8b949e',
        'tower-green': '#3fb950',
        'tower-yellow': '#d29922',
        'tower-red': '#f85149',
        'tower-blue': '#58a6ff',
        'tower-purple': '#a371f7',
      },
    },
  },
  plugins: [],
};
