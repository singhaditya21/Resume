const { EventEmitter } = require('events');

class AgentEventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
  }

  emitAgentEvent(agentName, eventType, payload = {}) {
    this.emit('agent:event', { agent: agentName, type: eventType, timestamp: Date.now(), ...payload });
    this.emit(`agent:${agentName}:${eventType}`, payload);
  }

  emitPipelineEvent(eventType, payload = {}) {
    this.emit('pipeline:event', { type: eventType, timestamp: Date.now(), ...payload });
  }

  onAgent(agentName, eventType, handler) {
    this.on(`agent:${agentName}:${eventType}`, handler);
  }

  onAllAgents(handler) {
    this.on('agent:event', handler);
  }

  onPipeline(handler) {
    this.on('pipeline:event', handler);
  }
}

module.exports = new AgentEventBus();
