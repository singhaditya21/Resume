/**
 * ReportAnalyzer — Intelligence layer for WSR reports
 * Provides root cause analysis, forecasts, data hygiene scoring, and action items
 */
class ReportAnalyzer {

  // ─── MAIN ENTRY ───
  analyze(sprintData, bnData, opsData = {}) {
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const sprint = sprintData?.sprint || {};

    // Engineering metrics (Phase 1)
    const cycleTimeDist = this.calculateCycleTimeDistribution(sprintData);
    const wipSnapshot = this.calculateWIPSnapshot(stats);
    const loadBalance = this.calculateAssigneeLoadBalance(stats);
    const throughputVar = this.calculateThroughputVariance(sprintData);
    const leadTimeByType = this.calculateLeadTimeByType(sprintData);
    const dailyBurn = this.calculateDailyBurnRate(sprintData);
    const blockedAge = this.calculateBlockedItemAge(stats);

    // Operations analysis (Phase 2-3)
    const incidents = this.analyzeIncidents(opsData?.itsm || [], opsData?.oeg || [], opsData?.wsr_incident || []);
    const itTickets = this.analyzeITTickets(opsData?.itdesk || []);
    const legalCases = this.analyzeLegalCases(opsData?.legal || []);
    const cloudRequests = this.analyzeCloudRequests(opsData?.cloud || []);
    const headcount = this.analyzeHeadcount([...(opsData?.headcount || []), ...(opsData?.headcount2 || [])]);
    const peoplestrong = this.analyzePeopleStrong(opsData?.peoplestrong || {});
    const headcountReconciliation = this.analyzeHeadcountReconciliation(opsData);
    const wsrIncidents = this.analyzeWSRIncidents(opsData?.wsr_incident || []);
    const wsrRequirements = this.analyzeWSRRequirements(opsData?.wsr_requirement || []);

    // Cross-domain (Phase 9)
    const opsMaturity = this.calculateOperationsMaturityScore({ incidents, itTickets, legalCases, cloudRequests });
    const orgHealth = this.calculateOrgHealthIndex({ stats, incidents, itTickets, headcount });

    return {
      rootCauses: this.analyzeRootCauses(sprintData, bnData),
      forecast: this.forecastCompletion(sprintData),
      hygiene: this.scoreDataHygiene(workItems),
      actions: this.generateActionItems(sprintData, bnData),
      bnAnalysis: this.analyzeBNBottlenecks(bnData),
      executiveVerdict: this._verdict(stats),
      trends: this.calculateTrends(sprintData),
      delta: this.calculateDelta(sprintData),
      burndown: this.calculateBurndown(sprintData),
      retro: this.generateRetroInsights(sprintData, bnData),
      priorityDistribution: this.calculatePriorityDistribution(stats),
      boardColumnDistribution: this.calculateBoardColumnDistribution(stats),
      effortVariance: this.calculateEffortVariance(stats),
      bnChannelBreakdown: this.calculateBNChannelBreakdown(bnData),
      bnAgingBuckets: this.calculateBNAgingBuckets(bnData),
      // Engineering metrics (Phase 1)
      cycleTimeDist,
      wipSnapshot,
      loadBalance,
      throughputVar,
      leadTimeByType,
      dailyBurn,
      blockedAge,
      // Operations analysis (Phase 2-8)
      incidents,
      itTickets,
      legalCases,
      cloudRequests,
      headcount,
      wsrIncidents,
      wsrRequirements,
      // PeopleStrong HR
      peoplestrong,
      headcountReconciliation,
      // Cross-domain (Phase 9)
      opsMaturity,
      orgHealth,
    };
  }

  // ─── ROOT CAUSE ANALYSIS ───
  analyzeRootCauses(sprintData, bnData) {
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const causes = [];
    const pct = stats.total > 0 ? Math.round((stats.closed / stats.total) * 100) : 0;

    // Velocity drop
    if ((stats.closedThisWeek || 0) < (stats.total || 0) * 0.15 && stats.total > 5) {
      causes.push({
        severity: 'high',
        area: 'velocity',
        message: `Weekly closures (${stats.closedThisWeek || 0}) below expected throughput (${Math.round((stats.total || 0) * 0.15)} for ${stats.total} items)`,
        recommendation: 'Investigate blockers and rebalance workload',
      });
    }

    // Blocked items
    const blocked = stats.blockedItems || [];
    if (blocked.length > 0) {
      causes.push({
        severity: 'high',
        area: 'blockers',
        message: `${blocked.length} item(s) blocked — potential external dependencies`,
        recommendation: `Escalate: ${blocked.slice(0, 3).map(b => `#${b.id}`).join(', ')}`,
      });
    }

    // Stale items
    const stale = (stats.staleItems || []).length;
    if (stale > 0) {
      causes.push({
        severity: stale > 3 ? 'high' : 'medium',
        area: 'stale',
        message: `${stale} item(s) unchanged for 5+ days — possible abandonment`,
        recommendation: 'Review stale items in next standup; close or reassign',
      });
    }

    // Workload imbalance
    const byAssignee = stats.byAssignee || {};
    const members = Object.entries(byAssignee).filter(([n]) => n !== 'Unassigned');
    if (members.length > 1) {
      const totals = members.map(([, d]) => d.total);
      const maxLoad = Math.max(...totals);
      const minLoad = Math.min(...totals);
      const imbalance = maxLoad - minLoad;
      if (imbalance > 3) {
        const overloaded = members.filter(([, d]) => d.total === maxLoad).map(([n]) => n);
        causes.push({
          severity: 'medium',
          area: 'balance',
          message: `Workload imbalance: ${imbalance} item spread. ${overloaded.join(', ')} overloaded`,
          recommendation: 'Redistribute items from overloaded to underloaded members',
        });
      }
    }

    // Scope creep
    if ((stats.scopeAdded || 0) > 2) {
      causes.push({
        severity: 'medium',
        area: 'scope',
        message: `+${stats.scopeAdded} items added after sprint start — scope creep detected`,
        recommendation: 'Lock sprint scope; defer new items to next sprint',
      });
    }

    // Low completion %
    if (pct < 40 && stats.total > 0) {
      causes.push({
        severity: 'high',
        area: 'completion',
        message: `Sprint only ${pct}% complete — significantly behind target`,
        recommendation: 'Descope non-critical items; focus on must-have deliverables',
      });
    }

    // Unassigned items
    const unass = byAssignee['Unassigned'];
    if (unass && unass.total > 0) {
      causes.push({
        severity: 'medium',
        area: 'ownership',
        message: `${unass.total} item(s) unassigned — no clear ownership`,
        recommendation: 'Assign owners immediately to ensure accountability',
      });
    }

    // BN issues affecting sprint
    if (bnData && bnData.length > 0) {
      const openBN = bnData.filter(c => {
        const st = (c.status || c.Status || '').toLowerCase();
        return !st.includes('resolv') && !st.includes('closed') && !st.includes('done') && !st.includes('invalid') && !st.includes('cancel');
      }).length;
      if (openBN > 10) {
        causes.push({
          severity: 'low',
          area: 'support',
          message: `${openBN} open BN cases may be diverting team capacity`,
          recommendation: 'Assess if support load is impacting sprint delivery',
        });
      }
    }

    // Hours burn vs estimate
    const est = stats.totalOriginalEstimate || 0;
    const done = stats.totalCompletedWork || 0;
    if (est > 0 && done > est * 1.2) {
      causes.push({
        severity: 'medium',
        area: 'estimation',
        message: `Hours burned (${done.toFixed(1)}h) exceed estimates (${est.toFixed(1)}h) by ${Math.round((done / est - 1) * 100)}%`,
        recommendation: 'Review estimation process; items are consistently underestimated',
      });
    }

    const severity = causes.some(c => c.severity === 'high') ? 'high' : causes.some(c => c.severity === 'medium') ? 'medium' : 'low';

    return {
      causes,
      severity,
      summary: causes.length === 0
        ? 'No significant root causes identified — sprint is healthy'
        : `${causes.length} root cause(s) identified, severity: ${severity}`,
    };
  }

  // ─── SPRINT COMPLETION FORECAST ───
  forecastCompletion(sprintData) {
    const stats = sprintData?.stats || {};
    const sprint = sprintData?.sprint || {};
    const workItems = sprintData?.workItems || [];
    const total = stats.total || 0;
    const closed = stats.closed || 0;
    const remaining = total - closed;

    if (total === 0) {
      return { probability: 0, bestCase: 0, worstCase: 0, mostLikely: 0, daysNeeded: 0, canFinish: false };
    }

    // Days remaining in sprint
    const finishDate = sprint?.attributes?.finishDate ? new Date(sprint.attributes.finishDate) : null;
    const startDate = sprint?.attributes?.startDate ? new Date(sprint.attributes.startDate) : null;
    const now = new Date();
    let daysRemaining = 0;
    let sprintDuration = 14;

    if (finishDate) {
      daysRemaining = Math.max(0, Math.ceil((finishDate - now) / 86400000));
    }
    if (startDate && finishDate) {
      sprintDuration = Math.max(1, Math.ceil((finishDate - startDate) / 86400000));
    }

    // Daily velocity based on this week's closures
    const dailyVelocity = (stats.closedThisWeek || 0) / 7;
    const avgDailyVelocity = dailyVelocity > 0 ? dailyVelocity : (closed / Math.max(sprintDuration - daysRemaining, 1));

    // Forecast
    const expectedClosures = Math.round(avgDailyVelocity * daysRemaining);
    const mostLikely = Math.min(100, Math.round(((closed + expectedClosures) / total) * 100));

    // Variance factor (±30% for best/worst case)
    const bestCase = Math.min(100, Math.round(((closed + Math.round(expectedClosures * 1.3)) / total) * 100));
    const worstCase = Math.min(100, Math.round(((closed + Math.round(expectedClosures * 0.7)) / total) * 100));

    // Probability of completing all items
    const needed = remaining;
    const expected = expectedClosures;
    let probability;
    if (needed <= 0) probability = 100;
    else if (expected <= 0) probability = 5;
    else probability = Math.min(95, Math.max(5, Math.round((expected / needed) * 70)));

    const canFinish = probability >= 60;
    const daysNeeded = avgDailyVelocity > 0 ? Math.ceil(remaining / avgDailyVelocity) : remaining > 0 ? 999 : 0;

    // Velocity variance → confidence interval (1-sigma)
    const now2 = new Date();
    const weekSamples = [];
    for (let w = 0; w < 4; w++) {
      const wkCount = workItems.filter(wi => {
        if (!wi.closedDate) return false;
        const diff = (now2 - new Date(wi.closedDate)) / 86400000;
        return diff >= w * 7 && diff < (w + 1) * 7;
      }).length;
      weekSamples.push(wkCount / 7);
    }
    const nonZeroSamples = weekSamples.filter(v => v > 0);
    let velocityStdDev = 0;
    if (nonZeroSamples.length >= 2) {
      const sampleMean = nonZeroSamples.reduce((a, b) => a + b, 0) / nonZeroSamples.length;
      const sampleVar = nonZeroSamples.reduce((s, v) => s + Math.pow(v - sampleMean, 2), 0) / nonZeroSamples.length;
      velocityStdDev = Math.sqrt(sampleVar);
    }
    const velocityLo = Math.max(0, avgDailyVelocity - velocityStdDev);
    const velocityHi = avgDailyVelocity + velocityStdDev;
    const closuresLo = Math.round(velocityLo * daysRemaining);
    const closuresHi = Math.round(velocityHi * daysRemaining);
    const probLo = needed <= 0 ? 100 : closuresLo <= 0 ? 5 : Math.min(95, Math.max(5, Math.round((closuresLo / needed) * 70)));
    const probHi = needed <= 0 ? 100 : closuresHi <= 0 ? 5 : Math.min(95, Math.max(5, Math.round((closuresHi / needed) * 70)));

    return { probability, probLo, probHi, bestCase, worstCase, mostLikely, daysNeeded, canFinish, daysRemaining, dailyVelocity: avgDailyVelocity.toFixed(2) };
  }

  // ─── DATA HYGIENE SCORING ───
  scoreDataHygiene(workItems) {
    if (!workItems || !workItems.length) {
      return { score: 0, grade: 'N/A', issues: [], missingEstimates: 0, missingAssignee: 0, missingPriority: 0, missingType: 0, staleCount: 0 };
    }

    const issues = [];
    const total = workItems.length;

    // Missing story points / effort
    const missingEstimates = workItems.filter(i => {
      const state = (i.state || '').toLowerCase();
      return state !== 'closed' && (!i.effort || i.effort === 0) && (!i.storyPoints || i.storyPoints === 0);
    }).length;
    if (missingEstimates > 0) {
      issues.push({ severity: 'medium', field: 'Effort/Story Points', count: missingEstimates, message: `${missingEstimates} non-closed item(s) missing effort estimates` });
    }

    // Missing assignee
    const missingAssignee = workItems.filter(i => {
      const state = (i.state || '').toLowerCase();
      return state !== 'closed' && (!i.assignedTo || i.assignedTo === 'Unassigned' || i.assignedTo === '');
    }).length;
    if (missingAssignee > 0) {
      issues.push({ severity: 'high', field: 'Assigned To', count: missingAssignee, message: `${missingAssignee} item(s) unassigned` });
    }

    // Missing priority
    const missingPriority = workItems.filter(i => !i.priority || i.priority === '' || i.priority === '—').length;
    if (missingPriority > 0) {
      issues.push({ severity: 'low', field: 'Priority', count: missingPriority, message: `${missingPriority} item(s) without priority` });
    }

    // Missing type
    const missingType = workItems.filter(i => !i.type || i.type === '').length;
    if (missingType > 0) {
      issues.push({ severity: 'low', field: 'Work Item Type', count: missingType, message: `${missingType} item(s) without type classification` });
    }

    // Stale items (active but no state change in 5+ days)
    const now = new Date();
    const staleCount = workItems.filter(i => {
      const state = (i.state || '').toLowerCase();
      if (state === 'closed' || state === 'new') return false;
      const changed = i.changedDate ? new Date(i.changedDate) : null;
      const created = i.createdDate ? new Date(i.createdDate) : null;
      const lastActivity = changed || created;
      return lastActivity && (now - lastActivity) / 86400000 > 5;
    }).length;
    if (staleCount > 0) {
      issues.push({ severity: 'medium', field: 'Staleness', count: staleCount, message: `${staleCount} item(s) unchanged for 5+ days` });
    }

    // Calculate score (100 = perfect, deduct for each issue)
    const deductions = issues.reduce((sum, iss) => {
      const weight = iss.severity === 'high' ? 15 : iss.severity === 'medium' ? 8 : 3;
      return sum + Math.min(weight, (iss.count / total) * weight * 2);
    }, 0);
    const score = Math.max(0, Math.round(100 - deductions));
    const grade = score >= 90 ? 'A' : score >= 75 ? 'B' : score >= 60 ? 'C' : score >= 40 ? 'D' : 'F';

    return { score, grade, issues, missingEstimates, missingAssignee, missingPriority, missingType, staleCount };
  }

  // ─── SMART PRIORITIZED ACTION ITEMS ───
  generateActionItems(sprintData, bnData) {
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const actions = [];
    const pct = stats.total > 0 ? Math.round((stats.closed / stats.total) * 100) : 0;

    // P1: Blocked items
    const blocked = stats.blockedItems || [];
    if (blocked.length > 0) {
      blocked.slice(0, 3).forEach(it => {
        actions.push({
          priority: 'P1',
          icon: '🔴',
          action: `Unblock #${it.id} ${this._trunc(it.title || it.type || '', 30)}`,
          owner: it.assignedTo || 'Tech Lead',
          reason: `${it.daysBlocked || '?'} days blocked — blocking sprint progress`,
        });
      });
    }

    // P1: Overdue items
    const overdue = stats.overdueItems || [];
    if (overdue.length > 0) {
      actions.push({
        priority: 'P1',
        icon: '🔴',
        action: `Close ${overdue.length} overdue item(s): ${overdue.slice(0, 2).map(i => `#${i.id}`).join(', ')}`,
        owner: 'PORTFOLIO_REDACTED',
        reason: 'Past due — impacting sprint commitment',
      });
    }

    // P2: Stale items
    const stale = stats.staleItems || [];
    if (stale.length > 0) {
      actions.push({
        priority: 'P2',
        icon: '🟡',
        action: `Review ${stale.length} stale item(s): ${stale.slice(0, 2).map(i => `#${i.id}`).join(', ')}`,
        owner: 'PORTFOLIO_REDACTED',
        reason: 'No activity in 5+ days — at risk of stalling',
      });
    }

    // P2: Unassigned items
    const byAssignee = stats.byAssignee || {};
    const unass = byAssignee['Unassigned'];
    if (unass && unass.total > 0) {
      actions.push({
        priority: 'P2',
        icon: '🟡',
        action: `Assign ${unass.total} unassigned item(s) to team members`,
        owner: 'PORTFOLIO_REDACTED',
        reason: 'No ownership = no accountability',
      });
    }

    // P2: Workload rebalance
    const members = Object.entries(byAssignee).filter(([n]) => n !== 'Unassigned');
    if (members.length > 1) {
      const totals = members.map(([, d]) => d.total);
      const spread = Math.max(...totals) - Math.min(...totals);
      if (spread > 3) {
        const overloaded = members.filter(([, d]) => d.total === Math.max(...totals)).map(([n]) => n);
        const underloaded = members.filter(([, d]) => d.total === Math.min(...totals)).map(([n]) => n);
        actions.push({
          priority: 'P2',
          icon: '🟡',
          action: `Rebalance: move items from ${overloaded.join(', ')} to ${underloaded.join(', ')}`,
          owner: 'PORTFOLIO_REDACTED',
          reason: `Workload spread of ${spread} indicates imbalance`,
        });
      }
    }

    // P2: Missing estimates
    const hygiene = this.scoreDataHygiene(workItems);
    if (hygiene.missingEstimates > 0) {
      actions.push({
        priority: 'P2',
        icon: '🟡',
        action: `Add estimates to ${hygiene.missingEstimates} item(s) missing story points`,
        owner: 'PORTFOLIO_REDACTED',
        reason: 'Cannot track progress without estimates',
      });
    }

    // P3: BN follow-up
    if (bnData && bnData.length > 0) {
      const openBN = bnData.filter(c => {
        const st = (c.status || c.Status || '').toLowerCase();
        return !st.includes('resolv') && !st.includes('closed') && !st.includes('done') && !st.includes('invalid') && !st.includes('cancel');
      });
      if (openBN.length > 0) {
        const oldCases = openBN.filter(c => c.reportedOn && (new Date() - new Date(c.reportedOn)) / 86400000 > 5);
        if (oldCases.length > 0) {
          actions.push({
            priority: 'P3',
            icon: '🟢',
            action: `Follow up on ${oldCases.length} BN case(s) older than 5 days`,
            owner: 'PORTFOLIO_REDACTED',
            reason: 'SLA risk — aging open cases',
          });
        }
      }
    }

    // P3: Sprint preparation
    if (pct >= 90) {
      actions.push({
        priority: 'P3',
        icon: '🟢',
        action: 'Begin next sprint planning — backlog grooming and estimation',
        owner: 'PORTFOLIO_REDACTED',
        reason: `Sprint ${pct}% complete — readiness for next iteration`,
      });
    }

    // P3: Archive completed items
    if (stats.closed > 10) {
      actions.push({
        priority: 'P3',
        icon: '🟢',
        action: `Archive ${stats.closed} completed items and update product backlog`,
        owner: 'PORTFOLIO_REDACTED',
        reason: 'Housekeeping — keep board clean for next sprint',
      });
    }

    return actions.sort((a, b) => {
      const pOrder = { P1: 0, P2: 1, P3: 2 };
      return (pOrder[a.priority] || 3) - (pOrder[b.priority] || 3);
    });
  }

  // ─── BN BOTTLENECK ANALYSIS ───
  analyzeBNBottlenecks(bnData) {
    if (!bnData || !bnData.length) {
      return { bottlenecks: [], paretoCategories: [], slaProjection: 'PORTFOLIO_REDACTED' };
    }

    const total = bnData.length;
    const bottlenecks = [];

    // Category concentration (Pareto)
    const catMap = {};
    bnData.forEach(c => {
      const cat = c.category || c.Category || 'Other';
      catMap[cat] = (catMap[cat] || 0) + 1;
    });
    const catsSorted = Object.entries(catMap).sort((a, b) => b[1] - a[1]);
    const paretoCategories = catsSorted.map(([cat, cnt]) => ({
      category: cat,
      count: cnt,
      pct: Math.round(cnt / total * 100),
      cumulative: 0,
    }));
    let cumul = 0;
    paretoCategories.forEach(p => {
      cumul += p.pct;
      p.cumulative = cumul;
    });

    // Find 80% threshold
    const eightyPercentCats = paretoCategories.filter(p => p.cumulative <= 85);
    if (eightyPercentCats.length > 0 && eightyPercentCats.length < paretoCategories.length) {
      bottlenecks.push({
        type: 'concentration',
        message: `${eightyPercentCats.length} categor${eightyPercentCats.length > 1 ? 'ies account' : 'PORTFOLIO_REDACTED'} for ~80% of cases: ${eightyPercentCats.map(c => c.category).join(', ')}`,
        severity: 'medium',
      });
    }

    // Owner bottleneck
    const ownerMap = {};
    bnData.forEach(c => {
      const o = c.currentOwner || c.owner || 'Unassigned';
      if (!ownerMap[o]) ownerMap[o] = { total: 0, resolved: 0 };
      ownerMap[o].total++;
      const st = (c.status || c.Status || '').toLowerCase();
      if (st.includes('resolv') || st.includes('closed') || st.includes('done')) ownerMap[o].resolved++;
    });

    const overloaded = Object.entries(ownerMap)
      .filter(([n]) => n !== 'Unassigned')
      .filter(([, d]) => d.total > total / Math.max(Object.keys(ownerMap).length, 1) * 1.5);
    if (overloaded.length > 0) {
      bottlenecks.push({
        type: 'owner_overload',
        message: `${overloaded.map(([n, d]) => `${n} (${d.total} cases)`).join(', ')} overloaded`,
        severity: 'medium',
      });
    }

    // Unassigned bottleneck
    const unassigned = ownerMap['Unassigned'];
    if (unassigned && unassigned.total > 0) {
      bottlenecks.push({
        type: 'unassigned',
        message: `${unassigned.total} case(s) unassigned — no one accountable`,
        severity: 'high',
      });
    }

    // SLA projection
    const resolved = bnData.filter(c => {
      const st = (c.status || c.Status || '').toLowerCase();
      return st.includes('resolv') || st.includes('closed') || st.includes('done');
    }).length;
    const rp = total > 0 ? Math.round(resolved / total * 100) : 0;
    const open = bnData.filter(c => {
      const st = (c.status || c.Status || '').toLowerCase();
      return !st.includes('resolv') && !st.includes('closed') && !st.includes('done') && !st.includes('invalid') && !st.includes('cancel');
    });

    // Old open cases
    const oldOpen = open.filter(c => c.reportedOn && (new Date() - new Date(c.reportedOn)) / 86400000 > 5).length;
    const slaProjection = rp >= 90 ? '✅ Excellent' : rp >= 80 ? '🟢 On Track' : rp >= 60 ? '🟡 At Risk' : '🔴 Critical';

    return { bottlenecks, paretoCategories, slaProjection, resolutionRate: rp, oldOpenCases: oldOpen };
  }

  // ─── DAILY TRENDS (from work item dates) ───
  calculateTrends(sprintData) {
    const workItems = sprintData?.workItems || [];
    const sprint = sprintData?.sprint || {};
    const stats = sprintData?.stats || {};
    const startDate = sprint?.attributes?.startDate ? new Date(sprint.attributes.startDate) : null;
    const finishDate = sprint?.attributes?.finishDate ? new Date(sprint.attributes.finishDate) : null;

    // Group closed items by day
    const dailyClosures = {};
    const dailyEffort = {};
    const dailyCreated = {};
    workItems.forEach(wi => {
      if (wi.closedDate) {
        const d = new Date(wi.closedDate).toISOString().split('T')[0];
        dailyClosures[d] = (dailyClosures[d] || 0) + 1;
        dailyEffort[d] = (dailyEffort[d] || 0) + (wi.effort || 0);
      }
      if (wi.createdDate) {
        const d = new Date(wi.createdDate).toISOString().split('T')[0];
        dailyCreated[d] = (dailyCreated[d] || 0) + 1;
      }
    });

    // Build cumulative data for burndown-style analysis
    const sprintDays = [];
    if (startDate && finishDate) {
      const d = new Date(startDate);
      while (d <= finishDate) {
        const key = d.toISOString().split('T')[0];
        sprintDays.push(key);
        d.setDate(d.getDate() + 1);
      }
    } else {
      // Fallback: last 14 days
      for (let i = 13; i >= 0; i--) {
        const d = new Date(); d.setDate(d.getDate() - i);
        sprintDays.push(d.toISOString().split('T')[0]);
      }
    }

    // Cumulative closures per day
    let cumClosed = 0, cumCreated = 0, cumEffort = 0;
    const dailyData = sprintDays.map(day => {
      cumClosed += dailyClosures[day] || 0;
      cumCreated += dailyCreated[day] || 0;
      cumEffort += dailyEffort[day] || 0;
      return { date: day, closed: dailyClosures[day] || 0, created: dailyCreated[day] || 0, effort: dailyEffort[day] || 0, cumClosed, cumCreated, cumEffort };
    });

    // Day-of-week pattern
    const dowClosed = { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0, Sun: 0 };
    const dowNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    workItems.forEach(wi => {
      if (wi.closedDate) { const d = new Date(wi.closedDate); dowClosed[dowNames[d.getDay()]]++; }
    });

    // Velocity trend (last 7 days vs prior 7 days)
    const now = new Date();
    const last7Closed = workItems.filter(wi => wi.closedDate && (now - new Date(wi.closedDate)) / 86400000 <= 7).length;
    const prev7Closed = workItems.filter(wi => {
      if (!wi.closedDate) return false;
      const diff = (now - new Date(wi.closedDate)) / 86400000;
      return diff > 7 && diff <= 14;
    }).length;
    const velocityTrend = last7Closed - prev7Closed;

    return {
      dailyData,
      dailyClosures,
      dailyEffort,
      dailyCreated,
      dowClosed,
      last7Closed,
      prev7Closed,
      velocityTrend,
      totalSprintDays: sprintDays.length,
      peakDay: Object.entries(dailyClosures).sort((a, b) => b[1] - a[1])[0] || null,
    };
  }

  // ─── DELTA COMPARISON (state transitions in current sprint) ───
  calculateDelta(sprintData) {
    const workItems = sprintData?.workItems || [];
    const stats = sprintData?.stats || {};
    const sprint = sprintData?.sprint || {};
    const sprintStart = sprint?.attributes?.startDate ? new Date(sprint.attributes.startDate) : null;

    // Items closed this week (state changed to Closed)
    const closedThisWeek = workItems.filter(wi => {
      if (!wi.closedDate) return false;
      const d = new Date(wi.closedDate);
      return (new Date() - d) / 86400000 <= 7;
    }).map(wi => ({ id: wi.id, title: wi.title || wi.type || '', type: wi.type || '', state: 'Closed', assignedTo: wi.assignedTo || '', effort: wi.effort || 0 }));

    // Items created this week (new scope)
    const addedThisWeek = workItems.filter(wi => {
      if (!wi.createdDate) return false;
      const d = new Date(wi.createdDate);
      return (new Date() - d) / 86400000 <= 7;
    }).map(wi => ({ id: wi.id, title: wi.title || wi.type || '', type: wi.type || '', state: wi.state || '', assignedTo: wi.assignedTo || '', effort: wi.effort || 0 }));

    // Items activated this week (moved to Active)
    const activatedThisWeek = workItems.filter(wi => {
      if (!wi.activatedDate) return false;
      const d = new Date(wi.activatedDate);
      return (new Date() - d) / 86400000 <= 7;
    }).map(wi => ({ id: wi.id, title: wi.title || wi.type || '', type: wi.type || '', state: wi.state || '', assignedTo: wi.assignedTo || '' }));

    // Scope additions (created after sprint start)
    const scopeAdded = sprintStart ? workItems.filter(wi => {
      if (!wi.createdDate) return false;
      return new Date(wi.createdDate) > sprintStart;
    }).length : 0;

    // State changes summary
    const stateChanges = {};
    workItems.forEach(wi => {
      const cur = wi.state || 'Unknown';
      stateChanges[cur] = (stateChanges[cur] || 0) + 1;
    });

    // Assignee changes (items currently assigned to different person)
    const byAssignee = stats.byAssignee || {};
    const assigneeShifts = Object.entries(byAssignee)
      .filter(([n]) => n !== 'Unassigned')
      .map(([name, d]) => ({ name, closedThisWeek: d.closedThisWeek || 0, active: d.active || 0, total: d.total || 0 }))
      .sort((a, b) => b.closedThisWeek - a.closedThisWeek);

    return {
      closedThisWeek,
      addedThisWeek,
      activatedThisWeek,
      scopeAdded,
      stateChanges,
      assigneeShifts,
      netChange: (addedThisWeek.length || 0) - (closedThisWeek.length || 0),
      closedCount: closedThisWeek.length,
      addedCount: addedThisWeek.length,
      activatedCount: activatedThisWeek.length,
    };
  }

  // ─── BURNDOWN CALCULATION (ideal vs actual) ───
  calculateBurndown(sprintData) {
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const sprint = sprintData?.sprint || {};
    const startDate = sprint?.attributes?.startDate ? new Date(sprint.attributes.startDate) : null;
    const finishDate = sprint?.attributes?.finishDate ? new Date(sprint.attributes.finishDate) : null;

    if (!startDate || !finishDate) {
      return { hasData: false, ideal: [], actual: [], labels: [], totalItems: 0, totalEffort: 0 };
    }

    const totalItems = stats.total || 0;
    const totalEffort = stats.totalEffort || 0;
    const sprintDuration = Math.max(1, Math.ceil((finishDate - startDate) / 86400000));
    const now = new Date();

    // Build day-by-day labels
    const labels = [];
    const days = [];
    const d = new Date(startDate);
    let dayIdx = 0;
    while (d <= finishDate) {
      labels.push(d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }));
      days.push({ date: new Date(d), idx: dayIdx });
      d.setDate(d.getDate() + 1);
      dayIdx++;
    }

    // Ideal burndown (linear)
    const ideal = days.map((_, i) => {
      const fraction = i / Math.max(days.length - 1, 1);
      return Math.round(totalItems * (1 - fraction));
    });

    // Actual burndown (based on cumulative closed items)
    const closedByDay = {};
    workItems.forEach(wi => {
      if (wi.closedDate) {
        const key = new Date(wi.closedDate).toISOString().split('T')[0];
        closedByDay[key] = (closedByDay[key] || 0) + 1;
      }
    });

    let cumClosed = 0;
    const actual = days.map(day => {
      const key = day.date.toISOString().split('T')[0];
      cumClosed += closedByDay[key] || 0;
      const remaining = Math.max(0, totalItems - cumClosed);
      // Don't show future data
      return day.date <= now ? remaining : null;
    });

    // Fill last known value forward for nulls (future days)
    let lastVal = totalItems;
    const actualFilled = actual.map((v, i) => {
      if (v !== null) { lastVal = v; return v; }
      return i === 0 ? totalItems : null; // future = null for chart
    });

    // Effort burndown
    const effortClosedByDay = {};
    workItems.forEach(wi => {
      if (wi.closedDate && wi.effort) {
        const key = new Date(wi.closedDate).toISOString().split('T')[0];
        effortClosedByDay[key] = (effortClosedByDay[key] || 0) + wi.effort;
      }
    });

    let cumEffort = 0;
    const effortActual = days.map(day => {
      const key = day.date.toISOString().split('T')[0];
      cumEffort += effortClosedByDay[key] || 0;
      return day.date <= now ? Math.max(0, totalEffort - cumEffort) : null;
    });

    const idealEffort = days.map((_, i) => {
      const fraction = i / Math.max(days.length - 1, 1);
      return Math.round(totalEffort * (1 - fraction));
    });

    return {
      hasData: totalItems > 0,
      labels,
      ideal,
      actual: actualFilled,
      idealEffort,
      effortActual,
      totalItems,
      totalEffort,
      sprintDuration: days.length,
      daysElapsed: days.filter(d => d.date <= now).length,
      daysRemaining: days.filter(d => d.date > now).length,
    };
  }

  // ─── SPRINT RETROSPECTIVE INSIGHTS ───
  generateRetroInsights(sprintData, bnData) {
    const stats = sprintData?.stats || {};
    const workItems = sprintData?.workItems || [];
    const byAssignee = stats.byAssignee || {};
    const members = Object.entries(byAssignee).filter(([n]) => n !== 'Unassigned');

    // Hoist shared variables needed by topics/nextSprintActions
    const pct = stats.total > 0 ? Math.round((stats.closed / stats.total) * 100) : 0;
    const spread = members.length > 1 ? Math.max(...members.map(([, d]) => d.total)) - Math.min(...members.map(([, d]) => d.total)) : 0;
    const hygiene = this.scoreDataHygiene(workItems);

    // What went well — source from ADO retro/action items, fall back to inferred stats
    const wentWell = [];
    const toImprove = [];

    const retroItems = workItems.filter(wi => {
      const type = (wi.type || '').toLowerCase();
      return type.includes('retro') || type.includes('action item') || type.includes('improvement');
    });
    const retroDone = retroItems.filter(wi => ['done', 'closed', 'resolved'].some(s => (wi.state || '').toLowerCase().includes(s)));
    const retroOpen = retroItems.filter(wi => !['done', 'closed', 'resolved'].some(s => (wi.state || '').toLowerCase().includes(s)));

    if (retroDone.length > 0) {
      retroDone.slice(0, 4).forEach(wi => {
        const title = (wi.title || wi.type || '').replace(/^retro[erspective]*:?\s*/i, '').trim();
        if (title) wentWell.push(`Completed: ${title}`);
      });
    }
    if (retroOpen.length > 0) {
      retroOpen.slice(0, 4).forEach(wi => {
        const title = (wi.title || wi.type || '').replace(/^retro[erspective]*:?\s*/i, '').trim();
        if (title) toImprove.push(`Open action: ${title}`);
      });
    }

    // Fallback: infer from sprint stats when no retro items found
    if (!wentWell.length) {
      if ((stats.closedThisWeek || 0) >= 3) wentWell.push(`Strong velocity: ${stats.closedThisWeek} items closed this week`);
      if ((stats.blockedItems || []).length === 0) wentWell.push('Zero blocked items — clean execution');
      if ((stats.staleItems || []).length === 0) wentWell.push('No stale items — all work progressing');
      const topContributor = members.sort((a, b) => b[1].closedThisWeek - a[1].closedThisWeek)[0];
      if (topContributor && topContributor[1].closedThisWeek > 0) wentWell.push(`${topContributor[0]} led with ${topContributor[1].closedThisWeek} closures`);
      if (pct >= 70) wentWell.push(`Sprint ${pct}% complete — on track for commitment`);
      if ((stats.totalEffort || 0) > 0 && (stats.closedEffort || 0) > 0) {
        const effortPct = Math.round((stats.closedEffort / stats.totalEffort) * 100);
        if (effortPct >= 60) wentWell.push(`${effortPct}% story point burn rate — healthy delivery`);
      }
      if (!wentWell.length) wentWell.push('Team is working through sprint backlog');
    }

    if (!toImprove.length) {
      if ((stats.blockedItems || []).length > 0) toImprove.push(`${(stats.blockedItems || []).length} blocked item(s) — identify and remove impediments faster`);
      if ((stats.staleItems || []).length > 0) toImprove.push(`${(stats.staleItems || []).length} stale item(s) — daily check on inactive items`);
      if (byAssignee['Unassigned']) toImprove.push(`${byAssignee['Unassigned'].total} unassigned — every item needs an owner from day 1`);
      if (pct < 50 && stats.total > 0) toImprove.push(`Sprint only ${pct}% done — review scope and prioritize must-haves`);
      if ((stats.scopeAdded || 0) > 2) toImprove.push(`+${stats.scopeAdded} scope additions — protect sprint boundaries`);
      if (spread > 3) toImprove.push(`Workload spread of ${spread} — consider better distribution during planning`);
      if (hygiene.missingEstimates > 0) toImprove.push(`${hygiene.missingEstimates} items missing estimates — estimation discipline needed`);
      if (!toImprove.length) toImprove.push('Continue current practices — no major improvement areas');
    }

    // Discussion topics
    const topics = [];
    topics.push(`Sprint commitment: ${pct}% delivered. ${pct >= 80 ? 'Strong.' : pct >= 50 ? 'Partial.' : 'Below target.'} How to improve predictability?`);
    if ((stats.avgCycleTime || 0) > 5) topics.push(`Average cycle time is ${stats.avgCycleTime} days. Can we break down work into smaller items?`);
    if (bnData && bnData.length > 0) {
      const openBN = bnData.filter(c => { const s = (c.status || '').toLowerCase(); return !s.includes('resolv') && !s.includes('closed') && !s.includes('invalid'); }).length;
      if (openBN > 5) topics.push(`${openBN} open support cases — is support load impacting sprint capacity?`);
    }
    if (members.length > 0) {
      const zeroContribution = members.filter(([, d]) => d.closedThisWeek === 0);
      if (zeroContribution.length > 0 && members.length > 1) topics.push(`${zeroContribution.length} team member(s) with zero closures this week — check blockers`);
    }
    topics.push('What process changes would help us deliver more consistently next sprint?');

    // Action for next sprint
    const nextSprintActions = [];
    if (hygiene.score < 80) nextSprintActions.push('Improve data hygiene — ensure all items have estimates, assignees, and priorities');
    if (spread > 3) nextSprintActions.push('Balanced sprint planning — distribute workload evenly across team');
    if (pct < 70) nextSprintActions.push('Right-size sprint commitment — carry fewer items but deliver them all');
    if ((stats.scopeAdded || 0) > 0) nextSprintActions.push('Lock sprint scope after planning — use next sprint for new items');
    nextSprintActions.push('Continue daily standups with focus on blockers and stale items');
    if (!nextSprintActions.length) nextSprintActions.push('Maintain current practices and velocity');

    return { wentWell, toImprove, topics, nextSprintActions };
  }

  // ─── PRIORITY DISTRIBUTION ───
  calculatePriorityDistribution(stats) {
    const byPriority = stats.byPriority || {};
    const total = Object.values(byPriority).reduce((s, v) => s + v, 0);
    const entries = Object.entries(byPriority).sort((a, b) => a[0] - b[0]);
    return {
      total,
      entries: entries.map(([pri, cnt]) => ({
        priority: pri === '1' ? 'P1 Critical' : pri === '2' ? 'P2 High' : pri === '3' ? 'P3 Medium' : pri === '4' ? 'P4 Low' : `P${pri}`,
        count: cnt,
        pct: total > 0 ? Math.round((cnt / total) * 100) : 0,
      })),
    };
  }

  // ─── BOARD COLUMN DISTRIBUTION ───
  calculateBoardColumnDistribution(stats) {
    const byBoardColumn = stats.byBoardColumn || {};
    const total = Object.values(byBoardColumn).reduce((s, v) => s + v, 0);
    const entries = Object.entries(byBoardColumn).sort((a, b) => b[1] - a[1]);
    return {
      total,
      entries: entries.map(([col, cnt]) => ({
        column: col,
        count: cnt,
        pct: total > 0 ? Math.round((cnt / total) * 100) : 0,
      })),
    };
  }

  // ─── EFFORT VARIANCE (hours) ───
  calculateEffortVariance(stats) {
    const original = stats.totalOriginalEstimate || 0;
    const completed = stats.totalCompletedWork || 0;
    const remaining = stats.totalRemainingWork || 0;
    const total = original || (completed + remaining);
    const variance = total > 0 ? Math.round(((completed + remaining) / total - 1) * 100) : 0;
    return { original, completed, remaining, total, variance };
  }

  // ─── BN CHANNEL BREAKDOWN ───
  calculateBNChannelBreakdown(bnData) {
    if (!bnData || !bnData.length) return { total: 0, entries: [] };
    const channels = {};
    bnData.forEach(c => {
      const ch = c.channel || 'Unknown';
      channels[ch] = (channels[ch] || 0) + 1;
    });
    const total = bnData.length;
    const entries = Object.entries(channels).sort((a, b) => b[1] - a[1]);
    return {
      total,
      entries: entries.map(([ch, cnt]) => ({ channel: ch, count: cnt, pct: Math.round((cnt / total) * 100) })),
    };
  }

  // ─── BN AGING BUCKETS ───
  calculateBNAgingBuckets(bnData) {
    if (!bnData || !bnData.length) return { total: 0, buckets: [] };
    const now = new Date();
    const buckets = { '0-3 days': 0, '4-7 days': 0, '8-14 days': 0, '15+ days': 0 };
    bnData.forEach(c => {
      const reported = c.reportedOn || c.createdDate || c.date;
      if (!reported) { buckets['15+ days']++; return; }
      const days = (now - new Date(reported)) / 86400000;
      if (days <= 3) buckets['0-3 days']++;
      else if (days <= 7) buckets['4-7 days']++;
      else if (days <= 14) buckets['8-14 days']++;
      else buckets['15+ days']++;
    });
    const total = bnData.length;
    return {
      total,
      buckets: Object.entries(buckets).map(([label, cnt]) => ({ label, count: cnt, pct: Math.round((cnt / total) * 100) })),
    };
  }

  // ─── OPERATIONS ANALYSIS ───

  analyzeIncidents(itsmData, oegData, wsrIncidentData) {
    const all = [...(itsmData || []), ...(oegData || []), ...(wsrIncidentData || [])];
    const itsm = itsmData || [];
    const oeg = oegData || [];
    const wsr = wsrIncidentData || [];
    const now = new Date();

    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const calcMttr = (items) => {
      const times = items.map(i => {
        const reported = i.reportedDate || i.createdDate || i.date;
        const resolved = i.resolvedDate || i.closedDate;
        if (!reported || !resolved) return null;
        return (new Date(resolved) - new Date(reported)) / 3600000;
      }).filter(t => t !== null && t >= 0);
      return times.length > 0 ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : 0;
    };

    const openItems = all.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st !== 'closed' && st !== 'resolved';
    });

    const p1Items = all.filter(i => {
      const sev = (i.severity || '').toLowerCase();
      return sev.includes('p1') || sev.includes('critical') || sev.includes('high');
    });

    const bySeverity = countBy(all, 'severity');
    const byStatus = countBy(all, 'status');
    const byTeam = { ITSM: itsm.length, OEG: oeg.length, WSR: wsr.length };

    // MTTR by Severity
    const mttrBySeverity = {};
    Object.keys(bySeverity).forEach(sev => {
      const items = all.filter(i => (i.severity || '').toLowerCase() === sev.toLowerCase());
      mttrBySeverity[sev] = calcMttr(items);
    });

    // App Reliability Score
    const appCounts = countBy(all, 'application');
    const appIncidents = Object.entries(appCounts).map(([app, cnt]) => {
      const appItems = all.filter(i => (i.application || '') === app);
      const sevWeight = appItems.reduce((sum, i) => {
        const s = (i.severity || '').toLowerCase();
        return sum + (s.includes('p1') ? 4 : s.includes('p2') ? 3 : s.includes('p3') ? 2 : 1);
      }, 0);
      const appMttr = calcMttr(appItems);
      const score = Math.max(0, Math.round(100 - (cnt * 5) - (sevWeight * 3) - (appMttr > 48 ? 20 : 0)));
      return { app, incidents: cnt, severityWeight: sevWeight, mttr: appMttr, score };
    }).sort((a, b) => a.score - b.score);

    // Top Offender Apps
    const topOffenderApps = appIncidents.filter(a => a.incidents > 2 || a.mttr > 48).slice(0, 5);

    return {
      total: all.length,
      itsmTotal: itsm.length,
      oegTotal: oeg.length,
      wsrTotal: wsr.length,
      open: openItems.length,
      resolved: all.length - openItems.length,
      p1Count: p1Items.length,
      mttr: calcMttr(all),
      itsmMttr: calcMttr(itsm),
      oegMttr: calcMttr(oeg),
      wsrMttr: calcMttr(wsr),
      mttrBySeverity: Object.entries(mttrBySeverity).map(([sev, mttr]) => ({ severity: sev, mttr })),
      appReliability: appIncidents.slice(0, 10),
      topOffenderApps,
      bySeverity: Object.entries(bySeverity).map(([k, v]) => ({ severity: k, count: v })),
      byStatus: Object.entries(byStatus).map(([k, v]) => ({ status: k, count: v })),
      byTeam,
      openItems: openItems.slice(0, 10),
      topApplications: Object.entries(countBy(all, 'application')).sort((a, b) => b[1] - a[1]).slice(0, 5),
    };
  }

  analyzeWSRIncidents(items) {
    const data = items || [];
    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const openItems = data.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st !== 'closed' && st !== 'resolved' && st !== 'completed';
    });

    const calcMttr = (items) => {
      const times = items.map(i => {
        const reported = i.reportedDate || i.createdDate || i.date;
        const resolved = i.resolvedDate || i.closedDate;
        if (!reported || !resolved) return null;
        return (new Date(resolved) - new Date(reported)) / 3600000;
      }).filter(t => t !== null && t >= 0);
      return times.length > 0 ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : 0;
    };

    const highPriority = data.filter(i => {
      const p = (i.priority || '').toLowerCase();
      return p.includes('high') || p.includes('critical') || p.includes('urgent');
    });

    return {
      total: data.length,
      open: openItems.length,
      resolved: data.length - openItems.length,
      highPriority: highPriority.length,
      mttr: calcMttr(data),
      bySeverity: Object.entries(countBy(data, 'severity')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ severity: k, count: v })),
      byStatus: Object.entries(countBy(data, 'status')).map(([k, v]) => ({ status: k, count: v })),
      byPriority: Object.entries(countBy(data, 'priority')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ priority: k, count: v })),
      openItems: openItems.slice(0, 10),
    };
  }

  analyzeWSRRequirements(reqData) {
    const items = reqData || [];
    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const openItems = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st !== 'closed' && st !== 'resolved' && st !== 'completed';
    });

    const highPriority = items.filter(i => {
      const p = (i.priority || '').toLowerCase();
      return p.includes('high') || p.includes('urgent') || p.includes('critical');
    });

    const completedItems = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st === 'completed' || st === 'closed' || st === 'resolved';
    });

    // Turnaround time
    const turnarounds = items.map(i => {
      const req = i.requestDate || i.createdDate || i.date;
      const comp = i.completionDate || i.closedDate;
      if (!req || !comp) return null;
      return (new Date(comp) - new Date(req)) / 86400000;
    }).filter(t => t !== null && t >= 0);
    const avgTurnaround = turnarounds.length > 0 ? Math.round((turnarounds.reduce((a, b) => a + b, 0) / turnarounds.length) * 10) / 10 : 0;

    // Rejection rate
    const rejected = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st.includes('reject') || st.includes('decline');
    }).length;

    return {
      total: items.length,
      open: openItems.length,
      closed: items.length - openItems.length,
      completed: completedItems.length,
      highPriority: highPriority.length,
      avgTurnaround,
      rejectionRate: items.length > 0 ? Math.round((rejected / items.length) * 100) : 0,
      byType: Object.entries(countBy(items, 'type')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ type: k, count: v })),
      byStatus: Object.entries(countBy(items, 'status')).map(([k, v]) => ({ status: k, count: v })),
      byPriority: Object.entries(countBy(items, 'priority')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ priority: k, count: v })),
    };
  }

  analyzeITTickets(itData) {
    const items = itData || [];
    const now = new Date();

    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const openItems = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st !== 'closed' && st !== 'resolved';
    });

    const slaBreaches = items.filter(i => {
      const sla = (i.slaStatus || '').toLowerCase();
      return sla.includes('breach') || sla.includes('overdue') || sla.includes('missed');
    });

    const avgResolution = (items) => {
      const times = items.map(i => {
        const opened = i.openedDate || i.createdDate || i.date;
        const closed = i.closedDate || i.resolvedDate;
        if (!opened || !closed) return null;
        return (new Date(closed) - new Date(opened)) / 86400000;
      }).filter(t => t !== null && t >= 0);
      return times.length > 0 ? Math.round((times.reduce((a, b) => a + b, 0) / times.length) * 10) / 10 : 0;
    };

    const aging = { '0-3 days': 0, '4-7 days': 0, '8-14 days': 0, '15+ days': 0 };
    openItems.forEach(i => {
      const opened = i.openedDate || i.createdDate || i.date;
      if (!opened) { aging['15+ days']++; return; }
      const days = (now - new Date(opened)) / 86400000;
      if (days <= 3) aging['0-3 days']++;
      else if (days <= 7) aging['4-7 days']++;
      else if (days <= 14) aging['8-14 days']++;
      else aging['15+ days']++;
    });

    // Agent performance
    const agentMap = {};
    items.forEach(i => {
      const agent = i.owner || i.assignedTo || 'Unassigned';
      if (!agentMap[agent]) agentMap[agent] = { total: 0, resolved: 0, avgResolution: 0, slaBreaches: 0 };
      agentMap[agent].total++;
      const st = (i.status || '').toLowerCase();
      if (st === 'closed' || st === 'resolved') agentMap[agent].resolved++;
      const sla = (i.slaStatus || '').toLowerCase();
      if (sla.includes('breach') || sla.includes('overdue')) agentMap[agent].slaBreaches++;
    });
    const agentPerformance = Object.entries(agentMap)
      .filter(([name]) => name !== 'Unassigned')
      .map(([name, d]) => ({
        name,
        total: d.total,
        resolved: d.resolved,
        resolutionRate: d.total > 0 ? Math.round((d.resolved / d.total) * 100) : 0,
        slaBreaches: d.slaBreaches,
      }))
      .sort((a, b) => b.resolved - a.resolved);

    return {
      total: items.length,
      open: openItems.length,
      resolved: items.length - openItems.length,
      slaBreaches: slaBreaches.length,
      avgResolutionDays: avgResolution(items),
      byCategory: Object.entries(countBy(items, 'category')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ category: k, count: v })),
      byStatus: Object.entries(countBy(items, 'status')).map(([k, v]) => ({ status: k, count: v })),
      aging: Object.entries(aging).map(([label, count]) => ({ label, count })),
      topCategories: Object.entries(countBy(items, 'category')).sort((a, b) => b[1] - a[1]).slice(0, 5),
      agentPerformance: agentPerformance.slice(0, 5),
    };
  }

  analyzeLegalCases(legalData) {
    const items = legalData || [];
    const now = new Date();

    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const openItems = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st !== 'closed' && st !== 'resolved';
    });

    const highPriority = items.filter(i => {
      const p = (i.priority || '').toLowerCase();
      return p.includes('high') || p.includes('urgent') || p.includes('critical');
    });

    const avgAge = (items) => {
      const ages = items.map(i => {
        const opened = i.openedDate || i.createdDate || i.date;
        if (!opened) return null;
        return (now - new Date(opened)) / 86400000;
      }).filter(a => a !== null);
      return ages.length > 0 ? Math.round(ages.reduce((a, b) => a + b, 0) / ages.length) : 0;
    };

    // Resolution time by type
    const resolutionByType = {};
    items.forEach(i => {
      if (!i.openedDate || !i.closedDate) return;
      const type = i.category || 'General';
      const days = (new Date(i.closedDate) - new Date(i.openedDate)) / 86400000;
      if (days < 0) return;
      if (!resolutionByType[type]) resolutionByType[type] = [];
      resolutionByType[type].push(days);
    });
    const resolutionTimeByType = Object.entries(resolutionByType).map(([type, times]) => ({
      type,
      avgDays: times.length > 0 ? Math.round((times.reduce((a, b) => a + b, 0) / times.length) * 10) / 10 : 0,
      count: times.length,
    })).sort((a, b) => b.count - a.count);

    // Case value/risk score
    const caseRiskScore = openItems.map(i => {
      const age = (now - new Date(i.openedDate || i.createdDate || now)) / 86400000;
      const priorityWeight = (i.priority || '').toLowerCase().includes('high') ? 3 : (i.priority || '').toLowerCase().includes('medium') ? 2 : 1;
      const score = Math.min(100, Math.round((age * 2) + (priorityWeight * 10)));
      return { caseId: i.caseId || i.id || '-', score, age: Math.round(age), priority: i.priority || '-' };
    }).sort((a, b) => b.score - a.score).slice(0, 5);

    return {
      total: items.length,
      open: openItems.length,
      closed: items.length - openItems.length,
      highPriority: highPriority.length,
      avgAgeDays: avgAge(openItems),
      byCategory: Object.entries(countBy(items, 'category')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ category: k, count: v })),
      byStatus: Object.entries(countBy(items, 'status')).map(([k, v]) => ({ status: k, count: v })),
      aging: this._calcAging(openItems),
      resolutionTimeByType,
      caseRiskScore,
    };
  }

  analyzeCloudRequests(cloudData) {
    const items = cloudData || [];

    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const pending = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st.includes('pending') || st.includes('in progress') || st.includes('open');
    });

    const completed = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st.includes('complete') || st.includes('done') || st.includes('closed');
    });

    const failed = items.filter(i => {
      const st = (i.status || '').toLowerCase();
      return st.includes('fail') || st.includes('reject') || st.includes('error');
    });

    // Cloud lead time
    const leadTimes = items.map(i => {
      const req = i.requestDate || i.createdDate || i.date;
      const comp = i.completionDate || i.closedDate;
      if (!req || !comp) return null;
      return (new Date(comp) - new Date(req)) / 86400000;
    }).filter(t => t !== null && t >= 0);
    const avgLeadTime = leadTimes.length > 0 ? Math.round((leadTimes.reduce((a, b) => a + b, 0) / leadTimes.length) * 10) / 10 : 0;

    // Fulfillment rate
    const fulfillmentRate = items.length > 0 ? Math.round((completed.length / items.length) * 100) : 0;

    return {
      total: items.length,
      pending: pending.length,
      completed: completed.length,
      failed: failed.length,
      queueDepth: pending.length,
      avgLeadTime,
      fulfillmentRate,
      byType: Object.entries(countBy(items, 'type')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ type: k, count: v })),
      byEnvironment: Object.entries(countBy(items, 'environment')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ environment: k, count: v })),
      byStatus: Object.entries(countBy(items, 'status')).map(([k, v]) => ({ status: k, count: v })),
    };
  }

  analyzeHeadcount(headcountData) {
    const items = headcountData || [];

    // Detect bucket-aggregate format (Neocities headcount-data.json returns
    // pre-aggregated buckets with a 'count' field, not individual employee records).
    const isBuckets = items.length > 0 && items[0].count != null && !items[0].employeeId;
    if (isBuckets) {
      const total = items.reduce((s, b) => s + (b.count || 0), 0);
      const byGroup = {};
      items.forEach(b => {
        const grp = b.group || b.groupName || b.department || 'Unknown';
        byGroup[grp] = (byGroup[grp] || 0) + (b.count || 0);
      });
      const byBand = {};
      items.forEach(b => {
        const key = `${b.band || '?'}/${b.grade || '?'}`;
        byBand[key] = (byBand[key] || 0) + (b.count || 0);
      });
      return {
        total, active: total, inactive: 0,
        byDepartment: Object.entries(byGroup).sort((a, b) => b[1] - a[1]).map(([department, count]) => ({ department, count })),
        byStatus: [{ status: 'Active', count: total }],
        byBand: Object.entries(byBand).sort((a, b) => b[1] - a[1]).map(([band, count]) => ({ band, count })),
        tenureDistribution: [{ label: '< 1 year', count: 0 }, { label: '1-3 years', count: 0 }, { label: '3-5 years', count: 0 }, { label: '5+ years', count: 0 }],
        spanOfControl: 0, managerCount: 0, newHires30: 0, newHires60: 0, newHires90: 0,
      };
    }

    const countBy = (items, key) => {
      const map = {};
      items.forEach(i => { const v = (i[key] || 'Unknown').toString(); map[v] = (map[v] || 0) + 1; });
      return map;
    };

    const active = items.filter(i => this._isActiveEmployment(i));

    // Tenure distribution
    const now = new Date();
    const tenure = { '< 1 year': 0, '1-3 years': 0, '3-5 years': 0, '5+ years': 0 };
    items.forEach(i => {
      const joined = i.joinDate || i.date;
      if (!joined) { tenure['< 1 year']++; return; }
      const years = (now - new Date(joined)) / (86400000 * 365);
      if (years < 1) tenure['< 1 year']++;
      else if (years < 3) tenure['1-3 years']++;
      else if (years < 5) tenure['3-5 years']++;
      else tenure['5+ years']++;
    });

    // Span of control
    const managerMap = {};
    items.forEach(i => {
      const mgr = i.manager || i.reportingManager || 'Unknown';
      managerMap[mgr] = (managerMap[mgr] || 0) + 1;
    });
    const managerCounts = Object.values(managerMap);
    const spanOfControl = managerCounts.length > 0 ? Math.round((managerCounts.reduce((a, b) => a + b, 0) / managerCounts.length) * 10) / 10 : 0;

    // New hire pipeline
    const newHires30 = items.filter(i => {
      const joined = i.joinDate || i.date;
      if (!joined) return false;
      return (now - new Date(joined)) / 86400000 <= 30;
    }).length;
    const newHires60 = items.filter(i => {
      const joined = i.joinDate || i.date;
      if (!joined) return false;
      return (now - new Date(joined)) / 86400000 <= 60;
    }).length;
    const newHires90 = items.filter(i => {
      const joined = i.joinDate || i.date;
      if (!joined) return false;
      return (now - new Date(joined)) / 86400000 <= 90;
    }).length;

    return {
      total: items.length,
      active: active.length,
      inactive: items.length - active.length,
      byDepartment: Object.entries(countBy(items, 'department')).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ department: k, count: v })),
      byStatus: Object.entries(countBy(items, 'status')).map(([k, v]) => ({ status: k, count: v })),
      tenureDistribution: Object.entries(tenure).map(([label, count]) => ({ label, count })),
      spanOfControl,
      managerCount: managerCounts.length,
      newHires30,
      newHires60,
      newHires90,
    };
  }

  analyzeHeadcountReconciliation(opsData = {}) {
    const dimensions = [
      { key: 'band', label: 'Band', fields: ['band', 'employeeBand', 'empBand'], compositeFields: ['bandGrade'], compositeIndex: 0 },
      { key: 'grade', label: 'Grade', fields: ['grade', 'employeeGrade', 'empGrade'], compositeFields: ['bandGrade'], compositeIndex: 1 },
      { key: 'group', label: 'Group', fields: ['group', 'department', 'dept', 'businessUnit'], compositeFields: ['groupSubGroup'], compositeIndex: 0 },
      { key: 'subGroup', label: 'Sub Group', fields: ['subGroup', 'subgroup', 'sub_group', 'subDepartment'], compositeFields: ['groupSubGroup'], compositeIndex: 1 },
    ];
    const activeOnly = (rows) => (rows || []).filter(row => this._isActiveEmployment(row));
    const sources = {
      bnEmployee: activeOnly(opsData.headcount2),
      bnUser: activeOnly(opsData.headcount),
      ps: activeOnly(opsData.peoplestrong?.employees),
    };
    const cleanValue = (value) => String(value || '').trim().replace(/\s+/g, ' ');
    const valueFor = (row, dimension) => {
      for (const field of dimension.fields) {
        const value = row?.[field];
        if (value !== undefined && value !== null && String(value).trim()) {
          return cleanValue(value);
        }
      }
      for (const field of dimension.compositeFields || []) {
        const value = row?.[field];
        if (value !== undefined && value !== null && String(value).trim()) {
          const parts = cleanValue(value).split(/\s*(?:\/|\||>)\s*/).filter(Boolean);
          return cleanValue(parts[dimension.compositeIndex] || value);
        }
      }
      return 'Unknown';
    };
    const countBy = (rows, dimension) => {
      const map = {};
      rows.forEach(row => {
        const value = valueFor(row, dimension);
        map[value] = (map[value] || 0) + 1;
      });
      return map;
    };
    const byDimension = {};
    let mismatchSegments = 0;
    let maxAbsDelta = 0;
    for (const dimension of dimensions) {
      const maps = {
        bnEmployee: countBy(sources.bnEmployee, dimension),
        bnUser: countBy(sources.bnUser, dimension),
        ps: countBy(sources.ps, dimension),
      };
      const labels = Array.from(new Set([
        ...Object.keys(maps.bnEmployee),
        ...Object.keys(maps.bnUser),
        ...Object.keys(maps.ps),
      ]));
      const rows = labels.map(label => {
        const bnEmployee = maps.bnEmployee[label] || 0;
        const bnUser = maps.bnUser[label] || 0;
        const ps = maps.ps[label] || 0;
        const employeeDelta = bnEmployee - ps;
        const userDelta = bnUser - ps;
        const mismatch = employeeDelta !== 0 || userDelta !== 0;
        if (mismatch) mismatchSegments += 1;
        maxAbsDelta = Math.max(maxAbsDelta, Math.abs(employeeDelta), Math.abs(userDelta));
        return { label, bnEmployee, bnUser, ps, employeeDelta, userDelta, mismatch };
      }).sort((a, b) => {
        const aGap = Math.max(Math.abs(a.employeeDelta), Math.abs(a.userDelta));
        const bGap = Math.max(Math.abs(b.employeeDelta), Math.abs(b.userDelta));
        return bGap - aGap || b.ps - a.ps || a.label.localeCompare(b.label);
      });
      byDimension[dimension.key] = {
        label: dimension.label,
        rows,
        mismatchCount: rows.filter(row => row.mismatch).length,
      };
    }
    return {
      sources: {
        bnEmployee: { label: 'BN Employee', total: sources.bnEmployee.length },
        bnUser: { label: 'BN User', total: sources.bnUser.length },
        ps: { label: 'PS Master', total: sources.ps.length },
      },
      totals: {
        bnEmployee: sources.bnEmployee.length,
        bnUser: sources.bnUser.length,
        ps: sources.ps.length,
        employeeDelta: sources.bnEmployee.length - sources.ps.length,
        userDelta: sources.bnUser.length - sources.ps.length,
      },
      mismatchSegments,
      maxAbsDelta,
      byDimension,
    };
  }

  // ─── ENGINEERING METRICS (Phase 1 additions) ───

  calculateCycleTimeDistribution(sprintData) {
    const workItems = sprintData?.workItems || [];
    const closedItems = workItems.filter(wi => wi.closedDate && wi.createdDate);
    const cycleTimes = closedItems.map(wi => {
      return (new Date(wi.closedDate) - new Date(wi.createdDate)) / 86400000;
    }).filter(t => t >= 0).sort((a, b) => a - b);

    if (cycleTimes.length === 0) return { p50: 0, p75: 0, p90: 0, avg: 0, count: 0 };

    const percentile = (arr, p) => {
      const idx = Math.ceil((p / 100) * arr.length) - 1;
      return Math.round(arr[Math.max(0, idx)] * 10) / 10;
    };

    return {
      p50: percentile(cycleTimes, 50),
      p75: percentile(cycleTimes, 75),
      p90: percentile(cycleTimes, 90),
      avg: Math.round((cycleTimes.reduce((a, b) => a + b, 0) / cycleTimes.length) * 10) / 10,
      count: cycleTimes.length,
    };
  }

  calculateWIPSnapshot(stats) {
    const byState = stats.byState || {};
    const activeCount = byState['Active'] || byState['In Progress'] || byState['Committed'] || 0;
    const wipLimit = Math.max(3, Math.round((stats.total || 0) * 0.4));
    return {
      activeCount,
      wipLimit,
      adherence: wipLimit > 0 ? Math.round((activeCount / wipLimit) * 100) : 0,
      overloaded: activeCount > wipLimit,
    };
  }

  calculateAssigneeLoadBalance(stats) {
    const byAssignee = stats.byAssignee || {};
    const members = Object.entries(byAssignee).filter(([n]) => n !== 'Unassigned');
    if (members.length < 2) return { gini: 0, spread: 0, balanced: true };

    const loads = members.map(([, d]) => d.total || 0).sort((a, b) => a - b);
    const n = loads.length;
    const mean = loads.reduce((a, b) => a + b, 0) / n;
    if (mean === 0) return { gini: 0, spread: 0, balanced: true };

    // Gini coefficient
    let num = 0;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        num += Math.abs(loads[i] - loads[j]);
      }
    }
    const gini = Math.round((num / (2 * n * n * mean)) * 100) / 100;

    const spread = Math.max(...loads) - Math.min(...loads);
    return { gini, spread, balanced: gini < 0.3, maxLoad: Math.max(...loads), minLoad: Math.min(...loads) };
  }

  calculateThroughputVariance(sprintData) {
    const workItems = sprintData?.workItems || [];
    const now = new Date();
    const weeklyClosures = [];
    for (let week = 0; week < 4; week++) {
      const start = week * 7;
      const end = (week + 1) * 7;
      const count = workItems.filter(wi => {
        if (!wi.closedDate) return false;
        const diff = (now - new Date(wi.closedDate)) / 86400000;
        return diff >= start && diff < end;
      }).length;
      weeklyClosures.push(count);
    }
    const mean = weeklyClosures.reduce((a, b) => a + b, 0) / weeklyClosures.length;
    const variance = mean > 0
      ? Math.round((weeklyClosures.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / weeklyClosures.length) * 100) / 100
      : 0;
    const stdDev = Math.round(Math.sqrt(variance) * 100) / 100;
    return { weekly: weeklyClosures, variance, stdDev, mean: Math.round(mean * 10) / 10, coefficient: mean > 0 ? Math.round((stdDev / mean) * 100) : 0 };
  }

  calculateLeadTimeByType(sprintData) {
    const workItems = sprintData?.workItems || [];
    const types = {};
    workItems.forEach(wi => {
      if (!wi.closedDate || !wi.createdDate) return;
      const type = wi.type || 'Unknown';
      const days = (new Date(wi.closedDate) - new Date(wi.createdDate)) / 86400000;
      if (days < 0) return;
      if (!types[type]) types[type] = [];
      types[type].push(days);
    });

    return Object.entries(types).map(([type, times]) => ({
      type,
      avgDays: times.length > 0 ? Math.round((times.reduce((a, b) => a + b, 0) / times.length) * 10) / 10 : 0,
      count: times.length,
    })).sort((a, b) => b.count - a.count);
  }

  calculateDailyBurnRate(sprintData) {
    const stats = sprintData?.stats || {};
    const sprint = sprintData?.sprint || {};
    const total = stats.total || 0;
    const closed = stats.closed || 0;
    const remaining = total - closed;
    const finishDate = sprint?.attributes?.finishDate ? new Date(sprint.attributes.finishDate) : null;
    const now = new Date();
    const daysRemaining = finishDate ? Math.max(0, Math.ceil((finishDate - now) / 86400000)) : 0;
    const rate = daysRemaining > 0 ? Math.round((remaining / daysRemaining) * 10) / 10 : 0;
    return { remaining, daysRemaining, rate, onTrack: rate <= 2 };
  }

  calculateBlockedItemAge(stats) {
    const blocked = stats.blockedItems || [];
    const now = new Date();
    const ages = blocked.map(b => {
      const blockedSince = b.blockedSince || b.changedDate || b.createdDate;
      if (!blockedSince) return 0;
      return Math.round((now - new Date(blockedSince)) / 86400000);
    });
    const avgAge = ages.length > 0 ? Math.round(ages.reduce((a, b) => a + b, 0) / ages.length) : 0;
    const maxAge = ages.length > 0 ? Math.max(...ages) : 0;
    return { count: blocked.length, avgAge, maxAge, critical: maxAge > 3 };
  }

  // ─── CROSS-DOMAIN METRICS (Phase 9) ───

  calculateOperationsMaturityScore(analysis) {
    const inc = analysis?.incidents || {};
    const it = analysis?.itTickets || {};
    const legal = analysis?.legalCases || {};
    const cloud = analysis?.cloudRequests || {};

    const mttrScore = (inc.mttr || 0) <= 24 ? 100 : (inc.mttr || 0) <= 48 ? 70 : 40;
    const slaScore = (it.slaBreaches || 0) === 0 ? 100 : (it.slaBreaches || 0) <= 2 ? 70 : 40;
    const backlogScore = (inc.open || 0) <= 5 ? 100 : (inc.open || 0) <= 10 ? 70 : 40;
    const p1Score = (inc.p1Count || 0) === 0 ? 100 : (inc.p1Count || 0) <= 2 ? 60 : 30;
    const cloudScore = (cloud.pending || 0) <= 3 ? 100 : (cloud.pending || 0) <= 5 ? 70 : 40;
    const legalScore = (legal.highPriority || 0) === 0 ? 100 : 60;

    const overall = Math.round((mttrScore + slaScore + backlogScore + p1Score + cloudScore + legalScore) / 6);
    return {
      overall,
      grade: overall >= 80 ? 'A' : overall >= 60 ? 'B' : overall >= 40 ? 'C' : 'D',
      breakdown: { mttr: mttrScore, sla: slaScore, backlog: backlogScore, p1: p1Score, cloud: cloudScore, legal: legalScore },
    };
  }

  calculateOrgHealthIndex(analysis) {
    const stats = analysis?.stats || {};
    const inc = analysis?.incidents || {};
    const it = analysis?.itTickets || {};
    const hc = analysis?.headcount || {};

    const engScore = (stats.healthScore || 0);
    const opsScore = this.calculateOperationsMaturityScore(analysis).overall;
    const hrScore = hc.total > 0 ? Math.min(100, Math.round((hc.active / hc.total) * 100)) : 0;

    const overall = Math.round((engScore * 0.4) + (opsScore * 0.4) + (hrScore * 0.2));
    return {
      overall,
      grade: overall >= 80 ? 'A' : overall >= 60 ? 'B' : overall >= 40 ? 'C' : 'D',
      breakdown: { engineering: engScore, operations: opsScore, hr: hrScore },
    };
  }

  _calcAging(items) {
    const now = new Date();
    const buckets = { '0-7 days': 0, '8-30 days': 0, '31-90 days': 0, '90+ days': 0 };
    items.forEach(i => {
      const opened = i.openedDate || i.createdDate || i.date;
      if (!opened) { buckets['90+ days']++; return; }
      const days = (now - new Date(opened)) / 86400000;
      if (days <= 7) buckets['0-7 days']++;
      else if (days <= 30) buckets['8-30 days']++;
      else if (days <= 90) buckets['31-90 days']++;
      else buckets['90+ days']++;
    });
    return Object.entries(buckets).map(([label, count]) => ({ label, count }));
  }

  // ─── HELPERS ───
  _verdict(stats) {
    const pct = stats.total > 0 ? Math.round((stats.closed / stats.total) * 100) : 0;
    const health = stats.healthScore || 0;
    const risk = (stats.staleItems || []).length + (stats.overdueItems || []).length + (stats.blockedItems || []).length;

    if (pct >= 80 && health >= 70 && risk === 0) return { status: 'green', icon: '🟢', text: 'On Track — Strong execution, no significant risks' };
    if (pct >= 60 && health >= 50) return { status: 'yellow', icon: '🟡', text: 'Moderate — Some areas need attention but overall progress' };
    if (pct >= 40 || health >= 30) return { status: 'amber', icon: '🟠', text: 'Behind — Requires intervention and scope review' };
    return { status: 'red', icon: '🔴', text: 'At Risk — Immediate escalation needed' };
  }

  _trunc(s, n) {
    if (typeof s === 'number') return String(s);
    return s && s.length > n ? s.substring(0, n - 2) + '..' : (s || '');
  }


  // ─── PEOPLESTRONG HR ANALYSIS ───
  analyzePeopleStrong(psData) {
    const employees = psData?.employees || [];
    const attendance = psData?.attendance || [];
    const leave = psData?.leave || [];

    // Employee stats
    const totalEmployees = employees.length;
    const activeEmployeeRows = employees.filter(e => this._isActiveEmployment(e));
    const activeEmployees = activeEmployeeRows.length;
    const byDepartment = this._groupByCount(activeEmployeeRows.map(e => ({ ...e, department: e.department || e.group || e.subGroup })), 'department');
    const byDesignation = this._groupByCount(activeEmployeeRows, 'designation');
    const byLocation = this._groupByCount(activeEmployeeRows.map(e => ({ ...e, location: e.location || e.workingLocation || e.workLocationName })), 'location');

    // Attendance stats
    const totalAttendanceRecords = attendance.length;
    const presentCount = attendance.filter(a => (a.status || '').toLowerCase().includes('present')).length;
    const absentCount = attendance.filter(a => (a.status || '').toLowerCase().includes('absent')).length;
    const lateCount = attendance.filter(a => (a.status || '').toLowerCase().includes('late')).length;
    const attendanceRate = totalAttendanceRecords > 0 ? Math.round((presentCount / totalAttendanceRecords) * 100) : 0;
    const avgHours = attendance.length > 0
      ? Math.round(attendance.reduce((sum, a) => sum + (parseFloat(a.hours) || 0), 0) / attendance.length * 10) / 10
      : 0;

    // Leave stats
    const totalLeaveRecords = leave.length;
    const approvedLeave = leave.filter(l => (l.status || '').toLowerCase().includes('approved')).length;
    const pendingLeave = leave.filter(l => (l.status || '').toLowerCase().includes('pending')).length;
    const totalLeaveDays = leave.reduce((sum, l) => sum + (parseFloat(l.days) || 0), 0);
    const byLeaveType = this._groupByCount(leave, 'leaveType');

    return {
      employees: {
        total: totalEmployees,
        active: activeEmployees,
        byDepartment,
        byDesignation,
        byLocation,
      },
      attendance: {
        totalRecords: totalAttendanceRecords,
        present: presentCount,
        absent: absentCount,
        late: lateCount,
        rate: attendanceRate,
        avgHours,
      },
      leave: {
        totalRecords: totalLeaveRecords,
        approved: approvedLeave,
        pending: pendingLeave,
        totalDays: totalLeaveDays,
        byType: byLeaveType,
      },
    };
  }

  _groupByCount(items, key) {
    const groups = {};
    items.forEach(item => {
      const val = item[key] || 'Unknown';
      groups[val] = (groups[val] || 0) + 1;
    });
    return Object.entries(groups)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }

  _isActiveEmployment(row) {
    const status = String(row?.status || row?.employmentStatus || '').toLowerCase();
    if (!status) return true;
    if (/inactive|exit|resign|terminat|reliev|left|dummy|excluded/.test(status)) return false;
    return true;
  }
}

module.exports = ReportAnalyzer;
