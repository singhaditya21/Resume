/**
 * Hermes Agent HTTP Client
 * Uses NVIDIA NIM OpenAI-compatible API for LLM inference
 */
const https = require('https');

const HERMES_HOST = process.env.HERMES_HOST || 'integrate.api.nvidia.com';
const HERMES_PORT = parseInt(process.env.HERMES_PORT || '443', 10);
const HERMES_API_KEY = process.env.HERMES_API_KEY;
const HERMES_MODEL = process.env.HERMES_MODEL || 'meta/llama-3.1-8b-instruct';

function hermesRequest(path, method = 'GET', body = null, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: HERMES_HOST,
      port: HERMES_PORT,
      path: path,
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HERMES_API_KEY}`,
      },
      timeout: timeoutMs,
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, data: parsed });
        } catch {
          resolve({ status: res.statusCode, data });
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error(`Hermes request timeout after ${timeoutMs}ms`));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

class HermesClient {
  constructor(opts = {}) {
    this.host = opts.host || HERMES_HOST;
    this.port = opts.port || HERMES_PORT;
    this.apiKey = opts.apiKey || HERMES_API_KEY;
    this.model = opts.model || HERMES_MODEL;
    // BUG FIX: 60s default was too tight — empirical test showed the full WSR
    // prompt (~10KB + slide context) takes 20-30s on an 8B model and can hit
    // 60s under load. Raised to 180s so transient API slowness doesn't null
    // out AI commentary across 7 cockpit slides.
    this.timeout = opts.timeout || 180000;
    if (!this.apiKey) {
      throw new Error('[Hermes] HERMES_API_KEY environment variable is required. Set it in your .env file.');
    }
  }

  /** Check if NVIDIA API is reachable */
  async health() {
    try {
      const { data } = await hermesRequest('/v1/models', 'GET', null, 10000);
      return { ok: true, models: data.data?.length || 0 };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  /**
   * Send a chat completion request to NVIDIA NIM
   * @param {Array} messages - OpenAI messages format
   * @param {Array} tools - Tool definitions for function calling
   * @param {object} opts - Extra options (temperature, max_tokens, etc.)
   */
  async chat(messages, tools = [], opts = {}) {
    const body = {
      model: this.model,
      messages,
      temperature: opts.temperature ?? 0.7,
      top_p: opts.top_p ?? 0.95,
      max_tokens: opts.max_tokens ?? 4096,
      stream: false,
    };

    if (tools.length > 0) {
      body.tools = tools;
      body.tool_choice = 'auto';
    }

    const { data } = await hermesRequest('/v1/chat/completions', 'POST', body, this.timeout);

    if (data.choices && data.choices[0]) {
      const choice = data.choices[0];
      return {
        text: choice.message?.content || '',
        toolCalls: choice.message?.tool_calls || [],
        finishReason: choice.finish_reason,
        usage: data.usage,
      };
    }
    return { text: '', toolCalls: [], finishReason: null, usage: null };
  }

  /**
   * Structured output: ask Hermes to return JSON
   *
   * Now with multi-strategy parsing to recover from common LLM JSON failures:
   *   1. Plain JSON.parse on cleaned text
   *   2. Strip markdown ```json``` fences
   *   3. Extract first {...} block from prose-padded responses
   *   4. Truncation repair: balance braces/brackets if response cut off
   * If all strategies fail, throw with raw text snippet for diagnosis.
   */
  async json(messages, schema = null, opts = {}) {
    const systemMsg = `You are a structured data assistant. You MUST respond with valid JSON only. No markdown, no explanations, no code blocks. Just raw JSON.`;
    const allMessages = [
      { role: 'system', content: systemMsg },
      ...messages,
    ];
    if (schema) {
      allMessages.push({
        role: 'user',
        content: `Respond with JSON matching this schem/opt/portfolio/project
      });
    }
    const result = await this.chat(allMessages, [], { ...opts, temperature: 0.3 });
    const raw = result.text || '';

    // Strategy 1+2: strip code fences, try to parse
    const cleaned = raw.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    try { return JSON.parse(cleaned); } catch (_) {}

    // Strategy 3: extract the first {...} block (handles prose padding)
    const start = cleaned.indexOf('{');
    if (start >= 0) {
      // Try to find a balanced closing brace
      let depth = 0, end = -1;
      for (let i = start; i < cleaned.length; i++) {
        const c = cleaned[i];
        if (c === '{') depth++;
        else if (c === '}') { depth--; if (depth === 0) { end = i; break; } }
      }
      if (end > start) {
        try { return JSON.parse(cleaned.slice(start, end + 1)); } catch (_) {}
      }
    }

    // Strategy 4: truncation repair — close unbalanced braces/brackets at the end
    if (start >= 0) {
      let body = cleaned.slice(start);
      // Trim trailing comma + whitespace before closing
      body = body.replace(/,\s*$/, '');
      let braces = 0, brackets = 0, inStr = false, escape = false;
      for (let i = 0; i < body.length; i++) {
        const c = body[i];
        if (escape) { escape = false; continue; }
        if (c === '\\') { escape = true; continue; }
        if (c === '"') { inStr = !inStr; continue; }
        if (inStr) continue;
        if (c === '{') braces++;
        else if (c === '}') braces--;
        else if (c === '[') brackets++;
        else if (c === ']') brackets--;
      }
      if (inStr) body += '"';
      while (brackets > 0) { body += ']'; brackets--; }
      while (braces > 0) { body += '}'; braces--; }
      try { return JSON.parse(body); } catch (_) {}
    }

    throw new Error(`Failed to parse Hermes JSON response after 4 repair strategies. Length=${raw.length}, finishReason=${result.finishReason}. Raw start: ${raw.slice(0, 300)}... end: ${raw.slice(-200)}`);
  }
}

module.exports = { HermesClient, hermesRequest };
