/**
 * Error type hierarchy for WSR Automate.
 *
 * BaseAgent.run() checks error type before retrying — ConfigError and
 * DataError skip retries immediately, NetworkError retries up to the
 * configured limit.
 */

class ConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ConfigError';
  }
}

class NetworkError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.name = 'NetworkError';
    this.statusCode = statusCode;
  }
}

class DataError extends Error {
  constructor(message) {
    super(message);
    this.name = 'DataError';
  }
}

class AuthError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthError';
  }
}

module.exports = { ConfigError, NetworkError, DataError, AuthError };
