const { EmailAgent } = require('./email-agent');
const { WhatsAppAgent } = require('./whatsapp-agent');

async function runDeliveryAgents({ dateFrom, dateTo, pptxResult, mergedAnalysis }) {
  const results = {};
  const errors = {};
  const context = { dateFrom, dateTo, dependencies: { pptx: pptxResult, analysis: { analysis: mergedAnalysis } } };
  for (const [key, AgentClass] of [['email', EmailAgent], ['whatsapp', WhatsAppAgent]]) {
    try {
      results[key] = await new AgentClass().run(context);
    } catch (err) {
      errors[key] = err.message;
      results[key] = { sent: false, error: err.message };
    }
  }
  return { results, errors };
}

module.exports = { runDeliveryAgents };
