const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_LIMITS = {
  runs: 60,
  learnings: 240,
  feedback: 120,
};

function nowIso() {
  return new Date().toISOString();
}

function normalizeText(value, max = 1000) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function stableId(prefix, value) {
  return `${prefix}-${crypto.createHash('sha1').update(String(value)).digest('hex').slice(0, 12)}`;
}

function writeJsonAtomic(filePath, payload) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(payload, null, 2));
  fs.renameSync(tmp, filePath);
}

function rowCount(evidence) {
  const count = Number(evidence?.count);
  return Number.isFinite(count) ? count : 0;
}

function summarizeRecommendation(item) {
  const raw = typeof item === 'string' ? item : item?.text || item?.action || item?.summary;
  return normalizeText(raw, 220);
}

function blankMemory() {
  const at = nowIso();
  return {
    schemaVersion: 1,
    createdAt: at,
    updatedAt: at,
    runCount: 0,
    sourceStats: {},
    recommendationStats: {},
    runs: [],
    learnings: [],
    feedback: [],
    weeklySnapshots: [],
    latestRun: null,
  };
}

class HermesMemory {
  constructor(opts = {}) {
    const root = opts.rootDir || opts.outputDir || process.env.HERMES_MEMORY_DIR || process.env.OUTPUT_DIR || path.join(process.cwd(), 'output');
    this.rootDir = path.resolve(root);
    this.filePath = opts.filePath || path.join(this.rootDir, 'hermes', 'memory.json');
    this.limits = { ...DEFAULT_LIMITS, ...(opts.limits || {}) };
  }

  read() {
    try {
      return { ...blankMemory(), ...JSON.parse(fs.readFileSync(this.filePath, 'utf8')) };
    } catch {
      return blankMemory();
    }
  }

  write(memory) {
    writeJsonAtomic(this.filePath, { ...memory, updatedAt: nowIso() });
  }

  promptContext() {
    const memory = this.read();
    const sourceLines = Object.values(memory.sourceStats || {})
      .sort((a, b) => String(a.id).localeCompare(String(b.id)))
      .slice(0, 20)
      .map(s => {
        const reliability = s.runs ? Math.round(((s.live || 0) / s.runs) * 100) : 0;
        return `${s.name || s.id}: ${reliability}% live reliability, last=${s.lastStatus || 'unknown'}, rows=${s.lastCount || 0}`;
      });
    const learningLines = (memory.learnings || []).slice(-8).map(l => `- ${l.text}`);
    const feedbackLines = (memory.feedback || []).filter(f => f.active !== false).slice(-6).map(f => `- ${f.area || 'general'}: ${f.message}`);

    let context = [
      `Hermes durable memory has ${memory.runCount || 0} prior runs.`,
      sourceLines.length ? `Source reliabilit/opt/portfolio/project'\n')}` : 'Source reliability: no prior runs.',
      learningLines.length ? `Recent learned pattern/opt/portfolio/project'\n')}` : 'Recent learned patterns: none yet.',
      feedbackLines.length ? `User feedback to hono/opt/portfolio/project'\n')}` : 'User feedback to honor: none recorded.',
    ].join('\n\n');

    // Editorial context for Hermes prompt
    const editPattern = (memory.patterns || []).find(p => p.key === 'editorial-outcomes');
    if (editPattern && editPattern.runs > 0) {
      const chronicallyWeak = Object.entries(editPattern.weakSlides || {})
        .filter(([, count]) => count >= 2)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([slide, count]) => `${slide}(${count}x)`);
      if (chronicallyWeak.length) {
        context += `\nEditorial history: these slides consistently need title rewrites: ${chronicallyWeak.join(', ')}. Prioritise editorial attention here.`;
      }
      const recentCoverage = editPattern.hermesCoverage.slice(-3);
      const avgScore = recentCoverage.length
        ? Math.round(recentCoverage.reduce((s, r) => s + r.score, 0) / recentCoverage.length)
        : 0;
      if (avgScore > 0) context += `\nEditorial quality 3-run avg: ${avgScore}/100.`;
    }

    // Trend distillation from weekly snapshots (last 4)
    const snapshots = (memory.weeklySnapshots || []).slice(-4);
    if (snapshots.length >= 2) {
      const first = snapshots[0];
      const last  = snapshots[snapshots.length - 1];
      const healthDir  = last.healthScore != null && first.healthScore != null
        ? (last.healthScore > first.healthScore ? 'improving' : last.healthScore < first.healthScore ? 'declining' : 'flat')
        : 'unknown';
      const velocityDir = last.velocity != null && first.velocity != null
        ? (last.velocity > first.velocity ? 'increasing' : last.velocity < first.velocity ? 'decreasing' : 'stable')
        : 'unknown';

      // Anomaly: metric that declined 2+ consecutive runs
      const anomalies = [];
      for (const key of ['healthScore', 'velocity', 'itsmOpen', 'mprOpen', 'cloudPending', 'oegTotal', 'wsrIncTotal']) {
        let declines = 0;
        for (let i = 1; i < snapshots.length; i++) {
          const prev = snapshots[i - 1][key];
          const curr = snapshots[i][key];
          if (prev != null && curr != null) {
            // For itsmOpen/mprOpen, increasing is bad; for health/velocity, decreasing is bad
            const deteriorated = (['itsmOpen', 'mprOpen', 'cloudPending', 'oegTotal', 'wsrIncTotal'].includes(key)) ? curr > prev : curr < prev;
            if (deteriorated) declines++;
            else declines = 0;
          }
          if (declines >= 2) { anomalies.push(key); break; }
        }
      }

      context += `\n\nHistorical trend (${snapshots.length} snapshots): health=${healthDir}, velocity=${velocityDir}.`;
      if (anomalies.length) context += ` Anomalies — ${anomalies.length} metric(s) deteriorating ≥2 consecutive runs: ${anomalies.join(', ')}.`;
    }

    // Co-failure warning for Hermes
    const coPattern = (memory.patterns || []).find(p => p.key === 'co-failure-patterns');
    if (coPattern && coPattern.runs >= 2) {
      const recent = coPattern.events.slice(-2).map(e => e.sources.join('+'));
      context += `\nCo-failure alert: ${coPattern.runs} runs had ≥2 simultaneous source failures. Recent: ${recent.join('; ')}. Check for systemic auth/infra issue.`;
    }

    // Persona usage context
    const personaPattern = (memory.patterns || []).find(p => p.key === 'persona-usage');
    if (personaPattern && personaPattern.runs >= 3) {
      const top = Object.entries(personaPattern.counts || {})
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([mode, count]) => `${mode}:${count}`)
        .join(', ');
      context += `\nPersona usage (${personaPattern.runs} runs): ${top}. Tailor analysis depth to the most-used persona.`;
    }

    // Persistent anomaly warning with start-date escalation
    const anomalyPattern = (memory.patterns || []).find(p => p.key === 'anomaly-tracking');
    if (anomalyPattern && Object.keys(anomalyPattern.active || {}).length > 0) {
      const activeAnomalies = Object.entries(anomalyPattern.active || {})
        .map(([metric, info]) => {
          const runsSince = info.consecutiveRuns || '?';
          const startDate = info.startedAt ? info.startedAt.slice(0, 10) : 'recent';
          return `${metric} (deteriorating since ${startDate}, ${runsSince} consecutive runs)`;
        });
      context += `\nPersistent anomalies requiring escalating language: ${activeAnomalies.join('; ')}.`;
    }

    return context;
  }

  recordFeedback(input = {}) {
    const message = normalizeText(input.message);
    if (!message) throw new Error('Feedback message is required');
    const area = normalizeText(input.area || 'general', 80).toLowerCase();
    const memory = this.read();
    const entry = {
      id: stableId('fb', `${Date.now()}-${message}`),
      createdAt: nowIso(),
      runId: normalizeText(input.runId || '', 80) || null,
      area,
      message,
      active: input.active !== false,
    };
    memory.feedback = [...(memory.feedback || []), entry].slice(-this.limits.feedback);
    this.write(memory);
    return entry;
  }

  learnFromRun(input = {}) {
    const memory = this.read();
    const at = input.completedAt || nowIso();
    const runId = normalizeText(input.runId || input.id || `${input.dateFrom}_${input.dateTo}_${Date.now()}`, 120);
    const learnedThisRun = [];
    const addLearning = (type, text, evidence = {}) => {
      const clean = normalizeText(text, 260);
      if (!clean || learnedThisRun.some(item => item.text === clean)) return;
      const entry = { id: stableId('learn', `${runId}-${type}-${clean}`), runId, at, type, text: clean, evidence };
      learnedThisRun.push(entry);
      memory.learnings.push(entry);
    };

    for (const source of input.sourceEvidence || []) {
      const id = normalizeText(source.id || source.agent || source.name, 80);
      if (!id) continue;
      const count = rowCount(source);
      const status = normalizeText(source.status || 'unknown', 40);
      const previous = memory.sourceStats[id];
      const previousStatus = previous?.lastStatus;
      const previousCount = previous?.lastCount;
      const stats = previous || { id, name: source.name || id, runs: 0, live: 0, cached: 0, failed: 0, missing: 0, skipped: 0, empty: 0, totalRows: 0 };
      stats.runs += 1;
      stats[status] = (stats[status] || 0) + 1;
      stats.totalRows += count;
      stats.avgRows = Math.round(stats.totalRows / stats.runs);
      stats.lastStatus = status;
      stats.lastCount = count;
      stats.lastRunId = runId;
      stats.lastFetchedAt = source.fetchedAt || at;
      memory.sourceStats[id] = stats;

      if (!previous) addLearning('source-baseline', `${source.name || id} baseline established: ${status} with ${count} rows.`, { source: id, count, status });
      else if (previousStatus && previousStatus !== status) addLearning('source-status', `${source.name || id} changed from ${previousStatus} to ${status}.`, { source: id, previous: previousStatus, status });
      else if (previousCount && count && Math.abs(count - previousCount) / Math.max(previousCount, 1) >= 0.25) {
        addLearning('volume-shift', `${source.name || id} volume shifted from ${previousCount} to ${count} rows.`, { source: id, previous: previousCount, count });
      }
      if (stats.runs >= 3 && ((stats.failed || 0) + (stats.missing || 0)) / stats.runs >= 0.34) {
        addLearning('source-risk', `${source.name || id} is becoming unreliable across recent runs.`, { source: id, failures: (stats.failed || 0) + (stats.missing || 0), runs: stats.runs });
      }
    }

    const hermes = input.analysis?.hermes || input.analysis || {};
    const recommendations = [...(hermes.recommendations || []), ...(input.analysis?.actions || [])]
      .map(summarizeRecommendation)
      .filter(Boolean)
      .slice(0, 12);
    for (const text of recommendations) {
      const key = stableId('rec', text.toLowerCase());
      const stat = memory.recommendationStats[key] || { id: key, text, seen: 0, firstRunId: runId };
      stat.seen += 1;
      stat.lastRunId = runId;
      stat.lastSeenAt = at;
      memory.recommendationStats[key] = stat;
      if (stat.seen >= 2) addLearning('recurring-recommendation', `Recurring recommendation seen ${stat.seen} times: ${text}`, { recommendationId: key, seen: stat.seen });
    }

    // ── Co-failure pattern detection ────────────────────────────────────────────
    // When ≥2 sources fail in the same run, record as a co-failure event.
    // Repeated co-failures signal systemic auth/infra issues, not isolated blips.
    const failedThisRun = (input.sourceEvidence || [])
      .filter(s => ['failed', 'missing'].includes(normalizeText(s.status || '', 40)))
      .map(s => normalizeText(s.id || s.name || '', 80));

    if (failedThisRun.length >= 2) {
      const coKey = 'co-failure-patterns';
      const existing = (memory.patterns || []).find(p => p.key === coKey) || {
        key: coKey, type: 'co-failure', events: [], runs: 0,
      };
      existing.runs += 1;
      existing.events = [...(existing.events || []), {
        runId, at, sources: failedThisRun,
      }].slice(-12);  // keep last 12 co-failure events
      const patterns = (memory.patterns || []).filter(p => p.key !== coKey);
      memory.patterns = [...patterns, existing];
      addLearning('co-failure', `${failedThisRun.length} sources failed together: ${failedThisRun.slice(0, 4).join(', ')}${failedThisRun.length > 4 ? '…' : ''}`, { sources: failedThisRun, runId });
    }

    // ── Persona effectiveness tracking ───────────────────────────────────────
    // Track which deckMode was used per run; used to advise on persona adoption.
    const personaKey = 'persona-usage';
    const deckMode   = normalizeText(input.deckMode || 'ops', 40);
    const existingPersona = (memory.patterns || []).find(p => p.key === personaKey) || {
      key: personaKey, type: 'persona', counts: {}, runs: 0,
    };
    existingPersona.runs += 1;
    existingPersona.counts[deckMode] = (existingPersona.counts[deckMode] || 0) + 1;
    const personaPatterns = (memory.patterns || []).filter(p => p.key !== personaKey);
    memory.patterns = [...personaPatterns, existingPersona];

    // ── Anomaly persistence ───────────────────────────────────────────────
    // Record when a metric starts/stops deteriorating so future prompts
    // can say "deteriorating since [date]" with escalating severity.
    const ANOMALY_METRICS = ['healthScore', 'velocity', 'itsmOpen', 'mprOpen', 'cloudPending', 'oegTotal', 'wsrIncTotal'];
    const ANOMALY_BAD_DIRECTION = new Set(['itsmOpen', 'mprOpen', 'cloudPending', 'oegTotal', 'wsrIncTotal']);
    const recentSnaps = (memory.weeklySnapshots || []).slice(-4);

    if (recentSnaps.length >= 2) {
      const anomalyKey = 'anomaly-tracking';
      const existingAnomaly = (memory.patterns || []).find(p => p.key === anomalyKey) || {
        key: anomalyKey, type: 'anomaly', active: {}, resolved: [],
      };

      for (const metricKey of ANOMALY_METRICS) {
        let declines = 0;
        for (let i = recentSnaps.length - 1; i >= 1; i--) {
          const prev = recentSnaps[i - 1][metricKey];
          const curr = recentSnaps[i][metricKey];
          if (prev == null || curr == null) break;
          const bad = ANOMALY_BAD_DIRECTION.has(metricKey) ? curr > prev : curr < prev;
          if (bad) declines++;
          else break;
        }

        if (declines >= 2 && !existingAnomaly.active[metricKey]) {
          existingAnomaly.active[metricKey] = {
            startedAt: recentSnaps[recentSnaps.length - 2].at,
            consecutiveRuns: declines,
          };
        } else if (declines >= 2 && existingAnomaly.active[metricKey]) {
          existingAnomaly.active[metricKey].consecutiveRuns = declines;
        } else if (declines < 2 && existingAnomaly.active[metricKey]) {
          existingAnomaly.resolved = [
            ...(existingAnomaly.resolved || []),
            { ...existingAnomaly.active[metricKey], resolvedAt: at, metric: metricKey },
          ].slice(-20);
          delete existingAnomaly.active[metricKey];
        }
      }

      memory.patterns = [
        ...(memory.patterns || []).filter(p => p.key !== anomalyKey),
        existingAnomaly,
      ];
    }

    // ── Editorial outcome learning ────────────────────────────────────────────
    // Track which slides consistently need Hermes editorial intervention
    // so future prompts can prioritise editorial attention on weak slides.
    if (input.editorialGrade) {
      const grade   = input.editorialGrade;
      const editKey = 'editorial-outcomes';
      const existing = (memory.patterns || []).find(p => p.key === editKey) || {
        key: editKey, type: 'editorial', weakSlides: {}, hermesCoverage: [], runs: 0,
      };

      // Accumulate weak slide frequency
      (grade.weakSlides || []).forEach(slide => {
        existing.weakSlides[slide] = (existing.weakSlides[slide] || 0) + 1;
      });

      // Track Hermes coverage rate over time
      existing.hermesCoverage = [
        ...(existing.hermesCoverage || []).slice(-12),
        { runId, score: grade.score || 0, passCount: grade.passCount || 0 },
      ];

      existing.runs = (existing.runs || 0) + 1;
      existing.lastUpdated = new Date().toISOString();

      // Replace or add
      memory.patterns = [
        ...(memory.patterns || []).filter(p => p.key !== editKey),
        existing,
      ];
    }

    if (!learnedThisRun.length) {
      addLearning('baseline-refresh', `No new durable pattern detected; refreshed memory for ${input.dateFrom || 'range'} to ${input.dateTo || 'range'}.`, {});
    }

    const run = {
      id: runId,
      dateFrom: input.dateFrom || null,
      dateTo: input.dateTo || null,
      completedAt: at,
      hermesMode: Boolean(input.hermesMode),
      sourceCount: (input.sourceEvidence || []).length,
      learnedCount: learnedThisRun.length,
      learnedThisRun: learnedThisRun.slice(0, 8),
      feedbackApplied: (memory.feedback || []).filter(f => f.active !== false).slice(-6),
    };

    memory.runCount = (memory.runCount || 0) + 1;
    memory.latestRun = run;
    memory.runs = [run, ...(memory.runs || []).filter(r => r.id !== runId)].slice(0, this.limits.runs);
    memory.learnings = (memory.learnings || []).slice(-this.limits.learnings);

    // ── Weekly snapshot for temporal trend analysis ───────────────────────────
    // Keep rolling 8 snapshots (~2 months). Each snapshot is a lean KPI object.
    const snap = {
      runId,
      at,
      healthScore: input.analysis?.healthScore ?? input.analysis?.hermes?.hygiene?.score ?? null,
      velocity:    input.analysis?.velocity    ?? null,
      itsmOpen:    input.analysis?.itsmOpen    ?? null,
      mprOpen:     input.analysis?.mprOpen     ?? null,
      cloudPending: input.analysis?.cloudPending ?? null,
      oegTotal:     input.analysis?.oegTotal     ?? null,
      wsrIncTotal:  input.analysis?.wsrIncTotal   ?? null,
      editScore:   input.editorialGrade?.score ?? null,
      hermesMode:  input.hermesMode            ?? false,
    };
    memory.weeklySnapshots = [...(memory.weeklySnapshots || []), snap].slice(-8);

    this.write(memory);
    return { memoryPath: this.filePath, ...run };
  }

  summary(limit = 10) {
    const memory = this.read();
    return {
      memoryPath: this.filePath,
      runCount: memory.runCount || 0,
      latestRun: memory.latestRun || null,
      recentRuns: (memory.runs || []).slice(0, limit),
      recentLearnings: (memory.learnings || []).slice(-limit).reverse(),
      feedback: (memory.feedback || []).slice(-limit).reverse(),
      sourceStats: Object.values(memory.sourceStats || {}),
    };
  }
}

module.exports = { HermesMemory };
