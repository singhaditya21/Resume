# ============================================================
# RMG Bot — LLM Server Startup Script
# ============================================================
# Requirements:
#   1. Python 3.10+
#   2. Run: pip install -r requirements_llm.txt
#   3. Download model (see instructions below) and place it in:
#        /opt/portfolio/project
# ============================================================

$ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModelDir   = Join-Path $ScriptDir "models"
$ModelFile  = Join-Path $ModelDir "qwen2.5-7b-instruct-q4_k_m.gguf"
$DataJson   = Join-Path $ScriptDir "training_data.json"
$ServerFile = Join-Path $ScriptDir "llm_server.py"

Write-Host ""
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "  RMG Bot — LLM Server (llama.cpp + Qwen 7B GGUF)" -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host ""

# ── Check Python ─────────────────────────────────────────────
try {
    $pyVersion = python --version 2>&1
    Write-Host "✅ Python: $pyVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Python not found. Please install Python 3.10+ from https://example.invalid" -ForegroundColor Red
    pause; exit 1
}

# ── Check llama-cpp-python ───────────────────────────────────
$llamaCheck = python -c "import llama_cpp; print('ok')" 2>&1
if ($llamaCheck -ne "ok") {
    Write-Host ""
    Write-Host "📦 Installing required packages (this may take a while)..." -ForegroundColor Yellow
    pip install -r "$ScriptDir\requirements_llm.txt"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Package installation failed." -ForegroundColor Red
        pause; exit 1
    }
    Write-Host "✅ Packages installed." -ForegroundColor Green
} else {
    Write-Host "✅ llama-cpp-python: installed" -ForegroundColor Green
}

# ── Check Model File & Dependencies ──────────────────────────
$UseLite = $false
Write-Host ""
if (-not (Test-Path $ModelFile)) {
    Write-Host "⚠️  Model file NOT found at: $ModelFile" -ForegroundColor Yellow
    $UseLite = $true
}

$llamaCheck = python -c "import llama_cpp; print('ok')" 2>&1
if ($llamaCheck -ne "ok") {
    Write-Host "⚠️  llama-cpp-python NOT installed (missing build tools)." -ForegroundColor Yellow
    $UseLite = $true
}

if ($UseLite) {
    Write-Host "🚀 Entering LITE AI MODE (No GGUF or Build Tools required)..." -ForegroundColor Cyan
    Write-Host "   This provides analytical responses using pre-computed ground truth." -ForegroundColor White
    python "$ScriptDir\lite_llm_server.py"
} else {
    Write-Host "🚀 Starting FULL LLM Server (llama.cpp + Qwen 7B)..." -ForegroundColor Cyan
    python "$ServerFile"
}
