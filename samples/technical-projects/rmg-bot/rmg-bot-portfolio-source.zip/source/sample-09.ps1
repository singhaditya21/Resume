# start_rag_server.ps1
# Starts the RMG RAG AI Server using Python 3.13 (LangChain + FAISS)
# Usage: .\start_rag_server.ps1

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  RMG Bot — RAG AI Server" -ForegroundColor Cyan
Write-Host "  LangChain + FAISS + Qwen2.5-7B" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

Set-Location $PSScriptRoot

# Kill any existing server
$existing = Get-Process -Name "python*" -ErrorAction SilentlyContinue
if ($existing) {
    $existing | Stop-Process -Force
    Write-Host "Stopped existing Python processes." -ForegroundColor Yellow
}
Start-Sleep -Seconds 1

# Start RAG Server using Python 3.13
Write-Host "Starting RAG Server on http://127.0.0.1:8080 ..." -ForegroundColor Green
Start-Process -FilePath "py" -ArgumentList "-3.13 rag_server.py" -NoNewWindow

Start-Sleep -Seconds 3
Write-Host "Server is starting. Open http://127.0.0.1:3000/RMGBot.html to access the bot." -ForegroundColor Green

# Also start the web server for the HTML frontend
Start-Process -FilePath "py" -ArgumentList "-3.13 -m http.server 3000 --bind 127.0.0.1" -NoNewWindow
Write-Host "Web Server running at http://127.0.0.1:3000" -ForegroundColor Green
