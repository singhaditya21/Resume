import os
import json
import time
import logging
from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import subprocess
import requests
from pydantic import BaseModel

from langchain_community.document_loaders import CSVLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate

# --- Logging ---
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("rag-server")

# --- Configuration ---
BASE_DIR = Path(__file__).parent
CSV_FILE = str(BASE_DIR / "project allocation Data.csv")
INDEX_PATH = str(BASE_DIR / "faiss_index")
MODEL_PATH = str(BASE_DIR / "models" / "qwen2.5-1.5b-instruct-q4_k_m.gguf")
LLAMA_SERVER_EXE = str(BASE_DIR / "llama-cpp" / "llama-server.exe")
LLM_URL = "http://127.0.0.1:8082/v1"

# llama-cpp settings
N_CTX = 4096
N_THREADS = max(4, os.cpu_count() or 4)
GPU_LAYERS = 0 # CPU only

# Lightweight local embeddings
EMBEDDINGS = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

app = FastAPI(title="RMG RAG AI Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class QueryRequest(BaseModel):
    prompt: str
    max_tokens: Optional[int] = 512
    temperature: Optional[float] = 0.3

# --- Global State ---
llm = None
vectorstore = None
last_csv_mtime = 0

def download_model():
    if os.path.exists(MODEL_PATH):
        return True
    
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    url = "https://example.invalid"
    log.info(f"Downloading model from {url}...")
    try:
        import urllib.request
        def report(block, size, total):
            if block % 1000 == 0:
                percent = (block * size * 100) / total
                log.info(f"Download: {percent:.1f}%")
        urllib.request.urlretrieve(url, MODEL_PATH, reporthook=report)
        log.info("Download complete.")
        return True
    except Exception as e:
        log.error(f"Download failed: {e}")
        return False

llm_process = None

def load_llm():
    global llm_process
    if not download_model():
        return

    if not os.path.exists(LLAMA_SERVER_EXE):
        log.error(f"llama-server.exe not found at {LLAMA_SERVER_EXE}")
        return

    log.info(f"Starting standalone llama-server with {MODEL_PATH}...")
    cmd = [
        LLAMA_SERVER_EXE,
        "-m", MODEL_PATH,
        "-c", str(N_CTX),
        "-t", str(N_THREADS),
        "--port", "8082",
        "-ngl", str(GPU_LAYERS)
    ]
    
    try:
        llm_process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )
        
        # Wait for server to be ready
        max_retries = 30
        for i in range(max_retries):
            try:
                resp = requests.get("http://127.0.0.1:8082/health", timeout=1)
                if resp.status_code == 200:
                    log.info("Standalone LLM server is ready.")
                    return
            except:
                pass
            time.sleep(1)
        log.error("Timed out waiting for LLM server.")
    except Exception as e:
        log.error(f"Failed to start LLM server: {e}")

def index_data():
    global vectorstore, last_csv_mtime
    if not os.path.exists(CSV_FILE):
        log.error(f"CSV file not found: {CSV_FILE}")
        return

    # Check if we should re-index
    mtime = os.path.getmtime(CSV_FILE)
    
    # 1. Try loading existing index if available and CSV hasn't changed
    if os.path.exists(os.path.join(INDEX_PATH, "index.faiss")):
        try:
            if not vectorstore or mtime > last_csv_mtime:
                log.info(f"Loading existing FAISS index from {INDEX_PATH}...")
                vectorstore = FAISS.load_local(INDEX_PATH, EMBEDDINGS, allow_dangerous_deserialization=True)
                last_csv_mtime = mtime
                log.info("Index loaded successfully.")
                return
        except Exception as e:
            log.warning(f"Failed to load local index: {e}. Re-indexing...")

    # 2. Re-index if needed
    if vectorstore and mtime <= last_csv_mtime:
        return

    log.info(f"Indexing RAG data from {CSV_FILE} (This may take a minute)...")
    loader = CSVLoader(file_path=CSV_FILE, encoding="utf-8-sig")
    documents = loader.load()
    log.info(f"Loaded {len(documents)} rows from CSV.")

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=50)
    chunks = text_splitter.split_documents(documents)
    log.info(f"Created {len(chunks)} chunks.")

    vectorstore = FAISS.from_documents(chunks, EMBEDDINGS)
    vectorstore.save_local(INDEX_PATH)
    last_csv_mtime = mtime
    log.info("Indexing complete.")

# --- RAG Prompt Template ---
RAG_PROMPT_TEMPLATE = """<|im_start|>system
You are the RMG AI Analyst. Answer the question using ONLY the provided context.
If the information is not in the context, say "Data not available in RMG dataset."
Format responses clearly with tables or bullet points for lists.

Context:
{context}<|im_end|>
<|im_start|>user
{question}<|im_end|>
<|im_start|>assistant
"""

# --- API Endpoints ---

@app.on_event("startup")
async def startup():
    index_data()
    load_llm()

@app.get("/health")
def health():
    return {
        "status": "ok",
        "llm_server": "online" if llm_process and llm_process.poll() is None else "offline",
        "index_ready": vectorstore is not None,
        "csv_file": CSV_FILE
    }

@app.post("/completion")
@app.post("/v1/completions")
async def completion(request: QueryRequest):
    # Check for data updates
    index_data()

    t0 = time.time()
    
    # 1. Retrieval
    retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
    docs = retriever.invoke(request.prompt)
    context_text = "\n\n".join([d.page_content for d in docs])

    # 2. Prompt Construction
    prompt = RAG_PROMPT_TEMPLATE.format(context=context_text, question=request.prompt)

    # 3. Generation
    # Try using the standalone server
    try:
        payload = {
            "model": "qwen",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "stop": ["<|im_end|>"]
        }
        resp = requests.post(f"{LLM_URL}/chat/completions", json=payload, timeout=120)
        if resp.status_code == 200:
            response_text = resp.json()["choices"][0]["message"]["content"].strip()
        else:
            raise Exception(f"LLM server error: {resp.text}")
    except Exception as e:
        log.error(f"Generation error: {e}")
        # LLM not available - Return the retrieved context for demonstration
        response_text = (
            "⚠️ **Local AI Generation Failed**.\n\n"
            "The RAG Retrieval Pipeline is working, but the local LLM encountered an error. "
            "Here is the context it found for your quer/opt/portfolio/project"
            "```text\n"
            f"{context_text}\n"
            "```"
        )

    elapsed_ms = int((time.time() - t0) * 1000)

    return {
        "content": response_text,
        "elapsed_ms": elapsed_ms,
        "model": "Qwen2.5-7B-RAG",
        "choices": [{"text": response_text}] # OpenAI compatibility
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
