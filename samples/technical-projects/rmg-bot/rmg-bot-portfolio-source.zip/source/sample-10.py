import os
import subprocess
import time
from datetime import datetime

# Git Configuration
REPO_PATH = os.path.dirname(os.path.abspath(__file__))
REMOTE = "origin"
BRANCH = "master"
POLL_INTERVAL = 30  # seconds
DEBOUNCE_TIME = 5   # seconds

def run_git(args):
    try:
        result = subprocess.run(["git"] + args, cwd=REPO_PATH, capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error running git {' '.join(args)}: {e.stderr}")
        return None

def get_last_modified():
    max_mtime = 0
    for root, dirs, files in os.walk(REPO_PATH):
        if ".git" in dirs:
            dirs.remove(".git")
        for f in files:
            path = os.path.join(root, f)
            try:
                mtime = os.path.getmtime(path)
                if mtime > max_mtime:
                    max_mtime = mtime
            except OSError:
                continue
    return max_mtime

def auto_push():
    print(f"Starting auto-push monitor in {REPO_PATH}...")
    print(f"Monitoring every {POLL_INTERVAL} seconds.")
    
    last_check_mtime = get_last_modified()
    
    while True:
        current_mtime = get_last_modified()
        
        if current_mtime > last_check_mtime:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Changes detected. Waiting {DEBOUNCE_TIME}s for stability...")
            time.sleep(DEBOUNCE_TIME)
            
            # Re-check to ensure no new changes happened during debounce
            new_mtime = get_last_modified()
            if new_mtime > current_mtime:
                current_mtime = new_mtime
                continue

            print(f"[{datetime.now().strftime('%H:%M:%S')}] Committing and pushing changes...")
            
            # Check if there are actual changes in git
            status = run_git(["status", "--porcelain"])
            if status:
                run_git(["add", "-A"])
                commit_msg = f"Auto-commit: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                run_git(["commit", "-m", commit_msg])
                
                push_res = run_git(["push", REMOTE, BRANCH])
                if push_res is not None:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Successfully pushed to {REMOTE}/{BRANCH}")
                else:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Push failed. Will retry later.")
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] No changes to commit (mtime changed but git status clean).")
            
            last_check_mtime = current_mtime
            
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    try:
        auto_push()
    except KeyboardInterrupt:
        print("\nAuto-push monitor stopped.")
