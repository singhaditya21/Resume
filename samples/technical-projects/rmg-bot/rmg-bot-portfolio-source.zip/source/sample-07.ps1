# Start a simple static web server on port 3000
Write-Host "--- Starting RMG Bot Web Server ---"
Write-Host "URL: http://localhost:3000/RMGBot.html"
Write-Host "Press Ctrl+C to stop."
python -m http.server 3000 --bind 127.0.0.1
