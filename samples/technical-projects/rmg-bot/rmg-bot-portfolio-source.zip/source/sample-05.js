// Project names are now read directly from the CSV (projectname column)

let currentRole = 'RM';
let csvData = [];
let projects = {};
let employees = {};
let trainingData = null; // Loaded from training_data.json
let currentSection = 'assistant';
let dashboardPersona = 'RM'; // RM, PM, DH

// Proper RFC-4180 CSV parser — handles quoted fields with commas inside
function parseCSVLine(line) {
  const fields = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        // Peek ahead for escaped double-quote ("")
        if (line[i + 1] === '"') { cur += '"'; i++; }
        else { inQuotes = false; }
      } else { cur += ch; }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === ',') { fields.push(cur.trim()); cur = ''; }
      else { cur += ch; }
    }
  }
  fields.push(cur.trim());
  return fields;
}

// Parse CSV on load
async function loadData() {

  try {
    const resp = await fetch('project allocation Data.csv');
    const text = await resp.text();
    // Split on lines — handle both \r\n and \n
    const lines = text.trim().split(/\r?\n/);
    const headers = parseCSVLine(lines[0]);
    csvData = [];
    for (let i = 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      const vals = parseCSVLine(lines[i]);
      if (vals.length < headers.length) continue;
      const row = {};
      headers.forEach((h, idx) => row[h] = vals[idx] ?? '');
      csvData.push(row);
    }
    processData();
    showWelcome();
    updateContextPanel();

    // Also try to load the pre-computed training data for LLM context
    try {
      const tResp = await fetch('training_data.json');
      if (tResp.ok) trainingData = await tResp.json();
    } catch (_) { console.log("training_data.json not found yet"); }

  } catch (e) {
    console.error("Data Load Error:", e);
  }
  
  checkLLMConnection();
  setInterval(checkLLMConnection, 30000); // Check every 30s
}


function parseDate(s) {
  if (!s) return null;
  // Handle DD-MM-YYYY format from CSV
  const parts = s.split(' ')[0].split(/[-/]/);
  if (parts.length < 3) return null;
  // Note: Date(year, monthIndex, day)
  return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
}

function processData() {
  projects = {};
  employees = {};
  const today = new Date();

  csvData.forEach(row => {
    const pid = row.projectid;
    const eid = row.employeeid;
    const ename = row.employeename;
    let allocPct = parseInt(row.alloc_percentage);
    const dayEffort = parseInt(row.dayeffort) || 0;
    // If percentage is 0 but there is effort, calculate it (480 mins = 100%)
    if ((isNaN(allocPct) || allocPct === 0) && dayEffort > 0) {
      allocPct = Math.round((dayEffort / 480) * 100);
    } else {
      allocPct = allocPct || 0;
    }
    const allocFrom = parseDate(row.allocatedfrom);
    const allocTo = parseDate(row.allocatedto);
    const projStart = parseDate(row.projectstartdate);
    const projEnd = parseDate(row.projectenddate);
    const effort = parseInt(row.totaleffort) || 0;
    const workdays = parseInt(row.workdays) || 0;
    // Read project name directly from CSV — with fallback to ID
    const csvProjName = (row.projectname || '').trim() || `Project ${pid}`;

    // Build project map
    if (!projects[pid]) {
      projects[pid] = { id: pid, name: csvProjName, employees: new Map(), allocations: [], startDate: projStart, endDate: projEnd, totalEffort: 0, totalWorkdays: 0 };
    } else if (projects[pid].name === `Project ${pid}` && csvProjName !== `Project ${pid}`) {
      // Update name if we previously only had the fallback
      projects[pid].name = csvProjName;
    }
    projects[pid].employees.set(eid, ename);
    projects[pid].allocations.push({ employeeid: eid, employeename: ename, from: allocFrom, to: allocTo, pct: allocPct, effort, workdays });
    projects[pid].totalEffort += effort;
    projects[pid].totalWorkdays += workdays;
    if (projStart && (!projects[pid].startDate || projStart < projects[pid].startDate)) projects[pid].startDate = projStart;
    if (projEnd && (!projects[pid].endDate || projEnd > projects[pid].endDate)) projects[pid].endDate = projEnd;

    // Build employee map
    if (!employees[eid]) { employees[eid] = { id: eid, name: ename, projects: new Set(), allocations: [] }; }
    employees[eid].projects.add(pid);
    employees[eid].allocations.push({ projectid: pid, from: allocFrom, to: allocTo, pct: allocPct, effort, workdays });
  });

  // Determine project status
  Object.values(projects).forEach(p => {
    const now = today;
    if (p.startDate && p.endDate) {
      if (now < p.startDate) p.status = 'Upcoming';
      else if (now > p.endDate) p.status = 'Completed';
      else p.status = 'Active';
    } else p.status = 'Unknown';
    p.teamSize = p.employees.size;
    p.allocCount = p.allocations.length;
  });
}

// ── Analytics Functions ─────────────────────────────────────────
function getKPIs() {

  const today = new Date();
  const projArr = Object.values(projects);
  const active = projArr.filter(p => p.status === 'Active');
  const upcoming = projArr.filter(p => p.status === 'Upcoming');
  const completed = projArr.filter(p => p.status === 'Completed');
  const uniqueEmps = Object.keys(employees).length;

  let allocatedCount = 0;
  Object.values(employees).forEach(emp => {
    const isAllocated = emp.allocations.some(a => a.from && a.to && a.from <= today && today <= a.to && a.pct > 0);
    if (isAllocated) allocatedCount++;
  });

  const benchEmp = uniqueEmps - allocatedCount;
  const util = uniqueEmps > 0 ? Math.round((allocatedCount / uniqueEmps) * 100) : 0;

  return {
    totalProjects: projArr.length,
    activeProjects: active.length,
    upcomingProjects: upcoming.length,
    completedProjects: completed.length,
    totalEmployees: uniqueEmps,
    allocatedEmployees: allocatedCount,
    benchEmployees: benchEmp,
    utilizationRate: util + '%',
    totalRecords: csvData.length
  };
}

// ── Phase 4: Competitive Analytics ──────────────────────────────
function getAdvancedAnalytics() {
    const today = new Date();
    let totalLeakageMins = 0;
    const roleStats = {}; // To find role saturation
    
    Object.values(employees).forEach(emp => {
        // 1. Revenue Leakage: Non-billable resources who are 100% available
        const isAllocated = emp.allocations.some(a => a.from && a.to && a.from <= today && today <= a.to && a.pct > 0);
        if (!isAllocated) {
            // Assume 480 mins per day as leakage
            totalLeakageMins += 480;
        }

        // 2. Role Saturation (proxy for skills)
        emp.allocations.forEach(a => {
            const row = csvData.find(r => r.employeeid === emp.id);
            const role = row ? row.engagementrole : 'Unknown';
            if (!roleStats[role]) roleStats[role] = { total: 0, allocated: 0 };
            roleStats[role].total++;
            if (a.pct > 0 && a.from <= today && today <= a.to) {
                roleStats[role].allocated++;
            }
        });
    });

    const saturationLevels = Object.entries(roleStats).map(([role, stats]) => ({
        role,
        level: Math.round((stats.allocated / stats.total) * 100)
    })).sort((a, b) => b.level - a.level);

    return {
        revenueLeakageMins: totalLeakageMins,
        leakageImpact: (totalLeakageMins / (Object.keys(employees).length * 480) * 100).toFixed(1) + '%',
        saturationLevels
    };
}

function getDailyStandup() {
    const today = new Date();
    const imminentRollOffs = [];
    const recentChanges = []; // Simulated for now since CSV is static
    
    Object.values(projects).forEach(p => {
        if (p.status === 'Active' && p.endDate) {
            const diff = (p.endDate - today) / (1000 * 60 * 60 * 24);
            if (diff >= 0 && diff <= 7) {
                imminentRollOffs.push({ name: p.name, days: Math.ceil(diff) });
            }
        }
    });

    return {
        rollOffs: imminentRollOffs.slice(0, 5),
        alerts: imminentRollOffs.length > 3 ? 'Critical staffing attention required' : 'Stable delivery outlook'
    };
}

function getDataHealth() {
    const headers = csvData.length > 0 ? Object.keys(csvData[0]) : [];
    const criticalHeaders = ['employeeid', 'projectid', 'allocatedfrom', 'allocatedto', 'alloc_percentage'];
    let missingCount = 0;
    
    csvData.forEach(row => {
        criticalHeaders.forEach(h => {
            if (!row[h] || row[h] === '0' || row[h] === '') missingCount++;
        });
    });

    const totalCells = csvData.length * criticalHeaders.length;
    const healthScore = totalCells > 0 ? Math.round(((totalCells - missingCount) / totalCells) * 100) : 0;
    
    return {
        score: healthScore,
        label: healthScore > 90 ? 'Healthy' : healthScore > 70 ? 'Needs Attention' : 'Critical'
    };
}

function getTopProjects(n = 10) {
  return Object.values(projects).sort((a, b) => b.teamSize - a.teamSize).slice(0, n);
}

function getActiveProjects() {
  return Object.values(projects).filter(p => p.status === 'Active').sort((a, b) => b.teamSize - a.teamSize);
}

function getUpcomingProjects() {
  return Object.values(projects).filter(p => p.status === 'Upcoming').sort((a, b) => (a.startDate || 0) - (b.startDate || 0));
}

// ── Premium Risk Registry Logic ──────────────────────────────
function getRiskAlerts() {
  const alerts = [];
  const today = new Date();
  const twoWeeksOut = new Date();
  twoWeeksOut.setDate(today.getDate() + 14);

  // 1. Over-allocated Resources
  Object.values(employees).forEach(emp => {
    const totalPct = emp.allocations
      .filter(a => a.from && a.to && a.from <= today && today <= a.to)
      .reduce((sum, a) => sum + (a.pct || 0), 0);
    if (totalPct > 100) {
      alerts.push({ type: 'danger', icon: '⚠️', title: 'Over-allocated', msg: `${emp.name} is at ${totalPct}% capacity.` });
    }
  });

  // 2. Critical Roll-offs (Ending in < 2 weeks)
  Object.values(projects).forEach(p => {
    if (p.status === 'Active' && p.endDate && p.endDate <= twoWeeksOut) {
      alerts.push({ type: 'warning', icon: '⌛', title: 'Project Ending', msg: `${p.name} ends on ${fmtDate(p.endDate)}.` });
    }
  });

  return alerts.slice(0, 5);
}

function fmtDate(d) {
  if (!d) return 'N/A';
  if (typeof d === 'string') return d;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function getEmployeesOnBench(startDate, endDate) {
  const checkStart = startDate || new Date();
  const checkEnd = endDate || checkStart;
  return Object.values(employees).filter(emp => {
    // Return true if they have NO allocation overlapping the period
    return !emp.allocations.some(a => a.from && a.to && a.from <= checkEnd && a.to >= checkStart && a.pct > 0);
  });
}

// ── Bot Response Engine ──────────────────────────────────────────
function getBotResponse(input) {
  const q = input.toLowerCase().trim();
  const kpi = getKPIs();

  // Greetings
  if (/^(hi|hello|hey|good morning|good afternoon)\b/.test(q)) {
    return {
      text: `Hello! 👋 I'm your <strong>Project Allocation Assistant</strong>.<br><br>📊 <strong>Live Stats:</strong><div class="data-card"><div class="dc-row"><span class="dc-label">Active Projects</span><span class="dc-value">${kpi.activeProjects}</span></div><div class="dc-row"><span class="dc-label">Employees</span><span class="dc-value">${kpi.totalEmployees}</span></div><div class="dc-row"><span class="dc-label">Utilization</span><span class="dc-value">${kpi.utilizationRate}</span></div></div>What can I help you find today?`,
      quick: ['Dashboard Summary', 'Who is on bench?', 'Active Projects', 'Low Allocation List']
    };
  }

  // Logical Queries: "less than X%", "more than X%", "in Month Year"
  const pctMatch = q.match(/(less|below|under|more|above|greater|equal)\s+(than\s+)?(\d+)/i);
  const dateMatch = q.match(/(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+(\d{4})/i);

  if (pctMatch) {
    const op = pctMatch[1];
    const val = parseInt(pctMatch[3]);
    let filtered = Object.values(employees).filter(emp => {
      const maxAlloc = Math.max(0, ...emp.allocations.map(a => a.pct));
      if (op.match(/less|below|under/)) return maxAlloc < val;
      if (op.match(/more|above|greater/)) return maxAlloc > val;
      return maxAlloc === val;
    });

    if (dateMatch) {
      const month = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].indexOf(dateMatch[1].toLowerCase());
      const year = parseInt(dateMatch[2]);
      filtered = filtered.filter(emp => {
        return emp.allocations.some(a => {
          if (!a.from || !a.to) return false;
          const filterStart = new Date(year, month, 1);
          const filterEnd = new Date(year, month + 1, 0);
          return (a.from <= filterEnd && a.to >= filterStart);
        });
      });
    }

    if (filtered.length > 0) {
      const rows = filtered.slice(0, 15).map(e => `<li><strong>${e.name}</strong> (ID: ${e.id})</li>`).join('');
      const title = `Found ${filtered.length} employees with allocation ${op} ${val}% ${dateMatch ? 'in ' + dateMatch[0] : ''}:`;
      return { text: `🔍 <strong>${title}</strong><ul>${rows}</ul>${filtered.length > 15 ? `<em>...and ${filtered.length - 15} more</em>` : ''}`, quick: ['Dashboard', 'Bench Resources'] };
    }
    return { text: `No employees found matching your criteria.`, quick: ['Dashboard', 'Project List'] };
  }

  // Over-allocated / Under-allocated resources
  if (/(over|under).*alloc/.test(q)) {
    const today = new Date();
    const isOver = /over/.test(q);
    const filtered = Object.values(employees).map(emp => {
      const totalPct = emp.allocations
        .filter(a => a.from && a.to && a.from <= today && today <= a.to)
        .reduce((sum, a) => sum + (a.pct || 0), 0);
      return { ...emp, totalPct };
    }).filter(e => isOver ? e.totalPct > 100 : (e.totalPct > 0 && e.totalPct < 100));

    if (filtered.length > 0) {
      const rows = filtered.slice(0, 15).map(e => `<li><strong>${e.name}</strong> (Total: ${e.totalPct}%)</li>`).join('');
      return {
        text: `⚠️ <strong>${isOver ? 'Over-allocated' : 'Under-allocated'} Resources (${filtered.length}):</strong><ul>${rows}</ul>${filtered.length > 15 ? `<em>...and ${filtered.length - 15} more</em>` : ''}`,
        quick: ['Dashboard', 'Who is on bench?']
      };
    }
    return { text: `✅ No resources are currently ${isOver ? 'over-allocated' : 'under-allocated'}.`, quick: ['Dashboard', 'Active Projects'] };
  }

  // Multi-project employees
  if (/multi.*project|more.*than.*one.*project|shared.*resource/.test(q)) {
    const today = new Date();
    const multi = Object.values(employees).map(e => {
      // Filter project IDs by their end date
      const activeProjectIds = Array.from(e.projects).filter(pid => {
        const p = projects[pid];
        return p && (!p.endDate || p.endDate >= today);
      });
      return { ...e, activeProjectCount: activeProjectIds.length };
    }).filter(e => e.activeProjectCount > 1).sort((a, b) => b.activeProjectCount - a.activeProjectCount);

    const rows = multi.slice(0, 10).map(e => `<li><strong>${e.name}</strong> (${e.activeProjectCount} projects)</li>`).join('');
    return { text: `🤝 <strong>Employees on Multiple Projects (End Date ≥ Today) (${multi.length}):</strong><ul>${rows}</ul>`, quick: ['Dashboard', 'Who is on bench?'] };
  }

  // Utilization Details
  if (/utilization|capacity|usage/.test(q)) {
    return {
      text: `📈 <strong>Utilization Overview:</strong><br><br>The current resource utilization rate is <strong>${kpi.utilizationRate}</strong>.<br>This is calculated based on ${kpi.allocatedEmployees} allocated employees out of a total pool of ${kpi.totalEmployees}.`,
      quick: ['Who is on bench?', 'Dashboard']
    };
  }

  // Dashboard / Summary
  if (/dashboard|summary|kpi|overview|metric|stat/.test(q)) {
    return {
      text: `📊 <strong>Allocation Dashboard:</strong><div class="data-card"><div class="dc-row"><span class="dc-label">Active Projects</span><span class="dc-value">${kpi.activeProjects}</span></div><div class="dc-row"><span class="dc-label">Upcoming Projects</span><span class="dc-value">${kpi.upcomingProjects}</span></div><div class="dc-row"><span class="dc-label">Total Employees</span><span class="dc-value">${kpi.totalEmployees}</span></div><div class="dc-row"><span class="dc-label">Allocated</span><span class="dc-value">${kpi.allocatedEmployees}</span></div><div class="dc-row"><span class="dc-label">On Bench</span><span class="dc-value">${kpi.benchEmployees}</span></div><div class="dc-row"><span class="dc-label">Utilization</span><span class="dc-value">${kpi.utilizationRate}</span></div></div>`,
      quick: ['Active Projects', 'Who is on bench?', 'Top Projects']
    };
  }

  // Bench / Unallocated Resources
  if (/bench|available|free|unassign|not.*alloc|unalloc/.test(q)) {
    let checkStart = new Date();
    let checkEnd = new Date();
    let label = 'Currently';

    const mMatch = q.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+(\d{4})/i);
    if (mMatch) {
      const yr = parseInt(mMatch[2]);
      const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(mMatch[1].toLowerCase().substring(0, 3));
      checkStart = new Date(yr, mIdx, 1);
      checkEnd = new Date(yr, mIdx + 1, 0);
      label = `in ${mMatch[1]} ${yr}`;
    }

    const bench = getEmployeesOnBench(checkStart, checkEnd);
    const rows = bench.slice(0, 15).map(e => `<li>${e.name} (${e.id})</li>`).join('');
    return { text: `👥 <strong>Employees Unallocated ${label} (${bench.length}):</strong><ul>${rows}</ul>${bench.length > 15 ? `<em>...and ${bench.length - 15} more</em>` : ''}`, quick: ['Dashboard', 'Active Projects'] };
  }

  // Allocated in [Month] [Year] (Tabular)
  if (/(\w+)\s+allocated\s+in\s+([a-z]{3})\w*\s+(\d{4})/i.test(q) || (/allocated\s+in\s+([a-z]{3})\w*\s+(\d{4})/i.test(q) && !/bench|unalloc/.test(q))) {
    const mMatch = q.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+(\d{4})/i);
    if (mMatch) {
      const yr = parseInt(mMatch[2]);
      const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(mMatch[1].toLowerCase().substring(0, 3));
      const checkStart = new Date(yr, mIdx, 1);
      const checkEnd = new Date(yr, mIdx + 1, 0);

      const allocated = Object.values(employees).filter(emp => {
        return emp.allocations.some(a => a.from && a.to && a.from <= checkEnd && a.to >= checkStart && a.pct > 0);
      }).sort((a, b) => a.name.localeCompare(b.name));

      if (allocated.length > 0) {
        const rows = allocated.slice(0, 20).map(e => `<tr><td>${e.name}</td><td>${e.id}</td></tr>`).join('');
        return {
          text: `📋 <strong>Employees Allocated in ${mMatch[1]} ${yr} (${allocated.length}):</strong>
          <div class="chat-table-wrapper">
            <table class="chat-table">
              <thead><tr><th>Employee Name</th><th>Employee ID</th></tr></thead>
              <tbody>${rows}</tbody>
            </table>
          </div>${allocated.length > 20 ? `<p><em>Showing first 20 records...</em></p>` : ''}`,
          quick: ['Dashboard', 'Active Projects', 'Show Under-allocated']
        };
      }
      return { text: `No employees found allocated in ${mMatch[1]} ${yr}.`, quick: ['Dashboard', 'Active Projects'] };
    }
  }
  // Top Projects / Largest Project
  if (/top\s+(\d+)\s+active|largest.*project|most.*employees/.test(q)) {
    const isLargest = /largest|most/.test(q);
    const countMatch = q.match(/top\s+(\d+)/);
    const n = isLargest ? 1 : (countMatch ? parseInt(countMatch[1]) : 10);
    const active = getActiveProjects().slice(0, n);
    if (active.length === 0) return { text: "No active projects found.", quick: ['Dashboard'] };
    
    if (isLargest) {
      const p = active[0];
      return { text: `🏆 <strong>Largest Active Project:</strong><br>${p.name} (ID: ${p.id}) with <strong>${p.teamSize}</strong> members.<br>Timeline: ${fmtDate(p.startDate)} - ${fmtDate(p.endDate)}`, quick: ['Show all active', 'Dashboard'] };
    }
    const rows = active.map(p => `<li><strong>${p.name}</strong> (${p.teamSize} members)</li>`).join('');
    return { text: `📁 <strong>Top ${n} Active Projects by Team Size:</strong><ul>${rows}</ul>`, quick: ['Dashboard', 'Project List'] };
  }

  // Upcoming / Completed / Status Lists
  if (/upcoming|not.*start|started.*in\s+(\d{4})|finished|completed|closed/.test(q)) {
    let filtered = [];
    let title = "";
    if (/upcoming|not.*start/.test(q)) {
      filtered = getUpcomingProjects();
      title = "Upcoming / Not Started Projects";
    } else if (/finished|completed|closed/.test(q)) {
      filtered = Object.values(projects).filter(p => p.status === 'Completed');
      title = "Completed Projects";
    }

    if (filtered.length > 0) {
      const rows = filtered.slice(0, 15).map(p => `<li>${p.name} (${fmtDate(p.startDate)})</li>`).join('');
      return { text: `🔮 <strong>${title} (${filtered.length}):</strong><ul>${rows}</ul>${filtered.length > 15 ? '<em>...and more</em>' : ''}`, quick: ['Dashboard', 'Active Projects'] };
    }
    return { text: `No projects found for: ${title}.`, quick: ['Dashboard'] };
  }

  // Total Headcount / Total Employees
  if (/total.*employee|headcount|how.*many.*employee/.test(q)) {
    return { 
      text: `👥 <strong>Headcount Summary:</strong><br>Total workforce consists of <strong>${kpi.totalEmployees}</strong> unique employees.<br>Currently, ${kpi.allocatedEmployees} are allocated (${kpi.utilizationRate}).`,
      quick: ['Who is on bench?', 'Dashboard']
    };
  }

  // Bench specifically for this/next month or quarter
  if (/(this|next)\s+month|this\s+quarter|q[1-4]/.test(q) && /bench|unalloc|available|free/.test(q)) {
    const now = new Date();
    let start = new Date(now.getFullYear(), now.getMonth(), 1);
    let end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    let label = "this month";

    if (/next\s+month/.test(q)) {
      start = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      end = new Date(now.getFullYear(), now.getMonth() + 2, 0);
      label = "next month";
    } else if (/quarter|q[1-4]/.test(q)) {
      let qIdx = Math.floor(now.getMonth() / 3);
      const qMatch = q.match(/q([1-4])/);
      if (qMatch) qIdx = parseInt(qMatch[1]) - 1;
      start = new Date(now.getFullYear(), qIdx * 3, 1);
      end = new Date(now.getFullYear(), (qIdx + 1) * 3, 0);
      label = `Q${qIdx + 1} ${now.getFullYear()}`;
    }

    const bench = getEmployeesOnBench(start, end);
    const rows = bench.slice(0, 12).map(e => `<li>${e.name} (${e.id})</li>`).join('');
    return { text: `👥 <strong>Bench Resources (${label}) (${bench.length}):</strong><ul>${rows}</ul>${bench.length > 12 ? '<em>...and more</em>' : ''}`, quick: ['Dashboard', 'Active Projects'] };
  }

  // All allocations for the current quarter
  if (/allocations?.*(this\s+quarter|q[1-4])/.test(q)) {
    const now = new Date();
    let qIdx = Math.floor(now.getMonth() / 3);
    const qMatch = q.match(/q([1-4])/);
    if (qMatch) qIdx = parseInt(qMatch[1]) - 1;
    const start = new Date(now.getFullYear(), qIdx * 3, 1);
    const end = new Date(now.getFullYear(), (qIdx + 1) * 3, 0);

    const allocated = Object.values(employees).filter(emp => {
      return emp.allocations.some(a => a.from && a.to && a.from <= end && a.to >= start && a.pct > 0);
    });

    return { 
      text: `📋 <strong>Allocations for Q${qIdx + 1} ${now.getFullYear()} (${allocated.length}):</strong><br>Utilization is tracked for this period across ${kpi.totalProjects} projects.`,
      quick: ['Dashboard', 'Who is on bench?']
    };
  }

  // Duration / Till-When (Generic or specific)
  if (/till.*when|ending.*soon|renewal|expiring/.test(q)) {
    const today = new Date();
    const endingSoon = Object.values(employees).map(e => {
      const activeAllocs = e.allocations.filter(a => a.to && a.to >= today && a.pct > 0);
      if (activeAllocs.length === 0) return null;
      const soonestEnd = new Date(Math.min(...activeAllocs.map(a => a.to)));
      return { id: e.id, name: e.name, endDate: soonestEnd };
    }).filter(x => x).sort((a, b) => a.endDate - b.endDate).slice(0, 10);

    const rows = endingSoon.map(x => `<li><strong>${x.name}</strong> ends ${fmtDate(x.endDate)}</li>`).join('');
    return { text: `⌛ <strong>Allocations Ending Soon (Duration):</strong><ul>${rows}</ul>`, quick: ['Dashboard', 'Who is on bench?'] };
  }

  // Detailed Project/Employee Lookup (ID based)
  const idMatch = q.match(/(\d{4,10})/);
  if (idMatch) {
    const id = idMatch[1];
    const p = projects[id];
    if (p) {
      const emps = Array.from(p.employees.values()).slice(0, 10).join(', ');
      return { text: `📁 <strong>${p.name}</strong> (ID: ${p.id})<div class="data-card"><div class="dc-row"><span class="dc-label">Status</span><span class="dc-value">${p.status}</span></div><div class="dc-row"><span class="dc-label">Timeline</span><span class="dc-value">${fmtDate(p.startDate)} - ${fmtDate(p.endDate)}</span></div><div class="dc-row"><span class="dc-label">Team Size</span><span class="dc-value">${p.teamSize}</span></div><div class="dc-row"><span class="dc-label">Team Members</span><span class="dc-value">${emps}...</span></div></div>`, quick: ['Back to Projects', 'Dashboard'] };
    }
    const e = employees[id];
    if (e) {
      const projSummary = Array.from(e.projects).map(pid => projects[pid] ? projects[pid].name : `Project ${pid}`).join(', ');
      return { text: `👤 <strong>Employee: ${e.name}</strong> (ID: ${e.id})<div class="data-card"><div class="dc-row"><span class="dc-label">Projects</span><span class="dc-value">${projSummary}</span></div><div class="dc-row"><span class="dc-label">Allocations</span><span class="dc-value">${e.allocations.length} records</span></div></div>`, quick: ['Dashboard', 'Bench List'] };
    }
  }

  // ── RMG ASSISTANT: Employee Allocation Lookup ────────────────────
  // Strip common stop-words, detect query terms, and STRIP PUNCTUATION
  const stopWords = /\b(employee|employees|name|names|which|project|projects|is|was|are|allocated|in|on|at|search|find|who|where|tell|me|about|the|their|my|show|what|currently|now|today|check|for|and|or|of|a|an|allocation|allocations|status|till|when|how|long|duration|end|ending|finish|finishing|start|starting|list|get|please|detail|details|info|information|not|unallocated|all|total|every)\b/g;
  const searchQuery = q.replace(stopWords, '').replace(/[?!.,]/g, '').replace(/\s+/g, ' ').trim();

  // Detect a specific date in query — formats: DD/MM/YYYY, DD-MM-YYYY, "15 feb 2026", "feb 2026"
  const specificDateMatch = input.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
  const namedDateMatch = input.match(/(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+(\d{4})/i);
  const monthYearMatch = input.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+(\d{4})/i);

  let queryDate = null;
  if (specificDateMatch) {
    queryDate = new Date(parseInt(specificDateMatch[3]), parseInt(specificDateMatch[2]) - 1, parseInt(specificDateMatch[1]));
  } else if (namedDateMatch) {
    const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
      .indexOf(namedDateMatch[2].toLowerCase().substring(0, 3));
    queryDate = new Date(parseInt(namedDateMatch[3]), mIdx, parseInt(namedDateMatch[1]));
  }

  // Detect intent keywords
  const isHistoryQuery = /histor|all.*alloc|all.*proj|ever.*alloc|previous|past|list.*alloc/i.test(input);
  const isBenchQuery = /bench|unalloc|not.*alloc|free|idle|available/i.test(input);
  const isDateQuery = queryDate !== null || monthYearMatch !== null;
  const isDurationQuery = /till|when|how.*long|duration|end|finish/i.test(input);

  // STRIP DATES from searchQuery to avoid breaking name lookup
  let finalSearchQuery = searchQuery;
  if (specificDateMatch) finalSearchQuery = finalSearchQuery.replace(specificDateMatch[0].toLowerCase(), '');
  if (namedDateMatch) finalSearchQuery = finalSearchQuery.replace(namedDateMatch[0].toLowerCase(), '');
  if (monthYearMatch) finalSearchQuery = finalSearchQuery.replace(monthYearMatch[0].toLowerCase(), '');
  finalSearchQuery = finalSearchQuery.trim();

  function buildAllocationCard(empName, empId, allocs, labelOverride) {
    if (allocs.length === 0) {
      return `<div class="rmg-card">
        <div class="rmg-row"><span class="rmg-field">Employee Name</span><span class="rmg-value"><strong>${empName}</strong> (ID: ${empId})</span></div>
        <div class="rmg-row"><span class="rmg-field">Allocation Status</span><span class="rmg-value status-badge red">Unallocated / On Bench</span></div>
        <div class="rmg-row"><span class="rmg-field">Project Name</span><span class="rmg-value">—</span></div>
        <div class="rmg-row"><span class="rmg-field">Allocation Period</span><span class="rmg-value">—</span></div>
      </div>`;
    }
    return allocs.map((a, i) => {
      const pName = (projects[a.projectid] ? projects[a.projectid].name : null) || `Project ${a.projectid}`;
      const status = a.pct >= 100 ? 'Fully Allocated' : a.pct > 0 ? `Partially Allocated (${a.pct}%)` : 'Allocated (0%)';
      const badge = a.pct >= 100 ? 'green' : 'orange';
      return `<div class="rmg-card">
        ${i === 0 ? `<div class="rmg-row"><span class="rmg-field">Employee Name</span><span class="rmg-value"><strong>${empName}</strong> (ID: ${empId})</span></div>` : ''}
        <div class="rmg-row"><span class="rmg-field">Allocation Status</span><span class="rmg-value status-badge ${badge}">${status}</span></div>
        <div class="rmg-row"><span class="rmg-field">Project Name</span><span class="rmg-value"><strong>${pName}</strong></span></div>
        <div class="rmg-row"><span class="rmg-field">Allocation Period</span><span class="rmg-value">${fmtDate(a.from)} → ${fmtDate(a.to)}</span></div>
      </div>`;
    }).join('');
  }

  if (finalSearchQuery.length > 2) {
    // 1. Search by Employee Name (Robust Word-based Matching)
    const queryWords = finalSearchQuery.toLowerCase().split(/\s+/).filter(w => w.length > 1);

    const matchedEmps = Object.values(employees).filter(e => {
      const eName = e.name.toLowerCase();
      // Check if EVERY word in the query roughly matches a part of the name
      return queryWords.every(qw => {
        // Direct match or partial match (starts with or significantly contained)
        if (eName.includes(qw)) return true;

        // Handle slight typos (like "veram" for "Verma") by checking word parts
        // If the query word is long enough, check if names contain 75%+ of it
        if (qw.length > 3) {
          const eWords = eName.split(/\s+/);
          return eWords.some(ew => {
            if (ew.startsWith(qw.substring(0, 3))) return true; // Starts with first 3 chars
            return false;
          });
        }
        return false;
      });
    });

    if (matchedEmps.length > 0) {
      if (matchedEmps.length === 1) {
        const e = matchedEmps[0];
        const today2 = new Date(); today2.setHours(0, 0, 0, 0);

        let allocs = [];
        let headingLabel = '';

        if (isBenchQuery) {
          // Check if unallocated during the query period
          let checkStart = today2, checkEnd = today2;
          if (monthYearMatch) {
            const yr = parseInt(monthYearMatch[2]);
            const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(monthYearMatch[1].toLowerCase().substring(0, 3));
            checkStart = new Date(yr, mIdx, 1);
            checkEnd = new Date(yr, mIdx + 1, 0);
          } else if (queryDate) {
            checkStart = queryDate; checkEnd = queryDate;
          }

          const overlapping = e.allocations.filter(a => a.from && a.to && a.from <= checkEnd && a.to >= checkStart && a.pct > 0);
          if (overlapping.length === 0) {
            return { text: `👤 <strong>RMG Allocation Report</strong><br>${buildAllocationCard(e.name, e.id, [], '')}`, quick: ['Active Projects', 'Dashboard'] };
          } else {
            return { text: `👤 <strong>RMG Allocation Report</strong><br>${buildAllocationCard(e.name, e.id, overlapping, 'Allocated Period')}`, quick: ['Active Projects', 'Dashboard'] };
          }

        } else if (isHistoryQuery) {
          // All allocations sorted chronologically
          allocs = [...e.allocations].filter(a => a.pct > 0).sort((a, b) => (a.from || 0) - (b.from || 0));
          headingLabel = 'Allocation History';

        } else if (isDurationQuery) {
          // Find the absolute maximum 'to' date across all allocations
          const validAllocs = e.allocations.filter(a => a.to && a.pct > 0);
          if (validAllocs.length > 0) {
            const maxToDate = new Date(Math.max(...validAllocs.map(a => a.to)));
            // For the card display, show the specific allocation that has this max date
            allocs = validAllocs.filter(a => a.to.getTime() === maxToDate.getTime());
            headingLabel = `Max Allocation (until ${fmtDate(maxToDate)})`;
          } else {
            allocs = [];
            headingLabel = 'No Allocations Found';
          }

        } else if (queryDate) {
          // Allocation on a specific date
          allocs = e.allocations.filter(a => a.from && a.to && a.from <= queryDate && queryDate <= a.to && a.pct > 0);
          headingLabel = `Allocation on ${fmtDate(queryDate)}`;

        } else if (monthYearMatch && !queryDate) {
          // Month+Year filter
          const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
            .indexOf(monthYearMatch[1].toLowerCase().substring(0, 3));
          const yr = parseInt(monthYearMatch[2]);
          const mStart = new Date(yr, mIdx, 1);
          const mEnd = new Date(yr, mIdx + 1, 0);
          allocs = e.allocations.filter(a => a.from && a.to && a.from <= mEnd && a.to >= mStart && a.pct > 0)
            .sort((a, b) => (a.from || 0) - (b.from || 0));
          headingLabel = `Allocation in ${monthYearMatch[1]} ${monthYearMatch[2]}`;

        } else {
          // Default: current allocation (today)
          allocs = e.allocations.filter(a => a.from && a.to && a.from <= today2 && today2 <= a.to && a.pct > 0);
          headingLabel = 'Current Allocation';
        }

        const card = buildAllocationCard(e.name, e.id, allocs, headingLabel);

        // Enhance Duration response with a direct textual answer if possible
        let summaryText = `👤 <strong>RMG Allocation Report</strong>${headingLabel ? ' — ' + headingLabel : ''}<br>${card}`;
        if (isDurationQuery && allocs.length > 0) {
          const maxDateStr = fmtDate(new Date(Math.max(...e.allocations.filter(a => a.to && a.pct > 0).map(a => a.to))));
          summaryText = `👤 <strong>${e.name}</strong> is allocated until <strong>${maxDateStr}</strong> (Max).<br>${card}`;
        }

        return { text: summaryText, quick: ['History', 'Active Projects', 'Dashboard'] };

      } else {
        // Multiple employees matched — list them
        const names = matchedEmps.slice(0, 10).map(e => `<li>${e.name} (ID: ${e.id})</li>`).join('');
        return { text: `Found ${matchedEmps.length} employees matching "<strong>${finalSearchQuery}</strong>":<ul>${names}</ul>Please be more specific.`, quick: ['Dashboard', 'Active Projects'] };
      }
    }

    // 2. Search by Project Name (Fuzzy)
    const matchedProjs = Object.values(projects).filter(p =>
      p.id.toLowerCase().includes(finalSearchQuery.toLowerCase()) ||
      p.name.toLowerCase().includes(finalSearchQuery.toLowerCase())
    );
    if (matchedProjs.length > 0) {
      if (monthYearMatch) {
        const mIdx = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
          .indexOf(monthYearMatch[1].toLowerCase().substring(0, 3));
        const yr = parseInt(monthYearMatch[2]);
        const mStart = new Date(yr, mIdx, 1);
        const mEnd = new Date(yr, mIdx + 1, 0);

        const p = matchedProjs[0];
        // This is a bit complex for a single block, just show project and mention date
        return { text: `📁 <strong>${p.name}</strong> (ID: ${p.id})<div class="data-card"><div class="dc-row"><span class="dc-label">Month Filter</span><span class="dc-value">${monthYearMatch[1]} ${monthYearMatch[2]}</span></div><div class="dc-row"><span class="dc-label">Team Size (Total)</span><span class="dc-value">${p.teamSize}</span></div></div>`, quick: ['Show team', 'Active Projects'] };
      }

      const p = matchedProjs[0];
      const emps = Array.from(p.employees.values()).slice(0, 10).map(ename => `<li>${ename}</li>`).join('');
      return { text: `📁 <strong>${p.name}</strong> (ID: ${p.id})<div class="data-card"><div class="dc-row"><span class="dc-label">Status</span><span class="dc-value">${p.status}</span></div><div class="dc-row"><span class="dc-label">Timeline</span><span class="dc-value">${fmtDate(p.startDate)} - ${fmtDate(p.endDate)}</span></div><div class="dc-row"><span class="dc-label">Team Size</span><span class="dc-value">${p.teamSize}</span></div></div><br><strong>Team Members (Top 10):</strong><ul>${emps}</ul>`, quick: ['Dashboard', 'Active Projects'] };
    }
  }

  return {
    text: `I'm not sure about that. Try asking:<br>
    • <strong>"Employees allocated in Apr 2026?"</strong><br>
    • <strong>"Are any resources over-allocated?"</strong><br>
    • <strong>"Which resources are under-allocated?"</strong><br>
    • <strong>"Till when is [Employee] allocated?"</strong><br>
    • <strong>"Where was [Employee] on [Date]?"</strong><br>
    • <strong>"Active projects in [Month] [Year]"</strong>`,
    quick: ['Allocated in Apr 2026', 'Over-allocated', 'Dashboard']
  };
}



// ── UI Logic ─────────────────────────────────────────────────────
const chat = document.getElementById('chatMessages');
const input = document.getElementById('userInput');

// ── Configuration & State ────────────────────────────────────────
const CONFIG = {
  DATA_JSON: 'training_data.json',
  REFRESH_INTERVAL: 15 * 60 * 1000 // 15 mins
};

const LLM_CONFIG = {
  BASE: 'http://127.0.0.1:8081',
  ENDPOINT: 'http://127.0.0.1:8081/v1/completions',
  HEALTH: 'http://127.0.0.1:8081/health',
  ENABLED: true,
  CONNECTED: false,
  MODEL: 'Qwen2.5-7B (llama.cpp)',
  TIMEOUT: 60000, // 60s — LLM on CPU can be slow
  modelInfo: null  // populated on successful health check
};

// ── LLM Status Badge ─────────────────────────────────────────────
function updateLLMStatusBadge(connected, label) {
  const badge = document.getElementById('llmStatusBadge');
  if (!badge) return;
  badge.textContent = label || (connected ? 'AI Online' : 'AI Offline');
  badge.className = 'status-badge ' + (connected ? 'online' : 'offline');
}

// ── Health Check ─────────────────────────────────────────────────
async function checkLLMConnection() {
  try {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 4000);
    const res = await fetch(LLM_CONFIG.HEALTH, { signal: ctrl.signal });
    clearTimeout(tid);
    if (res.ok) {
      const data = await res.json();
      if (data.status === 'ok') {
        LLM_CONFIG.CONNECTED = true;
        LLM_CONFIG.modelInfo = data;
        const label = `AI Online · ${data.employees || '?'} emps`;
        updateLLMStatusBadge(true, label);
        return;
      }
    }
    LLM_CONFIG.CONNECTED = false;
    updateLLMStatusBadge(false, 'AI Offline');
  } catch (_) {
    LLM_CONFIG.CONNECTED = false;
    updateLLMStatusBadge(false, 'AI Offline');
  }
}

// ── Build compact context from live in-memory data ───────────────
function buildContextString(userQuery) {
  const kpi = getKPIs();
  const today = new Date();
  const lines = [];
  const q = userQuery.toLowerCase();

  // --- Date Detection Logic ---
  let contextDate = today;
  let dateLabel = "Today";
  const months = ['january','february','march','april','may','june','july','august','september','october','november','december'];
  const monthsShort = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  
  let mIdx = months.findIndex(m => q.includes(m));
  if (mIdx === -1) mIdx = monthsShort.findIndex(m => q.includes(m));
  
  const yearMatch = q.match(/\b(202\d)\b/);

  if (mIdx !== -1) {
    const yr = yearMatch ? parseInt(yearMatch[1]) : today.getFullYear();
    contextDate = new Date(yr, mIdx, 1);
    dateLabel = `${months[mIdx].charAt(0).toUpperCase() + months[mIdx].slice(1)} ${yr}`;
  }

  lines.push(`=== REFERENCE DATE: ${dateLabel} ===`);
  lines.push('=== CURRENT ALLOCATION KPIs ===');
  lines.push(`Total Projects   : ${kpi.totalProjects}`);
  lines.push(`Active Projects  : ${kpi.activeProjects}`);
  lines.push(`Total Employees  : ${kpi.totalEmployees}`);
  lines.push(`Allocated        : ${kpi.allocatedEmployees}`);
  lines.push(`On Bench         : ${kpi.benchEmployees}`);
  lines.push(`Utilization      : ${kpi.utilizationRate}`);
  lines.push('');

  // 1. Contextual Bench List (Factual Answer)
  const bench = getEmployeesOnBench(contextDate, contextDate).slice(0, 25);
  lines.push(`=== EMPLOYEES ON BENCH (${dateLabel}) ===`);
  if (bench.length) {
    bench.forEach(e => lines.push(`• ${e.name} (ID:${e.id})`));
  } else {
    lines.push("No employees on bench for this period.");
  }
  lines.push('');

  // 2. Top active projects
  const active = getActiveProjects().slice(0, 5);
  if (active.length) {
    lines.push('=== ACTIVE PROJECTS ===');
    active.forEach(p => {
      lines.push(`• ${p.name} (ID:${p.id}) | ${p.teamSize} members`);
    });
    lines.push('');
  }

  // 3. Employee lookup from query
  const matched = Object.values(employees).filter(e => {
    const nameLower = e.name.toLowerCase();
    return q.includes(nameLower) || (e.id && q.includes(e.id.toLowerCase()));
  }).slice(0, 2);

  if (matched.length) {
    lines.push('=== MATCHED EMPLOYEE DETAILS ===');
    matched.forEach(e => {
      lines.push(`Employee: ${e.name} (ID:${e.id})`);
      
      // Filter allocations to match the requested period if a month was detected
      let filteredAllocs = e.allocations;
      if (mIdx !== -1) {
         const mStart = new Date(contextDate.getFullYear(), contextDate.getMonth(), 1);
         const mEnd = new Date(contextDate.getFullYear(), contextDate.getMonth() + 1, 0);
         filteredAllocs = e.allocations.filter(a => a.from <= mEnd && a.to >= mStart && a.pct > 0);
      } else {
         filteredAllocs = e.allocations.slice(0, 4);
      }

      if (filteredAllocs.length === 0) {
        lines.push(`  - No active allocations recorded for ${dateLabel}.`);
      } else {
        filteredAllocs.forEach(a => {
          const pname = projects[a.projectid] ? projects[a.projectid].name : `Project ${a.projectid}`;
          lines.push(`  - ${pname} | ${fmtDate(a.from)} to ${fmtDate(a.to)} | ${a.pct}%`);
        });
      }
    });
    lines.push('');
  }

  // 4. Inject matching training QA (Question Bank Ground Truth)
  if (trainingData && trainingData.trainingQA) {
    const hits = trainingData.trainingQA.filter(qa => 
      qa.intents.some(intent => q.includes(intent.replace('.*', '').toLowerCase()))
    ).slice(0, 1);
    
    if (hits.length) {
      lines.push('=== RELEVANT TRAINING Q&A (GROUND TRUTH) ===');
      hits.forEach(h => {
        lines.push(`Topic: ${h.intents[0]}`);
        lines.push(`Validated Answer: ${h.answer}`);
      });
      lines.push('');
    }
  }

  // 5. Inject Risk & Outlook (Benchmarking Goal)
  const risks = getRiskAlerts();
  if (risks.length) {
    lines.push('=== PROACTIVE RISK & OUTLOOK ===');
    risks.forEach(r => lines.push(`• [${r.title.toUpperCase()}] ${r.msg}`));
    lines.push('Forecast: High risk of mobilization bottleneck if roll-offs are not reassigned by EOM.');
    lines.push('');
  }

  return lines.join('\n');
}

// ── LLM Request ──────────────────────────────────────────────────
async function getLLMResponse(userInput) {
  const extraContext = buildContextString(userInput);
  const body = JSON.stringify({
    prompt: userInput,
    extra_context: extraContext,
    max_tokens: 512,
    temperature: 0.3
  });

  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), LLM_CONFIG.TIMEOUT);

  try {
    const res = await fetch(LLM_CONFIG.ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: ctrl.signal
    });
    clearTimeout(tid);

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `HTTP ${res.status}`);
    }

    const data = await res.json();
    const elapsed = data.elapsed_ms > 1000 ? `${(data.elapsed_ms/1000).toFixed(1)}s` : `${data.elapsed_ms}ms`;
    return {
      text: `${data.content}<br><span class="llm-attr">🤖 Qwen2.5-7B · ${elapsed}</span>`,
      quick: ['Dashboard', 'Who is on bench?', 'Active Projects']
    };
  } catch (err) {
    clearTimeout(tid);
    if (err.name === 'AbortError') {
      return {
        text: '⏱️ The AI is taking too long to respond (model may be loading). The rule-based engine is still available for structured queries.',
        quick: ['Dashboard', 'Who is on bench?', 'Active Projects']
      };
    }
    return {
      text: `⚠️ AI response error: ${err.message}. Falling back to rule engine.`,
      quick: ['Dashboard', 'Active Projects']
    };
  }
}

// ── Hybrid Query Classifier ───────────────────────────────────────
// Returns true if the query can be handled by the existing rule engine
function isStructuredQuery(q) {
  const lower = q.toLowerCase();
  // Numeric ID (project/employee lookup)
  if (/\d{4,}/.test(lower)) return true;
  // Date patterns
  if (/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+\d{4}/.test(lower)) return true;
  if (/\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4}/.test(lower)) return true;
  // Known structured keywords
  const structuredKw = [
    'bench','dashboard','summary','kpi','overview','stat','metric',
    'active project','upcoming','completed','utilization','capacity',
    'over-alloc','overalloc','under-alloc','underalloc','multi.*project',
    'less than','below','more than','above','greater than',
    'allocated in','unalloc','on bench','available','free resource',
    'till when','how long','when is','where was','allocation history',
    'who is on','who was','top project','largest project',
    'this quarter','this month','next month','headcount','efficiency',
    'workforce','rebalance','shared','idle','running project','in progress'
  ];
  return structuredKw.some(kw => new RegExp(kw, 'i').test(lower));
}

function switchRole(role) {
  currentRole = role;
  document.querySelectorAll('.role-btn').forEach(b => b.classList.toggle('active', b.dataset.role === role));
  document.getElementById('roleLabel').textContent = role === 'RM' ? 'Resource Manager' : 'PORTFOLIO_REDACTED';
  chat.innerHTML = '';
  showWelcome();
  updateContextPanel();
  
  // If we are in dashboard section, also update the dashboard persona and render
  if (currentSection === 'dashboard') {
    dashboardPersona = role; // Sync dashboard persona with global role
    renderDashboard();
  }
}

function updateContextPanel() {
  const panel = document.getElementById('contextContent');
  const kpi = getKPIs();
  const risks = getRiskAlerts();
  const topProj = getTopProjects(3);

  // Utilization Progress Bar
  const utilVal = parseInt(kpi.utilizationRate) || 0;

  const riskHtml = risks.length ? risks.map(r => `
    <div class="cp-card risk-${r.type}">
      <div class="cp-card-title">${r.icon} ${r.title}</div>
      <div class="cp-card-sub">${r.msg}</div>
    </div>
  `).join('') : '<div class="cp-card-sub">No critical risks detected.</div>';

  const cardsHtml = topProj.map(p => `
    <div class="cp-card interactive" onclick="window.openTeamModal('${p.id}')">
      <div class="cp-card-title">${p.name}</div>
      <div class="cp-card-sub">${p.teamSize} members · ${p.status}</div>
      <div class="gauge-container">
        <div class="gauge-bar-bg"><div class="gauge-bar-fill" style="width: ${Math.min(100, (p.teamSize/50)*100)}%"></div></div>
      </div>
    </div>
  `).join('');

  panel.innerHTML = `
    <div class="cp-section">
      <div class="cp-section-title">📊 Ecosystem Health</div>
      <div class="kpi-box" style="margin-bottom:15px">
        <div class="kpi-val">${kpi.utilizationRate}</div>
        <div class="kpi-label">Overall Utilization</div>
        <div class="gauge-container">
          <div class="gauge-bar-bg"><div class="gauge-bar-fill" style="width: ${utilVal}%"></div></div>
        </div>
      </div>
      <div class="kpi-row">
        <div class="kpi-box interactive" onclick="openProjectModal('active')">
          <div class="kpi-val">${kpi.activeProjects}</div>
          <div class="kpi-label">Active Proj</div>
        </div>
        <div class="kpi-box orange">
          <div class="kpi-val">${kpi.benchEmployees}</div>
          <div class="kpi-label">On Bench</div>
        </div>
      </div>
    </div>
    
    <div class="cp-section">
      <div class="cp-section-title">🚩 Risk Registry</div>
      <div id="riskList">${riskHtml}</div>
    </div>

    <div class="cp-section">
      <div class="cp-section-title">🏆 High Impact Projects</div>
      <div id="topProjectsList">${cardsHtml}</div>
    </div>`;
}

// ── Team Modal Logic (Project Drilldown) ──────────────────────────
window.openTeamModal = function (pid) {
  console.log("Opening Team Modal for PID:", pid);
  const p = projects[pid];
  if (!p) {
    console.warn("Project not found in projects map:", pid);
    return;
  }

  document.getElementById('teamModalTitle').textContent = p.name;

  const info = document.getElementById('teamProjectInfo');
  info.innerHTML = `
    <div class="dc-row"><span class="dc-label">Project ID</span><span class="dc-value">${p.id}</span></div>
    <div class="dc-row"><span class="dc-label">Start Date</span><span class="dc-value">${fmtDate(p.startDate)}</span></div>
    <div class="dc-row"><span class="dc-label">End Date</span><span class="dc-value">${fmtDate(p.endDate)}</span></div>
    <div class="dc-row"><span class="dc-label">Team Size</span><span class="dc-value">${p.teamSize}</span></div>
  `;

  const tbody = document.getElementById('teamTableBody');
  const teamMembers = Array.from(p.employees.keys()).map(eid => {
    const e = employees[eid];
    return { id: eid, name: e ? e.name : `Employee ${eid}` };
  }).sort((a, b) => a.name.localeCompare(b.name));

  tbody.innerHTML = teamMembers.map(m => `
    <tr>
      <td>${m.id}</td>
      <td style="font-weight:600">${m.name}</td>
    </tr>
  `).join('');

  document.getElementById('teamMemberCount').textContent = `${teamMembers.length} team members`;
  document.getElementById('teamModal').classList.add('open');
};

window.closeTeamModal = function (event) {
  if (!event || event.target === document.getElementById('teamModal')) {
    document.getElementById('teamModal').classList.remove('open');
  }
};


function removeWelcome() { const w = document.getElementById('welcome'); if (w) w.remove(); }

function showWelcome() {
  const kpi = getKPIs();
  const w = document.createElement('div');
  w.className = 'welcome-section'; w.id = 'welcome';
  w.innerHTML = `
    <div class="msg-avatar" style="width:50px; height:50px; font-size:24px; margin: 0 auto 12px;">🤖</div>
    <h2 style="text-align:center; margin-bottom:6px; font-size: 20px;">Intelligent Resource Hub</h2>
    <p style="text-align:center; color:var(--text-muted); margin-bottom:20px; font-size: 13px;">
      Analyzing ${kpi.totalRecords.toLocaleString()} records across ${kpi.totalProjects} projects with 
      <strong>${kpi.utilizationRate}</strong> efficiency.
    </p>
    <div class="topic-grid">
      <div class="cp-card interactive" onclick="sendQuick('Overview of current resource situation')">
        <div class="cp-card-title">📊 Strategic Overview</div>
        <div class="cp-card-sub">AI summary of efficiency, benchmarks, and upcoming risks.</div>
      </div>
      <div class="cp-card interactive" onclick="sendQuick('Who will be on bench in May 2026?')">
        <div class="cp-card-title">⌛ Future Availability</div>
        <div class="cp-card-sub">Identify resources rolling off projects in the coming months.</div>
      </div>
      <div class="cp-card interactive" onclick="sendQuick('Who is over-allocated?')">
        <div class="cp-card-title">⚠️ Over-capacity Alert</div>
        <div class="cp-card-sub">Find and rebalance resources assigned to >100% capacity.</div>
      </div>
    </div>
  `;
  chat.appendChild(w);
}

function appendMessage(text, role) {
  const row = document.createElement('div');
  row.className = `msg-row ${role}`;
  const av = document.createElement('div');
  av.className = 'msg-avatar';
  av.textContent = role === 'bot' ? '🤖' : '👤';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.innerHTML = text.replace(/\n/g, '<br>');
  row.appendChild(av); row.appendChild(bubble);
  chat.appendChild(row); chat.scrollTop = chat.scrollHeight;
}

function appendQuickReplies(replies) {
  if (!replies || !replies.length) return;
  const wrap = document.createElement('div');
  wrap.className = 'quick-actions';
  replies.forEach(r => {
    const btn = document.createElement('button');
    btn.className = 'quick-btn'; btn.textContent = r;
    btn.onclick = () => { wrap.remove(); sendQuick(r); };
    wrap.appendChild(btn);
  });
  chat.appendChild(wrap); chat.scrollTop = chat.scrollHeight;
}

function showTyping() {
  const row = document.createElement('div');
  row.className = 'msg-row bot'; row.id = 'typing';
  const av = document.createElement('div');
  av.className = 'msg-avatar'; av.textContent = '🤖';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
  row.appendChild(av); row.appendChild(bubble);
  chat.appendChild(row); chat.scrollTop = chat.scrollHeight;
}
function removeTyping() { const t = document.getElementById('typing'); if (t) t.remove(); }
function sendQuick(text) { removeWelcome(); appendMessage(text, 'user'); processMessage(text); }

async function processMessage(text) {
  showTyping();

  // 1. Always try the rule engine first for structured queries
  // 1. Favors LLM for Analysis/Report/Narrative queries
  const analysisKw = ['analyze', 'report', 'summary', 'explain', 'why', 'how', 'trend', 'situation', 'insight', 'suggest'];
  const isAnalysis = analysisKw.some(kw => text.toLowerCase().includes(kw));

  // Every message now goes through the LLM for a consistent AI experience
  try {
    const llmRes = await getLLMResponse(text);
    removeTyping();
    appendMessage(llmRes.text, 'bot');
    if (llmRes.quick) appendQuickReplies(llmRes.quick);
    return;
  } catch (e) {
    console.error("LLM Error:", e);
    
    // Fallback: If LLM is totally down/failed, use the Narrative Summary as emergency offline response
    if (trainingData && trainingData.narrativeSummary) {
      await new Promise(r => setTimeout(r, 800));
      removeTyping();
      appendMessage(
        trainingData.narrativeSummary + 
        '<br><br><span class="llm-attr">📊 Emergency Fallback: AI Server is offline. Showing pre-computed summary.</span>', 
        'bot'
      );
      return;
    }

    // Last resort help text
    removeTyping();
    appendMessage("I'm having trouble connecting to my AI brain right now. Please try again or ask for the 'Dashboard Summary'.", 'bot');
  }

  // 4. LLM offline — fallback rule response
  await new Promise(r => setTimeout(r, 300));
  removeTyping();
  appendMessage(
    ruleRes.text + '<br><span class="llm-attr">💡 Tip: Start the LLM server (<code>start_llm.ps1</code>) for AI-powered answers.</span>',
    'bot'
  );
  if (ruleRes.quick) appendQuickReplies(ruleRes.quick);
}

function handleSend() {
  const text = input.value.trim(); if (!text) return;
  removeWelcome(); appendMessage(text, 'user');
  input.value = ''; input.style.height = 'auto'; processMessage(text);
}
input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 100) + 'px'; });
input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } });

// ── Project Modal Logic ───────────────────────────────────────────
let _modalProjects = [];  // current set shown in modal

function openProjectModal(filter) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const all = Object.values(projects).sort((a, b) => b.teamSize - a.teamSize);

  if (filter === 'active') {
    _modalProjects = all.filter(p => p.status === 'Active');
    document.getElementById('modalTitle').textContent = `✅ Active Projects (${_modalProjects.length})`;
  } else {
    _modalProjects = all;
    document.getElementById('modalTitle').textContent = `📁 All Projects (${_modalProjects.length})`;
  }

  document.getElementById('modalSearch').value = '';
  renderModalTable(_modalProjects, today);

  document.getElementById('projectModal').classList.add('open');
}

function renderModalTable(list, today) {
  if (!today) { today = new Date(); today.setHours(0, 0, 0, 0); }
  const tbody = document.getElementById('projectTableBody');
  const count = document.getElementById('modalCount');

  tbody.innerHTML = list.map(p => {
    const endDate = p.endDate instanceof Date ? p.endDate : null;
    const expired = endDate && endDate < today;
    const rowClass = expired ? ' class="row-expired"' : '';

    return `<tr${rowClass}>
      <td>${p.id}</td>
      <td>${p.name}</td>
      <td>${fmtDate(p.startDate)}</td>
      <td>${fmtDate(p.endDate)}</td>
      <td><span class="team-size-badge">${p.teamSize}</span></td>
    </tr>`;
  }).join('');

  count.textContent = `${list.length} project${list.length !== 1 ? 's' : ''}`;
}

function filterModalTable() {
  const q = document.getElementById('modalSearch').value.toLowerCase().trim();
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const filtered = q
    ? _modalProjects.filter(p =>
      p.id.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q))
    : _modalProjects;
  renderModalTable(filtered, today);
}

function closeProjectModal(event) {
  // Only close if clicking the dark overlay directly (not the modal-box)
  if (event.target === document.getElementById('projectModal')) {
    document.getElementById('projectModal').classList.remove('open');
  }
}

// Close with Escape key
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.getElementById('projectModal')?.classList.remove('open');
    document.getElementById('teamModal')?.classList.remove('open');
  }
});

// Init — load data then render
loadData();

// ══════════════════════════════════════════════════════════════
// ── QUESTION BANK — 100 Project Allocation Questions ──────────
// ══════════════════════════════════════════════════════════════

const QUESTION_BANK = [
  // ── 1. Dashboard & Overview (10) ──────────────────────────
  { cat: '📊 Dashboard', q: 'Show me the dashboard summary' },
  { cat: '📊 Dashboard', q: 'What are the current KPIs?' },
  { cat: '📊 Dashboard', q: 'Give me an overview of all projects' },
  { cat: '📊 Dashboard', q: 'What is the total number of employees?' },
  { cat: '📊 Dashboard', q: 'How many projects are there in total?' },
  { cat: '📊 Dashboard', q: 'What is the overall utilization rate?' },
  { cat: '📊 Dashboard', q: 'How many employees are currently allocated?' },
  { cat: '📊 Dashboard', q: 'Show me all allocation metrics' },
  { cat: '📊 Dashboard', q: 'What is the current headcount?' },
  { cat: '📊 Dashboard', q: 'Give me a quick resource summary' },

  // ── 2. Bench & Available Resources (10) ───────────────────
  { cat: '👥 Bench', q: 'Who is on bench today?' },
  { cat: '👥 Bench', q: 'How many employees are on bench?' },
  { cat: '👥 Bench', q: 'List all unallocated resources' },
  { cat: '👥 Bench', q: 'Who is available for new projects?' },
  { cat: '👥 Bench', q: 'Show me free resources for this month' },
  { cat: '👥 Bench', q: 'Who is idle right now?' },
  { cat: '👥 Bench', q: 'Who was on bench in January 2026?' },
  { cat: '👥 Bench', q: 'Who is not assigned to any project currently?' },
  { cat: '👥 Bench', q: 'Show bench list for March 2026' },
  { cat: '👥 Bench', q: 'Who will be on bench in April 2026?' },

  // ── 3. Active Projects (10) ───────────────────────────────
  { cat: '📁 Active Projects', q: 'Show all active projects' },
  { cat: '📁 Active Projects', q: 'Which projects are currently running?' },
  { cat: '📁 Active Projects', q: 'List the top 10 active projects by team size' },
  { cat: '📁 Active Projects', q: 'Which project has the most employees?' },
  { cat: '📁 Active Projects', q: 'Show me the largest active project' },
  { cat: '📁 Active Projects', q: 'What are the ongoing projects?' },
  { cat: '📁 Active Projects', q: 'Which projects are in progress?' },
  { cat: '📁 Active Projects', q: 'Show active projects with more than 20 members' },
  { cat: '📁 Active Projects', q: 'List all running projects and their end dates' },
  { cat: '📁 Active Projects', q: 'Show me projects ending this month' },

  // ── 4. Upcoming & Completed Projects (10) ─────────────────
  { cat: '🔮 Project Status', q: 'Which projects are upcoming?' },
  { cat: '🔮 Project Status', q: 'Show me projects starting next month' },
  { cat: '🔮 Project Status', q: 'List all completed projects' },
  { cat: '🔮 Project Status', q: 'Which projects have finished recently?' },
  { cat: '🔮 Project Status', q: 'How many projects have been completed?' },
  { cat: '🔮 Project Status', q: 'Show projects that are not yet started' },
  { cat: '🔮 Project Status', q: 'Which projects are planned for future?' },
  { cat: '🔮 Project Status', q: 'List projects with unknown status' },
  { cat: '🔮 Project Status', q: 'Show me all closed projects' },
  { cat: '🔮 Project Status', q: 'Which projects started in 2025?' },

  // ── 5. Allocation Percentage Queries (10) ─────────────────
  { cat: '📈 Allocation %', q: 'Who has allocation less than 50%?' },
  { cat: '📈 Allocation %', q: 'Show employees with less than 60% allocation' },
  { cat: '📈 Allocation %', q: 'Who is under-allocated?' },
  { cat: '📈 Allocation %', q: 'List employees with more than 80% allocation' },
  { cat: '📈 Allocation %', q: 'Who is 100% allocated?' },
  { cat: '📈 Allocation %', q: 'Show employees with allocation above 90%' },
  { cat: '📈 Allocation %', q: 'Who has allocation equal to 50%?' },
  { cat: '📈 Allocation %', q: 'Show employees with low allocation in March 2026' },
  { cat: '📈 Allocation %', q: 'Who is partially allocated?' },
  { cat: '📈 Allocation %', q: 'Show me fully allocated employees this month' },

  // ── 6. Over & Under Allocated Resources (10) ──────────────
  { cat: '⚠️ Over/Under', q: 'Who is over-allocated?' },
  { cat: '⚠️ Over/Under', q: 'Show over-allocated resources' },
  { cat: '⚠️ Over/Under', q: 'Are there any employees with more than 100% allocation?' },
  { cat: '⚠️ Over/Under', q: 'Who is under-allocated right now?' },
  { cat: '⚠️ Over/Under', q: 'Show all under-allocated resources' },
  { cat: '⚠️ Over/Under', q: 'Which employees are overloaded?' },
  { cat: '⚠️ Over/Under', q: 'Are there resources with split allocation?' },
  { cat: '⚠️ Over/Under', q: 'Who has capacity for more work?' },
  { cat: '⚠️ Over/Under', q: 'Show employees allocated on multiple projects today' },
  { cat: '⚠️ Over/Under', q: 'Which resources need rebalancing?' },

  // ── 7. Multi-Project & Shared Resources (10) ──────────────
  { cat: '🤝 Multi-Project', q: 'Who is working on multiple projects?' },
  { cat: '🤝 Multi-Project', q: 'Show employees shared across projects' },
  { cat: '🤝 Multi-Project', q: 'Which employees are on more than one project?' },
  { cat: '🤝 Multi-Project', q: 'List all shared resources' },
  { cat: '🤝 Multi-Project', q: 'Who is a cross-project resource?' },
  { cat: '🤝 Multi-Project', q: 'Show me employees on 3 or more projects' },
  { cat: '🤝 Multi-Project', q: 'Which resources are most shared?' },
  { cat: '🤝 Multi-Project', q: 'Show employees involved in multiple allocations' },
  { cat: '🤝 Multi-Project', q: 'List resources with concurrent project involvement' },
  { cat: '🤝 Multi-Project', q: 'Who is the most shared employee?' },

  // ── 8. Utilization & Capacity (10) ────────────────────────
  { cat: '📉 Utilization', q: 'What is the utilization rate?' },
  { cat: '📉 Utilization', q: 'Show me the workforce capacity' },
  { cat: '📉 Utilization', q: 'How is resource utilization performing?' },
  { cat: '📉 Utilization', q: 'What percentage of employees are allocated?' },
  { cat: '📉 Utilization', q: 'Show capacity vs allocation breakdown' },
  { cat: '📉 Utilization', q: 'How many resources are at full capacity?' },
  { cat: '📉 Utilization', q: 'What is the bench percentage?' },
  { cat: '📉 Utilization', q: 'How many resources are underutilized?' },
  { cat: '📉 Utilization', q: 'Show team utilization overview' },
  { cat: '📉 Utilization', q: 'What is the allocation efficiency?' },

  // ── 9. Date & Period Based Queries (10) ───────────────────
  { cat: '📅 Date Queries', q: 'Who is allocated in April 2026?' },
  { cat: '📅 Date Queries', q: 'Show employees allocated in January 2026' },
  { cat: '📅 Date Queries', q: 'Who was allocated in December 2025?' },
  { cat: '📅 Date Queries', q: 'Show allocations for February 2026' },
  { cat: '📅 Date Queries', q: 'Who is allocated in June 2026?' },
  { cat: '📅 Date Queries', q: 'Show all allocations ending in March 2026' },
  { cat: '📅 Date Queries', q: 'Who starts their allocation in May 2026?' },
  { cat: '📅 Date Queries', q: 'Show resources allocated in Q1 2026' },
  { cat: '📅 Date Queries', q: 'Who is on bench in July 2026?' },
  { cat: '📅 Date Queries', q: 'Show all allocations for this quarter' },

  // ── 10. Employee Duration & Till-When (10) ────────────────
  { cat: '⌛ Duration', q: 'Till when is the current allocation going?' },
  { cat: '⌛ Duration', q: 'Which employees are ending their allocation soon?' },
  { cat: '⌛ Duration', q: 'Who is allocated till end of March 2026?' },
  { cat: '⌛ Duration', q: 'Show the longest running allocations' },
  { cat: '⌛ Duration', q: 'Which allocations expire this month?' },
  { cat: '⌛ Duration', q: 'Show employees whose allocation ends in April 2026?' },
  { cat: '⌛ Duration', q: 'Who has the longest project duration?' },
  { cat: '⌛ Duration', q: 'Show me allocations expiring soon' },
  { cat: '⌛ Duration', q: 'Which employees need allocation renewal?' },
  { cat: '⌛ Duration', q: 'Show resources allocated till end of 2026' },
];

// ── Question Bank State ───────────────────────────────────────
let _qbActiveCategory = 'All';
const _qbCategories = ['All', ...new Set(QUESTION_BANK.map(q => q.cat))];

// ── Open / Close ──────────────────────────────────────────────
function openQuestionBank() {
  _qbActiveCategory = 'All';
  document.getElementById('qbSearch').value = '';
  _renderQBTabs();
  _renderQBList(QUESTION_BANK);
  document.getElementById('questionBankModal').classList.add('open');
}

function closeQBModal(event) {
  if (event.target === document.getElementById('questionBankModal')) {
    document.getElementById('questionBankModal').classList.remove('open');
  }
}

// ── Render Tabs ───────────────────────────────────────────────
function _renderQBTabs() {
  const container = document.getElementById('qbTabs');
  container.innerHTML = _qbCategories.map(cat => {
    const count = cat === 'All' ? QUESTION_BANK.length :
      QUESTION_BANK.filter(q => q.cat === cat).length;
    const isActive = cat === _qbActiveCategory;
    return `<button class="qb-tab${isActive ? ' active' : ''}"
      onclick="_setQBCategory('${cat.replace(/'/g, "\\'")}')">
      ${cat} <span class="qb-tab-count">${count}</span>
    </button>`;
  }).join('');
}

function _setQBCategory(cat) {
  _qbActiveCategory = cat;
  document.getElementById('qbSearch').value = '';
  _renderQBTabs();
  const filtered = cat === 'All' ? QUESTION_BANK : QUESTION_BANK.filter(q => q.cat === cat);
  _renderQBList(filtered);
}

// ── Render Question List ──────────────────────────────────────
function _renderQBList(questions) {
  const container = document.getElementById('qbList');
  const count = document.getElementById('qbResultCount');

  if (questions.length === 0) {
    container.innerHTML = `<div class="qb-empty">No questions match your search.</div>`;
    count.textContent = '0 questions';
    return;
  }

  // Group by category for display
  const groups = {};
  questions.forEach(q => {
    if (!groups[q.cat]) groups[q.cat] = [];
    groups[q.cat].push(q);
  });

  let html = '';
  Object.entries(groups).forEach(([cat, qs]) => {
    // Only show category header when "All" tab is selected
    if (_qbActiveCategory === 'All') {
      html += `<div class="qb-group-label">${cat}</div>`;
    }
    qs.forEach((item, idx) => {
      const num = QUESTION_BANK.indexOf(item) + 1;
      html += `<div class="qb-item" onclick="_askFromQB(this)" data-q="${item.q.replace(/"/g, '&quot;')}">
        <span class="qb-num">${num}</span>
        <span class="qb-text">${item.q}</span>
        <span class="qb-arrow">→</span>
      </div>`;
    });
  });

  container.innerHTML = html;
  count.textContent = `${questions.length} question${questions.length !== 1 ? 's' : ''}`;
}

// ── Search Filter ─────────────────────────────────────────────
function filterQBQuestions() {
  const q = document.getElementById('qbSearch').value.toLowerCase().trim();
  const base = _qbActiveCategory === 'All' ? QUESTION_BANK :
    QUESTION_BANK.filter(item => item.cat === _qbActiveCategory);
  const filtered = q ? base.filter(item => item.q.toLowerCase().includes(q)) : base;
  _renderQBList(filtered);
}

// ── Ask a Question from Bank ──────────────────────────────────
function _askFromQB(el) {
  const text = el.getAttribute('data-q');
  document.getElementById('questionBankModal').classList.remove('open');
  removeWelcome();
  appendMessage(text, 'user');
  processMessage(text);
}

// Escape key closes Question Bank too
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.getElementById('questionBankModal')?.classList.remove('open');
  }
});
// ── Section Switching Logic ──────────────────────────────────────
function showSection(sectionId) {
  currentSection = sectionId;
  
  // Update sidebar active state
  document.getElementById('navAssistant').classList.toggle('active', sectionId === 'assistant');
  document.getElementById('navDashboard').classList.toggle('active', sectionId === 'dashboard');
  
  // Update visibility
  document.getElementById('assistantSection').classList.toggle('active', sectionId === 'assistant');
  document.getElementById('dashboardSection').classList.toggle('active', sectionId === 'dashboard');
  
  // Breadcrumb update
  const bc = document.querySelector('.breadcrumb');
  if (bc) bc.innerHTML = `<span>Home</span> / ${sectionId.charAt(0).toUpperCase() + sectionId.slice(1)}`;
  
  if (sectionId === 'dashboard') {
    renderDashboard();
  }
}

function setDashboardPersona(persona) {
  dashboardPersona = persona;
  document.querySelectorAll('.p-tab').forEach(tab => {
    tab.classList.toggle('active', tab.textContent.includes(persona === 'RM' ? 'Resource' : persona === 'PM' ? 'Project' : 'PORTFOLIO_REDACTED'));
  });
  renderDashboard();
}

function renderDashboard() {
  const grid = document.getElementById('dashboardGrid');
  if (!grid) return;
  
  const kpi = getKPIs();
  const advanced = getAdvancedAnalytics();
  const standup = getDailyStandup();
  const health = getDataHealth();
  const risks = getRiskAlerts();
  
  let html = '';
  
  if (dashboardPersona === 'RM') {
    // Resource Manager Dashboard: Focus on Bench, Utilization, and Leakage
    html = `
      <div class="db-card persona-rm">
        <div class="db-card-header">
          <div class="db-card-icon">📊</div>
          <div class="db-card-title">Talent Utilization</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large">${kpi.utilizationRate}</div>
          <div class="db-label-sub">Core Workforce Efficiency</div>
          <div class="db-bar-wrap">
            <div class="db-bar-fill" style="width: ${parseInt(kpi.utilizationRate)}%"></div>
          </div>
          <div class="db-trend"><span class="trend-up">↑ 2.4%</span> vs last month</div>
        </div>
      </div>
      
      <div class="db-card persona-rm">
        <div class="db-card-header">
          <div class="db-card-icon">💸</div>
          <div class="db-card-title">Revenue Leakage</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large">${advanced.leakageImpact}</div>
          <div class="db-label-sub">Impact of Unallocated Resources</div>
          <div class="db-bar-wrap">
            <div class="db-bar-fill" style="width: ${parseFloat(advanced.leakageImpact)}%; background: var(--sf-error)"></div>
          </div>
          <div class="db-trend"><span class="trend-down">↓ 1.2%</span> Optimization potential</div>
        </div>
      </div>

      <div class="db-card persona-rm">
        <div class="db-card-header">
          <div class="db-card-icon">🛡️</div>
          <div class="db-card-title">Data Integrity Health</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large">${health.score}%</div>
          <div class="db-label-sub">Current Status: <strong>${health.label}</strong></div>
          <div class="db-bar-wrap">
            <div class="db-bar-fill" style="width: ${health.score}%; background: ${health.score > 80 ? 'var(--sf-success)' : 'var(--sf-warning)'}"></div>
          </div>
        </div>
      </div>
    `;
  } else if (dashboardPersona === 'PM') {
    // Project Manager Dashboard: Focus on Active, Changes, and Saturation
    const saturation = advanced.saturationLevels[0] || { role: 'N/A', level: 0 };
    
    html = `
      <div class="db-card persona-pm">
        <div class="db-card-header">
          <div class="db-card-icon">📁</div>
          <div class="db-card-title">Active Engagements</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large">${kpi.activeProjects}</div>
          <div class="db-label-sub">Projects in Delivery</div>
          <div class="db-trend"><span class="trend-up">↑ 1</span> new this week</div>
        </div>
      </div>

      <div class="db-card persona-pm">
        <div class="db-card-header">
          <div class="db-card-icon">🔥</div>
          <div class="db-card-title">High Demand Role</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large" style="font-size:18px">${saturation.role}</div>
          <div class="db-label-sub">Saturation: ${saturation.level}%</div>
          <div class="db-bar-wrap">
            <div class="db-bar-fill" style="width: ${saturation.level}%; background: var(--sf-teal)"></div>
          </div>
          <div class="db-trend">Critical staffing bottleneck</div>
        </div>
      </div>

      <div class="db-card persona-pm">
        <div class="db-card-header">
          <div class="db-card-icon">📋</div>
          <div class="db-card-title">Daily Standup Alerts</div>
        </div>
        <div class="db-card-body">
          <div class="db-label-sub">Upcoming Roll-offs (7 days)</div>
          <ul class="db-list" style="margin-top:10px">
            ${standup.rollOffs.length > 0 ? standup.rollOffs.map(r => `
               <li class="db-list-item"><span class="db-list-label">${r.name}</span><span class="db-list-val">In ${r.days}d</span></li>
            `).join('') : '<li class="db-list-item">No imminent roll-offs</li>'}
          </ul>
          <div class="db-trend" style="margin-top:8px"><strong>Note:</strong> ${standup.alerts}</div>
        </div>
      </div>
    `;
  } else if (dashboardPersona === 'DH') {
    // Delivery Head Dashboard: Strategic Outlook & Scale
    const totalEffort = Object.values(projects).reduce((sum, p) => sum + p.totalEffort, 0);
    const topSaturation = advanced.saturationLevels.slice(0, 3);
    
    html = `
      <div class="db-card persona-dh">
        <div class="db-card-header">
          <div class="db-card-icon">💰</div>
          <div class="db-card-title">Delivery Scale</div>
        </div>
        <div class="db-card-body">
          <div class="db-val-large">${(totalEffort/1000).toFixed(1)}k</div>
          <div class="db-label-sub">Total Minutes Logged</div>
          <div class="db-bar-wrap">
            <div class="db-bar-fill" style="width: 85%; background: var(--sf-accent)"></div>
          </div>
          <div class="db-trend"><span class="trend-up">↑ 12%</span> Efficiency Growth</div>
        </div>
      </div>

      <div class="db-card persona-dh">
        <div class="db-card-header">
          <div class="db-card-icon">🎯</div>
          <div class="db-card-title">Top Role Saturation</div>
        </div>
        <div class="db-card-body">
          <ul class="db-list">
            ${topSaturation.map(s => `
              <li class="db-list-item">
                <span class="db-list-label">${s.role}</span>
                <span class="db-list-val">${s.level}%</span>
              </li>
            `).join('')}
          </ul>
        </div>
      </div>

      <div class="db-card persona-dh">
        <div class="db-card-header">
          <div class="db-card-icon">🚩</div>
          <div class="db-card-title">Critical Risk Registry</div>
        </div>
        <div class="db-card-body">
          <ul class="db-list">
            ${risks.slice(0, 3).map(r => `
              <li class="db-list-item">
                <span class="db-list-label">${r.icon} ${r.title}</span>
                <span class="db-list-val">${r.msg.substring(0, 15)}...</span>
              </li>
            `).join('')}
          </ul>
          <button class="quick-btn" style="width:100%; margin-top:10px" onclick="showSection('assistant'); sendQuick('Show all risks')">Full Report</button>
        </div>
      </div>
    `;
  }
  
  grid.innerHTML = html;
}
