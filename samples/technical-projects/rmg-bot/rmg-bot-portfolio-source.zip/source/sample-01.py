import json
import os
import random
import time
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="RMG Bot Lite AI Server")

# Enable CORS for frontend interaction
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.responses import HTMLResponse

@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html>
        <head>
            <title>RMG Lite AI Server</title>
            <style>
                body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #f0f2f5; }
                .card { background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; }
                .status { color: #10b981; font-weight: bold; }
                .code { background: #f3f4f6; padding: 0.5rem; border-radius: 4px; font-family: monospace; }
            </style>
        </head>
        <body>
            <div class="card">
                <h1>🤖 RMG Lite AI Server</h1>
                <p>Status: <span class="status">ONLINE</span></p>
                <p>This server provides analytical fallbacks for the RMG Bot.</p>
                <div class="code">http://127.0.0.1:8080/completion</div>
            </div>
        </body>
    </html>
    """

DATA_PATH = "training_data.json"

class CompletionRequest(BaseModel):
    prompt: str
    extra_context: Optional[str] = None
    max_tokens: Optional[int] = 512
    temperature: Optional[float] = 0.7
    stop: Optional[List[str]] = None

def load_data():
    if not os.path.exists(DATA_PATH):
        return None
    try:
        with open(DATA_PATH, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def generate_analytical_response(prompt: str, context: Optional[str], data: dict):
    prompt_lower = prompt.lower()
    narrative = data.get("narrativeSummary", "Data is currently being processed.")
    kpis = data.get("kpis", {})
    
    # 1. TRIGGER STRATEGIC OVERVIEW SYNTHESIS (High Priority for 'overview', 'summary', etc.)
    is_overview = any(kw in prompt_lower for kw in ["overview", "situation", "summary", "trend", "analys"])
    
    if is_overview:
        risk_text = ""
        if (context and "PROACTIVE RISK & OUTLOOK" in context):
            parts = context.split("=== PROACTIVE RISK & OUTLOOK ===")
            risk_info = parts[1].split("===")[0].strip() if len(parts) > 1 else ""
            if risk_info:
                risk_text = f"\n\n🚨 **Proactive Risk Registry:**\n{risk_info}"

        return f"### Strategic Resource Overview\n\n**Current State:** {narrative}\n\n**Key Indicators:**\n• Personnel Utilization: {kpis.get('utilizationRate', 'N/A')}\n• High Impact Projects: {kpis.get('activeProjects', 0)} active{risk_text}\n\n**Recommendation:** Maintain focus on roll-off reassignments to prevent bottlenecking."

    # 2. GROUND TRUTH CHECK (Specific Q&A)
    if (context):
        if "RELEVANT TRAINING Q&A" in context:
            parts = context.split("=== RELEVANT TRAINING Q&A (GROUND TRUTH) ===")
            qa_info = parts[1].split("===")[0].strip() if len(parts) > 1 else ""
            if "Validated Answer:" in qa_info:
                ans = qa_info.split("Validated Answer:")[1].strip()
                return ans

    # 3. BENCH / UNALLOCATED CHECK
    if any(kw in prompt_lower for kw in ["bench", "unallocated", "available", "unassigned", "free resource"]):
        if context and "EMPLOYEES ON BENCH" in context:
            parts = context.split("=== EMPLOYEES ON BENCH")
            bench_info = parts[1].split("===")[1].strip() if len(parts) > 1 else "No specific data found."
            return f"According to the RMG records for that perio/opt/portfolio/project"

    # 4. EMPLOYEE DETAILS
    if context and "MATCHED EMPLOYEE DETAILS" in context:
        parts = context.split("=== MATCHED EMPLOYEE DETAILS ===")
        emp_info = parts[1].split("===")[0].strip() if len(parts) > 1 else ""
        if emp_info:
            return f"Here are the allocation details for the requested resourc/opt/portfolio/project"

    # 5. Fallback specific entities
    if "who" in prompt_lower or "detail" in prompt_lower or "id:" in prompt_lower:
        return f"Based on the RMG Data: {narrative} If you are looking for specific availability, {kpis.get('benchEmployees', 0)} employees are currently on the bench. For deep employee histories, please refer to the 'Allocation History' in the side panel."

    if "how" in prompt_lower or "suggest" in prompt_lower:
        return f"Strategic Insight: With {kpis.get('totalEmployees', 0)} total resources, {narrative} I suggest focusing on optimizing the {kpis.get('benchEmployees', 0)} unallocated resources for upcoming pipeline projects."

    # Final Default
    return f"I've analyzed the current RMG data: {narrative} Would you like a breakdown of specific KPIs or project timelines?"

@app.get("/health")
def health():
    data = load_data()
    return {
        "status": "ok",
        "mode": "lite",
        "model": "rule-driven-synthesis",
        "employees": data.get("kpis", {}).get("totalEmployees", 0) if data else 0,
        "data_updated": data.get("generatedAt") if data else "never"
    }

@app.post("/v1/completions")
@app.post("/completion") # llama.cpp default
async def completion(request: CompletionRequest):
    start_time = time.time()
    # Simulate "Thinking" time for realism
    time.sleep(1.2 + random.random() * 0.8)
    
    data = load_data()
    if not data:
        raise HTTPException(status_code=500, detail="Data source not found.")

    # Generate response using context
    response_text = generate_analytical_response(request.prompt, request.extra_context, data)
    elapsed_ms = int((time.time() - start_time) * 1000)
    
    # Format as llama.cpp response
    return {
        "content": response_text,
        "elapsed_ms": elapsed_ms,
        "id": f"lite-{int(time.time())}",
        "created": int(time.time()),
        "model": "RMG-Lite-AI",
        "object": "text_completion",
        "choices": [
            {
                "text": response_text,
                "index": 0,
                "logprobs": None,
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": len(request.prompt) // 4,
            "completion_tokens": len(response_text) // 4,
            "total_tokens": (len(request.prompt) + len(response_text)) // 4
        }
    }

if __name__ == "__main__":
    import uvicorn
    print("\n--- RMG Bot Lite AI Server Running ---")
    print("Serving on http://localhost:8080")
    print("This server provides analytical fallbacks without GGUF requirements.\n")
    uvicorn.run(app, host="127.0.0.1", port=8080)
