"""
RMG Bot — Fast Data Processor & Training Data Generator
=========================================================
Single-pass CSV reader — generates training_data.json
in seconds. Auto-refreshes every 15 minutes.

Run: py data_processor.py
"""

import csv, json, time, os, re
from datetime import datetime, date
from collections import defaultdict

CSV_FILE   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "project allocation Data.csv")
OUT_FILE   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "training_data.json")
INTERVAL   = 15 * 60   # 15 minutes

# Project names are read directly from the CSV (projectname column)

MONTH_NAMES = ["", "Jan","Feb","Mar","Apr","May","Jun",
               "Jul","Aug","Sep","Oct","Nov","Dec"]

def parse_date(s):
    if not s: return None
    s = s.strip().split()[0]
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try: return datetime.strptime(s, fmt).date()
        except: pass
    return None

def fmt(d):
    return d.strftime("%d %b %Y") if d else "N/A"

# ─────────────────────────────────────────────────────────────────
def process():
    today     = date.today()
    start_ts  = time.time()

    # ── 1. Read CSV (single pass) ─────────────────────────────────
    rows = []
    try:
        with open(CSV_FILE, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                rows.append({k.strip(): (v or "").strip() for k, v in r.items()})
    except Exception as e:
        print(f"[ERROR] {e}"); return

    print(f"  Loaded {len(rows):,} rows in {time.time()-start_ts:.1f}s")

    # ── 2. Build project & employee maps (single pass) ────────────
    projects  = {}   # pid -> dict
    employees = {}   # eid -> dict
    name_map  = {}   # eid -> name

    # For alloc% filtering: eid -> list of (pct, from, to, pid)
    emp_alloc_detail = defaultdict(list)

    for r in rows:
        pid  = r.get("projectid","")
        eid  = r.get("employeeid","")
        name = r.get("employeename","")
        pct_str = r.get("alloc_percentage","0") or "0"
        pct = 0
        try: pct = int(pct_str)
        except: pct = 0

        # If percentage is 0 but there is effort, calculate it (480 mins = 100%)
        day_eff = 0
        try: day_eff = int(r.get("dayeffort","0") or 0)
        except: day_eff = 0

        if pct == 0 and day_eff > 0:
            pct = round((day_eff / 480) * 100)
        af   = parse_date(r.get("allocatedfrom"))
        at   = parse_date(r.get("allocatedto"))
        ps   = parse_date(r.get("projectstartdate"))
        pe   = parse_date(r.get("projectenddate"))
        eff  = int(r.get("totaleffort","0") or 0)
        wdays= int(r.get("workdays","0") or 0)

        pname= (r.get("projectname","") or "").strip() or f"Project {pid}"

        if eid: name_map[eid] = name

        # project
        if pid:
            if pid not in projects:
                projects[pid] = {"id":pid,"name":pname,"emps":set(),"start":ps,"end":pe,
                                 "effort":0,"wdays":0,"allocs":[]}
            else:
                # Update name if we got a real one this iteration
                if pname != f"Project {pid}" and projects[pid]["name"] == f"Project {pid}":
                    projects[pid]["name"] = pname
            p = projects[pid]
            p["emps"].add(eid)
            p["effort"] += eff; p["wdays"] += wdays
            p["allocs"].append({"eid":eid,"name":name,"af":af,"at":at,"pct":pct})
            if ps and (not p["start"] or ps < p["start"]): p["start"] = ps
            if pe and (not p["end"] or pe > p["end"]):   p["end"] = pe

        # employee
        if eid:
            if eid not in employees:
                employees[eid] = {"id":eid,"name":name,"projs":set(),"allocs":[]}
            e = employees[eid]
            e["projs"].add(pid)
            e["allocs"].append({"pid":pid,"af":af,"at":at,"pct":pct})
            emp_alloc_detail[eid].append({"pct":pct,"af":af,"at":at,"pid":pid})

    # ── 3. Project status ─────────────────────────────────────────
    for p in projects.values():
        ps, pe = p["start"], p["end"]
        p["status"] = ("Upcoming" if ps and today<ps else
                       "Completed" if pe and today>pe else
                       "Active"  if ps and pe else "Unknown")
        p["teamSize"] = len(p["emps"])
        p["allocCnt"] = len(p["allocs"])

    # ── 4. Bench (no active alloc today) ─────────────────────────
    allocated_today = set()
    for eid, allocs in emp_alloc_detail.items():
        for a in allocs:
            if a["af"] and a["at"] and a["af"] <= today <= a["at"] and a["pct"] > 0:
                allocated_today.add(eid); break

    bench_ids = [e for e in employees if e not in allocated_today]

    # ── 5. KPIs ───────────────────────────────────────────────────
    total_emp = len(employees)
    alloc_emp = len(allocated_today)
    bench_emp = total_emp - alloc_emp
    util      = round(alloc_emp/total_emp*100, 1) if total_emp else 0

    proj_arr   = list(projects.values())
    active_p   = sorted([p for p in proj_arr if p["status"]=="Active"],   key=lambda p:-p["teamSize"])
    upcoming_p = sorted([p for p in proj_arr if p["status"]=="Upcoming"], key=lambda p:(p["start"] or date.min))
    completed_p= sorted([p for p in proj_arr if p["status"]=="Completed"],key=lambda p:-(p["end"] or date.min).toordinal())
    top_p      = sorted(proj_arr, key=lambda p:-p["teamSize"])

    kpis = {
        "totalRecords": len(rows),
        "totalProjects": len(projects),
        "activeProjects": len(active_p),
        "upcomingProjects": len(upcoming_p),
        "completedProjects": len(completed_p),
        "totalEmployees": total_emp,
        "allocatedEmployees": alloc_emp,
        "benchEmployees": bench_emp,
        "utilizationRate": f"{util}%",
        "generatedAt": datetime.now().strftime("%d %b %Y %H:%M")
    }

    # ── 6. Alloc% buckets (eid-level, fast) ───────────────────────
    # For each employee find their MAX alloc% in any current/recent record
    emp_max_pct = {}
    for eid, allocs in emp_alloc_detail.items():
        emp_max_pct[eid] = max(a["pct"] for a in allocs)

    def emps_by_pct_filter(op, threshold):
        """Return [(eid, name, max_pct)] matching the filter."""
        result = []
        for eid, max_p in emp_max_pct.items():
            if op == "lt"  and max_p <  threshold: result.append((eid, name_map.get(eid,eid), max_p))
            if op == "lte" and max_p <= threshold: result.append((eid, name_map.get(eid,eid), max_p))
            if op == "gt"  and max_p >  threshold: result.append((eid, name_map.get(eid,eid), max_p))
            if op == "gte" and max_p >= threshold: result.append((eid, name_map.get(eid,eid), max_p))
            if op == "eq"  and max_p == threshold: result.append((eid, name_map.get(eid,eid), max_p))
        return sorted(result, key=lambda x: x[2])

    # Month-filtered alloc% — store per (year, month, eid) -> max pct that month
    # Fast: just use af month (not expand)
    monthly_emp_pct = defaultdict(lambda: defaultdict(int))  # (yr,mo) -> eid -> max_pct
    for eid, allocs in emp_alloc_detail.items():
        for a in allocs:
            if a["af"]:
                key = (a["af"].year, a["af"].month)
                monthly_emp_pct[key][eid] = max(monthly_emp_pct[key][eid], a["pct"])
            if a["at"] and a["at"] != a["af"]:
                key2 = (a["at"].year, a["at"].month)
                monthly_emp_pct[key2][eid] = max(monthly_emp_pct[key2][eid], a["pct"])

    # Build monthly summary (fast, no loop per row)
    monthly_summary = {}
    for (yr, mo), emp_pct_map in monthly_emp_pct.items():
        all_e = list(emp_pct_map.keys())
        low   = [(e, name_map.get(e,e), p) for e,p in emp_pct_map.items() if p < 60]
        full  = [(e, name_map.get(e,e), p) for e,p in emp_pct_map.items() if p >= 100]
        key   = f"{yr}-{mo:02d}"
        monthly_summary[key] = {
            "year": yr, "month": mo,
            "monthName": f"{MONTH_NAMES[mo]} {yr}",
            "totalEmployees": len(all_e),
            "lowAllocCount": len(low),
            "fullAllocCount": len(full),
            "lowAllocEmployees": [{"id":e,"name":n,"pct":p} for e,n,p in sorted(low, key=lambda x:x[2])[:30]],
            "fullAllocEmployees": [{"id":e,"name":n,"pct":p} for e,n,p in sorted(full, key=lambda x:x[2], reverse=True)[:30]],
            "allEmployees": [{"id":e,"name":name_map.get(e,e),"pct":p} for e,p in list(emp_pct_map.items())[:50]]
        }

    # ── 7. Serialise helpers ──────────────────────────────────────
    def ser_proj(p, include_allocs=True):
        name = p.get("name", f"Project {p['id']}")
        return {
            "id": p["id"], "name": name, "status": p["status"],
            "startDate": fmt(p["start"]), "endDate": fmt(p["end"]),
            "teamSize": p["teamSize"], "allocCount": p["allocCnt"],
            "totalEffort": p["effort"],
            "employees": [{"id":a["eid"],"name":a["name"],
                           "from":fmt(a["af"]),"to":fmt(a["at"]),"pct":a["pct"]}
                          for a in p["allocs"][:50]] if include_allocs else []
        }

    def ser_emp(e):
        return {
            "id": e["id"], "name": e["name"],
            "projectCount": len(e["projs"]),
            "projects": list(e["projs"]),
            "allocations": [{"pid":a["pid"],"from":fmt(a["af"]),"to":fmt(a["at"]),"pct":a["pct"]}
                            for a in e["allocs"]]
        }

    # ── 8. Data Slices for Summaries ─────────────────────────────
    lt60_list  = emps_by_pct_filter("lt", 60)
    gte80 = emps_by_pct_filter("gte", 80)
    eq100 = emps_by_pct_filter("eq", 100)
    multi = sorted([(e["id"],e["name"],len(e["projs"])) for e in employees.values() if len(e["projs"])>1],
                   key=lambda x:-x[2])[:30]

    # ── 9. Narrative Summary for AI "Training" ───────────────────
    narrative = (
        f"As of {kpis['generatedAt']}, the Resource Management Group is overseeing {kpis['totalProjects']} projects "
        f"with {kpis['activeProjects']} currently active. The total workforce of {kpis['totalEmployees']} has a "
        f"utilization rate of {kpis['utilizationRate']}. There are {kpis['benchEmployees']} employees on the bench "
        f"who are currently available for allocation. "
    )
    if active_p:
        top_p_name = active_p[0]['name']
        narrative += f"The largest active project is '{top_p_name}' with {active_p[0]['teamSize']} members. "
    
    if lt60_list:
        narrative += f"We have identified {len(lt60_list)} employees with low allocation (below 60%), suggesting potential underutilization. "
    
    if upcoming_p:
        narrative += f"{len(upcoming_p)} projects are lined up to start soon, which will help improve utilization."

    # ── 10. Pre-built answer strings for training Q&A ──────────────
    def emp_list_html(lst, max_n=20):
        shown = lst[:max_n]
        rest  = len(lst) - max_n
        lines = [f"{i+1}. {n} (ID:{e}) — Alloc: {p}%" for i,(e,n,p) in enumerate(shown)]
        if rest > 0: lines.append(f"...and {rest} more employees")
        return "\n".join(lines)

    training_qa = [
        {"intents":["dashboard","summary","kpi","overview","stats","metrics","data overview"],
         "answer": narrative},
        {"intents":["active project","current project","running project","ongoing"],
         "answer":"ACTIVE_PROJECTS"},
        {"intents":["upcoming","future","planned","starting soon","not started"],
         "answer":"UPCOMING_PROJECTS"},
        {"intents":["completed","done","finished","closed","ended"],
         "answer":"COMPLETED_PROJECTS"},
        {"intents":["top project","largest project","biggest","most members","highest team"],
         "answer":"TOP_PROJECTS"},
        {"intents":["bench","available","free","idle","not allocated","unassigned"],
         "answer":"BENCH"},
        {"intents":["utilization","capacity","usage","allocated vs bench"],
         "answer":"UTILIZATION"},
        {"intents":["multi","multiple project","cross project","overalloc","shared"],
         "answer":"MULTI_PROJECT"},
        {"intents":["less than 60","below 60","alloc.*less","low allocation","under 60","partial alloc",
                    "alloc_percentage.*less","percentage.*less","less.*60"],
         "answer": f"LOW_ALLOC_60:\n{emp_list_html(lt60_list)}"},
        {"intents":["more than 80","above 80","greater than 80","high alloc",">=80","over 80"],
         "answer": f"HIGH_ALLOC_80:\n{emp_list_html(gte80)}"},
        {"intents":["100%","fully allocated","full allocation","100 percent"],
         "answer": f"FULL_ALLOC_100:\n{emp_list_html(eq100)}"},
        {"intents":["multi project","multiple","cross project","shared resource"],
         "answer": "\n".join(f"{i+1}. {n} (ID:{e}) — {c} projects" for i,(e,n,c) in enumerate(multi))}
    ]

    # ── 10. Assemble final JSON ───────────────────────────────────
    out = {
        "generatedAt": kpis["generatedAt"],
        "narrativeSummary": narrative,
        "kpis": kpis,
        "topProjects":      [ser_proj(p, False) for p in top_p[:30]],
        "activeProjects":   [ser_proj(p, False) for p in active_p[:30]],
        "upcomingProjects": [ser_proj(p, False) for p in upcoming_p[:30]],
        "completedProjects":[ser_proj(p, False) for p in completed_p[:30]],
        "benchEmployees":   [{"id":e,"name":name_map.get(e,e)} for e in bench_ids[:50]],
        "allProjects":      {pid: ser_proj(p) for pid, p in projects.items()},
        "allEmployees":     {eid: ser_emp(e) for eid, e in employees.items()},
        "empNameMap":       name_map,
        "monthlySummary":   monthly_summary,
        "trainingQA":       training_qa,
        # Quick alloc-pct lookup: eid -> max pct
        "empMaxPct":        emp_max_pct,
        # Multi-project employees list
        "multiProjectEmps": [{"id":e,"name":n,"count":c} for e,n,c in multi]
    }

    with open(OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, default=str)

    elapsed = time.time() - start_ts
    size_kb = os.path.getsize(OUT_FILE) / 1024
    print(f"  Done in {elapsed:.1f}s — training_data.json {size_kb:.0f} KB")
    print(f"  Projects:{kpis['totalProjects']}  Employees:{kpis['totalEmployees']}  "
          f"Utilization:{kpis['utilizationRate']}")

# ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  RMG Bot — Fast Data Processor")
    print(f"  CSV:    {CSV_FILE}")
    print(f"  Output: {OUT_FILE}")
    print(f"  Refresh every {INTERVAL//60} min  |  Ctrl+C to stop")
    print("=" * 55)
    while True:
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Processing...")
        process()
        print(f"  Next refresh in {INTERVAL//60} min.")
        time.sleep(INTERVAL)
