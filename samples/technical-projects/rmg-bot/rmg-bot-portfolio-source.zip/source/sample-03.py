"""
RMG Bot — LLM Server (llama.cpp + Qwen 7B GGUF)
=================================================
Serves a FastAPI backend on http://localhost:8080
Endpoints:
  GET  /health       — returns model status
  POST /completion   — runs inference with CSV context injected

Run:
  python llm_server.py

Prerequisites:
  pip install fastapi uvicorn llama-cpp-python
  Place model at: models/qwen2.5-7b-instruct-q4_k_m.gguf
"""

import os, json, time, logging
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uvicorn

# ── Logging ───────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("rmg-llm")

# ── Config ────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
MODEL_PATH  = BASE_DIR / "models" / "qwen2.5-7b-instruct-q4_k_m.gguf"
DATA_JSON   = BASE_DIR / "training_data.json"

# llama-cpp-python settings
N_CTX       = 4096    # context window
N_THREADS   = max(4, os.cpu_count() or 4)  # use all CPU cores
N_GPU_LAYERS = 0      # 0 = CPU only; set to 35+ if you have a GPU
MAX_TOKENS  = REDACTED_SECRET
TEMPERATURE = 0.3     # lower = more factual
TOP_P       = 0.9

app = FastAPI(title="RMG LLM Server", version="1.0.0")

# Allow browser requests from any origin (localhost dev)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global LLM state ──────────────────────────────────────────────
llm = None
training_data: dict = {}
model_load_error: str = ""


def load_model():
    """Load Qwen GGUF model via llama-cpp-python."""
    global llm, model_load_error
    try:
        from llama_cpp import Llama
        if not MODEL_PATH.exists():
            model_load_error = (
                f"Model file not found: {MODEL_PATH}\n"
                "Download Qwen2.5-7B-Instruct-Q4_K_M.gguf from HuggingFace and place it in the 'models/' folder."
            )
            log.error(model_load_error)
            return

        log.info(f"Loading model from {MODEL_PATH} ...")
        log.info(f"Using {N_THREADS} CPU threads, context={N_CTX}")
        t0 = time.time()
        llm = Llama(
            model_path=str(MODEL_PATH),
            n_ctx=N_CTX,
            n_threads=N_THREADS,
            n_gpu_layers=N_GPU_LAYERS,
            verbose=False,
        )
        log.info(f"Model loaded in {time.time()-t0:.1f}s ✅")
    except ImportError:
        model_load_error = "llama-cpp-python not installed. Run: pip install llama-cpp-python"
        log.error(model_load_error)
    except Exception as e:
        model_load_error = str(e)
        log.error(f"Failed to load model: {e}")


def load_training_data():
    """Load the pre-processed training_data.json into memory."""
    global training_data
    try:
        if DATA_JSON.exists():
            with open(DATA_JSON, encoding="utf-8") as f:
                training_data = json.load(f)
            kpis = training_data.get("kpis", {})
            log.info(
                f"Loaded training_data.json — "
                f"{kpis.get('totalProjects')} projects, "
                f"{kpis.get('totalEmployees')} employees, "
                f"utilization={kpis.get('utilizationRate')}"
            )
        else:
            log.warning("training_data.json not found — run data_processor.py first.")
    except Exception as e:
        log.error(f"Could not load training_data.json: {e}")


# ── Context Builder ───────────────────────────────────────────────
def build_context(user_query: str, extra_context: str = "") -> str:
    """
    Build a compact context string (~600–800 tokens) from training_data.
    Injects Narrative, KPIs, bench list, top projects, and matched employees.
    """
    if not training_data:
        return "No allocation data is currently loaded."

    kpis = training_data.get("kpis", {})
    bench = training_data.get("benchEmployees", [])
    active = training_data.get("activeProjects", [])
    upcoming = training_data.get("upcomingProjects", [])
    top = training_data.get("topProjects", [])
    emp_map: dict = training_data.get("empNameMap", {})
    all_employees: dict = training_data.get("allEmployees", {})

    lines = []

    # 0. Narrative Summary (AI "Training")
    narrative = training_data.get("narrativeSummary")
    if narrative:
        lines.append("=== RMG OVERVIEW & NARRATIVE ===")
        lines.append(narrative)
        lines.append("")

    # 1. KPIs
    lines.append("=== CURRENT ALLOCATION KPIs ===")
    lines.append(f"Total Projects   : {kpis.get('totalProjects', 'N/A')}")
    lines.append(f"Active Projects  : {kpis.get('activeProjects', 'N/A')}")
    lines.append(f"Upcoming Projects: {kpis.get('upcomingProjects', 'N/A')}")
    lines.append(f"Completed        : {kpis.get('completedProjects', 'N/A')}")
    lines.append(f"Total Employees  : {kpis.get('totalEmployees', 'N/A')}")
    lines.append(f"Allocated Today  : {kpis.get('allocatedEmployees', 'N/A')}")
    lines.append(f"On Bench Today   : {kpis.get('benchEmployees', 'N/A')}")
    lines.append(f"Utilization Rate : {kpis.get('utilizationRate', 'N/A')}")
    lines.append(f"Data as of       : {kpis.get('generatedAt', 'N/A')}")
    lines.append("")

    # 2. Top Active Projects (max 8)
    lines.append("=== TOP ACTIVE PROJECTS (by team size) ===")
    for p in active[:8]:
        lines.append(
            f"• {p.get('name','?')} (ID:{p.get('id','?')}) "
            f"| {p.get('teamSize','?')} members "
            f"| {p.get('startDate','?')} → {p.get('endDate','?')}"
        )
    lines.append("")

    # 3. Upcoming Projects (max 5)
    if upcoming:
        lines.append("=== UPCOMING PROJECTS ===")
        for p in upcoming[:5]:
            lines.append(
                f"• {p.get('name','?')} (ID:{p.get('id','?')}) "
                f"| starts {p.get('startDate','?')}"
            )
        lines.append("")

    # 4. Bench Employees (max 20)
    lines.append(f"=== EMPLOYEES ON BENCH TODAY ({len(bench)} total) ===")
    for e in bench[:20]:
        lines.append(f"• {e.get('name','?')} (ID:{e.get('id','?')})")
    if len(bench) > 20:
        lines.append(f"  ...and {len(bench)-20} more on bench")
    lines.append("")

    # 5. Query-relevant employee lookup
    q_lower = user_query.lower()
    matched_emps = []
    # Scan a subset for speed, prioritize matches
    for eid, edata in list(all_employees.items())[:500]:
        name = edata.get("name", "").lower()
        if name in q_lower or (len(q_lower) > 3 and q_lower in name):
            matched_emps.append(edata)
            if len(matched_emps) >= 3: break

    if matched_emps:
        lines.append("=== EMPLOYEE ALLOCATION DETAILS (matched) ===")
        for e in matched_emps:
            lines.append(f"Employee: {e.get('name')} (ID:{e.get('id')})")
            for a in e.get("allocations", [])[:5]:
                lines.append(f"  Project {a.get('pid')} | {a.get('from')} → {a.get('to')} | {a.get('pct')}%")
        lines.append("")

    # 6. Extra context passed from frontend
    if extra_context:
        lines.append("=== ADDITIONAL CONTEXT ===")
        lines.append(extra_context[:800])
        lines.append("")

    return "\n".join(lines)


def build_prompt(user_query: str, context: str, extra_context: str = "") -> str:
    """
    Build the Qwen chat prompt using the ChatML format.
    Ensures context is injected into the system message.
    """
    data_ctx = build_context(user_query, extra_context)

    system_msg = (
        "You are the RMG AI Analyst for the Resource Management Group. "
        "Your goal is to provide intelligent, data-driven insights about project allocations, employee utilization, and bench status.\n\n"
        "RULE/opt/portfolio/project"
        "1. Be analytical and professional. If asked for a report or analysis, provide a structured response with highlights.\n"
        "2. Use the 'RMG OVERVIEW & NARRATIVE' in the context to understand the current situation.\n"
        "3. Be helpful and suggest solutions (e.g., if utilization is low, highlight the high bench count).\n"
        "4. If you don't have specific data for a query, use the general KPIs to give an estimated overview.\n"
        "5. Keep responses concise but insightful.\n"
        "6. For employee details, always include Employee ID and allocation percentages.\n\n"
        "CONTEXT DAT/opt/portfolio/project"
        f"{data_ctx}"
    )

    # ChatML format
    prompt = (
        f"<|im_start|>system\n{system_msg}<|im_end|>\n"
        f"<|im_start|>user\n{user_query}<|im_end|>\n"
        f"<|im_start|>assistant\n"
    )
    return prompt


# ── Request / Response Models ─────────────────────────────────────
class CompletionRequest(BaseModel):
    prompt: str
    extra_context: Optional[str] = ""
    max_tokens: Optional[int] = MAX_TOKENS
    temperature: Optional[float] = TEMPERATURE


class CompletionResponse(BaseModel):
    content: str
    tokens_used: int
    elapsed_ms: int


# ── API Endpoints ─────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    load_training_data()
    load_model()


@app.get("/health")
async def health():
    if model_load_error:
        return JSONResponse(status_code=503, content={"status": "error", "error": model_load_error})
    if llm is None:
        return JSONResponse(status_code=503, content={"status": "loading"})
    kpis = training_data.get("kpis", {})
    return {
        "status": "ok",
        "model": "Qwen2.5-7B (llama.cpp)",
        "employees": kpis.get("totalEmployees", 0),
        "projects": kpis.get("totalProjects", 0),
        "dataAt": kpis.get("generatedAt", "N/A")
    }


@app.post("/completion", response_model=CompletionResponse)
async def completion(req: CompletionRequest):
    if llm is None:
        raise HTTPException(status_code=503, detail="Model not ready")

    _maybe_refresh_data()
    t0 = time.time()
    full_prompt = build_prompt(req.prompt, "", req.extra_context or "")

    try:
        result = llm(
            full_prompt,
            max_tokens=req.max_tokens or MAX_TOKENS,
            temperature=req.temperature if req.temperature is not None else TEMPERATURE,
            top_p=TOP_P,
            stop=["<|im_end|>", "<|im_start|>"],
            echo=False,
        )
        content = result["choices"][0]["text"].strip()
        tokens = result.get("usage", {}).get("total_tokens", 0)
        elapsed = int((time.time() - t0) * 1000)
        return CompletionResponse(content=content, tokens_used=tokens, elapsed_ms=elapsed)
    except Exception as e:
        log.error(f"Inference error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Data refresh helper
_last_data_mtime: float = 0.0

def _maybe_refresh_data():
    global _last_data_mtime, training_data
    try:
        mtime = DATA_JSON.stat().st_mtime
        if mtime > _last_data_mtime:
            _last_data_mtime = mtime
            with open(DATA_JSON, encoding="utf-8") as f:
                training_data = json.load(f)
            log.info("training_data.json refreshed.")
    except Exception: pass


if __name__ == "__main__":
    print("=" * 60)
    print("  RMG Bot — LLM Server")
    print(f"  Model : {MODEL_PATH}")
    print(f"  Data  : {DATA_JSON}")
    print(f"  Port  : 8080")
    print("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="warning")
