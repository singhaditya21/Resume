"""One-time runner: regenerates training_data.json and exits."""
import importlib.util, os, sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))

spec = importlib.util.spec_from_file_location("data_processor", "data_processor.py")
mod  = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)   # defines mod.process()

print("\n[run_once] Processing CSV -> training_data.json ...")
mod.process()
print("[run_once] Complete. Exiting.\n")
