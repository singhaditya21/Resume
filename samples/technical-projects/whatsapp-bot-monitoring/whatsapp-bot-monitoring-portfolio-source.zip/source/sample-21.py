import json
import os
from datetime import datetime, timedelta

LOG_FILE = os.path.join(
    os.environ.get("WA_BASE") or os.path.dirname(os.path.abspath(__file__)),
    "logs.txt",
)

now = datetime.now()
report_day = now - timedelta(days=1)
report_date_key = report_day.strftime("%Y-%m-%d")

total_runs = 0
successful_runs = 0
failed_runs = 0
trace_logs = 0

try:
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        for line in f:
            try:
                data = json.loads(line)
            except Exception:
                continue
            timestamp = data.get("timestamp", "")
            if not timestamp.startswith(report_date_key):
                continue
            status = data.get("status")
            if status == "TRACE":
                trace_logs += 1
            elif status == "SUCCESS":
                successful_runs += 1
                total_runs += 1
            elif status == "FAIL":
                failed_runs += 1
                total_runs += 1
except FileNotFoundError:
    pass

success_rate = round((successful_runs / total_runs) * 100, 2) if total_runs else 0.0

# Emit a single JSON object so the n8n Daily Summary email can render rich HTML.
print(json.dumps({
    "report_date": report_day.strftime("%d-%b-%Y"),
    "report_date_key": report_date_key,
    "generated_on": now.strftime("%d-%b-%Y %I:%M %p"),
    "total_journeys": total_runs,
    "successful_journeys": successful_runs,
    "failed_journeys": failed_runs,
    "trace_logs": trace_logs,
    "success_rate": success_rate,
}))
