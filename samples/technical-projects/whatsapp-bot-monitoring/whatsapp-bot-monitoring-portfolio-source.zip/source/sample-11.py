from __future__ import annotations

import logging
from typing import Any

import requests


class N8nClient:
    def __init__(self, base_url: str, api_key: str, timeout_seconds: int = 15) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "X-N8N-API-KEY": api_key,
            }
        )
        self.logger = logging.getLogger(self.__class__.__name__)

    def _request(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any] | list[Any]:
        if not self.base_url or not self.session.headers.get("X-N8N-API-KEY"):
            raise RuntimeError("N8N_BASE_URL and N8N_API_KEY must be configured before querying n8n")
        url = f"{self.base_url}{path}"
        response = self.session.get(url, params=params or {}, timeout=self.timeout_seconds)
        response.raise_for_status()
        return response.json()

    def _get_all(self, path: str, params: dict[str, Any] | None = None, limit: int = 250, max_pages: int = 20) -> list[dict[str, Any]]:
        collected: list[dict[str, Any]] = []
        current_params = dict(params or {})
        current_params.setdefault("limit", limit)

        cursor = None

        for _ in range(max_pages):
            if cursor:
                current_params["cursor"] = cursor
            else:
                current_params.pop("cursor", None)

            payload = self._request(path, current_params)
            if isinstance(payload, list):
                items = payload
                meta: dict[str, Any] = {}
            else:
                items = payload.get("data", payload.get("items", []))
                meta = payload.get("meta", {}) if isinstance(payload.get("meta", {}), dict) else {}

            if not isinstance(items, list):
                break

            collected.extend(item for item in items if isinstance(item, dict))

            next_cursor = None
            if isinstance(payload, dict):
                next_cursor = payload.get("nextCursor") or meta.get("nextCursor") or meta.get("cursor")

            if next_cursor:
                cursor = next_cursor
                continue

            if len(items) < limit:
                break

        return collected

    def get_executions(self, limit: int = 250) -> list[dict[str, Any]]:
        params = {"includeData": "true"}
        return self._get_all("/api/v1/executions", params=params, limit=limit)

    def get_workflows(self, limit: int = 250) -> list[dict[str, Any]]:
        return self._get_all("/api/v1/workflows", limit=limit)

    def health_check(self) -> bool:
        self._request("/api/v1/workflows", {"limit": 1})
        return True
