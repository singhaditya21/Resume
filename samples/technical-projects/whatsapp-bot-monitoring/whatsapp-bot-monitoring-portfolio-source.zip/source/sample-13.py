from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from utils.parsing import parse_datetime


@dataclass(frozen=True)
class WorkflowRecord:
    workflow_id: str
    name: str
    active: bool
    raw_status: str
    updated_at: datetime | None = None


@dataclass(frozen=True)
class ExecutionRecord:
    execution_id: str
    workflow_id: str | None
    workflow_name: str
    status: str
    started_at: datetime | None
    finished_at: datetime | None
    duration_seconds: float | None
    retry_of: str | None
    retry_success_id: str | None
    error_message: str | None
    mode: str
    raw: dict[str, Any]


class ExecutionRepository(ABC):
    @abstractmethod
    def get_workflows(self) -> list[WorkflowRecord]:
        raise NotImplementedError

    @abstractmethod
    def get_executions(self) -> list[ExecutionRecord]:
        raise NotImplementedError

    def health_check(self) -> bool:
        """Return True if the underlying data source is reachable."""
        return True


def _as_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _extract_error_message(payload: dict[str, Any]) -> str | None:
    """Pull a human error out of an n8n execution payload.

    n8n's public API returns the real failure under ``data.resultData.error`` when
    ``includeData=true``; only some shapes expose a top-level ``error`` key.
    """
    err = payload.get("error")
    if isinstance(err, dict) and err.get("message"):
        return _as_str(err.get("message")) or None
    if isinstance(err, str) and err.strip():
        return err.strip()

    data = payload.get("data")
    if isinstance(data, dict):
        result = data.get("resultData")
        if isinstance(result, dict):
            nested = result.get("error")
            if isinstance(nested, dict) and nested.get("message"):
                return _as_str(nested.get("message")) or None
    return None


def _extract_run_data(payload: dict[str, Any]) -> dict[str, Any]:
    data = payload.get("data")
    if isinstance(data, dict):
        result = data.get("resultData") or data.get("result_data")
        if isinstance(result, dict):
            run_data = result.get("runData") or result.get("run_data")
            if isinstance(run_data, dict):
                return run_data
    result = payload.get("resultData") or payload.get("result_data")
    if isinstance(result, dict):
        run_data = result.get("runData") or result.get("run_data")
        if isinstance(run_data, dict):
            return run_data
    return {}


def _node_executed(payload: dict[str, Any], node_name: str) -> bool:
    run_data = _extract_run_data(payload)
    return any(name.lower() == node_name.lower() for name in run_data)


def _iter_node_json(payload: dict[str, Any], node_name: str):
    run_data = _extract_run_data(payload)
    matching = None
    for name, records in run_data.items():
        if name.lower() == node_name.lower():
            matching = records
            break

    if not isinstance(matching, list):
        return

    for record in matching:
        if not isinstance(record, dict):
            continue
        data = record.get("data")
        if not isinstance(data, dict):
            continue
        main = data.get("main")
        if not isinstance(main, list):
            continue
        for branch in main:
            if not isinstance(branch, list):
                continue
            for item in branch:
                if isinstance(item, dict) and isinstance(item.get("json"), dict):
                    yield item["json"]


def _find_key_value(value: Any, key_name: str) -> Any:
    if isinstance(value, dict):
        for key, nested in value.items():
            if str(key).lower() == key_name.lower():
                return nested
            found = _find_key_value(nested, key_name)
            if found not in (None, ""):
                return found
    if isinstance(value, list):
        for item in value:
            found = _find_key_value(item, key_name)
            if found not in (None, ""):
                return found
    return None


def _extract_case_id(payload: dict[str, Any]) -> str | None:
    for item in _iter_node_json(payload, "Incident Creation"):
        case_id = _find_key_value(item, "CaseID")
        if isinstance(case_id, list) and case_id:
            return _as_str(case_id[0]) or None
        if case_id not in (None, ""):
            return _as_str(case_id) or None
    return None


def _monitoring_outcome(payload: dict[str, Any]) -> tuple[str | None, str | None]:
    """Derive bot health from the branch n8n actually executed.

    n8n marks the whole workflow as successful when the failure branch creates
    an incident and sends the failure email. For dashboard health, that is still
    a bot failure, so branch execution takes precedence over n8n's raw status.
    """
    if _node_executed(payload, "Failure Email") or _node_executed(payload, "Incident Creation"):
        case_id = _extract_case_id(payload)
        if case_id:
            return "failed", f"Bot failed - incident created (Case ID: {case_id})"
        return "failed", "Bot failed - incident creation/failure email path executed"

    if _node_executed(payload, "Re-try Success Email"):
        return "success", "Bot recovered successfully on retry"

    if _node_executed(payload, "Success Email"):
        return "success", None

    return None, None


def workflow_from_api(payload: dict[str, Any]) -> WorkflowRecord:
    workflow_id = _as_str(payload.get("id") or payload.get("workflowId"))
    name = _as_str(payload.get("name"), "Unnamed Workflow")
    active = bool(payload.get("active", payload.get("isActive", False)))
    raw_status = _as_str(payload.get("status"), "active" if active else "inactive")
    updated_at = parse_datetime(payload.get("updatedAt") or payload.get("updated_at"))
    return WorkflowRecord(
        workflow_id=workflow_id,
        name=name,
        active=active,
        raw_status=raw_status,
        updated_at=updated_at,
    )


def execution_from_api(payload: dict[str, Any]) -> ExecutionRecord:
    execution_id = _as_str(payload.get("id") or payload.get("executionId") or payload.get("execution_id"))
    workflow_id = payload.get("workflowId") or payload.get("workflow_id")
    workflow_payload = payload.get("workflow") if isinstance(payload.get("workflow"), dict) else {}
    workflow_name = _as_str(
        payload.get("workflowName")
        or payload.get("workflow_name")
        or workflow_payload.get("name"),
        "Unknown Workflow",
    )
    raw_status = _as_str(payload.get("status"), "unknown").lower()
    started_at = parse_datetime(payload.get("startedAt") or payload.get("started_at") or payload.get("createdAt"))
    finished_at = parse_datetime(payload.get("stoppedAt") or payload.get("finishedAt") or payload.get("finished_at"))
    duration = payload.get("duration")
    duration_seconds = None
    if isinstance(duration, (int, float)):
        duration_seconds = float(duration)
    elif started_at and finished_at:
        duration_seconds = max((finished_at - started_at).total_seconds(), 0.0)

    error_message = _extract_error_message(payload)
    monitoring_status, monitoring_message = _monitoring_outcome(payload)
    if monitoring_status:
        raw_status = monitoring_status
        if monitoring_message:
            error_message = monitoring_message
    mode = _as_str(payload.get("mode"), "")

    retry_of = payload.get("retryOf") or payload.get("retry_of")
    retry_success_id = payload.get("retrySuccessId") or payload.get("retry_success_id")

    return ExecutionRecord(
        execution_id=execution_id,
        workflow_id=_as_str(workflow_id, "") or None,
        workflow_name=workflow_name,
        status=raw_status,
        started_at=started_at,
        finished_at=finished_at,
        duration_seconds=duration_seconds,
        retry_of=_as_str(retry_of, "") or None,
        retry_success_id=_as_str(retry_success_id, "") or None,
        error_message=error_message,
        mode=mode,
        raw=payload,
    )


class N8nExecutionRepository(ExecutionRepository):
    def __init__(self, client) -> None:
        self.client = client

    def get_workflows(self) -> list[WorkflowRecord]:
        return [workflow_from_api(item) for item in self.client.get_workflows()]

    def get_executions(self) -> list[ExecutionRecord]:
        return [execution_from_api(item) for item in self.client.get_executions()]

    def health_check(self) -> bool:
        return bool(self.client.health_check())


class SQLiteExecutionRepository(ExecutionRepository):
    def __init__(self, database_path: str) -> None:
        self.database_path = database_path

    def get_workflows(self) -> list[WorkflowRecord]:
        return []

    def get_executions(self) -> list[ExecutionRecord]:
        return []
