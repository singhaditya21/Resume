from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any


@dataclass(frozen=True)
class HealthAssessment:
    status: str
    score: int
    checks: list[dict[str, Any]]
    recommendations: list[str]


def assess_health(summary: dict[str, Any], live_status: dict[str, Any]) -> HealthAssessment:
    score = 100
    checks: list[dict[str, Any]] = []
    recommendations: list[str] = []

    scheduler_active = bool(live_status.get("scheduler_active"))
    monitoring_connected = bool(live_status.get("n8n_connected"))
    last_success = live_status.get("last_successful_run")
    last_failure = live_status.get("last_failure_time")
    repeated_failures = summary.get("critical_failures", 0)
    failed_executions = summary.get("failed_executions", 0)
    total_runs = max(summary.get("total_scheduler_runs", 0), 1)
    failure_rate = failed_executions / total_runs
    recovery_rate = summary.get("auto_recovered_failures", 0) / total_runs
    availability = float(summary.get("bot_availability_pct", 0))

    if not monitoring_connected:
        score -= 40
        checks.append({"name": "n8n connectivity", "status": "critical", "detail": "Unable to reach n8n API"})
        recommendations.append("Verify N8N_BASE_URL and N8N_API_KEY.")
    else:
        checks.append({"name": "n8n connectivity", "status": "ok", "detail": "n8n API reachable"})

    if scheduler_active:
        checks.append({"name": "scheduler", "status": "ok", "detail": "At least one workflow is active"})
    else:
        score -= 25
        checks.append({"name": "scheduler", "status": "warning", "detail": "No active workflows detected"})
        recommendations.append("Check whether the n8n scheduler/workflow has been paused.")

    if failure_rate >= 0.25:
        score -= 30
        checks.append({"name": "failure rate", "status": "critical", "detail": f"Failure rate is {failure_rate:.0%}"})
        recommendations.append("Investigate repeated execution failures immediately.")
    elif failure_rate >= 0.1:
        score -= 15
        checks.append({"name": "failure rate", "status": "warning", "detail": f"Failure rate is {failure_rate:.0%}"})
        recommendations.append("Review execution failures and retry patterns.")
    else:
        checks.append({"name": "failure rate", "status": "ok", "detail": f"Failure rate is {failure_rate:.0%}"})

    if repeated_failures >= max(3, int(total_runs * 0.1)):
        score -= 20
        checks.append({"name": "critical failures", "status": "critical", "detail": f"{repeated_failures} critical failures detected"})
        recommendations.append("Repeated failures are pushing the bot into an unstable state.")
    else:
        checks.append({"name": "critical failures", "status": "ok", "detail": f"{repeated_failures} critical failures detected"})

    if availability < 90:
        score -= 15
        checks.append({"name": "availability", "status": "warning", "detail": f"Availability is {availability:.1f}%"})
        recommendations.append("Availability is below the target operational threshold.")
    else:
        checks.append({"name": "availability", "status": "ok", "detail": f"Availability is {availability:.1f}%"})

    if recovery_rate >= 0.15:
        score -= 5
        checks.append({"name": "auto-recovery", "status": "warning", "detail": f"Recovery events are {recovery_rate:.0%} of runs"})
    else:
        checks.append({"name": "auto-recovery", "status": "ok", "detail": f"Recovery events are {recovery_rate:.0%} of runs"})

    if last_success:
        checks.append({"name": "recent success", "status": "ok", "detail": f"Last success at {last_success}"})
    else:
        score -= 20
        checks.append({"name": "recent success", "status": "critical", "detail": "No successful execution found"})
        recommendations.append("Investigate the pipeline immediately because no successful run is recorded.")

    if last_failure:
        checks.append({"name": "recent failure", "status": "warning", "detail": f"Last failure at {last_failure}"})

    score = max(min(score, 100), 0)
    if score >= 80:
        status = "HEALTHY"
    elif score >= 50:
        status = "WARNING"
    else:
        status = "CRITICAL"

    return HealthAssessment(status=status, score=score, checks=checks, recommendations=recommendations)
