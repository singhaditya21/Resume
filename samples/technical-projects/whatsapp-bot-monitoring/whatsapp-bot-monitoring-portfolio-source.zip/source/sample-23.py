from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _split_csv(value: str | None) -> tuple[str, ...]:
    if not value:
        return ()
    return tuple(item.strip() for item in value.split(",") if item.strip())


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        logger.warning("Invalid integer for %s=%r; falling back to %s", name, raw, default)
        return default


@dataclass(frozen=True)
class Settings:
    n8n_api_key: str
    n8n_base_url: str
    dashboard_host: str
    dashboard_port: int
    refresh_interval_seconds: int
    data_source: str
    n8n_timeout_seconds: int
    snapshot_cache_seconds: int
    monitored_workflow_ids: tuple[str, ...]
    monitored_workflow_names: tuple[str, ...]
    log_level: str
    secret_key: str
    window_days: int
    expected_interval_minutes: int
    overdue_grace_minutes: int
    n8n_public_url: str
    monitor_url: str
    timezone: str
    ai_provider: str
    ai_timeout_seconds: int
    azure_openai_endpoint: str
    azure_openai_api_key: str
    azure_openai_deployment: str
    azure_openai_api_version: str
    openai_base_url: str
    openai_api_key: str
    openai_model: str


_data_source = os.getenv("DATA_SOURCE", "n8n").strip().lower()
if _data_source not in {"n8n", "sqlite"}:
    logger.warning("Unknown DATA_SOURCE=%r; defaulting to 'n8n'", _data_source)
    _data_source = "n8n"

_secret_key = os.getenv("SECRET_KEY", "").strip()
if not _secret_key:
    logger.warning("SECRET_KEY is not set; using an insecure default. Set SECRET_KEY in .env before exposing the dashboard.")
    _secret_key = REDACTED_SECRET
_ai_provider = os.getenv("AI_PROVIDER", "").strip().lower()
if not _ai_provider:
    _ai_provider = "azure_openai" if os.getenv("AZURE_OPENAI_API_KEY") else "openai" if os.getenv("OPENAI_API_KEY") else "disabled"
if _ai_provider not in {"disabled", "azure_openai", "openai"}:
    logger.warning("Unknown AI_PROVIDER=%r; defaulting to 'disabled'", _ai_provider)
    _ai_provider = "disabled"

settings = Settings(
    n8n_api_key=os.getenv("N8N_API_KEY", "").strip(),
    n8n_base_url=os.getenv("N8N_BASE_URL", "http://127.0.0.1:5678").strip().rstrip("/"),
    dashboard_host=os.getenv("DASHBOARD_HOST", "0.0.0.0").strip(),
    dashboard_port=_env_int("DASHBOARD_PORT", 8080),
    refresh_interval_seconds=_env_int("REFRESH_INTERVAL_SECONDS", 30),
    data_source=_data_source,
    n8n_timeout_seconds=_env_int("N8N_TIMEOUT_SECONDS", 15),
    snapshot_cache_seconds=_env_int("SNAPSHOT_CACHE_SECONDS", 30),
    monitored_workflow_ids=_split_csv(os.getenv("MONITORED_WORKFLOW_IDS")),
    monitored_workflow_names=_split_csv(os.getenv("MONITORED_WORKFLOW_NAMES")),
    log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper(),
    secret_key=REDACTED_SECRET
    window_days=_env_int("WINDOW_DAYS", 7),
    expected_interval_minutes=_env_int("EXPECTED_INTERVAL_MINUTES", 240),
    overdue_grace_minutes=_env_int("OVERDUE_GRACE_MINUTES", 15),
    n8n_public_url=os.getenv("N8N_PUBLIC_URL", "https://example.invalid").strip().rstrip("/"),
    monitor_url=os.getenv("MONITOR_URL", "http://localhost:5090").strip().rstrip("/"),
    timezone=os.getenv("DASHBOARD_TZ", "Asia/Kolkata").strip(),
    ai_provider=_ai_provider,
    ai_timeout_seconds=_env_int("AI_TIMEOUT_SECONDS", 20),
    azure_openai_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "").strip().rstrip("/"),
    azure_openai_api_key=os.getenv("AZURE_OPENAI_API_KEY", "").strip(),
    azure_openai_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "").strip(),
    azure_openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview").strip(),
    openai_base_url=os.getenv("OPENAI_BASE_URL", "https://example.invalid").strip().rstrip("/"),
    openai_api_key=os.getenv("OPENAI_API_KEY", "").strip(),
    openai_model=os.getenv("OPENAI_MODEL", "").strip(),
)
