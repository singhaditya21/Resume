from __future__ import annotations

from flask import Flask

from api.routes import api_bp
from routes import web_bp
from utils.config import settings
from utils.logging_config import configure_logging


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    app.config.update(
        SECRET_KEY=REDACTED_SECRET
        JSON_SORT_KEYS=False,
        TEMPLATES_AUTO_RELOAD=True,
    )

    configure_logging(app)

    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp)

    @app.get("/api/health")
    def api_health():
        from api.routes import dashboard_service

        healthy = dashboard_service.source_healthy()
        body = {
            "status": "ok" if healthy else "degraded",
            "service": "REDACTED_OPAQUE_VALUE",
            "n8n_connected": healthy,
        }
        return (body, 200) if healthy else (body, 503)

    @app.errorhandler(404)
    def not_found(_error):
        return {"error": "Not Found"}, 404

    @app.errorhandler(500)
    def server_error(error):
        app.logger.exception("Unhandled server error: %s", error)
        return {"error": "Internal Server Error"}, 500

    return app


app = create_app()


if __name__ == "__main__":
    from waitress import serve

    serve(app, host=settings.dashboard_host, port=settings.dashboard_port)
