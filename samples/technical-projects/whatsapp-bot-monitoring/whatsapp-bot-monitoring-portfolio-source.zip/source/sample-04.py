from playwright.sync_api import sync_playwright
import time
from datetime import datetime
import json
import os
import sys
import re

print("UPDATED MONITOR.PY EXECUTING")

# ================= CONFIG =================

CONTACT_NAME = "PORTFOLIO_REDACTED"

CONTACT_NUMBER = os.environ.get("WA_CONTACT", "0000000000")

BASE_PATH = os.environ.get("WA_BASE") or os.path.dirname(os.path.abspath(__file__))

LOG_FILE = os.path.join(BASE_PATH, "logs.txt")

SCREENSHOT_DIR = os.path.join(BASE_PATH, "screenshots")

# ================= LOG FUNCTION =================

def log(
    status,
    step,
    reason="",
    duration="",
    retry="NO",
    incident_id=""
):

    log_data = {
        "timestamp": str(datetime.now()),
        "status": status,
        "step": step,
        "reason": reason,
        "duration": duration,
        "retry": retry,
        "incident_id": incident_id
    }

    with open(LOG_FILE, "a", encoding="utf-8") as f:

        f.write(
            json.dumps(log_data) + "\n"
        )

# ================= RESULT FUNCTION =================

def result_json(status, step, reason="", screenshot=""):

    result = {
        "timestamp": str(datetime.now()),
        "status": status,
        "step": step,
        "reason": reason,
        "screenshot": screenshot
    }

    print(json.dumps(result))

# ================= SCREENSHOT FUNCTION =================

def capture_screenshot(page, name):

    if not os.path.exists(SCREENSHOT_DIR):

        os.makedirs(SCREENSHOT_DIR)

    path = os.path.join(
        SCREENSHOT_DIR,
        f"{name}_{int(time.time())}.png"
    )

    try:

        chat_area = page.locator(
            "//div[@id='main']"
        )

        chat_area.screenshot(path=path)

    except:

        page.screenshot(path=path)

    return path

# ================= WHATSAPP UI HELPERS =================

def dismiss_whatsapp_dialogs(page):

    close_labels = [
        "Close",
        "Not now",
        "Continue",
        "OK",
        "Ok",
        "Got it",
        "Skip",
        "Cancel",
        "Maybe later",
        "Use here",
        "Continue to chat",
    ]

    for _ in range(4):

        dialog_count = 0

        try:

            dialog_count = page.locator("//div[@role='dialog']").count()

        except Exception:

            pass

        if dialog_count == 0:

            return

        print(f"WhatsApp dialog detected ({dialog_count}); attempting to close it.")

        closed = False

        for label in close_labels:

            try:

                button = page.locator(
                    f"//div[@role='dialog']//button[@aria-label='{label}' or normalize-space()='{label}']"
                )

                if button.count() > 0:

                    button.first.click(timeout=3000)
                    closed = True
                    break

            except Exception:

                pass

        if not closed:

            try:

                page.keyboard.press("Escape")
                closed = True

            except Exception:

                pass

        time.sleep(2)


def wait_for_message_box(page, timeout=60000):

    page.wait_for_selector(
        "//div[@contenteditable='true'][@data-tab='10']",
        timeout=timeout
    )


def open_assistnext_chat(page):

    print("Opening AssistNext chat...")

    dismiss_whatsapp_dialogs(page)

    try:

        page.goto(
            f"https://example.invalid}",
            wait_until="domcontentloaded",
            timeout=120000
        )

        dismiss_whatsapp_dialogs(page)
        wait_for_message_box(page, timeout=60000)
        return

    except Exception as direct_error:

        print(f"Direct chat open failed, falling back to contact click: {direct_error}")

    dismiss_whatsapp_dialogs(page)

    contact = page.locator(
        f"//span[@title='{CONTACT_NAME}']"
    )

    try:

        contact.click(timeout=30000)

    except Exception as click_error:

        print(f"Normal contact click failed, retrying with force after dialog cleanup: {click_error}")
        dismiss_whatsapp_dialogs(page)
        contact.click(force=True, timeout=10000)

    dismiss_whatsapp_dialogs(page)
    wait_for_message_box(page, timeout=60000)

# ================= SEND MESSAGE =================

def send_message(page, message):

    print(f"Sending: {message}")

    before_send = chat_message_state(page)

    message_box = page.locator(
        "//div[@contenteditable='true'][@data-tab='10']"
    )

    message_box.fill(message)

    time.sleep(1)

    page.keyboard.press("Enter")

    time.sleep(2)

    return before_send

# ================= MESSAGE READ HELPERS =================

def normalize_text(value):

    text = value or ""
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", " ").replace("\u2014", " ")
    text = text.replace("\xa0", " ")

    return re.sub(r"\s+", " ", text).strip().lower()


def compact_text(value):

    return re.sub(r"\s+", " ", value or "").strip()


def chat_message_state(page):

    selectors = [
        "//div[@id='main']//div[@data-pre-plain-text]",
        "//div[@id='main']//div[contains(@class,'message-in') or contains(@class,'message-out')]",
        "//div[@id='main']//div[contains(@class,'copyable-text')]",
    ]

    for selector in selectors:

        try:

            count = page.locator(selector).count()

            if count > 0:

                return {
                    "selector": selector,
                    "count": count
                }

        except Exception:

            pass

    return {
        "selector": selectors[0],
        "count": 0
    }


def chat_messages_after(page, state, limit=12):

    if not state:

        return recent_chat_messages(page, limit)

    selector = state.get("selector")
    start_count = state.get("count", 0)
    messages = []
    seen = set()

    try:

        nodes = page.locator(selector)
        count = nodes.count()
        start_index = max(0, min(start_count, count))

        for i in range(start_index, count):

            try:

                compact = compact_text(nodes.nth(i).inner_text(timeout=2000))

                if compact and compact not in seen:

                    seen.add(compact)
                    messages.append(compact)

            except Exception:

                pass

    except Exception:

        pass

    return messages[-limit:]


def recent_chat_messages(page, limit=12):

    selectors = [
        "//div[@id='main']//div[contains(@class,'message-in')]",
        "//div[@id='main']//div[contains(@class,'message-out')]",
        "//div[@id='main']//div[@data-pre-plain-text]",
        "//div[@id='main']//div[contains(@class,'copyable-text')]",
    ]

    messages = []
    seen = set()

    for selector in selectors:

        try:

            nodes = page.locator(selector)
            count = nodes.count()
            start_index = max(0, count - limit)

            for i in range(start_index, count):

                try:

                    text = nodes.nth(i).inner_text(timeout=2000)
                    compact = compact_text(text)

                    if compact and compact not in seen:

                        seen.add(compact)
                        messages.append(compact)

                except Exception:

                    pass

        except Exception:

            pass

    if not messages:

        try:

            main_text = page.locator("//div[@id='main']").inner_text(timeout=3000)
            compact = compact_text(main_text)

            if compact:

                messages.append(compact)

        except Exception:

            pass

    return messages[-limit:]


def visible_chat_text(page):

    try:

        return compact_text(page.locator("//div[@id='main']").inner_text(timeout=3000))

    except Exception:

        return ""


def text_after_last_visible(page, marker):

    chat_text = normalize_text(visible_chat_text(page))
    marker_text = normalize_text(marker)

    if not marker_text:

        return chat_text

    index = chat_text.rfind(marker_text)

    if index == -1:

        return chat_text

    return chat_text[index + len(marker_text):]

# ================= WAIT FUNCTION =================

def wait_for_reply_after(page, marker, expected_text, timeout=60, aliases=None, settle_seconds=8):

    print(f"Waiting after '{marker}' for bot reply containing: {expected_text}")

    start = time.time()
    expected_values = [expected_text] + (aliases or [])
    expected_values = [normalize_text(value) for value in expected_values if value]
    last_printed = ""

    while time.time() - start < timeout:

        if time.time() - start < settle_seconds:

            time.sleep(1)
            continue

        segment = text_after_last_visible(page, marker)

        if segment and segment != last_printed:

            print(f"\nVisible Chat After Marke/opt/portfolio/project")
            last_printed = segment

        if any(expected in segment for expected in expected_values):

            print(f"Matched expected text after {marker}: {expected_text}")
            return True

        time.sleep(3)

    return False


def wait_for_bot_reply(page, expected_text, timeout=60, aliases=None, after_state=None, settle_seconds=10):

    print(f"Waiting for bot reply containing: {expected_text}")

    start = time.time()

    already_printed = set()

    expected_values = [expected_text] + (aliases or [])
    expected_values = [normalize_text(value) for value in expected_values if value]

    while time.time() - start < timeout:

        try:

            # WhatsApp Web virtualizes messages, so DOM counts may not increase
            # even when a fresh message appears. Give the bot time to answer,
            # then fall back to scanning the currently visible chat.
            if time.time() - start < settle_seconds:

                time.sleep(1)
                continue

            recent_messages = chat_messages_after(page, after_state)

            if not recent_messages:

                recent_messages = recent_chat_messages(page)

            for msg in recent_messages:

                if msg not in already_printed:

                    print(f"\nLatest Visible Chat Messag/opt/portfolio/project")
                    already_printed.add(msg)

            combined_text = normalize_text(" ".join(recent_messages))

            if any(expected in combined_text for expected in expected_values):

                print(f"Matched expected text: {expected_text}")

                return True

        except Exception as e:

            print(f"Wait error: {e}")

        time.sleep(3)

    return False

# ================= MAIN =================

start_time = time.time()

try:

    with sync_playwright() as p:

        browser = p.chromium.launch_persistent_context(
            user_data_dir=os.path.join(
                BASE_PATH,
                "whatsapp_session"
            ),
            headless=os.environ.get("WA_HEADLESS", "false").lower() == "true"
        )

        page = browser.new_page()

        print("Opening WhatsApp Web...")

        page.goto(
            "https://example.invalid",
            wait_until="domcontentloaded",
            timeout=120000
        )

        print("Checking WhatsApp login state...")

        logged_in = False
        deadline = time.time() + 90

        while time.time() < deadline:
            try:
                if page.locator("//span[@title]").count() > 0:
                    logged_in = True
                    break
            except Exception:
                pass
            time.sleep(2)

        if not logged_in:
            # Distinguish a logged-out session (QR screen) from a load failure.
            is_qr = False
            try:
                is_qr = page.locator("canvas").count() > 0
            except Exception:
                pass
            try:
                page.screenshot(path=os.path.join(BASE_PATH, "qr.png"))
            except Exception:
                pass
            if is_qr:
                capture_screenshot(page, "session_logged_out")
                log("FAIL", "SESSION", "WhatsApp session logged out - re-link required")
                result_json(
                    "FAIL",
                    "SESSION",
                    "WhatsApp session logged out on the monitor server (192.0.2.10). "
                    "Re-scan the QR: https://example.invalid"
                )
            else:
                capture_screenshot(page, "load_timeout")
                log("FAIL", "LOAD", "WhatsApp Web did not load")
                result_json("FAIL", "LOAD", "WhatsApp Web did not load")
            try:
                browser.close()
            except Exception:
                pass
            sys.exit(1)

        print("WhatsApp loaded successfully.")

        # Logged in: clear any stale QR left by a previous logout so the /qr
        # endpoint only serves a QR when a re-link is actually needed.
        try:
            os.remove(os.path.join(BASE_PATH, "qr.png"))
        except OSError:
            pass

        open_assistnext_chat(page)

        time.sleep(5)

        # =====================================================
        # STEP 1
        # =====================================================

        step_state = send_message(page, "Hi")

        log(
            "TRACE",
            "STEP 1",
            "Sent Hi"
        )

        if not wait_for_reply_after(
            page,
            "Hi",
            "Please type your issue category",
            120,
            aliases=[
                "type your issue category",
                "select your issue category",
                "choose your issue category",
                "issue category"
            ],
            settle_seconds=15
        ):

            screenshot_path = capture_screenshot(
                page,
                "category_menu_failure"
            )

            log(
                "FAIL",
                "STEP 1",
                "Category menu not received"
            )

            result_json(
                "FAIL",
                "STEP 1",
                "Category menu not received",
                screenshot_path
            )

            sys.exit(1)

        time.sleep(3)

        # =====================================================
        # STEP 2
        # =====================================================

        step_state = send_message(page, "Hardware")

        log(
            "TRACE",
            "STEP 2",
            "Sent Hardware"
        )

        if not wait_for_reply_after(
            page,
            "Hardware",
            "Please Select your issue",
            150,
            aliases=[
                "select your issue",
                "please select your issue",
                "please select your issue from below",
                "choose your issue",
                "what are we dealing with",
                "options"
            ],
            settle_seconds=12
        ):

            screenshot_path = capture_screenshot(
                page,
                "issue_menu_failure"
            )

            log(
                "FAIL",
                "STEP 2",
                "Issue menu not received"
            )

            result_json(
                "FAIL",
                "STEP 2",
                "Issue menu not received",
                screenshot_path
            )

            sys.exit(1)

        time.sleep(3)

        # =====================================================
        # STEP 3
        # =====================================================

        step_state = send_message(
            page,
            "Hard disk/RAM/Laptop"
        )

        log(
            "TRACE",
            "STEP 3",
            "Sent issue type"
        )

        if not wait_for_reply_after(
            page,
            "Hard disk/RAM/Laptop",
            "Quick check",
            120,
            aliases=[
                "quick check",
                "what's the hardware situation",
                "what's the hardware situation?",
                "just let me know if it's your laptop",
                "laptop, hard disk, etc",
                "hardware situation"
            ],
            settle_seconds=12
        ):

            screenshot_path = capture_screenshot(
                page,
                "quick_check_failure"
            )

            log(
                "FAIL",
                "STEP 3",
                "Quick check response not received"
            )

            result_json(
                "FAIL",
                "STEP 3",
                "Quick check response not received",
                screenshot_path
            )

            sys.exit(1)

        time.sleep(3)

        # =====================================================
        # STEP 4
        # =====================================================

        step_state = send_message(
            page,
            "hard disk"
        )

        log(
            "TRACE",
            "STEP 4",
            "Sent hardware component"
        )

        if not wait_for_reply_after(
            page,
            "hard disk",
            "Secondly",
            120,
            aliases=[
                "secondly",
                "brand",
                "share the type or brand",
                "share the type or brand name"
            ],
            settle_seconds=12
        ):

            screenshot_path = capture_screenshot(
                page,
                "brand_request_failure"
            )

            log(
                "FAIL",
                "STEP 4",
                "Brand request not received"
            )

            result_json(
                "FAIL",
                "STEP 4",
                "Brand request not received",
                screenshot_path
            )

            sys.exit(1)

        time.sleep(3)

        # =====================================================
        # STEP 5
        # =====================================================

        step_state = send_message(
            page,
            "Dell"
        )

        log(
            "TRACE",
            "STEP 5",
            "Sent brand name"
        )

        # =====================================================
        # FINAL WAIT
        # =====================================================

        print(
            "Waiting for conversation reset..."
        )

        if wait_for_reply_after(
            page,
            "Dell",
            "Due to the idle state of the conversation",
            330,
            aliases=[
                "idle state of the conversation",
                "conversation is closed",
                "thanks for connecting"
            ],
            settle_seconds=20
        ):

            duration = round(
                time.time() - start_time,
                2
            )

            log(
                "SUCCESS",
                "COMPLETE",
                f"Journey completed in {duration} sec"
            )

            result_json(
                "SUCCESS",
                "COMPLETE",
                f"Journey completed in {duration} sec"
            )

            try:
                browser.close()
            except Exception:
                pass

            sys.exit(0)

        else:

            screenshot_path = capture_screenshot(
                page,
                "conversation_reset_failure"
            )

            log(
                "FAIL",
                "FINAL",
                "Conversation reset message not received"
            )

            result_json(
                "FAIL",
                "FINAL",
                "Conversation reset message not received",
                screenshot_path
            )

            sys.exit(1)

except Exception as e:

    print(f"FATAL ERROR: {e}")

    screenshot_path = ""

    try:

        screenshot_path = capture_screenshot(page, "fatal_error")

    except Exception:

        pass

    log(
        "FAIL",
        "FATAL",
        str(e)
    )

    result_json(
        "FAIL",
        "FATAL",
        str(e),
        screenshot_path
    )

    sys.exit(1)
