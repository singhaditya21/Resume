from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

import requests

from utils.config import settings


SECRET_PATTERNS = REDACTED_SECRET
    (re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]+", re.IGNORECASE), "Bearer [REDACTED]"),
    (re.compile(r'("Authorization"\s*:\s*")[^"]+(")', re.IGNORECASE), r"\1[REDACTED]\2"),
    (re.compile(r"(api[-_ ]?key\s*[:=]\s*)[^\s,;]+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(token\s*[:=]\s*)[^\s,;]+", re.IGNORECASE), r"\1[REDACTED]"),
]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _redact(value: Any) -> str:
    if isinstance(value, str):
        text = value
    else:
        text = json.dumps(value, ensure_ascii=True, default=str)
    for pattern, replacement in SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _truncate(value: Any, limit: int = 3500) -> str:
    text = _redact(value)
    if len(text) <= limit:
        return text
    return text[:limit] + "\n...[truncated]"


def _json_from_model_text(text: str) -> dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?", "", stripped, flags=re.IGNORECASE).strip()
        stripped = re.sub(r"```$", "", stripped).strip()
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start == -1 or end == -1 or end <= start:
            raise
        parsed = json.loads(stripped[start : end + 1])
    return parsed if isinstance(parsed, dict) else {}


def _provider_ready() -> tuple[bool, str]:
    if settings.ai_provider == "azure_openai":
        ready = bool(
            settings.azure_openai_endpoint
            and settings.azure_openai_api_key
            and settings.azure_openai_deployment
        )
        return ready, "azure_openai"
    if settings.ai_provider == "openai":
        ready = bool(settings.openai_api_key and settings.openai_model)
        return ready, "openai"
    return False, "disabled"


def _chat_completion(messages: list[dict[str, str]], *, temperature: float = 0.2) -> dict[str, Any]:
    ready, provider = _provider_ready()
    if not ready:
        raise RuntimeError(f"AI provider is not configured: {provider}")

    payload: dict[str, Any] = {
        "messages": messages,
        "temperature": temperature,
        "response_format": {"type": "json_object"},
    }

    if provider == "azure_openai":
        url = (
            f"{settings.azure_openai_endpoint}/openai/deployments/"
            f"{settings.azure_openai_deployment}/chat/completions"
        )
        response = requests.post(
            url,
            params={"api-version": settings.azure_openai_api_version},
            headers={
                "api-key": settings.azure_openai_api_key,
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=settings.ai_timeout_seconds,
        )
    else:
        payload["model"] = settings.openai_model
        response = requests.post(
            f"{settings.openai_base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.openai_api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=settings.ai_timeout_seconds,
        )

    response.raise_for_status()
    body = response.json()
    content = body["choices"][0]["message"]["content"]
    return _json_from_model_text(content)


def _fallback_dashboard_insight(payload: dict[str, Any]) -> dict[str, Any]:
    metrics = payload.get("metrics") or {}
    live_status = payload.get("live_status") or {}
    failure_trends = payload.get("failure_trends") or {}

    failed = int(metrics.get("failed_executions") or 0)
    recovered = int(metrics.get("auto_recovered_failures") or 0)
    total = int(metrics.get("total_scheduler_runs") or 0)
    availability = float(metrics.get("bot_availability_pct") or 0)
    overdue = bool(live_status.get("overdue"))

    if overdue or availability < 75 or failed >= 3:
        severity = "critical"
        title = "Immediate attention recommended"
    elif failed or recovered or availability < 95:
        severity = "warning"
        title = "Monitor closely"
    else:
        severity = "healthy"
        title = "Automation is stable"

    labels = failure_trends.get("labels") or []
    values = failure_trends.get("values") or []
    paired = sorted(zip(labels, values), key=lambda item: item[1], reverse=True)
    top_failure = next((label for label, value in paired if value), "No dominant failure step")

    summary = (
        f"Across the selected window, {total} scheduled runs were reviewed with "
        f"{failed} failed executions, {recovered} auto-recovered runs, and "
        f"{availability:.1f}% availability."
    )
    if overdue:
        summary += " The next scheduled run appears overdue."

    return {
        "source": "rule_based",
        "provider": "fallback",
        "enabled": False,
        "generated_at": _utc_now(),
        "severity": severity,
        "title": title,
        "summary": summary,
        "likely_causes": [
            top_failure,
            "WhatsApp Web session or UI state changed" if failed else "No active failure pattern detected",
            "n8n retry path recovered some failures" if recovered else "Retry path not currently active",
        ],
        "recommended_actions": [
            "Check the latest n8n execution logs and WhatsApp session state.",
            "Run the monitor endpoint manually if the dashboard shows overdue or failed runs.",
            "Configure Azure OpenAI/OpenAI environment variables for AI-generated root-cause analysis.",
        ],
        "confidence": "medium",
    }


def build_dashboard_insight(payload: dict[str, Any]) -> dict[str, Any]:
    fallback = _fallback_dashboard_insight(payload)
    ready, provider = _provider_ready()
    if not ready:
        return fallback

    prompt_payload = {
        "metrics": payload.get("metrics") or {},
        "live_status": payload.get("live_status") or {},
        "health": payload.get("health") or {},
        "failure_trends": payload.get("failure_trends") or {},
        "retry_trends": payload.get("retry_trends") or {},
        "recent_history": payload.get("recent_history") or [],
    }
    messages = [
        {
            "role": "system",
            "content": (
                "You are an SRE assistant for a WhatsApp bot monitoring system. "
                "Return compact JSON only. Do not invent data. Use the supplied metrics only."
            ),
        },
        {
            "role": "user",
            "content": (
                "Create an operational dashboard insight with keys: severity "
                "(healthy, warning, or critical), title, summary, likely_causes "
                "(array max 3), recommended_actions (array max 3), confidence. "
                f"Data: {_truncate(prompt_payload, 6000)}"
            ),
        },
    ]

    try:
        insight = _chat_completion(messages, temperature=0.1)
    except Exception as exc:
        fallback["error"] = f"AI unavailable, using fallback: {exc}"
        return fallback

    return {
        "source": "ai",
        "provider": provider,
        "enabled": True,
        "generated_at": _utc_now(),
        "severity": str(insight.get("severity") or fallback["severity"]).lower(),
        "title": str(insight.get("title") or fallback["title"]),
        "summary": str(insight.get("summary") or fallback["summary"]),
        "likely_causes": _list_or_default(insight.get("likely_causes"), fallback["likely_causes"]),
        "recommended_actions": _list_or_default(insight.get("recommended_actions"), fallback["recommended_actions"]),
        "confidence": str(insight.get("confidence") or "medium"),
    }


def _fallback_assistant_answer(payload: dict[str, Any], question: str) -> dict[str, Any]:
    insight = _fallback_dashboard_insight(payload)
    metrics = payload.get("metrics") or {}
    live_status = payload.get("live_status") or {}
    health = payload.get("health") or {}
    recent_history = payload.get("recent_history") or []
    lower_question = question.lower()

    total = int(metrics.get("total_scheduler_runs") or 0)
    failed = int(metrics.get("failed_executions") or 0)
    recovered = int(metrics.get("auto_recovered_failures") or 0)
    availability = float(metrics.get("bot_availability_pct") or 0)
    last_failure = metrics.get("last_failure_time") or "not available"
    session = live_status.get("session_status") or "Unknown"
    next_run = live_status.get("next_expected_run") or "not available"
    health_status = health.get("status") or metrics.get("current_monitoring_status") or "Unknown"

    if any(word in lower_question for word in ("fail", "failure", "critical", "down", "issue")):
        answer = (
            f"The selected window is {health_status}. I found {failed} failed executions "
            f"out of {total} scheduled runs, with {availability:.1f}% availability. "
            f"The latest failure time is {last_failure}."
        )
        bullets = [
            f"Most likely pattern: {insight['likely_causes'][0]}",
            f"Auto-recovered failures: {recovered}",
            f"WhatsApp session state: {session}",
        ]
    elif any(word in lower_question for word in ("next", "action", "do", "fix", "recommend")):
        answer = "The safest next action is to verify the latest n8n execution, then confirm the WhatsApp session and monitor API health."
        bullets = insight["recommended_actions"]
    elif any(word in lower_question for word in ("session", "login", "qr", "whatsapp")):
        answer = f"The dashboard currently reports the WhatsApp linked-device session as {session}."
        bullets = [
            "If the session is logged out, open the QR endpoint and re-link the device.",
            "If the session is logged in but runs fail, check WhatsApp Web dialogs or bot response timing.",
            "Run /run-monitor manually only when no scheduled execution is active.",
        ]
    elif any(word in lower_question for word in ("schedule", "scheduler", "run time", "trigger")):
        answer = f"The scheduler is {metrics.get('current_scheduler_status', 'Unknown')}. The next expected run is {next_run}."
        bullets = [
            f"Expected interval: {metrics.get('expected_interval_minutes', 'unknown')} minutes",
            f"Overdue: {'yes' if live_status.get('overdue') else 'no'}",
            "Check n8n executions if the next run becomes overdue.",
        ]
    else:
        answer = insight["summary"]
        bullets = insight["recommended_actions"]

    return {
        "source": "rule_based",
        "provider": "fallback",
        "enabled": False,
        "generated_at": _utc_now(),
        "question": question,
        "answer": answer,
        "bullets": bullets[:4],
        "recommended_actions": insight["recommended_actions"],
        "confidence": "medium",
        "recent_execution_count": len(recent_history),
    }


def build_assistant_answer(payload: dict[str, Any], question: str) -> dict[str, Any]:
    question = (question or "").strip()
    if not question:
        question = "Summarize current WhatsApp bot monitoring health and next action."

    fallback = _fallback_assistant_answer(payload, question)
    ready, provider = _provider_ready()
    if not ready:
        return fallback

    prompt_payload = {
        "question": question,
        "metrics": payload.get("metrics") or {},
        "live_status": payload.get("live_status") or {},
        "health": payload.get("health") or {},
        "failure_trends": payload.get("failure_trends") or {},
        "retry_trends": payload.get("retry_trends") or {},
        "recent_history": payload.get("recent_history") or [],
    }
    messages = [
        {
            "role": "system",
            "content": (
                "You are an AI assistant embedded in an operations dashboard for "
                "WhatsApp bot monitoring. Answer using only supplied dashboard data. "
                "Return compact JSON only with keys: answer, bullets, recommended_actions, confidence."
            ),
        },
        {
            "role": "user",
            "content": (
                "Answer the operator question in a clear, action-oriented way. "
                "Use no secrets and do not invent data. "
                f"Dashboard context: {_truncate(prompt_payload, 7000)}"
            ),
        },
    ]

    try:
        result = _chat_completion(messages, temperature=0.15)
    except Exception as exc:
        fallback["error"] = f"AI unavailable, using fallback: {exc}"
        return fallback

    return {
        "source": "ai",
        "provider": provider,
        "enabled": True,
        "generated_at": _utc_now(),
        "question": question,
        "answer": str(result.get("answer") or fallback["answer"]),
        "bullets": _list_or_default(result.get("bullets"), fallback["bullets"]),
        "recommended_actions": _list_or_default(result.get("recommended_actions"), fallback["recommended_actions"]),
        "confidence": str(result.get("confidence") or "medium"),
        "recent_execution_count": len(payload.get("recent_history") or []),
    }


def _list_or_default(value: Any, default: list[str]) -> list[str]:
    if isinstance(value, list):
        cleaned = [str(item) for item in value if str(item).strip()]
        return cleaned[:3] or default
    return default


def _classify_failure(text: str) -> tuple[str, str]:
    lowered = text.lower()
    if "logged out" in lowered or "/qr" in lowered or "qr" in lowered:
        return "WhatsApp session logged out", "Open the QR page and re-link the WhatsApp session."
    if "intercepts pointer events" in lowered or "dialog detected" in lowered:
        return "WhatsApp dialog blocked automation", "Dismiss the WhatsApp dialog and rerun the journey."
    if "category menu" in lowered or "please type your issue" in lowered:
        return "Bot category menu was not detected", "Check AssistNext response delay and WhatsApp chat visibility."
    if "issue menu" in lowered or "select your issue" in lowered:
        return "Issue menu was not detected", "Confirm the bot still accepts the configured Hardware path."
    if "quick check" in lowered:
        return "Hardware quick-check prompt was not detected", "Validate the bot prompt wording and response timing."
    if "timeout" in lowered or "timed out" in lowered:
        return "Automation timeout", "Review WhatsApp Web responsiveness and n8n timeout settings."
    return "Failure reason needs review", "Open the n8n execution and monitor logs for full trace details."


def _fallback_failure_summary(payload: dict[str, Any]) -> dict[str, Any]:
    text = _truncate(payload, 6000)
    cause, action = _classify_failure(text)
    case_id = payload.get("case_id") or ""

    return {
        "case_id": str(case_id),
        "source": "rule_based",
        "provider": "fallback",
        "enabled": False,
        "generated_at": _utc_now(),
        "title": "AI-style failure summary",
        "summary": "The monitoring journey failed after the retry path and an incident was created.",
        "probable_cause": cause,
        "impact": "The AssistNext WhatsApp bot health check could not be confirmed for this scheduled run.",
        "recommended_action": action,
        "operator_note": f"Review BusinessNEXT case {case_id} and the n8n execution trace." if case_id else "Review the n8n execution trace.",
        "confidence": "medium",
    }


def build_failure_summary(payload: dict[str, Any]) -> dict[str, Any]:
    fallback = _fallback_failure_summary(payload)
    ready, provider = _provider_ready()
    if not ready:
        return fallback

    messages = [
        {
            "role": "system",
            "content": (
                "You summarize failures for a WhatsApp bot monitoring system. "
                "Return JSON only. Do not expose secrets. Do not invent incident IDs."
            ),
        },
        {
            "role": "user",
            "content": (
                "Create a concise failure analysis with keys: title, summary, "
                "probable_cause, impact, recommended_action, operator_note, confidence. "
                f"Failure payload: {_truncate(payload, 7000)}"
            ),
        },
    ]

    try:
        result = _chat_completion(messages, temperature=0.1)
    except Exception as exc:
        fallback["error"] = f"AI unavailable, using fallback: {exc}"
        return fallback

    return {
        "case_id": str(payload.get("case_id") or ""),
        "source": "ai",
        "provider": provider,
        "enabled": True,
        "generated_at": _utc_now(),
        "title": str(result.get("title") or fallback["title"]),
        "summary": str(result.get("summary") or fallback["summary"]),
        "probable_cause": str(result.get("probable_cause") or fallback["probable_cause"]),
        "impact": str(result.get("impact") or fallback["impact"]),
        "recommended_action": str(result.get("recommended_action") or fallback["recommended_action"]),
        "operator_note": str(result.get("operator_note") or fallback["operator_note"]),
        "confidence": str(result.get("confidence") or "medium"),
    }
