from playwright.sync_api import sync_playwright
import time
from datetime import datetime

# ================= CONFIG =================
CONTACT_NAME = "PORTFOLIO_REDACTED"
TIMEOUT = 30
LOG_FILE = "logs.txt"

# ================= LOG FUNCTION =================
def log(status, step, reason=""):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now()} | {status} | {step} | {reason}\n")

# ================= WAIT FOR BOT RESPONSE =================
def wait_for_bot_reply(page, expected_text, timeout=30):

    start = time.time()
    previous_message = ""

    while time.time() - start < timeout:

        try:
            messages = page.locator("//div[contains(@class,'message-in')]")
            count = messages.count()

            if count > 0:

                last_msg = messages.nth(count - 1).inner_text()

                if last_msg != previous_message:
                    print(f"\nLast Bot Messag/opt/portfolio/project")
                    previous_message = last_msg

                if expected_text.lower() in last_msg.lower():
                    return True

        except Exception as e:
            print(f"Error while checking reply: {e}")

        time.sleep(2)

    return False

# ================= MAIN SCRIPT =================
with sync_playwright() as p:

    browser = p.chromium.launch_persistent_context(
        user_data_dir="PORTFOLIO_REDACTED",
        headless=False
    )

    page = browser.new_page()

    print("Opening WhatsApp Web...")
    page.goto("https://example.invalid")

    # ================= WAIT FOR LOAD =================
    print("Waiting for WhatsApp to load...")
    page.wait_for_selector("//span[@title]", timeout=60000)

    # ================= OPEN CHAT =================
    print("Opening AssistNext chat...")
    page.locator(f"//span[@title='{CONTACT_NAME}']").click()

    time.sleep(3)

    # ================= MESSAGE BOX =================
    message_box = page.locator("//div[@contenteditable='true'][@data-tab='10']")

    # ================= STEP 1 =================
    print("Sending: Hi")

    message_box.fill("Hi")
    page.keyboard.press("Enter")

    log("INFO", "Step 1", "Sent Hi")

    # ================= STEP 2 =================
    print("Waiting for category menu...")

    if wait_for_bot_reply(page, "Please type your issue category", TIMEOUT):

        print("✅ Category menu received")
        log("SUCCESS", "Step 2", "Category menu received")

        # ================= STEP 3 =================
        print("Sending: Hardware")

        message_box.fill("Hardware")
        page.keyboard.press("Enter")

        log("SUCCESS", "Step 3", "Sent Hardware")

    else:

        print("❌ Category menu not received")
        log("FAIL", "Step 2", "Category menu not received")

        input("Press Enter to exit")
        exit()

    # ================= STEP 4 =================
    print("Waiting for issue selection message...")

    if wait_for_bot_reply(page, "Please Select your issue", TIMEOUT):

        print("✅ Issue selection message received")
        log("SUCCESS", "Step 4", "Issue selection message received")

        try:

            # ================= CLICK OPTIONS =================
            print("Clicking Options button...")

            page.locator("text=Options").first.click()

            time.sleep(3)

            # ================= SELECT EXACT OPTION =================
            print("Selecting exact option...")

            option_text = page.locator("text='Hard disk/RAM/Laptop'").first

            option_text.scroll_into_view_if_needed()

            time.sleep(1)

            option_text.click(force=True)

            time.sleep(2)

            print("✅ Correct option selected")
            log("SUCCESS", "Step 5", "Selected Hard disk/RAM/Laptop")

            # ================= CLICK GREEN SEND BUTTON =================
            print("Clicking green send button...")

            dialog = page.locator("//div[@role='dialog']")

            # Find all buttons inside popup
            popup_buttons = dialog.locator("button")

            button_count = popup_buttons.count()

            print(f"Buttons found inside dialog: {button_count}")

            # Get last button inside popup
            green_button = popup_buttons.nth(button_count - 1)

            # Scroll into view
            green_button.scroll_into_view_if_needed()

            time.sleep(1)

            # Use bounding box click (MOST RELIABLE HERE)
            box = green_button.bounding_box()

            if box:

                page.mouse.click(
                    box["x"] + box["width"] / 2,
                    box["y"] + box["height"] / 2
                )

                print("✅ Green send button clicked")
                log("SUCCESS", "Step 6", "Clicked green send button")

            else:

                print("❌ Green button not found")
                log("FAIL", "Step 6", "Green button not found")

                input("Press Enter to exit")
                exit()

            # ================= WAIT FOR NEXT BOT REPLY =================
            print("Waiting for bot reply after option selection...")

            # Replace keyword later
            if wait_for_bot_reply(page, "employee", TIMEOUT):

                print("✅ Bot replied after option selection")
                log("SUCCESS", "Step 7", "Bot replied after option selection")

            else:

                print("❌ No bot reply after option selection")
                log("FAIL", "Step 7", "No bot reply after option selection")

        except Exception as e:

            print(f"❌ Failed while selecting option: {e}")
            log("FAIL", "Step 5", str(e))

    else:

        print("❌ Issue selection message not received")
        log("FAIL", "Step 4", "Issue selection message not received")

    # ================= FLOW END =================
    print("Flow completed")

    input("Press Enter to close")