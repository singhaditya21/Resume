#!/bin/bash
# Daily backup of the WhatsApp Web session profile so a corrupted/lost profile
# can be restored without re-scanning the QR. Keeps the last 7 backups.
# Installed at /biztech/wa-monitor/backup.sh and run by cron (see README/cron).
set -e
cd /biztech/wa-monitor
mkdir -p backups
ts=$(date +%Y%m%d-%H%M%S)
tar -czf "backups/whatsapp_session-$ts.tgz" whatsapp_session
# retain only the newest 7
ls -1t backups/whatsapp_session-*.tgz | tail -n +8 | xargs -r rm -f
echo "$(date) backed up whatsapp_session -> backups/whatsapp_session-$ts.tgz"
