from flask import Flask, jsonify, send_file
import subprocess
import os
import sys
import json
import threading
from datetime import datetime

app = Flask(__name__)

# Resolve everything relative to this file so it runs on Linux or Windows.
BASE = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable or "python3"
MONITOR = os.path.join(BASE, "monitor.py")
SUMMARY = os.path.join(BASE, "summary_generator.py")

PORT = int(os.environ.get("WA_PORT", "5000"))
# A full WhatsApp journey can take several minutes; cap it so the HTTP call
# never hangs forever (the original had no timeout).
RUN_TIMEOUT = int(os.environ.get("WA_RUN_TIMEOUT", "600"))
SUMMARY_TIMEOUT = int(os.environ.get("WA_SUMMARY_TIMEOUT", "120"))
WA_BASE = os.environ.get("WA_BASE", BASE)

# Only one Playwright journey may use the WhatsApp session profile at a time.
# Two Chromium instances on the same user-data-dir corrupt it and force a
# re-login, so /run-monitor is serialized.
RUN_LOCK = threading.Lock()


def _run(script, timeout):
    try:
        result = subprocess.run(
            [PYTHON, script],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "status": "SUCCESS" if result.returncode == 0 else "FAIL",
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except subprocess.TimeoutExpired:
        return {
            "status": "FAIL",
            "reason": "timeout",
            "stdout": "",
            "stderr": "Engine timed out after {}s".format(timeout),
        }
    except Exception as e:  # pragma: no cover - defensive
        return {"status": "ERROR", "message": str(e)}


@app.route("/run-monitor", methods=["GET"])
def run_monitor():
    # Non-blocking: if a run is already in progress, report BUSY so the caller's
    # retry handles it instead of starting a conflicting Chromium.
    if not RUN_LOCK.acquire(blocking=False):
        return jsonify({"status": "BUSY", "reason": "Another monitor run is already in progress"})
    try:
        return jsonify(_run(MONITOR, RUN_TIMEOUT))
    finally:
        RUN_LOCK.release()


@app.route("/run-summary", methods=["GET"])
def run_summary():
    payload = _run(SUMMARY, SUMMARY_TIMEOUT)
    # The summary just renders a report; treat a non-timeout, non-zero exit as
    # still delivering output (matches previous behaviour).
    if payload.get("status") == "FAIL" and payload.get("reason") != "timeout":
        payload["status"] = "SUCCESS"
    return jsonify(payload)


@app.route("/qr", methods=["GET"])
def qr():
    # Serves the most recently captured QR (written by monitor.py when it finds
    # the session logged out). Used by the logout alert to re-link the server.
    path = os.path.join(WA_BASE, "qr.png")
    if os.path.exists(path):
        return send_file(path, mimetype="image/png")
    return jsonify({
        "status": "no_qr",
        "message": "No QR available (session is logged in, or no recent logout captured).",
    }), 404


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "base": BASE, "port": PORT, "busy": RUN_LOCK.locked()})


@app.route("/stats", methods=["GET"])
def stats():
    """Per-step bot response latency derived from the journey timings in logs.txt."""
    path = os.path.join(os.environ.get("WA_BASE", BASE), "logs.txt")
    order = ["STEP 1", "STEP 2", "STEP 3", "STEP 4", "STEP 5", "COMPLETE"]
    labels = ["Category menu", "Issue menu", "Quick check", "Brand prompt", "Idle reset"]
    sums = [0.0] * 5
    counts = [0] * 5
    journeys = 0
    cur = {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                step = rec.get("step")
                try:
                    ts = datetime.fromisoformat(rec.get("timestamp", ""))
                except Exception:
                    continue
                if step == "STEP 1":
                    cur = {}
                if step in order:
                    cur[step] = ts
                if step == "COMPLETE":
                    for i in range(5):
                        a = cur.get(order[i])
                        b = cur.get(order[i + 1])
                        if a and b and (b - a).total_seconds() >= 0:
                            sums[i] += (b - a).total_seconds()
                            counts[i] += 1
                    journeys += 1
                    cur = {}
    except FileNotFoundError:
        pass
    steps = [
        {"label": labels[i], "avg_seconds": round(sums[i] / counts[i], 1) if counts[i] else 0, "samples": counts[i]}
        for i in range(5)
    ]
    return jsonify({"journeys": journeys, "steps": steps})


if __name__ == "__main__":
    print(app.url_map)
    app.run(host="0.0.0.0", port=PORT)
