import json
import os
from datetime import datetime

import requests


CASE_API_TOKEN_ENV = REDACTED_SECRET
def create_case(reason):

    token = REDACTED_SECRET
    if not token:

        print(f"Missing required environment variable: {CASE_API_TOKEN_ENV}")

        return "CASE_API_TOKEN_MISSING"

    now = datetime.now().strftime("%d-%m-%Y %I:%M:%S %p")

    url = "https://example.invalid"

    payload = json.dumps([
      {
        "ItemType": "Case",
        "ProcessMode": "create",
        "OutputFieldList": [
          "CaseID",
          "STATUSCODE"
        ],
        "ObjectData": {
          "StatusCode": "8",
          "SubCategory1": "112",
          "Cas_ex2_2": "8236",
          "Cas_ex5_36": "High",
          "Priority": "1",
          "CurrentOwner": "PORTFOLIO_REDACTED",
          "cas_ex6_93": "BUSINESSNEXT",
          "Cas_ex1_14": "Noida Local",
          "Cas_ex1_13": "Performance Bug",
          "Category": "25",
          "SubCategory": "35",
          "cas_ex3_110": "#Biztech-ROW",
          "AssignedToName": "3701",

          "Subject": f"AssistNext Failure | {now}",

          "Details": f"""
AssistNext monitoring automation detected failure.

Timestamp: {now}

Failure Reason:
{reason}
""",

          "Product": "CRMNEXT",
          "LAYOUTID": 1023
        }
      }
    ])

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}"
    }

    response = requests.request(
        "POST",
        url,
        headers=headers,
        data=payload
    )

    print("Status Code:", response.status_code)

    print("Raw Response:")
    print(response.text)

    try:

        response_json = response.json()

        case_id = response_json[0]["Result"]["CaseID"][0]

        print(f"\nIncident ID: {case_id}")

        return case_id

    except Exception as e:

        print("JSON Parsing Failed")
        print(str(e))

        return "CASE_API_FAILED"
