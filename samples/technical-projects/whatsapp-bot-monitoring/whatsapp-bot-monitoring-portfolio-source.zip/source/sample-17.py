from __future__ import annotations

from flask import Blueprint, redirect, render_template, url_for

from utils.config import settings

web_bp = Blueprint("web", __name__)


@web_bp.get("/")
def home():
    return redirect(url_for("web.dashboard"))


@web_bp.get("/dashboard")
def dashboard():
    return render_template(
        "dashboard.html",
        refresh_interval=settings.refresh_interval_seconds,
        dashboard_port=settings.dashboard_port,
        n8n_base_url=settings.n8n_base_url,
        n8n_public_url=settings.n8n_public_url,
        timezone=settings.timezone,
        expected_interval_minutes=settings.expected_interval_minutes,
        asset_version="20260618-1",
    )
