from __future__ import annotations

import logging
from collections import Counter, defaultdict
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from services.health_service import assess_health
from services.repositories import ExecutionRepository, ExecutionRecord, WorkflowRecord
from utils.config import settings
from utils.parsing import isoformat


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _dashboard_timezone():
    try:
        return ZoneInfo(settings.timezone)
    except ZoneInfoNotFoundError:
        return timezone.utc


def _window_start(window_days: int) -> datetime:
    now = _now_utc()
    if window_days == 0:
        local_now = now.astimezone(_dashboard_timezone())
        local_start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
        return local_start.astimezone(timezone.utc)
    return now - timedelta(days=max(1, window_days))


def _status_bucket(status: str) -> str:
    normalized = (status or "").strip().lower()
    if normalized in {"success", "completed", "done", "succeeded"}:
        return "success"
    if normalized in {"error", "failed", "failure", "crashed"}:
        return "failed"
    if normalized in {"canceled", "cancelled"}:
        return "canceled"
    if normalized in {"running", "executing", "in_progress", "waiting", "new"}:
        return "running"
    return "unknown"


def _failure_family(message: str | None, status: str) -> str:
    text = f"{message or ''} {status or ''}".lower()
    buckets = [
        ("authentication", ["auth", "login", "credential", "session"]),
        ("network", ["network", "timeout", "dns", "connection", "socket"]),
        ("browser", ["playwright", "selenium", "browser", "webpage", "page"]),
        ("workflow", ["workflow", "node", "trigger"]),
        ("validation", ["invalid", "validation", "schema", "format"]),
    ]
    for label, needles in buckets:
        if any(needle in text for needle in needles):
            return label
    return "other"


def _failure_step(message: str | None, status: str) -> str:
    """Map a failure to the WhatsApp journey step that broke."""
    text = f"{message or ''} {status or ''}".lower()
    steps = [
        ("Session logged out", ["logged out", "re-scan", "/qr", " session"]),
        ("WhatsApp load", ["did not load", "whatsapp web did not", "load timeout"]),
        ("Step 1: Category menu", ["category menu", "please type your issue"]),
        ("Step 2: Issue menu", ["issue menu", "select your issue"]),
        ("Step 3: Quick check", ["quick check"]),
        ("Step 4: Brand", ["brand request", "brand", "secondly"]),
        ("Step 5: Idle reset", ["idle", "conversation reset", "conversation is closed"]),
        ("Engine error", ["fatal", "timed out", "timeout", "error executing"]),
    ]
    for label, needles in steps:
        if any(n in text for n in needles):
            return label
    return "Other"


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "N/A"
    total = int(round(seconds))
    if total < 60:
        return f"{total}s"
    minutes, sec = divmod(total, 60)
    if minutes < 60:
        return f"{minutes}m {sec}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m"


def _serialize_execution(execution: ExecutionRecord, workflow_status: str = "unknown") -> dict[str, Any]:
    retry_status = "No Retry"
    if execution.retry_of:
        retry_status = "Recovered" if execution.retry_success_id or _status_bucket(execution.status) == "success" else "Retrying"
    elif execution.retry_success_id:
        retry_status = "Recovered"

    return {
        "execution_id": execution.execution_id,
        "timestamp": isoformat(execution.started_at or execution.finished_at),
        "status": _status_bucket(execution.status),
        "status_label": execution.status,
        "duration_seconds": execution.duration_seconds,
        "duration": _format_duration(execution.duration_seconds),
        "retry_status": retry_status,
        "failure_reason": execution.error_message or "",
        "workflow_name": execution.workflow_name,
        "workflow_status": workflow_status,
        "workflow_id": execution.workflow_id or "",
        "retry_of": execution.retry_of or "",
    }


@dataclass
class Snapshot:
    generated_at: datetime
    window_days: int
    workflows: list[WorkflowRecord]
    executions: list[ExecutionRecord]
    workflow_index: dict[str, WorkflowRecord]
    summary: dict[str, Any]
    live_status: dict[str, Any]
    retry_trends: dict[str, Any]
    failure_trends: dict[str, Any]
    execution_trends: dict[str, Any]
    alerts_trends: dict[str, Any]
    duration_trends: dict[str, Any]
    history_rows: list[dict[str, Any]]
    health: dict[str, Any]


class DashboardService:
    def __init__(self, repository: ExecutionRepository, cache_seconds: int = 15) -> None:
        self.repository = repository
        self.cache_seconds = cache_seconds
        self.logger = logging.getLogger(self.__class__.__name__)
        self._snapshots: dict[int, Snapshot] = {}
        self._snapshot_times: dict[int, datetime] = {}
        self._last_good: dict[int, Snapshot] = {}
        self._lock = Lock()

    def source_healthy(self) -> bool:
        try:
            return bool(self.repository.health_check())
        except Exception:
            self.logger.warning("Data source health check failed", exc_info=True)
            return False

    def _normalize_window_days(self, window_days: int | None = None) -> int:
        if window_days is None:
            window_days = settings.window_days
        try:
            normalized = int(window_days)
        except (TypeError, ValueError):
            return max(1, settings.window_days)
        if normalized == 0:
            return 0
        return max(1, normalized)

    def get_snapshot(self, force_refresh: bool = False, window_days: int | None = None) -> Snapshot:
        normalized_window_days = self._normalize_window_days(window_days)
        now = _now_utc()
        with self._lock:
            snapshot = self._snapshots.get(normalized_window_days)
            snapshot_time = self._snapshot_times.get(normalized_window_days)
            if (
                not force_refresh
                and snapshot is not None
                and snapshot_time is not None
                and (now - snapshot_time).total_seconds() < self.cache_seconds
            ):
                return snapshot

            try:
                snapshot = self._build_snapshot(normalized_window_days)
                self._last_good[normalized_window_days] = snapshot
            except Exception:
                self.logger.exception("Failed to build snapshot from data source")
                snapshot = self._degraded_snapshot(self._last_good.get(normalized_window_days), normalized_window_days)
            self._snapshots[normalized_window_days] = snapshot
            self._snapshot_times[normalized_window_days] = now
            return snapshot

    def _degraded_snapshot(self, previous: Snapshot | None, window_days: int) -> Snapshot:
        """A valid snapshot that honestly reports the data source is unreachable.

        Reuses the last good data (marked stale) when available so the UI keeps
        context; otherwise returns an empty-but-valid snapshot.
        """
        if previous is not None:
            live = dict(previous.live_status)
            live["n8n_connected"] = False
            live["stale"] = True
            health = dict(previous.health)
            health["status"] = "CRITICAL"
            checks = list(health.get("checks", []))
            checks.insert(0, {"name": "n8n connectivity", "status": "critical",
                              "detail": "Unable to reach n8n API; showing last known data"})
            health["checks"] = checks
            summary = dict(previous.summary)
            summary["current_monitoring_status"] = "Disconnected"
            return replace(previous, generated_at=_now_utc(), summary=summary,
                           live_status=live, health=health)

        summary = {
            "generated_at": isoformat(_now_utc()),
            "source": "n8n",
            "window_days": window_days,
            "total_scheduler_runs": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "auto_recovered_failures": 0,
            "critical_failures": 0,
            "email_alerts_sent": 0,
            "bot_availability_pct": 0.0,
            "REDACTED_OPAQUE_VALUE": 0.0,
            "average_execution_duration": "N/A",
            "last_successful_run": None,
            "last_failure_time": None,
            "last_execution_time": None,
            "current_monitoring_status": "Disconnected",
            "current_scheduler_status": "Unknown",
            "workflow_count": 0,
            "active_workflows": 0,
            "recent_execution_count_7d": 0,
        }
        live = {
            "n8n_connected": False,
            "scheduler_active": False,
            "flask_api_healthy": True,
            "stale": True,
            "last_execution_timestamp": None,
            "last_successful_run": None,
            "last_failure_time": None,
            "total_workflows": 0,
            "active_workflows": 0,
        }
        health = {
            "status": "CRITICAL",
            "score": 0,
            "checks": [{"name": "n8n connectivity", "status": "critical", "detail": "Unable to reach n8n API"}],
            "recommendations": ["Verify N8N_BASE_URL and N8N_API_KEY and that n8n is running."],
        }
        return Snapshot(
            generated_at=_now_utc(),
            window_days=window_days,
            workflows=[],
            executions=[],
            workflow_index={},
            summary=summary,
            live_status=live,
            retry_trends={"labels": [], "retried": [], "recovered": []},
            failure_trends={"labels": ["other"], "values": [0]},
            execution_trends={"labels": [], "success": [], "failure": []},
            alerts_trends={"labels": ["Success Alerts", "Failure Alerts", "Recovery Alerts"], "values": [0, 0, 0]},
            duration_trends={"labels": [], "values": []},
            history_rows=[],
            health=health,
        )

    def _build_snapshot(self, window_days: int) -> Snapshot:
        workflows = self.repository.get_workflows()
        executions = self.repository.get_executions()
        workflow_index = {workflow.workflow_id: workflow for workflow in workflows if workflow.workflow_id}
        summary = self._build_summary(executions, workflows, workflow_index, window_days)
        live_status = self._build_live_status(summary, workflows, executions)
        retry_trends = self._build_retry_trends(executions, window_days)
        failure_trends = self._build_failure_trends(executions, window_days)
        execution_trends = self._build_execution_trends(executions, window_days)
        alerts_trends = self._build_alerts_trends(summary)
        duration_trends = self._build_duration_trends(executions, window_days)
        history_rows = self._build_history_rows(executions, workflow_index, window_days)
        health_assessment = assess_health(summary, live_status)
        health = {
            "status": health_assessment.status,
            "score": health_assessment.score,
            "checks": health_assessment.checks,
            "recommendations": health_assessment.recommendations,
        }
        summary["current_monitoring_status"] = health_assessment.status
        summary["health_score"] = health_assessment.score

        return Snapshot(
            generated_at=_now_utc(),
            window_days=window_days,
            workflows=workflows,
            executions=executions,
            workflow_index=workflow_index,
            summary=summary,
            live_status=live_status,
            retry_trends=retry_trends,
            failure_trends=failure_trends,
            execution_trends=execution_trends,
            alerts_trends=alerts_trends,
            duration_trends=duration_trends,
            history_rows=history_rows,
            health=health,
        )

    def _filter_executions(self, executions: list[ExecutionRecord]) -> list[ExecutionRecord]:
        from utils.config import settings

        if not settings.monitored_workflow_ids and not settings.monitored_workflow_names:
            return executions

        filtered = []
        allowed_ids = set(settings.monitored_workflow_ids)
        allowed_names = {name.lower() for name in settings.monitored_workflow_names}
        for execution in executions:
            if execution.workflow_id and execution.workflow_id in allowed_ids:
                filtered.append(execution)
                continue
            if execution.workflow_name.lower() in allowed_names:
                filtered.append(execution)
        return filtered

    def _filter_windowed_executions(
        self,
        executions: list[ExecutionRecord],
        window_days: int,
    ) -> list[ExecutionRecord]:
        window_start = _window_start(window_days)
        windowed = []
        for execution in self._filter_executions(executions):
            timestamp = execution.started_at or execution.finished_at
            if timestamp is not None and timestamp >= window_start:
                windowed.append(execution)
        return windowed

    def _build_summary(
        self,
        executions: list[ExecutionRecord],
        workflows: list[WorkflowRecord],
        workflow_index: dict[str, WorkflowRecord],
        window_days: int,
    ) -> dict[str, Any]:
        filtered_executions = self._filter_executions(executions)
        windowed_executions = self._filter_windowed_executions(executions, window_days)
        now = _now_utc()

        def _ts(execution: ExecutionRecord) -> datetime | None:
            return execution.started_at or execution.finished_at

        # Only scheduled (non-manual) runs, within the rolling window, excluding
        # cancelled executions — so the health metrics reflect current reality.
        scored = [
            execution
            for execution in windowed_executions
            if execution.mode != "manual"
            and _ts(execution) is not None
            and _status_bucket(execution.status) != "canceled"
        ]

        success = 0
        failed = 0
        auto_recovered = 0
        critical_failures = 0
        total_duration = 0.0
        duration_count = 0
        last_success: datetime | None = None
        last_failure: datetime | None = None
        last_execution: datetime | None = None

        for execution in scored:
            bucket = _status_bucket(execution.status)
            timestamp = _ts(execution)
            if timestamp and (last_execution is None or timestamp > last_execution):
                last_execution = timestamp
            if bucket == "success":
                success += 1
                if timestamp and (last_success is None or timestamp > last_success):
                    last_success = timestamp
            elif bucket == "failed":
                failed += 1
                if timestamp and (last_failure is None or timestamp > last_failure):
                    last_failure = timestamp
            if execution.retry_success_id:
                auto_recovered += 1
            if bucket == "failed" and not execution.retry_success_id:
                critical_failures += 1
            if execution.duration_seconds is not None:
                total_duration += execution.duration_seconds
                duration_count += 1

        completed = success + failed
        average_duration = round(total_duration / duration_count, 2) if duration_count else 0.0
        bot_availability = round((success / completed) * 100, 2) if completed else 0.0
        scheduler_active = any(workflow.active for workflow in workflows)
        scheduler_status = "Active" if scheduler_active else "Paused"
        monitoring_status = "Connected" if completed > 0 else "No Data"
        alert_count = critical_failures + auto_recovered

        # Next-run / overdue: from the most recent scheduled run + expected interval.
        sched_times = sorted(
            (_ts(e) for e in filtered_executions if e.mode != "manual" and _ts(e) is not None),
            reverse=True,
        )
        last_sched = sched_times[0] if sched_times else None
        interval = timedelta(minutes=max(1, settings.expected_interval_minutes))
        grace = timedelta(minutes=max(0, settings.overdue_grace_minutes))
        next_run = (last_sched + interval) if last_sched else None
        overdue = bool(last_sched and now > last_sched + interval + grace)
        minutes_to_next = round((next_run - now).total_seconds() / 60) if next_run else None
        minutes_overdue = round((now - last_sched - interval).total_seconds() / 60) if (last_sched and overdue) else 0

        return {
            "generated_at": isoformat(now),
            "source": "n8n",
            "window_days": window_days,
            "total_scheduler_runs": len(scored),
            "successful_executions": success,
            "failed_executions": failed,
            "auto_recovered_failures": auto_recovered,
            "critical_failures": critical_failures,
            "email_alerts_sent": alert_count,
            "bot_availability_pct": bot_availability,
            "REDACTED_OPAQUE_VALUE": average_duration,
            "average_execution_duration": _format_duration(average_duration),
            "last_successful_run": isoformat(last_success) if last_success else None,
            "last_failure_time": isoformat(last_failure) if last_failure else None,
            "last_execution_time": isoformat(last_execution) if last_execution else None,
            "current_monitoring_status": monitoring_status,
            "current_scheduler_status": scheduler_status,
            "workflow_count": len(workflows),
            "active_workflows": sum(1 for workflow in workflows if workflow.active),
            "next_expected_run": isoformat(next_run) if next_run else None,
            "last_scheduled_run": isoformat(last_sched) if last_sched else None,
            "overdue": overdue,
            "minutes_to_next_run": minutes_to_next,
            "minutes_overdue": minutes_overdue,
            "expected_interval_minutes": settings.expected_interval_minutes,
        }

    def _build_live_status(
        self,
        summary: dict[str, Any],
        workflows: list[WorkflowRecord],
        executions: list[ExecutionRecord],
    ) -> dict[str, Any]:
        return {
            "n8n_connected": True,
            "scheduler_active": summary.get("current_scheduler_status") == "Active",
            "flask_api_healthy": True,
            "stale": False,
            "last_execution_timestamp": summary.get("last_execution_time"),
            "last_successful_run": summary.get("last_successful_run"),
            "last_failure_time": summary.get("last_failure_time"),
            "total_workflows": len(workflows),
            "active_workflows": sum(1 for workflow in workflows if workflow.active),
            "session_status": self._session_status(executions),
            "next_expected_run": summary.get("next_expected_run"),
            "overdue": summary.get("overdue"),
            "minutes_to_next_run": summary.get("minutes_to_next_run"),
            "minutes_overdue": summary.get("minutes_overdue"),
        }

    def _session_status(self, executions: list[ExecutionRecord]) -> str:
        runs = sorted(
            self._filter_executions(executions),
            key=lambda e: e.started_at or e.finished_at or datetime.min.replace(tzinfo=timezone.utc),
            reverse=True,
        )
        for execution in runs[:6]:
            bucket = _status_bucket(execution.status)
            message = (execution.error_message or "").lower()
            if bucket == "failed" and any(k in message for k in ("logged out", "re-scan", "/qr", "session")):
                return "Logged out"
            if bucket == "success":
                return "Logged in"
        return "Unknown"

    def _build_retry_trends(self, executions: list[ExecutionRecord], window_days: int) -> dict[str, Any]:
        daily = defaultdict(lambda: {"retried": 0, "recovered": 0})
        for execution in self._filter_windowed_executions(executions, window_days):
            timestamp = execution.started_at or execution.finished_at
            if not timestamp:
                continue
            key = timestamp.astimezone(timezone.utc).date().isoformat()
            if execution.retry_of:
                daily[key]["retried"] += 1
            if execution.retry_success_id or (_status_bucket(execution.status) == "success" and execution.retry_of):
                daily[key]["recovered"] += 1

        labels = sorted(daily.keys())
        return {
            "labels": labels,
            "retried": [daily[label]["retried"] for label in labels],
            "recovered": [daily[label]["recovered"] for label in labels],
        }

    def _build_failure_trends(self, executions: list[ExecutionRecord], window_days: int) -> dict[str, Any]:
        category_counts = Counter()
        for execution in self._filter_windowed_executions(executions, window_days):
            if _status_bucket(execution.status) == "failed":
                category_counts[_failure_step(execution.error_message, execution.status)] += 1

        if not category_counts:
            category_counts["No failures"] = 0

        labels = list(category_counts.keys())
        return {
            "labels": labels,
            "values": [category_counts[label] for label in labels],
        }

    def _build_execution_trends(self, executions: list[ExecutionRecord], window_days: int) -> dict[str, Any]:
        daily = defaultdict(lambda: {"success": 0, "failure": 0})
        for execution in self._filter_windowed_executions(executions, window_days):
            timestamp = execution.started_at or execution.finished_at
            if not timestamp:
                continue
            key = timestamp.astimezone(timezone.utc).date().isoformat()
            bucket = _status_bucket(execution.status)
            if bucket == "success":
                daily[key]["success"] += 1
            elif bucket == "failed":
                daily[key]["failure"] += 1

        labels = sorted(daily.keys())
        return {
            "labels": labels,
            "success": [daily[label]["success"] for label in labels],
            "failure": [daily[label]["failure"] for label in labels],
        }

    def _build_alerts_trends(self, summary: dict[str, Any]) -> dict[str, Any]:
        return {
            "labels": ["Success Alerts", "Failure Alerts", "Recovery Alerts"],
            "values": [
                summary.get("successful_executions", 0),
                summary.get("failed_executions", 0),
                summary.get("auto_recovered_failures", 0),
            ],
        }

    def _build_duration_trends(self, executions: list[ExecutionRecord], window_days: int) -> dict[str, Any]:
        daily = defaultdict(list)
        for execution in self._filter_windowed_executions(executions, window_days):
            timestamp = execution.started_at or execution.finished_at
            if not timestamp or execution.duration_seconds is None:
                continue
            key = timestamp.astimezone(timezone.utc).date().isoformat()
            daily[key].append(execution.duration_seconds)

        labels = sorted(daily.keys())
        averages = [round(sum(values) / len(values), 2) for values in (daily[label] for label in labels)]
        return {
            "labels": labels,
            "values": averages,
        }

    def _build_history_rows(
        self,
        executions: list[ExecutionRecord],
        workflow_index: dict[str, WorkflowRecord],
        window_days: int,
    ) -> list[dict[str, Any]]:
        rows = []
        filtered = self._filter_windowed_executions(executions, window_days)
        for execution in sorted(
            filtered,
            key=lambda item: item.started_at or item.finished_at or datetime.min.replace(tzinfo=timezone.utc),
            reverse=True,
        ):
            workflow = workflow_index.get(execution.workflow_id or "")
            rows.append(
                _serialize_execution(
                    execution,
                    workflow_status="active" if workflow and workflow.active else "inactive" if workflow else "unknown",
                )
            )
        return rows

    def build_dashboard_summary(self, window_days: int | None = None) -> dict[str, Any]:
        snapshot = self.get_snapshot(window_days=window_days)
        return {
            "generated_at": snapshot.summary["generated_at"],
            "window_days": snapshot.window_days,
            "metrics": snapshot.summary,
            "charts": {
                "success_failure_trend": snapshot.execution_trends,
                "retry_recovery_trend": snapshot.retry_trends,
                "failure_distribution": snapshot.failure_trends,
                "execution_duration_trend": snapshot.duration_trends,
                "monitoring_availability": {"value": snapshot.summary["bot_availability_pct"]},
                "daily_execution_trend": snapshot.execution_trends,
                "alerts_trend": snapshot.alerts_trends,
            },
            "live_status": snapshot.live_status,
        }

    def build_live_status(self, window_days: int | None = None) -> dict[str, Any]:
        return self.get_snapshot(window_days=window_days).live_status

    def build_system_health(self, window_days: int | None = None) -> dict[str, Any]:
        return self.get_snapshot(window_days=window_days).health

    def build_retry_trends(self, window_days: int | None = None) -> dict[str, Any]:
        return self.get_snapshot(window_days=window_days).retry_trends

    def build_failure_trends(self, window_days: int | None = None) -> dict[str, Any]:
        return self.get_snapshot(window_days=window_days).failure_trends

    def build_execution_history(
        self,
        page: int = 1,
        per_page: int = 10,
        search: str = "",
        status: str = "",
        sort_by: str = "timestamp",
        sort_dir: str = "desc",
        window_days: int | None = None,
    ) -> dict[str, Any]:
        snapshot = self.get_snapshot(window_days=window_days)
        rows = list(snapshot.history_rows)

        if search:
            needle = search.lower()
            rows = [
                row
                for row in rows
                if needle in row["execution_id"].lower()
                or needle in row["workflow_name"].lower()
                or needle in row["status"].lower()
                or needle in row["failure_reason"].lower()
            ]

        if status:
            status_lower = status.lower()
            rows = [row for row in rows if row["status"] == status_lower]

        sort_key_map = {
            "timestamp": lambda row: row.get("timestamp") or "",
            "duration": lambda row: row.get("duration_seconds") if row.get("duration_seconds") is not None else -1,
            "status": lambda row: row.get("status") or "",
            "workflow_name": lambda row: row.get("workflow_name") or "",
            "retry_status": lambda row: row.get("retry_status") or "",
        }
        sort_key = sort_key_map.get(sort_by, sort_key_map["timestamp"])
        reverse = sort_dir.lower() != "asc"
        rows.sort(key=sort_key, reverse=reverse)

        total = len(rows)
        per_page = max(1, min(per_page, 100))
        page = max(1, page)
        start = (page - 1) * per_page
        end = start + per_page
        page_items = rows[start:end]

        return {
            "items": page_items,
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": max((total + per_page - 1) // per_page, 1),
            "window_days": snapshot.window_days,
        }
