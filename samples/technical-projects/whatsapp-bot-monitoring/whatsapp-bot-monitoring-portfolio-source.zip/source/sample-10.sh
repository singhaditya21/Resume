#!/bin/bash
# Launcher for the WhatsApp AssistNext monitor API on the 192.0.2.10 server.
# Runs the Flask API (api_server.py) under a virtual display so the headed
# Playwright Chromium can render web.whatsapp.com. Installed at
# /biztech/wa-monitor/run.sh and invoked by the wa-monitor.service systemd unit.
export WA_BASE=/biztech/wa-monitor          # session/logs/screenshots live here
export WA_PORT=5090                          # API port (n8n calls http://localhost:5090)
export WA_RUN_TIMEOUT=600                     # max seconds for one /run-monitor journey
exec xvfb-run -a /biztech/wa-monitor/venv/bin/python "/biztech/Whatsapp/Login WhatsApp/api_server.py"
