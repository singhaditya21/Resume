export function calculateEvaluationResult(assertions: Array<{ passed: boolean; weight?: number }>) {
  if (assertions.length === 0) return { status: 'warning' as const, score: 0 };
  const totalWeight = assertions.reduce((total, assertion) => total + (assertion.weight ?? 1), 0);
  const passedWeight = assertions.reduce(
    (total, assertion) => total + (assertion.passed ? (assertion.weight ?? 1) : 0),
    0
  );
  const score = Number(((passedWeight / totalWeight) * 100).toFixed(1));
  return {
    status:
      score === 100
        ? ('passed' as const)
        : score >= 70
          ? ('warning' as const)
          : ('failed' as const),
    score
  };
}
