/**
 * Generic LLM chat helper — the single place every agent's reasoning /
 * scoring / reflection call goes through.
 *
 * There is ONE LLM: the on-prem vLLM / LiteLLM endpoint serving gemma4-26b
 * (OpenAI-compatible /chat/completions), configured via config.CEREBRAS_*
 * (env-var names kept for back-compat). No second provider, no cloud
 * fallback. When CEREBRAS_API_KEY is unset, activeLlmProvider() returns
 * null and the caller degrades to its deterministic rule-based fallback.
 */
import { config } from './config.js';
import { makeTraceId } from './shared.js';

// Single provider. The slug stays 'cerebras' for back-compat with stored
// model_provider values + the modules that read it, but it resolves ONLY to
// the on-prem gemma4-26b endpoint (config.CEREBRAS_*). No other LLM exists.
export type LlmProvider = 'cerebras';

export interface ChatResult {
  provider: LlmProvider;
  model: string;
  content: string;
  usage?: { input_tokens: number; output_tokens: number; total_tokens: number };
  latencyMs: number;
}

/** Why the last chat() call degraded to the deterministic fallback. Kept in
 *  memory so ops can see WHY the model isn't answering (previously every
 *  failure was swallowed silently → ~80% of runs fell back invisibly). */
export interface LlmFallback {
  reason: string;
  status?: number;
  attempts: number;
  at: number;
}
let lastFallback: LlmFallback | null = null;
export function lastLlmFallback(): LlmFallback | null {
  return lastFallback;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

interface ChatRequest {
  system: string;
  user: string;
  /** Defaults to 800. */
  maxTokens?: number;
  /** Defaults to 0.2. */
  temperature?: number;
  /** Reuse the run's trace id so logs correlate; auto-generated if absent. */
  traceId?: string;
  /** Abort timeout in ms. Defaults to 25_000. */
  timeoutMs?: number;
}

/** Whether the single on-prem LLM is configured (has a key) right now.
 *  Null → no key → calls degrade to the deterministic heuristic. */
export function activeLlmProvider(): LlmProvider | null {
  return config.CEREBRAS_API_KEY ? 'cerebras' : null;
}

function providerConfig(_provider: LlmProvider): { baseUrl: string; key: string; model: string } {
  return {
    baseUrl: config.CEREBRAS_BASE_URL,
    key: config.CEREBRAS_API_KEY ?? '',
    model: config.CEREBRAS_MODEL
  };
}

type Attempt =
  | { ok: true; result: ChatResult }
  | { ok: false; retriable: boolean; reason: string; status?: number };

/** One HTTP attempt against the provider. Classifies the failure so the
 *  caller knows whether a retry is worthwhile. */
async function chatAttempt(provider: LlmProvider, req: ChatRequest): Promise<Attempt> {
  const { baseUrl, key, model } = providerConfig(provider);
  const started = Date.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), req.timeoutMs ?? 30_000);
  try {
    const response = await fetch(`${baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        'X-Trace-Id': req.traceId ?? makeTraceId()
      },
      body: JSON.stringify({
        model,
        temperature: req.temperature ?? 0.2,
        max_tokens: req.maxTokens ?? 800,
        messages: [
          { role: 'system', content: req.system },
          { role: 'user', content: req.user }
        ]
      })
    });
    if (!response.ok) {
      // 429 (rate limit) + 5xx are transient → worth a retry. 401/403 (bad
      // key) + other 4xx are permanent → fall back immediately.
      const retriable = response.status === 429 || response.status >= 500;
      const reason =
        response.status === 429
          ? 'rate_limited'
          : response.status === 401 || response.status === 403
            ? 'auth_failed'
            : response.status >= 500
              ? 'server_error'
              : `http_${response.status}`;
      return { ok: false, retriable, reason, status: response.status };
    }
    const raw = (await response.json()) as {
      choices?: Array<{ message?: { content?: unknown } }>;
      usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
    };
    const content = raw?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || content.trim().length === 0) {
      return { ok: false, retriable: true, reason: 'empty_content' };
    }
    return {
      ok: true,
      result: {
        provider,
        model,
        content,
        usage: raw.usage
          ? {
              input_tokens: raw.usage.prompt_tokens ?? 0,
              output_tokens: raw.usage.completion_tokens ?? 0,
              total_tokens: raw.usage.total_tokens ?? 0
            }
          : undefined,
        latencyMs: Date.now() - started
      }
    };
  } catch (err) {
    // AbortError = our timeout fired; anything else is a network error. Both
    // are transient.
    const reason = (err as { name?: string })?.name === 'AbortError' ? 'timeout' : 'network_error';
    return { ok: false, retriable: true, reason };
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Make a chat call against the active provider and return the raw text
 * content. Returns `null` when no provider is configured OR the call
 * fails after retries — callers must always have a deterministic fallback
 * so a model outage degrades quality, never availability.
 *
 * Transient failures (timeout / 429 / 5xx / network / empty body) are
 * retried with backoff before giving up; the reason for any final fallback
 * is recorded (lastLlmFallback()) and logged, so the silent-degradation
 * problem becomes observable.
 */
export async function chat(req: ChatRequest): Promise<ChatResult | null> {
  const provider = activeLlmProvider();
  if (!provider) {
    lastFallback = { reason: 'no_provider_configured', attempts: 0, at: Date.now() };
    return null;
  }
  const maxAttempts = 3;
  let last: Extract<Attempt, { ok: false }> = {
    ok: false,
    retriable: false,
    reason: 'unknown'
  };
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const res = await chatAttempt(provider, req);
    if (res.ok) return res.result;
    last = res;
    if (!res.retriable || attempt === maxAttempts - 1) break;
    // Backoff: 400ms, then 1200ms.
    await sleep(attempt === 0 ? 400 : 1200);
  }
  lastFallback = {
    reason: last.reason,
    status: last.status,
    attempts: maxAttempts,
    at: Date.now()
  };
  // Structured, greppable line in the host console.log so ops can see the
  // real reason the model isn't answering.
  console.warn(
    `[llm] fallback provider=${provider} reason=${last.reason}${
      last.status ? ` status=${last.status}` : ''
    }`
  );
  return null;
}

/** Parse a JSON object out of an LLM text response, tolerating ```json
 *  fences and leading/trailing prose. Returns null on failure. */
export function parseJsonObject(content: string): Record<string, unknown> | null {
  const trimmed = content.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim();
  const candidate = fenced ?? trimmed;
  try {
    const parsed = JSON.parse(candidate);
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
  } catch {
    // Last resort: grab the outermost {...} block.
    const start = candidate.indexOf('{');
    const end = candidate.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try {
        const parsed = JSON.parse(candidate.slice(start, end + 1));
        return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
      } catch {
        return null;
      }
    }
    return null;
  }
}

/** Convenience: chat + JSON parse in one call. */
export async function chatJson(
  req: ChatRequest
): Promise<{ result: ChatResult; json: Record<string, unknown> } | null> {
  const result = await chat(req);
  if (!result) return null;
  const json = parseJsonObject(result.content);
  if (!json) return null;
  return { result, json };
}
