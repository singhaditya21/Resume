import type { AgentRunStatus } from '../../types/domain';

const transitions: Record<AgentRunStatus, AgentRunStatus[]> = {
  queued: ['running', 'cancelled', 'paused', 'budget_exceeded', 'policy_blocked', 'not_configured'],
  running: [
    'needs_approval',
    'succeeded',
    'failed',
    'cancelled',
    'budget_exceeded',
    'policy_blocked'
  ],
  needs_approval: ['succeeded', 'failed', 'cancelled'],
  succeeded: [],
  failed: [],
  cancelled: [],
  paused: ['queued', 'cancelled'],
  budget_exceeded: [],
  policy_blocked: [],
  not_configured: []
};

export function canMoveAgentRun(from: AgentRunStatus, to: AgentRunStatus) {
  return transitions[from].includes(to);
}
