/**
 * F22 — Hermes-style closed learning loop.
 *
 * After a successful agent run, this module fires a small follow-up
 * Cerebras call ("self-critique") that produces 0–3 lessons + an
 * optional reusable skill. Lessons go into `agent_learnings`; skills
 * go into `agent_skills` (deduped by name; the application counter
 * ticks up when the skill is re-used).
 *
 * The reflection runs out-of-band — fire-and-forget from runAgent —
 * so the user-visible run latency is unaffected even if the
 * reflection call is slow.
 *
 * Cost shape: ~300 output tokens × 7×24/3 = 56 calls/day per agent
 * at the 3-hour scheduler cadence, ≈ $0.02/day per agent at
 * gemma4-26b prices.
 */
import type { RowDataPacket } from './db.js';
import { config } from './config.js';
import { execute, query } from './db.js';
import { activeLlmProvider, chat } from './llm.js';
import { makeId, makeTraceId, nowSql, redact } from './shared.js';

/** Model name of the single LLM, for agent_runs bookkeeping. */
function reflectionModelName(): string {
  return config.CEREBRAS_MODEL;
}

/** Native agents that get the reflection treatment. Kept narrow on
 *  purpose — these three see the most varied input and benefit most
 *  from learning across runs. Cheap to widen later. */
const REFLECTING_AGENTS = new Set([
  'idea-triage-agent',
  'poc-planning-agent',
  'outcome-measurement-agent',
  // BN reviewer-copilots learn from each draft + from human feedback.
  'bn-l1-screening-agent',
  'bn-l2-financial-agent',
  'bn-l3-technical-agent'
]);

const REFLECTION_TIMEOUT_MS = 20_000;
const MAX_REFLECTION_TOKENS = 320;

interface ReflectionOutput {
  lessons: Array<{
    category: 'observation' | 'heuristic' | 'pattern' | 'skill';
    lesson: string;
  }>;
  proposed_skill?: {
    name: string;
    body: string;
  };
}

/** Fire-and-forget reflection. Always resolves; failures are
 *  swallowed and logged silently to avoid masking the real run. */
export function reflectOnRunAsync(input: {
  agentSlug: string;
  agentRunId: string;
  inputSummary: string;
  output: unknown;
}): void {
  void reflectOnRun(input).catch(() => {
    // Reflection is best-effort. A failure here must not propagate
    // up to the caller (runAgent) — the actual run already succeeded.
  });
}

async function reflectOnRun(input: {
  agentSlug: string;
  agentRunId: string;
  inputSummary: string;
  output: unknown;
}): Promise<void> {
  if (!REFLECTING_AGENTS.has(input.agentSlug)) return;
  if (!activeLlmProvider()) return;

  const result = await callReflection(input);
  if (!result) return;

  const now = nowSql();
  // Persist lessons.
  for (const item of result.lessons) {
    await execute(
      `INSERT INTO agent_learnings (id, agent_slug, agent_run_id, category, lesson, created_at)
       VALUES (:id, :slug, :run_id, :category, :lesson, :now)`,
      {
        id: makeId(),
        slug: input.agentSlug,
        run_id: input.agentRunId,
        category: item.category,
        lesson: item.lesson.slice(0, 4000),
        now
      }
    );
  }
  // Persist skill (deduped by unique key). If the same skill name
  // surfaces again, refresh its body + bump times_succeeded so the
  // skill record reflects the latest "what this is" + active usage.
  //
  // The model rarely volunteers an explicit `proposed_skill` (which is why
  // agent_skills stayed empty while agent_learnings grew), yet it regularly
  // emits 'heuristic'/'pattern' lessons that ARE reusable. Promote the first
  // such lesson into a skill so the learn→inject closed loop actually has
  // something to inject.
  let skill = result.proposed_skill;
  if (!skill) {
    const reusable = result.lessons.find(
      (l) => l.category === 'heuristic' || l.category === 'pattern' || l.category === 'skill'
    );
    if (reusable) {
      skill = { name: reusable.lesson.slice(0, 60), body: reusable.lesson };
    }
  }
  if (skill && skill.name && skill.body) {
    await execute(
      `INSERT INTO agent_skills
         (id, agent_slug, name, body, created_from_run_id,
          times_applied, times_succeeded, is_active, created_at, updated_at)
       VALUES
         (:id, :slug, :name, :body, :run_id, 0, 1, 1, :now, :now)
       ON CONFLICT (agent_slug, name) DO UPDATE SET
         body = EXCLUDED.body,
         times_succeeded = agent_skills.times_succeeded + 1,
         updated_at = EXCLUDED.updated_at`,
      {
        id: makeId(),
        slug: input.agentSlug,
        name: skill.name.slice(0, 255),
        body: skill.body.slice(0, 4000),
        run_id: input.agentRunId,
        now
      }
    );
  }
}

async function callReflection(input: {
  agentSlug: string;
  agentRunId: string;
  inputSummary: string;
  output: unknown;
}): Promise<ReflectionOutput | null> {
  // Runs on the on-prem LLM (gemma4-26b) —
  // chat() picks the active provider. This is the "learn" half of the
  // closed loop: the model critiques the run and emits reusable skills.
  const result = await chat({
    system: [
      "You are the agent's reflection step. You see what the agent just produced and you extract 0-3 SHORT lessons that would help the agent (or its sibling agents) do better next time.",
      'Return strict JSON matching: {lessons: [{category, lesson}], proposed_skill?: {name, body}}.',
      "category ∈ 'observation' | 'heuristic' | 'pattern' | 'skill'.",
      "Lessons must be SPECIFIC and ACTIONABLE — avoid generic 'be more careful'. Example: 'When the title contains \"sentiment\", expect data_sources to include CRM + social platforms.'",
      'Propose a `proposed_skill` ONLY when this run revealed a clear, reusable procedure or rule worth applying to future similar runs. Skill `name` is a short title (≤60 chars). Skill `body` is one paragraph describing when + how to apply it. Skip the skill field if nothing reusable emerged.',
      'Return JSON ONLY. No prose, no fences.'
    ].join('\n'),
    user: JSON.stringify({
      agent: input.agentSlug,
      input_summary: input.inputSummary,
      output: redact(input.output)
    }),
    temperature: 0.3,
    maxTokens: MAX_REFLECTION_TOKENS,
    timeoutMs: REFLECTION_TIMEOUT_MS
  });
  if (!result) return null;
  return normalize(parseJsonObject(result.content));
}

function normalize(value: unknown): ReflectionOutput | null {
  if (!value || typeof value !== 'object') return null;
  const obj = value as Record<string, unknown>;
  const lessonsRaw = Array.isArray(obj.lessons) ? obj.lessons : [];
  const lessons = lessonsRaw
    .slice(0, 3)
    .map((row) => {
      if (!row || typeof row !== 'object') return null;
      const r = row as Record<string, unknown>;
      const category = String(r.category ?? 'observation');
      const lesson = String(r.lesson ?? '').trim();
      if (!lesson) return null;
      const validCategories = ['observation', 'heuristic', 'pattern', 'skill'] as const;
      const safeCategory = (validCategories as readonly string[]).includes(category)
        ? (category as ReflectionOutput['lessons'][number]['category'])
        : 'observation';
      return { category: safeCategory, lesson };
    })
    .filter((x): x is ReflectionOutput['lessons'][number] => x !== null);
  let proposed_skill: ReflectionOutput['proposed_skill'];
  if (obj.proposed_skill && typeof obj.proposed_skill === 'object') {
    const sr = obj.proposed_skill as Record<string, unknown>;
    const name = String(sr.name ?? '').trim();
    const body = String(sr.body ?? '').trim();
    if (name && body) proposed_skill = { name, body };
  }
  if (lessons.length === 0 && !proposed_skill) return null;
  return { lessons, proposed_skill };
}

function parseJsonObject(value: unknown): unknown {
  if (value && typeof value === 'object') return value;
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim();
  try {
    return JSON.parse(fenced ?? trimmed);
  } catch {
    return null;
  }
}

/**
 * Top N currently-active skills for the agent, ordered by application
 * count desc. Used by the analyzer to inject "what you've learned"
 * into the system prompt for the next run.
 */
export async function getActiveSkillsForAgent(
  agentSlug: string,
  limit = 5
): Promise<Array<{ name: string; body: string }>> {
  const rows = (await query<RowDataPacket[]>(
    `SELECT name, body FROM agent_skills
      WHERE agent_slug = :slug AND is_active = 1
      ORDER BY times_applied DESC, created_at DESC
      LIMIT :limit`,
    { slug: agentSlug, limit }
  )) as Array<{ name: string; body: string }>;
  return rows.map((r) => ({ name: r.name, body: r.body }));
}

/** Tick the apply counter when skills are injected into a run. */
export async function markSkillsApplied(agentSlug: string, names: string[]) {
  if (names.length === 0) return;
  await execute(
    `UPDATE agent_skills
        SET times_applied = times_applied + 1,
            updated_at = :now
      WHERE agent_slug = :slug AND name IN (:names)`,
    { slug: agentSlug, names, now: nowSql() }
  );
}

// ──────────────────────────────────────────────────────────────────────
// F35 / Phase 1C — Outcome-grounded reflection.
//
// F22's reflection (above) compares the agent's output against
// itself — useful but ungrounded. This pass fires when an outcome row
// lands and feeds the LLM the *original prediction* + the *actual
// outcome* and asks "which skill should the triage agent update?".
//
// Always attributed to `idea-triage-agent` (the originator of the
// prediction). Lessons + proposed_skill flow into the same
// agent_learnings / agent_skills tables — the skill injection at
// triage-time picks them up automatically on the next run.
//
// Fire-and-forget. Failure must never block the outcome write.
// ──────────────────────────────────────────────────────────────────────

const OUTCOME_TARGET_AGENT = 'idea-triage-agent';

export function reflectOnOutcomeAsync(input: {
  ideaId: string;
  metricType: string;
  metricName: string;
  actualValue: number;
  predictedValueUsd: number;
  predictedBasis: string | null;
  unit: string | null;
}): void {
  void reflectOnOutcome(input).catch(() => {
    // Outcome-grounded reflection is best-effort.
  });
}

async function reflectOnOutcome(input: {
  ideaId: string;
  metricType: string;
  metricName: string;
  actualValue: number;
  predictedValueUsd: number;
  predictedBasis: string | null;
  unit: string | null;
}): Promise<void> {
  if (!activeLlmProvider()) return;

  // Pull the original analysis row so the LLM can see what the agent
  // "saw" when it made the prediction (summary + CUSTOMER_REDACTED scores + risk).
  // This is the prediction context — without it, the LLM can only
  // reason about the delta, not what to fix.
  const analysisRows = (await query<RowDataPacket[]>(
    `SELECT summary, problem_summary, impact_score, feasibility_score,
            data_readiness_score, risk_level, confidence,
            ai_predicted_value_usd, ai_predicted_value_basis
       FROM idea_ai_analyses
      WHERE idea_id = :id
      ORDER BY created_at DESC
      LIMIT 1`,
    { id: input.ideaId }
  )) as Array<{
    summary: string;
    problem_summary: string;
    impact_score: number;
    feasibility_score: number;
    data_readiness_score: number;
    risk_level: string;
    confidence: number;
    ai_predicted_value_usd: number | string | null;
    ai_predicted_value_basis: string | null;
  }>;
  const analysis = analysisRows[0];
  if (!analysis) return; // Can't ground reflection without the original prediction.

  const ideaRows = (await query<RowDataPacket[]>(
    `SELECT id, title FROM ideas WHERE id = :id LIMIT 1`,
    { id: input.ideaId }
  )) as Array<{ id: string; title: string }>;
  const ideaTitle = ideaRows[0]?.title ?? '(untitled)';

  const result = await callOutcomeReflection({
    ideaId: input.ideaId,
    ideaTitle,
    analysis,
    actual: {
      metric_type: input.metricType,
      metric_name: input.metricName,
      actual_value: input.actualValue,
      unit: input.unit
    },
    prediction: {
      value_usd: input.predictedValueUsd,
      basis: input.predictedBasis
    }
  });
  if (!result) return;

  // Write a synthetic agent_runs marker row for the reflection so the
  // agent timeline shows "learned from outcome on idea X". Without
  // this the learning would appear unattributed.
  const reflectionRunId = makeId();
  const now = nowSql();
  await execute(
    `INSERT INTO agent_runs (
      id, trace_id, idempotency_key, agent_slug, agent_type, trigger_type,
      entity_type, entity_id, status, input_summary, output_summary,
      model_provider, model_name, started_at, finished_at, created_at, updated_at
    ) VALUES (
      :id, :trace_id, :idempotency_key, :agent_slug, 'native', 'event',
      'idea', :entity_id, 'succeeded', :input_summary, :output_summary,
      :provider, :model, :now, :now, :now, :now
    )`,
    {
      id: reflectionRunId,
      trace_id: makeTraceId(),
      idempotency_key: `outcome_reflection:${input.ideaId}:${Date.now()}`,
      agent_slug: OUTCOME_TARGET_AGENT,
      entity_id: input.ideaId,
      input_summary: `Outcome reflection on "${ideaTitle.slice(0, 80)}"`,
      output_summary: `Predicted $${input.predictedValueUsd.toLocaleString()} → actual ${input.actualValue.toLocaleString()}${input.unit ? ` ${input.unit}` : ''}`,
      provider: activeLlmProvider() ?? 'cerebras',
      model: reflectionModelName(),
      now
    }
  ).catch(() => undefined);

  for (const item of result.lessons) {
    await execute(
      `INSERT INTO agent_learnings (id, agent_slug, agent_run_id, category, lesson, created_at)
       VALUES (:id, :slug, :run_id, :category, :lesson, :now)`,
      {
        id: makeId(),
        slug: OUTCOME_TARGET_AGENT,
        run_id: reflectionRunId,
        category: item.category,
        lesson: item.lesson.slice(0, 4000),
        now
      }
    );
  }
  if (result.proposed_skill && result.proposed_skill.name && result.proposed_skill.body) {
    await execute(
      `INSERT INTO agent_skills
         (id, agent_slug, name, body, created_from_run_id,
          times_applied, times_succeeded, is_active, created_at, updated_at)
       VALUES
         (:id, :slug, :name, :body, :run_id, 0, 1, 1, :now, :now)
       ON CONFLICT (agent_slug, name) DO UPDATE SET
         body = EXCLUDED.body,
         times_succeeded = agent_skills.times_succeeded + 1,
         updated_at = EXCLUDED.updated_at`,
      {
        id: makeId(),
        slug: OUTCOME_TARGET_AGENT,
        name: result.proposed_skill.name.slice(0, 255),
        body: result.proposed_skill.body.slice(0, 4000),
        run_id: reflectionRunId,
        now
      }
    );
  }
}

async function callOutcomeReflection(input: {
  ideaId: string;
  ideaTitle: string;
  analysis: {
    summary: string;
    problem_summary: string;
    impact_score: number;
    feasibility_score: number;
    data_readiness_score: number;
    risk_level: string;
    confidence: number;
    ai_predicted_value_usd: number | string | null;
    ai_predicted_value_basis: string | null;
  };
  actual: {
    metric_type: string;
    metric_name: string;
    actual_value: number;
    unit: string | null;
  };
  prediction: {
    value_usd: number;
    basis: string | null;
  };
}): Promise<ReflectionOutput | null> {
  const result = await chat({
    system: [
      'You are the outcome-grounded reflection step for the idea-triage-agent.',
      "You see the agent's ORIGINAL prediction (made at triage time) and the ACTUAL outcome (recorded by a human later).",
      'Compare them. If the agent was wrong, identify WHY — was the basis flawed? Was the dossier evidence misread? Was the heuristic over-confident?',
      'Return strict JSON: {lessons: [{category, lesson}], proposed_skill?: {name, body}}.',
      "category ∈ 'observation' | 'heuristic' | 'pattern' | 'skill'.",
      'Lessons should be CONCRETE, GROUNDED in this specific prediction vs outcome pair. Bad: "be more accurate". Good: "When the basis cites \'X hrs saved\' but no captured tasks exist, lower the $-projection to the impact-score heuristic floor".',
      'Propose a `proposed_skill` ONLY if this miss reveals a reusable rule the agent should apply on future triage runs. Skip if nothing reusable emerged. Skill name ≤60 chars; body is one paragraph: when + how to apply.',
      'Return JSON ONLY. No prose, no fences.'
    ].join('\n'),
    user: JSON.stringify({
      idea: { id: input.ideaId, title: input.ideaTitle },
      original_prediction: {
        value_usd: input.prediction.value_usd,
        basis: input.prediction.basis,
        impact_score: input.analysis.impact_score,
        feasibility_score: input.analysis.feasibility_score,
        data_readiness_score: input.analysis.data_readiness_score,
        risk_level: input.analysis.risk_level,
        confidence: input.analysis.confidence,
        summary: input.analysis.summary
      },
      actual_outcome: input.actual,
      delta: {
        predicted_usd: input.prediction.value_usd,
        actual: input.actual.actual_value,
        actual_unit: input.actual.unit ?? 'unit',
        same_currency:
          input.actual.metric_type === 'savings' || input.actual.metric_type === 'revenue'
      }
    }),
    temperature: 0.3,
    maxTokens: MAX_REFLECTION_TOKENS,
    timeoutMs: REFLECTION_TIMEOUT_MS
  });
  if (!result) return null;
  return normalize(parseJsonObject(result.content));
}

// ──────────────────────────────────────────────────────────────────────
// BN HITL-grounded reflection.
//
// The strongest learning signal a reviewer-copilot gets is the human's
// reaction to its draft: Applied (good), Edited (close — learn the gap),
// Dismissed (wrong — learn why). This pass feeds the model the agent's
// draft + the human's decision + (when edited) the human's final values,
// and asks for lessons/skills. Output lands in the same agent_learnings /
// agent_skills tables, so the next BN draft for a similar idea benefits.
//
// Fire-and-forget; never blocks the reviewer's action.
// ──────────────────────────────────────────────────────────────────────

export function reflectOnBnFeedbackAsync(input: {
  agentSlug: string;
  agentRunId: string;
  level: string;
  ideaTitle: string;
  draft: unknown;
  decision: 'applied' | 'edited' | 'dismissed';
  humanFinal?: unknown;
}): void {
  void reflectOnBnFeedback(input).catch(() => {
    // HITL reflection is best-effort.
  });
}

async function reflectOnBnFeedback(input: {
  agentSlug: string;
  agentRunId: string;
  level: string;
  ideaTitle: string;
  draft: unknown;
  decision: 'applied' | 'edited' | 'dismissed';
  humanFinal?: unknown;
}): Promise<void> {
  if (!activeLlmProvider()) return;
  const result = await chat({
    system: [
      `You are the human-feedback reflection step for the BN ${input.level.toUpperCase()} reviewer-copilot.`,
      "You see the DRAFT the agent proposed and the HUMAN reviewer's reaction to it.",
      "decision = 'applied' means the human used the draft as-is (it was good).",
      "decision = 'edited' means the human changed it — the gap between draft and human_final is the lesson.",
      "decision = 'dismissed' means the draft was unhelpful or wrong — figure out why.",
      'Return strict JSON ONLY: {lessons: [{category, lesson}], proposed_skill?: {name, body}}.',
      "category ∈ 'observation' | 'heuristic' | 'pattern' | 'skill'.",
      'Lessons must be SPECIFIC + ACTIONABLE and grounded in THIS draft-vs-human pair. Propose a skill only when a clearly reusable rule emerged. Skill name ≤60 chars; body one paragraph (when + how).',
      'Return JSON ONLY. No prose, no fences.'
    ].join('\n'),
    user: JSON.stringify({
      idea_title: input.ideaTitle,
      level: input.level,
      agent_draft: redact(input.draft),
      human_decision: input.decision,
      human_final: input.humanFinal ? redact(input.humanFinal) : null
    }),
    temperature: 0.3,
    maxTokens: MAX_REFLECTION_TOKENS,
    timeoutMs: REFLECTION_TIMEOUT_MS
  });
  const reflection = result ? normalize(parseJsonObject(result.content)) : null;
  if (!reflection) return;

  const now = nowSql();
  for (const item of reflection.lessons) {
    await execute(
      `INSERT INTO agent_learnings (id, agent_slug, agent_run_id, category, lesson, created_at)
       VALUES (:id, :slug, :run_id, :category, :lesson, :now)`,
      {
        id: makeId(),
        slug: input.agentSlug,
        run_id: input.agentRunId,
        category: item.category,
        lesson: item.lesson.slice(0, 4000),
        now
      }
    );
  }
  if (reflection.proposed_skill?.name && reflection.proposed_skill.body) {
    await execute(
      `INSERT INTO agent_skills
         (id, agent_slug, name, body, created_from_run_id,
          times_applied, times_succeeded, is_active, created_at, updated_at)
       VALUES
         (:id, :slug, :name, :body, :run_id, 0, 1, 1, :now, :now)
       ON CONFLICT (agent_slug, name) DO UPDATE SET
         body = EXCLUDED.body,
         times_succeeded = agent_skills.times_succeeded + 1,
         updated_at = EXCLUDED.updated_at`,
      {
        id: makeId(),
        slug: input.agentSlug,
        name: reflection.proposed_skill.name.slice(0, 255),
        body: reflection.proposed_skill.body.slice(0, 4000),
        run_id: input.agentRunId,
        now
      }
    );
  }
}
