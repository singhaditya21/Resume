export interface PaperclipConfig {
  baseUrl?: string;
  apiKey?: string;
  companyId?: string;
  webhookSecret?: string;
}

export interface PaperclipHeartbeatPayload {
  source: 'paperclip';
  runId: string;
  agentId: string;
  companyId: string;
  taskId?: string;
  wakeReason: string;
  context: {
    ideaStormIdeaId?: string;
    action?: string;
    [key: string]: unknown;
  };
}

export interface PaperclipTaskPayload {
  title: string;
  description: string;
  companyId?: string;
  metadata: Record<string, unknown>;
}
