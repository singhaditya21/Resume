/**
 * F20 — Native-agent scheduler. The product spec is "agents should be
 * running every 3 hours" — this module owns that cadence.
 *
 * Design:
 *  - In-process `setInterval` (server stays up under Passenger), fires
 *    every 15 minutes and checks a DB marker (`portal_settings.
 *    last_agent_schedule_run`) to decide whether to actually do work.
 *    The 15-minute pulse is cheap and means a Passenger restart loses
 *    at most 15 minutes of timer state.
 *  - Idempotency is in the marker — if two app instances ever fire at
 *    the same time, only one wins the `INTERVAL` check.
 *  - Each cycle iterates eligible ideas (active, not terminal, not
 *    `implemented`) and fires the relevant native agent on each. We
 *    space the fires by 500 ms to avoid hammering the LLM provider.
 *  - `/api/cron/run-agents` exposes the same `runScheduledAgentCycle`
 *    behind a CRON_TOKEN header so external schedulers can drive it
 *    if the in-process timer ever fails.
 */
import type { RowDataPacket } from './db.js';
import { runAgent } from './agents.js';
import { execute, query } from './db.js';
import { nowSql } from './shared.js';

/** F25 — Schedule cadence widened to 6 hours per product call. The
 *  3-hour cadence + parallel fire on 56 ideas hit Cerebras's free-tier
 *  rate limit (HTTP 429). The new model: every 6 hours, one agent at
 *  a time, one idea at a time, with a 2-second gap between Cerebras
 *  calls (~30 req/min ceiling). */
const SCHEDULE_INTERVAL_MS = 6 * 60 * 60 * 1000;
/** How often the in-process timer wakes up to check the DB marker. */
const CHECK_INTERVAL_MS = 15 * 60 * 1000;
/** F25 — Gap between consecutive agent runs in a cycle. 2 seconds keeps
 *  us under Cerebras's free-tier ceiling of ~30 requests/minute even
 *  when multiple agents fire per idea. Tunable here for future tiers. */
const RUN_GAP_MS = 2_000;
const MARKER_KEY = 'last_agent_schedule_run';

/** Idea statuses where it's worth re-running agents. We skip terminals
 *  + `implemented` (done) since the analysis adds little value there. */
const ELIGIBLE_STATUSES = [
  'new',
  'ai_triaged',
  'needs_more_info',
  'under_review',
  'prioritized',
  'poc',
  'delivery',
  // BN workflow stages — the reviewer-copilot agents fan out here.
  'submitted',
  'l1_review',
  'l2_review',
  'l3_review',
  'approved',
  'implementation'
];

/** F25 — Which agents make sense at each stage of an idea's life.
 *  Driven by the agent's job description, not blanket "run everything
 *  on everything." Order matters: we fire in the listed order per idea,
 *  one at a time. The supervisor / notification / integration agents
 *  stay off the per-idea schedule — they're workspace-level. */
function agentsForIdeaStage(status: string): string[] {
  // Triage applies at every stage until terminal — re-summarising is always
  // useful. (duplicate-clustering-agent was removed: it had no handler and
  // its ~1k scheduled runs were pure no-ops; real dup detection is done by
  // dup-detection-agent on intake + the synchronous /duplicate-check path.)
  const base = ['idea-triage-agent'];

  // BN approval pipeline — fire the level's reviewer-copilot. The copilot
  // is idempotent (skips when a pending draft already exists), so re-runs
  // every cycle are cheap. dup-detection still runs on intake stages.
  if (status === 'submitted')
    return ['idea-triage-agent', 'dup-detection-agent', 'bn-scoring-agent'];
  // bn-scoring-agent is idempotent (skips already-scored on scheduled
  // runs) so including it here backfills scorecards on the existing
  // l1_review ideas without re-scoring every cycle.
  if (status === 'l1_review') return ['bn-scoring-agent', 'bn-l1-screening-agent'];
  // L2 + L3 review in parallel → both copilots fire at l2_review.
  if (status === 'l2_review') return ['bn-l2-financial-agent', 'bn-l3-technical-agent'];
  if (status === 'l3_review') return ['bn-l3-technical-agent'];
  if (status === 'approved' || status === 'implementation') {
    return ['poc-planning-agent', 'outcome-measurement-agent'];
  }

  if (status === 'prioritized' || status === 'poc') {
    return [...base, 'poc-planning-agent'];
  }
  if (status === 'poc' || status === 'delivery') {
    return [...base, 'outcome-measurement-agent'];
  }
  return base;
}

async function readMarker(): Promise<Date | null> {
  const rows = (await query<RowDataPacket[]>(
    'SELECT setting_value FROM portal_settings WHERE setting_key = :k LIMIT 1',
    { k: MARKER_KEY }
  )) as Array<{ setting_value: string }>;
  if (!rows[0]) return null;
  const t = Date.parse(rows[0].setting_value);
  return Number.isNaN(t) ? null : new Date(t);
}

async function writeMarker(when: Date): Promise<void> {
  // portal_settings may not have an upsert helper; use REPLACE for an
  // atomic write that preserves the unique key on setting_key.
  await execute(
    `INSERT INTO portal_settings (setting_key, setting_value, updated_at)
     VALUES (:k, :v, :now)
     ON CONFLICT (setting_key) DO UPDATE SET setting_value = :v, updated_at = :now`,
    { k: MARKER_KEY, v: when.toISOString(), now: nowSql() }
  );
}

/**
 * Run one scheduled cycle. Idempotent — if the marker shows the last
 * cycle was < SCHEDULE_INTERVAL_MS ago, returns immediately with a
 * `skipped` reason so the cron caller knows. Pass `force: true` to
 * override (used by manual invocations).
 */
export async function runScheduledAgentCycle(opts: { force?: boolean } = {}) {
  const now = new Date();
  const lastRun = await readMarker();
  if (!opts.force && lastRun) {
    const elapsed = now.getTime() - lastRun.getTime();
    if (elapsed < SCHEDULE_INTERVAL_MS) {
      return {
        ok: true,
        skipped: true,
        reason: 'too_soon',
        next_run_at: new Date(lastRun.getTime() + SCHEDULE_INTERVAL_MS).toISOString(),
        last_run_at: lastRun.toISOString()
      };
    }
  }

  // Reserve the marker FIRST so a concurrent fire bails out via the
  // too_soon branch above.
  await writeMarker(now);

  const ideas = (await query<RowDataPacket[]>(
    `SELECT id, status FROM ideas WHERE status IN (:statuses) AND deleted_at IS NULL`,
    { statuses: ELIGIBLE_STATUSES }
  )) as Array<{ id: string; status: string }>;

  // BN merge Phase 5 — first sweep: SLA auto-escalation. Workspace-
  // scope, no LLM, no fan-out per idea. Fires once per cycle BEFORE
  // the per-idea agent fan-out so any newly-escalated idea is in the
  // right stage when the stage-specific agents fire below.
  try {
    await runAgent({
      agentSlug: 'sla-escalation-agent',
      triggerType: 'scheduled'
    });
  } catch {
    // Per-agent failures must not break the cycle.
  }

  // F25 — Strictly serial pacing. For each idea, fire each stage-
  // relevant agent one at a time, with a fixed gap between Cerebras
  // calls so we stay below the provider's rate limit. The outer for
  // loop awaits the inner loop completely before moving to the next
  // idea — no `Promise.all`, no fan-out.
  let fired = 0;
  let rateLimited = 0;
  let failed = 0;
  for (const idea of ideas) {
    const slugs = agentsForIdeaStage(idea.status);
    for (const agentSlug of slugs) {
      try {
        // eslint-disable-next-line no-await-in-loop
        await new Promise((r) => setTimeout(r, RUN_GAP_MS));
        // eslint-disable-next-line no-await-in-loop
        const result = await runAgent({
          agentSlug,
          triggerType: 'scheduled',
          entityType: 'idea',
          entityId: idea.id
        });
        // P-spec: re-running triage on an already-triaged idea is
        // additive — old behaviour preserved.
        fired += 1;
        // If we see provider-side rate limiting, back off for a full
        // minute before the next call. Cerebras's free-tier window is
        // a per-minute bucket; this lets the bucket refill.
        const status = (result as { status?: string } | null)?.status;
        if (status === 'failed' && typeof result === 'object' && result) {
          const errMsg = String((result as { error_message?: string }).error_message ?? '');
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate')) {
            rateLimited += 1;
            // eslint-disable-next-line no-await-in-loop
            await new Promise((r) => setTimeout(r, 60_000));
          }
        }
      } catch {
        failed += 1;
        // Per-run failures are swallowed; the next cycle will retry.
      }
    }
  }

  return {
    ok: true,
    skipped: false,
    fired,
    rate_limited: rateLimited,
    failed,
    eligible_ideas: ideas.length,
    last_run_at: now.toISOString(),
    next_run_at: new Date(now.getTime() + SCHEDULE_INTERVAL_MS).toISOString()
  };
}

/**
 * Wire the in-process timer. Called once at server boot. Returns the
 * timer handle (for tests / shutdown). Safe to call multiple times —
 * the second call clears the first timer.
 */
let activeTimer: ReturnType<typeof setInterval> | null = null;
export function startAgentScheduler(logger: {
  info: (msg: unknown, m?: string) => void;
  error: (err: unknown, msg?: string) => void;
}) {
  if (activeTimer) clearInterval(activeTimer);
  const fire = async () => {
    try {
      const result = await runScheduledAgentCycle();
      if (!result.skipped) {
        logger.info(
          { fired: result.fired, eligible: result.eligible_ideas },
          'scheduled agent cycle complete'
        );
      }
    } catch (err) {
      logger.error(err, 'scheduled agent cycle failed');
    }
  };
  activeTimer = setInterval(fire, CHECK_INTERVAL_MS);
  // Fire once a few seconds after boot so a fresh deploy doesn't sit
  // idle for the full check interval.
  setTimeout(fire, 5_000);
  return activeTimer;
}

/**
 * Helper exposed to the API + UI. Tells the catalog cards when the
 * next cycle will fire so users can answer "when will agents run
 * again?" without guessing.
 */
export async function getScheduleStatus() {
  const lastRun = await readMarker();
  const nextRun = lastRun
    ? new Date(lastRun.getTime() + SCHEDULE_INTERVAL_MS)
    : new Date(Date.now() + 5_000);
  return {
    last_run_at: lastRun?.toISOString() ?? null,
    next_run_at: nextRun.toISOString(),
    interval_seconds: SCHEDULE_INTERVAL_MS / 1000
  };
}
