import { migrate } from './db.js';

migrate()
  .then((result) => {
    console.log(`Applied Hostinger MySQL migrations from ${result.migrationsDir}`);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
