import { SHOWCASE_BATCH_ID, clearShowcaseData } from './showcase-seed.js';

clearShowcaseData()
  .then((deleted) => {
    const total = Object.values(deleted).reduce((sum, count) => sum + count, 0);
    console.log(`Cleared showcase batch ${SHOWCASE_BATCH_ID}`);
    console.log(`Deleted records: ${total}`);
    console.log(
      Object.entries(deleted)
        .filter(([, count]) => count > 0)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([table, count]) => `${table}: ${count}`)
        .join('\n')
    );
  })
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  });
