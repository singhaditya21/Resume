export interface RufloConfig {
  webhookUrl?: string;
  apiKey?: string;
  mode?: 'disabled' | 'local' | 'external';
}

export interface RufloCallbackPayload {
  source: 'ruflo';
  swarmId?: string;
  goalId?: string;
  runId?: string;
  action?: string;
  context?: Record<string, unknown>;
}

export interface RufloGoalPayload {
  name: string;
  objective: string;
  metadata: Record<string, unknown>;
}
