import type { SupabaseClient } from '@supabase/supabase-js';

export class SupabaseRepository {
  constructor(private readonly client: SupabaseClient) {}

  async listIdeas() {
    const { data, error } = await this.client
      .from('ideas')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  }

  async invokeAgent(functionName: 'analyze-idea' | 'run-agent', payload: Record<string, unknown>) {
    const { data, error } = await this.client.functions.invoke(functionName, { body: payload });
    if (error) throw error;
    return data;
  }
}
