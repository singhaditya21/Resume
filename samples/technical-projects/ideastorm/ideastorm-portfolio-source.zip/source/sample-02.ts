/**
 * BN reviewer-copilot agents.
 *
 * Three agents, one per approval level, that draft an *advisory* for the
 * human reviewer at that level. They NEVER act on the workflow (F29) —
 * they write a `bn_agent_advisories` draft the reviewer reads on the BN
 * review screen, then Applies / Edits / Dismisses. That human decision
 * is the grounding signal for the Hermes learning loop.
 *
 *   bn-l1-screening-agent  (Mgr Review)  — completeness + recommend
 *   bn-l2-financial-agent  (Dept Head)   — effort / budget / savings
 *   bn-l3-technical-agent  (Add'l Review) — tech stack / feasibility
 *
 * Each call runs on Hermes (Nous Research) when configured, else
 * Cerebras, else a deterministic heuristic — so a model outage degrades
 * quality, never availability.
 */
import { chatJson } from './llm.js';
import type { LearnedSkill } from './cerebras.js';

export type BnLevel = 'l1' | 'l2' | 'l3';

export const BN_COPILOT_SLUG: Record<BnLevel, string> = {
  l1: 'bn-l1-screening-agent',
  l2: 'bn-l2-financial-agent',
  l3: 'bn-l3-technical-agent'
};

export const BN_COPILOT_LEVEL: Record<string, BnLevel> = {
  'bn-l1-screening-agent': 'l1',
  'bn-l2-financial-agent': 'l2',
  'bn-l3-technical-agent': 'l3'
};

export interface BnAdvisory {
  recommended_action: 'approve' | 'send_back' | 'reject';
  summary: string;
  /** Level-specific structured suggestion the human can apply. */
  draft: Record<string, unknown>;
  confidence: number;
  provider: 'cerebras' | 'deterministic_fallback';
  model: string;
  latencyMs: number;
}

export interface BnIdeaForAgent {
  id: string;
  title: string;
  problem_statement?: string | null;
  proposed_solution?: string | null;
  expected_benefit?: string | null;
  business_function?: string | null;
  scope_of_impact?: string | null;
  category?: string | null;
  effort_size?: string | null;
  budget_usd?: number | string | null;
  savings_usd?: number | string | null;
  tech_stack?: unknown;
}

const LEVEL_SYSTEM: Record<BnLevel, string> = {
  l1: [
    'You are the L1 Screening copilot for a BusinessNEXT idea-approval workflow.',
    "The L1 reviewer is the submitter's reporting manager. Your job is to PRE-DRAFT their screening — you never approve or reject; a human does.",
    'Assess: is the submission complete and clear enough to advance to L2/L3 review? What, if anything, is missing?',
    'Return strict JSON ONLY (no prose, no fences) matching:',
    '{ "recommended_action": "approve"|"send_back"|"reject", "summary": string, "clarity_score": number(0..1), "missing": string[], "clarifying_questions": string[], "rationale": string, "confidence": number(0..1) }',
    'Recommend "send_back" when critical detail is missing; "reject" only when the idea is clearly out of scope or duplicative; otherwise "approve".',
    'clarifying_questions are the exact questions the manager would ask the submitter. Keep each ≤140 chars.'
  ].join('\n'),
  l2: [
    'You are the L2 Financial copilot for a BusinessNEXT idea-approval workflow.',
    'The L2 reviewer is the department head, assessing business impact + financials. Pre-draft a financial assessment — you never approve; a human does.',
    'Return strict JSON ONLY (no prose, no fences) matching:',
    '{ "recommended_action": "approve"|"send_back"|"reject", "summary": string, "effort_size": "S"|"M"|"L", "budget_usd": number|null, "savings_usd": number|null, "roi_rationale": string, "rationale": string, "confidence": number(0..1) }',
    'effort_size: S = days, M = weeks, L = months. budget_usd is one-off build cost; savings_usd is estimated ANNUAL benefit. Use null when you genuinely cannot estimate.',
    'Be conservative and explain the basis in roi_rationale (≤280 chars).'
  ].join('\n'),
  l3: [
    'You are the L3 Technical copilot for a BusinessNEXT idea-approval workflow.',
    'The L3 reviewer is the AI CoE / additional technical reviewer. Pre-draft a feasibility read — you never approve; a human does.',
    'Return strict JSON ONLY (no prose, no fences) matching:',
    '{ "recommended_action": "approve"|"send_back"|"reject", "summary": string, "feasibility": "high"|"medium"|"low", "suggested_tech_stack": string[], "technical_risks": string[], "rationale": string, "confidence": number(0..1) }',
    'suggested_tech_stack: concrete components (e.g. "Azure OpenAI (GPT-4o)", "n8n", "pgvector"). technical_risks: the 1-4 biggest feasibility risks.',
    'Recommend "send_back" when key technical detail is missing to judge feasibility.'
  ].join('\n')
};

function ideaUserPayload(idea: BnIdeaForAgent): string {
  return JSON.stringify({
    title: idea.title,
    problem_statement: idea.problem_statement ?? null,
    proposed_solution: idea.proposed_solution ?? null,
    expected_benefit: idea.expected_benefit ?? null,
    business_function: idea.business_function ?? null,
    scope_of_impact: idea.scope_of_impact ?? null,
    category: idea.category ?? null,
    existing_effort_size: idea.effort_size ?? null,
    existing_budget_usd: idea.budget_usd ?? null,
    existing_savings_usd: idea.savings_usd ?? null
  });
}

/** Prepend the agent's earned skills so prior reflections steer the run. */
function skillBlock(skills: LearnedSkill[] | undefined): string {
  if (!skills || skills.length === 0) return '';
  return (
    '\n\nSkills you have learned from past runs + human feedback (apply where relevant):\n' +
    skills.map((s, i) => `${i + 1}. ${s.name}: ${s.body}`).join('\n')
  );
}

/**
 * Build the advisory for a level. Uses the active LLM provider; on any
 * failure (no key, timeout, bad JSON) returns a deterministic heuristic
 * draft so the copilot always produces *something* the reviewer can act
 * on.
 */
export async function buildBnAdvisory(
  level: BnLevel,
  idea: BnIdeaForAgent,
  skills?: LearnedSkill[],
  traceId?: string
): Promise<BnAdvisory> {
  const started = Date.now();
  const llm = await chatJson({
    system: LEVEL_SYSTEM[level] + skillBlock(skills),
    user: ideaUserPayload(idea),
    temperature: 0.2,
    maxTokens: 700,
    traceId
  });
  if (llm) {
    const j = llm.json;
    const action = normalizeAction(j.recommended_action);
    return {
      recommended_action: action,
      summary: String(j.summary ?? '').slice(0, 2000),
      draft: j,
      confidence: clamp01(Number(j.confidence ?? 0.6)),
      provider: llm.result.provider,
      model: llm.result.model,
      latencyMs: Date.now() - started
    };
  }
  return deterministicAdvisory(level, idea, started);
}

function normalizeAction(v: unknown): 'approve' | 'send_back' | 'reject' {
  const s = String(v ?? '').toLowerCase();
  if (s === 'reject') return 'reject';
  if (s === 'send_back' || s === 'sendback' || s === 'send back') return 'send_back';
  return 'approve';
}

function clamp01(n: number): number {
  if (!Number.isFinite(n)) return 0.5;
  return Math.max(0, Math.min(1, n));
}

/** Heuristic fallback — no LLM. Conservative, explainable. */
function deterministicAdvisory(level: BnLevel, idea: BnIdeaForAgent, started: number): BnAdvisory {
  const problem = (idea.problem_statement ?? '').trim();
  const solution = (idea.proposed_solution ?? '').trim();
  const thin = problem.length < 40 || solution.length < 40;
  const base = (draft: Record<string, unknown>, summary: string): BnAdvisory => ({
    recommended_action: thin ? 'send_back' : 'approve',
    summary,
    draft: { ...draft, recommended_action: thin ? 'send_back' : 'approve' },
    confidence: 0.35,
    provider: 'deterministic_fallback',
    model: 'local-rules',
    latencyMs: Date.now() - started
  });
  if (level === 'l1') {
    const missing: string[] = [];
    if (problem.length < 40) missing.push('A clear problem statement');
    if (solution.length < 40) missing.push('A concrete proposed solution');
    if (!idea.expected_benefit) missing.push('Expected benefit / outcome');
    return base(
      {
        clarity_score: thin ? 0.4 : 0.7,
        missing,
        clarifying_questions: missing.map((m) => `Can you provide: ${m.toLowerCase()}?`),
        rationale: thin
          ? 'Key fields are thin — recommend sending back for detail before L2/L3.'
          : 'Submission has enough detail to advance to parallel L2/L3 review.'
      },
      thin
        ? 'Submission is missing detail for a confident L1 screen.'
        : `Ready to advance: ${idea.title}`
    );
  }
  if (level === 'l2') {
    const size = solution.length > 400 ? 'L' : solution.length > 160 ? 'M' : 'S';
    return base(
      {
        effort_size: size,
        budget_usd: null,
        savings_usd: null,
        roi_rationale: 'Heuristic estimate from solution scope; confirm with the submitter.'
      },
      `Estimated effort ${size}; financials need a human estimate.`
    );
  }
  return base(
    {
      feasibility: 'medium',
      suggested_tech_stack: [],
      technical_risks: thin ? ['Insufficient technical detail to assess feasibility'] : [],
      rationale: 'Heuristic feasibility read; confirm tech approach with the submitter.'
    },
    'Feasibility looks moderate; technical detail needed to firm it up.'
  );
}
