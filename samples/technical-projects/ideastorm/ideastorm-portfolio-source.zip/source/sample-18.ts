export function getFrontendEnvStatus() {
  return {
    appName: import.meta.env.VITE_APP_NAME ?? 'Idea Storm',
    demoMode: import.meta.env.VITE_USE_DEMO_MODE === 'true',
    supabaseConfigured: Boolean(
      import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY
    ),
    aiEnabled: import.meta.env.VITE_ENABLE_AI !== 'false',
    agentsEnabled: import.meta.env.VITE_ENABLE_AGENTS !== 'false'
  };
}
