import type { RowDataPacket } from './db.js';
import { analyzeIdeaWithCerebras } from './cerebras.js';
import { execute, query } from './db.js';
import { baseRecord, canManage, type AppRole, type ProfileLike, similarIdeas } from './domain.js';
import { json, makeId, makeTraceId, nowSql, redact } from './shared.js';
import { dispatchWebhook } from './webhooks.js';
import type { DossierSignals, IdeaLike } from './domain.js';

export const builtInAgents = [
  'idea-triage-agent',
  'duplicate-clustering-agent',
  'governance-risk-agent',
  'reviewer-copilot-agent',
  'ceo-portfolio-insights-agent',
  'poc-planning-agent',
  'outcome-measurement-agent',
  'notification-digest-agent',
  'integration-sync-agent',
  'agent-supervisor-agent',
  // BN merge Phase 4 — semantic dup detection. Stores a sparse TF-IDF
  // token vector on ideas.embedding; cosine similarity at query time
  // returns top matches. Pluggable to real LLM embeddings later
  // (Azure OpenAI / Cerebras) by swapping the vectoriser implementation
  // in dup-detection.ts.
  'dup-detection-agent',
  // BN merge Phase 5 — SLA enforcement. Runs every 4 hours via the
  // existing agent-scheduler. Finds BN-flow ideas past their L1/L2/L3
  // due_at, marks them 'escalated', notifies the escalation target.
  'sla-escalation-agent',
  // BN reviewer-copilot agents. One per approval level; each drafts an
  // advisory the human reviewer Applies / Edits / Dismisses (HITL).
  // They never mutate the workflow. Reflection feeds the Hermes loop.
  'bn-l1-screening-agent',
  'bn-l2-financial-agent',
  'bn-l3-technical-agent',
  // D4/D6 AI Reviewer — produces the 5-dimension/100-point scorecard +
  // tier on submit. Advisory: drives routing/SLA, never auto-decides.
  'bn-scoring-agent'
] as const;

export interface RunAgentInput {
  agentSlug: string;
  triggerType: 'manual' | 'event' | 'scheduled' | 'webhook' | 'integration_callback';
  entityType?: string;
  entityId?: string;
  user?: ProfileLike;
  payload?: unknown;
}

export async function runAgent(input: RunAgentInput) {
  const traceId = makeTraceId();
  const runId = makeId();
  const now = nowSql();
  const agentKnown = builtInAgents.includes(input.agentSlug as (typeof builtInAgents)[number]);
  await execute(
    `INSERT INTO agent_runs (
      id, trace_id, idempotency_key, agent_slug, agent_type, trigger_type, triggered_by,
      entity_type, entity_id, status, input_payload, input_summary, model_provider, model_name,
      started_at, created_at, updated_at
    ) VALUES (
      :id, :trace_id, :idempotency_key, :agent_slug, 'native', :trigger_type, :triggered_by,
      :entity_type, :entity_id, 'running', :input_payload, :input_summary, 'cerebras', :model_name,
      :started_at, :created_at, :updated_at
    )`,
    {
      id: runId,
      trace_id: traceId,
      idempotency_key: `${input.agentSlug}:${input.triggerType}:${input.entityType ?? 'none'}:${input.entityId ?? 'none'}`,
      agent_slug: input.agentSlug,
      trigger_type: input.triggerType,
      triggered_by: input.user?.id ?? null,
      entity_type: input.entityType ?? null,
      entity_id: input.entityId ?? null,
      input_payload: json(
        redact(input.payload ?? { entityType: input.entityType, entityId: input.entityId })
      ),
      input_summary: `${input.agentSlug} ${input.entityType ?? ''}`.trim(),
      model_name: process.env.CEREBRAS_MODEL || 'gemma4-26b',
      started_at: now,
      created_at: now,
      updated_at: now
    }
  );
  await audit('agent_run_started', {
    actor: input.user,
    agentSlug: input.agentSlug,
    agentRunId: runId,
    entityType: input.entityType,
    entityId: input.entityId,
    traceId
  });
  // Gotcha #2a fix: emit the previously-silent agent.run_started event.
  await dispatchWebhook('agent.run_started', {
    run_id: runId,
    trace_id: traceId,
    agent_slug: input.agentSlug,
    trigger_type: input.triggerType,
    entity_type: input.entityType ?? null,
    entity_id: input.entityId ?? null,
    triggered_by: input.user?.id ?? null
  });

  const finish = async (status: string, patch: Record<string, unknown> = {}) => {
    await execute(
      `UPDATE agent_runs
       SET status = :status,
           output_payload = :output_payload,
           output_summary = :output_summary,
           error_message = :error_message,
           model_provider = :model_provider,
           model_name = :model_name,
           finished_at = :finished_at,
           updated_at = :updated_at
       WHERE id = :id`,
      {
        id: runId,
        status,
        output_payload: json(patch.output_payload ?? null),
        output_summary: patch.output_summary ?? null,
        error_message: patch.error_message ?? null,
        model_provider: patch.model_provider ?? 'cerebras',
        model_name: patch.model_name ?? process.env.CEREBRAS_MODEL ?? 'gemma4-26b',
        finished_at: nowSql(),
        updated_at: nowSql()
      }
    );
    await audit(status === 'succeeded' ? 'agent_run_completed' : 'agent_run_failed', {
      actor: input.user,
      agentSlug: input.agentSlug,
      agentRunId: runId,
      entityType: input.entityType,
      entityId: input.entityId,
      traceId,
      newValue: { status }
    });
    // Raise an incident on a genuine run failure so the Incidents surface
    // reflects reality (previously it only ever fired on a budget breach
    // that never happened → the table stayed empty). Best-effort.
    if (status === 'failed') {
      await createIncident(
        `Agent run failed: ${input.agentSlug}`,
        String(patch.error_message ?? 'Unknown error'),
        'medium',
        input.agentSlug,
        runId
      ).catch(() => undefined);
    }
  };

  if (!agentKnown) {
    await addStep(runId, 1, 'Resolve agent definition', 'context', 'failed', 'Unknown agent.');
    await finish('failed', { error_message: 'Unknown agent.' });
    return getRun(runId);
  }

  const blocked = await isBlocked(input.agentSlug);
  if (blocked) {
    await addStep(runId, 1, 'Kill switch check', 'policy', 'failed', blocked);
    await policyResult(runId, 'kill_switch', 'failed', blocked);
    await finish('policy_blocked', { output_summary: blocked, error_message: blocked });
    return getRun(runId);
  }

  const paused = await isPaused(input.agentSlug);
  if (paused) {
    await addStep(runId, 1, 'Pause check', 'policy', 'warning', 'Agent is paused.');
    await finish('paused', { output_summary: 'Agent is paused by an admin override.' });
    return getRun(runId);
  }

  const budgetReason = await budgetExceeded(input.agentSlug);
  if (budgetReason) {
    await addStep(runId, 1, 'Budget check', 'policy', 'failed', budgetReason);
    await policyResult(runId, 'budget_policy', 'failed', budgetReason);
    await createIncident('Agent budget exceeded', budgetReason, 'medium', input.agentSlug, runId);
    await finish('budget_exceeded', { error_message: budgetReason });
    return getRun(runId);
  }

  await addStep(
    runId,
    1,
    'Load scoped context',
    'context',
    'succeeded',
    input.entityType ?? 'workspace'
  );
  await policyResult(
    runId,
    'scheduled_disabled_by_default',
    'passed',
    'Scheduled runs are disabled unless an admin enables them.'
  );

  if (input.agentSlug === 'idea-triage-agent' && input.entityType === 'idea' && input.entityId) {
    const idea = await getIdea(input.entityId);
    if (!idea) {
      await addStep(runId, 2, 'Read idea', 'context', 'failed', 'Idea not found.');
      await finish('failed', { error_message: 'Idea not found.' });
      return getRun(runId);
    }
    // Stream B (B4) — pull the 7-phase dossier alongside the idea row so
    // the LLM (and the deterministic fallback) can reason over the
    // structured context, not just the free-text fields.
    const dossier = await getDossierForAgent(input.entityId);
    // F22 — Hermes closed loop. Inject the top 5 most-applied
    // skills this agent has earned so prior reflections influence
    // the next run. markSkillsApplied bumps each skill's
    // application counter so retrospective stats stay accurate.
    const { getActiveSkillsForAgent, markSkillsApplied } = await import('./agent-reflection.js');
    const learnedSkills = await getActiveSkillsForAgent(input.agentSlug);
    const llm = await analyzeIdeaWithCerebras(idea, traceId, dossier, learnedSkills);
    if (learnedSkills.length > 0) {
      await markSkillsApplied(
        input.agentSlug,
        learnedSkills.map((s) => s.name)
      );
    }
    await addStep(
      runId,
      2,
      llm.provider === 'cerebras' ? 'Cerebras triage' : 'Deterministic fallback triage',
      llm.provider === 'cerebras' ? 'llm' : 'fallback',
      'succeeded',
      llm.provider === 'cerebras'
        ? 'Cerebras returned validated JSON.'
        : 'Fallback rules returned validated JSON.',
      llm.latencyMs
    );
    // Real output guardrail — actually validate the triage payload shape
    // (previously this was hard-coded 'passed'). A malformed output fails
    // the guardrail, raises an incident, and aborts the write instead of
    // persisting garbage.
    const gr = validateTriageOutput(llm.output);
    await guardrailResult(
      runId,
      'schema_validation',
      'output',
      gr.ok ? 'passed' : 'failed',
      gr.message
    );
    if (!gr.ok) {
      await finish('failed', {
        error_message: `Guardrail failed: ${gr.message}`,
        model_provider: llm.provider,
        model_name: llm.model
      });
      return getRun(runId);
    }
    const analysisId = makeId();
    await execute(
      `INSERT INTO idea_ai_analyses (
        id, idea_id, agent_run_id, summary, problem_summary, category_suggestion,
        classification_suggestion, tags, impact_score, feasibility_score, data_readiness_score,
        risk_level, risk_flags, missing_info_questions, recommended_status, confidence,
        ai_predicted_value_usd, ai_predicted_value_basis,
        raw_response, model_provider, model_name, created_at, updated_at
      ) VALUES (
        :id, :idea_id, :agent_run_id, :summary, :problem_summary, :category_suggestion,
        :classification_suggestion, :tags, :impact_score, :feasibility_score, :data_readiness_score,
        :risk_level, :risk_flags, :missing_info_questions, :recommended_status, :confidence,
        :ai_predicted_value_usd, :ai_predicted_value_basis,
        :raw_response, :model_provider, :model_name, :created_at, :updated_at
      )`,
      {
        id: analysisId,
        idea_id: idea.id,
        agent_run_id: runId,
        summary: llm.output.summary,
        problem_summary: llm.output.problem_summary,
        category_suggestion: llm.output.category,
        classification_suggestion: llm.output.classification,
        tags: json(llm.output.tags),
        impact_score: llm.output.impact_score,
        feasibility_score: llm.output.feasibility_score,
        data_readiness_score: llm.output.data_readiness_score,
        risk_level: llm.output.risk_level,
        risk_flags: json(llm.output.risk_flags),
        missing_info_questions: json(llm.output.missing_info_questions),
        recommended_status: llm.output.recommended_status,
        confidence: llm.output.confidence,
        ai_predicted_value_usd: llm.output.ai_predicted_value_usd ?? null,
        ai_predicted_value_basis: llm.output.ai_predicted_value_basis ?? null,
        raw_response: json(redact(llm.raw ?? llm.output)),
        model_provider: llm.provider,
        model_name: llm.model,
        created_at: nowSql(),
        updated_at: nowSql()
      }
    );
    // F29 — Strict rule: agents NEVER mutate the workflow. Humans do.
    // The agent writes its idea_ai_analyses row (above), then — if the
    // idea is still at 'new' — proposes a status transition to
    // 'ai_triaged' via agent_actions. A reviewer picks it up from the
    // Agents inbox / idea detail and applies it. clean_title /
    // ai_classification / risk_level travel with the proposal payload
    // so accepting the proposal also imports those fields. Nothing on
    // the ideas row changes here.
    const isFirstTriage = (idea.status ?? 'new') === 'new';
    // Idempotency — don't pile up a fresh proposal on every triage re-run.
    // If an unactioned `propose_status_change` already exists for this idea,
    // skip. This is the source-side fix for the duplicate-proposal backlog
    // (the cron sweep cleans any that already accumulated).
    const existingProposal = (await query<RowDataPacket[]>(
      `SELECT id FROM agent_actions
        WHERE entity_type = 'idea' AND entity_id = :id
          AND action_type = 'propose_status_change' AND status = 'proposed'
        LIMIT 1`,
      { id: idea.id }
    )) as Array<{ id: string }>;
    if (isFirstTriage && !existingProposal[0]) {
      await execute(
        `INSERT INTO agent_actions
         (id, agent_run_id, action_type, entity_type, entity_id, proposed_payload, risk_level, requires_approval, status, created_at, updated_at)
         VALUES (:id, :agent_run_id, 'propose_status_change', 'idea', :entity_id, :proposed_payload, :risk_level, 1, 'proposed', :created_at, :updated_at)`,
        {
          id: makeId(),
          agent_run_id: runId,
          entity_id: idea.id,
          proposed_payload: json({
            from_status: idea.status ?? 'new',
            status: 'ai_triaged',
            clean_title: llm.output.clean_title,
            ai_classification: llm.output.classification,
            risk_level: llm.output.risk_level,
            recommendation:
              'Triage agent reviewed this idea — proposing advance to AI Triaged with the metadata above.'
          }),
          risk_level: llm.output.risk_level === 'critical' ? 'high' : 'medium',
          created_at: nowSql(),
          updated_at: nowSql()
        }
      );
      await audit('approval_requested', {
        agentSlug: input.agentSlug,
        agentRunId: runId,
        entityType: 'idea',
        entityId: idea.id,
        newValue: {
          action_type: 'propose_status_change',
          from: idea.status ?? 'new',
          to: 'ai_triaged'
        }
      });
      // F33a — Push the proposal into the reviewer/admin inbox.
      await notifyAgentActionProposed({
        agentSlug: input.agentSlug,
        actionType: 'propose_status_change',
        entityType: 'idea',
        entityId: idea.id,
        ideaTitle: idea.title
      });
    }
    // Duplicate candidates: the row is itself a suggestion (status =
    // 'candidate'). It does not advance workflow — reviewers accept /
    // dismiss via the duplicates UI on the idea page. Keep as-is.
    const allIdeas = await query<RowDataPacket[]>('SELECT * FROM ideas ORDER BY created_at DESC');
    const candidates = similarIdeas(idea, allIdeas as unknown as IdeaLike[]);
    for (const candidate of candidates) {
      await execute(
        // Risk 6 fix: created_by is a uuid column, so the literal
        // 'duplicate-clustering-agent' raised 22P02 and the automated dedupe
        // row was silently dropped. created_by is nullable — bind null and keep
        // the agent identity in the human-readable reason instead.
        `INSERT INTO idea_duplicate_links
         (id, source_idea_id, target_idea_id, similarity, status, reason, created_by, created_at, updated_at)
         VALUES (:id, :source, :target, :similarity, 'candidate', :reason, NULL, :created_at, :updated_at)`,
        {
          id: makeId(),
          source: idea.id,
          target: candidate.idea.id,
          similarity: candidate.similarity,
          reason: 'Text similarity candidate (duplicate-clustering-agent).',
          created_at: nowSql(),
          updated_at: nowSql()
        }
      );
    }
    await addStep(
      runId,
      3,
      'Write AI analysis',
      'tool',
      'succeeded',
      isFirstTriage
        ? 'AI analysis stored + proposed advance to ai_triaged (pending human approval).'
        : 'AI analysis stored. Idea already past triage; no transition proposed.'
    );
    const totalTokens = llm.usage?.total_tokens ?? 0;
    await execute(
      `INSERT INTO agent_cost_events
       (id, agent_run_id, provider, model, input_tokens, output_tokens, total_tokens, latency_ms, cost_estimate, created_at, updated_at)
       VALUES (:id, :agent_run_id, :provider, :model, :input_tokens, :output_tokens, :total_tokens, :latency_ms, :cost_estimate, :created_at, :updated_at)`,
      {
        id: makeId(),
        agent_run_id: runId,
        provider: llm.provider,
        model: llm.model,
        input_tokens: llm.usage?.input_tokens ?? 0,
        output_tokens: llm.usage?.output_tokens ?? 0,
        total_tokens: totalTokens,
        latency_ms: llm.latencyMs,
        // Real (estimated) spend instead of a hard-coded 0 — a deterministic
        // fallback run costs nothing; a real model call is priced per token.
        cost_estimate: estimateCostUsd(llm.provider, totalTokens),
        created_at: nowSql(),
        updated_at: nowSql()
      }
    );
    await finish('succeeded', {
      output_payload: llm.output,
      output_summary: llm.output.summary,
      model_provider: llm.provider,
      model_name: llm.model
    });
    // F22 — Hermes reflection step. Fire-and-forget; lessons +
    // proposed skill land in agent_learnings + agent_skills.
    const { reflectOnRunAsync } = await import('./agent-reflection.js');
    reflectOnRunAsync({
      agentSlug: input.agentSlug,
      agentRunId: runId,
      inputSummary: `Idea: ${idea.title}`,
      output: llm.output
    });
    return getRun(runId);
  }

  // BN merge Phase 4 — dup-detection-agent. Native, deterministic.
  // On an 'idea' event, build the TF-IDF embedding from title +
  // problem + proposed_solution, write it to ideas.embedding, query
  // the existing portfolio for near-matches, and emit a structured
  // output payload the caller (POST /api/ideas) can use to decide
  // warn / block.
  if (input.agentSlug === 'dup-detection-agent' && input.entityType === 'idea' && input.entityId) {
    const idea = await getIdea(input.entityId);
    if (!idea) {
      await addStep(runId, 2, 'Read idea', 'context', 'failed', 'Idea not found.');
      await finish('failed', { error_message: 'Idea not found.' });
      return getRun(runId);
    }
    const { buildIdeaEmbedding, findSemanticDuplicates, classifyDupSeverity } =
      await import('./dup-detection.js');
    // Phase 7c — buildIdeaEmbedding is now async + provider-aware
    // (local TF-IDF by default; remote OpenAI-compatible if configured).
    const vec = await buildIdeaEmbedding({
      title: idea.title,
      problem_statement: idea.problem_statement,
      proposed_solution: idea.proposed_solution
    });
    await execute('UPDATE ideas SET embedding = :embedding, updated_at = :now WHERE id = :id', {
      id: idea.id,
      embedding: json(vec),
      now: nowSql()
    });
    const matches = await findSemanticDuplicates(
      `${idea.title} ${idea.problem_statement} ${idea.proposed_solution}`,
      { excludeId: idea.id, limit: 5 }
    );
    const highest = matches[0]?.similarity ?? 0;
    const severity = classifyDupSeverity(highest);
    await addStep(
      runId,
      2,
      'Build embedding + match',
      'tool',
      'succeeded',
      `Top match: ${(highest * 100).toFixed(0)}% (${severity}).`
    );
    await finish('succeeded', {
      output_payload: { matches, highest_score: highest, severity },
      output_summary:
        severity === 'ok'
          ? 'No duplicate concerns.'
          : `${(highest * 100).toFixed(0)}% similarity to ${matches[0]?.title ?? 'an existing idea'}.`
    });
    return getRun(runId);
  }

  // BN merge Phase 5 — sla-escalation-agent. Workspace-scope agent
  // (not idea-scope), fires from the scheduler every 6h. Each pass
  // sweeps BN-flow ideas past their stage SLA + auto-escalates.
  if (input.agentSlug === 'sla-escalation-agent') {
    const { runSlaEscalationPass } = await import('./sla-escalation.js');
    const result = await runSlaEscalationPass();
    await addStep(
      runId,
      2,
      'SLA escalation sweep',
      'tool',
      'succeeded',
      `${result.scanned} BN ideas scanned, ${result.escalated} escalated.`
    );
    await finish('succeeded', {
      output_payload: result,
      output_summary:
        result.escalated > 0
          ? `${result.escalated} idea(s) escalated past SLA.`
          : 'No SLA breaches found.'
    });
    return getRun(runId);
  }

  // BN reviewer-copilot agents (L1 / L2 / L3). Draft an advisory for the
  // human reviewer at that level. STRICT HITL: write a bn_agent_advisories
  // draft + reflect; never touch the workflow. Idempotent — skip if a
  // pending draft already exists for this idea+level.
  const bnLevel = (await import('./bn-agents.js')).BN_COPILOT_LEVEL[input.agentSlug];
  if (bnLevel && input.entityType === 'idea' && input.entityId) {
    const { buildBnAdvisory, BN_COPILOT_SLUG } = await import('./bn-agents.js');
    const idea = await getIdea(input.entityId);
    if (!idea) {
      await addStep(runId, 2, 'Read idea', 'context', 'failed', 'Idea not found.');
      await finish('failed', { error_message: 'Idea not found.' });
      return getRun(runId);
    }
    // Only run on BN-flow ideas actually sitting at this level's stage.
    const ideaRow = idea as unknown as {
      workflow_variant?: string;
      status?: string;
    };
    const stageOk =
      ideaRow.workflow_variant === 'bn' &&
      ((bnLevel === 'l1' && ideaRow.status === 'l1_review') ||
        (bnLevel === 'l2' && ideaRow.status === 'l2_review') ||
        (bnLevel === 'l3' && (ideaRow.status === 'l2_review' || ideaRow.status === 'l3_review')));
    if (!stageOk) {
      await addStep(
        runId,
        2,
        'Stage gate',
        'context',
        'succeeded',
        `Idea not at the ${bnLevel.toUpperCase()} stage; no advisory needed.`
      );
      await finish('succeeded', { output_summary: 'Skipped — idea not at this level.' });
      return getRun(runId);
    }
    // Idempotency: one pending draft per idea+level until a human acts.
    const existing = (await query<RowDataPacket[]>(
      `SELECT id FROM bn_agent_advisories
        WHERE idea_id = :id AND level = :level AND status = 'draft' LIMIT 1`,
      { id: input.entityId, level: bnLevel }
    )) as Array<{ id: string }>;
    if (existing[0]) {
      await addStep(
        runId,
        2,
        'Idempotency check',
        'context',
        'succeeded',
        'A pending advisory already exists; not regenerating.'
      );
      await finish('succeeded', { output_summary: 'Existing advisory still pending.' });
      return getRun(runId);
    }
    // Inject earned skills (Hermes loop) so prior reflections steer it.
    const { getActiveSkillsForAgent, markSkillsApplied, reflectOnRunAsync } =
      await import('./agent-reflection.js');
    const learnedSkills = await getActiveSkillsForAgent(input.agentSlug);
    const advisory = await buildBnAdvisory(bnLevel, idea as never, learnedSkills, traceId);
    if (learnedSkills.length > 0) {
      await markSkillsApplied(
        input.agentSlug,
        learnedSkills.map((s) => s.name)
      );
    }
    await addStep(
      runId,
      2,
      advisory.provider === 'deterministic_fallback'
        ? `Deterministic ${bnLevel.toUpperCase()} draft`
        : `${advisory.provider} ${bnLevel.toUpperCase()} draft`,
      advisory.provider === 'deterministic_fallback' ? 'fallback' : 'llm',
      'succeeded',
      `Recommended: ${advisory.recommended_action} (confidence ${advisory.confidence.toFixed(2)})`,
      advisory.latencyMs
    );
    await execute(
      `INSERT INTO bn_agent_advisories
         (id, idea_id, level, agent_slug, agent_run_id, recommended_action, summary,
          draft, confidence, model_provider, model_name, status, created_at, updated_at)
       VALUES
         (:id, :idea_id, :level, :slug, :run_id, :action, :summary,
          :draft, :confidence, :provider, :model, 'draft', :now, :now)`,
      {
        id: makeId(),
        idea_id: input.entityId,
        level: bnLevel,
        slug: input.agentSlug,
        run_id: runId,
        action: advisory.recommended_action,
        summary: advisory.summary,
        draft: json(advisory.draft),
        confidence: advisory.confidence,
        provider: advisory.provider,
        model: advisory.model,
        now: nowSql()
      }
    );
    void BN_COPILOT_SLUG; // (kept for symmetry / future per-level routing)
    // Notify the current-stage reviewer that an AI advisory is ready. Without
    // this the copilot draft — the central BN AI deliverable — was written
    // silently and the reviewer never knew it existed on their queue.
    const reviewerField =
      bnLevel === 'l1' ? 'l1_reviewer_id' : bnLevel === 'l2' ? 'l2_reviewer_id' : 'l3_reviewer_id';
    const reviewerId = (idea as unknown as Record<string, unknown>)[reviewerField] as
      | string
      | null
      | undefined;
    if (reviewerId) {
      await execute(
        `INSERT INTO notifications
           (id, profile_id, title, body, entity_type, entity_id, created_at, updated_at)
         VALUES (:id, :pid, :title, :body, 'bn_advisory_ready', :entity_id, :now, :now)`,
        {
          id: makeId(),
          pid: reviewerId,
          title: `AI ${bnLevel.toUpperCase()} advisory ready: "${(idea as { title?: string }).title ?? 'idea'}"`,
          body: `Recommended: ${advisory.recommended_action}. Open the review screen to Apply / Edit / Dismiss.`,
          entity_id: input.entityId,
          now: nowSql()
        }
      ).catch(() => undefined);
    }
    await finish('succeeded', {
      output_payload: advisory.draft,
      output_summary: `${bnLevel.toUpperCase()} advisory: ${advisory.recommended_action}`,
      model_provider: advisory.provider,
      model_name: advisory.model
    });
    // Hermes reflection — learn from this draft (and later from the
    // human's accept/edit/dismiss, via reflectOnBnFeedbackAsync).
    reflectOnRunAsync({
      agentSlug: input.agentSlug,
      agentRunId: runId,
      inputSummary: `BN ${bnLevel.toUpperCase()} draft for "${(idea as { title?: string }).title ?? ''}"`,
      output: advisory.draft
    });
    return getRun(runId);
  }

  // D4/D6 AI Reviewer scorecard agent. Produces the 5-dimension/100-pt
  // scorecard + tier + tier-driven SLA. On a scheduled run it only scores
  // ideas that have never been scored (backfill); manual/event triggers
  // always (re)score. Advisory only — routing is informed, not forced.
  if (input.agentSlug === 'bn-scoring-agent' && input.entityType === 'idea' && input.entityId) {
    if (input.triggerType === 'scheduled') {
      const scored = (await query<RowDataPacket[]>(
        'SELECT scorecard_tier FROM ideas WHERE id = :id LIMIT 1',
        { id: input.entityId }
      )) as Array<{ scorecard_tier: number | null }>;
      if (scored[0]?.scorecard_tier != null) {
        await addStep(runId, 2, 'Idempotency check', 'context', 'succeeded', 'Already scored.');
        await finish('succeeded', { output_summary: 'Already scored; skipped.' });
        return getRun(runId);
      }
    }
    const { runAndStoreScorecard } = await import('./bn-scoring.js');
    const card = await runAndStoreScorecard(input.entityId, runId);
    if (!card) {
      await addStep(runId, 2, 'Score idea', 'tool', 'failed', 'Scoring failed or idea not found.');
      await finish('failed', { error_message: 'Scoring failed.' });
      return getRun(runId);
    }
    await addStep(
      runId,
      2,
      card.model_provider === 'deterministic_fallback'
        ? 'Deterministic scorecard'
        : `${card.model_provider} scorecard`,
      card.model_provider === 'deterministic_fallback' ? 'fallback' : 'llm',
      'succeeded',
      `Score ${card.total_score}/100 · Tier ${card.tier} (${card.tier_label})`
    );
    await finish('succeeded', {
      output_payload: { total_score: card.total_score, tier: card.tier },
      output_summary: `Scored ${card.total_score}/100 — Tier ${card.tier}`,
      model_provider: card.model_provider,
      model_name: card.model_name
    });
    return getRun(runId);
  }

  const action = await maybeCreateAction(input.agentSlug, runId, input.entityType, input.entityId);
  await addStep(
    runId,
    2,
    'Run deterministic handler',
    'fallback',
    'succeeded',
    action ? 'Created proposed action for human approval.' : 'Completed with no unsafe changes.'
  );
  await finish(action ? 'needs_approval' : 'succeeded', {
    output_payload: { proposedAction: action },
    output_summary: action
      ? 'Run completed and proposed an action requiring approval.'
      : 'Run completed with no unsafe changes applied.'
  });
  // F22 — Reflection on the deterministic-handler path too. Cheap;
  // the reflection module filters by agent slug internally so only
  // the in-scope agents actually pay the LLM call.
  if (!action) {
    const { reflectOnRunAsync } = await import('./agent-reflection.js');
    reflectOnRunAsync({
      agentSlug: input.agentSlug,
      agentRunId: runId,
      inputSummary: `${input.entityType ?? 'workspace'} ${input.entityId ?? ''}`.trim(),
      output: { proposedAction: action }
    });
  }
  return getRun(runId);
}

async function getIdea(id: string) {
  const rows = await query<RowDataPacket[]>('SELECT * FROM ideas WHERE id = :id LIMIT 1', { id });
  return rows[0] as unknown as IdeaLike | undefined;
}

/**
 * Stream B (B4) — load the 7-phase dossier as a compact snapshot ready
 * for the triage LLM. Returns `undefined` when no child rows exist so
 * callers can keep the legacy code path.
 */
async function getDossierForAgent(ideaId: string): Promise<DossierSignals | undefined> {
  const [tasks, decisions, dataSources, toolLinks, exceptionRows, kpis] = await Promise.all([
    query<RowDataPacket[]>(
      `SELECT description, step_type, avg_time_minutes, role_responsible, pain_points
         FROM idea_workflow_steps WHERE idea_id = :id ORDER BY step_number ASC LIMIT 50`,
      { id: ideaId }
    ),
    query<RowDataPacket[]>(
      `SELECT description, risk_level, automation_potential
         FROM idea_decisions WHERE idea_id = :id ORDER BY created_at ASC LIMIT 30`,
      { id: ideaId }
    ),
    query<RowDataPacket[]>(
      `SELECT field_name, source_system, format_type, reliability, is_sensitive
         FROM idea_data_sources WHERE idea_id = :id ORDER BY created_at ASC LIMIT 30`,
      { id: ideaId }
    ),
    query<RowDataPacket[]>(
      `SELECT t.name, t.category, t.integration_type
         FROM idea_tools it
         JOIN tools t ON t.id = it.tool_id
        WHERE it.idea_id = :id ORDER BY t.name ASC LIMIT 30`,
      { id: ideaId }
    ),
    query<RowDataPacket[]>(
      `SELECT scenario, impact, human_intervention_required
         FROM idea_exceptions WHERE idea_id = :id ORDER BY created_at ASC LIMIT 30`,
      { id: ideaId }
    ),
    query<RowDataPacket[]>(
      `SELECT kpi_name, current_target, current_actual, improvement_goal
         FROM idea_kpis WHERE idea_id = :id ORDER BY created_at ASC LIMIT 30`,
      { id: ideaId }
    )
  ]);
  const total =
    tasks.length +
    decisions.length +
    dataSources.length +
    toolLinks.length +
    exceptionRows.length +
    kpis.length;
  if (total === 0) return undefined;
  return {
    tasks: (tasks as Array<Record<string, unknown>>).map((r) => ({
      description: String(r.description),
      step_type: (r.step_type as DossierSignals['tasks'][0]['step_type']) ?? 'manual',
      avg_time_minutes: typeof r.avg_time_minutes === 'number' ? r.avg_time_minutes : null,
      role_responsible: r.role_responsible ? String(r.role_responsible) : null,
      pain_points: r.pain_points ? String(r.pain_points) : null
    })),
    decisions: (decisions as Array<Record<string, unknown>>).map((r) => ({
      description: String(r.description),
      risk_level: (r.risk_level as DossierSignals['decisions'][0]['risk_level']) ?? 'low',
      automation_potential:
        (r.automation_potential as DossierSignals['decisions'][0]['automation_potential']) ?? null
    })),
    data_sources: (dataSources as Array<Record<string, unknown>>).map((r) => ({
      field_name: String(r.field_name),
      source_system: r.source_system ? String(r.source_system) : null,
      format_type: (r.format_type as DossierSignals['data_sources'][0]['format_type']) ?? null,
      reliability: (r.reliability as DossierSignals['data_sources'][0]['reliability']) ?? null,
      is_sensitive: Boolean(r.is_sensitive)
    })),
    tools: (toolLinks as Array<Record<string, unknown>>).map((r) => ({
      name: String(r.name),
      category: r.category ? String(r.category) : null,
      integration_type:
        (r.integration_type as DossierSignals['tools'][0]['integration_type']) ?? 'unknown'
    })),
    exceptions: (exceptionRows as Array<Record<string, unknown>>).map((r) => ({
      scenario: String(r.scenario),
      impact: (r.impact as DossierSignals['exceptions'][0]['impact']) ?? null,
      human_intervention_required: Boolean(r.human_intervention_required)
    })),
    kpis: (kpis as Array<Record<string, unknown>>).map((r) => ({
      kpi_name: String(r.kpi_name),
      current_target: r.current_target ? String(r.current_target) : null,
      current_actual: r.current_actual ? String(r.current_actual) : null,
      improvement_goal: r.improvement_goal ? String(r.improvement_goal) : null
    }))
  };
}

async function getRun(id: string) {
  const rows = await query<RowDataPacket[]>('SELECT * FROM agent_runs WHERE id = :id LIMIT 1', {
    id
  });
  return rows[0];
}

async function isPaused(agentSlug: string) {
  const rows = await query<RowDataPacket[]>(
    'SELECT is_paused FROM agent_registry_overrides WHERE agent_slug = :agent_slug LIMIT 1',
    { agent_slug: agentSlug }
  );
  return Boolean(rows[0]?.is_paused);
}

async function isBlocked(agentSlug: string) {
  const rows = await query<RowDataPacket[]>(
    `SELECT reason FROM agent_kill_switches
     WHERE is_active = 1
       AND (scope_type = 'global' OR (scope_type = 'agent' AND scope_value = :agent_slug))
     ORDER BY created_at DESC LIMIT 1`,
    { agent_slug: agentSlug }
  );
  return rows[0]?.reason
    ? String(rows[0].reason)
    : rows.length
      ? 'Run blocked by kill switch.'
      : undefined;
}

async function budgetExceeded(agentSlug: string) {
  const budgets = await query<RowDataPacket[]>(
    `SELECT * FROM agent_budgets
     WHERE is_enabled = 1 AND (scope_type = 'global' OR agent_slug = :agent_slug)
     ORDER BY scope_type DESC`,
    { agent_slug: agentSlug }
  );
  const budget = budgets[0] as Record<string, number | string | null> | undefined;
  if (!budget) return undefined;
  const monthlyRows = await query<RowDataPacket[]>(
    `SELECT COUNT(*) AS count FROM agent_runs
     WHERE agent_slug = :agent_slug AND created_at >= date_trunc('month', now())`,
    { agent_slug: agentSlug }
  );
  const dailyRows = await query<RowDataPacket[]>(
    `SELECT COUNT(*) AS count FROM agent_runs
     WHERE agent_slug = :agent_slug AND created_at >= current_date`,
    { agent_slug: agentSlug }
  );
  const monthly = Number(monthlyRows[0]?.count ?? 0);
  const daily = Number(dailyRows[0]?.count ?? 0);
  if (budget.monthly_run_budget && monthly > Number(budget.monthly_run_budget)) {
    return 'Monthly agent run budget exceeded.';
  }
  if (budget.daily_run_budget && daily > Number(budget.daily_run_budget)) {
    return 'Daily agent run budget exceeded.';
  }
  // Gotcha #3 fix: enforce monthly token budget alongside run-count budgets.
  // Sums total_tokens from agent_cost_events for the agent in the current
  // month; if the configured monthly_token_budget is exceeded, the next run
  // is blocked the same way a run-count breach blocks it. Configured budgets
  // that don't set a token cap are unaffected (current behaviour).
  if (budget.monthly_token_budget) {
    const tokenRows = await query<RowDataPacket[]>(
      `SELECT COALESCE(SUM(c.total_tokens), 0) AS total
         FROM agent_cost_events c
         JOIN agent_runs r ON r.id = c.agent_run_id
        WHERE r.agent_slug = :agent_slug
          AND r.created_at >= date_trunc('month', now())`,
      { agent_slug: agentSlug }
    );
    const monthlyTokens = Number(tokenRows[0]?.total ?? 0);
    if (monthlyTokens >= Number(budget.monthly_token_budget)) {
      return 'Monthly agent token budget exceeded.';
    }
  }
  return undefined;
}

async function addStep(
  runId: string,
  stepIndex: number,
  stepName: string,
  stepType: string,
  status: string,
  outputSummary?: string,
  latencyMs = 20
) {
  const started = nowSql();
  await execute(
    `INSERT INTO agent_run_steps
     (id, agent_run_id, step_index, step_name, step_type, status, output_summary, latency_ms, started_at, finished_at, created_at, updated_at)
     VALUES (:id, :agent_run_id, :step_index, :step_name, :step_type, :status, :output_summary, :latency_ms, :started_at, :finished_at, :created_at, :updated_at)`,
    {
      id: makeId(),
      agent_run_id: runId,
      step_index: stepIndex,
      step_name: stepName,
      step_type: stepType,
      status,
      output_summary: outputSummary ?? null,
      latency_ms: latencyMs,
      started_at: started,
      finished_at: nowSql(),
      created_at: started,
      updated_at: started
    }
  );
}

async function policyResult(runId: string, policySlug: string, status: string, message: string) {
  await execute(
    `INSERT INTO agent_policy_results
     (id, agent_run_id, policy_slug, status, severity, message, created_at, updated_at)
     VALUES (:id, :agent_run_id, :policy_slug, :status, :severity, :message, :created_at, :updated_at)`,
    {
      id: makeId(),
      agent_run_id: runId,
      policy_slug: policySlug,
      status,
      severity: status === 'failed' ? 'high' : 'low',
      message,
      created_at: nowSql(),
      updated_at: nowSql()
    }
  );
}

async function guardrailResult(
  runId: string,
  guardrailSlug: string,
  guardrailType: string,
  status: string,
  message: string
) {
  await execute(
    `INSERT INTO agent_guardrail_results
     (id, agent_run_id, guardrail_slug, guardrail_type, status, message, created_at, updated_at)
     VALUES (:id, :agent_run_id, :guardrail_slug, :guardrail_type, :status, :message, :created_at, :updated_at)`,
    {
      id: makeId(),
      agent_run_id: runId,
      guardrail_slug: guardrailSlug,
      guardrail_type: guardrailType,
      status,
      message,
      created_at: nowSql(),
      updated_at: nowSql()
    }
  );
}

/**
 * F33a — Notify reviewers + admins (excluding the agent itself, since
 * the agent isn't a profile) that a new proposal has landed in the
 * inbox. Called from every site that writes an `agent_actions` row.
 *
 * Best-effort: notification failures must never block the agent run.
 */
export async function notifyAgentActionProposed(input: {
  agentSlug: string;
  actionType: string;
  entityType?: string;
  entityId?: string;
  ideaTitle?: string;
}) {
  try {
    const approverRows = (await query<RowDataPacket[]>(
      `SELECT id FROM profiles
        WHERE role IN ('admin', 'reviewer')
          AND is_active = 1`
    )) as Array<{ id: string }>;
    if (!approverRows.length) return;
    const now = nowSql();
    const title = input.ideaTitle
      ? `New agent proposal: "${input.ideaTitle}"`
      : `New agent proposal from ${input.agentSlug}`;
    const verb = input.actionType.replace(/_/g, ' ');
    const body = `${input.agentSlug} suggests: ${verb}. Approve or reject in the Agents inbox.`;
    for (const approver of approverRows) {
      await execute(
        `INSERT INTO notifications
           (id, profile_id, title, body, entity_type, entity_id, created_at, updated_at)
         VALUES (:id, :pid, :title, :body, 'agent_proposal', :entity_id, :now, :now)`,
        {
          id: makeId(),
          pid: approver.id,
          title,
          body,
          entity_id: input.entityId ?? null,
          now
        }
      ).catch(() => undefined);
    }
  } catch {
    /* swallow */
  }
}

async function maybeCreateAction(
  agentSlug: string,
  runId: string,
  entityType?: string,
  entityId?: string
) {
  // The apply-dispatcher only implements 'propose_status_change'; the old
  // 'create_poc_plan' / 'sync_external_system' canned actions were never
  // applicable, so approving them did nothing. The only agent that emitted
  // an *applicable* canned action (reviewer-copilot) is retired in favour of
  // the real BN L1/L2/L3 copilots. So no agent emits a canned action here
  // any more — idea-triage proposes its (real, applicable) status change on
  // its own dedicated path. Kept as a map so re-enabling is a one-line add.
  const actionTypeByAgent: Record<string, string> = {};
  const actionType = actionTypeByAgent[agentSlug];
  if (!actionType || !entityType) return undefined;
  const action = {
    ...baseRecord(),
    agent_run_id: runId,
    action_type: actionType,
    entity_type: entityType,
    entity_id: entityId ?? null,
    proposed_payload: {
      status: actionType === 'propose_status_change' ? 'prioritized' : undefined,
      recommendation: `${agentSlug} recommends human review before applying this action.`
    },
    risk_level: actionType.includes('sync') ? 'high' : 'medium',
    requires_approval: true,
    status: 'proposed'
  };
  await execute(
    `INSERT INTO agent_actions
     (id, agent_run_id, action_type, entity_type, entity_id, proposed_payload, risk_level, requires_approval, status, created_at, updated_at)
     VALUES (:id, :agent_run_id, :action_type, :entity_type, :entity_id, :proposed_payload, :risk_level, 1, 'proposed', :created_at, :updated_at)`,
    { ...action, proposed_payload: json(action.proposed_payload) }
  );
  await audit('approval_requested', {
    agentSlug,
    agentRunId: runId,
    entityType,
    entityId,
    newValue: action
  });
  // F33a — Push the proposal into the reviewer/admin inbox.
  let ideaTitle: string | undefined;
  if (entityType === 'idea' && entityId) {
    const titleRows = (await query<RowDataPacket[]>(
      'SELECT title FROM ideas WHERE id = :id LIMIT 1',
      { id: entityId }
    )) as Array<{ title: string }>;
    ideaTitle = titleRows[0]?.title;
  }
  await notifyAgentActionProposed({
    agentSlug,
    actionType,
    entityType,
    entityId,
    ideaTitle
  });
  // Gotcha #2a fix: emit the previously-silent agent.action_proposed event.
  await dispatchWebhook('agent.action_proposed', {
    action_id: action.id,
    run_id: runId,
    agent_slug: agentSlug,
    action_type: actionType,
    entity_type: entityType,
    entity_id: entityId,
    risk_level: action.risk_level
  });
  return action;
}

export async function audit(
  eventType: string,
  input: {
    actor?: ProfileLike;
    agentSlug?: string;
    agentRunId?: string;
    entityType?: string;
    entityId?: string;
    oldValue?: unknown;
    newValue?: unknown;
    metadata?: Record<string, unknown>;
    traceId?: string;
  } = {}
) {
  const now = nowSql();
  // Risk 6 fix: entity_id is a uuid column, but security/audit callers pass
  // non-uuid identifiers (route paths, permission keys, 'from->to') for
  // entityId. Binding those raised 22P02 and the swallowed insert dropped the
  // row entirely. Keep entity_id null for non-uuid refs and preserve the
  // original value inside metadata so no information is lost. This is safe even
  // before the 0003 column widening lands.
  const isUuid = (s: string): boolean =>
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
  const hasEntityId = input.entityId != null && input.entityId !== '';
  const entityIdIsUuid = hasEntityId && isUuid(input.entityId as string);
  const entityId = entityIdIsUuid ? (input.entityId as string) : null;
  const metadata =
    hasEntityId && !entityIdIsUuid
      ? { ...(input.metadata ?? {}), entity_ref: input.entityId }
      : input.metadata ?? {};
  await execute(
    `INSERT INTO agent_audit_events
     (id, event_type, actor_id, actor_role, agent_slug, agent_run_id, entity_type, entity_id, old_value, new_value, metadata, trace_id, created_at, updated_at)
     VALUES (:id, :event_type, :actor_id, :actor_role, :agent_slug, :agent_run_id, :entity_type, :entity_id, :old_value, :new_value, :metadata, :trace_id, :created_at, :updated_at)`,
    {
      id: makeId(),
      event_type: eventType,
      actor_id: input.actor?.id ?? null,
      actor_role: input.actor?.role ?? null,
      agent_slug: input.agentSlug ?? null,
      agent_run_id: input.agentRunId ?? null,
      entity_type: input.entityType ?? null,
      entity_id: entityId,
      old_value: json(redact(input.oldValue ?? null)),
      new_value: json(redact(input.newValue ?? null)),
      metadata: json(redact(metadata)),
      trace_id: input.traceId ?? null,
      created_at: now,
      updated_at: now
    }
  );
}

async function createIncident(
  title: string,
  description: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  agentSlug?: string,
  agentRunId?: string
) {
  const now = nowSql();
  const incidentId = makeId();
  await execute(
    `INSERT INTO agent_incidents
     (id, title, description, severity, status, agent_slug, agent_run_id, opened_at, created_at, updated_at)
     VALUES (:id, :title, :description, :severity, 'open', :agent_slug, :agent_run_id, :opened_at, :created_at, :updated_at)`,
    {
      id: incidentId,
      title,
      description,
      severity,
      agent_slug: agentSlug ?? null,
      agent_run_id: agentRunId ?? null,
      opened_at: now,
      created_at: now,
      updated_at: now
    }
  );
  // Gotcha #2a fix: emit the previously-silent agent.incident_opened event.
  await dispatchWebhook('agent.incident_opened', {
    incident_id: incidentId,
    title,
    severity,
    agent_slug: agentSlug ?? null,
    agent_run_id: agentRunId ?? null
  });
}

export function requireManager(role: AppRole) {
  if (!canManage(role)) {
    throw Object.assign(new Error('Admin access required.'), { statusCode: 403 });
  }
}

/** Real output guardrail for the triage agent — validates the LLM/fallback
 *  payload actually has the shape downstream code persists. A failure aborts
 *  the write rather than storing garbage. Today the producer guarantees the
 *  shape (so this passes), but it is a genuine gate that catches a regression
 *  — not the old hard-coded 'passed'. */
function validateTriageOutput(output: unknown): { ok: boolean; message: string } {
  const o = output as Record<string, unknown> | null;
  if (!o || typeof o !== 'object') return { ok: false, message: 'Output is not an object.' };
  if (typeof o.summary !== 'string' || o.summary.trim().length === 0) {
    return { ok: false, message: 'Missing summary.' };
  }
  const scores = ['impact_score', 'feasibility_score', 'data_readiness_score'] as const;
  for (const k of scores) {
    const v = o[k];
    if (typeof v !== 'number' || v < 0 || v > 100) {
      return { ok: false, message: `Invalid ${k}.` };
    }
  }
  if (!['low', 'medium', 'high', 'critical'].includes(String(o.risk_level))) {
    return { ok: false, message: 'Invalid risk_level.' };
  }
  return { ok: true, message: 'Output schema validation passed.' };
}

// Rough blended price for the gemma4-26b class model (USD per token). The
// number is an estimate for cost *tracking* — exact billing lives with the
// provider. A deterministic-fallback run made no API call, so it costs 0.
const COST_PER_TOKEN_USD = 0.00000025; // ~$0.25 / 1M tokens
function estimateCostUsd(provider: string, totalTokens: number): number {
  if (provider === 'deterministic_fallback' || !totalTokens) return 0;
  return Number((totalTokens * COST_PER_TOKEN_USD).toFixed(6));
}
