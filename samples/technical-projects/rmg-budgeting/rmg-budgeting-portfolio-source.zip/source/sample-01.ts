/**
 * Configurable margin-tier approval rules — BRD §8.1 as data, not code.
 *
 * The Admin console edits the tier table stored in PostgreSQL (`app_config`
 * key `approval_rules`) and served by the API; these defaults mirror the BRD
 * and are the offline fallback. Tiers are evaluated top-down (highest margin
 * first): the first tier whose comparison matches decides the approver chain;
 * when none match, `fallback` applies (the "< lowest threshold" row).
 */
import type { ApproverRole } from './types.js';

/** Comparison of margin against the tier threshold. */
export type TierOp = 'gte' | 'gt';

export interface ApprovalTier {
  /** Threshold as a percent, e.g. 30 for 30%. */
  threshold: number;
  /** 'gte' → margin ≥ threshold matches; 'gt' → margin > threshold matches. */
  op: TierOp;
  /** Ordered sign-off chain required in this tier; [] = auto-approved. */
  approvers: ApproverRole[];
}

export interface ApprovalRules {
  /** Evaluated top-down; keep thresholds descending. */
  tiers: ApprovalTier[];
  /** Chain when no tier matches. */
  fallback: ApproverRole[];
}

/** BRD §8.1 defaults — mirrors backend/app/rbac.py DEFAULT_APPROVAL_RULES. */
export const DEFAULT_APPROVAL_RULES: ApprovalRules = {
  tiers: [
    { threshold: 30, op: 'gte', approvers: [] },
    { threshold: 25, op: 'gte', approvers: ['PO'] },
    { threshold: 20, op: 'gte', approvers: ['PO', 'HOD'] },
  ],
  fallback: ['PO', 'HOD', 'COO'],
};

export const OP_SYMBOL: Record<TierOp, string> = { gte: '≥', gt: '>' };

function matches(marginPctFraction: number, tier: ApprovalTier): boolean {
  const m = marginPctFraction * 100;
  return tier.op === 'gte' ? m >= tier.threshold : m > tier.threshold;
}

/** The approver chain a margin (fraction, e.g. 0.28) requires under `rules`. */
export function requiredApproversFor(
  marginPctFraction: number,
  rules: ApprovalRules = DEFAULT_APPROVAL_RULES,
): ApproverRole[] {
  for (const tier of rules.tiers) {
    if (matches(marginPctFraction, tier)) return tier.approvers;
  }
  return rules.fallback;
}

export interface TierRow {
  /** e.g. "≥ 30%" or "25% – <30%" or "< 20%" */
  cond: string;
  /** e.g. "PO → HOD" or "None" */
  chain: string;
  approvers: ApproverRole[];
  /** True when the given margin lands in this row. */
  active: (marginPctFraction: number) => boolean;
}

/** Rows for the tier table UI, derived from the rules (last row = fallback). */
export function tierRows(rules: ApprovalRules = DEFAULT_APPROVAL_RULES): TierRow[] {
  const rows: TierRow[] = rules.tiers.map((t, i) => {
    const upper = i === 0 ? null : rules.tiers[i - 1];
    // The upper bound is the previous tier's threshold; its op decides whether
    // that bound is open ("<30%") or closed ("≤30%").
    const upperTxt = upper ? ` – ${upper.op === 'gte' ? '<' : '≤'}${upper.threshold}%` : '';
    const cond = upper ? `${OP_SYMBOL[t.op]} ${t.threshold}%${upperTxt}` : `${OP_SYMBOL[t.op]} ${t.threshold}%`;
    return {
      cond,
      chain: t.approvers.length ? t.approvers.join(' → ') : 'None',
      approvers: t.approvers,
      active: (m) => requiredApproversFor(m, rules) === t.approvers && matches(m, t),
    };
  });
  const last = rules.tiers[rules.tiers.length - 1];
  rows.push({
    cond: last ? `${last.op === 'gte' ? '<' : '≤'} ${last.threshold}%` : 'Any margin',
    chain: rules.fallback.length ? rules.fallback.join(' → ') : 'None',
    approvers: rules.fallback,
    active: (m) => rules.tiers.every((t) => !matches(m, t)),
  });
  return rows;
}

/** Validation for the Admin editor; returns an error message or null. */
export function validateRules(rules: ApprovalRules): string | null {
  if (!Array.isArray(rules.tiers) || rules.tiers.length === 0) {
    return 'At least one tier is required.';
  }
  for (const [i, t] of rules.tiers.entries()) {
    if (!Number.isFinite(t.threshold) || t.threshold < 0 || t.threshold > 100) {
      return `Tier ${i + 1}: threshold must be between 0 and 100.`;
    }
    if (t.op !== 'gte' && t.op !== 'gt') return `Tier ${i + 1}: invalid comparison.`;
    if (i > 0 && t.threshold >= rules.tiers[i - 1].threshold) {
      return 'Thresholds must decrease from top to bottom.';
    }
  }
  return null;
}
