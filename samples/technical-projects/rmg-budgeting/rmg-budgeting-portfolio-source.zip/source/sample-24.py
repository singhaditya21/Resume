"""Password hashing for app_users — demo-grade (salted SHA-256, salt = username).

Every account starts with DEFAULT_PASSWORD; users change it in-app (Summary →
My Account) and admins can reset it from the Admin console. For production
this should move to bcrypt/argon2 — kept dependency-free for the demo.
"""
from __future__ import annotations

import hashlib

DEFAULT_PASSWORD = REDACTED_SECRET
def pw_hash(username: str, password: str) -> str:
    return hashlib.sha256(f"{username.strip().lower()}:{password}".encode()).hexdigest()
