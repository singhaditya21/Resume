/**
 * App state + reducer.
 *
 * The app is a paged application: a Budget List (home) and a Budget Editor
 * whose pages follow the workflow stages — 1 Budget Details, 2 Resource Plan,
 * 3 Review & Versions, 4 Approval. Multiple budgets are kept in a map; each
 * budget document carries its own versions, approvals and submission flag.
 * Every mutating action recomputes the approval signature; if it moved, the
 * document's sign-offs reset and it drops back to Draft (BRD §8.2).
 */
import {
  ALL_ROLES,
  approvalSignature,
  clamp,
  computeBudget,
  DEFAULT_APPROVAL_RULES,
  DEFAULT_ROLE_PERMISSIONS,
  emptyApprovals,
  ensureWindows,
  hasAdminAccess,
  hasPermission,
  num,
  resizeToMonths,
  revoke,
  SAMPLE_STATE,
  seedVersions,
  type ApprovalMap,
  type ApprovalRules,
  type ApproverRole,
  type BudgetState,
  type BudgetVersion,
  type ExportEnvelope,
  type Location,
  type Role,
  type RolePermissionMap,
} from '@rmg/engine';

/**
 * Who put a budget forward for approval, captured at submission.
 *
 * The approval chain is about to resolve from this person — their RM1 and HOD —
 * so it has to exist before any of that can be built. Recorded here for display
 * and for the resolver to read; before approval is *enforced* on it, the server
 * must be the one writing it, because a client-supplied submitter would let
 * someone choose their own approvers.
 */
export interface Submitter {
  /** Account username (an email for directory accounts). */
  username: string;
  /** Display name at the time of submission. */
  displayName: string;
  /** Directory link — the key the RM1/HOD lookup needs. Absent for accounts
   *  with no employee record, such as the built-in `admin`. */
  employeeId?: number;
  at: string;
}

/** One entry in a budget's approval history. */
export interface Decision {
  role: ApproverRole;
  /** 'approve' signs off; 'revoke' withdraws a sign-off and sends the budget back. */
  action: 'approve' | 'revoke';
  /** Who acted, and the role they were acting as. */
  by: string;
  at: string;
  /** Why. Optional on approval, expected on a revoke — an approver who sends a
   *  budget back should be able to say what needs to change. */
  note?: string;
  /** Budget signature at the time, so a decision cannot be silently re-attached
   *  to a re-priced budget. */
  signature: string;
}

/** One budget workspace: plan + versions + approval state. */
export interface BudgetDoc {
  budget: BudgetState;
  versions: BudgetVersion[];
  approvals: ApprovalMap;
  signature: string;
  submitted: boolean;
  updatedAt: string;
  /** Append-only approval history. Optional so documents saved before this
   *  existed load unchanged. */
  decisions?: Decision[];
  /** Set when the budget is submitted, cleared when it returns to Draft.
   *  Optional for the same reason as `decisions`: budgets saved before this
   *  existed must load untouched. */
  submittedBy?: Submitter;
}

export const EDITOR_STEPS = [
  { n: 1, title: 'Budget Details', hint: 'Project & assumptions' },
  { n: 2, title: 'Resource Plan', hint: 'Phases & allocation grid' },
  { n: 3, title: 'Review & Versions', hint: 'P&L, roll-ups, snapshots' },
  { n: 4, title: 'Approval', hint: 'Submit & sign-off chain' },
] as const;

/** Administration is five separate pages, each with its own route and rail entry. */
export type AdminPageKey = 'users' | 'accounts' | 'perms' | 'lov' | 'rules';

export interface AppState {
  budgets: Record<string, BudgetDoc>;
  activeId: string | null;
  view: 'list' | 'editor' | 'admin' | 'settings';
  /** Editor page, 1..4 */
  step: number;
  /** Role the user is acting as — drives role-wise access. */
  role: Role;
  /** Signed-in username (demo auth); null shows the login page. */
  user: string | null;
  /** Signed-in email when known — used for RM access-request matching. */
  userEmail: string | null;
  /** Roles this user may act as; the header dropdown is limited to these. */
  availableRoles: Role[];
  /** Bounded undo stack of previous `budgets` maps. Never persisted — see
   *  persist() — so it cannot bloat localStorage or survive a reload. */
  history?: Record<string, BudgetDoc>[];
  /** Which Administration page is open when view === 'admin'. */
  adminPage: AdminPageKey;
  /** Live role → permission matrix (server-loaded; defaults offline). */
  permissions: RolePermissionMap;
  /** Live margin-tier approval rules (server-loaded; BRD defaults offline). */
  approvalRules: ApprovalRules;
}

export type Action =
  | { type: 'project'; field: 'pid' | 'name' | 'start' | 'goLive'; value: string }
  | { type: 'assumption'; field: 'rev' | 'uplift' | 'eff' | 'exp' | 'travel'; value: number }
  | { type: 'months'; value: number }
  | { type: 'phase.upd'; i: number; field: 'n' | 's' | 'e'; value: string | number }
  | { type: 'phase.add' }
  | { type: 'phase.del'; i: number }
  | { type: 'role.upd'; i: number; field: 'team' | 'role' | 'loc' | 'cpm' | 'start' | 'dur'; value: string | number }
  | { type: 'role.pick'; i: number; roleId: string; name: string }
  | { type: 'role.add' }
  | { type: 'role.del'; i: number }
  | { type: 'alloc'; i: number; j: number; value: number }
  /** Copy a role's first in-window month across the rest of its window. */
  | { type: 'alloc.fill'; i: number }
  /** Spread a total man-month figure evenly across a role's active window. */
  | { type: 'alloc.spread'; i: number; total: number }
  | { type: 'undo' }
  | { type: 'submit'; by?: Submitter }
  | { type: 'approve'; role: ApproverRole; note?: string }
  | { type: 'revoke'; role: ApproverRole; note?: string }
  | { type: 'role.set'; role: Role }
  | { type: 'version.save'; label: string }
  | { type: 'version.del'; id: number }
  | { type: 'version.restore'; id: number }
  | { type: 'versions.resetSeed' }
  | { type: 'import'; envelope: ExportEnvelope }
  | { type: 'reset' }
  // paged-application navigation & budget management
  | { type: 'login'; user: string; role?: Role; email?: string; roles?: Role[] }
  | { type: 'logout' }
  | { type: 'permissions.set'; matrix: RolePermissionMap }
  | { type: 'rules.set'; rules: ApprovalRules }
  | { type: 'nav.admin'; page?: AdminPageKey }
  | { type: 'nav.settings' }
  | { type: 'budget.new' }
  | { type: 'budget.open'; id: string }
  | { type: 'budget.del'; id: string }
  /** Inline edit from the budget list — targets a budget by id, not the active one.
   *  Project ID is deliberately absent: it is the key budgets sync under, and
   *  renaming it from a list row would orphan the existing database record. */
  | { type: 'budget.edit'; id: string; field: 'name' | 'rev'; value: string }
  | { type: 'budget.save' }
  | { type: 'nav.step'; step: number }
  | { type: 'nav.list' };

const STORAGE_KEY = 'rmg_budgeting_workspace_v2';
const LEGACY_KEY = 'rmg_budgeting_workspace_v1';

let idCounter = 0;
function newId(): string {
  idCounter += 1;
  return `b_${Date.now().toString(36)}_${idCounter}`;
}

function docSignature(budget: BudgetState): string {
  return approvalSignature(computeBudget(budget));
}

function makeDoc(budget: BudgetState, versions: BudgetVersion[] = []): BudgetDoc {
  return {
    budget,
    versions,
    approvals: emptyApprovals(),
    signature: docSignature(budget),
    submitted: false,
    updatedAt: new Date().toISOString(),
  };
}

/**
 * The Project ID is the natural key: budgets sync to PostgreSQL under it, so it
 * must survive a URL path and a database lookup unchanged. Allowed: letters,
 * digits, hyphen, underscore — no spaces, no other punctuation.
 */
export const PID_PATTERN = /[^A-Za-z0-9_-]/g;

export function sanitisePid(value: string): string {
  return String(value).replace(PID_PATTERN, '');
}

/**
 * Next free Project ID, PRJ-{year}-{sequence}. Allocated by the app rather than
 * typed: the ID is the key a budget is stored and synced under, so leaving it to
 * a person invited collisions (two budgets sharing a key silently overwrite one
 * another on sync, since project_ref is UNIQUE), house-style drift, and typos
 * that could never be corrected once the ID was in use.
 *
 * The sequence continues from the highest existing ID for the current year, so
 * it survives deletions rather than reusing a retired number.
 *
 * Client-side allocation is safe for a single workspace but cannot coordinate
 * across users; the durable form is a server-side sequence, which also gives
 * imported budgets a guaranteed-unique key.
 */
export function nextProjectId(budgets: Record<string, BudgetDoc>, year = new Date().getFullYear()): string {
  const prefix = `PRJ-${year}-`;
  const taken = new Set(Object.values(budgets).map((d) => d.budget.project.pid));
  let highest = 0;
  for (const pid of taken) {
    if (!pid?.startsWith(prefix)) continue;
    const n = Number.parseInt(pid.slice(prefix.length), 10);
    if (Number.isFinite(n) && n > highest) highest = n;
  }
  // Step past anything already claimed, in case an imported budget brought its own.
  let seq = highest + 1;
  while (taken.has(prefix + String(seq).padStart(3, '0'))) seq += 1;
  return prefix + String(seq).padStart(3, '0');
}

function blankBudget(): BudgetState {
  return {
    project: { pid: '', name: '', start: '', goLive: '' },
    assumptions: { rev: 0, uplift: 25, eff: 15, exp: 10, travel: 50000, months: 12 },
    phases: [
      { n: 'IDR', s: 1, e: 2 },
      { n: 'Dev', s: 3, e: 6 },
      { n: 'SIT', s: 7, e: 8 },
      { n: 'UAT', s: 9, e: 10 },
      { n: 'Go-Live', s: 11, e: 11 },
      { n: 'Support', s: 12, e: 12 },
    ],
    roster: [
      { team: '', role: 'New role', loc: 'Offshore', cpm: 0, start: 1, dur: 12, alloc: Array(12).fill(0) },
    ],
  };
}

function seedDoc(): BudgetDoc {
  return makeDoc(structuredClone(SAMPLE_STATE), seedVersions());
}

function freshSeed(): AppState {
  const id = newId();
  return {
    budgets: { [id]: seedDoc() },
    activeId: id,
    view: 'list',
    step: 1,
    role: 'Planner',
    user: null,
    userEmail: null,
    adminPage: 'users',
    availableRoles: [...ALL_ROLES],
    permissions: DEFAULT_ROLE_PERMISSIONS,
    approvalRules: DEFAULT_APPROVAL_RULES,
  };
}

export function initialState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const saved = JSON.parse(raw) as AppState;
      if (saved.budgets && typeof saved.budgets === 'object') {
        for (const doc of Object.values(saved.budgets)) {
          ensureWindows(doc.budget.roster, doc.budget.assumptions.months);
          // Budgets created before IDs were generated — or imported without one —
          // get an ID here. The field is read-only now, so a budget with a blank
          // ID could never be given one by hand.
          if (!doc.budget.project.pid?.trim()) {
            doc.budget.project.pid = nextProjectId(saved.budgets);
          }
          doc.signature = docSignature(doc.budget);
        }
        return {
          budgets: saved.budgets,
          activeId: saved.activeId ?? Object.keys(saved.budgets)[0] ?? null,
          view:
            saved.view === 'admin' || saved.view === 'settings'
              ? saved.view
              : saved.view === 'editor' && saved.activeId
                ? 'editor'
                : 'list',
          step: clamp(Math.round(num(saved.step)) || 1, 1, 4),
          role: saved.role ?? 'Planner',
          user: saved.user ?? null,
          userEmail: saved.userEmail ?? null,
          adminPage: saved.adminPage ?? 'users',
          availableRoles: saved.availableRoles?.length ? saved.availableRoles : [...ALL_ROLES],
          permissions: saved.permissions ?? DEFAULT_ROLE_PERMISSIONS,
          approvalRules: saved.approvalRules ?? DEFAULT_APPROVAL_RULES,
        };
      }
    }
    // migrate the single-budget v1 workspace
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) {
      const old = JSON.parse(legacy);
      if (old?.budget?.assumptions) {
        ensureWindows(old.budget.roster, old.budget.assumptions.months);
        const id = newId();
        const doc = makeDoc(old.budget, Array.isArray(old.versions) ? old.versions : []);
        doc.submitted = old.submitted ?? false;
        doc.approvals = old.approvals ?? emptyApprovals();
        return {
          budgets: { [id]: doc },
          activeId: id,
          view: 'list',
          step: 1,
          role: old.role ?? 'Planner',
          user: null,
          userEmail: null,
          adminPage: 'users',
          availableRoles: [...ALL_ROLES],
          permissions: DEFAULT_ROLE_PERMISSIONS,
          approvalRules: DEFAULT_APPROVAL_RULES,
        };
      }
    }
  } catch {
    /* corrupted storage — fall through to seed */
  }
  return freshSeed();
}

export function persist(state: AppState): void {
  try {
    // history is deliberately dropped: it is a session-only convenience, and
    // serialising 20 snapshots of the workspace would blow the storage quota.
    const { history: _history, ...persisted } = state;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(persisted));
  } catch {
    /* storage full/blocked — working copy only */
  }
}

export function activeDoc(state: AppState): BudgetDoc | null {
  return state.activeId ? (state.budgets[state.activeId] ?? null) : null;
}

/** Role-wise access. Every gate consults the permission matrix (server-loaded,
 * Admin-editable; built-in defaults offline): edits need budget.edit, versions
 * version.manage, submit budget.submit, sign-offs approve.<stage>, the Admin
 * console an admin.* permission. */
const EDIT_ACTIONS = new Set<Action['type']>([
  'project', 'assumption', 'months',
  'phase.upd', 'phase.add', 'phase.del',
  'role.upd', 'role.pick', 'role.add', 'role.del', 'alloc', 'alloc.fill', 'alloc.spread', 'undo',
  'import', 'reset',
  'budget.new', 'budget.del', 'budget.save', 'budget.edit',
]);

const VERSION_ACTIONS = new Set<Action['type']>([
  'version.save', 'version.del', 'version.restore', 'versions.resetSeed',
]);

export function canPerform(role: Role, action: Action, perms: RolePermissionMap): boolean {
  if (
    action.type === 'login' ||
    action.type === 'logout' ||
    action.type === 'permissions.set' ||
    action.type === 'rules.set'
  ) {
    return true;
  }
  if (action.type === 'nav.admin') return hasAdminAccess(role, perms);
  if (action.type === 'role.set' || action.type.startsWith('nav.') || action.type === 'budget.open') return true;
  if (action.type === 'submit') return hasPermission(role, 'budget.submit', perms);
  if (action.type === 'approve' || action.type === 'revoke') {
    return hasPermission(role, `approve.${action.role}`, perms);
  }
  if (VERSION_ACTIONS.has(action.type)) return hasPermission(role, 'version.manage', perms);
  if (EDIT_ACTIONS.has(action.type)) return hasPermission(role, 'budget.edit', perms);
  return true;
}

/**
 * Append to a budget's approval history. Kept separate from the approval map
 * itself: the map answers "is this signed off?", the history answers "who
 * decided what, when, and why" — which is the question an auditor and a
 * returned-to planner both actually have.
 */
function recordDecision(
  doc: BudgetDoc,
  role: ApproverRole,
  action: 'approve' | 'revoke',
  by: string | null,
  note?: string,
): void {
  (doc.decisions ??= []).push({
    role,
    action,
    by: by || 'unknown',
    at: new Date().toISOString(),
    note: note?.trim() || undefined,
    signature: doc.signature,
  });
}

/** Reset approvals — and drop back to Draft — whenever an edit moved cost/margin (signature change). */
function guardSignature(doc: BudgetDoc): void {
  const sig = docSignature(doc.budget);
  if (sig !== doc.signature) {
    doc.signature = sig;
    doc.approvals = emptyApprovals();
    doc.submitted = false;
    // The budget is back in Draft, so it has no live submission — leaving the
    // submitter behind would make a resolved chain look current when it is not.
    delete doc.submittedBy;
  }
}

/** Edits worth remembering for undo — navigation and role switching are not. */
const UNDOABLE = new Set<Action['type']>([
  'project', 'assumption', 'months',
  'phase.upd', 'phase.add', 'phase.del',
  'role.upd', 'role.pick', 'role.add', 'role.del',
  'alloc', 'alloc.fill', 'alloc.spread',
  'import', 'reset', 'budget.del', 'budget.edit', 'version.restore',
]);
const HISTORY_LIMIT = 25;

export function reducer(state: AppState, action: Action): AppState {
  if (!canPerform(state.role, action, state.permissions)) return state;

  if (action.type === 'undo') {
    const stack = state.history ?? [];
    if (!stack.length) return state;
    const restored = structuredClone(state);
    restored.budgets = stack[stack.length - 1];
    restored.history = stack.slice(0, -1);
    // The restored workspace may not contain the budget that was open.
    if (restored.activeId && !restored.budgets[restored.activeId]) {
      restored.activeId = Object.keys(restored.budgets)[0] ?? null;
      restored.view = 'list';
    }
    return restored;
  }

  const next = structuredClone(state);

  if (UNDOABLE.has(action.type)) {
    // Snapshot before the edit lands, capped so a long session cannot grow
    // without bound.
    next.history = [...(state.history ?? []), structuredClone(state.budgets)].slice(-HISTORY_LIMIT);
  }

  /* ----- navigation & budget management ----- */
  switch (action.type) {
    case 'login':
      next.user = action.user.trim();
      next.userEmail = action.email?.trim() || null;
      // Directory accounts are limited to their assigned roles; demo sign-ins keep all.
      next.availableRoles = action.roles?.length ? action.roles : action.role ? [action.role] : [...ALL_ROLES];
      if (action.role) next.role = action.role;
      if (!next.availableRoles.includes(next.role)) next.role = next.availableRoles[0];
      next.view = 'list';
      return next;
    case 'logout':
      next.user = null;
      next.userEmail = null;
      return next;
    case 'rules.set':
      next.approvalRules = action.rules;
      return next;
    case 'permissions.set':
      next.permissions = action.matrix;
      // the matrix may have tightened — leave the admin view if access is gone
      if (next.view === 'admin' && !hasAdminAccess(next.role, next.permissions)) next.view = 'list';
      return next;
    case 'role.set':
      if (!next.availableRoles.includes(action.role)) return state; // not an assigned role
      next.role = action.role;
      if (next.view === 'admin' && !hasAdminAccess(action.role, next.permissions)) next.view = 'list';
      return next;
    case 'nav.admin':
      next.view = 'admin';
      if (action.page) next.adminPage = action.page;
      return next;
    case 'nav.settings':
      next.view = 'settings';
      return next;
    case 'nav.list':
      next.view = 'list';
      return next;
    case 'nav.step':
      next.step = clamp(Math.round(num(action.step)) || 1, 1, 4);
      next.view = 'editor';
      return next;
    case 'budget.new': {
      const id = newId();
      const doc = makeDoc(blankBudget());
      // Assigned at creation and persisted immediately — the field is read-only,
      // so there is no moment where a budget exists without an ID.
      doc.budget.project.pid = nextProjectId(next.budgets);
      next.budgets[id] = doc;
      next.activeId = id;
      next.view = 'editor';
      next.step = 1;
      return next;
    }
    case 'budget.open':
      if (!next.budgets[action.id]) return state;
      next.activeId = action.id;
      next.view = 'editor';
      next.step = 1;
      return next;
    case 'budget.edit': {
      // Edits a budget by id (the list shows every budget, not just the active
      // one), so this cannot go through the active-document switch below.
      const target = next.budgets[action.id];
      if (!target) return state;
      if (action.field === 'rev') target.budget.assumptions.rev = num(action.value);
      else target.budget.project[action.field] = action.value;
      target.updatedAt = new Date().toISOString();
      // Revenue moves margin, so the same signature rule as the editor applies:
      // an edit that changes cost/margin resets the sign-off chain (BRD §8).
      guardSignature(target);
      return next;
    }
    case 'budget.del': {
      delete next.budgets[action.id];
      if (next.activeId === action.id) {
        next.activeId = Object.keys(next.budgets)[0] ?? null;
        next.view = 'list';
      }
      return next;
    }
    default:
      break;
  }

  /* ----- everything below operates on the active budget document ----- */
  const doc = next.activeId ? next.budgets[next.activeId] : null;
  if (!doc) return state;
  const b = doc.budget;
  const months = b.assumptions.months;
  doc.updatedAt = new Date().toISOString();

  switch (action.type) {
    case 'budget.save':
      // Working copy persists automatically; this stamps updatedAt and lets
      // the App layer sync project metadata to PostgreSQL.
      return next;

    case 'project':
      // The Project ID is the key budgets are stored and synced under, so it is
      // restricted to characters that are safe in a URL path and a database
      // key: letters, digits, hyphen, underscore. Anything else — spaces
      // included — is stripped as it is typed rather than rejected, so pasting
      // "PRJ 2026/014" yields "PRJ2026014" instead of an error.
      b.project[action.field] = action.field === 'pid' ? sanitisePid(action.value) : action.value;
      break;

    case 'assumption':
      b.assumptions[action.field] = num(action.value);
      break;

    case 'months':
      resizeToMonths(b, action.value);
      break;

    case 'phase.upd': {
      const p = b.phases[action.i];
      if (!p) break;
      if (action.field === 'n') p.n = String(action.value);
      else p[action.field] = clamp(Math.round(num(action.value)) || 1, 1, months);
      break;
    }
    case 'phase.add': {
      const last = b.phases.length ? b.phases[b.phases.length - 1].e : 0;
      const s = clamp(last + 1, 1, months);
      b.phases.push({ n: 'New Phase', s, e: s });
      break;
    }
    case 'phase.del':
      b.phases.splice(action.i, 1);
      break;

    case 'role.upd': {
      const r = b.roster[action.i];
      if (!r) break;
      if (action.field === 'cpm') r.cpm = num(action.value);
      else if (action.field === 'start') r.start = clamp(Math.round(num(action.value)) || 1, 1, months);
      else if (action.field === 'dur') r.dur = clamp(Math.round(num(action.value)), 0, months);
      else if (action.field === 'loc') r.loc = action.value as Location;
      else r[action.field] = String(action.value);
      break;
    }
    case 'role.pick': {
      const r = b.roster[action.i];
      if (!r) break;
      r.roleId = action.roleId; // the id is what persists to the database
      r.role = action.name; // denormalised display label
      break;
    }
    case 'role.add':
      b.roster.push({
        team: '',
        role: 'New role',
        loc: 'Offshore',
        cpm: 0,
        start: 1,
        dur: months,
        alloc: Array(months).fill(0),
      });
      break;
    case 'role.del':
      b.roster.splice(action.i, 1);
      break;

    case 'alloc.fill': {
      // Copy the first in-window month across the rest of the window; months
      // outside the role's start/duration are left untouched.
      const r = b.roster[action.i];
      if (!r) break;
      const from = clamp(Math.round(num(r.start)) || 1, 1, months);
      const to = clamp(from + (Math.round(num(r.dur)) || 0) - 1, 1, months);
      const seed = num(r.alloc[from - 1]);
      for (let j = from - 1; j <= to - 1; j++) r.alloc[j] = seed;
      break;
    }

    case 'alloc.spread': {
      // Distribute a total evenly across the window, rounding to the grid's
      // 0.25 step and putting any remainder in the first month so the row's
      // total matches exactly what was asked for.
      const r = b.roster[action.i];
      if (!r) break;
      const from = clamp(Math.round(num(r.start)) || 1, 1, months);
      const span = clamp(Math.round(num(r.dur)) || 0, 0, months - from + 1);
      if (span <= 0) break;
      const total = Math.max(0, num(action.total));
      const per = Math.round((total / span) * 4) / 4;
      for (let j = from - 1; j <= from + span - 2; j++) r.alloc[j] = per;
      const drift = Math.round((total - per * span) * 100) / 100;
      if (drift) r.alloc[from - 1] = Math.max(0, Math.round((per + drift) * 100) / 100);
      break;
    }

    case 'alloc': {
      const r = b.roster[action.i];
      if (r) r.alloc[action.j] = num(action.value);
      break;
    }

    case 'submit':
      doc.submitted = true;
      // Recorded, not yet read by anything that decides access.
      if (action.by) doc.submittedBy = action.by;
      return next;
    case 'approve':
      if (!doc.submitted) return state; // approvals only start after submission
      doc.approvals[action.role] = true;
      recordDecision(doc, action.role, 'approve', next.user, action.note);
      return next; // sign-off does not change the signature
    case 'revoke':
      doc.approvals = revoke(action.role, doc.approvals);
      recordDecision(doc, action.role, 'revoke', next.user, action.note);
      return next;

    case 'version.save': {
      const id = doc.versions.length ? Math.max(...doc.versions.map((v) => v.id)) + 1 : 1;
      doc.versions.push({
        id,
        label: action.label.trim() || `Revision ${id}`,
        ts: new Date().toISOString().slice(0, 10),
        state: structuredClone(b),
      });
      return next;
    }
    case 'version.del':
      doc.versions = doc.versions.filter((v) => v.id !== action.id);
      return next;
    case 'version.restore': {
      const v = doc.versions.find((x) => x.id === action.id);
      if (v) {
        doc.budget = structuredClone(v.state);
        ensureWindows(doc.budget.roster, doc.budget.assumptions.months);
      }
      break;
    }
    case 'versions.resetSeed': {
      next.budgets[next.activeId!] = seedDoc();
      return next;
    }

    case 'import': {
      const env = action.envelope;
      const months2 =
        env.assumptions?.months ?? (env.roster?.[0]?.alloc ? env.roster[0].alloc.length : 12);
      doc.budget = {
        project: {
          pid: env.project?.pid ?? '',
          name: env.project?.name ?? '',
          start: env.project?.start ?? '',
          goLive: env.project?.goLive ?? undefined,
        },
        assumptions: {
          rev: num(env.assumptions?.rev),
          uplift: num(env.assumptions?.uplift),
          eff: num(env.assumptions?.eff),
          exp: num(env.assumptions?.exp),
          travel: num(env.assumptions?.travel),
          months: clamp(Math.round(num(months2)) || 12, 1, 36),
        },
        phases: Array.isArray(env.phases) ? structuredClone(env.phases) : [],
        roster: Array.isArray(env.roster) ? structuredClone(env.roster) : [],
      };
      resizeToMonths(doc.budget, doc.budget.assumptions.months);
      ensureWindows(doc.budget.roster, doc.budget.assumptions.months);
      if (Array.isArray(env.versions)) {
        // Prototype exports store version state flat; normalise to BudgetState
        doc.versions = env.versions.map((v: any) => ({
          id: v.id,
          label: v.label ?? '',
          ts: v.ts ?? '',
          state: v.state?.assumptions
            ? v.state
            : {
                project: doc.budget.project,
                assumptions: {
                  rev: num(v.state?.rev), uplift: num(v.state?.uplift), eff: num(v.state?.eff),
                  exp: num(v.state?.exp), travel: num(v.state?.travel),
                  months: clamp(Math.round(num(v.state?.months)) || 12, 1, 36),
                },
                phases: v.state?.phases ?? [],
                roster: v.state?.roster ?? [],
              },
        }));
      }
      break;
    }

    case 'reset':
      next.budgets[next.activeId!] = seedDoc();
      return next;
  }

  guardSignature(doc);
  return next;
}
