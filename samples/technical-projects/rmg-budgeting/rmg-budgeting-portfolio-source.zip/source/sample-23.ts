// Shell
export { Shell } from "./Shell";
export type { ShellProps } from "./Shell";
export { ShellHeader, initials } from "./ShellHeader";
export type { ShellHeaderProps, AccountMenuItem } from "./ShellHeader";
export { ShellSidebar } from "./ShellSidebar";
export type { ShellSidebarProps, NavItem } from "./ShellSidebar";
export { PageTitleBar } from "./PageTitleBar";
export type { PageTitleBarProps } from "./PageTitleBar";

// Design system (re-exported so consumers need only one import path)
export * from "./ds";
