from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from typing import Protocol
from typing import Any

from .exceptions import ExternalServiceError


class JsonChatClient(Protocol):
    provider: str
    model: str

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        ...

    def health(self) -> bool:
        ...


class GLMClient:
    provider = "glm"

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: int = 180,
    ):
        self.model = model or os.getenv("GLM_MODEL", "glm-5.1")
        self.api_key = api_key if api_key is not None else os.getenv("GLM_API_KEY") or os.getenv("ZAI_API_KEY")
        self.base_url = (base_url or os.getenv("GLM_BASE_URL", "https://example.invalid")).rstrip("/")
        self.timeout = timeout

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        if not self.api_key:
            raise ExternalServiceError("GLM_API_KEY is not set.")

        payload = {
            "model": self.model,
            "stream": False,
            "temperature": 0.2,
            "max_tokens": 4096,
            "thinking": {"type": "disabled"},
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        try:
            req = urllib.request.Request(
                f"{self.base_url}/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "Accept-Language": "en-US,en",
                    "Authorization": f"Bearer {self.api_key}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ExternalServiceError(f"GLM request failed for model {self.model}: {exc}") from exc

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ExternalServiceError("GLM returned an unexpected response shape.") from exc
        return parse_json_response(content, provider="GLM")

    def health(self) -> bool:
        return bool(self.api_key)


class NvidiaMistralClient:
    provider = "mistral"

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: int = 180,
    ):
        self.model = model or os.getenv("MISTRAL_MODEL", "meta/llama-3.3-70b-instruct")
        self.api_key = REDACTED_SECRET
            api_key
            if api_key is not None
            else os.getenv("NVIDIA_API_KEY")
            or os.getenv("MISTRAL_API_KEY")
            or os.getenv("MISTRAL_NVIDIA_API_KEY")
        )
        self.base_url = (base_url or os.getenv("NVIDIA_BASE_URL", "https://example.invalid")).rstrip("/")
        self.timeout = timeout

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        if not self.api_key:
            raise ExternalServiceError("NVIDIA_API_KEY or MISTRAL_API_KEY is not set.")

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "max_tokens": 4096,
            "temperature": 0.15,
            "top_p": 1.0,
            "frequency_penalty": 0.0,
            "presence_penalty": 0.0,
            "stream": False,
        }
        try:
            req = urllib.request.Request(
                f"{self.base_url}/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "Authorization": f"Bearer {self.api_key}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ExternalServiceError(f"NVIDIA Mistral request failed for model {self.model}: {exc}") from exc

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ExternalServiceError("NVIDIA Mistral returned an unexpected response shape.") from exc
        return parse_json_response(content, provider="NVIDIA Mistral")

    def health(self) -> bool:
        return bool(self.api_key)


class GroqClient:
    provider = "groq"

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: int = 180,
    ):
        self.model = model or os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
        self.api_key = api_key if api_key is not None else os.getenv("GROQ_API_KEY")
        self.base_url = (base_url or os.getenv("GROQ_BASE_URL", "https://example.invalid")).rstrip("/")
        self.timeout = timeout

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        if not self.api_key:
            raise ExternalServiceError("GROQ_API_KEY is not set.")

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.15,
            "response_format": {"type": "json_object"},
            "stream": False,
        }
        try:
            req = urllib.request.Request(
                f"{self.base_url}/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "Authorization": f"Bearer {self.api_key}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ExternalServiceError(f"Groq request failed for model {self.model}: {exc}") from exc

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ExternalServiceError("Groq returned an unexpected response shape.") from exc
        return parse_json_response(content, provider="Groq")

    def health(self) -> bool:
        return bool(self.api_key)


class OllamaClient:
    provider = "ollama"

    def __init__(self, model: str | None = None, base_url: str | None = None, timeout: int = 180):
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen3:8b")
        self.base_url = (base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")).rstrip("/")
        self.timeout = timeout

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "stream": False,
            "format": "json",
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "options": {"temperature": 0.1},
        }
        try:
            req = urllib.request.Request(
                f"{self.base_url}/api/chat",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ExternalServiceError(f"Ollama request failed for model {self.model}: {exc}") from exc

        content = (data.get("message") or {}).get("content") or "{}"
        return parse_json_response(content, provider="Ollama")

    def health(self) -> bool:
        try:
            with urllib.request.urlopen(f"{self.base_url}/api/tags", timeout=5) as response:
                json.loads(response.read().decode("utf-8"))
            return True
        except Exception:
            return False


def build_chat_client(
    *,
    provider: str = "glm",
    glm_api_key: str | None = None,
    glm_model: str = "glm-5.1",
    glm_base_url: str | None = None,
    mistral_api_key: str | None = None,
    mistral_model: str = "meta/llama-3.3-70b-instruct",
    mistral_base_url: str | None = None,
    groq_api_key: str | None = None,
    groq_model: str = "llama-3.1-8b-instant",
    groq_base_url: str | None = None,
    ollama_model: str = "qwen3:8b",
) -> JsonChatClient:
    if provider == "ollama":
        return OllamaClient(model=ollama_model)
    if provider == "mistral":
        return NvidiaMistralClient(model=mistral_model, api_key=mistral_api_key, base_url=mistral_base_url)
    if provider == "groq":
        return GroqClient(model=groq_model, api_key=groq_api_key, base_url=groq_base_url)
    if provider == "glm":
        return GLMClient(model=glm_model, api_key=glm_api_key, base_url=glm_base_url)
    raise ValueError(f"Unsupported LLM provider: {provider}")


def parse_json_response(content: str, *, provider: str) -> dict[str, Any]:
    text = (content or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
    raise ExternalServiceError(f"{provider} returned non-JSON content.")
