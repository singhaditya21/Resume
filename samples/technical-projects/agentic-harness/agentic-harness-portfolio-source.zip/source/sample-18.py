import urllib.request, json

API_KEY = REDACTED_SECRET
BASE = "http://localhost:5678/api/v1"

# Get latest execution
req = urllib.request.Request(
    f"{BASE}/executions?limit=1",
    headers={"X-N8N-API-KEY": API_KEY, "Accept": "application/json"}
)

r = urllib.request.urlopen(req, timeout=30)
data = json.loads(r.read().decode())
execs = data.get("data", [])
if not execs:
    print("No executions found")
    exit()

exec_id = execs[0]["id"]
print(f"Latest execution: {exec_id} status={execs[0]['status']}")

# Get full execution data
req2 = urllib.request.Request(
    f"{BASE}/executions/{exec_id}?includeData=true",
    headers={"X-N8N-API-KEY": API_KEY, "Accept": "application/json"}
)
r2 = urllib.request.urlopen(req2, timeout=30)
data2 = json.loads(r2.read().decode())

# Drill into resultData
rd = data2.get("data", {})
result_data = rd.get("resultData", {})
run_data = result_data.get("runData", {})

if not run_data:
    print("No runData! Keys in data:", list(rd.keys()))
    print("Full response keys:", list(data2.keys()))
    # Try alternate structure
    if "data" in data2:
        print("data.data keys:", list(data2["data"].keys()) if isinstance(data2["data"], dict) else type(data2["data"]))
else:
    for node_name, runs in run_data.items():
        print(f"\n=== {node_name} ===")
        for run in runs:
            if run.get("error"):
                print(f"  ERROR: {json.dumps(run['error'], indent=2, default=str)[:1000]}")
            output = run.get("data", {})
            if output:
                main = output.get("main", [[]])
                for items in main:
                    for item in (items or []):
                        j = item.get("json", {})
                        # Truncate large fields
                        for k in list(j.keys()):
                            if isinstance(j[k], (list, str)) and len(str(j[k])) > 300:
                                j[k] = str(j[k])[:300] + "..."
                        print(json.dumps(j, indent=2, default=str)[:2000])
            else:
                print("  (no output data)")