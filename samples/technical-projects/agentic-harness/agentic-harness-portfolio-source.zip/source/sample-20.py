"""Deal Intelligence Pipeline — Code-based Embedding & Milvus (10 nodes + 1 sub-node)

All external API calls use Code nodes with this.helpers.httpRequest() to avoid
HTTP Request node credential/auth issues.

Flow: Transcript → Archive → Embed (Code→NVIDIA NIM) → Milvus (Code) → AI Agent → 9 Metrics
"""
import json
import urllib.request

BASE = "http://localhost:5678/api/v1"
API_KEY = REDACTED_SECRET
NVIDIA_CHAT_KEY = "REDACTED_SECRET"
NVIDIA_EMBED_KEY = "REDACTED_SECRET"

def api(method, path, data=None):
    url = f"{BASE}/{path}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, method=method,
        headers={"Content-Type": "application/json", "Accept": "application/json", "X-N8N-API-KEY": API_KEY})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read().decode()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.read().decode()[:500]}")
        return None

# ── Step 1: Create credentials ──
print("Step 1: Creating NVIDIA NIM API credential...")
cred_result = api("POST", "credentials", {
    "name": "NVIDIA NIM API",
    "type": "openAiApi",
    "data": {
        "apiKey": NVIDIA_CHAT_KEY,
        "headerName": "Authorization",
        "headerValue": f"Bearer {NVIDIA_CHAT_KEY}"
    }
})
cred_id = None
if cred_result and cred_result.get("id"):
    cred_id = cred_result["id"]
    print(f"  Created credential (id: {cred_id})")
else:
    creds = api("GET", "credentials")
    if creds and creds.get("data"):
        for c in creds["data"]:
            if "nvidia" in c.get("name", "").lower() or "nim" in c.get("name", "").lower():
                cred_id = c["id"]
                print(f"  Found existing: {c['name']} (id: {cred_id})")
                break
    if not cred_id:
        print("  WARNING: No credential available.")

# ── Step 2: Clean up old workflows ──
print("\nStep 2: Cleaning up old workflows...")
existing = api("GET", "workflows")
if existing and existing.get("data"):
    for wf in existing["data"]:
        print(f"  Deleting: {wf['name']} ({wf['id']})")
        api("DELETE", f"workflows/{wf['id']}")

# ── Sample transcript ──
SAMPLE_TRANSCRIPT = """SALES CALL TRANSCRIPT - Life Insurance Policy
Date: 2026-05-10 | Agent: Rajesh Kumar | Prospect: Priya Sharma | Duration: 12 min

[00:00] Rajesh: Good morning Priya! Thank you for taking the time to speak with me today. I'm Rajesh from SecureLife Insurance. How are you doing today?

[00:15] Priya: Good morning Rajesh. I'm doing well, thank you. I saw your advertisement about life insurance plans and was curious to learn more.

[00:25] Rajesh: That's wonderful! I'd be happy to walk you through our plans. Before we begin, may I ask what prompted your interest in life insurance?

[00:38] Priya: Well, I recently got married and my husband and I are planning to start a family. I want to make sure we have financial security in place.

[00:55] Rajesh: That's very thoughtful. Family security is one of the most important reasons to get life insurance. Our Term Life Insurance Premium Plan offers coverage up to 1 crore rupees with a monthly premium starting at just 1,500 rupees.

[01:20] Priya: That sounds reasonable. But does the premium increase over time?

[01:28] Rajesh: Great question! With our Premium Plan, the premium is locked in for the entire term - 20, 25, or 30 years.

[01:45] Priya: What about the claim process? I've heard insurance companies can be difficult with claims.

[01:55] Rajesh: At SecureLife, we have a claim settlement ratio of 98.5%. Most claims are processed within 7 working days.

[02:20] Priya: That's impressive. What about additional benefits and riders?

[02:28] Rajesh: Our Premium Plan includes an accidental death benefit rider at no extra cost. You can also add a critical illness rider for 400 rupees per month.

[03:30] Priya: We have a budget concern - we're also saving for a home loan down payment. Can we start with lower coverage?

[03:50] Rajesh: Yes! We have a step-up option - start with 25 lakh and increase as your income grows.

[04:10] Priya: Can you send me a detailed brochure?

[04:20] Rajesh: Absolutely! I'll email you the brochure and a personalized quote within the hour.

[04:48] Rajesh: We have a special offer - enroll within 15 days and get the first month's premium waived. Shall I schedule a follow-up next week?

[05:10] Priya: Yes, next Wednesday at 11 AM?

[05:15] Rajesh: Perfect! Next Wednesday at 11 AM. Thank you, Priya!"""

# ══════════════════════════════════════════════════════════════════════
# NODE DEFINITIONS
# ══════════════════════════════════════════════════════════════════════
print("\nStep 3: Building pipeline nodes...")

# ── Node 1: Webhook Trigger (callable from dashboard) ──
node_manual = {
    "parameters": {
        "httpMethod": "POST",
        "path": "deal-intelligence",
        "responseMode": "lastNode",
        "options": {}
    },
    "id": "c300-0001", "name": "1. Webhook Trigger",
    "type": "n8n-nodes-base.webhook", "typeVersion": 2,
    "position": [200, 400],
    "webhookId": "deal-intelligence-webhook",
    "notes": "POST webhook — returns last node output as response"
}

# ── Node 2: Set Transcript Input (reads from webhook body) ──
node_transcript = {
    "parameters": {
        "mode": "raw",
        "jsonOutput": "={{ JSON.stringify($json.body) }}"
    },
    "id": "c300-0002", "name": "2. Set Transcript Input",
    "type": "n8n-nodes-base.set", "typeVersion": 3.4,
    "position": [420, 400],
    "notes": "RAW TRANSCRIPT ONLY — edit this node to paste your sales call transcript"
}

# ── Node 3: Archive Transcript (passthrough) ──
node_archive = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": "const d = items[0].json;\nd.archived_at = new Date().toISOString();\nreturn [{ json: d }];"
    },
    "id": "c300-0003", "name": "3. Archive Transcript",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [640, 400],
    "notes": "Archive transcript with timestamp"
}

# ── Node 4: Generate Embedding (Code node calls NVIDIA NIM API directly) ──
node_embed = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const raw = $node['2. Set Transcript Input'].json.transcript;\n"
            "const dealId = $node['2. Set Transcript Input'].json.deal_id || 'DEAL-UNKNOWN';\n"
            "const apiKey = 'REDACTED_SECRET';\n"
            "\n"
            "// Normalize transcript to flat string (handles string, array, or object)\n"
            "let transcript;\n"
            "if (typeof raw === 'string') {\n"
            "  transcript = raw;\n"
            "} else if (Array.isArray(raw)) {\n"
            "  transcript = raw.map(e => typeof e === 'string' ? e : `[${e.timestamp||''}] ${e.speaker||''}: ${e.text||JSON.stringify(e)}`).join('\\n');\n"
            "} else {\n"
            "  transcript = JSON.stringify(raw);\n"
            "}\n"
            "\n"
            "const response = await this.helpers.httpRequest({\n"
            "  method: 'POST',\n"
            "  url: 'https://example.invalid',\n"
            "  headers: {\n"
            "    'Content-Type': 'application/json',\n"
            "    'Authorization': `Bearer ${apiKey}`,\n"
            "    'Accept': 'application/json'\n"
            "  },\n"
            "  body: {\n"
            "    model: 'REDACTED_OPAQUE_VALUE',\n"
            "    input: [transcript.substring(0, 8000)],\n"
            "    input_type: 'query',\n"
            "    encoding_format: 'float'\n"
            "  },\n"
            "  json: true,\n"
            "  timeout: 30000\n"
            "});\n"
            "\n"
            "const embedding = response.data?.[0]?.embedding ?? [];\n"
            "return [{\n"
            "  json: {\n"
            "    deal_id: dealId,\n"
            "    embedding: embedding,\n"
            "    embedding_model: 'REDACTED_OPAQUE_VALUE',\n"
            "    embedding_dim: embedding.length,\n"
            "    transcript_text: transcript,\n"
            "    transcript_preview: transcript.substring(0, 500),\n"
            "    generated_at: new Date().toISOString()\n"
            "  }\n"
            "}];"
        )
    },
    "id": "c300-0004", "name": "4. Generate Embedding",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [860, 400],
    "notes": "NVIDIA NIM Embedding API — Code node calls nvidia/llama-nemotron-embed-1b-v2 directly"
}

# ── Node 5: Create Milvus Collection + Store Embedding (Code) ──
node_milvus_store = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const embedData = $node['4. Generate Embedding'].json;\n"
            "const vector = embedData.embedding || [];\n"
            "const dealId = embedData.deal_id;\n"
            "const preview = embedData.transcript_preview || '';\n"
            "const milvusUrl = 'https://example.invalid';\n"
            "\n"
            "// Step 1: Create collection if not exists\n"
            "try {\n"
            "  await this.helpers.httpRequest({\n"
            "    method: 'POST',\n"
            "    url: `${milvusUrl}/v2/vectordb/collections/create`,\n"
            "    headers: { 'Content-Type': 'application/json' },\n"
            "    body: {\n"
            "      collectionName: 'deal_intelligence',\n"
            "      dimension: vector.length || 1024,\n"
            "      metricType: 'COSINE'\n"
            "    },\n"
            "    json: true,\n"
            "    timeout: 10000\n"
            "  });\n"
            "} catch(e) { /* collection may already exist */ }\n"
            "\n"
            "// Step 2: Insert embedding (id must be Int64)\n"
            "const numericId = Date.now();\n"
            "let insertResult = { code: 0 };\n"
            "try {\n"
            "  insertResult = await this.helpers.httpRequest({\n"
            "    method: 'POST',\n"
            "    url: `${milvusUrl}/v2/vectordb/entities/insert`,\n"
            "    headers: { 'Content-Type': 'application/json' },\n"
            "    body: {\n"
            "      collectionName: 'deal_intelligence',\n"
            "      data: [{\n"
            "        id: numericId,\n"
            "        vector: vector,\n"
            "        deal_id: dealId,\n"
            "        transcript_preview: preview,\n"
            "        stored_at: new Date().toISOString()\n"
            "      }]\n"
            "    },\n"
            "    json: true,\n"
            "    timeout: 15000\n"
            "  });\n"
            "} catch(e) {\n"
            "  insertResult = { code: 1, error: e.message };\n"
            "}\n"
            "\n"
            "return [{\n"
            "  json: {\n"
            "    deal_id: dealId,\n"
            "    milvus_id: numericId,\n"
            "    vector_stored: vector.length > 0,\n"
            "    vector_dim: vector.length,\n"
            "    insert_result: insertResult,\n"
            "    stored_at: new Date().toISOString()\n"
            "  }\n"
            "}];"
        )
    },
    "id": "c300-0005", "name": "5. Store in Milvus",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [1080, 400],
    "notes": "Auto-create Milvus collection + store embedding vector"
}

# ── Node 6: Search Milvus for context (Code) ──
node_milvus_search = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const embedData = $node['4. Generate Embedding'].json;\n"
            "const vector = embedData.embedding || [];\n"
            "const milvusUrl = 'https://example.invalid';\n"
            "\n"
            "let searchResults = [];\n"
            "try {\n"
            "  if (vector.length > 0) {\n"
            "    const resp = await this.helpers.httpRequest({\n"
            "      method: 'POST',\n"
            "      url: `${milvusUrl}/v2/vectordb/entities/search`,\n"
            "      headers: { 'Content-Type': 'application/json' },\n"
            "      body: {\n"
            "        collectionName: 'deal_intelligence',\n"
            "        data: [vector],\n"
            "        limit: 5,\n"
            "        outputFields: ['id', 'transcript_preview']\n"
            "      },\n"
            "      json: true,\n"
            "      timeout: 15000\n"
            "    });\n"
            "    searchResults = resp.data || [];\n"
            "  }\n"
            "} catch(e) {\n"
            "  searchResults = [];\n"
            "}\n"
            "\n"
            "return [{\n"
            "  json: {\n"
            "    similar_deals: searchResults,\n"
            "    similar_deals_count: searchResults.length,\n"
            "    context_retrieved_at: new Date().toISOString()\n"
            "  }\n"
            "}];"
        )
    },
    "id": "c300-0006", "name": "6. Search Milvus Context",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [1300, 400],
    "notes": "Vector similarity search in Milvus for matching past deals"
}

# ── Node 7: AI Analysis (Code node calls NVIDIA NIM directly) ──
SYSTEM_PROMPT = (
    "You are an expert sales conversation intelligence analyst. You analyze sales call transcripts "
    "to extract actionable deal intelligence. You ALWAYS respond with strict JSON — never markdown, "
    "never explanatory text. Your analysis must be evidence-based, referencing specific moments in the transcript."
)

USER_PROMPT_PREFIX = (
    "Analyze this sales call transcript and produce a comprehensive deal intelligence report.\\n\\n"
    "=== TRANSCRIPT ===\\n"
)

USER_PROMPT_SUFFIX = (
    "\\n=== END TRANSCRIPT ===\\n\\n"
    "Produce your analysis as STRICT JSON with these exact top-level key/opt/portfolio/project"
    "1. 'conversation_intelligence': object with keys: key_topics (array of strings), talk_ratio (object: {agent: number, prospect: number}), engagement_score (0-100), questions_asked (number), key_moments (array of strings)\\n\\n"
    "2. 'risks': array of objects, each with: category (string), severity (critical/high/medium/low), summary (string), evidence (exact quote from transcript)\\n\\n"
    "3. 'objections': array of objects, each with: type (string), severity (critical/high/medium/low), summary (string), evidence (exact quote from transcript)\\n\\n"
    "4. 'sales_performance': object with keys: overall_score (0-100), strengths (array of strings), weaknesses (array of strings), technique_rating (0-100), closing_effectiveness (0-100)\\n\\n"
    "5. 'sentiment_analysis': object with keys: prospect (object: {sentiment, confidence 0-100, trend}), agent (object: {sentiment, confidence 0-100, trend})\\n\\n"
    "6. 'deal_score': number 0-100 representing probability of closing\\n\\n"
    "7. 'recommendations': object with keys: next_best_action (string), priority (critical/high/medium/low), timeline (string), reasoning (string), coaching_tips (array of strings)\\n\\n"
    "8. 'refined_pitch': string — a refined sales pitch tailored to this prospect\\n\\n"
    "9. 'follow_up': object with keys: subject (string), body (string), timing (string), channel (string)\\n\\n"
    "Return ONLY valid JSON, no markdown, no explanation outside the JSON."
)

node_ai_agent = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const transcript = $node['4. Generate Embedding'].json.transcript_text || '';\n"
            "const similarDeals = JSON.stringify($json.similar_deals ?? []);\n"
            "const apiKey = '" + NVIDIA_CHAT_KEY + "';\n"
            "const model = 'meta/llama-3.3-70b-instruct';\n"
            "\n"
            "const sysPrompt = " + json.dumps(SYSTEM_PROMPT) + ";\n"
            "const userPrompt = "PORTFOLIO_REDACTED" + transcript.substring(0, 6000) + " + json.dumps(USER_PROMPT_SUFFIX) + ";\n"
            "\n"
            "let content = '';\n"
            "let errorMsg = '';\n"
            "let rawResponse = {};\n"
            "try {\n"
            "  rawResponse = await this.helpers.httpRequest({\n"
            "    method: 'POST',\n"
            "    url: 'https://example.invalid',\n"
            "    headers: {\n"
            "      'Content-Type': 'application/json',\n"
            "      'Authorization': `Bearer ${apiKey}`,\n"
            "      'Accept': 'application/json'\n"
            "    },\n"
            "    body: {\n"
            "      model: model,\n"
            "      messages: [\n"
            "        { role: 'system', content: sysPrompt },\n"
            "        { role: 'user', content: userPrompt }\n"
            "      ],\n"
            "      max_tokens: 4096,\n"
            "      temperature: 0.2,\n"
            "      stream: false\n"
            "    },\n"
            "    json: true,\n"
            "    timeout: 120000\n"
            "  });\n"
            "  content = rawResponse.choices?.[0]?.message?.content ?? '';\n"
            "} catch(e) {\n"
            "  errorMsg = e.message;\n"
            "  content = JSON.stringify({error: errorMsg, details: String(e).substring(0, 500)});\n"
            "}\n"
            "return [{ json: { output: content, model: model, error: errorMsg, prompt_len: userPrompt.length, generated_at: new Date().toISOString() } }];"
        )
    },
    "id": "c300-0007", "name": "7. AI Analysis",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [1520, 400],
    "notes": "Code node calls NVIDIA NIM API directly — no AI Agent node issues"
}

# No separate chat model sub-node needed
node_chat_model = None

# ── Node 8: Score & Classify ──
node_scoring = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const raw = items[0].json ?? {};\n"
            "let analysis = {};\n"
            "try {\n"
            "  const text = raw.output ?? raw.text ?? JSON.stringify(raw);\n"
            "  const clean = (typeof text === 'string') ? text.replace(/^```(?:json)?\\n?/g,'').replace(/```\\s*$/,'').replace(/^```(?:json)?\\n?/gm,'').trim() : JSON.stringify(text);\n"
            "  analysis = JSON.parse(clean);\n"
            "} catch(e) {\n"
            "  analysis = { error: 'Parse failed', raw: String(raw.output ?? '').substring(0, 500) };\n"
            "}\n"
            "\n"
            "const dealScore = analysis.deal_score ?? 50;\n"
            "const riskCount = (analysis.risks ?? []).length;\n"
            "const objCount = (analysis.objections ?? []).length;\n"
            "const highRisks = (analysis.risks ?? []).filter(r => r.severity === 'high' || r.severity === 'critical').length;\n"
            "\n"
            "const severity = dealScore < 35 ? 'critical' : dealScore < 55 ? 'high' : dealScore < 70 ? 'medium' : 'low';\n"
            "const health = dealScore >= 70 ? 'healthy' : dealScore >= 45 ? 'at_risk' : 'critical';\n"
            "\n"
            "return [{ json: {\n"
            "  deal_id: $node['2. Set Transcript Input'].json.deal_id,\n"
            "  analysis,\n"
            "  classification: {\n"
            "    deal_score: dealScore,\n"
            "    severity,\n"
            "    deal_health: health,\n"
            "    risk_count: riskCount,\n"
            "    objection_count: objCount,\n"
            "    high_risk_count: highRisks,\n"
            "  },\n"
            "  pipeline_stage: 'scored',\n"
            "} }];"
        )
    },
    "id": "c300-0008", "name": "8. Score & Classify",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [1780, 400],
    "notes": "Parse AI JSON output, classify deal health and severity"
}

# ── Node 9: Archive Results (passthrough) ──
node_archive_results = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": "const d = items[0].json;\nd.results_archived_at = new Date().toISOString();\nreturn [{ json: d }];"
    },
    "id": "c300-0009", "name": "9. Archive Results",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [2040, 400],
    "notes": "Archive results data with timestamp"
}

# ── Node 10: Dashboard Output ──
node_dashboard = {
    "parameters": {
        "mode": "runOnceForAllItems",
        "jsCode": (
            "const d = items[0].json;\n"
            "const a = d.analysis ?? {};\n"
            "const c = d.classification ?? {};\n"
            "\n"
            "return [{ json: {\n"
            "  deal_id: d.deal_id,\n"
            "  deal_score: c.deal_score,\n"
            "  deal_health: c.deal_health,\n"
            "  severity: c.severity,\n"
            "  conversation_intelligence: a.conversation_intelligence ?? {},\n"
            "  risks: a.risks ?? [],\n"
            "  objections: a.objections ?? [],\n"
            "  sales_performance: a.sales_performance ?? {},\n"
            "  sentiment_analysis: a.sentiment_analysis ?? {},\n"
            "  recommendations: a.recommendations ?? {},\n"
            "  refined_pitch: a.refined_pitch ?? '',\n"
            "  follow_up: a.follow_up ?? {},\n"
            "  risk_count: c.risk_count,\n"
            "  objection_count: c.objection_count,\n"
            "  pipeline_stage: 'COMPLETE',\n"
            "  timestamp: new Date().toISOString(),\n"
            "} }];"
        )
    },
    "id": "c300-0010", "name": "10. Dashboard Output",
    "type": "n8n-nodes-base.code", "typeVersion": 2,
    "position": [2300, 400],
    "notes": "Final structured output — 9 deal intelligence metrics"
}

# ══════════════════════════════════════════════════════════════════════
# CONNECTIONS
# ══════════════════════════════════════════════════════════════════════
connections = {
    "1. Webhook Trigger": {
        "main": [[{"node": "2. Set Transcript Input", "type": "main", "index": 0}]]
    },
    "2. Set Transcript Input": {
        "main": [[{"node": "3. Archive Transcript", "type": "main", "index": 0}]]
    },
    "3. Archive Transcript": {
        "main": [[{"node": "4. Generate Embedding", "type": "main", "index": 0}]]
    },
    "4. Generate Embedding": {
        "main": [[{"node": "5. Store in Milvus", "type": "main", "index": 0}]]
    },
    "5. Store in Milvus": {
        "main": [[{"node": "6. Search Milvus Context", "type": "main", "index": 0}]]
    },
    "6. Search Milvus Context": {
        "main": [[{"node": "7. AI Analysis", "type": "main", "index": 0}]]
    },
    "7. AI Analysis": {
        "main": [[{"node": "8. Score & Classify", "type": "main", "index": 0}]]
    },
    "8. Score & Classify": {
        "main": [[{"node": "9. Archive Results", "type": "main", "index": 0}]]
    },
    "9. Archive Results": {
        "main": [[{"node": "10. Dashboard Output", "type": "main", "index": 0}]]
    },
    "10. Dashboard Output": {}
}

# ══════════════════════════════════════════════════════════════════════
# CREATE WORKFLOW
# ══════════════════════════════════════════════════════════════════════
print("\nStep 4: Creating workflow...")
workflow = {
    "name": "Deal Intelligence Pipeline",
    "nodes": [n for n in [
        node_manual, node_transcript, node_archive,
        node_embed, node_milvus_store, node_milvus_search,
        node_ai_agent, node_chat_model,
        node_scoring, node_archive_results, node_dashboard
    ] if n is not None],
    "connections": connections,
    "settings": {"executionOrder": "v1"},
}

result = api("POST", "workflows", workflow)
if not result:
    print("FAILED to create workflow!")
    exit(1)

wf_id = result["id"]
print(f"  Created: {result['name']} (id: {wf_id})")
print(f"  Nodes ({len(result['nodes'])}):")
for n in result["nodes"]:
    note = f" — {n.get('notes','')}" if n.get('notes') else ""
    print(f"    [{n['name']}] {n['type']}{note}")

print("\n" + "=" * 78)
print("  DEAL INTELLIGENCE PIPELINE — Fixed (10 nodes)")
print("=" * 78)
print("""
  All external API calls use Code nodes (no HTTP Request node issues)

  1. Manual Trigger
  2. Set Transcript Input     ← RAW transcript
  3. Archive Transcript       ← Code passthrough
  4. Generate Embedding       ← Code → NVIDIA NIM API (nvidia/nv-embedqa-e5-v5)
  5. Store in Milvus          ← Code → Milvus REST API (auto-create collection)
  6. Search Milvus Context    ← Code → Milvus vector similarity search
  7. AI Agent                 ← n8n AI Agent + NVIDIA NIM Chat Model
     └── NVIDIA NIM Chat Model (mistral-large-3-675b)
  8. Score & Classify         ← Parse AI JSON, classify deal health
  9. Archive Results          ← Code passthrough
  10. Dashboard Output        ← Final 9-metric JSON

  OUTPUTS: Conversation Intelligence | Risks | Objections |
           Sales Performance | Sentiment Analysis | Deal Score |
           Recommendations | Refined Pitch | Follow-up
""")
print(f"  n8n: http://localhost:5678")
print(f"  MinIO: http://localhost:9001")
print(f"  Milvus: http://localhost:8000")
print("=" * 78)
print("  Ready! Open n8n and click 'Execute Workflow'")