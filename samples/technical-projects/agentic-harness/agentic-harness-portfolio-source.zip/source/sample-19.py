from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dealintel.diarization import assign_speakers, diarize_video
from dealintel.models import make_deal_id, utc_now_iso
from dealintel.parakeet import DEFAULT_PARAKEET_MODEL, transcribe_with_parakeet
from dealintel.scoring import (
    build_recommendations,
    enrich_segment_sentiment,
    extract_objections,
    extract_risks,
    score_deal,
    speaker_metrics,
)
from dealintel.transcript_io import format_transcript_txt, write_transcript_artifacts


ALLOWED_EXTENSIONS = {".mp4", ".mov", ".mkv", ".mp3", ".wav", ".m4a", ".webm"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Process a DealIntel video job inside n8n.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    process = subparsers.add_parser("process", help="Transcribe and diarize a queued video job.")
    process.add_argument("--job-id", required=True)
    process.add_argument("--jobs-root", default=os.getenv("DEALINTEL_JOBS_ROOT", "/files/jobs"))

    args = parser.parse_args(argv)
    if args.command == "process":
        return process_job(job_id=args.job_id, jobs_root=Path(args.jobs_root))
    return 1


def process_job(*, job_id: str, jobs_root: Path) -> int:
    job_dir = jobs_root / _safe_id(job_id)
    job_path = job_dir / "job.json"
    if not job_path.exists():
        _write_failure(job_dir, "job_not_found", f"Job metadata not found: {job_path}")
        return 2

    metadata = json.loads(job_path.read_text(encoding="utf-8"))
    deal_id = _safe_id(str(metadata.get("deal_id") or make_deal_id()))
    try:
        _write_status(job_dir, status="transcribing", deal_id=deal_id, stage="extracting_audio")
        source = _resolve_source(job_dir, metadata)
        audio_path = job_dir / "audio.wav"
        _extract_audio(source, audio_path)

        parakeet_api_key = REDACTED_SECRET
        if not parakeet_api_key:
            raise RuntimeError("PARAKEET_API_KEY is required for NVIDIA Parakeet transcription.")

        parakeet_model = os.getenv("PARAKEET_MODEL", DEFAULT_PARAKEET_MODEL)
        _write_status(job_dir, status="transcribing", deal_id=deal_id, stage="parakeet")
        segments = transcribe_with_parakeet(
            audio_path,
            api_key=REDACTED_SECRET
            model=parakeet_model,
            server=os.getenv("PARAKEET_SERVER"),
            function_id=os.getenv("PARAKEET_FUNCTION_ID"),
            language_code=os.getenv("PARAKEET_LANGUAGE_CODE", "en-US"),
        )
        if not segments:
            raise RuntimeError("Parakeet transcription produced no segments.")

        _write_status(job_dir, status="diarizing", deal_id=deal_id, stage="pyannote")
        hf_token = REDACTED_SECRET
        if not hf_token:
            raise RuntimeError("HF_TOKEN is required because diarization is mandatory for video jobs.")

        min_speakers = _int_env("PYANNOTE_MIN_SPEAKERS")
        max_speakers = _int_env("PYANNOTE_MAX_SPEAKERS")
        turns = diarize_video(
            audio_path,
            hf_token=REDACTED_SECRET
            device=os.getenv("PYANNOTE_DEVICE", "cpu"),
            model_name=os.getenv("PYANNOTE_MODEL", "REDACTED_OPAQUE_VALUE"),
            min_speakers=min_speakers,
            max_speakers=max_speakers,
        )
        if not turns:
            raise RuntimeError("Mandatory diarization completed without speaker turns.")

        segments = assign_speakers(segments, turns)
        segments = enrich_segment_sentiment(segments)
        baseline_analysis = _build_baseline_analysis(segments)
        artifacts = write_transcript_artifacts(
            segments,
            job_dir,
            deal_id=deal_id,
            source={
                "path": str(source),
                "job_id": job_id,
                "source_url": metadata.get("source_url"),
            },
            diarization={
                "status": "completed",
                "reason": None,
                "turn_count": len(turns),
                "model": os.getenv("PYANNOTE_MODEL", "REDACTED_OPAQUE_VALUE"),
                "asr_model": parakeet_model,
            },
        )

        payload = {
            "job_id": job_id,
            "deal_id": deal_id,
            "status": "transcript_ready",
            "generated_at": utc_now_iso(),
            "source_path": str(source),
            "audio_path": str(audio_path),
            "transcript_artifacts": artifacts,
            "diarization": {
                "status": "completed",
                "turn_count": len(turns),
                "speakers": sorted({str(turn["speaker"]) for turn in turns}),
            },
            "asr": {
                "provider": "nvidia",
                "model": parakeet_model,
            },
            "baseline_analysis": baseline_analysis,
            "transcript": {
                "segments": [segment.to_dict() for segment in segments],
            },
            "transcript_text": format_transcript_txt(segments),
        }
        (job_dir / "transcription_result.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        _write_status(
            job_dir,
            status="analyzing",
            deal_id=deal_id,
            stage="deal_intelligence",
            extra={"transcript_path": artifacts["json"]},
        )
        print(json.dumps(payload))
        return 0
    except Exception as exc:
        _write_failure(job_dir, "video_processing_failed", str(exc), deal_id=deal_id)
        return 1


def _resolve_source(job_dir: Path, metadata: dict[str, Any]) -> Path:
    if metadata.get("source_path"):
        source = Path(str(metadata["source_path"]))
        if source.exists():
            return source
        raise FileNotFoundError(f"Source file not found: {source}")

    source_url = str(metadata.get("source_url") or "").strip()
    if not source_url:
        raise ValueError("Video job must include either source_path or source_url.")

    suffix = Path(source_url.split("?", 1)[0]).suffix.lower() or ".mp4"
    if suffix not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported video URL extension: {suffix}")

    target = job_dir / f"source{suffix}"
    req = urllib.request.Request(source_url, headers={"User-Agent": "PORTFOLIO_REDACTED"})
    with urllib.request.urlopen(req, timeout=120) as response:
        with target.open("wb") as handle:
            shutil.copyfileobj(response, handle)
    return target


def _extract_audio(source: Path, audio_path: Path) -> None:
    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(source),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "16000",
        str(audio_path),
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        message = (completed.stderr or completed.stdout or "ffmpeg failed").strip()
        raise RuntimeError(message[-1200:])


def _build_baseline_analysis(segments: list[Any]) -> dict[str, Any]:
    metrics = speaker_metrics(segments)
    objections = extract_objections(segments)
    risks = extract_risks(segments)
    deal_score, dimensions = score_deal(segments)
    recommendations = build_recommendations(deal_score, dimensions, risks, objections)

    agent_metrics = _role_metrics(metrics, "sales_agent")
    prospect_metrics = _role_metrics(metrics, "prospect")
    total_talk = sum(float(item.get("talk_time_seconds", 0.0)) for item in metrics) or 1.0
    agent_talk = round(agent_metrics["talk_time_seconds"] / total_talk * 100, 1) if total_talk else 0.0
    prospect_talk = round(prospect_metrics["talk_time_seconds"] / total_talk * 100, 1) if total_talk else 0.0

    questions = [segment for segment in segments if "?" in segment.text]
    key_topics = _key_topics(segments)
    avg_agent_sentiment = agent_metrics["avg_sentiment_score"]
    avg_prospect_sentiment = prospect_metrics["avg_sentiment_score"]

    return {
        "conversation_intelligence": {
            "key_topics": key_topics,
            "talk_ratio": {"agent": agent_talk, "prospect": prospect_talk},
            "engagement_score": _engagement_score(segments, questions, prospect_talk),
            "questions_asked": len(questions),
            "key_moments": _key_moments(segments),
        },
        "risks": risks,
        "objections": objections,
        "sales_performance": {
            "overall_score": round(min(100.0, max(0.0, deal_score)), 1),
            "strengths": _sales_strengths(segments),
            "weaknesses": _sales_weaknesses(segments, objections, risks),
            "technique_rating": round(min(10.0, max(0.0, deal_score / 10)), 1),
            "closing_effectiveness": _closing_effectiveness(segments),
        },
        "sentiment_analysis": {
            "prospect": _sentiment_summary(avg_prospect_sentiment),
            "agent": _sentiment_summary(avg_agent_sentiment),
        },
        "deal_score": deal_score,
        "score_dimensions": [dimension.to_dict() for dimension in dimensions],
        "recommendations": _recommendation_summary(recommendations),
        "refined_pitch": "",
        "follow_up": {},
        "baseline_source": "REDACTED_OPAQUE_VALUE",
    }


def _role_metrics(metrics: list[dict[str, object]], role: str) -> dict[str, float]:
    selected = [item for item in metrics if item.get("role") == role]
    if not selected:
        return {"talk_time_seconds": 0.0, "avg_sentiment_score": 0.0}
    talk = sum(float(item.get("talk_time_seconds", 0.0)) for item in selected)
    sentiment_values = [float(item.get("avg_sentiment_score", 0.0)) for item in selected]
    return {
        "talk_time_seconds": talk,
        "avg_sentiment_score": round(sum(sentiment_values) / len(sentiment_values), 3) if sentiment_values else 0.0,
    }


def _key_topics(segments: list[Any]) -> list[str]:
    topics = [
        ("advertising", ["advertising", "ad ", "ads"]),
        ("facebook", ["facebook"]),
        ("tiktok", ["tiktok"]),
        ("gaming", ["gaming", "game"]),
        ("customer acquisition", ["customer", "download", "install", "acquisition"]),
        ("cost per install", ["cost per install", "cpi", "cost"]),
        ("roi", ["roi", "return on investment", "return"]),
        ("budget", ["budget", "price", "expensive"]),
        ("timeline", ["timeline", "next step", "quarter"]),
    ]
    transcript = " ".join(segment.text.lower() for segment in segments)
    found = [name for name, keywords in topics if any(keyword in transcript for keyword in keywords)]
    return found[:8]


def _key_moments(segments: list[Any]) -> list[str]:
    moments = []
    keywords = ("budget", "cost", "approval", "timeline", "next step", "return on investment", "problem", "concern")
    for segment in segments:
        text = segment.text.strip()
        if any(keyword in text.lower() for keyword in keywords):
            moments.append(f"{segment.id}: {text[:180]}")
        if len(moments) >= 6:
            break
    return moments


def _engagement_score(segments: list[Any], questions: list[Any], prospect_talk: float) -> int:
    if not segments:
        return 0
    question_score = min(40, len(questions) * 4)
    balance_score = max(0, 30 - int(abs(50 - prospect_talk) * 0.6))
    length_score = min(30, len(segments) // 5)
    return int(min(100, question_score + balance_score + length_score))


def _sales_strengths(segments: list[Any]) -> list[str]:
    transcript = " ".join(segment.text.lower() for segment in segments)
    strengths = []
    if "?" in transcript:
        strengths.append("Asked discovery questions")
    if "next step" in transcript or "follow" in transcript:
        strengths.append("Attempted to define a next step")
    if "roi" in transcript or "return on investment" in transcript:
        strengths.append("Connected discussion to ROI")
    return strengths[:5]


def _sales_weaknesses(segments: list[Any], objections: list[dict[str, object]], risks: list[dict[str, object]]) -> list[str]:
    weaknesses = []
    if objections:
        weaknesses.append("Buyer objections need explicit resolution")
    if risks:
        weaknesses.append("Deal risks require owner and next action")
    if not any("next step" in segment.text.lower() for segment in segments):
        weaknesses.append("No clear next step captured")
    return weaknesses[:5]


def _closing_effectiveness(segments: list[Any]) -> int:
    transcript = " ".join(segment.text.lower() for segment in segments)
    score = 0
    if "next step" in transcript:
        score += 4
    if "follow" in transcript:
        score += 3
    if "schedule" in transcript or "meeting" in transcript:
        score += 3
    return min(10, score)


def _sentiment_summary(score: float) -> dict[str, object]:
    if score > 0.15:
        sentiment = "positive"
    elif score < -0.15:
        sentiment = "negative"
    else:
        sentiment = "neutral"
    return {"sentiment": sentiment, "confidence": round(min(1.0, abs(score) + 0.55), 2), "trend": "stable"}


def _recommendation_summary(recommendations: list[Any]) -> dict[str, object]:
    first = recommendations[0] if recommendations else None
    if not first:
        return {
            "next_best_action": "Review the transcript and define a concrete next step.",
            "priority": "medium",
            "timeline": "next follow-up",
            "reasoning": "No recommendation was generated from transcript evidence.",
            "coaching_tips": [],
        }
    return {
        "next_best_action": first.action,
        "priority": first.priority,
        "timeline": "next follow-up",
        "reasoning": first.rationale,
        "coaching_tips": [item.action for item in recommendations[1:4]],
    }


def _write_status(
    job_dir: Path,
    *,
    status: str,
    deal_id: str | None = None,
    stage: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    job_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "job_id": job_dir.name,
        "deal_id": deal_id,
        "status": status,
        "stage": stage,
        "updated_at": utc_now_iso(),
    }
    if extra:
        payload.update(extra)
    (job_dir / "status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_failure(job_dir: Path, code: str, message: str, *, deal_id: str | None = None) -> None:
    payload = {
        "job_id": job_dir.name,
        "deal_id": deal_id,
        "status": "failed",
        "stage": "failed",
        "error": {"code": code, "message": message},
        "updated_at": utc_now_iso(),
    }
    job_dir.mkdir(parents=True, exist_ok=True)
    (job_dir / "error.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (job_dir / "status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload), file=sys.stderr)


def _safe_id(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "-" for ch in value)
    cleaned = "-".join(part for part in cleaned.split("-") if part)
    return cleaned[:80] or "job"


def _int_env(name: str) -> int | None:
    raw = os.getenv(name)
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


if __name__ == "__main__":
    raise SystemExit(main())
