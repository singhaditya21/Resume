import urllib.request
try:
    r = urllib.request.urlopen("http://localhost:8502/", timeout=5)
    print(f"HTTP {r.status} - Dashboard is UP")
    print(f"Content-Length: {r.headers.get('Content-Length', 'unknown')}")
except Exception as e:
    print(f"Dashboard check failed: {e}")