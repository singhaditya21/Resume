from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st

from app.businessnext_dashboard import render_businessnext_dashboard, render_businessnext_empty_state
from dealintel.n8n_workflow import build_n8n_workflow
from dealintel.pipeline import AnalysisPipeline


st.set_page_config(page_title="Deal Intelligence", layout="wide")


def _latest_runs() -> list[Path]:
    runs = ROOT / "runs"
    if not runs.exists():
        return []
    files = sorted(runs.glob("*/deal_intelligence.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    return files


def _load_payload(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _default_video() -> Path | None:
    videos = sorted(ROOT.glob("*.mp4"))
    return videos[0] if videos else None


with st.sidebar:
    st.header("Run Analysis")
    existing_video = _default_video()
    uploaded = st.file_uploader("Upload video recording", type=["mp4", "mov", "mkv", "mp3", "wav"])
    corrected_transcript = st.file_uploader("Use corrected transcript", type=["json", "csv"])
    deal_default = Path(uploaded.name).stem[:48] if uploaded else (existing_video.stem[:48] if existing_video else "demo-deal")
    deal_id = st.text_input("Deal ID", value=deal_default)
    run_clicked = st.button("Analyze", type="primary")

    use_existing = uploaded is None and corrected_transcript is None and existing_video is not None
    parakeet_model = "nvidia/parakeet-tdt-0_6b-v2"
    llm_provider = "glm"
    glm_model = "glm-5.1"
    glm_api_key = REDACTED_SECRET
    mistral_model = "REDACTED_OPAQUE_VALUE"
    mistral_api_key = REDACTED_SECRET
    groq_model = "llama-3.1-8b-instant"
    groq_api_key = REDACTED_SECRET
    ollama_model = "qwen3:8b"
    skip_diarization = False
    skip_visual = False
    apex_scenes = False
    skip_llm = False

if run_clicked:
    transcript_path = None
    if corrected_transcript:
        upload_dir = ROOT / "runs" / "_uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        transcript_path = upload_dir / corrected_transcript.name
        transcript_path.write_bytes(corrected_transcript.getbuffer())
        input_path = existing_video if use_existing and existing_video else None
    elif use_existing and existing_video:
        input_path = existing_video
    elif uploaded:
        upload_dir = ROOT / "runs" / "_uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        input_path = upload_dir / uploaded.name
        input_path.write_bytes(uploaded.getbuffer())
    else:
        st.error("Select or upload a video first.")
        st.stop()

    out_dir = ROOT / "runs" / deal_id
    pipeline = AnalysisPipeline(
        project_root=ROOT,
        vector_dir=ROOT / ".data" / "chroma",
        llm_provider=llm_provider,
        glm_api_key=glm_api_key or None,
        glm_model=glm_model,
        mistral_api_key=mistral_api_key or None,
        mistral_model=mistral_model,
        groq_api_key=groq_api_key or None,
        groq_model=groq_model,
        ollama_model=ollama_model,
    )
    with st.spinner("Analyzing. Parakeet transcription and local diarization can take several minutes; corrected transcripts skip transcription."):
        try:
            if transcript_path:
                payload = pipeline.analyze_transcript(
                    transcript_path=transcript_path,
                    deal_id=deal_id,
                    out_dir=out_dir,
                    source_video=input_path,
                    skip_visual=skip_visual,
                    apex_scenes=apex_scenes,
                    skip_llm=skip_llm,
                )
            else:
                payload = pipeline.analyze(
                    input_path=input_path,
                    deal_id=deal_id,
                    out_dir=out_dir,
                    parakeet_model=parakeet_model,
                    skip_diarization=skip_diarization,
                    skip_visual=skip_visual,
                    apex_scenes=apex_scenes,
                    skip_llm=skip_llm,
                )
            st.success(f"Analysis complete: {out_dir}")
        except Exception as exc:
            st.exception(exc)
            st.stop()
else:
    latest = _latest_runs()
    payload = _load_payload(latest[0]) if latest else None

workflow = build_n8n_workflow()

if not payload:
    render_businessnext_empty_state(workflow=workflow)
    st.stop()

render_businessnext_dashboard(payload, workflow=workflow)
