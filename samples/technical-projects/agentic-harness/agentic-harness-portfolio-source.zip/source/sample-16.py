"""Start the Deal Intelligence Dashboard."""
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
os.environ["REDACTED_OPAQUE_VALUE"] = "false"

# Always use .venv Python (system Python may not have streamlit)
venv_python = ROOT / ".venv" / "Scripts" / "python.exe"
python = str(venv_python) if venv_python.exists() else sys.executable

print(f"Using Python: {python}")
subprocess.run([
    python, "-m", "streamlit", "run",
    "app/streamlit_app.py",
    "--server.port", "8502",
    "--server.address", "0.0.0.0",
    "--server.headless", "true"
])
