from __future__ import annotations

from collections import defaultdict
from statistics import mean

from .models import Evidence, Recommendation, ScoreDimension, TranscriptSegment
from .text_utils import first_sentence, keyword_hits, normalize_space, word_count


POSITIVE_WORDS = [
    "great",
    "good",
    "helpful",
    "interested",
    "yes",
    "exactly",
    "valuable",
    "like",
    "works",
    "right",
    "perfect",
    "important",
]
NEGATIVE_WORDS = [
    "concern",
    "issue",
    "problem",
    "expensive",
    "cost",
    "budget",
    "delay",
    "difficult",
    "hard",
    "risk",
    "not",
    "no",
    "unsure",
    "can't",
    "cannot",
]

OBJECTION_KEYWORDS = [
    "too expensive",
    "budget",
    "cost",
    "price",
    "pricing",
    "no budget",
    "not interested",
    "think about it",
    "need approval",
    "send me",
    "competitor",
    "already use",
    "timeline",
    "later",
    "not sure",
]

RISK_KEYWORDS = [
    "no budget",
    "budget",
    "approval",
    "legal",
    "procurement",
    "security",
    "competitor",
    "timeline",
    "delay",
    "not interested",
    "decision maker",
    "boss",
    "manager",
    "contract",
]

SELLER_KEYWORDS = [
    "we help",
    "our product",
    "our solution",
    "can help",
    "let me",
    "next step",
    "follow up",
    "demo",
    "proposal",
    "recommend",
    "could you",
    "what are",
    "tell me",
]

BUYER_KEYWORDS = [
    "we need",
    "i need",
    "our team",
    "my team",
    "budget",
    "approval",
    "we already",
    "concern",
    "issue",
    "timeline",
    "not sure",
]

SCORE_FACTORS: list[tuple[str, float, list[str]]] = [
    ("Metrics", 8.0, ["metric", "roi", "revenue", "cost saving", "growth", "conversion", "target"]),
    ("Economic buyer", 9.0, ["decision maker", "economic buyer", "budget owner", "ceo", "cfo", "vp"]),
    ("Decision criteria", 8.0, ["criteria", "requirements", "must have", "evaluation", "compare"]),
    ("Decision process", 8.0, ["process", "approval", "procurement", "legal", "steps", "committee"]),
    ("Identify pain", 10.0, ["pain", "challenge", "problem", "issue", "struggle", "need"]),
    ("Champion", 8.0, ["champion", "sponsor", "advocate", "support", "push this"]),
    ("Competition", 7.0, ["competitor", "alternative", "vendor", "already use", "compare"]),
    ("Budget", 9.0, ["budget", "price", "pricing", "cost", "investment", "afford"]),
    ("Authority", 9.0, ["authority", "approval", "decision maker", "boss", "manager", "sign off"]),
    ("Need", 12.0, ["need", "important", "priority", "goal", "objective", "problem"]),
    ("Timeline", 12.0, ["timeline", "deadline", "when", "this quarter", "next month", "by"]),
]


def score_sentiment(text: str) -> tuple[str, float]:
    positive = len(keyword_hits(text, POSITIVE_WORDS))
    negative = len(keyword_hits(text, NEGATIVE_WORDS))
    total = positive + negative
    if total == 0:
        return "neutral", 0.0
    score = (positive - negative) / total
    if score > 0.2:
        return "positive", round(score, 3)
    if score < -0.2:
        return "negative", round(score, 3)
    return "neutral", round(score, 3)


def enrich_segment_sentiment(segments: list[TranscriptSegment]) -> list[TranscriptSegment]:
    for segment in segments:
        label, score = score_sentiment(segment.text)
        segment.sentiment = label
        segment.sentiment_score = score
    return segments


def infer_speaker_roles(segments: list[TranscriptSegment]) -> list[TranscriptSegment]:
    speaker_scores: dict[str, dict[str, int]] = defaultdict(lambda: {"seller": 0, "buyer": 0})
    for segment in segments:
        speaker = segment.speaker or "UNKNOWN"
        speaker_scores[speaker]["seller"] += len(keyword_hits(segment.text, SELLER_KEYWORDS))
        speaker_scores[speaker]["buyer"] += len(keyword_hits(segment.text, BUYER_KEYWORDS))
        if "?" in segment.text:
            speaker_scores[speaker]["seller"] += 1

    if not speaker_scores:
        return segments

    seller = max(speaker_scores, key=lambda name: speaker_scores[name]["seller"] - speaker_scores[name]["buyer"])
    for segment in segments:
        if segment.speaker == seller:
            segment.role = "sales_agent"
        elif len(speaker_scores) > 1:
            segment.role = "prospect"
        else:
            segment.role = "unknown"
    return segments


def speaker_metrics(segments: list[TranscriptSegment]) -> list[dict[str, object]]:
    by_speaker: dict[str, list[TranscriptSegment]] = defaultdict(list)
    for segment in segments:
        by_speaker[segment.speaker].append(segment)

    total_talk_time = sum(segment.duration for segment in segments) or 1.0
    metrics: list[dict[str, object]] = []
    for speaker, items in sorted(by_speaker.items()):
        sentiments = [segment.sentiment_score for segment in items]
        metrics.append(
            {
                "speaker": speaker,
                "role": items[0].role,
                "talk_time_seconds": round(sum(item.duration for item in items), 2),
                "talk_time_pct": round(sum(item.duration for item in items) / total_talk_time * 100, 2),
                "word_count": sum(word_count(item.text) for item in items),
                "turn_count": len(items),
                "avg_sentiment_score": round(mean(sentiments), 3) if sentiments else 0.0,
            }
        )
    return metrics


def extract_objections(segments: list[TranscriptSegment]) -> list[dict[str, object]]:
    objections: list[dict[str, object]] = []
    for segment in segments:
        hits = keyword_hits(segment.text, OBJECTION_KEYWORDS)
        if not hits:
            continue
        objections.append(
            {
                "type": _classify_objection(hits),
                "keywords": hits,
                "summary": first_sentence(segment.text),
                "speaker": segment.speaker,
                "role": segment.role,
                "segment_id": segment.id,
                "start": segment.start,
                "end": segment.end,
                "severity": "high" if segment.sentiment == "negative" else "medium",
                "confidence": 0.8 if segment.sentiment == "negative" else 0.65,
                "evidence": {
                    "segment_id": segment.id,
                    "text": normalize_space(segment.text),
                    "speaker": segment.speaker,
                    "start": segment.start,
                    "end": segment.end,
                },
            }
        )
    return objections


def extract_risks(segments: list[TranscriptSegment]) -> list[dict[str, object]]:
    risks: list[dict[str, object]] = []
    for segment in segments:
        hits = keyword_hits(segment.text, RISK_KEYWORDS)
        if not hits:
            continue
        risks.append(
            {
                "category": _classify_risk(hits),
                "keywords": hits,
                "summary": first_sentence(segment.text),
                "evidence": {
                    "segment_id": segment.id,
                    "text": normalize_space(segment.text),
                    "speaker": segment.speaker,
                    "start": segment.start,
                    "end": segment.end,
                },
                "severity": "high" if {"legal", "security", "competitor", "no budget"} & set(hits) else "medium",
                "confidence": 0.8 if {"legal", "security", "competitor", "no budget"} & set(hits) else 0.65,
            }
        )
    return risks


def score_deal(segments: list[TranscriptSegment]) -> tuple[float, list[ScoreDimension]]:
    transcript = " ".join(segment.text for segment in segments)
    dimensions: list[ScoreDimension] = []
    total_weight = sum(weight for _name, weight, _keywords in SCORE_FACTORS)
    weighted = 0.0

    for name, weight, keywords in SCORE_FACTORS:
        evidence = _evidence_for_keywords(segments, keywords)
        hits = keyword_hits(transcript, keywords)
        if evidence:
            raw = min(10.0, 2.5 + len(set(hits)) * 2.0)
            status = "supported_by_transcript"
            confidence = min(1.0, 0.4 + len(evidence[:3]) * 0.2)
            rationale = f"Found timestamped transcript evidence for {', '.join(sorted(set(hits)))}."
        else:
            raw = 0.0
            status = "insufficient_evidence"
            confidence = 0.0
            rationale = "insufficient_evidence: no timestamped transcript support found for this qualification factor."
        dimensions.append(
            ScoreDimension(
                name=name,
                score=round(raw, 2),
                weight=weight,
                rationale=rationale,
                status=status,
                confidence=round(confidence, 2),
                evidence=evidence[:3],
            )
        )
        weighted += raw * weight

    total = round((weighted / (total_weight * 10.0)) * 100, 2)
    return total, dimensions


def build_recommendations(
    score: float,
    dimensions: list[ScoreDimension],
    risks: list[dict[str, object]],
    objections: list[dict[str, object]],
) -> list[Recommendation]:
    recommendations: list[Recommendation] = []
    weak = sorted([item for item in dimensions if item.score < 5.0], key=lambda item: item.weight, reverse=True)

    if weak:
        first = weak[0]
        recommendations.append(
            Recommendation(
                priority="high",
                title=f"Confirm {first.name.lower()}",
                action=f"Ask a direct discovery question to capture missing {first.name.lower()} evidence before the next sales step.",
                rationale=f"{first.rationale} This is a gap-based recommendation, not a transcript claim.",
                confidence=0.45 if first.status == "insufficient_evidence" else first.confidence,
                evidence=first.evidence,
            )
        )

    if objections:
        obj = objections[0]
        recommendations.append(
            Recommendation(
                priority="high",
                title=f"Address {obj['type']} objection",
                action="Send a concise follow-up that acknowledges the objection, reframes value, and proposes a specific next step.",
                rationale=str(obj["summary"]),
                evidence=[
                    Evidence(
                        text=str(obj["summary"]),
                        source="transcript",
                        segment_id=str(obj.get("segment_id", "")),
                        start=float(obj["start"]),
                        end=float(obj["end"]),
                        speaker=str(obj["speaker"]),
                    )
                ],
                confidence=float(obj.get("confidence", 0.65)),
            )
        )

    if risks:
        risk = risks[0]
        ev = risk.get("evidence", {})
        recommendations.append(
            Recommendation(
                priority="medium",
                title=f"De-risk {risk['category']}",
                action="Create an owner and due date for this risk in the follow-up plan.",
                rationale=str(risk["summary"]),
                evidence=[
                    Evidence(
                        text=str(risk["summary"]),
                        source="transcript",
                        segment_id=str(ev.get("segment_id", "")),
                        start=float(ev.get("start", 0.0)),
                        end=float(ev.get("end", 0.0)),
                        speaker=str(ev.get("speaker", "")),
                    )
                ],
                confidence=float(risk.get("confidence", 0.65)),
            )
        )

    if score >= 70:
        recommendations.append(
            Recommendation(
                priority="medium",
                title="Advance to mutual action plan",
                action="Send a short recap with business outcomes, stakeholder map, and a dated decision path.",
                rationale="Deal score has enough qualification evidence to justify a structured next step.",
                confidence=0.7,
                evidence=_top_dimension_evidence(dimensions),
            )
        )
    else:
        recommendations.append(
            Recommendation(
                priority="medium",
                title="Run focused qualification",
                action="Do not pitch broadly; use the next interaction to validate pain, budget, authority, and timeline.",
                rationale="Deal score indicates incomplete qualification evidence. Missing items are marked as insufficient_evidence.",
                confidence=0.6,
                evidence=_top_dimension_evidence(dimensions),
            )
        )

    return recommendations


def _evidence_for_keywords(segments: list[TranscriptSegment], keywords: list[str]) -> list[Evidence]:
    evidence: list[Evidence] = []
    for segment in segments:
        if keyword_hits(segment.text, keywords):
            evidence.append(
                Evidence(
                    text=first_sentence(segment.text),
                    source="transcript",
                    segment_id=segment.id,
                    start=segment.start,
                    end=segment.end,
                    speaker=segment.speaker,
                )
            )
    return evidence


def _top_dimension_evidence(dimensions: list[ScoreDimension]) -> list[Evidence]:
    evidence: list[Evidence] = []
    for dimension in dimensions:
        evidence.extend(dimension.evidence)
        if len(evidence) >= 3:
            return evidence[:3]
    return evidence


def _classify_objection(hits: list[str]) -> str:
    joined = " ".join(hits)
    if any(word in joined for word in ["budget", "cost", "price", "pricing", "expensive"]):
        return "pricing"
    if any(word in joined for word in ["approval", "send me", "think about"]):
        return "authority/process"
    if any(word in joined for word in ["timeline", "later"]):
        return "timing"
    if any(word in joined for word in ["competitor", "already use"]):
        return "competition"
    return "general"


def _classify_risk(hits: list[str]) -> str:
    joined = " ".join(hits)
    if any(word in joined for word in ["legal", "procurement", "contract", "security"]):
        return "procurement/security"
    if any(word in joined for word in ["budget", "price", "cost"]):
        return "commercial"
    if any(word in joined for word in ["approval", "decision maker", "boss", "manager"]):
        return "stakeholder"
    if any(word in joined for word in ["competitor", "alternative"]):
        return "competitive"
    if any(word in joined for word in ["timeline", "delay"]):
        return "timeline"
    return "general"
