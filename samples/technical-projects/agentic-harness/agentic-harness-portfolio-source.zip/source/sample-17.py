import urllib.request, json
API_KEY = REDACTED_SECRET
BASE = "http://localhost:5678/api/v1"
headers = {"Content-Type": "application/json", "Accept": "application/json", "X-N8N-API-KEY": API_KEY}

# Get workflow ID
req = urllib.request.Request(f"{BASE}/workflows", headers=headers)
r = urllib.request.urlopen(req, timeout=10)
data = json.loads(r.read().decode())
for w in data.get("data", []):
    wf_id = w["id"]
    print(f"Activating workflow: {w['name']} (id={wf_id}) active={w['active']}")
    req2 = urllib.request.Request(f"{BASE}/workflows/{wf_id}/activate", headers=headers, method="POST")
    r2 = urllib.request.urlopen(req2, timeout=10)
    result = json.loads(r2.read().decode())
    print(f"  Active: {result.get('active', 'unknown')}")
    print(f"  Webhook: POST http://localhost:5678/webhook/deal-intelligence")