"""
Deal Intelligence Dashboard - Comprehensive Sales Call Analysis
"""
from __future__ import annotations
import json, os, sys, re, time, uuid, urllib.error, urllib.request
from pathlib import Path
from dataclasses import dataclass, asdict
from collections import defaultdict
from statistics import mean

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st
import pandas as pd

# Load .env
def _load_dotenv():
    p = ROOT / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())
_load_dotenv()

@dataclass
class Segment:
    id: str; start: float; end: float; speaker: str
    role: str = "unknown"; text: str = ""
    sentiment: str = "neutral"; sentiment_score: float = 0.0
    @property
    def duration(self): return max(0.0, self.end - self.start)
    def to_dict(self): return asdict(self)

def parse_transcript_file(path: Path) -> list[Segment]:
    text = path.read_text(encoding="utf-8")
    segs, sid = [], 0
    for line in text.splitlines():
        m = re.match(r'\[(\d+):(\d+)\]\s*(\w+):\s*(.+)', line.strip())
        if m:
            sid += 1
            start = int(m.group(1))*60 + int(m.group(2))
            segs.append(Segment(f"seg-{sid:03d}", start, start+10, m.group(3), text=m.group(4).strip()))
    for i in range(len(segs)-1):
        segs[i].end = segs[i+1].start
    return segs

def assign_roles(segs):
    SK = ["we help","our product","our solution","let me","next step","follow up","demo","proposal","recommend","plan","premium","coverage","policy","offer","enroll","brochure","quote","schedule"]
    BK = ["we need","i need","budget","concern","issue","not sure","think about","interested","question","husband","family","saving","skeptical","worried"]
    scores = defaultdict(lambda: {"s":0,"b":0})
    for s in segs:
        lo = s.text.lower()
        scores[s.speaker]["s"] += sum(1 for k in SK if k in lo)
        scores[s.speaker]["b"] += sum(1 for k in BK if k in lo)
        if "?" in s.text: scores[s.speaker]["s"] += 1
    if len(scores) < 2: return segs
    seller = max(scores, key=lambda x: scores[x]["s"]-scores[x]["b"])
    for s in segs:
        s.role = "sales_agent" if s.speaker == seller else "prospect"
    return segs

POS_W = ["great","good","helpful","interested","yes","exactly","valuable","like","works","right","perfect","important","wonderful","impressive","convenient","thoughtful","pleasure","responsible","reasonable","appreciate","thank","secure","protect"]
NEG_W = ["concern","issue","problem","expensive","cost","budget","delay","difficult","hard","risk","not","no","unsure","can't","cannot","skeptical","worried","afraid","hesitate","struggle"]

def kw_hits(text, kws): return [k for k in kws if k in text.lower()]

def score_sent(text):
    p,n = len(kw_hits(text,POS_W)), len(kw_hits(text,NEG_W))
    t = p+n
    if t==0: return "neutral",0.0
    sc = (p-n)/t
    return ("positive",round(sc,3)) if sc>0.2 else (("negative",round(sc,3)) if sc<-0.2 else ("neutral",round(sc,3)))

def enrich_sent(segs):
    for s in segs: s.sentiment, s.sentiment_score = score_sent(s.text)
    return segs

OBJ_KW = ["too expensive","budget","cost","price","pricing","no budget","not interested","think about it","need approval","send me","competitor","already use","timeline","later","not sure","concern","difficult","claims","skeptical","saving"]
RISK_KW = ["no budget","budget","approval","legal","procurement","security","competitor","timeline","delay","not interested","decision maker","boss","manager","contract","saving for","home loan","market"]

def classify_obj(hits):
    j = " ".join(hits)
    rules = [
        (["budget","cost","price","pricing","expensive","saving"], "pricing"),
        (["approval","send me","think about"], "authority/process"),
        (["timeline","later"], "timing"),
        (["competitor","already use"], "competition"),
        (["claims","difficult","skeptical"], "trust"),
    ]
    for kws, cat in rules:
        if any(w in j for w in kws):
            return cat
    return "general"

def classify_risk(hits):
    j = " ".join(hits)
    rules = [
        (["legal","procurement","contract","security"], "procurement/security"),
        (["budget","price","cost","saving"], "commercial"),
        (["approval","decision maker","boss","manager"], "stakeholder"),
        (["competitor","alternative"], "competitive"),
        (["timeline","delay"], "timeline"),
        (["market"], "market"),
    ]
    for kws, cat in rules:
        if any(w in j for w in kws):
            return cat
    return "general"

def extract_objections(segs):
    objs = []
    for s in segs:
        hits = kw_hits(s.text, OBJ_KW)
        if not hits: continue
        objs.append({"type":classify_obj(hits),"keywords":hits,"summary":s.text[:150],
                      "speaker":s.speaker,"role":s.role,"start":s.start,"end":s.end,
                      "severity":"high" if s.sentiment=="negative" else "medium",
                      "sentiment":s.sentiment,"segment_id":s.id})
    return objs

def extract_risks(segs):
    risks = []
    for s in segs:
        hits = kw_hits(s.text, RISK_KW)
        if not hits: continue
        risks.append({"category":classify_risk(hits),"keywords":hits,"summary":s.text[:150],
                       "speaker":s.speaker,"role":s.role,"start":s.start,"end":s.end,
                       "severity":"high" if s.sentiment=="negative" else "medium",
                       "segment_id":s.id})
    return risks

SCORE_FACTORS = [
    ("Metrics",8.0,["metric","roi","revenue","cost saving","growth","conversion","target","crore","lakh"]),
    ("Economic Buyer",9.0,["decision maker","economic buyer","budget owner","ceo","cfo","vp","husband","spouse"]),
    ("Decision Criteria",8.0,["criteria","requirements","must have","evaluation","compare","chart"]),
    ("Decision Process",8.0,["process","approval","procurement","legal","steps","discuss"]),
    ("Identify Pain",10.0,["pain","challenge","problem","issue","struggle","need","security","concern","scare","worried"]),
    ("Champion",8.0,["champion","sponsor","advocate","support","push this","friend","recommend"]),
    ("Competition",7.0,["competitor","alternative","vendor","already use","compare","market"]),
    ("Budget",9.0,["budget","price","pricing","cost","investment","afford","premium","rupees","monthly"]),
    ("Authority",9.0,["authority","approval","decision maker","boss","manager","sign off"]),
    ("Need",12.0,["need","important","priority","goal","objective","family","financial","coverage","protect"]),
    ("Timeline",12.0,["timeline","deadline","when","this quarter","next month","next week","wednesday","days"]),
]

def score_deal(segs):
    full = " ".join(s.text for s in segs)
    dims = []; tw = sum(w for _,w,_ in SCORE_FACTORS); weighted = 0.0
    for name,weight,kws in SCORE_FACTORS:
        hits = kw_hits(full,kws)
        ev = [s for s in segs if kw_hits(s.text,kws)]
        if hits:
            raw = min(10.0, 2.5+len(set(hits))*2.0)
            conf = min(1.0, 0.4+len(ev[:3])*0.2)
            rat = f"Evidence: {', '.join(sorted(set(hits)))}"
        else:
            raw,conf,rat = 0.0,0.0,"No transcript evidence"
        dims.append({"dimension":name,"score":round(raw,2),"weight":weight,"rationale":rat,
                      "confidence":round(conf,2),"evidence_count":len(ev)})
        weighted += raw*weight
    return round((weighted/(tw*10.0))*100,2), dims

def speaker_metrics(segs):
    by = defaultdict(list)
    for s in segs: by[s.speaker].append(s)
    tt = sum(s.duration for s in segs) or 1.0
    out = []
    for sp,items in sorted(by.items()):
        ss = [s.sentiment_score for s in items]
        out.append({"Speaker":sp,"Role":items[0].role,"Talk Time (s)":round(sum(s.duration for s in items),1),
                     "Talk %":round(sum(s.duration for s in items)/tt*100,1),
                     "Words":sum(len(s.text.split()) for s in items),"Turns":len(items),
                     "Avg Sentiment":round(mean(ss),3) if ss else 0.0,
                     "Positive":sum(1 for s in items if s.sentiment=="positive"),
                     "Negative":sum(1 for s in items if s.sentiment=="negative")})
    return out

def call_llm(sys_prompt, user_prompt):
    key = os.getenv("NVIDIA_API_KEY","")
    base = os.getenv("NVIDIA_BASE_URL","https://example.invalid").rstrip("/")
    model = os.getenv("MISTRAL_MODEL","meta/llama-3.3-70b-instruct")
    if not key or "replace" in key: return ""
    payload = {"model":model,"messages":[{"role":"system","content":sys_prompt},{"role":"user","content":user_prompt}],
               "max_tokens":4096,"temperature":0.2,"stream":False}
    try:
        req = urllib.request.Request(f"{base}/chat/completions",data=json.dumps(payload).encode(),
            headers={"Content-Type":"application/json","Authorization":f"Bearer {key}"},method="POST")
        with urllib.request.urlopen(req,timeout=120) as r:
            data = json.loads(r.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        return f"LLM Error: {e}"

def n8n_json_request(url, *, data=None, headers=None, timeout=30):
    req = urllib.request.Request(
        url,
        data=data,
        headers=headers or {},
        method="POST" if data is not None else "GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    return json.loads(raw) if raw else {}

def _safe_job_part(value):
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")[:40] or "video"

def _stage_video_for_n8n(*, file_name, file_bytes, deal_id):
    ext = Path(file_name).suffix.lower() or ".mp4"
    if ext not in {".mp4", ".mov", ".mkv", ".mp3", ".wav", ".m4a", ".webm"}:
        raise ValueError(f"Unsupported video extension: {ext}")
    job_id = f"{_safe_job_part(deal_id)}-{uuid.uuid4().hex[:12]}"
    shared_root = Path(os.getenv("N8N_SHARED_FILES_DIR", ROOT / "runs" / "n8n_files"))
    job_dir = shared_root / "jobs" / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    target = job_dir / f"source{ext}"
    target.write_bytes(file_bytes)
    return job_id, f"/files/jobs/{job_id}/{target.name}"

def post_video_to_n8n(url, *, file_name, file_bytes, deal_id, token=""):
    job_id, source_path = _stage_video_for_n8n(file_name=file_name, file_bytes=file_bytes, deal_id=deal_id)
    payload = {
        "deal_id": deal_id,
        "job_id": job_id,
        "source_path": source_path,
    }
    headers = {"Content-Type": "application/json"}
    if token:
        headers["X-DealIntel-Token"] = token
    return n8n_json_request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, timeout=120)

def build_recommendations(score, dims, risks, objections):
    recs = []
    weak = sorted([d for d in dims if d["score"]<5], key=lambda x:x["weight"],reverse=True)
    if weak:
        d = weak[0]
        recs.append({"priority":"high","title":f"Confirm {d['dimension']}","action":f"Ask a discovery question about {d['dimension'].lower()} before the next step.","rationale":d["rationale"]})
    if objections:
        o = objections[0]
        recs.append({"priority":"high","title":f"Address {o['type']} objection","action":"Acknowledge the concern, reframe value, propose next step.","rationale":o["summary"]})
    if risks:
        r = risks[0]
        recs.append({"priority":"medium","title":f"De-risk {r['category']}","action":"Create follow-up plan with owner and due date.","rationale":r["summary"]})
    if score >= 60:
        recs.append({"priority":"medium","title":"Advance to mutual action plan","action":"Send recap with outcomes, stakeholder map, decision path.","rationale":"Score supports structured next step."})
    else:
        recs.append({"priority":"medium","title":"Run focused qualification","action":"Validate pain, budget, authority, timeline in next interaction.","rationale":"Incomplete qualification evidence."})
    return recs

def sent_color(l):
    return {"positive":"🟢","negative":"🔴","neutral":"⚪"}.get(l,"⚪")

# ═══ APP ═══
st.set_page_config(page_title="Deal Intelligence Dashboard",page_icon="📊",layout="wide")

st.sidebar.title("📊 Deal Intelligence")
st.sidebar.markdown("---")
tdir = ROOT/"demo_transcripts"
tfiles = sorted(tdir.glob("*.txt")) if tdir.exists() else []
tnames = [f.name for f in tfiles]

mode = st.sidebar.radio("Analysis Mode",["🚀 n8n AI Pipeline","📋 Local Analysis","Paste Custom"],index=0)
segs,sname = [],""

video_upload_mode = st.sidebar.checkbox("Video Upload via n8n AI Pipeline", value=False)
if video_upload_mode:
    mode = "Video Upload"

if mode == "Video Upload":
    st.sidebar.markdown("### Video Pipeline Input")
    uploaded_video = st.sidebar.file_uploader("Upload video/audio", type=["mp4","mov","mkv","mp3","wav","m4a","webm"])
    default_deal = Path(uploaded_video.name).stem if uploaded_video else "video-deal"
    sname = st.sidebar.text_input("Deal ID", value=default_deal)
    analyze_btn = st.sidebar.button("Upload Video to n8n", type="primary", use_container_width=True)

    if not analyze_btn or not uploaded_video:
        st.markdown("""<div style="text-align:center;padding:80px 20px;">
            <h1>Deal Intelligence Dashboard</h1>
            <p style="font-size:18px;color:#666;">Upload a video and let the n8n AI pipeline transcribe, diarize, and analyze it.</p>
            <p style="color:#999;">Video Upload -> n8n -> Parakeet ASR -> pyannote diarization -> Milvus -> AI Agent</p></div>""", unsafe_allow_html=True)
        st.stop()

    progress_text = st.empty()
    progress = st.progress(0, text="Uploading video to n8n...")
    try:
        accepted = post_video_to_n8n(
            "http://localhost:5678/webhook/deal-video",
            file_name=uploaded_video.name,
            file_bytes=uploaded_video.getvalue(),
            deal_id=sname,
            token=REDACTED_SECRET
        )
        status_url = accepted.get("status_url")
        if not status_url:
            st.error("n8n did not return a status_url.")
            st.json(accepted)
            st.stop()

        n8n_result = None
        token = REDACTED_SECRET
        headers = {"X-DealIntel-Token": token} if token else {}
        for _attempt in range(720):
            status = n8n_json_request(status_url, headers=headers, timeout=30)
            state = status.get("status", "unknown")
            stage = status.get("stage", state)
            pct = 10
            if state == "transcribing":
                pct = 30
            elif state == "diarizing":
                pct = 55
            elif state == "analyzing":
                pct = 75
            elif state == "completed":
                pct = 100
            progress.progress(pct, text=f"n8n job {state}: {stage}")
            progress_text.info(f"Job {accepted.get('job_id')} status: {state} ({stage})")
            if state == "completed":
                n8n_result = status.get("result")
                break
            if state == "failed":
                st.error("Video job failed in n8n.")
                st.json(status)
                st.stop()
            time.sleep(5)

        progress_text.empty()
        progress.empty()
        if not n8n_result:
            st.error("Timed out waiting for n8n video job completion.")
            st.stop()
    except urllib.error.URLError as ue:
        progress_text.empty()
        progress.empty()
        st.error(f"Connection error: {ue}")
        st.info("Make sure the video-enabled n8n workflow is active in http://localhost:5678")
        st.stop()
    except Exception as e:
        progress_text.empty()
        progress.empty()
        st.error(f"Video pipeline error: {e}")
        st.info("Make sure the custom n8n container is running and HF_TOKEN is configured.")
        st.stop()

    nr = n8n_result if isinstance(n8n_result, dict) else {}
    dscore = nr.get("deal_score", 0)
    deal_health = nr.get("deal_health", "unknown")
    ci = nr.get("conversation_intelligence", {})
    risks = nr.get("risks", [])
    objections = nr.get("objections", [])
    sp = nr.get("sales_performance", {})
    sa = nr.get("sentiment_analysis", {})
    recs_data = nr.get("recommendations", {})
    pitch = nr.get("refined_pitch", "")
    fup = nr.get("follow_up", {})
    plbl = sa.get("prospect", {}).get("sentiment", "unknown")
    albl = sa.get("agent", {}).get("sentiment", "unknown")

    st.title("Video Deal Analysis")
    st.caption(f"{sname} | n8n Video AI Pipeline | Score: {dscore:.0f}/100 | Health: {deal_health}")

    k1,k2,k3,k4,k5 = st.columns(5)
    k1.metric("Deal Score", f"{dscore:.0f}/100")
    k2.metric("Prospect", f"{sent_color(plbl)} {str(plbl).title()}")
    k3.metric("Agent", f"{sent_color(albl)} {str(albl).title()}")
    k4.metric("Risks", len(risks))
    k5.metric("Objections", len(objections))
    st.markdown("---")

    t1,t2,t3,t4,t5,t6,t7 = st.tabs(["Conversation","Risks & Objections","Sales Performance",
        "Sentiment","Scoring & Recommendations","Follow-up & Pitch","Raw n8n Output"])

    with t1:
        st.subheader("Conversation Intelligence")
        ci_topics = ci.get("key_topics", [])
        ci_ratio = ci.get("talk_ratio", {})
        c1,c2,c3 = st.columns(3)
        c1.metric("Engagement Score", f"{ci.get('engagement_score', 0)}/100")
        c2.metric("Questions Asked", ci.get("questions_asked", 0))
        c3.metric("Key Topics", len(ci_topics))
        if ci_topics:
            st.markdown("**Key Topics:** " + ", ".join(f"`{t}`" for t in ci_topics))
        if ci_ratio:
            st.markdown(f"**Talk Ratio:** Agent {ci_ratio.get('agent',0)}% | Prospect {ci_ratio.get('prospect',0)}%")
        st.subheader("Transcript Artifacts")
        st.json(nr.get("transcript_artifacts", {}))
        st.subheader("Diarization")
        st.json(nr.get("diarization", {}))

    with t2:
        st.subheader("Objections")
        st.dataframe(pd.DataFrame(objections), use_container_width=True, hide_index=True) if objections else st.success("No objections detected.")
        st.subheader("Risks")
        st.dataframe(pd.DataFrame(risks), use_container_width=True, hide_index=True) if risks else st.success("No risks detected.")

    with t3:
        st.subheader("Sales Performance")
        st.json(sp)

    with t4:
        st.subheader("Sentiment Analysis")
        st.json(sa)

    with t5:
        st.subheader(f"Deal Score: {dscore:.0f}/100")
        st.json(recs_data)

    with t6:
        st.subheader("Follow-up Email")
        if fup.get("subject"):
            st.text_input("Subject", value=fup["subject"], key="video_fup_sub")
            st.text_area("Body", value=fup.get("body",""), height=300, key="video_fup_body")
        st.subheader("Refined Pitch")
        st.markdown(pitch or "No refined pitch generated.")

    with t7:
        st.json(nr)
        st.download_button("Download JSON", json.dumps(nr, indent=2),
            file_name=f"n8n_video_deal_intelligence_{sname}.json", mime="application/json")

    st.stop()

if mode == "🚀 n8n AI Pipeline":
    st.sidebar.markdown("### n8n Pipeline Input")
    input_mode = st.sidebar.radio("Input Source",["Demo Transcripts","Paste JSON"],index=0)
    if input_mode == "Demo Transcripts":
        sname = st.sidebar.selectbox("Select Transcript",tnames)
        if sname:
            raw_text = (tdir/sname).read_text(encoding="utf-8")
            segs = parse_transcript_file(tdir/sname)
    else:
        sname = "custom"
        raw_text = st.sidebar.text_area("Paste Transcript Text",height=300,placeholder="[00:00] Speaker: Hello...")
        if raw_text:
            tmp=ROOT/"runs"/"_tmp.txt"; tmp.parent.mkdir(parents=True,exist_ok=True)
            tmp.write_text(raw_text,encoding="utf-8"); segs=parse_transcript_file(tmp)
    analyze_btn = st.sidebar.button("🚀 Run n8n Pipeline",type="primary",use_container_width=True)

    if not analyze_btn or not raw_text:
        st.markdown("""<div style="text-align:center;padding:80px 20px;">
            <h1>📊 Deal Intelligence Dashboard</h1>
            <p style="font-size:18px;color:#666;">Select a transcript and click <b>Run n8n Pipeline</b> to analyze</p>
            <p style="color:#999;">Full AI Pipeline: Embedding → Milvus → AI Agent → 9 Metrics</p></div>""",unsafe_allow_html=True)
        st.stop()

    # Call n8n webhook
    webhook_url = "http://localhost:5678/webhook/deal-intelligence"
    payload = {"transcript": raw_text, "deal_id": sname.replace(".txt","")}

    progress_text = st.empty()
    progress_text.info("🚀 Running n8n pipeline (Embedding → Milvus → AI Agent → Scoring)... This may take 2-5 minutes...")
    try:
        req = urllib.request.Request(webhook_url, data=json.dumps(payload).encode(),
            headers={"Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=600) as r:
            raw_resp = r.read().decode()
            if not raw_resp or raw_resp.strip() == "":
                st.error("❌ Pipeline returned empty response. Check n8n execution logs at http://localhost:5678")
                st.stop()
            n8n_result = json.loads(raw_resp)
        progress_text.empty()
    except urllib.error.URLError as ue:
        progress_text.empty()
        st.error(f"❌ Connection error: {ue}")
        st.info("Make sure the n8n workflow is **Active** in http://localhost:5678")
        st.stop()
    except json.JSONDecodeError as je:
        progress_text.empty()
        st.error(f"❌ Invalid JSON response: {je}")
        st.text(raw_resp[:1000])
        st.stop()
    except Exception as e:
        progress_text.empty()
        st.error(f"❌ Pipeline error: {e}")
        st.info("Make sure the n8n workflow is **Active** in http://localhost:5678")
        st.stop()

    # Parse n8n result
    nr = n8n_result if isinstance(n8n_result, dict) else {}
    dscore = nr.get("deal_score", 0)
    deal_health = nr.get("deal_health", "unknown")
    severity = nr.get("severity", "unknown")
    ci = nr.get("conversation_intelligence", {})
    risks = nr.get("risks", [])
    objections = nr.get("objections", [])
    sp = nr.get("sales_performance", {})
    sa = nr.get("sentiment_analysis", {})
    recs_data = nr.get("recommendations", {})
    pitch = nr.get("refined_pitch", "")
    fup = nr.get("follow_up", {})
    plbl = sa.get("prospect", {}).get("sentiment", "unknown")
    albl = sa.get("agent", {}).get("sentiment", "unknown")

    tmap = {"transcript_001":"🛡️ Life Insurance","transcript_002":"💻 SaaS Pitch","transcript_003":"🏠 Real Estate","transcript_004":"🏦 Bank CRM"}
    dtitle = next((v for k,v in tmap.items() if k in sname),"📋 Deal Analysis")
    st.title(f"{dtitle}")
    st.caption(f"{sname} | n8n AI Pipeline | Score: {dscore:.0f}/100 | Health: {deal_health}")

    # KPI ROW
    k1,k2,k3,k4,k5 = st.columns(5)
    k1.metric("🎯 Deal Score", f"{dscore:.0f}/100")
    k2.metric("😊 Prospect", f"{sent_color(plbl)} {str(plbl).title()}")
    k3.metric("💼 Agent", f"{sent_color(albl)} {str(albl).title()}")
    k4.metric("⚠️ Risks", len(risks))
    k5.metric("🚫 Objections", len(objections))
    st.markdown("---")

    t1,t2,t3,t4,t5,t6,t7 = st.tabs(["🗣️ Conversation","⚠️ Risks & Objections","📊 Sales Performance",
        "😊 Sentiment","🎯 Scoring & Recommendations","📧 Follow-up & Pitch","🔗 Raw n8n Output"])

    with t1:
        st.subheader("Conversation Intelligence")
        ci_topics = ci.get("key_topics", [])
        ci_ratio = ci.get("talk_ratio", {})
        ci_engage = ci.get("engagement_score", 0)
        ci_questions = ci.get("questions_asked", 0)
        ci_moments = ci.get("key_moments", [])
        c1,c2,c3 = st.columns(3)
        c1.metric("🎯 Engagement Score", f"{ci_engage}/100")
        c2.metric("❓ Questions Asked", ci_questions)
        c3.metric("🔑 Key Topics", len(ci_topics))
        if ci_topics:
            st.markdown("**Key Topics:** " + ", ".join(f"`{t}`" for t in ci_topics))
        if ci_ratio:
            st.markdown(f"**Talk Ratio:** Agent {ci_ratio.get('agent',0)}% | Prospect {ci_ratio.get('prospect',0)}%")
        if ci_moments:
            st.subheader("Key Moments")
            for m in ci_moments:
                st.markdown(f"- 💡 {m}")
        st.subheader("Transcript")
        st.text_area("Full Transcript", value=raw_text[:5000], height=300, disabled=True)

    with t2:
        st.subheader("🚫 Objections")
        if objections:
            odf = pd.DataFrame([{"Type":o.get("type",""),"Severity":o.get("severity",""),
                "Summary":o.get("summary",""),"Evidence":o.get("evidence","")} for o in objections])
            st.dataframe(odf, use_container_width=True, hide_index=True)
        else: st.success("No objections detected!")
        st.subheader("⚠️ Risks")
        if risks:
            rdf = pd.DataFrame([{"Category":r.get("category",""),"Severity":r.get("severity",""),
                "Summary":r.get("summary",""),"Evidence":r.get("evidence","")} for r in risks])
            st.dataframe(rdf, use_container_width=True, hide_index=True)
        else: st.success("No risks detected!")
        if risks:
            st.subheader("Risk Heat Map")
            from collections import Counter
            rc = Counter(r.get("category","unknown") for r in risks)
            st.bar_chart(pd.DataFrame({"Count":rc}))

    with t3:
        st.subheader("Sales Performance (AI)")
        sp_score = sp.get("overall_score", 0)
        sp_str = sp.get("strengths", [])
        sp_weak = sp.get("weaknesses", [])
        sp_tech = sp.get("technique_rating", 0)
        sp_close = sp.get("closing_effectiveness", 0)
        c1,c2 = st.columns(2)
        c1.metric("📊 Overall Score", f"{sp_score}/100")
        c2.metric("🎯 Technique", f"{sp_tech}/100")
        if sp_str:
            st.markdown("**✅ Strengths:**")
            for s in sp_str: st.markdown(f"- {s}")
        if sp_weak:
            st.markdown("**⚠️ Weaknesses:**")
            for w in sp_weak: st.markdown(f"- {w}")

    with t4:
        st.subheader("Sentiment Analysis (AI)")
        ps = sa.get("prospect", {})
        ag = sa.get("agent", {})
        c1,c2 = st.columns(2)
        with c1:
            p_sent = ps.get("sentiment","unknown")
            p_conf = ps.get("confidence",0)
            p_trend = ps.get("trend","unknown")
            st.metric("😊 Prospect", f"{sent_color(p_sent)} {p_sent.title()}")
            st.metric("Confidence", f"{p_conf}%")
            st.metric("Trend", p_trend)
        with c2:
            a_sent = ag.get("sentiment","unknown")
            a_conf = ag.get("confidence",0)
            a_trend = ag.get("trend","unknown")
            st.metric("💼 Agent", f"{sent_color(a_sent)} {a_sent.title()}")
            st.metric("Confidence", f"{a_conf}%")
            st.metric("Trend", a_trend)

    with t5:
        st.subheader(f"🎯 Deal Score: {dscore:.0f}/100")
        score_color = "green" if dscore>=60 else "orange" if dscore>=40 else "red"
        st.markdown(f'<div style="background:#1e293b;padding:20px;border-radius:10px;text-align:center;">'
            f'<span style="font-size:48px;font-weight:800;color:{score_color};">{dscore:.0f}</span>'
            f'<span style="font-size:24px;color:#94a3b8;">/100</span> | '
            f'<span style="font-size:18px;color:{"green" if deal_health=="healthy" else "orange" if deal_health=="at_risk" else "red"};">'
            f'{deal_health.upper()}</span></div>', unsafe_allow_html=True)
        st.subheader("📋 Recommendations")
        nba = recs_data.get("next_best_action", "")
        priority = recs_data.get("priority", "")
        timeline = recs_data.get("timeline", "")
        reasoning = recs_data.get("reasoning", "")
        tips = recs_data.get("coaching_tips", [])
        if nba:
            pc = "🔴" if priority=="critical" else "🟡" if priority=="high" else "🟢"
            st.markdown(f"**{pc} Next Best Action:** {nba}")
            st.markdown(f"- **Priority:** {priority}")
            st.markdown(f"- **Timeline:** {timeline}")
            st.markdown(f"- **Reasoning:** {reasoning}")
        if tips:
            st.subheader("🎓 Coaching Tips")
            for tip in tips:
                st.markdown(f"- 💡 {tip}")

    with t6:
        st.subheader("📧 Follow-up Email")
        if fup.get("subject"):
            st.text_input("Subject", value=fup["subject"], key="n8n_fup_sub")
            st.text_area("Body", value=fup["body"], height=300, key="n8n_fup_body")
            st.info(f"⏰ Send: {fup.get('timing','Within 24 hours')} | Channel: {fup.get('channel','email')}")
        st.subheader("🎯 Refined Pitch")
        if pitch:
            st.markdown(pitch)
        else:
            st.info("No refined pitch generated.")

    with t7:
        st.subheader("🔗 Raw n8n Pipeline Output")
        st.json(nr)
        st.download_button("📥 Download JSON", json.dumps(nr, indent=2),
            file_name=f"n8n_deal_intelligence_{sname}.json", mime="application/json")

    st.stop()  # End of n8n mode

# ═══ LOCAL ANALYSIS MODE ═══
if mode=="📋 Local Analysis":
    sname = st.sidebar.selectbox("Select Transcript",tnames)
    if sname: segs = parse_transcript_file(tdir/sname)
else:
    ct = st.sidebar.text_area("Paste Transcript",height=300,placeholder="[00:00] Speaker: Hello...")
    if ct:
        tmp=ROOT/"runs"/"_tmp.txt"; tmp.parent.mkdir(parents=True,exist_ok=True)
        tmp.write_text(ct,encoding="utf-8"); segs=parse_transcript_file(tmp); sname="custom"

use_llm = st.sidebar.checkbox("🤖 LLM Full Analysis (Llama 3.3 70B via NVIDIA NIM)", value=True)
analyze_btn = st.sidebar.button("🔍 Analyze",type="primary",use_container_width=True)

if not segs or not analyze_btn:
    st.markdown("""<div style="text-align:center;padding:80px 20px;">
        <h1>📊 Deal Intelligence Dashboard</h1>
        <p style="font-size:18px;color:#666;">Select a transcript and click Analyze to begin</p>
        <p style="color:#999;">Conversation Intelligence • Risks & Objections • Deal Scoring • Sentiment Analysis • Recommendations</p></div>""",unsafe_allow_html=True)
    st.stop()

with st.spinner("Processing transcript..."):
    segs = assign_roles(enrich_sent(segs))
    objs = extract_objections(segs)
    risks = extract_risks(segs)
    dscore,dims = score_deal(segs)
    spm = speaker_metrics(segs)
    recs = build_recommendations(dscore,dims,risks,objs)
    ttext = "\n".join(f"[{int(s.start//60):02d}:{int(s.start%60):02d}] {s.speaker}: {s.text}" for s in segs)

    # Initialize with local/keyword defaults
    pitch,nba,fup = "","",{"subject":"","body":"","timing":""}
    llm_ci, llm_risks, llm_objs, llm_sp, llm_sa = {}, [], [], {}, {}
    llm_score, llm_recs, llm_pitch, llm_fup = None, {}, "", {}

    psl = [s.sentiment_score for s in segs if s.role=="prospect"]
    asl = [s.sentiment_score for s in segs if s.role=="sales_agent"]
    plbl = "positive" if mean(psl)>0.15 else ("negative" if mean(psl)<-0.15 else "neutral") if psl else "unknown"
    albl = "positive" if mean(asl)>0.15 else ("negative" if mean(asl)<-0.15 else "neutral") if asl else "unknown"

    def _parse_llm_json(raw):
        """Parse LLM response into JSON, handling markdown fences and extras."""
        clean = raw.strip()
        if clean.startswith("```"):
            clean = re.sub(r"^```(?:json)?\s*", "", clean, flags=re.IGNORECASE)
            clean = re.sub(r"\s*```$", "", clean)
        if not clean.startswith("{"):
            m = re.search(r"\{.*\}", clean, flags=re.DOTALL)
            if m: clean = m.group(0)
        return json.loads(clean)

    if use_llm:
        llm_progress = st.progress(0, text="🤖 LLM Call 1/2: Analyzing transcript...")

        # ── CALL 1: ANALYSIS (6 metrics — analytical assessment) ──
        ANALYSIS_SYS = (
            "You are an expert sales conversation intelligence analyst. You analyze sales call transcripts "
            "to extract deal intelligence. You ALWAYS respond with strict JSON — never markdown, never text outside JSON."
        )
        ANALYSIS_USER = (
            f"Analyze this sales call transcript and produce an analytical report.\n\n"
            f"=== TRANSCRIPT ===\n{ttext[:6000]}\n=== END TRANSCRIPT ===\n\n"
            "Return STRICT JSON with these exact top-level key/opt/portfolio/project"
            "1. 'conversation_intelligence': {{key_topics: string[], talk_ratio: {{agent: number, prospect: number}}, "
            "engagement_score: 0-100, questions_asked: number, key_moments: string[]}}\n\n"
            "2. 'risks': array of {{category, severity (critical/high/medium/low), summary, evidence (exact quote)}}\n\n"
            "3. 'objections': array of {{type, severity, summary, evidence (exact quote)}}\n\n"
            "4. 'sales_performance': {{overall_score: 0-100, strengths: string[], weaknesses: string[], "
            "technique_rating: 0-100, closing_effectiveness: 0-100}}\n\n"
            "5. 'sentiment_analysis': {{prospect: {{sentiment, confidence: 0-100, trend}}, agent: {{sentiment, confidence: 0-100, trend}}}}\n\n"
            "6. 'deal_score': number 0-100\n\n"
            "Return ONLY valid JSON."
        )
        analysis_ok = False
        llm_raw = call_llm(ANALYSIS_SYS, ANALYSIS_USER)

        if llm_raw and not llm_raw.startswith("LLM Error"):
            try:
                llm_result = _parse_llm_json(llm_raw)
                llm_ci = llm_result.get("conversation_intelligence", {})
                llm_risks = llm_result.get("risks", [])
                llm_objs = llm_result.get("objections", [])
                llm_sp = llm_result.get("sales_performance", {})
                llm_sa = llm_result.get("sentiment_analysis", {})
                llm_score = llm_result.get("deal_score")

                # Apply analysis results over local results
                if llm_risks: risks = llm_risks
                if llm_objs: objs = llm_objs
                if llm_score is not None: dscore = llm_score
                if llm_sa:
                    ps = llm_sa.get("prospect", {})
                    als = llm_sa.get("agent", {})
                    if ps.get("sentiment"): plbl = ps["sentiment"]
                    if als.get("sentiment"): albl = als["sentiment"]
                analysis_ok = True
            except (json.JSONDecodeError, KeyError) as e:
                st.warning(f"⚠️ Call 1 parsing failed ({e}), using keyword-based analysis.")

        llm_progress.progress(50, text="🤖 LLM Call 1/2 complete. Starting Call 2/2: Generating actions...")

        # ── CALL 2: ACTION (3 metrics — generative, uses Call 1 results) ──
        if analysis_ok:
            # Summarize Call 1 findings for Call 2 context
            top_risks = "; ".join(r.get("summary","")[:80] for r in risks[:3])
            top_objs = "; ".join(o.get("summary","")[:80] for o in objs[:3])
            sp_summary = f"Score {llm_sp.get('overall_score',0)}/100" if llm_sp else "N/A"

            ACTION_SYS = (
                "You are a sales action generator. Given deal analysis results, you produce actionable outputs. "
                "You ALWAYS respond with strict JSON — never markdown, never text outside JSON."
            )
            ACTION_USER = (
                f"Based on this deal analysi/opt/portfolio/project"
                f"- Deal Score: {dscore}/100\n"
                f"- Prospect Sentiment: {plbl}\n"
                f"- Top Risks: {top_risks or 'None'}\n"
                f"- Top Objections: {top_objs or 'None'}\n"
                f"- Sales Performance: {sp_summary}\n\n"
                f"Original transcript excerp/opt/portfolio/project"
                "Return STRICT JSON with these exact key/opt/portfolio/project"
                "1. 'recommendations': {{next_best_action, priority, timeline, reasoning, coaching_tips: string[]}}\n\n"
                "2. 'refined_pitch': string — a refined sales pitch tailored to this prospect addressing their concerns\n\n"
                "3. 'follow_up': {{subject, body, timing, channel}}\n\n"
                "Return ONLY valid JSON."
            )
            llm_raw2 = call_llm(ACTION_SYS, ACTION_USER)

            if llm_raw2 and not llm_raw2.startswith("LLM Error"):
                try:
                    llm_action = _parse_llm_json(llm_raw2)
                    llm_recs = llm_action.get("recommendations", {})
                    llm_pitch = llm_action.get("refined_pitch", "")
                    llm_fup = llm_action.get("follow_up", {})

                    if llm_pitch: pitch = llm_pitch
                    if llm_fup: fup = llm_fup
                    if llm_recs: nba = llm_recs.get("next_best_action", "")
                except (json.JSONDecodeError, KeyError) as e:
                    st.warning(f"⚠️ Call 2 parsing failed ({e}), action items use defaults.")
            else:
                st.warning("⚠️ Call 2 failed, action items use keyword defaults.")
        else:
            st.warning("⚠️ Call 1 failed, skipping Call 2. Using keyword-based analysis.")

        llm_progress.progress(100, text="✅ LLM analysis complete!")
        import time; time.sleep(0.5)
        llm_progress.empty()

tmap = {"transcript_001":"🛡️ Life Insurance","transcript_002":"💻 SaaS Pitch","transcript_003":"🏠 Real Estate","transcript_004":"🏦 Bank CRM"}
dtitle = next((v for k,v in tmap.items() if k in sname),"📋 Deal Analysis")
st.title(f"{dtitle}")
st.caption(f"{sname} | {len(segs)} segments | Score: {dscore:.0f}/100")

# KPI ROW
k1,k2,k3,k4,k5 = st.columns(5)
k1.metric("🎯 Deal Score",f"{dscore:.0f}/100")
k2.metric("😊 Prospect",f"{sent_color(plbl)} {plbl.title()}")
k3.metric("💼 Agent",f"{sent_color(albl)} {albl.title()}")
k4.metric("⚠️ Risks",len(risks))
k5.metric("🚫 Objections",len(objs))
st.markdown("---")

# TABS
t1,t2,t3,t4,t5,t6,t7 = st.tabs(["🗣️ Conversation","⚠️ Risks & Objections","📊 Sales Performance",
    "😊 Sentiment","🎯 Scoring & Recommendations","📧 Follow-up & Pitch","🔗 n8n Webhook"])

with t1:
    if use_llm and llm_ci:
        st.subheader("🗣️ Conversation Intelligence (LLM)")
        ci_topics = llm_ci.get("key_topics", [])
        ci_ratio = llm_ci.get("talk_ratio", {})
        ci_engage = llm_ci.get("engagement_score", 0)
        ci_questions = llm_ci.get("questions_asked", 0)
        ci_moments = llm_ci.get("key_moments", [])
        c1,c2,c3 = st.columns(3)
        c1.metric("🎯 Engagement Score", f"{ci_engage}/100")
        c2.metric("❓ Questions Asked", ci_questions)
        c3.metric("🔑 Key Topics", len(ci_topics))
        if ci_topics:
            st.markdown("**Key Topics:** " + ", ".join(f"`{t}`" for t in ci_topics))
        if ci_ratio:
            st.markdown(f"**Talk Ratio:** Agent {ci_ratio.get('agent',0)}% | Prospect {ci_ratio.get('prospect',0)}%")
        if ci_moments:
            st.markdown("**Key Moments:**")
            for m in ci_moments:
                st.markdown(f"- 💡 {m}")
        st.markdown("---")
    st.subheader("Speaker Metrics")
    if spm: st.dataframe(pd.DataFrame(spm),use_container_width=True,hide_index=True)
    st.subheader("Transcript")
    tdata = [{"Time":f"{int(s.start//60):02d}:{int(s.start%60):02d}","Speaker":s.speaker,"Role":s.role,
              "Sentiment":f"{sent_color(s.sentiment)} {s.sentiment}","Text":s.text} for s in segs]
    st.dataframe(pd.DataFrame(tdata),use_container_width=True,height=400)
    st.subheader("Sentiment Timeline")
    tl_data = pd.DataFrame({"Score":[s.sentiment_score for s in segs],
        "Index":range(len(segs)),"Speaker":[s.speaker for s in segs]})
    st.line_chart(tl_data,x="Index",y="Score",height=300)

with t2:
    src = "LLM" if (use_llm and (llm_objs or llm_risks)) else "Keyword"
    st.caption(f"Source: {src}-based analysis")
    st.subheader("🚫 Objections")
    if objs:
        odf = pd.DataFrame([{"Type":o.get("type",""),"Severity":o.get("severity",""),
            "Speaker":o.get("speaker",""),"Summary":o.get("summary",""),
            "Evidence":o.get("evidence",""),"Keywords":", ".join(o.get("keywords",[]))} for o in objs])
        st.dataframe(odf,use_container_width=True,hide_index=True)
    else: st.success("No objections detected!")
    st.subheader("⚠️ Risks")
    if risks:
        rdf = pd.DataFrame([{"Category":r.get("category",""),"Severity":r.get("severity",""),
            "Speaker":r.get("speaker",""),"Summary":r.get("summary",""),
            "Evidence":r.get("evidence",""),"Keywords":", ".join(r.get("keywords",[]))} for r in risks])
        st.dataframe(rdf,use_container_width=True,hide_index=True)
    else: st.success("No risks detected!")
    if risks:
        st.subheader("Risk Heat Map")
        rc = defaultdict(int)
        for r in risks:
            rc[r.get("category","unknown")] += 1
        st.bar_chart(pd.DataFrame({"Count":rc}))

with t3:
    if use_llm and llm_sp:
        st.subheader("📊 Sales Performance (LLM)")
        sp_ov = llm_sp.get("overall_score", 0)
        sp_tech = llm_sp.get("technique_rating", 0)
        sp_close = llm_sp.get("closing_effectiveness", 0)
        sp_str = llm_sp.get("strengths", [])
        sp_weak = llm_sp.get("weaknesses", [])
        c1,c2,c3 = st.columns(3)
        c1.metric("📊 Overall Score", f"{sp_ov}/100")
        c2.metric("🎯 Technique", f"{sp_tech}/100")
        c3.metric("🏁 Closing Effectiveness", f"{sp_close}/100")
        if sp_str:
            st.markdown("**✅ Strengths:**")
            for s in sp_str: st.markdown(f"- {s}")
        if sp_weak:
            st.markdown("**⚠️ Weaknesses:**")
            for w in sp_weak: st.markdown(f"- {w}")
        st.markdown("---")
    st.subheader("MEDDICC+BANT Score Breakdown")
    for d in dims:
        pct = (d["score"]/10)*100
        c = "#22c55e" if pct>=50 else "#eab308" if pct>=25 else "#ef4444"
        st.markdown(f"""<div style="background:#1e293b;padding:10px;border-radius:6px;margin:4px 0;">
            <div style="display:flex;justify-content:space-between;color:white;font-size:13px;">
            <span><b>{d['dimension']}</b> <span style="color:#94a3b8;font-size:11px;">(wt:{d['weight']})</span></span>
            <span style="color:{c};font-weight:700;">{d['score']:.1f}/10</span></div>
            <div style="background:#374151;border-radius:3px;height:8px;margin-top:4px;">
            <div style="background:{c};height:100%;width:{pct}%;border-radius:3px;"></div></div>
            <div style="font-size:11px;color:#94a3b8;margin-top:3px;">{d['rationale']}</div></div>""",unsafe_allow_html=True)
    st.subheader("Dimension Comparison")
    cdf = pd.DataFrame({"Dimension":[d["dimension"] for d in dims],"Score":[d["score"] for d in dims]})
    st.bar_chart(cdf,x="Dimension",y="Score",height=350)

with t4:
    st.subheader("Sentiment Analysis by Speaker Role")
    sc1,sc2 = st.columns(2)
    with sc1:
        st.markdown(f"### 😊 Prospect Sentiment: {sent_color(plbl)} {plbl.title()}")
        psegs = [s for s in segs if s.role=="prospect"]
        if psegs:
            sp = pd.DataFrame({"Segment":range(len(psegs)),"Score":[s.sentiment_score for s in psegs]})
            st.line_chart(sp,x="Segment",y="Score")
            st.write("**Prospect Sentiment Details:**")
            for s in psegs:
                st.markdown(f"- {sent_color(s.sentiment)} **[{int(s.start//60):02d}:{int(s.start%60):02d}] {s.speaker}**: {s.text[:100]}")
    with sc2:
        st.markdown(f"### 💼 Agent Sentiment: {sent_color(albl)} {albl.title()}")
        asegs = [s for s in segs if s.role=="sales_agent"]
        if asegs:
            sa = pd.DataFrame({"Segment":range(len(asegs)),"Score":[s.sentiment_score for s in asegs]})
            st.line_chart(sa,x="Segment",y="Score")
            st.write("**Agent Sentiment Details:**")
            for s in asegs:
                st.markdown(f"- {sent_color(s.sentiment)} **[{int(s.start//60):02d}:{int(s.start%60):02d}] {s.speaker}**: {s.text[:100]}")
    # Sentiment distribution
    st.subheader("Sentiment Distribution")
    sd1,sd2 = st.columns(2)
    pcounts = defaultdict(int)
    for s in psegs: pcounts[s.sentiment]+=1
    acounts = defaultdict(int)
    for s in asegs: acounts[s.sentiment]+=1
    sd1.markdown("**Prospect**")
    sd1.json(dict(pcounts))
    sd2.markdown("**Agent**")
    sd2.json(dict(acounts))

with t5:
    st.subheader(f"🎯 Deal Score: {dscore:.0f}/100")
    score_color = "green" if dscore>=60 else "orange" if dscore>=40 else "red"
    st.markdown(f'<div style="background:#1e293b;padding:20px;border-radius:10px;text-align:center;">'
        f'<span style="font-size:48px;font-weight:800;color:{score_color};">{dscore:.0f}</span>'
        f'<span style="font-size:24px;color:#94a3b8;">/100</span></div>',unsafe_allow_html=True)
    if use_llm and llm_recs:
        st.subheader("📋 Recommendations (LLM)")
        nba_llm = llm_recs.get("next_best_action", "")
        priority = llm_recs.get("priority", "")
        timeline = llm_recs.get("timeline", "")
        reasoning = llm_recs.get("reasoning", "")
        tips = llm_recs.get("coaching_tips", [])
        if nba_llm:
            pc = "🔴" if priority=="critical" else "🟡" if priority=="high" else "🟢"
            st.markdown(f"**{pc} Next Best Action:** {nba_llm}")
            st.markdown(f"- **Priority:** {priority}")
            st.markdown(f"- **Timeline:** {timeline}")
            st.markdown(f"- **Reasoning:** {reasoning}")
        if tips:
            st.subheader("🎓 Coaching Tips")
            for tip in tips:
                st.markdown(f"- 💡 {tip}")
        st.markdown("---")
    st.subheader("📋 Keyword-Based Recommendations")
    for i,r in enumerate(recs):
        pc = "🔴" if r["priority"]=="high" else "🟡" if r["priority"]=="medium" else "🟢"
        st.markdown(f"**{pc} {r['title']}** (Priority: {r['priority']})")
        st.markdown(f"- **Action:** {r['action']}")
        st.markdown(f"- **Rationale:** {r['rationale']}")
        st.markdown("---")

with t6:
    st.subheader("📧 Follow-up Email")
    if fup.get("subject"):
        st.text_input("Subject",value=fup["subject"],key="fup_sub")
        st.text_area("Body",value=fup["body"],height=300,key="fup_body")
        st.info(f"⏰ Send: {fup.get('timing','Within 24 hours')}")
    else:
        st.info("Enable LLM in sidebar to generate follow-up email.")
    st.subheader("🎯 Refined Pitch")
    if pitch and not pitch.startswith("LLM Error"):
        st.markdown(pitch)
    else:
        st.info("Enable LLM to generate refined pitch.")

with t7:
    st.subheader("🔗 n8n Webhook Integration")
    webhook_url = st.text_input("n8n Webhook URL",value="http://localhost:5678/webhook/deal-intelligence")
    # Build payload
    payload = {
        "schema_version":"1.0","deal_id":sname.replace(".txt",""),
        "deal_score":dscore,"prospect_sentiment":plbl,"agent_sentiment":albl,
        "risks":risks,"objections":objs,"recommendations":recs,
        "speaker_metrics":spm,"dimensions":dims,
        "next_best_action":nba,"follow_up":fup,"refined_pitch":pitch,
        "transcript":[{"time":f"{int(s.start//60):02d}:{int(s.start%60):02d}","speaker":s.speaker,
                        "role":s.role,"sentiment":s.sentiment,"text":s.text} for s in segs]
    }
    st.subheader("Payload Preview")
    st.json(payload)
    col1,col2 = st.columns(2)
    with col1:
        st.download_button("📥 Download JSON",json.dumps(payload,indent=2),
            file_name=f"deal_intelligence_{sname}.json",mime="application/json",use_container_width=True)
    with col2:
        if st.button("📤 Send to n8n Webhook",use_container_width=True):
            try:
                req = urllib.request.Request(webhook_url,data=json.dumps(payload).encode(),
                    headers={"Content-Type":"application/json"},method="POST")
                with urllib.request.urlopen(req,timeout=30) as r:
                    resp = r.read().decode()
                st.success(f"✅ Sent! Response: {resp[:200]}")
            except Exception as e:
                st.error(f"❌ Webhook error: {e}")
    # n8n workflow import
    st.subheader("📋 n8n Workflow Template")
    n8n_wf = {
        "name":"Deal Intelligence Webhook","nodes":[
            {"parameters":{"httpMethod":"POST","path":"deal-intelligence","responseMode":"responseNode"},
             "name":"Webhook","type":"n8n-nodes-base.webhook","position":[250,300]},
            {"parameters":{"respondWith":"json","responseBody":"={{ JSON.stringify({status:'ok',deal_id:$json.body.deal_id,score:$json.body.deal_score}) }}"},
             "name":"Respond","type":"n8n-nodes-base.respondToWebhook","position":[500,300]},
        ],"connections":{"Webhook":{"main":[[{"node":"Respond","type":"main","index":0}]]}},
        "settings":{"executionOrder":"v1"}
    }
    st.download_button("📥 Download n8n Workflow",json.dumps(n8n_wf,indent=2),
        file_name="deal_intelligence_webhook.json",mime="application/json",use_container_width=True)
    st.caption("Import this into n8n via Menu → Import from File. It creates a POST webhook at /deal-intelligence.")
