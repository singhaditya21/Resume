'use strict';

const { execFile } = require('node:child_process');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const http = require('node:http');
const path = require('node:path');
const { URL } = require('node:url');

loadEnvFile(path.join(__dirname, '.env'));

const PORT = Number(process.env.PORT || 5680);
const HOST = process.env.HOST || '0.0.0.0';
const N8N_BASE_URL = process.env.N8N_BASE_URL || 'http://127.0.0.1:5678';
const N8N_DIR = process.env.N8N_DIR || '/biztech/AgenticHarness/n8n';
const N8N_SERVICE = process.env.N8N_SERVICE || 'n8n-agentic-harness.service';
const N8N_API_KEY = process.env.N8N_API_KEY || '';
const PUBLIC_DIR = path.join(__dirname, 'public');
const SAMPLE_LIMIT = 72;
const EVENT_LIMIT = 80;

const staticTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

const monitor = {
  last: null,
  events: [],
  clients: new Set(),
  sequence: 0,
  running: false,
  samples: {
    latency: [],
    executions: [],
    failures: [],
    activeWorkflows: [],
  },
};

function loadEnvFile(filePath) {
  try {
    for (const rawLine of fs.readFileSync(filePath, 'utf8').split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const separator = line.indexOf('=');
      if (separator === -1) continue;
      const key = line.slice(0, separator).trim();
      let value = line.slice(separator + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      if (key && !(key in process.env)) process.env[key] = value;
    }
  } catch {
    // Missing .env means the UI can still show health, but not API telemetry.
  }
}

function nowIso() {
  return new Date().toISOString();
}

function run(command, args, options = {}) {
  return new Promise((resolve) => {
    execFile(command, args, {
      cwd: options.cwd || undefined,
      timeout: options.timeout || 5000,
      maxBuffer: options.maxBuffer || 1024 * 1024,
    }, (error, stdout, stderr) => {
      resolve({
        ok: !error,
        stdout: String(stdout || '').trim(),
        stderr: String(stderr || '').trim(),
      });
    });
  });
}

async function fetchText(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs || 4000);
  const started = Date.now();
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: options.headers || {},
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = null;
    }
    return {
      ok: response.ok,
      statusCode: response.status,
      latencyMs: Date.now() - started,
      body,
      text: body ? undefined : text.slice(0, 500),
    };
  } catch (error) {
    return {
      ok: false,
      statusCode: 0,
      latencyMs: Date.now() - started,
      error: error.name === 'AbortError' ? 'Request timed out' : error.message,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function n8nApi(pathname, params = {}) {
  if (!N8N_API_KEY) {
    return { ok: false, statusCode: 0, latencyMs: 0, error: 'N8N_API_KEY is not configured' };
  }
  const url = new URL(pathname, N8N_BASE_URL);
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value));
  return fetchText(url.href, {
    timeoutMs: 7000,
    headers: { 'X-N8N-API-KEY': N8N_API_KEY },
  });
}

async function getN8nRuntime() {
  const [service, enabled, port] = await Promise.all([
    run('systemctl', ['is-active', N8N_SERVICE], { timeout: 2500 }),
    run('systemctl', ['is-enabled', N8N_SERVICE], { timeout: 2500 }),
    run('ss', ['-ltnp'], { timeout: 2500, maxBuffer: 2 * 1024 * 1024 }),
  ]);
  const listeners = port.stdout.split('\n').filter((line) => line.includes(':5678'));
  return {
    service: {
      name: N8N_SERVICE,
      active: service.stdout || service.stderr || 'unknown',
      enabled: enabled.stdout || enabled.stderr || 'unknown',
    },
    port: {
      ok: listeners.length > 0,
      port: 5678,
      listeners,
    },
  };
}

async function getN8nStorage() {
  const [folder, sqlite, log, binary] = await Promise.all([
    run('du', ['-sh', N8N_DIR], { timeout: 5000 }),
    run('du', ['-h', path.join(N8N_DIR, 'data/.n8n/database.sqlite')], { timeout: 5000 }),
    run('du', ['-h', path.join(N8N_DIR, 'logs/n8n.log')], { timeout: 5000 }),
    run('du', ['-sh', path.join(N8N_DIR, 'data/binaryData')], { timeout: 5000 }),
  ]);
  return {
    folder: firstToken(folder.stdout),
    sqlite: firstToken(sqlite.stdout),
    log: firstToken(log.stdout),
    binaryData: firstToken(binary.stdout),
  };
}

function firstToken(value) {
  return value.split(/\s+/)[0] || 'unknown';
}

function durationMs(execution) {
  if (!execution || !execution.startedAt || !execution.stoppedAt) return null;
  const value = Date.parse(execution.stoppedAt) - Date.parse(execution.startedAt);
  return Number.isFinite(value) && value >= 0 ? value : null;
}

async function getN8nApiState() {
  const [workflowsRes, executionsRes, credentialsRes, tagsRes, usersRes] = await Promise.all([
    n8nApi('/api/v1/workflows', { limit: 100 }),
    n8nApi('/api/v1/executions', { limit: 20, includeData: false }),
    n8nApi('/api/v1/credentials', { limit: 100 }),
    n8nApi('/api/v1/tags', { limit: 100 }),
    n8nApi('/api/v1/users', { limit: 100 }),
  ]);

  const workflows = Array.isArray(workflowsRes.body?.data) ? workflowsRes.body.data : [];
  const executions = Array.isArray(executionsRes.body?.data) ? executionsRes.body.data : [];
  const credentials = Array.isArray(credentialsRes.body?.data) ? credentialsRes.body.data : [];
  const tags = Array.isArray(tagsRes.body?.data) ? tagsRes.body.data : [];
  const users = Array.isArray(usersRes.body?.data) ? usersRes.body.data : [];
  const workflowById = new Map(workflows.map((workflow) => [workflow.id, workflow]));
  const failures = executions.filter((execution) => ['error', 'failed', 'crashed'].includes(execution.status));
  const running = executions.filter((execution) => ['running', 'new', 'waiting'].includes(execution.status) || execution.finished === false);
  const success = executions.filter((execution) => execution.status === 'success');
  const latestExecution = executions[0] || null;

  return {
    configured: Boolean(N8N_API_KEY),
    ok: workflowsRes.ok && executionsRes.ok,
    endpoints: {
      workflows: endpointSummary(workflowsRes),
      executions: endpointSummary(executionsRes),
      credentials: endpointSummary(credentialsRes),
      tags: endpointSummary(tagsRes),
      users: endpointSummary(usersRes),
    },
    workflows: {
      total: workflows.length,
      active: workflows.filter((workflow) => workflow.active).length,
      inactive: workflows.filter((workflow) => !workflow.active && !workflow.isArchived).length,
      archived: workflows.filter((workflow) => workflow.isArchived).length,
      items: workflows.slice(0, 20).map((workflow) => ({
        id: workflow.id,
        name: workflow.name,
        active: Boolean(workflow.active),
        updatedAt: workflow.updatedAt,
        nodeCount: Array.isArray(workflow.nodes) ? workflow.nodes.length : 0,
        triggerCount: workflow.triggerCount || 0,
      })),
    },
    executions: {
      totalRecent: executions.length,
      success: success.length,
      failed: failures.length,
      running: running.length,
      latest: latestExecution ? enrichExecution(latestExecution, workflowById) : null,
      items: executions.slice(0, 14).map((execution) => enrichExecution(execution, workflowById)),
    },
    inventory: {
      credentials: credentials.length,
      tags: tags.length,
      users: users.length,
    },
  };
}

function enrichExecution(execution, workflowById) {
  return {
    id: execution.id,
    status: execution.status,
    mode: execution.mode,
    workflowId: execution.workflowId,
    workflowName: workflowById.get(execution.workflowId)?.name || execution.workflowId || 'unknown',
    startedAt: execution.startedAt,
    stoppedAt: execution.stoppedAt,
    durationMs: durationMs(execution),
  };
}

function endpointSummary(result) {
  return {
    ok: result.ok,
    statusCode: result.statusCode,
    latencyMs: result.latencyMs,
    error: result.error,
  };
}

function addSample(bucket, value) {
  if (!Number.isFinite(value)) return;
  bucket.push({ at: nowIso(), value });
  while (bucket.length > SAMPLE_LIMIT) bucket.shift();
}

function recordEvent(agent, level, message, detail) {
  const event = {
    id: ++monitor.sequence,
    at: nowIso(),
    agent,
    level,
    message,
    detail: detail || '',
  };
  monitor.events.unshift(event);
  while (monitor.events.length > EVENT_LIMIT) monitor.events.pop();
  broadcast('activity', event);
}

function buildAgents(snapshot) {
  const n8nHealthy = Boolean(snapshot.n8n.health.ok && snapshot.n8n.health.body?.status === 'ok');
  const serviceMismatch = snapshot.n8n.runtime.service.active !== 'active' && snapshot.n8n.runtime.port.ok;
  const latest = snapshot.n8n.api.executions.latest;

  return [
    {
      id: 'health',
      name: 'Health Agent',
      state: n8nHealthy ? 'active' : 'critical',
      headline: n8nHealthy ? 'n8n health endpoint is green' : 'n8n health endpoint is failing',
      metric: snapshot.n8n.health.statusCode ? `${snapshot.n8n.health.latencyMs} ms` : 'offline',
      detail: `${N8N_BASE_URL}/healthz`,
    },
    {
      id: 'workflow',
      name: 'Workflow Agent',
      state: snapshot.n8n.api.ok ? 'active' : 'warning',
      headline: `${snapshot.n8n.api.workflows.active} active of ${snapshot.n8n.api.workflows.total} workflows`,
      metric: `${snapshot.n8n.api.workflows.inactive} inactive`,
      detail: 'Watching workflow inventory through the n8n public API',
    },
    {
      id: 'execution',
      name: 'Execution Agent',
      state: snapshot.n8n.api.executions.failed > 0 ? 'warning' : 'active',
      headline: latest ? `Latest ${latest.status}: ${latest.workflowName}` : 'No recent executions',
      metric: `${snapshot.n8n.api.executions.success}/${snapshot.n8n.api.executions.totalRecent} succeeded`,
      detail: latest ? `Execution ${latest.id}, ${formatMs(latest.durationMs)}` : 'Waiting for workflow activity',
    },
    {
      id: 'api',
      name: 'API Agent',
      state: snapshot.n8n.api.ok ? 'active' : 'warning',
      headline: snapshot.n8n.api.ok ? 'n8n API telemetry is live' : 'n8n API telemetry needs attention',
      metric: `${snapshot.n8n.api.endpoints.workflows.statusCode}/${snapshot.n8n.api.endpoints.executions.statusCode}`,
      detail: 'Polling workflows, executions, credentials, tags, and users',
    },
    {
      id: 'credential',
      name: 'Credential Agent',
      state: 'active',
      headline: `${snapshot.n8n.api.inventory.credentials} credentials visible`,
      metric: `${snapshot.n8n.api.inventory.users} users`,
      detail: `${snapshot.n8n.api.inventory.tags} tags from n8n API`,
    },
    {
      id: 'runtime',
      name: 'Runtime Agent',
      state: serviceMismatch ? 'warning' : snapshot.n8n.runtime.port.ok ? 'active' : 'critical',
      headline: serviceMismatch ? 'n8n port is up; unit is inactive' : snapshot.n8n.runtime.port.ok ? 'n8n listener is present' : 'n8n listener is missing',
      metric: '5678',
      detail: `${snapshot.n8n.runtime.service.name}: ${snapshot.n8n.runtime.service.active}/${snapshot.n8n.runtime.service.enabled}`,
    },
    {
      id: 'storage',
      name: 'n8n Storage Agent',
      state: 'active',
      headline: `SQLite DB ${snapshot.n8n.storage.sqlite}`,
      metric: snapshot.n8n.storage.folder,
      detail: `Log ${snapshot.n8n.storage.log}, binary data ${snapshot.n8n.storage.binaryData}`,
    },
  ];
}

function formatMs(value) {
  if (!Number.isFinite(value)) return 'open';
  if (value < 1000) return `${value} ms`;
  const seconds = Math.round(value / 1000);
  if (seconds < 60) return `${seconds}s`;
  return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
}

function detectEvents(previous, current) {
  if (!previous) {
    recordEvent('Command Center', 'info', 'n8n-focused monitoring started', 'Only n8n health, workflows, executions, API, and n8n storage are shown');
    if (current.n8n.api.configured) recordEvent('API Agent', 'success', 'n8n API key accepted', 'Public API telemetry enabled');
    return;
  }

  const prevHealth = Boolean(previous.n8n.health.ok && previous.n8n.health.body?.status === 'ok');
  const nextHealth = Boolean(current.n8n.health.ok && current.n8n.health.body?.status === 'ok');
  if (prevHealth !== nextHealth) {
    recordEvent('Health Agent', nextHealth ? 'success' : 'critical', nextHealth ? 'n8n recovered' : 'n8n health check failed', current.n8n.health.error || `HTTP ${current.n8n.health.statusCode}`);
  }

  if (previous.n8n.api.workflows.active !== current.n8n.api.workflows.active) {
    recordEvent('Workflow Agent', 'info', 'Active workflow count changed', `${previous.n8n.api.workflows.active} -> ${current.n8n.api.workflows.active}`);
  }

  const prevExecution = previous.n8n.api.executions.latest;
  const nextExecution = current.n8n.api.executions.latest;
  if (nextExecution && (!prevExecution || nextExecution.id !== prevExecution.id || nextExecution.status !== prevExecution.status)) {
    const level = nextExecution.status === 'success' ? 'success' : ['error', 'failed', 'crashed'].includes(nextExecution.status) ? 'critical' : 'info';
    recordEvent('Execution Agent', level, `Execution ${nextExecution.status}`, `${nextExecution.workflowName} #${nextExecution.id}`);
  }
}

async function collectSnapshot() {
  const generatedAt = nowIso();
  const [health, runtime, storage, api] = await Promise.all([
    fetchText(`${N8N_BASE_URL.replace(/\/$/, '')}/healthz`, { timeoutMs: 3000 }),
    getN8nRuntime(),
    getN8nStorage(),
    getN8nApiState(),
  ]);

  const snapshot = {
    generatedAt,
    n8n: {
      url: N8N_BASE_URL,
      health,
      runtime,
      storage,
      api,
    },
  };

  snapshot.agents = buildAgents(snapshot);
  addSample(monitor.samples.latency, health.statusCode ? health.latencyMs : 0);
  addSample(monitor.samples.executions, api.executions.totalRecent);
  addSample(monitor.samples.failures, api.executions.failed);
  addSample(monitor.samples.activeWorkflows, api.workflows.active);
  snapshot.samples = monitor.samples;

  detectEvents(monitor.last, snapshot);
  snapshot.events = monitor.events;
  monitor.last = snapshot;
  broadcast('snapshot', snapshot);
  return snapshot;
}

async function monitoringLoop() {
  if (monitor.running) return;
  monitor.running = true;
  try {
    await collectSnapshot();
  } catch (error) {
    recordEvent('Command Center', 'critical', 'n8n monitoring loop failed', error.message);
  } finally {
    monitor.running = false;
  }
}

function broadcast(eventName, payload) {
  const body = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const response of monitor.clients) response.write(body);
}

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(JSON.stringify(payload, null, 2));
}

async function serveStatic(response, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.normalize(path.join(PUBLIC_DIR, requested));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    response.writeHead(403);
    response.end('Forbidden');
    return;
  }
  try {
    const body = await fsp.readFile(filePath);
    response.writeHead(200, {
      'Content-Type': staticTypes[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-store',
    });
    response.end(body);
  } catch {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('Not found');
  }
}

const server = http.createServer(async (request, response) => {
  const requestUrl = new URL(request.url, `https://example.invalid || 'localhost'}`);

  if (request.method === 'GET' && requestUrl.pathname === '/api/status') {
    sendJson(response, 200, monitor.last || await collectSnapshot());
    return;
  }

  if (request.method === 'GET' && requestUrl.pathname === '/api/events') {
    response.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-store',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    response.write(': connected\n\n');
    monitor.clients.add(response);
    if (monitor.last) response.write(`event: snapshot\ndata: ${JSON.stringify(monitor.last)}\n\n`);
    request.on('close', () => monitor.clients.delete(response));
    return;
  }

  if (request.method === 'GET' && requestUrl.pathname === '/healthz') {
    sendJson(response, 200, { status: 'ok' });
    return;
  }

  if (request.method === 'GET') {
    await serveStatic(response, requestUrl.pathname);
    return;
  }

  response.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
  response.end('Method not allowed');
});

server.listen(PORT, HOST, () => {
  console.log(`n8n-focused command center listening on ${HOST}:${PORT}`);
  monitoringLoop();
  setInterval(monitoringLoop, 5000);
  setInterval(() => broadcast('ping', { at: nowIso() }), 15000);
});
