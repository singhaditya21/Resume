from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pandas as pd

try:
    import streamlit as st
except ModuleNotFoundError:  # Allows adapter unit tests without UI dependencies.
    st = None

try:
    import altair as alt
except Exception:  # pragma: no cover - Streamlit-native fallback handles this.
    alt = None


PRIMARY = "#D73875"
SECONDARY = "#D0DE47"
INK = "#060808"
MUTED = "#6B7280"
SURFACE = "#FFFFFF"
WORKSPACE = "#F3F4F6"
SUCCESS = "#45B36B"
WARNING = "#F7B731"
DANGER = "#EF5B5B"
BLUE = "#3C80D3"
CYAN = "#87D8E3"
ORANGE = "#F8B51A"


def render_businessnext_dashboard(payload: dict[str, Any], *, workflow: dict[str, Any] | None = None) -> None:
    if st is None:
        raise RuntimeError("Streamlit is required to render the BUSINESSNEXT dashboard.")
    data = adapt_payload(payload)
    inject_businessnext_css()
    render_shell_header(data)

    tabs = st.tabs(
        [
            "Executive Overview",
            "RevOps Financials",
            "Conversation Intelligence",
            "Risks, Objections & Coaching",
            "Actions & Export",
        ]
    )

    with tabs[0]:
        render_executive_overview(data)
    with tabs[1]:
        render_financials(data)
    with tabs[2]:
        render_conversation(data)
    with tabs[3]:
        render_risks_and_coaching(data)
    with tabs[4]:
        render_actions_and_export(data, payload, workflow=workflow)


def render_businessnext_empty_state(*, workflow: dict[str, Any] | None = None) -> None:
    if st is None:
        raise RuntimeError("Streamlit is required to render the BUSINESSNEXT dashboard.")
    inject_businessnext_css()
    render_shell_header(
        {
            "deal_id": "No deal selected",
            "deal_health": "Ready",
            "generated_at": "",
        }
    )
    k1, k2, k3, k4 = st.columns(4)
    metric_card(k1, "Dashboard Mode", "Ready", "Run or load analysis", "soft-green")
    metric_card(k2, "Executive View", "Enabled", "Summary-first layout", "soft-blue")
    metric_card(k3, "RevOps Financials", "Enabled", "Evidence-backed only", "soft-cream")
    metric_card(k4, "Exports", "Available", "n8n workflow ready", "soft-cyan")

    left, right = st.columns([1.2, 0.8])
    with left:
        card_start("Sales Intelligence Workspace")
        st.write(
            "Run a video analysis or place a completed `deal_intelligence.json` under `runs/<deal-id>` "
            "to populate the executive dashboard, RevOps financials, conversation intelligence, coaching, "
            "and evidence exports."
        )
        st.markdown(
            chip("BUSINESSNEXT style", "primary")
            + chip("Executive summary")
            + chip("Financial evidence")
            + chip("Sales coaching"),
            unsafe_allow_html=True,
        )
        card_end()

    with right:
        card_start("Expected Output")
        st.markdown("- Executive Overview")
        st.markdown("- RevOps Financials")
        st.markdown("- Conversation Intelligence")
        st.markdown("- Risks, Objections & Coaching")
        st.markdown("- Actions & Export")
        card_end()

    card_start("n8n Workflow")
    if workflow:
        st.download_button(
            "Download n8n Workflow JSON",
            data=json.dumps(workflow, indent=2),
            file_name="dealintel_n8n_workflow.json",
            mime="application/json",
        )
        with st.expander("Preview n8n Workflow JSON"):
            st.json(workflow)
    else:
        st.info("n8n workflow metadata is not available.")
    card_end()


def adapt_payload(payload: dict[str, Any]) -> dict[str, Any]:
    deal = payload.get("deal_intelligence", {}) if isinstance(payload.get("deal_intelligence"), dict) else {}
    convo = payload.get("conversation_intelligence", {}) if isinstance(payload.get("conversation_intelligence"), dict) else {}
    transcript = payload.get("transcript", {}) if isinstance(payload.get("transcript"), dict) else {}
    n8n = payload.get("n8n", {}) if isinstance(payload.get("n8n"), dict) else {}

    score = _number(deal.get("score", payload.get("deal_score", n8n.get("score", 0))))
    risks = _ensure_list(deal.get("risks", payload.get("risks", [])))
    objections = _ensure_list(deal.get("objections", payload.get("objections", [])))
    recommendations = _recommendations(payload.get("recommendations", []))
    segments = _ensure_list(transcript.get("segments", payload.get("transcript", [])))
    speaker_metrics = _ensure_list(convo.get("speaker_metrics", payload.get("speaker_metrics", [])))
    dimensions = _ensure_list(deal.get("dimensions", payload.get("dimensions", [])))
    financial = payload.get("financial_intelligence") if isinstance(payload.get("financial_intelligence"), dict) else _empty_financial()
    sales = payload.get("sales_performance") if isinstance(payload.get("sales_performance"), dict) else _fallback_sales(payload)
    executive = payload.get("executive_summary") if isinstance(payload.get("executive_summary"), dict) else _fallback_executive(payload, score, risks, objections, recommendations)
    sentiment = convo.get("customer_sentiment", payload.get("prospect_sentiment", "unknown"))
    agent_sentiment = convo.get("sales_agent_sentiment", payload.get("agent_sentiment", "unknown"))
    confidence = _number(payload.get("analysis_confidence", {}).get("overall", executive.get("confidence", 0)))

    return {
        "payload": payload,
        "deal_id": str(payload.get("deal_id") or n8n.get("deal_id") or "deal"),
        "generated_at": str(payload.get("generated_at", "")),
        "score": score,
        "deal_health": _health_label(score, risks, objections),
        "sentiment": str(sentiment),
        "agent_sentiment": str(agent_sentiment),
        "confidence": confidence,
        "risks": risks,
        "objections": objections,
        "recommendations": recommendations,
        "segments": segments,
        "speaker_metrics": speaker_metrics,
        "dimensions": dimensions,
        "financial": financial,
        "sales": sales,
        "executive": executive,
        "follow_up": payload.get("follow_up", {}) if isinstance(payload.get("follow_up"), dict) else {},
        "refined_pitch": str(payload.get("refined_pitch", "")),
        "next_best_action": str(n8n.get("next_best_action") or executive.get("next_best_action", {}).get("text") or "Review the call and define next steps."),
        "artifacts": payload.get("transcript_artifacts", {}) if isinstance(payload.get("transcript_artifacts"), dict) else {},
        "visual": payload.get("visual_intelligence", {}) if isinstance(payload.get("visual_intelligence"), dict) else {},
        "scene": payload.get("scene_intelligence", {}) if isinstance(payload.get("scene_intelligence"), dict) else {},
    }


def inject_businessnext_css() -> None:
    st.markdown(
        f"""
        <style>
        @import url('https://example.invalid');
        :root {{
            --bn-primary: {PRIMARY};
            --bn-secondary: {SECONDARY};
            --bn-ink: {INK};
            --bn-muted: {MUTED};
            --bn-workspace: {WORKSPACE};
            --bn-surface: {SURFACE};
        }}
        html, body, [class*="css"] {{
            font-family: "Poppins", "Inter", "Segoe UI", sans-serif;
            color: var(--bn-ink);
        }}
        .stApp {{
            background: var(--bn-workspace);
        }}
        [data-testid="stSidebar"] {{
            background: #080A0A;
        }}
        [data-testid="stSidebar"] * {{
            color: #F9FAFB;
        }}
        .block-container {{
            padding-top: 1.1rem;
            max-width: 1440px;
        }}
        .bn-header {{
            background: #060808;
            color: white;
            border-radius: 0;
            padding: 18px 24px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
        }}
        .bn-logo {{
            font-size: 20px;
            font-weight: 800;
            line-height: 0.95;
            letter-spacing: 0;
        }}
        .bn-search {{
            background: #252728;
            border: 1px solid #3B3D3E;
            color: #D1D5DB;
            border-radius: 22px;
            padding: 10px 18px;
            min-width: 280px;
            flex: 0 1 420px;
            font-size: 13px;
        }}
        .bn-header-meta {{
            display: flex;
            gap: 12px;
            align-items: center;
            font-size: 12px;
            color: #D1D5DB;
        }}
        .bn-card {{
            background: #FFFFFF;
            border: 1px solid #E5E7EB;
            border-radius: 8px;
            padding: 18px;
            min-height: 100%;
        }}
        .bn-section-title {{
            font-size: 18px;
            font-weight: 700;
            margin: 2px 0 14px;
        }}
        .bn-card-title {{
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 10px;
        }}
        .bn-muted {{
            color: var(--bn-muted);
            font-size: 12px;
        }}
        .bn-metric {{
            background: #FFFFFF;
            border: 1px solid #E5E7EB;
            border-radius: 8px;
            padding: 15px 16px;
            min-height: 112px;
        }}
        .bn-metric.soft-green {{ background: #EFDFF0; }}
        .bn-metric.soft-blue {{ background: #EAF4FC; }}
        .bn-metric.soft-sage {{ background: #E9F3EA; }}
        .bn-metric.soft-cream {{ background: #F8EEE1; }}
        .bn-metric.soft-cyan {{ background: #CDEEF7; }}
        .bn-label {{
            color: #68707C;
            font-size: 11px;
            text-transform: uppercase;
            font-weight: 600;
        }}
        .bn-value {{
            color: var(--bn-ink);
            font-size: 24px;
            font-weight: 700;
            margin-top: 8px;
        }}
        .bn-trend {{
            font-size: 12px;
            margin-top: 8px;
            color: {SUCCESS};
        }}
        .bn-chip {{
            display: inline-block;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 600;
            margin: 2px 4px 2px 0;
            background: #F3F4F6;
            color: #111827;
        }}
        .bn-chip.primary {{ background: #F9D7E5; color: #7C1D45; }}
        .bn-chip.success {{ background: #E2F6E8; color: #246B3D; }}
        .bn-chip.warning {{ background: #FFF1C7; color: #7A5300; }}
        .bn-chip.danger {{ background: #FDE2E2; color: #8A2020; }}
        .bn-gauge {{
            width: 156px;
            height: 156px;
            border-radius: 50%;
            display: grid;
            place-items: center;
            margin: 4px auto 12px;
            background: conic-gradient({PRIMARY} var(--score), #ECEEF2 0);
        }}
        .bn-gauge-inner {{
            width: 112px;
            height: 112px;
            border-radius: 50%;
            background: white;
            display: grid;
            place-items: center;
            text-align: center;
        }}
        .bn-gauge-value {{
            font-size: 30px;
            font-weight: 800;
        }}
        .bn-next {{
            border-left: 4px solid {PRIMARY};
            background: #FFFFFF;
            border-radius: 8px;
            padding: 14px 16px;
            border-top: 1px solid #E5E7EB;
            border-right: 1px solid #E5E7EB;
            border-bottom: 1px solid #E5E7EB;
        }}
        .stTabs [data-baseweb="tab-list"] {{
            gap: 18px;
            border-bottom: 1px solid #D1D5DB;
        }}
        .stTabs [data-baseweb="tab"] {{
            background: transparent;
            padding-left: 0;
            padding-right: 0;
            color: #6B7280;
            font-weight: 600;
        }}
        .stTabs [aria-selected="true"] {{
            color: #060808;
            border-bottom: 3px solid {PRIMARY};
        }}
        div[data-testid="stDataFrame"] {{
            border: 1px solid #E5E7EB;
            border-radius: 8px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_shell_header(data: dict[str, Any]) -> None:
    st.markdown(
        f"""
        <div class="bn-header">
            <div class="bn-logo">BUSINESS<br>NEXT</div>
            <div class="bn-search">Search deal insights, risks, objections, financial evidence</div>
            <div class="bn-header-meta">
                <span>{_escape(data["deal_id"])}</span>
                <span>{_escape(data["deal_health"])}</span>
                <span>{_escape(data["generated_at"][:10])}</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_executive_overview(data: dict[str, Any]) -> None:
    k1, k2, k3, k4, k5 = st.columns(5)
    metric_card(k1, "Deal Score", f"{data['score']:.0f}/100", data["deal_health"], "soft-green")
    metric_card(k2, "Customer Sentiment", _title(data["sentiment"]), f"{data['confidence'] * 100:.0f}% confidence", "soft-blue")
    metric_card(k3, "Risks", str(len(data["risks"])), "Open risk signals", "soft-cream")
    metric_card(k4, "Objections", str(len(data["objections"])), "Detected in call", "soft-cyan")
    metric_card(k5, "Next Step", _short(data["next_best_action"], 28), "Action required", "")

    left, right = st.columns([1.15, 1])
    with left:
        card_start("Executive Summary")
        executive = data["executive"]
        st.write(executive.get("summary", "No executive summary is available."))
        st.markdown(chip(data["deal_health"], "primary"), unsafe_allow_html=True)
        st.markdown(chip(f"Confidence {data['confidence'] * 100:.0f}%", "success" if data["confidence"] >= 0.6 else "warning"), unsafe_allow_html=True)
        buyer_need = executive.get("buyer_need", {})
        st.markdown("**Buyer need**")
        st.write(buyer_need.get("text", "insufficient_evidence"))
        card_end()

    with right:
        card_start("Deal Score")
        score = max(0, min(100, data["score"]))
        st.markdown(
            f"""
            <div class="bn-gauge" style="--score:{score}%;">
                <div class="bn-gauge-inner">
                    <div>
                        <div class="bn-gauge-value">{score:.0f}</div>
                        <div class="bn-muted">out of 100</div>
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(f"<div class='bn-next'><b>Next best action</b><br>{_escape(data['next_best_action'])}</div>", unsafe_allow_html=True)
        card_end()

    st.markdown("<div class='bn-section-title'>Key Moments</div>", unsafe_allow_html=True)
    moments = _ensure_list(data["executive"].get("key_moments", []))
    if moments:
        cols = st.columns(min(3, len(moments)))
        for idx, moment in enumerate(moments[:3]):
            with cols[idx % len(cols)]:
                card_start(str(moment.get("type", "Moment")))
                st.write(moment.get("summary", ""))
                st.caption(_timestamp(moment))
                card_end()
    else:
        st.info("No key moments were grounded in the transcript.")


def render_financials(data: dict[str, Any]) -> None:
    financial = data["financial"]
    budget = financial.get("client_budget", {})
    pricing = financial.get("proposed_pricing", {})
    roi = financial.get("roi_discussion", {})
    implementation = financial.get("implementation_plan", {})
    commercial_risks = _ensure_list(financial.get("commercial_risks", []))

    cols = st.columns(5)
    metric_card(cols[0], "Client Budget", _amount_or_status(budget), _status_label(budget), "soft-cream")
    metric_card(cols[1], "Proposed Cost", _amount_or_status(pricing), _status_label(pricing), "soft-blue")
    metric_card(cols[2], "ROI Discussed", "Yes" if roi.get("status") == "supported_by_transcript" else "No", _status_label(roi), "soft-green")
    metric_card(cols[3], "Commercial Risk", str(len(commercial_risks)), "Evidence-backed", "soft-cyan")
    metric_card(cols[4], "Implementation", "Discussed" if implementation.get("status") == "supported_by_transcript" else "Missing", _status_label(implementation), "")

    chart_left, chart_right = st.columns([1, 1])
    with chart_left:
        chart_card_start("Financial Evidence By Topic")
        matrix = _ensure_list(financial.get("evidence_matrix", []))
        if matrix:
            counts = Counter(str(item.get("topic", "unknown")).replace("_", " ").title() for item in matrix)
            chart_df = pd.DataFrame({"Topic": list(counts.keys()), "Evidence": list(counts.values())})
            bar_chart(chart_df, "Topic", "Evidence", color=PRIMARY)
        else:
            st.info("No budget, pricing, ROI, or implementation evidence was detected.")
        card_end()

    with chart_right:
        chart_card_start("Financial Discussion Timeline")
        matrix = _ensure_list(financial.get("evidence_matrix", []))
        if matrix:
            timeline = pd.DataFrame(
                {
                    "Minute": [round(float(item.get("start", 0)) / 60, 1) for item in matrix],
                    "Topic": [str(item.get("topic", "unknown")).replace("_", " ").title() for item in matrix],
                    "Confidence": [_number(item.get("confidence", 0)) for item in matrix],
                }
            )
            point_chart(timeline, "Minute", "Confidence", "Topic")
        else:
            st.info("Financial timeline is empty because no grounded financial evidence was found.")
        card_end()

    st.markdown("<div class='bn-section-title'>Evidence Matrix</div>", unsafe_allow_html=True)
    matrix_rows = [
        {
            "Topic": str(item.get("topic", "")).replace("_", " ").title(),
            "Amounts": ", ".join(str(amount) for amount in item.get("amounts", [])),
            "Speaker": item.get("speaker", ""),
            "Time": _timestamp(item),
            "Confidence": item.get("confidence", ""),
            "Status": item.get("status", ""),
            "Quote": item.get("quote", item.get("summary", "")),
        }
        for item in _ensure_list(financial.get("evidence_matrix", []))
    ]
    if matrix_rows:
        st.dataframe(pd.DataFrame(matrix_rows), use_container_width=True, hide_index=True, height=340)
    else:
        st.info("No financial evidence matrix is available for this conversation.")


def render_conversation(data: dict[str, Any]) -> None:
    metrics = data["speaker_metrics"]
    segments = data["segments"]
    dims = data["dimensions"]
    topics = _topic_chips(segments, dims)

    c1, c2, c3, c4 = st.columns(4)
    questions = sum(str(item.get("text", "")).count("?") for item in segments)
    metric_card(c1, "Questions Asked", str(questions), "Across transcript", "soft-blue")
    metric_card(c2, "Speakers", str(len({item.get("speaker") for item in segments if item.get("speaker")})), "Detected roles", "soft-green")
    metric_card(c3, "Key Topics", str(len(topics)), "Transcript themes", "soft-cream")
    metric_card(c4, "Segments", str(len(segments)), "Transcript turns", "")

    left, right = st.columns([1, 1])
    with left:
        chart_card_start("Talk Ratio")
        if metrics:
            talk_df = pd.DataFrame(
                {
                    "Role": [str(item.get("role", item.get("speaker", "unknown"))).replace("_", " ").title() for item in metrics],
                    "Talk %": [_number(item.get("talk_time_pct", item.get("Talk %", 0))) for item in metrics],
                }
            )
            bar_chart(talk_df, "Role", "Talk %", color=BLUE)
        else:
            st.info("Speaker metrics are not available.")
        card_end()

    with right:
        chart_card_start("Sentiment Timeline")
        timeline_rows = [
            {
                "Turn": idx + 1,
                "Sentiment Score": _number(item.get("sentiment_score", 0)),
                "Role": str(item.get("role", item.get("speaker", "unknown"))).replace("_", " ").title(),
            }
            for idx, item in enumerate(segments)
        ]
        if timeline_rows:
            line_chart(pd.DataFrame(timeline_rows), "Turn", "Sentiment Score", "Role")
        else:
            st.info("Sentiment timeline is not available.")
        card_end()

    card_start("Key Topics")
    if topics:
        st.markdown(" ".join(chip(topic, "primary" if idx == 0 else "") for idx, topic in enumerate(topics[:16])), unsafe_allow_html=True)
    else:
        st.info("No key topics were available.")
    card_end()

    st.markdown("<div class='bn-section-title'>Transcript Drill-down</div>", unsafe_allow_html=True)
    transcript_rows = [
        {
            "Time": _timestamp(item),
            "Speaker": item.get("speaker", ""),
            "Role": item.get("role", ""),
            "Sentiment": item.get("sentiment", ""),
            "Text": item.get("text", ""),
        }
        for item in segments
    ]
    if transcript_rows:
        st.dataframe(pd.DataFrame(transcript_rows), use_container_width=True, hide_index=True, height=420)
    else:
        st.info("Transcript segments are not available.")


def render_risks_and_coaching(data: dict[str, Any]) -> None:
    sales = data["sales"]
    c1, c2, c3, c4 = st.columns(4)
    metric_card(c1, "Sales Score", f"{_number(sales.get('overall_score', 0)):.0f}/100", "Manager coaching", "soft-green")
    metric_card(c2, "Discovery Quality", f"{_number(sales.get('discovery_quality', 0)):.0f}%", "Qualification coverage", "soft-blue")
    metric_card(c3, "Objection Handling", f"{_number(sales.get('objection_handling', 0)):.0f}%", "Response quality", "soft-cream")
    metric_card(c4, "Closing", f"{_number(sales.get('closing_effectiveness', 0)):.0f}%", "Next-step clarity", "")

    left, right = st.columns([1, 1])
    with left:
        chart_card_start("Risk Categories")
        risks = data["risks"]
        if risks:
            counts = Counter(str(item.get("category", item.get("type", "general"))).title() for item in risks)
            bar_chart(pd.DataFrame({"Category": list(counts.keys()), "Count": list(counts.values())}), "Category", "Count", DANGER)
        else:
            st.success("No risks detected.")
        card_end()

    with right:
        chart_card_start("Objection Categories")
        objections = data["objections"]
        if objections:
            counts = Counter(str(item.get("type", "general")).title() for item in objections)
            bar_chart(pd.DataFrame({"Type": list(counts.keys()), "Count": list(counts.values())}), "Type", "Count", WARNING)
        else:
            st.success("No objections detected.")
        card_end()

    sc1, sc2 = st.columns(2)
    with sc1:
        card_start("Strengths")
        for item in _ensure_list(sales.get("strengths", [])):
            st.markdown(f"- {item}")
        card_end()
    with sc2:
        card_start("Weaknesses")
        for item in _ensure_list(sales.get("weaknesses", [])):
            st.markdown(f"- {item}")
        card_end()

    card_start("Recommended Coaching Actions")
    for item in _ensure_list(sales.get("coaching_actions", [])):
        st.markdown(f"- {item}")
    card_end()

    rows = []
    for item in data["risks"]:
        rows.append({"Type": "Risk", "Category": item.get("category", ""), "Severity": item.get("severity", ""), "Summary": item.get("summary", "")})
    for item in data["objections"]:
        rows.append({"Type": "Objection", "Category": item.get("type", ""), "Severity": item.get("severity", ""), "Summary": item.get("summary", "")})
    if rows:
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True, height=320)


def render_actions_and_export(data: dict[str, Any], payload: dict[str, Any], *, workflow: dict[str, Any] | None) -> None:
    left, right = st.columns([1, 1])
    with left:
        card_start("Follow-up Email")
        follow = data["follow_up"]
        st.text_input("Subject", value=str(follow.get("subject", "")), key="businessnext_follow_subject")
        st.text_area("Body", value=str(follow.get("body", "")), height=260, key="businessnext_follow_body")
        if follow.get("suggested_send_window"):
            st.caption(f"Suggested send window: {follow['suggested_send_window']}")
        card_end()

    with right:
        card_start("Refined Pitch")
        st.write(data["refined_pitch"] or "No refined pitch is available.")
        st.markdown("<div class='bn-section-title'>Next Best Action</div>", unsafe_allow_html=True)
        st.write(data["next_best_action"])
        card_end()

    st.markdown("<div class='bn-section-title'>Evidence & Export</div>", unsafe_allow_html=True)
    export_tabs = st.tabs(["Artifacts", "Visual & Scene", "Raw JSON", "n8n Workflow"])
    with export_tabs[0]:
        artifacts = data["artifacts"]
        if artifacts:
            cols = st.columns(3)
            for index, key in enumerate(["json", "txt", "vtt"]):
                artifact_value = artifacts.get(key)
                path = Path(artifact_value) if artifact_value else None
                if path and path.exists() and path.is_file():
                    cols[index].download_button(
                        f"Download transcript {key.upper()}",
                        data=path.read_text(encoding="utf-8"),
                        file_name=path.name,
                        mime="application/json" if key == "json" else "text/plain",
                    )
        else:
            st.info("No transcript artifacts are available.")
    with export_tabs[1]:
        visual = data["visual"]
        scene = data["scene"]
        st.write(f"Visual status: {visual.get('status', 'unknown')}")
        if visual.get("objects"):
            st.dataframe(pd.DataFrame(visual.get("objects", [])), use_container_width=True)
        package = scene.get("knowledge_package", []) if isinstance(scene, dict) else []
        if package:
            st.dataframe(pd.DataFrame(package), use_container_width=True)
        else:
            st.caption("No scene intelligence package is available.")
    with export_tabs[2]:
        st.download_button(
            "Download Deal Intelligence JSON",
            data=json.dumps(payload, indent=2),
            file_name=f"{data['deal_id']}_deal_intelligence.json",
            mime="application/json",
        )
        st.json(payload)
    with export_tabs[3]:
        if workflow:
            st.download_button(
                "Download n8n Workflow JSON",
                data=json.dumps(workflow, indent=2),
                file_name="dealintel_n8n_workflow.json",
                mime="application/json",
            )
            st.json(workflow)
        else:
            st.info("No n8n workflow was provided.")


def metric_card(target: Any, label: str, value: str, trend: str = "", variant: str = "") -> None:
    target.markdown(
        f"""
        <div class="bn-metric {variant}">
            <div class="bn-label">{_escape(label)}</div>
            <div class="bn-value">{_escape(value)}</div>
            <div class="bn-trend">{_escape(trend)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def card_start(title: str) -> None:
    st.markdown(f"<div class='bn-card'><div class='bn-card-title'>{_escape(title)}</div>", unsafe_allow_html=True)


def chart_card_start(title: str) -> None:
    card_start(title)


def card_end() -> None:
    st.markdown("</div>", unsafe_allow_html=True)


def bar_chart(df: pd.DataFrame, x: str, y: str, color: str) -> None:
    if alt is not None:
        chart = (
            alt.Chart(df)
            .mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3, color=color)
            .encode(x=alt.X(x, sort=None), y=y, tooltip=list(df.columns))
            .properties(height=260)
        )
        st.altair_chart(chart, use_container_width=True)
    else:
        st.bar_chart(df.set_index(x)[y])


def line_chart(df: pd.DataFrame, x: str, y: str, color: str) -> None:
    if alt is not None:
        chart = (
            alt.Chart(df)
            .mark_line(point=True, color=PRIMARY)
            .encode(x=x, y=y, color=color, tooltip=list(df.columns))
            .properties(height=260)
        )
        st.altair_chart(chart, use_container_width=True)
    else:
        st.line_chart(df, x=x, y=y)


def point_chart(df: pd.DataFrame, x: str, y: str, color: str) -> None:
    if alt is not None:
        chart = (
            alt.Chart(df)
            .mark_circle(size=90)
            .encode(x=x, y=y, color=color, tooltip=list(df.columns))
            .properties(height=260)
        )
        st.altair_chart(chart, use_container_width=True)
    else:
        st.scatter_chart(df, x=x, y=y)


def chip(text: str, variant: str = "") -> str:
    return f"<span class='bn-chip {variant}'>{_escape(text)}</span>"


def _empty_financial() -> dict[str, Any]:
    missing = {
        "status": "insufficient_evidence",
        "summary": "insufficient_evidence",
        "amounts": [],
        "evidence": [],
    }
    return {
        "client_budget": {"name": "client_budget", **missing},
        "proposed_pricing": {"name": "proposed_pricing", **missing},
        "roi_discussion": {"name": "roi_discussion", **missing},
        "commercial_risks": [],
        "implementation_plan": {"name": "implementation_plan", **missing},
        "evidence_matrix": [],
        "status": "insufficient_evidence",
        "summary": "No grounded financial intelligence is available for this payload.",
    }


def _fallback_sales(payload: dict[str, Any]) -> dict[str, Any]:
    raw = payload.get("sales_performance", {}) if isinstance(payload.get("sales_performance"), dict) else {}
    return {
        "overall_score": _number(raw.get("overall_score", 0)),
        "discovery_quality": _number(raw.get("technique_rating", 0)),
        "objection_handling": 0,
        "closing_effectiveness": _number(raw.get("closing_effectiveness", 0)),
        "strengths": _ensure_list(raw.get("strengths", [])),
        "weaknesses": _ensure_list(raw.get("weaknesses", [])),
        "coaching_actions": _ensure_list(raw.get("coaching_tips", [])),
        "status": "supported_by_analysis" if raw else "insufficient_evidence",
    }


def _fallback_executive(
    payload: dict[str, Any],
    score: float,
    risks: list[dict[str, Any]],
    objections: list[dict[str, Any]],
    recommendations: list[dict[str, Any]],
) -> dict[str, Any]:
    next_action = ""
    if recommendations:
        next_action = str(recommendations[0].get("action", recommendations[0].get("next_best_action", "")))
    return {
        "summary": f"Deal score is {score:.0f}/100 with {len(risks)} risk signal(s) and {len(objections)} objection(s). Review evidence before advancing the deal.",
        "buyer_need": {"text": "insufficient_evidence: no executive buyer need summary is available in this payload.", "status": "insufficient_evidence", "evidence": []},
        "deal_state": {"label": _health_label(score, risks, objections), "score": score},
        "decision_context": {},
        "key_moments": [],
        "next_best_action": {"text": next_action or payload.get("n8n", {}).get("next_best_action", "Review the call."), "status": "supported_by_analysis", "evidence": []},
        "confidence": _number(payload.get("analysis_confidence", {}).get("overall", 0)),
    }


def _recommendations(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        return [value]
    return []


def _ensure_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return []


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _health_label(score: float, risks: list[Any], objections: list[Any]) -> str:
    if score >= 70 and not risks:
        return "Healthy"
    if score >= 45:
        return "Developing"
    if risks or objections:
        return "At Risk"
    return "Needs Qualification"


def _status_label(value: dict[str, Any]) -> str:
    return "Grounded evidence" if value.get("status") == "supported_by_transcript" else "Missing evidence"


def _amount_or_status(value: dict[str, Any]) -> str:
    amounts = _ensure_list(value.get("amounts", []))
    return str(amounts[0]) if amounts else ("Found" if value.get("status") == "supported_by_transcript" else "Missing")


def _topic_chips(segments: list[dict[str, Any]], dimensions: list[dict[str, Any]]) -> list[str]:
    supported = [str(item.get("name", item.get("dimension", ""))) for item in dimensions if item.get("status") == "supported_by_transcript" or item.get("score", 0)]
    words = Counter()
    stop = {"this", "that", "with", "have", "need", "what", "when", "your", "about", "there", "their", "would", "could", "should"}
    for segment in segments:
        for raw in str(segment.get("text", "")).lower().replace(",", " ").replace(".", " ").split():
            word = raw.strip("?:;!()[]")
            if len(word) > 4 and word not in stop:
                words[word] += 1
    inferred = [word.title() for word, _count in words.most_common(8)]
    return [item for item in supported + inferred if item][:16]


def _timestamp(item: dict[str, Any]) -> str:
    start = item.get("start")
    if start is None:
        return ""
    seconds = int(_number(start))
    return f"{seconds // 60:02d}:{seconds % 60:02d}"


def _short(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "..."


def _title(text: str) -> str:
    return text.replace("_", " ").title()


def _escape(value: Any) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )
