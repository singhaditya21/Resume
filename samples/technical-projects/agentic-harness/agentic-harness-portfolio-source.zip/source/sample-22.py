"""Create the Deal Intelligence n8n AI pipeline with Parakeet video transcription and diarization support.

Flow:
  Transcript webhook/manual sample -> embedding -> Milvus -> AI Agent -> result
  Video webhook -> async response -> Parakeet ASR + pyannote -> same AI path
  Status webhook -> reads /files/jobs/<job_id>/status.json/result.json
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / ".env"
if ENV_PATH.exists():
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip())

BASE = "http://localhost:5678/api/v1"
API_KEY = os.environ.get("N8N_API_KEY", "")
NVIDIA_CHAT_KEY = os.environ.get("NVIDIA_API_KEY", "")
NVIDIA_EMBED_KEY = os.environ.get("NVIDIA_EMBED_KEY") or NVIDIA_CHAT_KEY


def api(method: str, path: str, data: dict | None = None) -> dict | None:
    url = f"{BASE}/{path}"
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-N8N-API-KEY": API_KEY,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        print(f"HTTP {exc.code}: {exc.read().decode('utf-8', errors='replace')[:1000]}")
        return None


def create_or_find_chat_credential() -> str | None:
    if not NVIDIA_CHAT_KEY:
        print("WARNING: NVIDIA_API_KEY is not set; AI Agent credential cannot be created.")
        return None

    creds = api("GET", "credentials") or {}
    for credential in creds.get("data", []):
        if credential.get("name") == "NVIDIA NIM Chat API":
            return str(credential["id"])

    created = api(
        "POST",
        "credentials",
        {
            "name": "NVIDIA NIM Chat API",
            "type": "openAiApi",
            "data": {
                "apiKey": NVIDIA_CHAT_KEY,
                "headerName": "Authorization",
                "headerValue": f"Bearer {NVIDIA_CHAT_KEY}",
            },
        },
    )
    if created and created.get("id"):
        return str(created["id"])

    return None


def create_or_find_embedding_credential() -> str | None:
    if not NVIDIA_EMBED_KEY:
        print("WARNING: NVIDIA_EMBED_KEY/NVIDIA_API_KEY is not set; embedding credential cannot be created.")
        return None

    creds = api("GET", "credentials") or {}
    for credential in creds.get("data", []):
        if credential.get("name") == "NVIDIA Embeddings API":
            return str(credential["id"])

    created = api(
        "POST",
        "credentials",
        {
            "name": "NVIDIA Embeddings API",
            "type": "httpHeaderAuth",
            "data": {
                "name": "Authorization",
                "value": f"Bearer {NVIDIA_EMBED_KEY}",
            },
        },
    )
    if created and created.get("id"):
        return str(created["id"])

    return None


def find_workflow_by_name(name: str) -> dict | None:
    workflows = api("GET", "workflows") or {}
    for workflow in workflows.get("data", []):
        if workflow.get("name") == name:
            return workflow
    return None


def get_workflow(workflow_id: str) -> dict | None:
    return api("GET", f"workflows/{workflow_id}")


def save_workflow(workflow: dict) -> dict | None:
    existing = find_workflow_by_name(workflow["name"])
    if not existing:
        print(f"Creating workflow: {workflow['name']}")
        return api("POST", "workflows", workflow)

    workflow_id = existing["id"]
    payload = {
        "name": workflow["name"],
        "nodes": workflow["nodes"],
        "connections": workflow["connections"],
        "settings": workflow.get("settings", {}),
    }

    print(f"Updating existing workflow: {workflow['name']} ({workflow_id})")
    updated = api("PUT", f"workflows/{workflow_id}", payload)
    if updated:
        return updated

    print("PUT update failed; trying PATCH without deleting any workflow.")
    return api("PATCH", f"workflows/{workflow_id}", payload)


def node(
    *,
    node_id: str,
    name: str,
    type_: str,
    position: list[int],
    parameters: dict | None = None,
    type_version: float | int = 1,
    credentials: dict | None = None,
    notes: str | None = None,
    on_error: str | None = None,
) -> dict:
    payload = {
        "id": node_id,
        "name": name,
        "type": type_,
        "typeVersion": type_version,
        "position": position,
        "parameters": parameters or {},
    }
    if credentials:
        payload["credentials"] = credentials
    if notes:
        payload["notes"] = notes
    if on_error:
        payload["onError"] = on_error
    return payload


def manual_sample_code() -> str:
    return r"""return [{
  json: {
    deal_id: 'manual-test-deal',
    transcript: `Agent: Good afternoon. What timeline are you working toward?
Prospect: We need to improve loan document verification this quarter, but budget and approval are concerns.
Agent: We can start with two branches, measure turnaround time, and build an expansion plan.`,
  },
}];"""


def normalize_transcript_code() -> str:
    return r"""const input = items[0].json ?? {};
const body = input.body ?? input;
return [{
  json: {
    deal_id: body.deal_id ?? body.dealId ?? 'transcript-deal',
    transcript: body.transcript ?? body.segments ?? body,
    transcript_artifacts: body.transcript_artifacts ?? {},
    trigger_source: 'transcript',
  },
}];"""


def prepare_video_job_code() -> str:
    return r"""const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function env(name, fallback = '') {
  try {
    if (typeof $env !== 'undefined' && $env && $env[name] !== undefined && $env[name] !== null) {
      return String($env[name]);
    }
  } catch (e) {}
  return fallback;
}

function safeId(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'job';
}

const item = items[0];
const body = item.json?.body ?? item.json ?? {};
const headers = item.json?.headers ?? {};
const expectedToken = env('DEALINTEL_WEBHOOK_TOKEN');
const suppliedToken = headers['x-dealintel-token'] || headers['X-DealIntel-Token'] || body.token || '';
if (expectedToken && suppliedToken !== expectedToken) {
  throw new Error('Unauthorized video webhook request.');
}

const jobsRoot = env('DEALINTEL_JOBS_ROOT', '/files/jobs') || '/files/jobs';
const jobId = safeId(body.job_id || body.jobId || crypto.randomUUID());
const dealId = safeId(body.deal_id || body.dealId || jobId);
const jobDir = path.join(jobsRoot, jobId);
fs.mkdirSync(jobDir, { recursive: true });

const allowed = new Set(['.mp4', '.mov', '.mkv', '.mp3', '.wav', '.m4a', '.webm']);
let sourcePath = body.source_path || body.sourcePath || null;
let sourceUrl = body.video_url || body.videoUrl || body.source_url || body.sourceUrl || null;

if (sourcePath) {
  const filesRoot = path.resolve(env('DEALINTEL_FILES_ROOT', '/files') || '/files');
  const resolvedSourcePath = path.resolve(String(sourcePath));
  if (resolvedSourcePath !== filesRoot && !resolvedSourcePath.startsWith(filesRoot + path.sep)) {
    throw new Error(`source_path must be under ${filesRoot}.`);
  }
  const ext = path.extname(resolvedSourcePath).toLowerCase();
  if (!allowed.has(ext)) {
    throw new Error(`Unsupported video extension: ${ext}`);
  }
  if (!fs.existsSync(resolvedSourcePath)) {
    throw new Error(`source_path does not exist: ${resolvedSourcePath}`);
  }
  sourcePath = resolvedSourcePath;
}

const binary = item.binary || {};
const binaryKey = body.binary_key || body.binaryKey || Object.keys(binary)[0];
if (!sourcePath && binaryKey) {
  const meta = binary[binaryKey] || {};
  const originalName = meta.fileName || meta.file_name || 'source.mp4';
  const ext = (path.extname(originalName).toLowerCase() || '.mp4');
  if (!allowed.has(ext)) {
    throw new Error(`Unsupported video extension: ${ext}`);
  }
  const buffer = await this.helpers.getBinaryDataBuffer(0, binaryKey);
  const maxMb = Number(env('MAX_VIDEO_MB', '500') || 500);
  if (buffer.length > maxMb * 1024 * 1024) {
    throw new Error(`Video is larger than MAX_VIDEO_MB=${maxMb}.`);
  }
  sourcePath = path.join(jobDir, `source${ext}`);
  fs.writeFileSync(sourcePath, buffer);
}

if (!sourcePath && !sourceUrl) {
  throw new Error('Provide a multipart video file or JSON video_url.');
}

const now = new Date().toISOString();
const statusUrlBase = (env('WEBHOOK_URL', 'http://localhost:5678/') || 'http://localhost:5678/').replace(/\/$/, '');
const metadata = {
  job_id: jobId,
  deal_id: dealId,
  source_path: sourcePath,
  source_url: sourceUrl,
  created_at: now,
};
const status = {
  job_id: jobId,
  deal_id: dealId,
  status: 'queued',
  stage: 'queued',
  updated_at: now,
};
fs.writeFileSync(path.join(jobDir, 'job.json'), JSON.stringify(metadata, null, 2));
fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify(status, null, 2));

return [{
  json: {
    ...status,
    job_dir: jobDir,
    source_path: sourcePath,
    source_url: sourceUrl,
    status_url: `${statusUrlBase}/webhook/deal-video-status?job_id=${jobId}`,
  },
}];"""


def parse_video_transcript_code() -> str:
    return r"""const stdout = String(items[0].json.stdout || '').trim();
const lines = stdout.split(/\r?\n/).filter(Boolean);
let parsed = null;
for (let i = lines.length - 1; i >= 0; i--) {
  try {
    parsed = JSON.parse(lines[i]);
    break;
  } catch (e) {}
}
if (!parsed) {
  throw new Error(`Video processor did not return JSON. stdout=${stdout.slice(0, 500)}`);
}
if (parsed.status === 'failed') {
  throw new Error(parsed.error?.message || 'Video processing failed.');
}
return [{
  json: {
    job_id: parsed.job_id,
    deal_id: parsed.deal_id,
    transcript: parsed.transcript?.segments ?? [],
    transcript_text: parsed.transcript_text ?? '',
    transcript_artifacts: parsed.transcript_artifacts ?? {},
    diarization: parsed.diarization ?? {},
    asr: parsed.asr ?? {},
    baseline_analysis: parsed.baseline_analysis ?? {},
    trigger_source: 'video',
  },
}];"""


def prepare_embedding_code() -> str:
    return r"""const input = items[0].json ?? {};
const fs = require('fs');
const path = require('path');
const raw = input.transcript?.segments ?? input.transcript ?? input.transcript_text ?? '';
const dealId = input.deal_id || 'DEAL-UNKNOWN';

let transcript = '';
let transcriptSegments = [];
if (typeof raw === 'string') {
  transcript = raw;
} else if (Array.isArray(raw)) {
  transcriptSegments = raw;
  transcript = raw.map((entry) => {
    if (typeof entry === 'string') return entry;
    const start = entry.start ?? entry.timestamp ?? '';
    const end = entry.end ?? '';
    const speaker = entry.speaker ?? '';
    const role = entry.role ?? '';
    const text = entry.text ?? JSON.stringify(entry);
    return `[${start}-${end}] ${speaker}/${role}: ${text}`;
  }).join('\n');
} else {
  transcript = JSON.stringify(raw);
}

if (!transcript.trim()) {
  throw new Error('Transcript text is required before embedding.');
}

if (input.job_id) {
  const jobDir = path.join('/files/jobs', input.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: input.job_id,
    deal_id: dealId,
    status: 'analyzing',
    stage: 'embedding',
    updated_at: new Date().toISOString(),
  }, null, 2));
}

return [{
  json: {
    job_id: input.job_id,
    deal_id: dealId,
    trigger_source: input.trigger_source ?? 'transcript',
    transcript_text: transcript,
    transcript_segments: transcriptSegments,
    transcript_artifacts: input.transcript_artifacts ?? {},
    diarization: input.diarization ?? {},
    baseline_analysis: input.baseline_analysis ?? {},
    embedding_request: {
    model: 'REDACTED_OPAQUE_VALUE',
    input: [transcript.substring(0, 8000)],
    input_type: 'query',
    encoding_format: 'float',
    },
  },
}];"""


def generate_embedding_code() -> str:
    return r"""const source = $node['4a. Prepare Embedding Input'].json;
const response = items[0].json ?? {};

const embedding = response.data?.[0]?.embedding ?? [];
if (!embedding.length) {
  throw new Error(`Embedding response did not contain an embedding vector: ${JSON.stringify(response).slice(0, 500)}`);
}
return [{
  json: {
    job_id: source.job_id,
    deal_id: source.deal_id,
    trigger_source: source.trigger_source ?? 'transcript',
    embedding,
    embedding_model: 'REDACTED_OPAQUE_VALUE',
    embedding_dim: embedding.length,
    transcript_text: source.transcript_text,
    transcript_segments: source.transcript_segments ?? [],
    transcript_artifacts: source.transcript_artifacts ?? {},
    diarization: source.diarization ?? {},
    baseline_analysis: source.baseline_analysis ?? {},
    generated_at: new Date().toISOString(),
  },
}];"""


def store_milvus_code() -> str:
    return r"""const embedData = $node['4. Generate Embedding'].json;
const fs = require('fs');
const path = require('path');
const vector = embedData.embedding || [];
const dealId = embedData.deal_id;
const preview = embedData.transcript_text?.substring(0, 500) || '';
const milvusUrl = 'https://example.invalid';
if (embedData.job_id) {
  const jobDir = path.join('/files/jobs', embedData.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: embedData.job_id,
    deal_id: dealId,
    status: 'analyzing',
    stage: 'vector_store',
    updated_at: new Date().toISOString(),
  }, null, 2));
}

try {
  await this.helpers.httpRequest({
    method: 'POST',
    url: `${milvusUrl}/v2/vectordb/collections/create`,
    headers: { 'Content-Type': 'application/json' },
    body: { collectionName: 'deal_intelligence', dimension: vector.length || 2048, metricType: 'COSINE' },
    json: true,
    timeout: 10000,
  });
} catch(e) {}

const numericId = Date.now();
let insertResult = { code: 0 };
try {
  insertResult = await this.helpers.httpRequest({
    method: 'POST',
    url: `${milvusUrl}/v2/vectordb/entities/insert`,
    headers: { 'Content-Type': 'application/json' },
    body: {
      collectionName: 'deal_intelligence',
      data: [{
        id: numericId,
        vector,
        deal_id: dealId,
        transcript_preview: preview,
        trigger_source: embedData.trigger_source,
        stored_at: new Date().toISOString(),
      }],
    },
    json: true,
    timeout: 15000,
  });
} catch(e) {
  insertResult = { code: 1, error: e.message };
}

return [{ json: { ...embedData, milvus_id: numericId, vector_stored: vector.length > 0, insert_result: insertResult } }];"""


def search_milvus_code() -> str:
    return r"""const embedData = $node['4. Generate Embedding'].json;
const fs = require('fs');
const path = require('path');
const vector = embedData.embedding || [];
const milvusUrl = 'https://example.invalid';
if (embedData.job_id) {
  const jobDir = path.join('/files/jobs', embedData.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: embedData.job_id,
    deal_id: embedData.deal_id,
    status: 'analyzing',
    stage: 'vector_search',
    updated_at: new Date().toISOString(),
  }, null, 2));
}
let searchResults = [];
try {
  if (vector.length > 0) {
    const response = await this.helpers.httpRequest({
      method: 'POST',
      url: `${milvusUrl}/v2/vectordb/entities/search`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        collectionName: 'deal_intelligence',
        data: [vector],
        limit: 5,
        outputFields: ['id', 'deal_id', 'transcript_preview'],
      },
      json: true,
      timeout: 15000,
    });
    searchResults = response.data || [];
  }
} catch(e) {}
return [{ json: { ...embedData, similar_deals: searchResults, similar_deals_count: searchResults.length } }];"""


def mark_ai_analysis_code() -> str:
    return r"""const fs = require('fs');
const path = require('path');
const item = items[0].json ?? {};
if (item.job_id) {
  const jobDir = path.join('/files/jobs', item.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: item.job_id,
    deal_id: item.deal_id,
    status: 'analyzing',
    stage: 'ai_analysis',
    updated_at: new Date().toISOString(),
  }, null, 2));
}
return items;"""


SYSTEM_PROMPT = (
    "You are an expert sales conversation intelligence analyst. You analyze diarized sales call "
    "transcripts to extract actionable deal intelligence. Return strict JSON only. Use evidence "
    "from the transcript and do not invent facts."
)

def build_ai_analysis_prompt_code() -> str:
    return r"""const item = items[0].json ?? {};
const transcript = String(item.transcript_text || '');
const baseline = item.baseline_analysis ?? {};
function excerpt(text) {
  const max = 30000;
  if (text.length <= max) return text;
  const head = text.slice(0, 12000);
  const middleStart = Math.max(0, Math.floor(text.length / 2) - 3000);
  const middle = text.slice(middleStart, middleStart + 6000);
  const tail = text.slice(-12000);
  return `${head}\n\n[... middle excerpt ...]\n${middle}\n\n[... final excerpt ...]\n${tail}`;
}

const prompt = `Analyze this diarized sales call transcript and produce a comprehensive deal intelligence report.

Use the transcript evidence. Do not return empty arrays or zero metrics unless the transcript genuinely has no evidence.
Use baseline metrics as guardrails; if you disagree, explain through evidence in the relevant JSON fields.

=== BASELINE METRICS ===
${JSON.stringify(baseline, null, 2).slice(0, 12000)}

=== TRANSCRIPT ===
${excerpt(transcript)}
=== END TRANSCRIPT ===

Produce STRICT JSON with these exact top-level keys:
conversation_intelligence, risks, objections, sales_performance, sentiment_analysis, deal_score, recommendations, refined_pitch, follow_up.

Required shapes:
- conversation_intelligence: {key_topics: string[], talk_ratio: {agent: number, prospect: number}, engagement_score: number, questions_asked: number, key_moments: string[]}
- risks: [{category, severity, summary, evidence}]
- objections: [{type, severity, summary, evidence}]
- sales_performance: {overall_score, strengths, weaknesses, technique_rating, closing_effectiveness}
- sentiment_analysis: {prospect: {sentiment, confidence, trend}, agent: {sentiment, confidence, trend}}
- deal_score: number 0-100
- recommendations: {next_best_action, priority, timeline, reasoning, coaching_tips}
- refined_pitch: string
- follow_up: {subject, body, timing, channel}

Every risk, objection, recommendation, and key moment must cite an exact quote or segment id in its text/evidence.
Return only valid JSON.`;

return [{ json: { ...item, analysis_prompt: prompt } }];"""


def score_classify_code() -> str:
    return r"""const raw = items[0].json ?? {};
const fs = require('fs');
const path = require('path');
const source = $node['4. Generate Embedding'].json;
const baseline = source.baseline_analysis ?? {};
if (source.job_id) {
  const jobDir = path.join('/files/jobs', source.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: source.job_id,
    deal_id: source.deal_id,
    status: 'analyzing',
    stage: 'scoring',
    updated_at: new Date().toISOString(),
  }, null, 2));
}
let analysis = {};
try {
  const text = raw.output ?? raw.text ?? JSON.stringify(raw);
  const clean = (typeof text === 'string')
    ? text.replace(/^```(?:json)?\n?/g, '').replace(/```\s*$/g, '').replace(/^```(?:json)?\n?/gm, '').trim()
    : JSON.stringify(text);
  analysis = JSON.parse(clean);
} catch(e) {
  analysis = { error: 'Parse failed', raw: String(raw.output ?? '').substring(0, 500) };
}

function hasItems(value) {
  return Array.isArray(value) && value.length > 0;
}
function isEmptyObject(value) {
  return !value || (typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === 0);
}
function isLlmEmpty(candidate) {
  const ci = candidate.conversation_intelligence ?? {};
  return Number(candidate.deal_score ?? 0) === 0
    && !hasItems(candidate.risks)
    && !hasItems(candidate.objections)
    && !hasItems(ci.key_topics)
    && Number(ci.questions_asked ?? 0) === 0
    && isEmptyObject(candidate.follow_up)
    && !candidate.refined_pitch;
}

const hasBaseline = baseline && Object.keys(baseline).length > 0;
const transcriptLength = String(source.transcript_text || '').length;
const useBaseline = hasBaseline && (analysis.error || (transcriptLength > 1000 && isLlmEmpty(analysis)));
if (useBaseline) {
  analysis = {
    ...baseline,
    analysis_warning: analysis.error ? 'llm_parse_failed_used_baseline' : 'llm_empty_output_used_baseline',
    llm_raw: analysis.raw,
  };
} else if (hasBaseline) {
  const baselineCi = baseline.conversation_intelligence ?? {};
  const llmCi = analysis.conversation_intelligence ?? {};
  analysis = {
    ...analysis,
    conversation_intelligence: {
      ...llmCi,
      key_topics: hasItems(llmCi.key_topics) ? llmCi.key_topics : (baselineCi.key_topics ?? []),
      talk_ratio: baselineCi.talk_ratio ?? llmCi.talk_ratio ?? {},
      engagement_score: baselineCi.engagement_score ?? llmCi.engagement_score ?? 0,
      questions_asked: baselineCi.questions_asked ?? llmCi.questions_asked ?? 0,
      key_moments: hasItems(llmCi.key_moments) ? llmCi.key_moments : (baselineCi.key_moments ?? []),
    },
    risks: hasItems(baseline.risks) ? baseline.risks : (analysis.risks ?? []),
    objections: hasItems(baseline.objections) ? baseline.objections : (analysis.objections ?? []),
    sentiment_analysis: baseline.sentiment_analysis ?? analysis.sentiment_analysis ?? {},
    sales_performance: {
      ...(analysis.sales_performance ?? {}),
      overall_score: baseline.sales_performance?.overall_score ?? analysis.sales_performance?.overall_score ?? 0,
    },
    deal_score: baseline.deal_score ?? analysis.deal_score ?? 50,
    recommendations: isEmptyObject(analysis.recommendations) ? (baseline.recommendations ?? {}) : analysis.recommendations,
    analysis_warning: 'numeric_metrics_from_baseline',
  };
}

const dealScore = Number(analysis.deal_score ?? baseline.deal_score ?? 50);
const risks = analysis.risks ?? [];
const objections = analysis.objections ?? [];
const highRisks = risks.filter((risk) => risk.severity === 'high' || risk.severity === 'critical').length;
const severity = dealScore < 35 ? 'critical' : dealScore < 55 ? 'high' : dealScore < 70 ? 'medium' : 'low';
const health = dealScore >= 70 ? 'healthy' : dealScore >= 45 ? 'at_risk' : 'critical';

return [{
  json: {
    job_id: source.job_id,
    deal_id: source.deal_id,
    trigger_source: source.trigger_source,
    transcript_artifacts: source.transcript_artifacts ?? {},
    diarization: source.diarization ?? {},
    analysis,
    classification: {
      deal_score: dealScore,
      severity,
      deal_health: health,
      risk_count: risks.length,
      objection_count: objections.length,
      high_risk_count: highRisks,
    },
    pipeline_stage: 'scored',
  },
}];"""


def dashboard_output_code() -> str:
    return r"""const d = items[0].json;
const a = d.analysis ?? {};
const c = d.classification ?? {};

return [{
  json: {
    job_id: d.job_id,
    deal_id: d.deal_id,
    trigger_source: d.trigger_source,
    deal_score: c.deal_score,
    deal_health: c.deal_health,
    severity: c.severity,
    conversation_intelligence: a.conversation_intelligence ?? {},
    risks: a.risks ?? [],
    objections: a.objections ?? [],
    sales_performance: a.sales_performance ?? {},
    sentiment_analysis: a.sentiment_analysis ?? {},
    recommendations: a.recommendations ?? {},
    refined_pitch: a.refined_pitch ?? '',
    follow_up: a.follow_up ?? {},
    analysis_warning: a.analysis_warning ?? '',
    risk_count: c.risk_count,
    objection_count: c.objection_count,
    transcript_artifacts: d.transcript_artifacts ?? {},
    diarization: d.diarization ?? {},
    pipeline_stage: 'COMPLETE',
    timestamp: new Date().toISOString(),
  },
}];"""


def persist_job_result_code() -> str:
    return r"""const fs = require('fs');
const path = require('path');
const item = items[0].json;
function env(name, fallback = '') {
  try {
    if (typeof $env !== 'undefined' && $env && $env[name] !== undefined && $env[name] !== null) {
      return String($env[name]);
    }
  } catch (e) {}
  return fallback;
}
if (item.job_id) {
  const jobsRoot = env('DEALINTEL_JOBS_ROOT', '/files/jobs') || '/files/jobs';
  const jobDir = path.join(jobsRoot, item.job_id);
  fs.mkdirSync(jobDir, { recursive: true });
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: item.job_id,
    deal_id: item.deal_id,
    status: 'analyzing',
    stage: 'persisting',
    updated_at: new Date().toISOString(),
  }, null, 2));
  const resultPath = path.join(jobDir, 'result.json');
  fs.writeFileSync(resultPath, JSON.stringify(item, null, 2));
  const status = {
    job_id: item.job_id,
    deal_id: item.deal_id,
    status: 'completed',
    stage: 'completed',
    result_path: resultPath,
    updated_at: new Date().toISOString(),
  };
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify(status, null, 2));
}
return [{ json: item }];"""


def persist_job_failure_code() -> str:
    return r"""const fs = require('fs');
const path = require('path');
const item = items[0]?.json ?? {};
function nodeJson(name) {
  try { return $node[name]?.json ?? {}; } catch (e) { return {}; }
}
const prepared = nodeJson('4a. Prepare Embedding Input');
const parsed = nodeJson('Parse Video Transcript');
const embedded = nodeJson('4. Generate Embedding');
const searched = nodeJson('6. Search Milvus Context');
const prompt = nodeJson('7b. Build AI Analysis Prompt');
const candidates = [item, prepared, parsed, embedded, searched, prompt];
const jobId = candidates.map((candidate) => candidate.job_id).find(Boolean);
const dealId = candidates.map((candidate) => candidate.deal_id).find(Boolean) ?? null;

const error = item.error ?? item;
const message =
  error.message ??
  error.description ??
  item.message ??
  item.errorMessage ??
  'n8n video pipeline failed after transcription.';
const failedNode =
  error.node?.name ??
  item.node?.name ??
  item.failedNode ??
  $prevNode?.name ??
  'unknown';
const stageByNode = {
  '4a. Prepare Embedding Input': 'embedding',
  '4b. NVIDIA Embedding Request': 'embedding',
  '4. Generate Embedding': 'embedding',
  '5. Store in Milvus': 'vector_store',
  '6. Search Milvus Context': 'vector_search',
  '7a. Mark AI Analysis': 'ai_analysis',
  '7b. Build AI Analysis Prompt': 'ai_analysis',
  '7. AI Agent': 'ai_analysis',
  '8. Score & Classify': 'scoring',
  '9. Archive Results': 'scoring',
  '10. Dashboard Output': 'scoring',
  '11. Persist Video Job Result': 'persisting',
};
const stage = stageByNode[failedNode] ?? item.stage ?? 'failed';

if (!jobId) {
  throw new Error(`Could not persist video job failure because job_id was unavailable. Original error: ${message}`);
}

const jobsRoot = '/files/jobs';
const jobDir = path.join(jobsRoot, jobId);
fs.mkdirSync(jobDir, { recursive: true });
const payload = {
  job_id: jobId,
  deal_id: dealId,
  status: 'failed',
  stage,
  error: {
    code: 'n8n_downstream_failed',
    message: String(message),
    node: failedNode,
  },
  updated_at: new Date().toISOString(),
};
fs.writeFileSync(path.join(jobDir, 'error.json'), JSON.stringify(payload, null, 2));
fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify(payload, null, 2));
return [{ json: payload }];"""


def read_video_status_code() -> str:
    return r"""const fs = require('fs');
const path = require('path');
function env(name, fallback = '') {
  try {
    if (typeof $env !== 'undefined' && $env && $env[name] !== undefined && $env[name] !== null) {
      return String($env[name]);
    }
  } catch (e) {}
  return fallback;
}
function safeId(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
}
function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { return null; }
}
const query = items[0].json?.query ?? {};
const body = items[0].json?.body ?? {};
const jobId = safeId(query.job_id || query.jobId || body.job_id || body.jobId);
if (!jobId) {
  return [{ json: { status: 'bad_request', error: 'job_id is required' } }];
}
const jobsRoot = env('DEALINTEL_JOBS_ROOT', '/files/jobs') || '/files/jobs';
const jobDir = path.join(jobsRoot, jobId);
const status = readJson(path.join(jobDir, 'status.json'));
if (!status) {
  return [{ json: { job_id: jobId, status: 'not_found' } }];
}
const result = readJson(path.join(jobDir, 'result.json'));
const error = readJson(path.join(jobDir, 'error.json'));
return [{ json: { ...status, result: result || undefined, error: error?.error || status.error || undefined } }];"""


def build_workflow(chat_cred_id: str | None, embedding_cred_id: str | None = None) -> dict:
    chat_credentials = (
        {"openAiApi": {"id": chat_cred_id, "name": "NVIDIA NIM Chat API"}}
        if chat_cred_id
        else None
    )
    embedding_credentials = (
        {"httpHeaderAuth": {"id": embedding_cred_id, "name": "NVIDIA Embeddings API"}}
        if embedding_cred_id
        else None
    )

    nodes = [
        node(
            node_id="di-video-webhook",
            name="Video Intake Webhook",
            type_="n8n-nodes-base.webhook",
            type_version=2,
            position=[80, -80],
            parameters={"httpMethod": "POST", "path": "deal-video", "responseMode": "responseNode", "options": {}},
        ),
        node(
            node_id="di-prepare-video-job",
            name="Prepare Video Job",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[320, -80],
            parameters={"mode": "runOnceForAllItems", "jsCode": prepare_video_job_code()},
        ),
        node(
            node_id="di-respond-video-accepted",
            name="Respond Video Accepted",
            type_="n8n-nodes-base.respondToWebhook",
            type_version=1,
            position=[560, -240],
            parameters={
                "respondWith": "firstIncomingItem",
                "options": {"responseCode": 202},
            },
        ),
        node(
            node_id="di-run-video-transcription",
            name="Video AI Agent: Parakeet ASR + pyannote Tool",
            type_="n8n-nodes-base.executeCommand",
            type_version=1,
            position=[560, -40],
            parameters={
                "command": "={{ '/opt/dealintel/venv/bin/python /opt/dealintel/dealintel_video_job.py process --job-id ' + $json.job_id + ' --jobs-root /files/jobs' }}"
            },
            notes="AI-agent-orchestrated video tool path. Parakeet performs ASR; pyannote remains mandatory diarization.",
        ),
        node(
            node_id="di-parse-video-transcript",
            name="Parse Video Transcript",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[800, -40],
            parameters={"mode": "runOnceForAllItems", "jsCode": parse_video_transcript_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-status-webhook",
            name="Video Status Webhook",
            type_="n8n-nodes-base.webhook",
            type_version=2,
            position=[80, 200],
            parameters={"httpMethod": "GET", "path": "deal-video-status", "responseMode": "lastNode", "options": {}},
        ),
        node(
            node_id="di-read-video-status",
            name="Read Video Job Status",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[320, 200],
            parameters={"mode": "runOnceForAllItems", "jsCode": read_video_status_code()},
        ),
        node(
            node_id="di-transcript-webhook",
            name="1. Transcript Webhook",
            type_="n8n-nodes-base.webhook",
            type_version=2,
            position=[80, 520],
            parameters={"httpMethod": "POST", "path": "deal-intelligence", "responseMode": "lastNode", "options": {}},
        ),
        node(
            node_id="di-set-transcript-input",
            name="2. Set Transcript Input",
            type_="n8n-nodes-base.set",
            type_version=3.4,
            position=[320, 520],
            parameters={"mode": "raw", "jsonOutput": "={{ JSON.stringify($json.body) }}"},
        ),
        node(
            node_id="di-normalize-transcript",
            name="3. Normalize Transcript Input",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[560, 520],
            parameters={"mode": "runOnceForAllItems", "jsCode": normalize_transcript_code()},
        ),
        node(
            node_id="di-manual-trigger",
            name="Manual Test Trigger",
            type_="n8n-nodes-base.manualTrigger",
            type_version=1,
            position=[80, 720],
        ),
        node(
            node_id="di-manual-sample",
            name="Manual Sample Transcript",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[320, 720],
            parameters={"mode": "runOnceForAllItems", "jsCode": manual_sample_code()},
        ),
        node(
            node_id="di-prepare-embedding",
            name="4a. Prepare Embedding Input",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[1040, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": prepare_embedding_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-embedding-request",
            name="4b. NVIDIA Embedding Request",
            type_="n8n-nodes-base.httpRequest",
            type_version=4.2,
            position=[1280, 360],
            parameters={
                "method": "POST",
                "url": "https://example.invalid",
                "authentication": "genericCredentialType",
                "genericAuthType": "httpHeaderAuth",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "Content-Type", "value": "application/json"},
                        {"name": "Accept", "value": "application/json"},
                    ]
                },
                "sendBody": True,
                "specifyBody": "json",
                "jsonBody": "={{ JSON.stringify($json.embedding_request) }}",
                "options": {"timeout": 30000},
            },
            credentials=embedding_credentials,
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-generate-embedding",
            name="4. Generate Embedding",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[1520, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": generate_embedding_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-store-milvus",
            name="5. Store in Milvus",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[1760, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": store_milvus_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-search-milvus",
            name="6. Search Milvus Context",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[2000, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": search_milvus_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-mark-ai-analysis",
            name="7a. Mark AI Analysis",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[2240, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": mark_ai_analysis_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-build-ai-prompt",
            name="7b. Build AI Analysis Prompt",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[2480, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": build_ai_analysis_prompt_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-ai-agent",
            name="7. AI Agent",
            type_="@n8n/n8n-nodes-langchain.agent",
            type_version=2,
            position=[2720, 360],
            parameters={
                "promptType": "define",
                "text": "={{ $json.analysis_prompt }}",
                "options": {"systemMessage": SYSTEM_PROMPT, "temperature": 0.2, "maxTokens": 4096},
            },
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-chat-model",
            name="NVIDIA NIM Chat Model",
            type_="@n8n/n8n-nodes-langchain.lmChatOpenAi",
            type_version=1,
            position=[2720, 600],
            parameters={
                "model": "meta/llama-3.3-70b-instruct",
                "options": {"baseURL": "https://example.invalid", "temperature": 0.2, "maxTokens": 4096},
            },
            credentials=chat_credentials,
        ),
        node(
            node_id="di-score-classify",
            name="8. Score & Classify",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[2960, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": score_classify_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-archive-results",
            name="9. Archive Results",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[3200, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": "const d = items[0].json; d.results_archived_at = new Date().toISOString(); return [{ json: d }];"},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-dashboard-output",
            name="10. Dashboard Output",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[3440, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": dashboard_output_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-persist-job-result",
            name="11. Persist Video Job Result",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[3680, 360],
            parameters={"mode": "runOnceForAllItems", "jsCode": persist_job_result_code()},
            on_error="continueErrorOutput",
        ),
        node(
            node_id="di-persist-job-failure",
            name="Persist Video Job Failure",
            type_="n8n-nodes-base.code",
            type_version=2,
            position=[2240, 40],
            parameters={"mode": "runOnceForAllItems", "jsCode": persist_job_failure_code()},
        ),
    ]

    return {
        "name": "Deal Intelligence Pipeline",
        "nodes": nodes,
        "connections": {
            "Video Intake Webhook": {"main": [[{"node": "Prepare Video Job", "type": "main", "index": 0}]]},
            "Prepare Video Job": {
                "main": [[
                    {"node": "Respond Video Accepted", "type": "main", "index": 0},
                    {"node": "Video AI Agent: Parakeet ASR + pyannote Tool", "type": "main", "index": 0},
                ]]
            },
            "Video AI Agent: Parakeet ASR + pyannote Tool": {"main": [[{"node": "Parse Video Transcript", "type": "main", "index": 0}]]},
            "Parse Video Transcript": {"main": [
                [{"node": "4a. Prepare Embedding Input", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "Video Status Webhook": {"main": [[{"node": "Read Video Job Status", "type": "main", "index": 0}]]},
            "1. Transcript Webhook": {"main": [[{"node": "2. Set Transcript Input", "type": "main", "index": 0}]]},
            "2. Set Transcript Input": {"main": [[{"node": "3. Normalize Transcript Input", "type": "main", "index": 0}]]},
            "3. Normalize Transcript Input": {"main": [[{"node": "4a. Prepare Embedding Input", "type": "main", "index": 0}]]},
            "Manual Test Trigger": {"main": [[{"node": "Manual Sample Transcript", "type": "main", "index": 0}]]},
            "Manual Sample Transcript": {"main": [[{"node": "4a. Prepare Embedding Input", "type": "main", "index": 0}]]},
            "4a. Prepare Embedding Input": {"main": [
                [{"node": "4b. NVIDIA Embedding Request", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "4b. NVIDIA Embedding Request": {"main": [
                [{"node": "4. Generate Embedding", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "4. Generate Embedding": {"main": [
                [{"node": "5. Store in Milvus", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "5. Store in Milvus": {"main": [
                [{"node": "6. Search Milvus Context", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "6. Search Milvus Context": {"main": [
                [{"node": "7a. Mark AI Analysis", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "7a. Mark AI Analysis": {"main": [
                [{"node": "7b. Build AI Analysis Prompt", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "7b. Build AI Analysis Prompt": {"main": [
                [{"node": "7. AI Agent", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "NVIDIA NIM Chat Model": {"ai_languageModel": [[{"node": "7. AI Agent", "type": "ai_languageModel", "index": 0}]]},
            "7. AI Agent": {"main": [
                [{"node": "8. Score & Classify", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "8. Score & Classify": {"main": [
                [{"node": "9. Archive Results", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "9. Archive Results": {"main": [
                [{"node": "10. Dashboard Output", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "10. Dashboard Output": {"main": [
                [{"node": "11. Persist Video Job Result", "type": "main", "index": 0}],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
            "11. Persist Video Job Result": {"main": [
                [],
                [{"node": "Persist Video Job Failure", "type": "main", "index": 0}],
            ]},
        },
        "settings": {"executionOrder": "v1"},
    }


def main() -> int:
    if not API_KEY:
        print("N8N_API_KEY is required in .env or the environment.")
        return 2

    chat_cred_id = create_or_find_chat_credential()
    embedding_cred_id = create_or_find_embedding_credential()

    print("Saving Deal Intelligence Pipeline with video diarization...")
    print("Non-destructive mode: this script updates the named workflow and never deletes workflows, users, or credentials.")
    result = save_workflow(build_workflow(chat_cred_id, embedding_cred_id))
    if not result:
        print("FAILED to save workflow.")
        return 1

    workflow_id = result["id"]
    print(f"  Saved: {result['name']} ({workflow_id})")
    activated = api("POST", f"workflows/{workflow_id}/activate")
    if activated:
        print("  Activated workflow.")
    else:
        print("  Could not auto-activate; activate it in the n8n UI.")

    print("")
    print("Endpoints:")
    print("  Transcript: POST http://localhost:5678/webhook/deal-intelligence")
    print("  Video:      POST http://localhost:5678/webhook/deal-video")
    print("  Status:     GET  http://localhost:5678/webhook/deal-video-status?job_id=<job_id>")
    print("")
    print("Video jobs require HF_TOKEN and accepted pyannote model terms.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
