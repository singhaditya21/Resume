from __future__ import annotations

from pathlib import Path
from typing import Any

from .apex import write_apex_scene_package
from .analysis import (
    build_executive_summary,
    build_financial_intelligence,
    build_follow_up,
    build_refined_pitch,
    build_sales_performance,
    llm_next_best_action,
)
from .chunking import chunk_transcript
from .diarization import assign_speakers, diarize_video
from .exceptions import MissingDependencyError
from .llm import JsonChatClient, build_chat_client
from .media import probe_video
from .models import make_deal_id, utc_now_iso
from .n8n_workflow import build_n8n_workflow
from .pdf_kb import load_pitch_knowledge
from .reporting import write_json_report, write_markdown_report
from .schema import validate_deal_json
from .scoring import (
    build_recommendations,
    enrich_segment_sentiment,
    extract_objections,
    extract_risks,
    score_deal,
    speaker_metrics,
)
from .transcription import transcribe_video
from .transcript_io import read_transcript, write_transcript_artifacts
from .vector_store import VectorIndex
from .visual import detect_visual_objects


class AnalysisPipeline:
    def __init__(
        self,
        *,
        project_root: str | Path,
        vector_dir: str | Path = ".data/chroma",
        llm_provider: str = "glm",
        glm_api_key: str | None = None,
        glm_model: str = "glm-5.1",
        glm_base_url: str | None = None,
        mistral_api_key: str | None = None,
        mistral_model: str = "REDACTED_OPAQUE_VALUE",
        mistral_base_url: str | None = None,
        groq_api_key: str | None = None,
        groq_model: str = "llama-3.1-8b-instant",
        groq_base_url: str | None = None,
        ollama_model: str = "qwen3:8b",
    ):
        self.project_root = Path(project_root)
        self.vector_dir = Path(vector_dir)
        if not self.vector_dir.is_absolute():
            self.vector_dir = self.project_root / self.vector_dir
        self.llm_provider = llm_provider
        self.llm: JsonChatClient = build_chat_client(
            provider=llm_provider,
            glm_api_key=REDACTED_SECRET
            glm_model=glm_model,
            glm_base_url=glm_base_url,
            mistral_api_key=REDACTED_SECRET
            mistral_model=mistral_model,
            mistral_base_url=mistral_base_url,
            groq_api_key=REDACTED_SECRET
            groq_model=groq_model,
            groq_base_url=groq_base_url,
            ollama_model=ollama_model,
        )

    def analyze(
        self,
        *,
        input_path: str | Path,
        deal_id: str | None = None,
        out_dir: str | Path | None = None,
        parakeet_model: str = "nvidia/parakeet-tdt-0_6b-v2",
        whisper_model: str | None = None,
        hf_token: str | None = None,
        skip_diarization: bool = False,
        skip_visual: bool = False,
        apex_scenes: bool = False,
        skip_llm: bool = False,
        visual_max_frames: int = 12,
        apex_interval_seconds: float = 1.5,
    ) -> dict[str, Any]:
        transcript_result = self.transcribe(
            input_path=input_path,
            deal_id=deal_id,
            out_dir=out_dir,
            parakeet_model=whisper_model or parakeet_model,
            hf_token=REDACTED_SECRET
            skip_diarization=skip_diarization,
        )
        return self._analyze_segments(
            transcript_result["segments"],
            deal_id=transcript_result["deal_id"],
            out_dir=transcript_result["out_dir"],
            source=transcript_result["source"],
            diarization_status=transcript_result["diarization"],
            transcript_artifacts=transcript_result["transcript_artifacts"],
            video_path=Path(input_path),
            skip_visual=skip_visual,
            apex_scenes=apex_scenes,
            skip_llm=skip_llm,
            visual_max_frames=visual_max_frames,
            apex_interval_seconds=apex_interval_seconds,
        )

    def transcribe(
        self,
        *,
        input_path: str | Path,
        deal_id: str | None = None,
        out_dir: str | Path | None = None,
        parakeet_model: str = "nvidia/parakeet-tdt-0_6b-v2",
        whisper_model: str | None = None,
        hf_token: str | None = None,
        skip_diarization: bool = False,
    ) -> dict[str, Any]:
        video = Path(input_path)
        if not video.exists():
            raise FileNotFoundError(f"Input video not found: {video}")

        deal_id = deal_id or make_deal_id(video)
        out_path = Path(out_dir) if out_dir else self.project_root / "runs" / deal_id
        out_path.mkdir(parents=True, exist_ok=True)

        source = probe_video(video)
        transcript = transcribe_video(video, model_size=whisper_model or parakeet_model)

        diarization_status = {"status": "skipped", "reason": None}
        if not skip_diarization:
            try:
                turns = diarize_video(video, hf_token=hf_token, device="cpu", min_speakers=1, max_speakers=4)
                transcript = assign_speakers(transcript, turns)
                diarization_status = {"status": "completed", "reason": None, "turn_count": len(turns)}
            except MissingDependencyError as exc:
                transcript = assign_speakers(transcript, None)
                diarization_status = {"status": "skipped", "reason": str(exc)}
        else:
            transcript = assign_speakers(transcript, None)

        transcript = enrich_segment_sentiment(transcript)
        artifacts = write_transcript_artifacts(
            transcript,
            out_path,
            deal_id=deal_id,
            source=source,
            diarization=diarization_status,
        )
        return {
            "deal_id": deal_id,
            "out_dir": out_path,
            "source": source,
            "segments": transcript,
            "diarization": diarization_status,
            "transcript_artifacts": artifacts,
        }

    def analyze_transcript(
        self,
        *,
        transcript_path: str | Path,
        deal_id: str | None = None,
        out_dir: str | Path | None = None,
        source_video: str | Path | None = None,
        skip_visual: bool = True,
        apex_scenes: bool = False,
        skip_llm: bool = False,
        visual_max_frames: int = 12,
        apex_interval_seconds: float = 1.5,
    ) -> dict[str, Any]:
        transcript_file = Path(transcript_path)
        if not transcript_file.exists():
            raise FileNotFoundError(f"Transcript file not found: {transcript_file}")

        segments, metadata = read_transcript(transcript_file)
        if not segments:
            raise ValueError(f"Transcript contains no segments: {transcript_file}")

        deal_id = deal_id or metadata.get("deal_id") or make_deal_id(transcript_file)
        out_path = Path(out_dir) if out_dir else self.project_root / "runs" / str(deal_id)
        out_path.mkdir(parents=True, exist_ok=True)

        segments = enrich_segment_sentiment(segments)
        source = metadata.get("source") or {"path": str(source_video or transcript_file), "source_transcript": str(transcript_file)}
        diarization_status = metadata.get("diarization") or {}
        if diarization_status.get("status") != "completed" and _has_corrected_speaker_labels(segments):
            diarization_status = {"status": "provided_transcript", "reason": str(transcript_file)}
        elif not diarization_status:
            diarization_status = {"status": "provided_transcript", "reason": str(transcript_file)}
        artifacts = write_transcript_artifacts(
            segments,
            out_path,
            deal_id=str(deal_id),
            source=source,
            diarization=diarization_status,
        )

        video_path = Path(source_video) if source_video else None
        return self._analyze_segments(
            segments,
            deal_id=str(deal_id),
            out_dir=out_path,
            source=source,
            diarization_status=diarization_status,
            transcript_artifacts=artifacts,
            video_path=video_path,
            skip_visual=skip_visual or video_path is None,
            apex_scenes=apex_scenes and video_path is not None,
            skip_llm=skip_llm,
            visual_max_frames=visual_max_frames,
            apex_interval_seconds=apex_interval_seconds,
        )

    def _analyze_segments(
        self,
        transcript: list[Any],
        *,
        deal_id: str,
        out_dir: str | Path,
        source: dict[str, Any],
        diarization_status: dict[str, Any],
        transcript_artifacts: dict[str, str],
        video_path: Path | None = None,
        skip_visual: bool = False,
        apex_scenes: bool = False,
        skip_llm: bool = False,
        visual_max_frames: int = 12,
        apex_interval_seconds: float = 1.5,
    ) -> dict[str, Any]:
        out_path = Path(out_dir)
        transcript = enrich_segment_sentiment(transcript)
        transcript_chunks = chunk_transcript(transcript)
        knowledge_chunks = load_pitch_knowledge(self.project_root)

        index = VectorIndex(self.vector_dir, collection_name="dealintel")
        index.upsert(knowledge_chunks)
        index.upsert(transcript_chunks)
        retrieved = index.query(
            "sales pitch objection handling follow up value proposition risk next step",
            top_k=6,
            source_type="pitch_template",
        )

        objections = extract_objections(transcript)
        risks = extract_risks(transcript)
        score, dimensions = score_deal(transcript)
        recommendations = build_recommendations(score, dimensions, risks, objections)
        metrics = speaker_metrics(transcript)

        pitch, llm_data = build_refined_pitch(
            transcript,
            retrieved or knowledge_chunks,
            objections,
            transcript_chunks=transcript_chunks,
            risks=risks,
            dimensions=dimensions,
            llm=None if skip_llm else self.llm,
        )
        follow_up = build_follow_up(recommendations, llm_data, deal_id=deal_id)

        visual = (
            {"status": "skipped", "reason": "Disabled by user.", "objects": [], "frames": []}
            if skip_visual or video_path is None
            else detect_visual_objects(video_path, max_frames=visual_max_frames)
        )
        scene_intelligence = (
            write_apex_scene_package(
                deal_id=deal_id,
                source_video=video_path,
                voice_segments=transcript,
                out_dir=out_path,
                llm=None if skip_llm else self.llm,
                interval_seconds=apex_interval_seconds,
            )
            if apex_scenes and video_path is not None
            else {
                "metadata": {
                    "visual_status": "skipped",
                    "visual_reason": "Apex scene extraction disabled.",
                },
                "knowledge_package": [],
            }
        )
        speaker_reliability = _speaker_reliability(diarization_status, transcript)

        payload = self._build_payload(
            deal_id=deal_id,
            source=source,
            transcript=transcript,
            transcript_chunks=transcript_chunks,
            knowledge_chunks=knowledge_chunks,
            retrieved=retrieved,
            diarization_status=diarization_status,
            metrics=metrics,
            objections=objections,
            risks=risks,
            score=score,
            dimensions=dimensions,
            recommendations=recommendations,
            refined_pitch=pitch,
            follow_up=follow_up,
            visual=visual,
            scene_intelligence=scene_intelligence,
            vector_mode=index.mode,
            llm_data=llm_data,
            llm_provider=None if skip_llm else self.llm.provider,
            llm_model=None if skip_llm else self.llm.model,
            out_path=out_path,
            transcript_artifacts=transcript_artifacts,
            speaker_reliability=speaker_reliability,
        )

        errors = validate_deal_json(payload)
        if errors:
            raise ValueError("Invalid deal intelligence payload: " + "; ".join(errors))

        write_json_report(payload, out_path / "deal_intelligence.json")
        write_json_report(build_n8n_workflow(), out_path / "n8n_workflow.json")
        write_markdown_report(payload, out_path / "deal_report.md")
        return payload

    def _build_payload(self, **kwargs: Any) -> dict[str, Any]:
        transcript = kwargs["transcript"]
        metrics = kwargs["metrics"]
        score = kwargs["score"]
        recommendations = kwargs["recommendations"]
        llm_data = kwargs["llm_data"]

        speaker_reliability = kwargs["speaker_reliability"]
        customer_sentiments = [segment.sentiment_score for segment in transcript if segment.role == "prospect"]
        seller_sentiments = [segment.sentiment_score for segment in transcript if segment.role == "sales_agent"]
        if speaker_reliability["status"] == "insufficient_speaker_evidence":
            customer_sentiment = "PORTFOLIO_REDACTED"
            seller_sentiment = "insufficient_speaker_evidence"
        else:
            customer_sentiment = _sentiment_label(customer_sentiments)
            seller_sentiment = _sentiment_label(seller_sentiments)

        next_best_action = llm_next_best_action(llm_data, recommendations)
        unsupported_claims = _unsupported_claims(kwargs["dimensions"])
        analysis_confidence = _analysis_confidence(kwargs["dimensions"], speaker_reliability)
        executive_summary = build_executive_summary(
            segments=transcript,
            score=score,
            dimensions=kwargs["dimensions"],
            risks=kwargs["risks"],
            objections=kwargs["objections"],
            recommendations=recommendations,
            next_best_action=next_best_action,
            analysis_confidence=analysis_confidence,
        )
        financial_intelligence = build_financial_intelligence(transcript)
        sales_performance = build_sales_performance(
            segments=transcript,
            speaker_metrics=metrics,
            dimensions=kwargs["dimensions"],
            risks=kwargs["risks"],
            objections=kwargs["objections"],
            recommendations=recommendations,
        )
        payload = {
            "schema_version": "1.0",
            "deal_id": kwargs["deal_id"],
            "generated_at": utc_now_iso(),
            "evidence_required": True,
            "transcript_artifacts": kwargs["transcript_artifacts"],
            "analysis_confidence": analysis_confidence,
            "unsupported_claims": unsupported_claims,
            "source": kwargs["source"],
            "executive_summary": executive_summary,
            "transcript": {
                "segments": [segment.to_dict() for segment in transcript],
                "chunks": [chunk.to_dict() for chunk in kwargs["transcript_chunks"]],
                "diarization": kwargs["diarization_status"],
            },
            "conversation_intelligence": {
                "speaker_metrics": metrics,
                "speaker_reliability": speaker_reliability,
                "customer_sentiment": customer_sentiment,
                "sales_agent_sentiment": seller_sentiment,
                "sentiment_timeline": [
                    {
                        "start": segment.start,
                        "end": segment.end,
                        "speaker": segment.speaker,
                        "role": segment.role,
                        "sentiment": segment.sentiment,
                        "sentiment_score": segment.sentiment_score,
                    }
                    for segment in transcript
                ],
            },
            "deal_intelligence": {
                "framework": "MEDDICC+BANT",
                "score": score,
                "dimensions": [dimension.to_dict() for dimension in kwargs["dimensions"]],
                "risks": kwargs["risks"],
                "objections": kwargs["objections"],
            },
            "financial_intelligence": financial_intelligence,
            "sales_performance": sales_performance,
            "visual_intelligence": kwargs["visual"],
            "scene_intelligence": kwargs["scene_intelligence"],
            "recommendations": [rec.to_dict() for rec in recommendations],
            "refined_pitch": kwargs["refined_pitch"],
            "follow_up": kwargs["follow_up"],
            "rag": {
                "llm_provider": kwargs["llm_provider"],
                "llm_model": kwargs["llm_model"],
                "vector_mode": kwargs["vector_mode"],
                "knowledge_sources": sorted({chunk.source for chunk in kwargs["knowledge_chunks"]}),
                "retrieved_snippets": [chunk.to_dict() for chunk in kwargs["retrieved"]],
            },
            "n8n": {
                "event": "deal_intelligence.completed",
                "deal_id": kwargs["deal_id"],
                "score": score,
                "next_best_action": next_best_action,
                "json_path": str(Path(kwargs["out_path"]) / "deal_intelligence.json"),
            },
        }
        return payload


def _sentiment_label(scores: list[float]) -> str:
    if not scores:
        return "unknown"
    avg = sum(scores) / len(scores)
    if avg > 0.15:
        return "positive"
    if avg < -0.15:
        return "negative"
    return "neutral"


def _speaker_reliability(diarization_status: dict[str, Any], segments: list[Any]) -> dict[str, Any]:
    speakers = {segment.speaker for segment in segments if segment.speaker and segment.speaker != "UNKNOWN"}
    roles = {segment.role for segment in segments if segment.role and segment.role != "unknown"}
    if diarization_status.get("status") == "completed" and len(speakers) >= 2:
        return {
            "status": "reliable",
            "source": "diarization",
            "confidence": 0.85,
            "reason": "Speaker diarization completed and produced multiple speakers.",
        }
    if diarization_status.get("status") == "provided_transcript" and len(speakers) >= 2 and {"sales_agent", "prospect"} <= roles:
        return {
            "status": "provided_by_transcript",
            "source": "corrected_transcript",
            "confidence": 0.8,
            "reason": "Corrected transcript provided speaker and role labels.",
        }
    return {
        "status": "insufficient_speaker_evidence",
        "source": diarization_status.get("status", "unknown"),
        "confidence": 0.0,
        "reason": "Speaker diarization or corrected speaker labels are required for speaker-level sentiment.",
    }


def _has_corrected_speaker_labels(segments: list[Any]) -> bool:
    speakers = {segment.speaker for segment in segments if segment.speaker and segment.speaker != "UNKNOWN"}
    roles = {segment.role for segment in segments if segment.role and segment.role != "unknown"}
    return len(speakers) >= 2 and {"sales_agent", "prospect"} <= roles


def _analysis_confidence(dimensions: list[Any], speaker_reliability: dict[str, Any]) -> dict[str, Any]:
    dimension_confidences = [float(item.confidence) for item in dimensions]
    qualification = round(sum(dimension_confidences) / len(dimension_confidences), 2) if dimension_confidences else 0.0
    speaker = float(speaker_reliability.get("confidence", 0.0))
    overall = round((qualification * 0.75) + (speaker * 0.25), 2)
    return {
        "overall": overall,
        "qualification": qualification,
        "speaker": speaker,
        "method": "timestamped_transcript_evidence",
    }


def _unsupported_claims(dimensions: list[Any]) -> list[dict[str, Any]]:
    return [
        {
            "type": "score_dimension",
            "name": item.name,
            "reason": item.rationale,
        }
        for item in dimensions
        if item.status == "insufficient_evidence"
    ]
