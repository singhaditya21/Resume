import unittest

from dealintel.chunking import chunk_transcript
from dealintel.models import TranscriptSegment


class ChunkingTests(unittest.TestCase):
    def test_transcript_chunks_preserve_metadata(self):
        segments = [
            TranscriptSegment(id=f"seg-{i}", start=i * 5.0, end=i * 5.0 + 4.0, text="pricing concern and next step " * 8, speaker="SPEAKER_00")
            for i in range(6)
        ]
        chunks = chunk_transcript(segments, target_chars=180, overlap_segments=1)
        self.assertGreaterEqual(len(chunks), 2)
        self.assertEqual(chunks[0].metadata["start"], 0.0)
        self.assertIn("segment_ids", chunks[0].metadata)
        self.assertEqual(chunks[1].metadata["segment_ids"][0], chunks[0].metadata["segment_ids"][-1])


if __name__ == "__main__":
    unittest.main()

