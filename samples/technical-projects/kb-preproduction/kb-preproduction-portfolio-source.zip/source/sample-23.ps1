param(
    [string]$PythonExecutable = "python",
    [switch]$SkipListDrives
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir
$LogDir = Join-Path $RepoRoot "logs"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$LogFile = Join-Path $LogDir "sharepoint-check-$Stamp.log"

Set-Location $RepoRoot
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null

$RequiredVars = @(
    "MS_TENANT_ID",
    "SP_CLIENT_ID",
    "SP_CLIENT_SECRET",
    "SP_SITE_URL"
)

function Get-ConfiguredEnvironmentVariable {
    param([string]$Name)

    $Scopes = @("Process", "User", "Machine")
    foreach ($Scope in $Scopes) {
        $Value = [Environment]::GetEnvironmentVariable($Name, $Scope)
        if (-not [string]::IsNullOrWhiteSpace($Value)) {
            return $Value
        }
    }

    return $null
}

$MissingVars = @()
foreach ($Name in $RequiredVars) {
    $Value = Get-ConfiguredEnvironmentVariable -Name $Name
    if ([string]::IsNullOrWhiteSpace($Value)) {
        $MissingVars += $Name
    } else {
        [Environment]::SetEnvironmentVariable($Name, $Value, "Process")
    }
}

if ($MissingVars.Count -gt 0) {
    "Missing required environment variables: $($MissingVars -join ', ')" |
        Tee-Object -FilePath $LogFile
    exit 2
}

$Arguments = @(
    "scripts/test_sharepoint_connection.py",
    "--no-dotenv",
    "--non-interactive"
)

if (-not $SkipListDrives) {
    $Arguments += "--list-drives"
}

& $PythonExecutable @Arguments *>&1 | Tee-Object -FilePath $LogFile
exit $LASTEXITCODE
