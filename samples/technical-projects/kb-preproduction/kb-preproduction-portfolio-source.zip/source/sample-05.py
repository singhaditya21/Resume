import json
import os
from typing import Any, Dict, List, Optional

from app.config.constants import MAX_SEARCH_LIMIT
from app.config.settings import get_settings
from ingestion.embeddings.embedder import embed_query
from utils.tracing import set_span_attrs, start_span
from vector_store.client import get_milvus_client


def parse_hit(hit: Dict[str, Any], include_text: bool) -> Dict[str, Any]:
    entity = hit.get("entity", hit)
    text = entity.get("content") or entity.get("text") or ""
    if isinstance(text, str) and text.startswith("{"):
        try:
            text = json.loads(text).get("text", text)
        except Exception:
            pass

    file_path = (
        entity.get("source_path")
        or entity.get("file_path")
        or entity.get("source")
        or entity.get("doc_id")
        or ""
    )
    document_id = entity.get("doc_id") or entity.get("document_id") or entity.get("file_name") or os.path.basename(file_path)

    result = {
        "score": hit.get("distance", hit.get("score", 0.0)),
        "document_id": document_id,
        "file_name": entity.get("file_name") or os.path.basename(file_path),
        "file_path": file_path,
        "source": entity.get("source", ""),
        "text_preview": text[:700].replace("\n", " ").strip(),
    }
    if include_text:
        result["text"] = text
    return result


def search_milvus(query: str, limit: int = 5, collection: Optional[str] = None, include_text: bool = False) -> List[Dict[str, Any]]:
    settings = get_settings()
    with start_span("rag.retrieve.milvus") as span:
        query = query.strip()
        if not query:
            set_span_attrs(span, {"retrieval.empty_query": True})
            return []

        collection_name = collection or settings.milvus_collection
        top_k = max(1, min(limit, MAX_SEARCH_LIMIT))
        set_span_attrs(
            span,
            {
                "openinference.span.kind": "RETRIEVER",
                "db.system": "milvus",
                "db.collection": collection_name,
                "retrieval.top_k": top_k,
                "input.value": query[:1000],
            },
        )

        client = get_milvus_client()
        results = client.search(
            collection_name=collection_name,
            data=[embed_query(query)],
            limit=top_k,
            output_fields=["doc_id", "content"],
        )
        parsed = [parse_hit(hit, include_text) for hit in (results[0] if results else [])]
        set_span_attrs(
            span,
            {
                "retrieval.result_count": len(parsed),
                "output.value": json.dumps(
                    [
                        {
                            "file_name": item.get("file_name"),
                            "score": item.get("score"),
                            "text_preview": item.get("text_preview", "")[:300],
                        }
                        for item in parsed[:5]
                    ],
                    ensure_ascii=False,
                ),
            },
        )
        if parsed:
            set_span_attrs(
                span,
                {
                    "retrieval.top_source": parsed[0].get("file_name", ""),
                    "retrieval.top_score": float(parsed[0].get("score") or 0.0),
                },
            )
        return parsed