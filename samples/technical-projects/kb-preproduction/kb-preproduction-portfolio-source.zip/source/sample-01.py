from llm.providers.chat_client import call_llm


def generate_answer(prompt: str) -> str:
    return call_llm(prompt)