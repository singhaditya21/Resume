from app.config.settings import get_settings
from vector_store.index import collection_health


def health_status(phoenix_status: dict) -> dict:
    settings = get_settings()
    milvus = {}
    try:
        milvus = collection_health()
    except Exception as exc:
        milvus = {"exists": False, "error": str(exc)}

    return {
        "success": True,
        "app": settings.app_name,
        "version": settings.app_version,
        "milvus": milvus,
        "llm_provider": "groq" if settings.groq_api_key else "llama.cpp",
        "llm_model": settings.groq_model if settings.groq_api_key else settings.llm_model,
        "embed_model": settings.embed_model,
        "phoenix": phoenix_status,
    }