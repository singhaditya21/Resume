from typing import Any, Dict, List


def rerank(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return chunks