from collections import deque
from typing import Any, Deque, Dict, List, Optional


class ConversationMemory:
    def __init__(self, max_turns: int = 6) -> None:
        self._max_turns = max_turns
        self._sessions: Dict[str, Deque[Dict[str, str]]] = {}

    def history(self, session_id: str) -> List[Dict[str, str]]:
        if session_id not in self._sessions:
            self._sessions[session_id] = deque(maxlen=self._max_turns)
        return list(self._sessions[session_id])

    def append_turn(self, session_id: str, user_msg: str, assistant_msg: str) -> None:
        if session_id not in self._sessions:
            self._sessions[session_id] = deque(maxlen=self._max_turns)
        self._sessions[session_id].append({"role": "user", "content": user_msg})
        self._sessions[session_id].append({"role": "assistant", "content": assistant_msg})