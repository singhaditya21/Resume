#!/usr/bin/env python3
"""Check documents stored in Milvus"""
from pymilvus import MilvusClient

client = MilvusClient(uri="http://localhost:19530")
result = client.query("biztech_rag", output_fields=["doc_id"], limit=10000)
files = set(r.get("doc_id", "unknown") for r in result)

with open("/tmp/milvus_docs.txt", "w") as f:
    f.write(f"Total chunks: {len(result)}\n")
    f.write(f"Unique files: {len(files)}\n\n")
    for doc in sorted(files):
        count = sum(1 for r in result if r.get("doc_id") == doc)
        f.write(f"  {doc}: {count} chunks\n")

with open("/tmp/milvus_docs.txt", "r") as f:
    print(f.read())