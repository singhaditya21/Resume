#!/usr/bin/env python3
"""
Export Milvus collection data to JSON file for migration.
Run on the SOURCE server (production).

Usage:
  python scripts/export_milvus.py --collection biztech_rag --output data/milvus_export.json
  python scripts/export_milvus.py  # defaults: biztech_rag -> data/milvus_export.json
"""

import argparse
import json
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()


def export_collection(collection_name: str, output_path: str, milvus_uri: str):
    from pymilvus import MilvusClient

    print(f"Connecting to Milvus at {milvus_uri}...")
    client = MilvusClient(uri=milvus_uri)

    if not client.has_collection(collection_name):
        print(f"ERROR: Collection '{collection_name}' does not exist!")
        sys.exit(1)

    # Get collection stats
    stats = client.get_collection_stats(collection_name)
    row_count = stats.get("row_count", 0)
    print(f"Collection '{collection_name}' has {row_count} rows")

    # Query all data
    print("Exporting data...")
    results = client.query(
        collection_name=collection_name,
        filter="",
        output_fields=["*"],
        limit=16384,
    )

    print(f"Exported {len(results)} records")

    # Save to file
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"Saved to {output_path} ({os.path.getsize(output_path) / 1024 / 1024:.1f} MB)")
    return len(results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Export Milvus collection to JSON")
    parser.add_argument("--collection", default=os.getenv("MILVUS_COLLECTION", "biztech_rag"))
    parser.add_argument("--output", default="data/milvus_export.json")
    parser.add_argument("--uri", default=os.getenv("MILVUS_URI", "http://localhost:19530"))
    args = parser.parse_args()

    count = export_collection(args.collection, args.output, args.uri)
    print(f"Done! Exported {count} records.")