#!/bin/bash
# Interactive Q&A for AIbot RAG
# Usage: bash scripts/ask.sh

URL="http://localhost:7100/ask"

echo "═══════════════════════════════════════"
echo "  AIbot RAG - Interactive Q&A"
echo "  Type your question and press Enter"
echo "  Type 'quit' or 'exit' to stop"
echo "═══════════════════════════════════════"
echo ""

while true; do
    echo -n "❓ Your question: "
    read -r question

    if [[ -z "$question" ]]; then
        continue
    fi

    if [[ "$question" == "quit" || "$question" == "exit" ]]; then
        echo "👋 Bye!"
        break
    fi

    echo "⏳ Thinking..."
    echo ""

    response=$(curl -s -X POST "$URL" \
        -H "Content-Type: application/json" \
        -d "{\"question\": \"$question\"}" 2>/dev/null)

    # Extract and print the answer
    answer=$(echo "$response" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print()
    print('📝 ANSWER:')
    print('─' * 60)
    print(data.get('answer', 'No answer'))
    print('─' * 60)
    sources = data.get('sources', [])
    if sources:
        print()
        print('📚 SOURCES:')
        for i, s in enumerate(sources[:3], 1):
            name = s.get('file_name', 'Unknown')
            score = s.get('score', 0)
            print(f'  {i}. {name} (score: {score:.3f})')
    print()
except Exception as e:
    print('Error: ' + str(e))
" 2>/dev/null)

    echo "$answer"
    echo ""
done