/*
 * Profitability dashboard — client-side content guard.
 * NOTE: these are DETERRENTS for casual copying, not real security.
 * A determined user can bypass all of this (disable JS, use a proxy, fetch
 * /data.json directly, or photograph the screen). Real protection = auth on
 * the server (Azure AD SSO + IP allow-list). Toggle features in CFG below.
 */
(function () {
  'use strict';

  var CFG = {
    disableContextMenu: true,   // block right-click menu
    blockDevtoolsKeys:  true,   // F12, Ctrl+Shift+I/J/C/K, Ctrl+U (Win) + Cmd+Alt+I/J/C/U (Mac)
    blockSaveOpenPrint: true,   // Ctrl/Cmd+S, +P, +O
    disableSelection:   true,   // no text selection / copy / cut  (UX cost: numbers not selectable)
    disableDrag:        true,   // no image/text drag-out
    blockPrint:         true,   // blank the page while printing
    devtoolsDetect:     true,   // pause behind an overlay if devtools appear (heuristic; can false-positive)
    watermark:          false,  // tiled CONFIDENTIAL watermark over the page (disabled per request)
    watermarkText:      'BusinessNext · CONFIDENTIAL · Business Finance',
    screenshotDeter:    true,   // PrintScreen -> wipe clipboard + brief blur flash
    blurOnBlur:         true    // blur the page whenever the window loses focus (deters screen-share / 2nd-monitor capture; blurs on alt-tab)
  };

  function on(t, ev, fn) { t.addEventListener(ev, fn, true); }
  function stop(e) { e.preventDefault(); e.stopPropagation(); return false; }
  function isField(el) { return el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName || ''); }

  // Platform detection (userAgentData is Chromium-only; fall back to the deprecated
  // navigator.platform, then the UA string) so key combos match Win vs Mac correctly.
  var _plat = ((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || navigator.userAgent || '');
  var IS_MAC = /Mac|iPhone|iPad|iPod/i.test(_plat);
  var IS_WIN = /Win/i.test(_plat);

  // ---------- injected CSS ----------
  var css = '';
  if (CFG.disableSelection) {
    css += '*{-webkit-user-select:none!important;-moz-user-select:none!important;-ms-user-select:none!important;user-select:none!important;-webkit-touch-callout:none!important;}';
    css += 'input,textarea,[contenteditable="true"]{-webkit-user-select:text!important;user-select:text!important;}';
  }
  if (CFG.blockPrint) {
    css += '@media print{html,body{display:none!important;visibility:hidden!important;}}';
  }
  css += '#__wm{position:fixed;inset:0;z-index:2147483646;pointer-events:none;opacity:.11;background-repeat:repeat;}';
  css += 'html.__sec-blur,body.__sec-blur{filter:blur(24px)!important;transition:filter .01s!important;}';
  css += '#__sec-overlay{position:fixed;inset:0;z-index:2147483647;display:none;align-items:center;justify-content:center;'
       + 'background:#0b1220;color:#e6edf6;font:600 18px/1.6 system-ui,-apple-system,Segoe UI,sans-serif;text-align:center;padding:2rem;}';
  var style = document.createElement('style');
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);

  // ---------- watermark ----------
  function buildWatermark() {
    if (!CFG.watermark || !document.body) return;
    var wm = document.getElementById('__wm');
    if (!wm) { wm = document.createElement('div'); wm.id = '__wm'; document.body.appendChild(wm); }
    var label = CFG.watermarkText + '  ·  ' + new Date().toISOString().slice(0, 16).replace('T', ' ');
    var esc = label.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="440" height="240">'
            + '<text x="0" y="130" transform="rotate(-28 220 120)" fill="#8493a8" '
            + 'font-family="sans-serif" font-size="15" font-weight="600">' + esc + '</text></svg>';
    wm.style.backgroundImage = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
  }

  // ---------- blur state (screenshot / focus-loss defense) ----------
  var _hold = false, _holdTimer = null;
  function _setBlur(on) {
    var h = document.documentElement, b = document.body;
    if (h) h.classList.toggle('__sec-blur', on);
    if (b) b.classList.toggle('__sec-blur', on);
  }
  // Persistent blur: the page is "not safe to show" (focus lost / Meta key down).
  function blurHold() {
    _hold = true; _setBlur(true);
    clearTimeout(_holdTimer);
    _holdTimer = setTimeout(blurRelease, 8000); // safety valve so it can never stick
  }
  function blurRelease() { _hold = false; clearTimeout(_holdTimer); _setBlur(false); }
  // Brief flash used when focus is NOT lost (e.g. after a PrtSc keyup).
  function blurFlash() {
    if (_hold) return;
    _setBlur(true);
    setTimeout(function () { if (!_hold) _setBlur(false); }, 1000);
  }

  // ---------- screenshot deterrent ----------
  function deterShot() {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText('Screenshots of this confidential dashboard are prohibited.');
      }
    } catch (_) {}
    blurFlash();
  }

  // ---------- devtools overlay ----------
  var overlay;
  function setOverlay(show) {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = '__sec-overlay';
      overlay.textContent = 'Access paused — developer tools detected. Close them to continue viewing this confidential dashboard.';
      (document.body || document.documentElement).appendChild(overlay);
    }
    overlay.style.display = show ? 'flex' : 'none';
  }

  // ---------- wire up ----------
  function init() {
    buildWatermark();

    if (CFG.disableContextMenu) on(document, 'contextmenu', stop);
    if (CFG.disableDrag) { on(document, 'dragstart', stop); on(document, 'drop', stop); }
    if (CFG.disableSelection) {
      on(document, 'copy', stop);
      on(document, 'cut', stop);
      on(document, 'selectstart', function (e) { return isField(e.target) ? undefined : stop(e); });
    }

    on(document, 'keydown', function (e) {
      var k = (e.key || '').toLowerCase(), c = e.ctrlKey || e.metaKey, s = e.shiftKey;
      // Pre-emptively blur the instant the Windows/Meta key is involved. OS screen-capture
      // shortcuts (Win+Shift+S, Win+PrtSc) freeze the screen only after the whole combo is
      // recognized — a few ms after Meta goes down — so blurring here can win the race that a
      // focus/blur event loses. Released on refocus / click / timeout.
      // Windows only: the Windows key (Meta) precedes Win+Shift+S / Win+PrtSc. On macOS the
      // Meta key is Cmd — used for nearly every shortcut — so pre-blurring on it there would
      // blur the page constantly; macOS screenshots (Cmd+Shift+3/4) are OS-level anyway.
      if (CFG.screenshotDeter && IS_WIN && (e.key === 'Meta' || e.metaKey)) blurHold();
      // DevTools / view-source shortcuts. Windows/Linux: F12, Ctrl+Shift+I/J/C/K, Ctrl+U.
      // macOS: Cmd+Alt+I/J/C, Cmd+Alt+U — hence the altKey branch. (Bypassable via the
      // browser menu on every desktop browser; this only covers the keyboard.)
      if (CFG.blockDevtoolsKeys && (k === 'f12' || (c && (s || e.altKey) && (k === 'i' || k === 'j' || k === 'c' || k === 'k' || k === 'u')) || (c && k === 'u'))) return stop(e);
      // Win+Shift+S (Windows Snipping Tool). The OS normally intercepts this before
      // the page sees it, so this is best-effort; the real mitigation is the
      // blur-on-focus-loss below (the snip overlay steals focus -> page blurs).
      // Checked BEFORE the save/print block so the screenshot deterrent (clipboard
      // wipe + blur) runs rather than just a plain preventDefault.
      if (CFG.screenshotDeter && e.metaKey && s && k === 's') { deterShot(); return stop(e); }
      // macOS screenshots: Cmd+Shift+3 (full, instant), Cmd+Shift+4/5 (region, has an overlay).
      // OS-level capture — cannot be blocked; best-effort blur only (won't beat the instant one).
      if (CFG.screenshotDeter && IS_MAC && e.metaKey && s && (k === '3' || k === '4' || k === '5')) deterShot();
      if (CFG.blockSaveOpenPrint && c && (k === 's' || k === 'p' || k === 'o')) return stop(e);
      if (CFG.disableSelection && c && (k === 'a' || k === 'c' || k === 'x')) { if (!isField(e.target)) return stop(e); }
      // Some browsers do emit keydown for PrintScreen; keyup handler below is the reliable path.
      if (CFG.screenshotDeter && (k === 'printscreen' || e.keyCode === 44)) deterShot();
    });

    // PrintScreen fires on keyup (not keydown) in most browsers. We can't stop the
    // capture, but we overwrite the clipboard so a subsequent paste yields a notice.
    on(document, 'keyup', function (e) {
      var k = (e.key || '').toLowerCase();
      if (CFG.screenshotDeter && (k === 'printscreen' || e.keyCode === 44)) deterShot();
    });

    if (CFG.blockPrint) {
      on(window, 'beforeprint', blurHold);
      on(window, 'afterprint', blurRelease);
    }

    // Blur when focus/visibility is lost; release when the user is verifiably back on
    // the page (refocus, click, or tab becomes visible). Release triggers are registered
    // whenever either focus-loss blur OR the Meta-key screenshot pre-blur is enabled.
    if (CFG.blurOnBlur || CFG.screenshotDeter) {
      on(window, 'focus', blurRelease);
      on(document, 'pointerdown', blurRelease);
      on(document, 'visibilitychange', function () { if (document.hidden) blurHold(); else blurRelease(); });
    }
    if (CFG.blurOnBlur) {
      on(window, 'blur', blurHold);
    }

    if (CFG.devtoolsDetect) {
      setInterval(function () {
        var w = window.outerWidth - window.innerWidth, h = window.outerHeight - window.innerHeight;
        setOverlay(w > 200 || h > 200);
      }, 1000);
    }
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init);
})();
