async function diagnose() {
  console.log('--- ACTUAL TABLE DIAGNOSTICS ---');
  // Discovered names from schema search
  const discoveredTables = [
    'leads', 
    'project', 
    'opportunityview', 
    'opportunityproducts',
    'sv_accounts',
    'sv_leads',
    'project_revenue'
  ];
  
  try {
    for (const table of discoveredTables) {
      const stats = await pool.query(`
        SELECT count(*) as actual_count 
        FROM dbo.${table}
      `).catch(() => ({ rows: [{ actual_count: 'TIMEOUT/ERROR' }] }));
      
      console.log(`[${table.toUpperCase()}]`);
      console.log(` - Rows: ${stats.rows[0]?.actual_count}`);
    }
  } catch (err) {
    console.error('Diagnostic failed:', err.message);
  } finally {
    process.exit();
  }
}
