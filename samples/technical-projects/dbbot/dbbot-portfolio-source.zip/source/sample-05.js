const path = require('path');
const { Groq } = require('groq-sdk');
const { OpenAI } = require('openai');
const dotenv = require('dotenv');
const https = require('https');
const { spawn } = require('child_process');

dotenv.config({ path: path.resolve(__dirname, '..', '..', '.env'), quiet: true });
dotenv.config({ path: path.resolve(__dirname, '..', '..', '.env.local'), quiet: true });
dotenv.config({ path: path.resolve(__dirname, '..', '.env'), quiet: true });
dotenv.config({ path: path.resolve(__dirname, '..', '.env.local'), quiet: true });
dotenv.config({ quiet: true });

// ─── Load Keys ──────────────────────────────────────────────────
function parseListEnv(name) {
  return (process.env[name] || '')
    .split(',')
    .map(k => k.trim())
    .filter(Boolean);
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function collectNamedKeys(pattern) {
  return Object.entries(process.env)
    .filter(([name, value]) => pattern.test(name) && value)
    .sort(([a], [b]) => a.localeCompare(b, undefined, { numeric: true }))
    .map(([, value]) => value.trim())
    .filter(Boolean);
}

const GROQ_KEYS = unique([
  ...parseListEnv('GROQ_API_KEYS'),
  ...collectNamedKeys(/^GROQ_API_KEY(?:_\d+)?$/),
]).filter(key => key.startsWith('gsk_'));

const NVIDIA_KEYS = unique([
  ...parseListEnv('NVIDIA_API_KEYS'),
  ...collectNamedKeys(/^NVIDIA_(?:API_KEY|KEY)(?:_\d+)?$/),
]).filter(key => key.startsWith('nvapi-'));
const NVIDIA_BASE_URL = process.env.NVIDIA_BASE_URL || 'https://example.invalid';

// ─── Models ─────────────────────────────────────────────────────
const MODEL_FAST   = process.env.GROQ_MODEL_FAST || 'llama-3.1-8b-instant';
const MODEL_EXPERT = process.env.GROQ_MODEL      || 'llama-3.3-70b-versatile';
const NVIDIA_MODEL = process.env.NVIDIA_MODEL || 'REDACTED_OPAQUE_VALUE';
const NVIDIA_MODEL_FAST = process.env.NVIDIA_MODEL_FAST || NVIDIA_MODEL;
const NVIDIA_MODEL_EXPERT = process.env.NVIDIA_MODEL_EXPERT || NVIDIA_MODEL;
const NVIDIA_MAX_TOKENS = Number.parseInt(process.env.NVIDIA_MAX_TOKENS || '2048', 10);
const NVIDIA_MAX_TOKENS_FAST = Number.parseInt(process.env.NVIDIA_MAX_TOKENS_FAST || '128', 10);
const NVIDIA_TOP_P = Number.parseFloat(process.env.NVIDIA_TOP_P || '1');
const NVIDIA_FREQUENCY_PENALTY = Number.parseFloat(process.env.NVIDIA_FREQUENCY_PENALTY || '0');
const NVIDIA_PRESENCE_PENALTY = Number.parseFloat(process.env.NVIDIA_PRESENCE_PENALTY || '0');
const NVIDIA_TIMEOUT_MS = Number.parseInt(process.env.NVIDIA_TIMEOUT_MS || '30000', 10);
const NVIDIA_STREAM = process.env.NVIDIA_STREAM !== 'false';
const NVIDIA_TRANSPORT = process.env.NVIDIA_TRANSPORT || 'python';
const NVIDIA_PYTHON = process.env.NVIDIA_PYTHON || process.env.PYTHON || 'python3';
const NVIDIA_USE_FOR_FAST = process.env.NVIDIA_USE_FOR_FAST === 'true';
const NVIDIA_USE_FOR_EXPERT = process.env.NVIDIA_USE_FOR_EXPERT === 'true';

// Local Ollama Fallback
const OLLAMA_HOST  = process.env.OLLAMA_HOST  || 'http://localhost:11434/v1';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3';

// ─── Index Rotation ─────────────────────────────────────────────
let currentGroqIndex = 0;
let currentNvidiaIndex = 0;

// ─── Groq Cooldown ──────────────────────────────────────────────
let groqCooldownUntil = 0;
const isGroqCooling = () => Date.now() < groqCooldownUntil;
function cooldownGroq(secs = 60) {
  groqCooldownUntil = Date.now() + secs * 1000;
  console.log(`[Provider] ⏸️ Groq cooling down for ${secs}s`);
}

// ─── Clients ────────────────────────────────────────────────────
function getGroqClient() {
  if (GROQ_KEYS.length === 0) return null;
  const key = GROQ_KEYS[currentGroqIndex];
  currentGroqIndex = (currentGroqIndex + 1) % GROQ_KEYS.length;
  return new Groq({ apiKey: key });
}

function getNvidiaKey() {
  if (NVIDIA_KEYS.length === 0) return null;
  const key = NVIDIA_KEYS[currentNvidiaIndex];
  currentNvidiaIndex = (currentNvidiaIndex + 1) % NVIDIA_KEYS.length;
  return key;
}

function getNvidiaClient(apiKey) {
  return new OpenAI({ baseURL: NVIDIA_BASE_URL, apiKey });
}

function resolveNvidiaModel(model) {
  return model === MODEL_FAST ? NVIDIA_MODEL_FAST : NVIDIA_MODEL_EXPERT;
}

function resolveNvidiaMaxTokens(model) {
  return model === MODEL_FAST ? NVIDIA_MAX_TOKENS_FAST : NVIDIA_MAX_TOKENS;
}

function shouldTryNvidia(model) {
  if (NVIDIA_KEYS.length === 0) return false;
  if (model === MODEL_FAST) return NVIDIA_USE_FOR_FAST;
  return NVIDIA_USE_FOR_EXPERT;
}

function getOllamaClient() {
  return new OpenAI({ baseURL: OLLAMA_HOST, apiKey: 'REDACTED_SECRET' });
}

async function runNvidiaCompletion(apiKey, payload) {
  if (NVIDIA_TRANSPORT === 'python') {
    return runNvidiaPythonCompletion(apiKey, payload);
  }

  if (!NVIDIA_STREAM) {
    const nvidia = getNvidiaClient(apiKey);
    const c = await nvidia.chat.completions.create({ ...payload, stream: false });
    return c.choices[0].message.content.trim();
  }

  return await new Promise((resolve, reject) => {
    const endpoint = new URL(`${NVIDIA_BASE_URL.replace(/\/$/, '')}/chat/completions`);
    const body = JSON.stringify({ ...payload, stream: true });
    let content = '';
    let buffer = '';
    let settled = false;
    let responseRef = null;

    function finish() {
      if (settled) return;
      settled = true;
      responseRef?.removeAllListeners();
      responseRef?.destroy();
      resolve(content.trim());
    }

    function fail(err) {
      if (settled) return;
      settled = true;
      responseRef?.removeAllListeners();
      responseRef?.destroy();
      reject(err);
    }

    const req = https.request({
      method: 'POST',
      hostname: endpoint.hostname,
      path: `${endpoint.pathname}${endpoint.search}`,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'text/event-stream',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      timeout: NVIDIA_TIMEOUT_MS,
    }, response => {
      responseRef = response;
      response.setEncoding('utf8');

      if (response.statusCode < 200 || response.statusCode >= 300) {
        let errorBody = '';
        response.on('data', chunk => { errorBody += chunk; });
        response.on('end', () => fail(new Error(`NVIDIA ${response.statusCode}: ${errorBody}`)));
        return;
      }

      response.on('data', chunk => {
        buffer += chunk;
        const lines = buffer.split(/\r?\n/);
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data:')) continue;
          const data = line.replace(/^dat/opt/portfolio/project'').trim();
          if (!data) continue;
          if (data === '[DONE]') return finish();

          try {
            const parsed = JSON.parse(data);
            content += parsed.choices?.[0]?.delta?.content || parsed.choices?.[0]?.message?.content || '';
          } catch (err) {
            return fail(err);
          }
        }
      });

      response.on('end', finish);
      response.on('error', fail);
    });

    req.on('timeout', () => req.destroy(new Error(`NVIDIA timeout (${NVIDIA_TIMEOUT_MS}ms)`)));
    req.on('error', fail);
    req.write(body);
    req.end();
  });
}

async function runNvidiaPythonCompletion(apiKey, payload) {
  return await new Promise((resolve, reject) => {
    const helper = path.join(__dirname, 'nvidiaStream.py');
    const child = spawn(NVIDIA_PYTHON, [helper], {
      env: {
        ...process.env,
        NVIDIA_API_KEY_VALUE: apiKey,
        NVIDIA_TIMEOUT_SECONDS: String(Math.ceil(NVIDIA_TIMEOUT_MS / 1000)),
      },
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill('SIGTERM');
      reject(new Error(`NVIDIA python transport timeout (${NVIDIA_TIMEOUT_MS}ms)`));
    }, NVIDIA_TIMEOUT_MS + 5000);

    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8'); });
    child.stderr.on('data', chunk => { stderr += chunk.toString('utf8'); });
    child.on('error', err => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', code => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code === 0) return resolve(stdout.trim());
      reject(new Error(stderr.trim() || `NVIDIA python transport exited with code ${code}`));
    });

    child.stdin.end(JSON.stringify({
      url: `${NVIDIA_BASE_URL.replace(/\/$/, '')}/chat/completions`,
      stream: NVIDIA_STREAM,
      payload: { ...payload, stream: NVIDIA_STREAM },
    }));
  });
}

// ─── Timeout wrapper ────────────────────────────────────────────
function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timeout (${ms}ms)`)), ms)),
  ]);
}

// ─── Core completion engine (internal) ──────────────────────────
async function _complete({ messages, model, temperature = 0.7, label = '' }) {

  // 1. Try NVIDIA NIM (Premium First Choice)
  if (shouldTryNvidia(model)) {
    for (let i = 0; i < NVIDIA_KEYS.length; i++) {
      try {
        const nvidiaKey = getNvidiaKey();
        if (!nvidiaKey) continue;
        const nvModel = resolveNvidiaModel(model);
        console.log(`[Provider] ${label} → NVIDIA NIM (${nvModel})`);
        return await withTimeout(
          runNvidiaCompletion(nvidiaKey, {
            messages,
            model: nvModel,
            temperature,
            top_p: NVIDIA_TOP_P,
            frequency_penalty: NVIDIA_FREQUENCY_PENALTY,
            presence_penalty: NVIDIA_PRESENCE_PENALTY,
            max_tokens: resolveNvidiaMaxTokens(model),
          }),
          NVIDIA_TIMEOUT_MS, 'NVIDIA'
        );
      } catch (err) {
        console.warn(`[Provider] NVIDIA fallback required: ${err.message}`);
        if (err.status === 401 || err.status === 429) continue; // try next key
        break; // break loop on total failure
      }
    }
  }

  // 2. Try Groq (Fast Secondary Fallback)
  if (!isGroqCooling() && GROQ_KEYS.length > 0) {
    for (let i = 0; i < GROQ_KEYS.length; i++) {
      const groq = getGroqClient();
      if (!groq) continue;
      try {
        console.log(`[Provider] ${label} → Groq Fallback (${model})`);
        const c = await withTimeout(
          groq.chat.completions.create({ messages, model, temperature }),
          20000, 'Groq'
        );
        return c.choices[0].message.content.trim();
      } catch (err) {
        if (err.status === 429) {
          if (i === GROQ_KEYS.length - 1) cooldownGroq(60);
          continue;
        }
        console.warn(`[Provider] Groq fallback required (${err.status || 'unknown'}): ${err.message}`);
        if (err.status === 400 || err.status === 413) break;
        continue;
      }
    }
  }

  // 3. Ollama local
  console.log(`[Provider] ${label} → Ollama (${OLLAMA_MODEL})`);
  try {
    const ollama = getOllamaClient();
    const c = await withTimeout(
      ollama.chat.completions.create({ messages, model: OLLAMA_MODEL, temperature }),
      45000, 'Ollama'
    );
    return c.choices[0].message.content.trim();
  } catch (err) {
    console.error('[Provider] ❌ ALL providers failed:', err.message);
    throw new Error('AI Service Unavailable.');
  }
}

// ═══════════════════════════════════════════════════════════════
// PUBLIC API — Split-Brain Architecture
// ═══════════════════════════════════════════════════════════════

/**
 * FAST (8B) — For intent classification, general chat, self-verification.
 * Cheap, low-latency, high throughput.
 */
async function getCompletionFast({ messages, temperature = 0 }) {
  return _complete({ messages, model: MODEL_FAST, temperature, label: '⚡ FAST' });
}

/**
 * EXPERT (70B) — For SQL generation only.
 * High accuracy, deeper reasoning, slower.
 */
async function getCompletionExpert({ messages, temperature = 0 }) {
  return _complete({ messages, model: MODEL_EXPERT, temperature, label: '🧠 EXPERT' });
}

/**
 * LEGACY — Backwards-compatible wrapper. Routes to appropriate brain based on model hint.
 */
async function getCompletion({ messages, model, temperature = 0.7 }) {
  const useModel = model || MODEL_EXPERT;
  return _complete({ messages, model: useModel, temperature, label: '🔄 LEGACY' });
}

module.exports = { getCompletion, getCompletionFast, getCompletionExpert };
