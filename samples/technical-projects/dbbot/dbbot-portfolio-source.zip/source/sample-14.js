const { pool } = require('./db');

async function inspect() {
  const tables = ['opportunityview'];
  for (const table of tables) {
    const res = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_schema = 'dbo' AND table_name = $1
    `, [table]);
    console.log(`\nTABLE: ${table}`);
    res.rows.forEach(r => console.log(`|${r.column_name}|`));
  }
  process.exit();
}

inspect();
