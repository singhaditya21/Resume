import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://example.invalid
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    host: '127.0.0.1'
  }
})
