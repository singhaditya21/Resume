const semanticLayer = require('../semantic/semanticLayer');
const goldViews = require('../semantic/goldViews');
const { matchSourceCatalog } = require('../utils/sourceCatalog');
const { matchSpCatalog } = require('../utils/spCatalog');

// Step 2: Retrieval Agent – finds the most relevant tables/views for a query
function retrievalAgent(question, plan) {
  const questionLower = question.toLowerCase();
  const planText = JSON.stringify(plan || '').toLowerCase();
  let combinedText = questionLower + ' ' + planText;

  // --- Semantic Synonyms (Intelligence Layer) ---
  const synonyms = {
    'client': 'PORTFOLIO_REDACTED',
    'customer': 'PORTFOLIO_REDACTED',
    'geography': 'territory',
    'location': 'city territory address',
    'region': 'territory',
    'money': 'revenue amount value cost price',
    'income': 'revenue',
    'staff': 'owner assignedto usercontact',
    'employee': 'PORTFOLIO_REDACTED',
    'who': 'owner name assignedto',
    'company': 'account companyname',
    'firm': 'account'
  };

  // Expand text with synonyms for better matching
  for (const [key, val] of Object.entries(synonyms)) {
    if (combinedText.includes(key)) combinedText += ' ' + val;
  }

  const scores = {};

  // Score Gold Views first (preferred)
  for (const [viewName, view] of Object.entries(goldViews)) {
    let score = 0;
    const viewText = (view.name + ' ' + (view.description || '') + ' ' + (view.businessPurpose || '')).toLowerCase();
    for (const word of combinedText.split(/\W+/).filter(w => w.length > 2)) {
      if (viewText.includes(word)) score += 5; 
    }
    if (score > 0) scores[`view:${viewName}`] = { type: 'view', name: viewName, score, ...view };
  }

  // Score base tables
  for (const [tableName, table] of Object.entries(semanticLayer.tables)) {
    let score = 0;
    const tableText = (tableName + ' ' + table.businessName + ' ' + table.description).toLowerCase();
    for (const word of combinedText.split(/\W+/)) {
      if (word.length > 3 && tableText.includes(word)) score += 2;
    }
    // Also check column names and descriptions
    for (const [colName, colDesc] of Object.entries(table.columns || {})) {
      if (combinedText.includes(colName.toLowerCase())) score += 1;
      if (colDesc.toLowerCase().split(/\W+/).some(w => combinedText.includes(w) && w.length > 3)) score += 0.5;
    }
    if (score > 0) scores[`table:${tableName}`] = { type: 'table', name: tableName, score, ...table };
  }

  // Score workbook source catalog sheets for business semantics and sample values.
  const sourceMatches = matchSourceCatalog(question, plan, 8);
  for (const sheet of sourceMatches) {
    scores[`source:${sheet.name}`] = {
      type: 'source',
      name: sheet.name,
      score: sheet.score,
      businessName: sheet.businessName,
      description: `Source workbook sheet (${sheet.role}) for ${sheet.parent}`,
      columns: sheet.columns || [],
      sourceSheet: sheet.name,
      parent: sheet.parent,
    };
  }

  // Score stored procedures as reference implementations for business logic.
  const spMatches = matchSpCatalog(question, plan, 6);
  for (const routine of spMatches) {
    scores[`procedure:${routine.id}`] = {
      type: 'procedure',
      name: routine.qualifiedName,
      score: routine.score,
      businessName: routine.purpose,
      description: `Stored procedure reference (${routine.routineType}; actions: ${(routine.actions || []).join(', ')})`,
      columns: (routine.parameters || []).map(param => ({
        name: param.name || param.raw,
        businessName: param.type || param.mode || '',
      })),
      routine,
    };
  }

  // Sort by score and return top 5
  const ranked = Object.values(scores)
    .sort((a, b) => b.score - a.score)
    .filter(item => item.score > 0.5)
    .slice(0, 8);

  // Always include accounts and opportunities if nothing found
  if (ranked.length === 0) {
    ranked.push({ type: 'table', name: 'sv_accounts', score: 1, ...semanticLayer.tables.sv_accounts });
    ranked.push({ type: 'view', name: 'opportunityview', score: 1, ...goldViews.opportunityview });
  }

  return ranked;
}

module.exports = { retrievalAgent };
