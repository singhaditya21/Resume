const path = require('path');
const { validateReadOnlyQuery } = require('../middleware/security');
const { loadCachedSchema } = require('../schemaDiscovery');
const semanticLayer = require('../semantic/semanticLayer');
const { buildSourceCatalogContext } = require('../utils/sourceCatalog');
const { buildSpCatalogContext } = require('../utils/spCatalog');
const { getCompletionExpert, getCompletionFast } = require('../utils/providerManager');
const { buildHermesContext } = require('../hermes/learningMemory');
const { getFewShotPrompt } = require('./fewShotPrompt');
const fs = require('fs');

const PROMPT_DEBUG_FILE = path.join(__dirname, '..', 'logs', 'prompt_debug.txt');

function appendPromptDebug(text) {
  try {
    fs.mkdirSync(path.dirname(PROMPT_DEBUG_FILE), { recursive: true });
    fs.writeFileSync(PROMPT_DEBUG_FILE, text, { flag: 'a' });
  } catch (err) {
    console.warn('[SQLAgent] Prompt debug skipped:', err.message);
  }
}

/**
 * Builds a comprehensive, dynamic schema context string from the live cached schema.
 * Filters for relevant tables based on detected entities to keep prompt size manageable.
 */
function buildDynamicSchemaContext(entities = []) {
  const cached = loadCachedSchema();
  if (!cached || !cached.tables) return 'No schema discovered yet.';

  const SCHEMA = process.env.DB_SCHEMA || 'dbo';
  const lines = [];

  // Map common entity names to table fragments/stems
  const entityMap = {
    'leads': ['lead'],
    'lead': ['lead'],
    'accounts': ['account', 'sv_accounts'],
    'account': ['account', 'sv_accounts'],
    'opportunities': ['opportunity', 'opp'],
    'deals': ['opportunity', 'opp', 'deal'],
    'deal': ['opportunity', 'opp', 'deal'],
    'projects': ['project'],
    'project': ['project'],
    'contacts': ['contact', 'usercontact'],
    'contracts': ['contract'],
    'revenue': ['revenue', 'opp'],
    'sales': ['revenue', 'opp']
  };

  const relevantPrefixes = entities.flatMap(e => entityMap[e.toLowerCase()] || [e.toLowerCase()]);

  for (const [fullName, tableDef] of Object.entries(cached.tables)) {
    const tableName = fullName.split('.').pop().toLowerCase();
    
    // Check if table is relevant to any requested entity
    const isRelevant = relevantPrefixes.length === 0 || relevantPrefixes.some(p => tableName.includes(p));
    if (!isRelevant) continue;

    if (!tableDef.columns || tableDef.columns.length === 0) continue;

    const colList = tableDef.columns.map(c => `    ${c.name} (${c.type})`).join('\n');
    lines.push(`TABLE: ${fullName}\n  Column/opt/portfolio/project
  }

  return lines.length > 0 ? lines.join('\n\n') : 'No matching tables found in schema.';
}

async function sqlAgent(question, plan, matchedTables, intentContext = {}, retryContext = null) {
  const dynamicSchema = buildDynamicSchemaContext(intentContext.entities || []);
  const sourceCatalogContext = buildSourceCatalogContext(question, intentContext, {
    maxSheets: 5,
    maxColumnsPerSheet: 24,
  });
  const spCatalogContext = buildSpCatalogContext(question, intentContext, { maxRoutines: 4 });
  const hermesContext = buildHermesContext(question, intentContext, { mode: 'query', limit: 6 });

  const SCHEMA = semanticLayer.schema || process.env.DB_SCHEMA || 'dbo';

  // Build semantic instructions
  const instructionString = (semanticLayer.instructions || []).join('\n- ');

  // Build context from retrieval agent
  const contextString = matchedTables.map(c => `
Table/View: ${c.name}
Description: ${c.description || 'No description'}
Columns: ${c.type === 'view' ? c.query : (Array.isArray(c.columns) ? c.columns.slice(0, 40).map(col => col.businessName ? `${col.name} (${col.businessName})` : col.name).join(', ') : 'See full schema below')}
`).join('\n');

  // Build retry context if this is a self-correction attempt
  const retrySection = retryContext ? `
PREVIOUS ATTEMPT FAILED:
- Previous SQL: ${retryContext.previousSql}
- Error: ${retryContext.error}
- Fix Hints: Use ILIKE for case-insensitive matching. Double-check column names against the FULL SCHEMA below. Quote columns with spaces.
` : '';

  const entitiesRaw = require('../scripts/discovered_entities.json');
  const topBrands = entitiesRaw.brands.slice(0, 50).join(', ');
  const topCities = entitiesRaw.categories || entitiesRaw.cities.slice(0, 30).join(', ');

  const systemPrompt = `You are a specialized PostgreSQL Expert for the DB Bot CRM dashboard.
Your task is to convert natural language questions into precise PostgreSQL queries.

FEW-SHOT EXAMPLES (Follow these patterns):
${getFewShotPrompt()}

STRUCTURED CONTEXT (Extracted by Intent Classifier):
- Entities: ${JSON.stringify(intentContext.entities || [])}
- Requested Columns: ${JSON.stringify(intentContext.requested_columns || [])}
- isCount: ${intentContext.isCount} 
- isDetail: ${intentContext.isDetail}
- Temporal Logic: ${JSON.stringify(intentContext.temporal || {})}
- Filters Specified: ${JSON.stringify(intentContext.filters || [])}
- Negations (Exclude These): ${JSON.stringify(intentContext.negations || [])}

SCHEMA DETAILS (EXACT COLUMN NAMES):
${dynamicSchema}

SOURCE WORKBOOK CATALOG (BUSINESS MEANING AND SAMPLES):
${sourceCatalogContext}

STORED PROCEDURE CATALOG (REFERENCE BUSINESS LOGIC):
${spCatalogContext}

HERMES MEMORY (CATALOG LESSONS + PAST MISTAKES):
${hermesContext}

TABLE RELATIONSHIPS (JOIN HINTS):
${(() => {
  try {
    const hints = require('../scripts/join_hints.json');
    return Object.entries(hints.joins).map(([key, val]) => 
      `- ${key}: ${val.condition} (${val.purpose})`
    ).join('\n');
  } catch { return 'No join hints available.'; }
})()}

CRITICAL RULES:
1. **COUNT vs LIST (MANDATORY)**:
   - If "isCount" is true AND "isDetail" is false: You MUST return a single-row result using \`SELECT COUNT(*) \`.
   - If "isDetail" is true OR specialized counts like "Top 5" are requested: You MUST return a table of records (no aggregation).
2. **COLUMN SELECTION (POLYMORPHISM)**:
   - If "Requested Columns" is provided and not empty, you MUST ONLY \`SELECT\` the specific columns requested (map them to the best matching columns in the schema). 
   - NEVER use \`SELECT *\` if specific columns are requested!
3. **MULTI-ENTITY JOINS & UNIONS**:
   - If multiple entities are detected (e.g. Accounts and Leads):
     - Use \`UNION ALL\` if the user wants independent lists.
     - Use a \`JOIN\` heavily relying on the matching columns from TABLE RELATIONSHIPS if the user wants related data.
     - Refer to the JOIN HINTS above for exact join conditions.
4. **CRITICAL BUSINESS RULES (STRICT ADHERENCE):
- For ACCOUNTS: Use "shortname" for the company name, and "bill_city" for the city/territory.
- For LEADS: Use "firstname" and "lastname" for the person's name, and "city" for their city.
- For OPPORTUNITIES: Prefer dbo.opportunityview when it is present in SCHEMA DETAILS. Its key columns use spaces, including "Opportunity Name", "Account Name", "Close Date", "License Value", "Status Code", and "territory".
- DETAILS: If "isDetail" is true and "requested_columns" is empty, SELECT ALL relevant columns (at least 12 fields or SELECT *) so the user can see a rich data set.
- GEOGRAPHIC FORCE-MAPPING (CRITICAL): If the filter is "Mumbai", "Pune", "Delhi", or "Bangalore", you MUST use the "territory" (in opportunityview) or "bill_city" (in accounts) column. Never use "Account Name" for these values.
- REVENUE BY REGION: Use this pattern: SELECT SUM("License Value") FROM dbo.opportunityview WHERE "territory" ILIKE '%[Region]%';
- STRICT: If a specific column is requested (e.g., "names and emails"), only select those columns.
- STRICT: Never guess a column. If not in the SCHEMA below, do not use it.
- For 'opportunities' or 'revenue', ALWAYS prioritize 'dbo.opportunityview'.
5. **TEMPORAL LOGIC & STRING MATCHING (EXTREMELY IMPORTANT)**:
   - **NEVER** put time/temporal phrases (e.g., 'overdue', 'next 30 days', 'closing date', 'last week') inside an \`ILIKE '%...%'\` string filter. This is a severe hallucination.
   - Time concepts MUST be translated into precise PostgreSQL date mathematics. 
     - "Overdue" -> \`target_date_column < CURRENT_DATE\`
     - "Next 30 days" -> \`target_date_column BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days')\`
   - ONLY use ILIKE for actual string names (account names, contact names, subjects).
6. **ID MATCHING**: 
   - Use numeric PK columns (e.g., projectid = 205).
7. **FORMATTING**:
   - **SELECTIVITY**: ONLY select primitive types (text, int, numeric, date). **NEVER** select JSONB or complex object fields unless explicitly asked.
   - Column names with spaces: Wrap in double quotes (e.g., "Account Name").
   - Add 'LIMIT 1000' to all list queries.
8. **SOURCE CATALOG VS LIVE SCHEMA**:
   - Use the workbook catalog to understand business terms, synonyms, and example values.
   - Use the stored procedure catalog to understand existing business logic, filters, parameters, and table usage.
   - Only generate executable SQL using tables and columns present in SCHEMA DETAILS.
   - Do not copy mutating stored procedure bodies into executable query SQL. Query output must remain read-only SELECT/WITH.

OUTPUT ONLY THE RAW SQL. NO CONVERSATION.
${retrySection}`;

  const prompt = `
${systemPrompt}

User Question: "${question}"
Plan: ${plan}

SQL:`;

  appendPromptDebug(prompt);

  try {
    const sqlGenerated = await getCompletionExpert({
      messages: [{ role: 'user', content: prompt }],
      temperature: 0,
    });
    
    appendPromptDebug(`\n==== RAW LLM ====\n${sqlGenerated}\n=================\n`);

    let sql = sqlGenerated;
    const sqlMatch = sqlGenerated.match(/```(?:sql)?([\s\S]*?)```/i);
    if (sqlMatch) {
      sql = sqlMatch[1].trim();
    } else {
      sql = sqlGenerated.replace(/^[^{]*To /i, '').replace(/```[a-z]*\n?/gi, '').replace(/```\n?/g, '').trim();
    }
    
    // --- Intelligence Layer: Self-Correction (v2) ---
    // If this wasn't a retry, perform a quick "Syntax & Reality Check"
    if (!retryContext && !sql.toLowerCase().includes('count')) {
      console.log('[SQLAgent] 🤖 Self-Verifying SQL structure...');
      const verificationPrompt = `You are a SQL Validator.
      SCHEMA: ${dynamicSchema.slice(0, 2000)}...
      GENERATED SQL: ${sql}
      
      TASK:
      1. Check if tables and columns in the SQL exist in the SCHEMA.
      2. If you find a hallucination, fix it.
      3. Return ONLY the final corrected SQL inside \`\`\`sql block.
      4. If correct, return the original.`;
      
      try {
        const corrected = await getCompletionFast({
          messages: [{ role: 'user', content: verificationPrompt }],
          temperature: 0
        });
        const match = corrected.match(/```(?:sql)?([\s\S]*?)```/i);
        if (match) sql = match[1].trim();
      } catch (e) {
        console.warn('[SQLAgent] Self-verification skipped:', e.message);
      }
    }

    // Security check
    const check = validateReadOnlyQuery(sql);
    if (!check.valid) throw new Error(check.reason);

    return sql;
  } catch (err) {
    console.error('[SQLAgent] Error:', err.message);
    throw err;
  }
}

module.exports = { sqlAgent };
