const fs = require('fs');
const path = require('path');

const businessTablesPath = path.join(__dirname, 'scripts', 'business_tables.json');
const outputPath = path.join(__dirname, 'scripts', 'column_index.json');

try {
  const data = JSON.parse(fs.readFileSync(businessTablesPath, 'utf8'));
  const index = {};

  data.tables.forEach(table => {
    const key = `${table.schema || 'dbo'}.${table.name}`;
    index[key] = table.columns || [];
    // Also store by just name for convenience
    index[table.name] = table.columns || [];
  });

  fs.writeFileSync(outputPath, JSON.stringify(index, null, 2));
  console.log(`Successfully created column_index.json with ${Object.keys(index).length} entries.`);
} catch (err) {
  console.error('Error creating column_index.json:', err.stack);
}
