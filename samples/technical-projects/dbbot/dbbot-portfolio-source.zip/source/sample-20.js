const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: '192.0.2.10',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: 'my_2026_05_07',
  port: 5432,
});

async function checkData() {
  try {
    const res = await pool.query(`
      SELECT "KAM Head", "KAM Leader", "Engagement Manager", "Delivery Owner", "Sales Dev Owner" 
      FROM accountcustomtable 
      WHERE ownerid = 2 
      LIMIT 10;
    `);
    console.log(JSON.stringify(res.rows, null, 2));
  } catch (err) {
    console.error('Error executing query', err.stack);
  } finally {
    await pool.end();
  }
}

checkData();
