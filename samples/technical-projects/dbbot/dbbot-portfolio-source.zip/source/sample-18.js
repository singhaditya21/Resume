const { pool } = require('./db');
const fs = require('fs');
async function inspect() {
  try {
    const res2 = await pool.query('SELECT column_name FROM information_schema.columns WHERE table_schema = \'dbo\' AND table_name = \'leads\'');
    const res3 = await pool.query('SELECT column_name FROM information_schema.columns WHERE table_schema = \'dbo\' AND table_name = \'project\'');
    fs.writeFileSync('cols.json', JSON.stringify({
      leads: res2.rows.map(r=>r.column_name),
      project: res3.rows.map(r=>r.column_name)
    }, null, 2));
  } catch(e) { console.error(e); }
  process.exit();
}
inspect();
