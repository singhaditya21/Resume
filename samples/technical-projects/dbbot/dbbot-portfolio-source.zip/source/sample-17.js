const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: '192.0.2.10',
  user: 'PORTFOLIO_REDACTED',
  password: 'REDACTED_SECRET',
  database: 'postgres', // Connect to default postgres DB
  port: 5432,
});

async function listDBs() {
  try {
    const res = await pool.query('SELECT datname FROM pg_database WHERE datistemplate = false;');
    console.log('Databases:', res.rows.map(r => r.datname));
  } catch (err) {
    console.error('Error listing databases', err.stack);
  } finally {
    await pool.end();
  }
}

listDBs();
