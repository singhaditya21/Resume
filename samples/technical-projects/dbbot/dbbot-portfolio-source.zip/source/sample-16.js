const { pool } = require('./db');

async function checkCounts() {
  const tables = ['sv_cases', 'sv_tasks', 'sv_campaigns', 'tasks', 'tasksview'];
  const results = {};

  for (const table of tables) {
    try {
      const res = await pool.query(`SELECT count(*) FROM dbo.${table}`);
      results[table] = parseInt(res.rows[0].count);
    } catch (err) {
      results[table] = `Error: ${err.message}`;
    }
  }

  console.log(JSON.stringify(results, null, 2));
  process.exit(0);
}

checkCounts();
