const express = require('express');
const router = express.Router();
const { pool } = require('../db');
const { retrievalAgent } = require('../agents/retrievalAgent');
const { sqlAgent } = require('../agents/sqlAgent');
const { functionAgent } = require('../agents/functionAgent');
const { tryFastFunction } = require('../agents/fastFunctionAgent');
const { tryDirectSQL } = require('../agents/directSqlEngine');
const { checkMemory, saveToMemory } = require('../utils/queryMemory');
const { classifyIntent, generalResponse, technicalGuideResponse } = require('../agents/intentClassifier');
const { validateReadOnlyQuery, validateGeneratedFunction } = require('../middleware/security');
const { recordHermesMistake } = require('../hermes/learningMemory');
const { getSourceCatalogSummary } = require('../utils/sourceCatalog');
const { getSpCatalogSummary } = require('../utils/spCatalog');
const { v4: uuidv4 } = require('uuid');

const MAX_RETRIES = 1;
const OUTCOME_TYPES = new Set(['auto', 'query', 'function']);

// ─── Fast Programmatic Insight ──────────────────────────────────
function generateInsight(question, rows, rowCount) {
  if (rowCount === 0) return "No records found matching your query. Try broadening your search.";
  const cols = Object.keys(rows[0]);
  if (rowCount === 1 && cols.length <= 3) {
    const parts = cols.map(c => {
      const val = rows[0][c];
      const num = parseFloat(val);
      if (!isNaN(num) && num > 1000) return `**${c.replace(/_/g, ' ')}**: ${num.toLocaleString('en-US')}`;
      return `**${c.replace(/_/g, ' ')}**: ${val}`;
    });
    return parts.join(' | ');
  }
  let insight = `Found **${rowCount}** records`;
  if (rowCount > 100) insight += ` (showing top 100)`;
  insight += '.';
  return insight;
}

function normalizeOutcomeType(value) {
  const normalized = String(value || 'auto').toLowerCase();
  return OUTCOME_TYPES.has(normalized) ? normalized : 'auto';
}

function shouldGenerateFunction(question, outcomeType) {
  if (outcomeType === 'function') return true;
  if (outcomeType === 'query') return false;
  return /\b(sp|stored\s+procedure|procedure|function|reusable|scheduled|schedule|routine|outcome)\b/i.test(question);
}

async function executeDirectSqlPayload({ queryId, question, directResult, startTime, context = {} }) {
  console.log(`[Query ${queryId}] ⚡ Direct Path: ${directResult.sql.slice(0, 50)}...`);
  const result = await pool.query(directResult.sql);
  const rows = result.rows;
  const columns = result.fields ? result.fields.map(f => f.name) : (rows.length > 0 ? Object.keys(rows[0]) : []);

  let xAxis = 'Category', yAxis = 'Value';
  if (rows.length > 0) {
    const keys = columns;
    xAxis = keys.find(k => k.toLowerCase().includes('name') || k.toLowerCase().includes('shortname') || k.toLowerCase().includes('city') || k.toLowerCase().includes('territory')) || keys[0] || 'Category';
    yAxis = keys.find(k => k.toLowerCase().includes('revenue') || k.toLowerCase().includes('value') || k.toLowerCase().includes('total') || k.toLowerCase().includes('count')) || keys[1] || 'Value';
  }

  return {
    queryId, question, intent: 'DATA', sql: directResult.sql,
    rowCount: rows.length, rows: rows.slice(0, 100), columns,
    outcomeType: 'query',
    insight: generateInsight(question, rows, rows.length),
    durationMs: Date.now() - startTime, direct: true, xAxis, yAxis,
    businessScore: context?.businessUtility || 5
  };
}

function sendSse(res, event, data) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

async function runInternalQuery(question, outcomeType) {
  const port = process.env.PORT || 5000;
  const response = await fetch(`http://127.0.0.1:${port}/api/query`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, outcomeType }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data.error || `Query failed with HTTP ${response.status}`);
    err.payload = data;
    throw err;
  }
  return data;
}

/**
 * Optimized AI pipeline: intent classify → Memory → Direct SQL → LLM fallback
 */
router.post('/', async (req, res) => {
  const { question } = req.body;
  const outcomeType = normalizeOutcomeType(req.body?.outcomeType);

  if (!question || typeof question !== 'string' || question.trim().length < 2) {
    return res.status(400).json({ error: 'Please provide a valid question.' });
  }

  const queryId = uuidv4();
  const startTime = Date.now();

  if (shouldGenerateFunction(question, outcomeType)) {
    const isRawFunction = /^\s*CREATE\s+OR\s+REPLACE\s+FUNCTION\b/i.test(question.trim());
    if (isRawFunction) {
      const check = validateGeneratedFunction(question);
      if (!check.valid) {
        return res.status(403).json({ error: `Function validation failed: ${check.reason}`, queryId });
      }
      return res.json({
        queryId,
        question,
        intent: 'FUNCTION',
        outcomeType: 'function',
        sql: question.trim(),
        rows: [],
        columns: [],
        rowCount: 0,
        generatedOnly: true,
        insight: 'Validated PostgreSQL table-returning function SQL. It was not executed or deployed.',
        durationMs: Date.now() - startTime,
      });
    }

    try {
      const fastGenerated = tryFastFunction(question);
      if (fastGenerated) {
        return res.json({
          queryId,
          question,
          intent: 'FUNCTION',
          outcomeType: 'function',
          sql: fastGenerated.sql,
          functionName: fastGenerated.functionName,
          rows: [],
          columns: [],
          rowCount: 0,
          generatedOnly: true,
          fastPath: true,
          insight: fastGenerated.routineName
            ? `Returned PostgreSQL-safe reference function for stored procedure **${fastGenerated.routineName}**. It was not executed or deployed.`
            : `Generated PostgreSQL table-returning function **${fastGenerated.functionName}** from the validated direct query path. It was not executed or deployed.`,
          durationMs: Date.now() - startTime,
        });
      }

      let context = { intent: 'DATA', confidence: 'low' };
      try {
        const cls = await classifyIntent(question);
        context = cls.context || context;
      } catch (clsErr) {
        console.warn(`[Query ${queryId}] Function intent classification failed, continuing with retrieval...`);
      }

      const relevantContext = retrievalAgent(question, context);
      const generated = await functionAgent(question, relevantContext, context);
      return res.json({
        queryId,
        question,
        intent: 'FUNCTION',
        outcomeType: 'function',
        sql: generated.sql,
        functionName: generated.functionName,
        rows: [],
        columns: [],
        rowCount: 0,
        generatedOnly: true,
        insight: `Generated PostgreSQL table-returning function **${generated.functionName}**. It was not executed or deployed.`,
        durationMs: Date.now() - startTime,
      });
    } catch (fnErr) {
      console.error(`[Query ${queryId}] Function generation error:`, fnErr.message);
      recordHermesMistake({
        queryId,
        question,
        outcomeType: 'function',
        stage: 'function-generation',
        error: fnErr.message,
        lesson: 'Function generation must return validated PostgreSQL CREATE OR REPLACE FUNCTION ... RETURNS TABLE SQL without execution.',
      });
      return res.status(400).json({
        queryId,
        question,
        intent: 'FUNCTION',
        outcomeType: 'function',
        sql: null,
        rows: [],
        columns: [],
        rowCount: 0,
        generatedOnly: true,
        error: fnErr.message,
        insight: `Function generation failed: ${fnErr.message}`,
        durationMs: Date.now() - startTime,
      });
    }
  }

// ─── Phase 22: Raw SQL Detection & Execution ──────────────
  const isRawSql = /^\s*(SELECT|WITH)\b/i.test(question.trim());
  if (isRawSql) {
    console.log(`[Query ${queryId}] Raw SQL detected. Validating...`);
    const validator = validateReadOnlyQuery(question);
    
    if (!validator.valid) {
      return res.status(403).json({ error: `Security violation: ${validator.reason}`, queryId });
    }

    try {
      const result = await pool.query(question);
      const rows = result.rows;
      const columns = result.fields ? result.fields.map(f => f.name) : (rows.length > 0 ? Object.keys(rows[0]) : []);
      
      return res.json({
        queryId, question, intent: 'DATA', sql: question,
        rowCount: rows.length, rows: rows.slice(0, 100), columns,
        outcomeType: 'query',
        insight: `Raw SQL executed. Found **${rows.length}** records.`,
        durationMs: Date.now() - startTime, raw: true
      });
    } catch (dbErr) {
      console.error(`[Query ${queryId}] Raw SQL error:`, dbErr.message);
      return res.status(400).json({ error: `SQL Execution Error: ${dbErr.message}`, queryId, sql: question });
    }
  }

  // 1. Check Memory (Instant "Learned" Path)
  const memorySql = checkMemory(question);
  if (memorySql) {
    try {
      const result = await pool.query(memorySql);
      const rows = result.rows;
      const columns = result.fields ? result.fields.map(f => f.name) : (rows.length > 0 ? Object.keys(rows[0]) : []);
      return res.json({
        queryId, question, intent: 'DATA', sql: memorySql,
        rowCount: rows.length, rows: rows.slice(0, 100), columns,
        outcomeType: 'query',
        insight: generateInsight(question, rows, rows.length),
        durationMs: Date.now() - startTime, learned: true
      });
    } catch (e) {
      console.warn(`[Query ${queryId}] Memory SQL failed.`);
      recordHermesMistake({
        queryId,
        question,
        outcomeType: 'query',
        stage: 'learned-query-memory',
        failedSql: memorySql,
        error: e.message,
        lesson: 'A saved query-memory mapping failed against the current live schema and should be regenerated from schema-aware context.',
      });
    }
  }

  try {
    const directResult = tryDirectSQL(question);
    if (directResult) {
      const payload = await executeDirectSqlPayload({ queryId, question, directResult, startTime });
      return res.json({ ...payload, fastPath: true });
    }
  } catch (directErr) {
    console.warn(`[Query ${queryId}] Pre-classifier direct path failed:`, directErr.message);
  }

  try {
    // 2. Intent Classification & Semantic Interpreter (Stage 1)
    let context = { intent: 'DATA', confidence: 'low' };
    try {
      const cls = await classifyIntent(question);
      context = cls.context || context;
      if (cls.intent === 'GENERAL') {
        const response = await generalResponse(question);
        return res.json({ queryId, insight: response, intent: 'GENERAL', durationMs: Date.now() - startTime });
      }
      if (cls.intent === 'TECHNICAL_HELP') {
        const response = await technicalGuideResponse(question);
        return res.json({ queryId, insight: response, intent: 'TECHNICAL_HELP', durationMs: Date.now() - startTime });
      }
    } catch (clsErr) {
      console.warn(`[Query ${queryId}] Interpreter failed, continuing with heuristics...`);
    }

    // 3. Try Direct SQL Engine (Stage 2)
    try {
      const directResult = tryDirectSQL(question, context);
      if (directResult) {
        return res.json(await executeDirectSqlPayload({ queryId, question, directResult, startTime, context }));
      }
    } catch (directErr) {
      console.warn(`[Query ${queryId}] Direct Path failed:`, directErr.message);
    }

    // 4. Fallback to LLM Pipeline (Stage 3)
    console.log(`[Query ${queryId}] Final Fallback: LLM Pipeline...`);
    let generatedSql = null;
    try {
      const relevantContext = retrievalAgent(question, context);
      const instruction = `INTENT: ${context.intent}, ENTITIES: ${JSON.stringify(context.entities)}, FILTERS: ${context.filters?.join(', ')}, IS_COUNT: ${context.isCount}, IS_REVENUE: ${context.isRevenue}`;
      
      let result = null;
      let lastDbError = null;
      let firstFailedSql = null;
      let firstDbError = null;
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        if (attempt === 0) {
          generatedSql = await sqlAgent(question, instruction, relevantContext, context);
        } else {
          console.warn(`[Query ${queryId}] Retrying generated SQL after DB error: ${lastDbError.message}`);
          generatedSql = await sqlAgent(question, instruction, relevantContext, context, {
            previousSql: generatedSql,
            error: lastDbError.message,
          });
        }

        try {
          result = await pool.query(generatedSql);
          break;
        } catch (dbErr) {
          lastDbError = dbErr;
          if (!firstDbError) {
            firstDbError = dbErr;
            firstFailedSql = generatedSql;
          }
          if (attempt === MAX_RETRIES) throw dbErr;
        }
      }

      if (firstDbError) {
        recordHermesMistake({
          queryId,
          question,
          outcomeType: 'query',
          stage: 'sql-retry-repaired',
          failedSql: firstFailedSql,
          correctedSql: generatedSql,
          error: firstDbError.message,
          lesson: 'Generated SQL failed once and was repaired by retrying with the PostgreSQL error and live schema.',
        });
      }

      const rows = result.rows;
      const columns = result.fields ? result.fields.map(f => f.name) : (rows.length > 0 ? Object.keys(rows[0]) : []);
      
      // Learn from successful queries
      if (context.businessUtility >= 4) {
        saveToMemory(question, generatedSql);
      }

      let xAxis = 'Category', yAxis = 'Value';
      if (rows.length > 0) {
        const keys = columns;
        xAxis = keys.find(k => k.toLowerCase().includes('name') || k.toLowerCase().includes('month') || k.toLowerCase().includes('shortname')) || keys[0] || 'Category';
        yAxis = keys.find(k => k.toLowerCase().includes('revenue') || k.toLowerCase().includes('value') || k.toLowerCase().includes('total') || k.toLowerCase().includes('count')) || keys[1] || 'Value';
      }

      return res.json({
        queryId, question, intent: 'DATA', sql: generatedSql,
        rowCount: rows.length, rows: rows.slice(0, 100), columns,
        outcomeType: 'query',
        insight: rows.length === 0 
          ? "No records found matching your query. You can copy the SQL below and run it directly in **pgSQL** or **Redash** to debug."
          : generateInsight(question, rows, rows.length),
        durationMs: Date.now() - startTime, llm: true, xAxis, yAxis,
        businessScore: context?.businessUtility || 5
      });
    } catch (llmErr) {
      console.error(`[Query ${queryId}] LLM Pipeline error:`, llmErr.message);
      recordHermesMistake({
        queryId,
        question,
        outcomeType: 'query',
        stage: 'sql-final-failure',
        failedSql: generatedSql,
        error: llmErr.message,
        lesson: 'Final SQL generation or execution failed; future prompts should retrieve this error and avoid the same table/column pattern.',
      });
      
      let columnSuggestion = "";
      if (llmErr.message.includes('column') && llmErr.message.includes('does not exist')) {
        const missingColMatch = llmErr.message.match(/column "(.*?)"/);
        const missingCol = missingColMatch ? missingColMatch[1] : null;
        if (missingCol) {
          try {
            const columnIndex = require('../scripts/column_index.json');
            // Find the table from the SQL
            const tableMatch = (generatedSql || question || '').match(/(?:FROM|JOIN)\s+(?:dbo\.)?(\w+)/i);
            const tableName = tableMatch ? tableMatch[1] : null;
            if (tableName && columnIndex[tableName]) {
              const fuse = new (require('fuse.js'))(columnIndex[tableName], { threshold: 0.4 });
              const bestMatch = fuse.search(missingCol)[0];
              if (bestMatch) {
                columnSuggestion = ` (Did you mean **${bestMatch.item}**?)`;
              }
            }
          } catch (e) { console.warn('Column suggestion failed:', e.message); }
        }
      }

      // ── ALWAYS RETURN SQL ──
      return res.json({
        queryId, question, intent: 'DATA',
        outcomeType: 'query',
        sql: generatedSql || null,
        rows: [], columns: [], rowCount: 0,
        insight: (generatedSql || question)
          ? `SQL execution failed: *${llmErr.message}*${columnSuggestion}. You can copy the SQL below and run it directly in **pgSQL** or **Redash** to debug.`
          : `I'm currently having trouble connecting to my AI providers. Try asking something simpler like "Show all accounts".`,
        error: llmErr.message,
        durationMs: Date.now() - startTime
      });
    }

  } catch (err) {
    console.error(`[Query ${queryId}] CRITICAL ERROR:`, err.message);
    res.status(500).json({ error: 'System error. Please retry in a moment.', queryId });
  }
});

router.post('/stream', async (req, res) => {
  const { question } = req.body;
  const outcomeType = normalizeOutcomeType(req.body?.outcomeType);

  if (!question || typeof question !== 'string' || question.trim().length < 2) {
    return res.status(400).json({ error: 'Please provide a valid question.' });
  }

  const queryId = uuidv4();
  const startTime = Date.now();
  res.status(200);
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders?.();

  try {
    sendSse(res, 'accepted', { queryId, outcomeType, elapsedMs: Date.now() - startTime });

    const sourceSummary = getSourceCatalogSummary();
    const spSummary = getSpCatalogSummary();
    sendSse(res, 'catalog', {
      workbookSheets: sourceSummary?.sheetCount || 0,
      coreSheets: sourceSummary?.coreSheets || [],
      spRoutines: spSummary?.summary?.totalRoutines || 0,
      elapsedMs: Date.now() - startTime,
    });

    sendSse(res, 'phase', {
      label: shouldGenerateFunction(question, outcomeType) ? 'Generating PostgreSQL function text' : 'Generating PostgreSQL SELECT query',
      elapsedMs: Date.now() - startTime,
    });

    const payload = await runInternalQuery(question, outcomeType);
    sendSse(res, 'result', payload);
    sendSse(res, 'done', {
      queryId: payload.queryId || queryId,
      durationMs: Date.now() - startTime,
      finalDurationMs: payload.durationMs,
    });
  } catch (err) {
    const payload = err.payload || {};
    sendSse(res, 'error', {
      queryId: payload.queryId || queryId,
      error: payload.error || err.message,
      sql: payload.sql || null,
      durationMs: Date.now() - startTime,
    });
  } finally {
    res.end();
  }
});

module.exports = router;
