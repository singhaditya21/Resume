const { pool } = require('./db');

async function findTables() {
  const keywords = ['incident', 'case', 'activity', 'task', 'phone', 'email', 'campaign', 'marketing'];
  try {
    const res = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'dbo'
      ORDER BY table_name
    `);
    const allTables = res.rows.map(r => r.table_name);
    const filtered = allTables.filter(t => keywords.some(k => t.toLowerCase().includes(k)));
    
    console.log(JSON.stringify(filtered, null, 2));
  } catch (err) {
    console.error('Error:', err.message);
  }
  process.exit(0);
}

findTables();
