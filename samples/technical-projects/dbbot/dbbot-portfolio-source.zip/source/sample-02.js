#!/usr/bin/env node
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
} = require("@modelcontextprotocol/sdk/types.js");
const { pool } = require("./db.js");
const { loadCachedSchema } = require("./schemaDiscovery.js");

class DBBotMcpServer {
  constructor() {
    this.server = new Server(
      {
        name: "db-bot-mcp",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
    
    // Error handling
    this.server.onerror = (error) => console.error("[MCP Error]", error);
    process.on("SIGINT", async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  setupToolHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: "get_schema",
          description: "Get the database schema (tables and columns)",
          inputSchema: {
            type: "object",
            properties: {},
          },
        },
        {
          name: "execute_query",
          description: "Execute a read-only PostgreSQL query",
          inputSchema: {
            type: "object",
            properties: {
              sql: {
                type: "string",
                description: "The SQL query to execute",
              },
            },
            required: ["sql"],
          },
        },
        {
          name: "search_entities",
          description: "Search for specific brand names or regions across accounts and leads",
          inputSchema: {
            type: "object",
            properties: {
              query: {
                type: "string",
                description: "The brand name or region to search for (e.g. 'CUSTOMER_REDACTED')",
              },
            },
            required: ["query"],
          },
        },
      ],
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      switch (request.params.name) {
        case "get_schema":
          return this.handleGetSchema();
        case "execute_query":
          return this.handleExecuteQuery(request.params.arguments.sql);
        case "search_entities":
          return this.handleSearchEntities(request.params.arguments.query);
        default:
          throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${request.params.name}`);
      }
    });
  }

  async handleGetSchema() {
    const cached = loadCachedSchema();
    if (!cached || !cached.tables) {
      return {
        content: [{ type: "text", text: "Schema not yet discovered." }],
      };
    }
    const schemaText = Object.entries(cached.tables)
      .map(([name, def]) => {
        const cols = def.columns.map(c => `${c.name} (${c.type})`).join(", ");
        return `${name}: [${cols}]`;
      })
      .join("\n");
    return {
      content: [{ type: "text", text: schemaText }],
    };
  }

  async handleExecuteQuery(sql) {
    // Simple safety check
    const forbidden = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT", "GRANT", "REVOKE"];
    if (forbidden.some(word => sql.toUpperCase().includes(word))) {
      return {
        content: [{ type: "text", text: "Error: Only SELECT queries are permitted via MCP." }],
        isError: true,
      };
    }

    try {
      const result = await pool.query(sql);
      return {
        content: [{ type: "text", text: JSON.stringify(result.rows, null, 2) }],
      };
    } catch (error) {
      return {
        content: [{ type: "text", text: `SQL Error: ${error.message}` }],
        isError: true,
      };
    }
  }

  async handleSearchEntities(query) {
    const sql = `
      SELECT 'Account' as type, name, shortname, bill_city as location FROM dbo.accounts WHERE name ILIKE $1 OR shortname ILIKE $1
      UNION ALL
      SELECT 'Lead' as type, companyname as name, leadname as shortname, city as location FROM dbo.leads WHERE companyname ILIKE $1
      LIMIT 20
    `;
    try {
      const result = await pool.query(sql, [`%${query}%`]);
      return {
        content: [{ type: "text", text: JSON.stringify(result.rows, null, 2) }],
      };
    } catch (error) {
      return {
        content: [{ type: "text", text: `Search Error: ${error.message}` }],
        isError: true,
      };
    }
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("DB Bot MCP Server running on stdio");
  }
}

const server = new DBBotMcpServer();
server.run().catch(console.error);
