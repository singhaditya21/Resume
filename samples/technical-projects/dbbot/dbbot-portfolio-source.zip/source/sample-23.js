const { pool } = require('./db');

async function checkSchemas() {
  console.log('--- SCHEMA & TABLE SEARCH ---');
  try {
    const res = await pool.query(`
      SELECT table_schema, table_name 
      FROM information_schema.tables 
      WHERE table_name ILIKE '%account%' 
         OR table_name ILIKE '%lead%' 
         OR table_name ILIKE '%opportunity%'
         OR table_name ILIKE '%project%'
      ORDER BY table_schema, table_name
    `);
    
    if (res.rows.length === 0) {
      console.log('No matching tables found.');
    } else {
      res.rows.forEach(r => console.log(` - ${r.table_schema}.${r.table_name}`));
    }
  } catch (err) {
    console.error('Search failed:', err.message);
  } finally {
    process.exit();
  }
}

checkSchemas();
