/**
 * Semantic Parser / Intent Classifier (v2.0)
 * 
 * Uses LLM 8B to interpret the "Meaning" of a question before SQL generation.
 * Extracts Years, Months, Brands, Entities, and Business Utility Scores.
 */

const { getCompletionFast } = require('../utils/providerManager');
const goldViews = require('../semantic/goldViews');

// DATA_KEYWORDS preserved for fast heuristic check
const DATA_KEYWORDS = ['how many', 'count', 'total', 'sum', 'revenue', 'sales', 'leads', 'accounts', 'deals', 'projects'];

/**
 * Parses a question into a structured Semantic Context JSON.
 * Fulfills the "ChatGPT-type Interpreter" request.
 */
async function parseSemanticContext(question) {
  const q = question.toLowerCase();

  // HEURISTIC / REGEX FALLBACK (Always run first or as backup)
  const entities_json = require('../scripts/discovered_entities.json');
  const entities_found = [];
  if (q.includes('lead')) entities_found.push('leads');
  if (q.includes('account')) entities_found.push('accounts');
  if (q.includes('opp') || q.includes('deal')) entities_found.push('opportunities');
  if (q.includes('project')) entities_found.push('projects');

  // Smarter Filter extraction for fallback
  const fallbackFilters = [];
  entities_json.cities.forEach(city => { if (q.includes(city.toLowerCase())) fallbackFilters.push(city); });
  entities_json.brands.slice(0, 100).forEach(brand => { if (q.includes(brand.toLowerCase())) fallbackFilters.push(brand); });

  const regexContext = {
    intent: "DATA",
    entities: entities_found,
    isCount: q.includes('total') || q.includes('count') || q.includes('how many'),
    isRevenue: q.includes('revenue') || q.includes('sales'),
    filters: fallbackFilters,
    year: q.match(/\b(20\d{2})\b/)?.[1] ? parseInt(q.match(/\b(20\d{2})\b/)[1]) : null,
    month: null,
    businessUtility: 5
  };

  const topBrands = entities_json.brands.slice(0, 50).join(', ');
  const topCities = entities_json.cities.slice(0, 30).join(', ');

  const prompt = `Act as a CRM Meaning Interpreter for DB Bot. 
  Your goal is to parse the question: "${question}" into structured JSON.

  KNOWN CONTEXT:
  - Brands: ${topBrands}
  - Cities/Territories: ${topCities}
  - Leads City Column: "Address 1: City"
  - Accounts City Column: "Address 1: City" or "territory"

  EXTRACTION RULES:
  - "entities": Array of business entities mentioned (leads, accounts, opportunities, projects, contacts). Extract ALL that are mentioned.
  - "requested_columns": Array of specific columns or data points the user explicitly asks to see (e.g. "names and emails" -> ["name", "email"]). Leave empty if they just ask for general records or counts.
  - "isCount": Set to TRUE ONLY if the user asks for a grand total, how many, or sum (e.g., "total revenue"). 
  - "isDetail": Set to TRUE if the user asks for "top X", "list", "show all", specific records, or if an ID is present (e.g., "show projects with project id 205" -> isDetail: true, isCount: false).
  - "limit": Extract the number if the user says "top 5", "first 10", etc.
  - "temporal": { "year": number|null, "month": number|null, "operator": ">=", "<=", "=", "between", "after", "since" }.
  - "filters": Extract brand names, cities, regions, or owner names. 
  - "NEGATION_PRIORITY": If a filter matches both a BRAND and a CITY/TERRITORY (e.g., "Mumbai"), and the query context is geographic (e.g., "from Mumbai region", "in Mumbai"), prioritize it as a location filter.
  - "negations": Extract brand names or entities the user wants to EXCLUDE (e.g., after "not", "except", "excluding").
  - "grouping": Array of columns to group by (e.g. "territory", "year", "owner").
  - "isMultiIntent": Set to TRUE if the user asks for two or more distinct things (e.g. "leads and accounts").

  Structure: { 
    "intent": "DATA" | "GENERAL" | "TECHNICAL_HELP", 
    "entities": string[], 
    "requested_columns": string[],
    "isCount": boolean, 
    "isDetail": boolean,
    "isRevenue": boolean, 
    "limit": number | null,
    "filters": string[], 
    "negations": string[],
    "temporal": { "year": number|null, "month": number|null, "operator": string|null, "endYear": number|null },
    "grouping": string[],
    "isMultiIntent": boolean,
  }. 
  - USE "TECHNICAL_HELP" if the user asks "how to", "show me an example of", or asks for SQL syntax help for INSERT, UPDATE, DELETE, or CREATE.
  - USE "GENERAL" for greetings or off-topic talk.
  - USE "DATA" for any request to see CRM records, totals, or trends.

  Return ONLY valid JSON.`;

  try {
    const result = await getCompletionFast({
      messages: [{ role: 'user', content: prompt }],
      temperature: 0,
    });
    
    const jsonStr = result.match(/\{[\s\S]*\}/)?.[0];
    if (jsonStr) {
      const context = JSON.parse(jsonStr);
      // Fallback for older single entity field
      if (!context.entities && context.entity) context.entities = [context.entity];
      if (!context.entities) context.entities = [];
      return context;
    }
    return regexContext;
  } catch (err) {
    console.warn('[SemanticParser] Fast parse failed, using Logic Fallback:', err.message);
    return regexContext;
  }
}

async function generalResponse(question) {
  const entityList = Object.keys(goldViews).map(k => goldViews[k].description || k).join(', ');
  const prompt = `You are DB Bot, a CRM Intelligence expert. 
  Respond to: "${question}" concisely. 
  AVAILABLE DATA: ${entityList}.
  Mention you can help with deep insights on these entities.`;
  try {
    const result = await getCompletionFast({
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
    });
    return result.trim();
  } catch (err) {
    return "Hello! I'm DB Bot. I can help you with CRM data insights for Leads, Accounts, Opportunities, and more. Try asking 'Show opportunities for 2025'.";
  }
}

async function classifyIntent(question) {
  // Simple check to keep compatibility with existing router
  const context = await parseSemanticContext(question);
  return { 
    intent: context.intent || 'DATA', 
    confidence: 'high',
    context // Attach full context for downstream consumption
  };
}

async function technicalGuideResponse(question) {
  const entities = Object.keys(goldViews).map(k => goldViews[k].description).join('\n- ');
  const prompt = `You are DB Bot, a Database and SQL Expert. Respond to: "${question}".
  
  KNOWLEDGE BASE (ENTITIES):
  - ${entities}
  
  RULES:
  1. MAX 3-4 SHORT BULLET POINTS.
  2. PROVIDE ONE CLEAR SQL TEMPLATE.
  3. BE EXTREMELY CONCISE. NO FLUFF.
  
  Structure:
  - Help: Concise action.
  - Query: \`\`\`sql ... \`\`\`
  - Note: 1-sentence tip.`;
  try {
    const result = await getCompletionFast({
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.2,
    });
    return result.trim();
  } catch (err) {
    return "- I can help with SQL scripts and database operations.\n- Could you please specify which table or action you're interested in?\n- Example: 'How do I insert into accounts?'";
  }
}

module.exports = { classifyIntent, parseSemanticContext, generalResponse, technicalGuideResponse };
