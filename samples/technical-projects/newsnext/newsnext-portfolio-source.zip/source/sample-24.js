// One-time-code login: issue, email and verify 6-digit codes.
// Codes live in memory only (a restart just means requesting a fresh code),
// hashed so a memory dump or log never contains a usable code.
import crypto from "crypto";
import { CONFIG } from "../config.js";
import { sendMail, otpEmailHtml } from "./mailer.js";

const pending = new Map();   // email -> { hash, exp, attempts, lastSentAt, sends: [timestamps] }

const hashCode = (email, code) =>
  crypto.createHmac("sha256", CONFIG.webhookSecret).update(email + ":" + code).digest("hex");

function newCode() {
  // crypto-random, never starting with 0 being an issue — pad to fixed length
  const n = crypto.randomInt(0, 10 ** CONFIG.otp.length);
  return String(n).padStart(CONFIG.otp.length, "0");
}

export async function requestOtp(emailRaw) {
  const email = String(emailRaw || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { status: 400, body: { error: "Enter a valid email address." } };
  if (!email.endsWith(CONFIG.allowedDomain)) return { status: 403, body: { error: `Only ${CONFIG.allowedDomain} accounts can sign in.` } };

  const now = Date.now();
  const rec = pending.get(email) || { sends: [] };
  rec.sends = rec.sends.filter((t) => now - t < 3600e3);
  if (rec.lastSentAt && now - rec.lastSentAt < CONFIG.otp.resendCooldownMs) {
    return { status: 429, body: { error: "Please wait a moment before requesting another code.", retryInMs: CONFIG.otp.resendCooldownMs - (now - rec.lastSentAt) } };
  }
  if (rec.sends.length >= CONFIG.otp.maxSendsPerHour) {
    return { status: 429, body: { error: "Too many codes requested for this address. Try again in an hour." } };
  }

  const code = newCode();
  const minutes = Math.round(CONFIG.otp.ttlMs / 60000);

  if (CONFIG.otp.dev) {
    console.log(`  [OTP dev mode] code for ${email}: ${code}`);
  } else {
    try {
      // The code must live only in the message body — subject lines show up in
      // lock-screen banners and inbox previews, where anyone can read them.
      await sendMail({ to: email, subject: "Your NewsNext login code", html: otpEmailHtml(code, minutes) });
    } catch (e) {
      // The demo must not dead-end if the mailbox/SMTP is misconfigured — surface
      // the reason to the server console (with the code, so an admin can unblock
      // a live demo) and a clean message to the user.
      console.log(`  ⚠ OTP email to ${email} failed: ${e.message}`);
      console.log(`    (code was ${code} — fix SMTP creds/allowlist, or run with OTP_DEV=1 while testing)`);
      return { status: 502, body: { error: "Couldn't send the code email. Please try again, or contact IT if this keeps happening." } };
    }
  }

  rec.hash = hashCode(email, code);
  rec.exp = now + CONFIG.otp.ttlMs;
  rec.attempts = 0;
  rec.lastSentAt = now;
  rec.sends.push(now);
  pending.set(email, rec);
  return { status: 200, body: { ok: true, sent: true, expiresInMs: CONFIG.otp.ttlMs, resendInMs: CONFIG.otp.resendCooldownMs, dev: CONFIG.otp.dev || undefined } };
}

export function verifyOtp(emailRaw, codeRaw) {
  const email = String(emailRaw || "").trim().toLowerCase();
  const code = String(codeRaw || "").replace(/\D/g, "");
  const rec = pending.get(email);
  if (!rec || !rec.hash) return { status: 400, body: { error: "No code was requested for this email. Send a code first." } };
  if (Date.now() > rec.exp) { pending.delete(email); return { status: 400, body: { error: "That code has expired. Request a new one." } }; }
  rec.attempts = (rec.attempts || 0) + 1;
  if (rec.attempts > CONFIG.otp.maxVerifyAttempts) { pending.delete(email); return { status: 429, body: { error: "Too many wrong attempts. Request a new code." } }; }
  const a = Buffer.from(hashCode(email, code));
  const b = Buffer.from(rec.hash);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    const left = CONFIG.otp.maxVerifyAttempts - rec.attempts;
    return { status: 400, body: { error: left > 0 ? `Incorrect code — ${left} attempt${left === 1 ? "" : "s"} left.` : "Incorrect code." } };
  }
  pending.delete(email);   // single use
  return { status: 200, body: { ok: true, email } };
}
