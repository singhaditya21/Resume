// diagnose.mjs — quick network diagnostic. Run ON THE SERVER:  node diagnose.mjs
// Tests one representative feed of each kind and prints exactly what happens,
// so we know whether failures are UA-blocking, firewall category blocks,
// proxy requirements, or timeouts.
const TESTS = [
  ["Publisher RSS (TechCrunch)", "https://example.invalid"],
  ["Google News RSS", "https://example.invalid"],
  ["Bing News RSS", "https://example.invalid"],
  ["Reddit RSS", "https://example.invalid"],
  ["YouTube RSS", "https://example.invalid"],
  ["Unsplash image CDN", "https://example.invalid"],
];
const UAS = {
  "browser UA": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/192.0.2.10 Safari/537.36",
  "bot UA": "NewsNext/1.0 (+internal aggregator)",
};
console.log("\nNewsNext network diagnostic\n" + "=".repeat(60));
if (process.env.HTTP_PROXY || process.env.HTTPS_PROXY) {
  console.log(`⚠ Proxy env vars detected (HTTP_PROXY/HTTPS_PROXY) — note that Node's fetch does NOT use them automatically.\n`);
}
for (const [name, url] of TESTS) {
  for (const [uaName, ua] of Object.entries(UAS)) {
    const t0 = Date.now();
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(10000), redirect: "follow", headers: { "User-Agent": ua, "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9" } });
      const body = await r.text();
      const looksFeed = /<(item|entry)[\s>]/i.test(body);
      const looksImg = (r.headers.get("content-type") || "").startsWith("image/");
      console.log(`${r.ok ? "✅" : "❌"} ${name} [${uaName}] → HTTP ${r.status} in ${Date.now() - t0}ms · ${looksFeed ? "valid feed" : looksImg ? "valid image" : "NOT feed/image (" + (r.headers.get("content-type") || "?") + ")"}`);
    } catch (e) {
      console.log(`❌ ${name} [${uaName}] → ${e.name === "TimeoutError" ? "TIMEOUT (10s)" : e.cause?.code || e.message} in ${Date.now() - t0}ms`);
    }
  }
}
console.log("=".repeat(60));
console.log(`Reading the results:
• Google/Bing/Reddit fail with bot UA but work with browser UA → fixed by this build (fetcher now uses a browser UA).
• Everything except publishers fails with ENOTFOUND/ECONNREFUSED/timeout → your firewall blocks those domains server-side; ask IT to allow news.google.com, bing.com, reddit.com, images.unsplash.com — or we stick to publisher feeds.
• Everything fails → outbound needs a corporate proxy; tell me and I'll add proxy support.
Then run:  node verify-sources.mjs  — it disables whatever truly doesn't work, so the header shows an honest count of enabled, verified sources.\n`);
