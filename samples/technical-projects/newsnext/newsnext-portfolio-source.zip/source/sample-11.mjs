// ─────────────────────────────────────────────────────────────────────────
//  NewsNext image-library harvester — DEV-TIME TOOL, run on a machine with
//  internet (NOT the Spark). Pulls license-clean raster photos from Wikimedia
//  Commons into library/images/<concept>/ and library/images/entities/, writing
//  a metadata sidecar (tags + source + license + attribution) for each.
//
//  Usage (from repo root):
//    node scripts/image-harvest/harvest.mjs                 # full run
//    node scripts/image-harvest/harvest.mjs --only=telecom,economy   # subset
//    PER_CONCEPT=6 node scripts/image-harvest/harvest.mjs --only=startups
//    node scripts/image-harvest/harvest.mjs --dry           # no writes
//
//  Quality gate: raster JPEG/PNG/WebP only (magic-byte verified), min width,
//  sane landscape aspect, title-blocklist (no logos/maps/diagrams/flags),
//  global sha1 dedupe (incl. against files already in the library). Idempotent:
//  never overwrites, tops each bucket up to its target. The Commons search API
//  is per-IP rate-limited, so every search is funnelled through one serialized,
//  spaced, back-off gate while image downloads stay concurrent.
//
//  Images are served LOCALLY in production (baked into the repo → Docker image →
//  Spark disk), matching the curated pool — zero runtime internet required.
// ─────────────────────────────────────────────────────────────────────────
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import { CONCEPTS, ENTITIES } from "./worklist.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = process.argv.find((a) => a.startsWith("--repo="))?.slice(7) || path.resolve(__dirname, "..", "..");
const IMG_DIR = path.join(REPO, "library", "images");
const META_DIR = path.join(REPO, "library", "metadata");

const UA = "NewsNext-ImageHarvester/1.0 (internal BusinessNext news dashboard; non-commercial editorial use)";
const PER_CONCEPT = Number(process.env.PER_CONCEPT || 5);
const PER_ENTITY = Number(process.env.PER_ENTITY || 2);
const MIN_W = 1000, MIN_H = 640, MAX_BYTES = 2_600_000;
const CONC = 4;
const DRY = process.argv.includes("--dry");
const ONLY = (process.argv.find((a) => a.startsWith("--only="))?.slice(7) || "").split(",").map((s) => s.trim()).filter(Boolean);

const BAD_TITLE = /\b(logo|icon|favicon|map|diagram|chart|graph|flag|coat[_ ]of[_ ]arms|seal|emblem|svg|screenshot|poster|banner|infographic|clipart|drawing|sketch|cartoon|meme|stamp|coin|plaque|signature|barcode|qr[_ ]code)\b/i;
const OK_MIME = new Set(["image/jpeg", "image/png", "image/webp"]);
const EXT_FOR = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp" };

function sniff(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "image/jpeg";
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "image/png";
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
      buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50) return "image/webp";
  return null;
}
const sha1 = (b) => crypto.createHash("sha1").update(b).digest("hex");
const slug = (s) => String(s).toLowerCase().replace(/\.[^.]+$/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const seen = new Set();
(function seedHashes(dir) {
  let ents = []; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) seedHashes(full);
    else if (/\.(jpe?g|png|webp|avif|gif)$/i.test(e.name)) { try { seen.add(sha1(fs.readFileSync(full))); } catch {} }
  }
})(IMG_DIR);
console.log(`seeded ${seen.size} existing image hashes for dedupe`);

// Serialized, spaced, retrying gate over the rate-limited Commons search API.
let apiChain = Promise.resolve();
let lastApi = 0;
async function apiRaw(query) {
  const u = new URL("https://example.invalid");
  u.search = new URLSearchParams({
    action: "query", format: "json", generator: "search",
    gsrsearch: `filetype:bitmap ${query}`, gsrnamespace: "6", gsrlimit: "24",
    prop: "imageinfo", iiprop: "url|size|mime|extmetadata", iiurlwidth: "1280",
  }).toString();
  for (let attempt = 0; attempt < 5; attempt++) {
    const wait = Math.max(0, 1100 - (Date.now() - lastApi));
    if (wait) await sleep(wait);
    lastApi = Date.now();
    const r = await fetch(u, { headers: { "User-Agent": UA, "Accept": "application/json" } });
    if (r.status === 429) { const ra = Number(r.headers.get("retry-after")) || Math.pow(2, attempt + 1); await sleep(ra * 1000); continue; }
    if (!r.ok) throw new Error(`API ${r.status}`);
    const j = await r.json();
    return Object.values(j?.query?.pages || {});
  }
  throw new Error("429 after retries");
}
function api(query) {
  const p = apiChain.then(() => apiRaw(query), () => apiRaw(query));
  apiChain = p.catch(() => {});
  return p;
}

function candidatesFrom(pages) {
  const out = [];
  for (const p of pages) {
    const ii = p.imageinfo?.[0]; if (!ii) continue;
    const title = p.title || "";
    if (BAD_TITLE.test(title)) continue;
    if (!OK_MIME.has(ii.mime)) continue;
    if ((ii.width || 0) < MIN_W || (ii.height || 0) < MIN_H) continue;
    const ar = ii.width / ii.height;
    if (ar < 1.05 || ar > 2.2) continue;
    const md = ii.extmetadata || {};
    out.push({
      title,
      thumb: ii.thumburl || ii.url,
      desc: ii.descriptionurl || "",
      license: (md.LicenseShortName?.value || md.UsageTerms?.value || "see Commons file page").replace(/<[^>]+>/g, "").slice(0, 80),
      artist: (md.Artist?.value || "").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 120),
      ar,
    });
  }
  return out.sort((a, b) => Math.abs(1.6 - a.ar) - Math.abs(1.6 - b.ar));
}

async function fetchImage(url) {
  let r;
  for (let attempt = 0; attempt < 3; attempt++) {
    r = await fetch(url, { headers: { "User-Agent": UA } });
    if (r.status === 429) { await sleep((attempt + 1) * 1500); continue; }
    break;
  }
  if (!r.ok) throw new Error(`img ${r.status}`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length > MAX_BYTES || buf.length < 6000) return null;
  const mime = sniff(buf);
  if (!mime || !OK_MIME.has(mime)) return null;
  return { buf, mime };
}

async function harvestBucket(destDir, metaDir, baseName, queries, tags, want, extraTagFullName) {
  fs.mkdirSync(destDir, { recursive: true });
  fs.mkdirSync(metaDir, { recursive: true });
  let got = 0, tried = 0;
  for (const q of queries) {
    if (got >= want) break;
    let pages;
    try { pages = await api(q); } catch (e) { console.log(`   ! api "${q}": ${e.message}`); continue; }
    for (const c of candidatesFrom(pages)) {
      if (got >= want) break;
      tried++;
      let img;
      try { img = await fetchImage(c.thumb); } catch { img = null; }
      if (!img) continue;
      const h = sha1(img.buf);
      if (seen.has(h)) continue;
      seen.add(h);
      const fname = `${baseName}-${slug(c.title) || "img"}${EXT_FOR[img.mime]}`.replace(/-+/g, "-");
      const fpath = path.join(destDir, fname);
      if (fs.existsSync(fpath)) continue;
      const sidecar = {
        tags: extraTagFullName ? [extraTagFullName, ...tags] : tags,
        concept: baseName,
        source: "wikimedia-commons",
        sourceUrl: c.desc,
        license: c.license,
        attribution: c.artist || undefined,
        addedAt: process.env.HARVEST_DATE || "2026-08-25",
      };
      if (!DRY) {
        fs.writeFileSync(fpath, img.buf);
        const sp = path.join(metaDir, fname + ".json");
        fs.mkdirSync(path.dirname(sp), { recursive: true });
        fs.writeFileSync(sp, JSON.stringify(sidecar, null, 2));
      }
      got++;
      await sleep(120);
    }
  }
  return { got, tried };
}

let addedC = 0, addedE = 0;
async function run() {
  const cEntries = Object.entries(CONCEPTS).filter(([c]) => !ONLY.length || ONLY.includes(c));
  if (cEntries.length) {
    console.log(`\n== CONCEPTS (${cEntries.length}) — +${PER_CONCEPT} each ==`);
    for (let i = 0; i < cEntries.length; i += CONC) {
      await Promise.all(cEntries.slice(i, i + CONC).map(([c, def]) =>
        harvestBucket(path.join(IMG_DIR, c), path.join(META_DIR, c), c, def.queries, def.tags, PER_CONCEPT)
          .then((r) => { console.log(`  ${c}: +${r.got} (tried ${r.tried})`); addedC += r.got; })
          .catch((e) => console.log(`  ${c}: ERR ${e.message}`))));
    }
  }
  const doEntities = !ONLY.length || ONLY.includes("entities");
  if (doEntities) {
    console.log(`\n== ENTITIES (${ENTITIES.length}) — +${PER_ENTITY} each ==`);
    for (let i = 0; i < ENTITIES.length; i += CONC) {
      await Promise.all(ENTITIES.slice(i, i + CONC).map((e) =>
        harvestBucket(path.join(IMG_DIR, "entities"), path.join(META_DIR, "entities"),
          slug(e.name), e.queries, e.tags, PER_ENTITY, e.name.toLowerCase())
          .then((r) => { console.log(`  ${e.name}: +${r.got} (tried ${r.tried})`); addedE += r.got; })
          .catch((err) => console.log(`  ${e.name}: ERR ${err.message}`))));
    }
  }
  console.log(`\nDONE${DRY ? " (dry)" : ""}: +${addedC} concept images, +${addedE} entity images`);
}
run();
