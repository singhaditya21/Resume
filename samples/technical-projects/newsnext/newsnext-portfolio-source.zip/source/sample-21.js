// The one HTML-entity decoder for all inbound text (feed titles/summaries,
// publisher previews). Guarantee: any character a publisher writes — any
// language, any encoding style — renders as itself, never as "&#xF8;".
//
//  - Hex (&#xF8;) and decimal (&#248;) numeric entities via fromCodePoint:
//    the complete Unicode range (accents, non-Latin scripts, emoji).
//  - The COMPLETE Latin-1 named set (all 96, &nbsp; through &yuml;),
//    generated from the spec order — no hand-picked subset to miss one.
//  - The HTML4 symbol/typographic set feeds actually use.
//  - Two passes, because aggregators double-encode (&amp;#xF8; → ø).
//  - Unknown names pass through untouched (never corrupt literal text).
//
// Covered by test-entities.mjs, which runs in CI — a regression here fails
// the build, so the Ler&#xF8;y class of bug cannot ship again.

const NAMED = Object.create(null);

// Latin-1: codepoints 160–255 in spec order — complete by construction.
"nbsp iexcl cent pound curren yen brvbar sect uml copy ordf laquo not shy reg macr deg plusmn sup2 sup3 acute micro para middot cedil sup1 ordm raquo frac14 frac12 frac34 iquest Agrave Aacute Acirc Atilde Auml Aring AElig Ccedil Egrave Eacute Ecirc Euml Igrave Iacute Icirc Iuml ETH Ntilde Ograve Oacute Ocirc Otilde Ouml times Oslash Ugrave Uacute Ucirc Uuml Yacute THORN szlig agrave aacute acirc atilde auml aring aelig ccedil egrave eacute ecirc euml igrave iacute icirc iuml eth ntilde ograve oacute ocirc otilde ouml divide oslash ugrave uacute ucirc uuml yacute thorn yuml"
  .split(" ").forEach((name, i) => { NAMED[name] = String.fromCodePoint(160 + i); });

// Core markup + HTML4 typographic, symbol and currency entities.
Object.assign(NAMED, {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'",
  OElig: "Œ", oelig: "œ", Scaron: "Š", scaron: "š", Yuml: "Ÿ",
  circ: "ˆ", tilde: "˜", ensp: " ", emsp: " ", thinsp: " ",
  zwnj: "‌", zwj: "‍", lrm: "‎", rlm: "‏",
  ndash: "–", mdash: "—", lsquo: "‘", rsquo: "’", sbquo: "‚",
  ldquo: "“", rdquo: "”", bdquo: "„", dagger: "†", Dagger: "‡",
  bull: "•", hellip: "…", permil: "‰", prime: "′", Prime: "″",
  lsaquo: "‹", rsaquo: "›", oline: "‾", frasl: "⁄", euro: "€",
  trade: "™", minus: "−", lowast: "∗", radic: "√", infin: "∞",
  ne: "≠", le: "≤", ge: "≥", asymp: "≈", equiv: "≡",
  larr: "←", uarr: "↑", rarr: "→", darr: "↓", harr: "↔",
  loz: "◊", spades: "♠", clubs: "♣", hearts: "♥", diams: "♦",
  sum: "∑", prod: "∏", int: "∫", part: "∂", deg: "°", plusmn: "±",
});

function decodeOnce(s) {
  return s
    .replace(/&#[xX]([0-9a-fA-F]+);/g, (_, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return " "; } })
    .replace(/&#(\d+);/g, (_, n) => { try { return String.fromCodePoint(+n); } catch { return " "; } })
    // Name lookup tolerates sloppy casing: exact form first, then the
    // capitalized variant (&OSLASH; → Ø, not ø), then lowercase.
    .replace(/&([a-zA-Z][a-zA-Z0-9]{1,10});/g, (m, name) =>
      NAMED[name] ?? NAMED[name[0] + name.slice(1).toLowerCase()] ?? NAMED[name.toLowerCase()] ?? m);
}

/** Decode every HTML entity form a feed can carry. Idempotent on clean text. */
export function decodeEntities(s = "") {
  return decodeOnce(decodeOnce(String(s)));
}
