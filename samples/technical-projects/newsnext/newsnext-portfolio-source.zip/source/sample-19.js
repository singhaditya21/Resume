// Default GuardRail blocklist — English + Hindi (romanized and Devanagari).
// Admins can add/remove terms in Governance → Content Moderation; this list is
// what ships out of the box. Matching is normalized (case, leetspeak, spaced-out
// letters, repeated characters) with word boundaries, so "F.U.C.K", "fuKKK" and
// "BHOSDIKE" are all caught while "Scunthorpe" or "assessment" are not.
export const DEFAULT_BLOCKED_TERMS = [
  // --- English profanity / abuse ---
  "fuck", "fucker", "fucking", "motherfucker", "fck", "fuk", "wtf",
  "shit", "bullshit", "shitty", "shithead",
  "bitch", "bastard", "asshole", "arsehole", "dumbass", "jackass",
  "dick", "dickhead", "prick", "cock", "pussy", "cunt", "twat", "wanker",
  "slut", "whore", "hoe", "skank",
  "retard", "retarded", "moron", "idiot", "stupid", "loser", "scum", "douchebag",
  "screw you", "piss off", "go to hell", "shut up",
  "kys", "kill yourself", "kill you", "hate you", "kill",
  "nigger", "nigga", "faggot", "fag",
  "nsfw", "porn", "nudes", "scam", "slur",
  // --- Hindi (romanized) ---
  "chutiya", "chutiye", "chutia", "chutiyapa",
  "bhosdi", "bhosdike", "bhosdi ke", "bhosadike", "bhosda", "bsdk",
  "bhenchod", "behenchod", "behan chod", "bhen chod", "benchod", "bc",
  "madarchod", "maderchod", "madar chod", "mc", "mkc",
  "gandu", "gaandu", "gand", "gaand", "gand mara", "gaand mara",
  "lund", "lauda", "laude", "lode", "lodu", "loda",
  "jhant", "jhaant", "jhatu", "jhaatu",
  "randi", "raand", "chinal", "chhinal", "rakhail",
  "saala", "saale", "sala kutta",
  "kutta", "kutte", "kutiya",
  "kamina", "kamine", "kaminey",
  "harami", "haramkhor", "haramzada", "haraamzada", "haramzade",
  "chod", "chodu", "chut", "choot", "chutad",
  "tatti", "bhadwa", "bhadwe", "hijra", "chakka",
  "suar ki aulad", "teri maa", "teri maa ki", "maa ki chut", "behen ki", "betichod",
  // --- Hindi (Devanagari) ---
  "चूतिया", "चुतिया", "चूतिये",
  "भोसड़ी", "भोसड़ीके", "भोसड़ा", "भोसडी",
  "भेनचोद", "बहनचोद", "बहन चोद",
  "मादरचोद", "मादर चोद",
  "गांडू", "गांड", "गाँड",
  "लंड", "लौड़ा", "लोड़े", "लौड़े",
  "झांट", "झाटू",
  "रंडी", "रांड", "छिनाल",
  "साला", "साले",
  "कुत्ता", "कुत्ते", "कुतिया",
  "कमीना", "कमीने",
  "हरामी", "हरामखोर", "हरामज़ादा", "हरामजादा",
  "चोद", "चोदू", "चूत",
  "टट्टी", "भड़वा", "भड़वे", "छक्का",
  "तेरी माँ की", "तेरी मां की", "माँ की चूत", "बहन की",
];
