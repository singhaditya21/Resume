// ═══════════════════════════════════════════════════════════════════════════
//  Image Engine · engine.js — orchestration: understand → match → guarantee.
//
//  Pipeline per article (runs server-side once per feed refresh, cached):
//    1. ANALYZE     embed title+summary, extract entities + keywords
//    2. CLASSIFY    cosine vs every taxonomy concept → categories + confidence
//    3. RETRIEVE    hybrid score over candidates from (a) local library,
//                   (b) curated concept pools:
//                      0.55·semantic cosine + 0.25·tag overlap + 0.20·entity/
//                      dept boost − rotation penalty
//    4. DIVERSIFY   batch-local no-repeat + persistent least-recently-used
//    5. GUARANTEE   tier chain: source → library → curated → concept-default
//                   → client-side deterministic gradient (never blank)
//    6. LEARN       count unknown recurring entities; promote to dynamic
//                   taxonomy concepts once seen ≥ PROMOTE_AT times
//
//  All state persists to data/image-engine-state.json (debounced writes).
// ═══════════════════════════════════════════════════════════════════════════
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { embed, embedText, cosine, tokenize, stem, extractEntities, extractKeywords, isProperEntity } from "./text.js";
import { buildConceptIndex, SEED } from "./taxonomy.js";
import { curatedPool } from "./curated.js";
import { scanLibrary, ensureLibraryDirs, libraryStats } from "./library.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STATE_FILE = path.join(__dirname, "..", "..", "data", "image-engine-state.json");
const PROMOTE_AT = 5;          // entity seen in ≥5 DISTINCT articles → dynamic concept
const MATCH_FLOOR = 0.08;      // below this cosine, a concept match is noise
const LOG_MAX = 200;
// Hard ceilings. Every story is re-analysed on every refresh, and a story sits
// in the 48h window for ~288 refreshes — so without "distinct article" counting
// plus these caps, every capitalised phrase in the feed became a concept
// (observed: 48k entities / 19k concepts / 7.8MB state), and analyze() then
// scored every story against all of them: seconds of blocked event loop per
// refresh, growing daily.
const MAX_PROMOTED = 400;      // dynamic concepts kept (oldest pruned first)
const MAX_ENTITIES = 20000;    // entity ledger cap
const ENTITY_TTL = 21 * 864e5; // forget an entity not seen for 3 weeks

// ── persistent state ───────────────────────────────────────────────────────
let state = { usage: {}, entities: {}, promoted: [], log: [], counters: { assigned: 0, bySource: 0, byLibrary: 0, byCurated: 0, byDefault: 0 } };
try { const s = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); state = { ...state, ...s, counters: { ...state.counters, ...(s.counters || {}) } }; } catch { /* fresh */ }
// Enforce the caps against whatever was on disk, not just against growth from
// here: a state file written by an older build (or an interrupted prune) would
// otherwise stay oversized forever and keep every refresh slow.
let prunedJunk = 0;
(function boundLoadedState() {
  // Self-heal: purge concepts the pre-gate learner promoted before the
  // proper-noun gate existed — editorial labels ("Opinion", "Govt"), generic
  // acronyms ("SSL"), outlet names ("The Economic Times"). Runs every startup,
  // so the taxonomy converges to real entities without a manual state reset.
  if (Array.isArray(state.promoted)) {
    const kept = state.promoted.filter((p) => isProperEntity(p.name));
    prunedJunk = state.promoted.length - kept.length;
    state.promoted = kept;
  }
  for (const nm of Object.keys(state.entities || {})) if (!isProperEntity(nm)) delete state.entities[nm];
  // Scrub historical "learn" log lines whose concept no longer survives, so the
  // Engine-log view stops showing "Promoted 'Opinion'" for a concept that's gone.
  if (prunedJunk > 0 && Array.isArray(state.log)) {
    const live = new Set(state.promoted.map((p) => p.name));
    state.log = state.log.filter((l) => {
      if (l.kind !== "learn") return true;
      const m = /"([^"]+)"/.exec(l.msg || "");
      return !m || live.has(m[1]);
    });
  }
  if (Array.isArray(state.promoted) && state.promoted.length > MAX_PROMOTED) {
    for (const p of state.promoted.splice(0, state.promoted.length - MAX_PROMOTED)) delete state.entities[p.name];
  }
  const names = Object.keys(state.entities || {});
  if (names.length > MAX_ENTITIES) {
    names.sort((a, b) => (state.entities[a].count - state.entities[b].count) || ((state.entities[a].last || 0) - (state.entities[b].last || 0)));
    for (const nm of names.slice(0, names.length - MAX_ENTITIES)) delete state.entities[nm];
  }
})();
let saveTimer = null;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(state)); } catch { /* best effort */ }
  }, 800);
}

// ── concept index (seed + promoted dynamic concepts) ───────────────────────
let concepts = rebuildConcepts();
function rebuildConcepts() {
  const dynamic = (state.promoted || []).map((p) => ({
    id: "dyn:" + p.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    domain: p.domain || "general", name: p.name, terms: p.terms, dynamic: true,
    parent: p.parent || "news-general",
  }));
  return buildConceptIndex(dynamic);
}

// Map NewsNext departments to taxonomy domains for a soft prior.
const DEPT_DOMAIN = {
  "Technology / Engineering / IT": ["technology", "ai"], "Finance": ["finance"],
  "Sales / Revenue": ["sales"], "Marketing": ["marketing"], "HR / People": ["people"],
  "Leadership / Strategy": ["leadership"], "Product": ["product"],
  "Customer Success / Support": ["customer"], "Delivery": ["technology"],
  "Legal / Compliance / Risk": ["legal", "technology"], "Operations / Procurement / Admin": ["operations"],
};

// Topic → taxonomy/library concept (mirrors the client). Terse finance headlines
// ("Volex stock surges") embed poorly, so cosine classification misfires; the
// story's TOPIC is a far more reliable signal for choosing a fallback photo.
const TOPIC_CONCEPT = {
  "artificial intelligence": "ai-models", "ai agents": "ai-agents", "generative ai": "genai-media",
  "machine learning": "ml-datasci", "data science": "ml-datasci", "responsible ai": "ai-ethics",
  "cloud operations": "cloud", "system architecture": "cloud", "platform engineering": "software-eng",
  "software engineering": "software-eng", "api development": "software-eng", "enterprise software": "enterprise-saas",
  "digital transformation": "enterprise-saas", "innovation": "startups", "cyber security": "cybersecurity",
  "cybersecurity": "cybersecurity", "business finance": "corp-finance", "corporate finance": "corp-finance",
  "accounting": "PORTFOLIO_REDACTED", "budgeting": "corp-finance", "fp&a": "corp-finance",
  "market intelligence": "markets", "business strategy": "leadership", "enterprise sales": "sales-crm",
  "sales": "sales-crm", "crm": "sales-crm", "customer experience": "customer-exp", "customer success": "customer-exp",
  "demand generation": "marketing-digital", "digital marketing": "marketing-digital", "product marketing": "marketing-brand",
  "product management": "product-mgmt", "product strategy": "product-mgmt", "product launches": "product-mgmt",
  "product design": "ux-design", "procurement": "supply-chain", "policy & compliance": "legal-reg",
  "talent acquisition": "hr-people", "human resources": "hr-people", "employee engagement": "workplace",
  "employee experience": "workplace", "workplace culture": "workplace", "learning & development": "education",
};
// A real, topical, VARIED local photo for a story whose remote source thumbnail
// is blocked. Prefers the topic-mapped concept's own library folder (rotated by
// story id, skipping images already used this batch), then that concept's
// curated pool, then news-general — never a branded SVG placeholder.
function conceptFallbackUrl(s, analysis, batchUsed) {
  let cid = TOPIC_CONCEPT[String(s.topic || "").toLowerCase().trim()];
  if (!cid && analysis && analysis.best && !String(analysis.best.id).startsWith("dyn:")) cid = analysis.best.id;
  cid = cid || "news-general";
  const rotate = (arr) => {
    if (!arr || !arr.length) return null;
    const start = Math.abs(hashStr(s.id)) % arr.length;
    for (let i = 0; i < arr.length; i++) { const u = arr[(start + i) % arr.length]; if (!batchUsed.has(u)) return u; }
    return arr[start];
  };
  const lib = scanLibrary().images.filter((im) => im.id.startsWith("lib:" + cid + "/")).map((im) => im.url);
  return rotate(lib) || rotate(curatedPool(cid)) || rotate(curatedPool("news-general"));
}

// ── 1+2: analysis & classification ─────────────────────────────────────────
export function analyze(article) {
  const text = `${article.title} ${article.title} ${article.summary || ""}`; // title ×2
  const vector = embedText(text);
  const entities = extractEntities(`${article.title}. ${article.summary || ""}`);
  const keywords = extractKeywords(article.title, article.summary || "");
  const domains = DEPT_DOMAIN[article.dept] || [];

  const scored = [];
  for (const c of concepts) {
    let s = cosine(vector, c.vector);
    if (domains.includes(c.domain)) s += 0.06;                 // department prior
    if (article.topic && c.terms.toLowerCase().includes(String(article.topic).toLowerCase())) s += 0.05;
    scored.push({ id: c.id, name: c.name, domain: c.domain, score: s, concept: c });
  }
  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 3).filter((c) => c.score > MATCH_FLOOR);
  // Confidence = normalised share of the top-3 mass (interpretable 0..1).
  const mass = top.reduce((a, c) => a + Math.max(c.score, 0), 0) || 1;
  const categories = top.map((c) => ({ id: c.id, name: c.name, domain: c.domain, confidence: +(Math.max(c.score, 0) / mass).toFixed(3), raw: +c.score.toFixed(4) }));
  return { vector, entities, keywords, categories, best: top[0] || null };
}

// ── 3+4: hybrid retrieval with rotation & diversity ────────────────────────
function tagOverlap(keywords, tags) {
  if (!tags.length) return 0;
  const ks = new Set(keywords.map(stem));
  let hit = 0; for (const t of tags) if (ks.has(stem(t))) hit++;
  return hit / Math.sqrt(tags.length * Math.max(ks.size, 1));
}
function rotationPenalty(key) {
  const u = state.usage[key];
  if (!u) return 0;
  const hrs = (Date.now() - u.at) / 3600e3;
  return Math.max(0, 0.18 - hrs * 0.01) + Math.min(u.n, 20) * 0.004; // fades over ~18h
}
function markUsed(key) { const u = state.usage[key] || { n: 0, at: 0 }; u.n++; u.at = Date.now(); state.usage[key] = u; }

function pickImage(analysis, article, batchUsed) {
  const lib = scanLibrary();
  const cands = [];

  // (a) local library candidates — pre-filtered via inverted tag index, so we
  //     score a handful of images, not the whole library.
  if (lib.images.length) {
    const seen = new Set();
    for (const kw of analysis.keywords) {
      for (const img of lib.byTag.get(stem(kw)) || []) {
        if (!seen.has(img.id)) { seen.add(img.id); cands.push({ kind: "library", key: img.id, url: img.url, vec: img.vector, tags: img.tags }); }
      }
    }
    if (!seen.size) for (const img of lib.images.slice(0, 60)) cands.push({ kind: "library", key: img.id, url: img.url, vec: img.vector, tags: img.tags });
  }
  // (b) curated pool of each top concept.
  for (const cat of analysis.categories) {
    const baseId = cat.id.startsWith("dyn:") ? (concepts.find((c) => c.id === cat.id)?.parent || "news-general") : cat.id;
    curatedPool(baseId).forEach((url, i) => {
      cands.push({ kind: "curated", key: "cur:" + baseId + ":" + i, url, vec: null, tags: [], concept: cat, order: i });
    });
  }

  // Batch diversity: images unused this batch win outright; once every
  // candidate has appeared (3,400+ stories share ~320 local images, so the
  // whole-batch "unused" pool WILL exhaust), spread by use count instead —
  // 0.15/use outweighs the 0.2 entity boost after two uses, so fifteen Nvidia
  // stories rotate through their candidates rather than all converging on the
  // top-scored HQ photo. (A binary used/unused set degraded to no diversity at
  // all on saturation; a flat −0.5 lost to the entity boost before it.)
  let pool = cands.filter((c) => !batchUsed.get(c.url));
  if (!pool.length) pool = cands;
  let best = null;
  for (const c of pool) {
    let s;
    if (c.kind === "library") {
      s = 0.55 * cosine(analysis.vector, c.vec) + 0.25 * tagOverlap(analysis.keywords, c.tags) + 0.12; // library priority bump
      for (const e of analysis.entities) if (c.tags.includes(e.name.toLowerCase())) s += 0.2;          // exact entity tag → strong boost
    } else {
      s = 0.55 * (c.concept ? c.concept.raw : 0) + 0.2 * (c.concept ? c.concept.confidence : 0) - c.order * 0.015;
    }
    s -= rotationPenalty(c.key);
    s -= 0.15 * (batchUsed.get(c.url) || 0);                   // spread reuse when the pool is saturated
    if (!best || s > best.s) best = { ...c, s };
  }
  return best;
}

// ── 6: learning loop ───────────────────────────────────────────────────────
const KNOWN = new Set(concepts.flatMap((c) => c.tokens));
// "Seen in 5 distinct articles" means five DIFFERENT stories, not five passes
// over the same story. Each entity remembers which story ids it came from, so
// re-analysing the same feed every 10 minutes never inflates a count.
function learn(analysis, article, ctx) {
  for (const e of analysis.entities) {
    const name = e.name;
    if (name.length < 3 || KNOWN.has(name.toLowerCase()) || !isProperEntity(name)) continue;
    const rec = state.entities[name] || { count: 0, first: Date.now(), domains: {}, ids: [] };
    if (!Array.isArray(rec.ids)) rec.ids = [];           // migrate pre-fix records
    if (rec.ids.includes(article.id)) continue;          // already counted for this story
    rec.ids.push(article.id);
    if (rec.ids.length > PROMOTE_AT) rec.ids = rec.ids.slice(-PROMOTE_AT);
    rec.count = Math.max(rec.count, rec.ids.length);
    rec.last = Date.now();
    const d = analysis.best ? analysis.best.domain : "general";
    rec.domains[d] = (rec.domains[d] || 0) + 1;
    state.entities[name] = rec;
    if (rec.count >= PROMOTE_AT && !state.promoted.some((p) => p.name === name)) {
      const topDomain = Object.entries(rec.domains).sort((a, b) => b[1] - a[1])[0][0];
      const parent = (SEED.find((c) => c.domain === topDomain) || { id: "news-general" }).id;
      state.promoted.push({ name, domain: topDomain, parent, terms: name.toLowerCase(), promotedAt: new Date().toISOString() });
      if (state.promoted.length > MAX_PROMOTED) {
        // Forget the evicted concepts' entity ledgers too: left at
        // count >= PROMOTE_AT they re-promote on the very next sighting, so the
        // cap would thrash the concept index instead of bounding it.
        for (const p of state.promoted.splice(0, state.promoted.length - MAX_PROMOTED)) delete state.entities[p.name];
      }
      // Rebuilding the whole concept index per promotion is quadratic during a
      // burst — flag it and rebuild once when the batch finishes.
      if (ctx) ctx.dirty = true; else concepts = rebuildConcepts();
      log("learn", `Promoted new concept "${name}" (domain: ${topDomain})`);
    }
  }
}

// Keep the entity ledger from growing without bound: drop anything stale, then
// the least-seen if still over cap.
function pruneEntities() {
  const names = Object.keys(state.entities);
  if (names.length <= MAX_ENTITIES) return;
  const cutoff = Date.now() - ENTITY_TTL;
  for (const n of names) { const r = state.entities[n]; if ((r.last || r.first || 0) < cutoff) delete state.entities[n]; }
  const left = Object.keys(state.entities);
  if (left.length > MAX_ENTITIES) {
    left.sort((a, b) => (state.entities[a].count - state.entities[b].count) || ((state.entities[a].last || 0) - (state.entities[b].last || 0)));
    for (const n of left.slice(0, left.length - MAX_ENTITIES)) delete state.entities[n];
  }
}

// ── logging ────────────────────────────────────────────────────────────────
function log(kind, msg, extra = {}) {
  state.log.unshift({ at: new Date().toISOString(), kind, msg, ...extra });
  if (state.log.length > LOG_MAX) state.log.length = LOG_MAX;
}

// ── public API ─────────────────────────────────────────────────────────────
ensureLibraryDirs();
if (prunedJunk > 0) { log("prune", `Cleaned ${prunedJunk} low-quality concept${prunedJunk === 1 ? "" : "s"} from the taxonomy`); persist(); }

// Attach an image to every story that lacks one. Runs once per refresh batch.
export function attachImages(stories) {
  // url -> times used this batch. Map, not Set: with far more stories than
  // local images, "used at least once" saturates — the COUNT drives spreading.
  const batchUsed = new Map();
  const useUrl = (u) => batchUsed.set(u, (batchUsed.get(u) || 0) + 1);
  const ctx = { dirty: false };
  let filled = 0;
  for (const s of stories) {
    let analysis;
    try { analysis = analyze(s); } catch { analysis = null; }
    if (analysis) { learn(analysis, s, ctx); s.imgCategories = analysis.categories; }
    // Stories replayed from the per-source last-known-good cache arrive with
    // the ENGINE's own earlier pick still in thumbnailUrl. Treating that as a
    // "source" image freezes stale assignments (five Nvidia cards kept the
    // same HQ photo) and inflates bySource. Recognize our own local URLs and
    // re-pick, so batch diversity and matching improvements apply every refresh.
    if (s.thumbnailUrl && /^\/(library\/images|assets\/(curated|ph))\//.test(s.thumbnailUrl)) s.thumbnailUrl = null;
    if (s.thumbnailUrl) {
      s.imgTier = "source"; state.counters.bySource++; useUrl(s.thumbnailUrl);
      // Some CDNs (e.g. content-media.investing.com) hard-block server-side
      // fetches, so the proxied source thumbnail 404s in the browser. Attach a
      // real, topical, varied local photo the client can swap in on error —
      // never the generic branded SVG placeholder.
      try { const fb = conceptFallbackUrl(s, analysis, batchUsed); if (fb) { s.imgFallback = fb; useUrl(fb); } } catch { /* fallback is best-effort */ }
      continue;
    }
    let choice = null;
    if (analysis && analysis.categories.length) { try { choice = pickImage(analysis, s, batchUsed); } catch { choice = null; } }
    if (choice) {
      s.thumbnailUrl = choice.url;
      s.imgTier = choice.kind;                                  // "library" | "curated"
      markUsed(choice.key); useUrl(choice.url);
      state.counters[choice.kind === "library" ? "byLibrary" : "byCurated"]++;
      filled++;
    } else {
      // Tier 4: concept-default pool; ultimate tier 5 = client gradient (never blank).
      const pool = curatedPool("news-general");
      const url = pool[(Math.abs(hashStr(s.id)) % pool.length)];
      if (!batchUsed.has(url)) { s.thumbnailUrl = url; useUrl(url); }
      else s.thumbnailUrl = pool[(Math.abs(hashStr(s.id)) + 1) % pool.length];
      s.imgTier = "default"; state.counters.byDefault++; filled++;
    }
    state.counters.assigned++;
  }
  if (filled) log("assign", `Filled ${filled}/${stories.length} missing thumbnails`, { filled, total: stories.length });
  if (ctx.dirty) concepts = rebuildConcepts();   // one rebuild per batch, not per promotion
  pruneEntities();
  persist();
  return stories;
}
function hashStr(x) { let h = 0; const s = String(x); for (let i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; } return h; }

export function engineStats() {
  const lib = libraryStats();
  const topEntities = Object.entries(state.entities).sort((a, b) => b[1].count - a[1].count).slice(0, 25)
    .map(([name, r]) => ({ name, count: r.count, domain: Object.entries(r.domains).sort((a, b) => b[1] - a[1])[0]?.[0] || "general" }));
  return {
    counters: state.counters,
    taxonomy: { seed: SEED.length, dynamic: state.promoted.length, total: concepts.length },
    library: lib,
    curatedPoolSize: Object.values(state.usage).length,
    promoted: state.promoted.slice(-25).reverse(),
    topEntities,
    log: state.log.slice(0, 30),
  };
}

export function reindex() {
  const lib = scanLibrary(true);
  concepts = rebuildConcepts();
  log("reindex", `Manual reindex: ${lib.images.length} library images, ${concepts.length} concepts`);
  persist();
  return { images: lib.images.length, concepts: concepts.length };
}
