// Per-user saved data — reading list (with story snapshots), likes, interests,
// theme. One row per email in the userdata table of data/newsnext.db, so
// every user's data is theirs alone: a save writes THAT person's row and no
// one else's, committed to disk the moment it happens (write-through — no
// debounce window to lose). Reads are a single primary-key lookup.
//
// The client keeps localStorage as an instant cache and syncs here; on
// sign-in the two are merged.
import { db } from "./db.js";

const MAX_SAVED = 200;      // per user
const MAX_LIKED = 2000;
const SAVE_TTL_MS = 15 * 864e5;   // the Reading List's promised 15-day shelf life

const _get = db.prepare("SELECT value FROM userdata WHERE email = ?");
const _put = db.prepare(
  "INSERT INTO userdata(email,value,updatedAt) VALUES(?,?,?) " +
  "ON CONFLICT(email) DO UPDATE SET value = excluded.value, updatedAt = excluded.updatedAt");

// Enforce the 15-day expiry the UI promises. Entries saved before the `at`
// timestamp existed are stamped now (their clock starts today — generous, never
// destructive). Returns the pruned list, or null when nothing changed.
function pruneSaved(list) {
  if (!Array.isArray(list)) return null;
  const now = Date.now();
  let changed = false;
  const out = [];
  for (let e of list) {
    let at = Date.parse(e.at || "");
    if (isNaN(at)) { e = { ...e, at: new Date(now).toISOString() }; at = now; changed = true; }
    if (now - at < SAVE_TTL_MS) out.push(e); else changed = true;
  }
  return changed ? out : null;
}

const str = (v, m) => String(v == null ? "" : v).trim().slice(0, m);
// The snapshot is what keeps a saved story readable after it leaves the live
// 48-hour news window — enough fields to render the card and open the source.
function cleanStory(s) {
  if (!s || typeof s !== "object") return null;
  return {
    id: str(s.id, 200), title: str(s.title, 300), source: str(s.source, 120),
    link: str(s.link, 600), thumbnailUrl: str(s.thumbnailUrl, 600),
    topic: str(s.topic, 80), dept: str(s.dept, 80), type: str(s.type, 40),
    published: str(s.published, 40), summary: str(s.summary, 400),
  };
}

function rowFor(key) {
  const row = _get.get(key);
  if (!row) return null;
  try { return JSON.parse(row.value); } catch { return null; }
}
function persist(key, u) { _put.run(key, JSON.stringify(u), u.updatedAt || new Date().toISOString()); }

export function getUserData(email) {
  const key = String(email || "").toLowerCase();
  const u = rowFor(key);
  // Expiry applies on read too, so saves age out even for someone who only
  // ever opens the list — and the deletion is persisted, not just cosmetic.
  if (u) { const pruned = pruneSaved(u.saved); if (pruned) { u.saved = pruned; persist(key, u); } }
  return u || { saved: [], liked: [], topics: [], theme: null, updatedAt: null };
}

export function setUserData(email, { saved, liked, topics, theme } = {}) {
  const key = String(email || "").toLowerCase();
  const cur = rowFor(key) || {};
  let nextSaved = Array.isArray(saved)
    ? saved.slice(0, MAX_SAVED).map((e) => ({ id: str(e.id, 200), savedAt: str(e.savedAt, 40), at: str(e.at, 40), story: cleanStory(e.story) })).filter((e) => e.id)
    : cur.saved || [];
  nextSaved = pruneSaved(nextSaved) || nextSaved;
  const next = {
    saved: nextSaved,
    liked: Array.isArray(liked) ? [...new Set(liked.map((x) => str(x, 200)))].slice(0, MAX_LIKED) : cur.liked || [],
    topics: Array.isArray(topics) ? topics.slice(0, 40).map((t) => str(t, 60)).filter(Boolean) : cur.topics || [],
    theme: theme === undefined ? (cur.theme ?? null) : (theme === null ? null : str(theme, 20)),
    updatedAt: new Date().toISOString(),
  };
  persist(key, next);
  return next;
}
