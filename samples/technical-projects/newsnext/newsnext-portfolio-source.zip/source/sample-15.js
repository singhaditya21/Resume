// Zero-dependency .env loader. The README has always said "copy to .env or
// export these", but nothing actually read the file — every value had to be a
// real environment variable. This closes that gap: KEY=VALUE lines from .env
// become process.env defaults (real environment variables still win).
//
// Imported FIRST in server.js, before config.js reads process.env.
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", ".env");
try {
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const eq = t.indexOf("=");
    if (eq < 1) continue;
    const key = t.slice(0, eq).trim();
    let val = t.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (!(key in process.env)) process.env[key] = val;
  }
} catch { /* no .env — fine, real env vars only */ }
