// Governance activity log — the record of who changed what, and when.
//
// Every change that alters how NewsNext behaves for other people is appended
// here: role grants, source add/remove, GuardRail rule edits, approval
// decisions and report resolutions. Each entry says whether the change was
// applied directly (a super admin) or went through the approval queue, so the
// log answers "who did this, and was it signed off?" without cross-referencing
// three other stores.
//
// Rows in the activity table of data/newsnext.db — append-only from the app's
// point of view, indexed newest-first, capped so it can never grow unbounded.
import { db } from "./db.js";

const MAX = 2000;               // newest kept; older rows fall off the end

const str = (v, n) => String(v == null ? "" : v).trim().slice(0, n);

const _ins = db.prepare("INSERT INTO activity(id,at,actor,action,summary,via,meta) VALUES(?,?,?,?,?,?,?)");
const _trim = db.prepare(
  "DELETE FROM activity WHERE id IN (SELECT id FROM activity ORDER BY at DESC LIMIT -1 OFFSET ?)");
const _list = db.prepare("SELECT * FROM activity ORDER BY at DESC LIMIT ?");
const _listByAction = db.prepare("SELECT * FROM activity WHERE action LIKE ? ORDER BY at DESC LIMIT ?");
const _count = db.prepare("SELECT COUNT(*) AS n FROM activity");
const _countSince = db.prepare("SELECT COUNT(*) AS n FROM activity WHERE at > ?");
const _countVia = db.prepare("SELECT COUNT(*) AS n FROM activity WHERE via = ?");

const shape = (r) => ({
  id: r.id, at: r.at, actor: r.actor, action: r.action, summary: r.summary, via: r.via,
  meta: r.meta ? JSON.parse(r.meta) : null,
});

/**
 * Record one governance action.
 * @param actor    who did it (email)
 * @param action   short machine-ish verb: "role.change", "source.add",
 *                 "source.remove", "guardrail.update", "approval.approve",
 *                 "approval.reject", "report.resolve", "report.dismiss"
 * @param summary  one human line: "Made x@y an Admin"
 * @param via      "direct" (applied immediately) | "approval" (via the queue)
 *                 | "request" (queued, not yet applied)
 * @param meta     small extra detail (target email, source id, scope…)
 */
export function logActivity({ actor, action, summary, via = "direct", meta = null }) {
  try {
    _ins.run(
      "ac-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      new Date().toISOString(),
      str(actor, 160), str(action, 40), str(summary, 300), str(via, 12),
      meta && typeof meta === "object" ? JSON.stringify(meta) : null);
    _trim.run(MAX);
  } catch (e) { console.log("  ⚠ activity log:", e.message); }
}

/** Newest-first slice of the log, optionally filtered by action prefix. */
export function listActivity({ limit = 200, action = "" } = {}) {
  const n = Math.max(1, Math.min(1000, limit));
  const rows = action ? _listByAction.all(action + "%", n) : _list.all(n);
  return rows.map(shape);
}

/** Counts for the summary tiles — indexed queries, cheap on every read. */
export function activityStats() {
  return {
    total: Number(_count.get().n),
    last24h: Number(_countSince.get(new Date(Date.now() - 864e5).toISOString()).n),
    viaApproval: Number(_countVia.get("approval").n),
    direct: Number(_countVia.get("direct").n),
  };
}
