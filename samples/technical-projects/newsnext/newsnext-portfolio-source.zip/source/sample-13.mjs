// test-entities.mjs — CI gate for HTML-entity decoding (runs in Jenkins).
// If any of these fail, the build fails: the "Ler&#xF8;y" class of bug can
// never ship again. Run locally with:  node test-entities.mjs
import { decodeEntities } from "./lib/entities.js";

const CASES = [
  // The original bug, in every encoding a feed can use
  ["Ler&#xF8;y Seafood", "Lerøy Seafood"],
  ["Ler&#XF8;y UPPERCASE-X hex", "Lerøy UPPERCASE-X hex"],
  ["Ler&#xf8;y lowercase hex digits", "Lerøy lowercase hex digits"],
  ["Ler&#248;y Seafood", "Lerøy Seafood"],
  ["Ler&oslash;y Seafood", "Lerøy Seafood"],
  ["Ler&Oslash;y capital form", "LerØy capital form"],
  ["Ler&OSLASH;y all-caps name", "LerØy all-caps name"],
  ["caf&EACUTE; all-caps accent", "cafÉ all-caps accent"],
  ["Ler&amp;#xF8;y (double-encoded)", "Lerøy (double-encoded)"],
  ["Ler&amp;oslash;y (double-encoded)", "Lerøy (double-encoded)"],
  // Every Latin-1 named entity family (spot checks across the generated set)
  ["&Agrave;&aacute;&Acirc;&atilde;&Auml;&aring;&AElig;&ccedil;", "Àá́ÂãÄåÆç".normalize("NFC").replace("á́", "á")],
  ["caf&eacute; &mdash; d&eacute;j&agrave; vu", "café — déjà vu"],
  ["&Egrave;&ecirc;&euml; &Iacute;&icirc;&iuml;", "Èêë Íîï"],
  ["&Ntilde;o&ntilde;o &Ograve;&oacute;&ocirc;&otilde;&ouml;", "Ñoño Òóôõö"],
  ["&Ugrave;&uacute;&ucirc;&uuml; &yacute;&yuml;", "Ùúûü ýÿ"],
  ["&THORN;&thorn;&ETH;&eth;&szlig;", "ÞþÐðß"],
  ["50&deg; &plusmn;2 &frac12; &sup2;", "50° ±2 ½ ²"],
  ["&pound;5 &euro;10 &yen;100 &cent;99 &curren;", "£5 €10 ¥100 ¢99 ¤"],
  ["&copy; &reg; &trade; &sect; &para; &middot; &laquo;quote&raquo;", "© ® ™ § ¶ · «quote»"],
  // Typographic set
  ["&ldquo;Hi&rdquo; &lsquo;there&rsquo; &ndash; ok&hellip; &bull; &dagger;", "“Hi” ‘there’ – ok… • †"],
  ["&OElig;uvre &oelig;uvre &Scaron;&scaron; &Yuml;", "Œuvre œuvre Šš Ÿ"],
  // Numeric across scripts and planes
  ["&#26085;&#26412; news", "日本 news"],
  ["&#x1F4F0; newspaper emoji", "📰 newspaper emoji"],
  ["&#x439;&#x43E; cyrillic", "йо cyrillic"],
  // Core markup entities
  ["A &amp; B &lt;tag&gt; &quot;q&quot; &apos;a&apos;", `A & B <tag> "q" 'a'`],
  // Unknown names must pass through untouched — never corrupt literal text
  ["R&D; stays as-is &notarealentity; too", "R&D; stays as-is &notarealentity; too"],
  // Idempotent on clean text
  ["Already clean: Lerøy — café ½", "Already clean: Lerøy — café ½"],
];

let fail = 0;
for (const [input, expected] of CASES) {
  const got = decodeEntities(input);
  if (got !== expected) {
    fail++;
    console.error(`FAIL  ${JSON.stringify(input)}\n  got:      ${JSON.stringify(got)}\n  expected: ${JSON.stringify(expected)}`);
  } else {
    console.log(`PASS  ${input.slice(0, 56)}`);
  }
}
// The complete Latin-1 sweep: every one of the 96 named entities must decode
// to its exact codepoint (this is what makes "never again" a proven claim).
const L1 = "nbsp iexcl cent pound curren yen brvbar sect uml copy ordf laquo not shy reg macr deg plusmn sup2 sup3 acute micro para middot cedil sup1 ordm raquo frac14 frac12 frac34 iquest Agrave Aacute Acirc Atilde Auml Aring AElig Ccedil Egrave Eacute Ecirc Euml Igrave Iacute Icirc Iuml ETH Ntilde Ograve Oacute Ocirc Otilde Ouml times Oslash Ugrave Uacute Ucirc Uuml Yacute THORN szlig agrave aacute acirc atilde auml aring aelig ccedil egrave eacute ecirc euml igrave iacute icirc iuml eth ntilde ograve oacute ocirc otilde ouml divide oslash ugrave uacute ucirc uuml yacute thorn yuml".split(" ");
L1.forEach((name, i) => {
  const got = decodeEntities(`&${name};`);
  const expected = String.fromCodePoint(160 + i);
  if (got !== expected) { fail++; console.error(`FAIL  &${name}; -> ${JSON.stringify(got)} (expected ${JSON.stringify(expected)})`); }
});
console.log(fail === 0 ? `\nALL PASS (${CASES.length} cases + full Latin-1 sweep of ${L1.length})` : `\n${fail} FAILURES`);
process.exit(fail === 0 ? 0 : 1);
