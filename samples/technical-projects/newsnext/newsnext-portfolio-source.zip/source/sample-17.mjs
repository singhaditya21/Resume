// verify-sources.mjs — run this ON THE SERVER (where the internet is reachable):
//     node verify-sources.mjs
//
// It pings every source in config.js, checks that the feed actually returns
// items, and writes the list of DEAD feeds into the sources document of
// data/newsnext.db ("disabled"). NewsNext then automatically uses only the
// verified-working feeds. Safe to run while the app is up (WAL + busy
// timeout). Re-run it any time (e.g. weekly via cron) to keep the list clean.
import { SOURCES } from "./config.js";
import { dbRead, dbWrite } from "./lib/db.js";
const TIMEOUT = 9000;
const BATCH = 20;

async function check(s) {
  try {
    const res = await fetch(s.url, {
      signal: AbortSignal.timeout(TIMEOUT),
      redirect: "follow",
      headers: {
        "User-Agent": "PORTFOLIO_REDACTED",
        "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml, */*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });
    if (!res.ok) return { id: s.id, name: s.name, ok: false, err: `HTTP ${res.status}` };
    const text = await res.text();
    const ok = /<(item|entry)[\s>]/i.test(text);           // has at least one story
    return { id: s.id, name: s.name, ok, err: ok ? null : "no items in feed" };
  } catch (e) {
    return { id: s.id, name: s.name, ok: false, err: (e.name === "TimeoutError" ? "timeout" : e.message) };
  }
}

console.log(`\nVerifying ${SOURCES.length} sources (timeout ${TIMEOUT / 1000}s each)…\n`);
const results = [];
for (let i = 0; i < SOURCES.length; i += BATCH) {
  results.push(...await Promise.all(SOURCES.slice(i, i + BATCH).map(check)));
  process.stdout.write(`\r  checked ${Math.min(i + BATCH, SOURCES.length)}/${SOURCES.length}`);
}
process.stdout.write("\n\n");

const dead = results.filter((r) => !r.ok);
const okCount = results.length - dead.length;

// Merge into the sources document without clobbering admin-added custom sources.
const cur = dbRead("sources", {});
cur.custom = Array.isArray(cur.custom) ? cur.custom : [];
cur.disabled = dead.map((d) => d.id);
dbWrite("sources", cur);

console.log(`✅ ${okCount}/${SOURCES.length} feeds verified working (${Math.round(okCount / SOURCES.length * 100)}%).`);
console.log(`🚫 ${dead.length} dead feeds disabled → written to the sources store in data/newsnext.db`);
if (dead.length) {
  console.log(`\nDisabled feeds (first 40 shown):`);
  dead.slice(0, 40).forEach((d) => console.log(`   • ${d.name}  —  ${d.err}`));
  if (dead.length > 40) console.log(`   … and ${dead.length - 40} more`);
}
console.log(`\nRestart NewsNext (or wait for the next 10-min refresh) — only verified feeds are now used.\n`);
