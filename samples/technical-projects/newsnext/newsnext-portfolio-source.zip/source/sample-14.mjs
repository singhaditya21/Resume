// test-image-engine.mjs — offline test suite for the Intelligent Image Engine.
// Run:  node test-image-engine.mjs   (exits non-zero on any failure)
import fs from "fs";
import { analyze, attachImages, engineStats, reindex } from "./lib/image-engine/engine.js";

let pass = 0, fail = 0;
const t = (name, ok, info = "") => { (ok ? pass++ : fail++); console.log(`${ok ? "✅" : "❌"} ${name}${info ? " — " + info : ""}`); };

const A = (id, title, summary, dept, topic) => ({ id, title, summary, dept, topic });

// 1 ── coverage guarantee: every article (even garbage) gets an image
const batch = [
  A("c1", "OpenAI unveils enterprise reasoning model for banks", "Compliance workflows with audit trails.", "Technology / Engineering / IT", "Artificial Intelligence"),
  A("c2", "Fed holds interest rates steady amid inflation concerns", "Central bank signals patience.", "Finance", "Market Intelligence"),
  A("c3", "Ransomware gang targets hospital networks", "Phishing lures and unpatched VPNs.", "Legal / Compliance / Risk", "Responsible AI"),
  A("c4", "HR leaders rethink return-to-office mandates", "Hybrid work policies adjusted.", "HR / People", "Workplace Culture"),
  A("c5", "Supply chain teams brace for port congestion", "Freight rates climb as containers pile up.", "Operations / Procurement / Admin", "Procurement"),
  A("c6", "xq zz vv", "", "Delivery", ""),
];
attachImages(batch);
t("coverage: all 6 stories have an image", batch.every((s) => s.thumbnailUrl));
t("coverage: garbage input still covered", !!batch[5].thumbnailUrl, batch[5].imgTier);

// 2 ── classification sanity
const cls = (s) => (s.imgCategories && s.imgCategories[0] ? s.imgCategories[0].name : "?");
t("classify: AI article → AI concept", /AI|LLM/i.test(cls(batch[0])), cls(batch[0]));
t("classify: Fed article → banking/markets/economy", /Bank|Market|Econom/i.test(cls(batch[1])), cls(batch[1]));
t("classify: ransomware → cybersecurity", /Cyber/i.test(cls(batch[2])), cls(batch[2]));
t("classify: confidence scores normalised", batch[0].imgCategories.every((c) => c.confidence > 0 && c.confidence <= 1));

// 3 ── batch diversity: no duplicate images inside one refresh
const urls = batch.map((s) => s.thumbnailUrl);
t("diversity: batch images all distinct", new Set(urls).size === urls.length);

// 4 ── rotation: same article re-assigned across "refreshes" rotates images
const r1 = [A("r", "Stock market rally lifts equities", "Bull run on Wall Street.", "Finance", "Market Intelligence")];
attachImages(r1);
const first = r1[0].thumbnailUrl;
const r2 = [A("r", "Stock market rally lifts equities", "Bull run on Wall Street.", "Finance", "Market Intelligence")];
attachImages(r2);
t("rotation: repeated assignment avoids the just-used image", r2[0].thumbnailUrl !== first, `${String(first).slice(-20)} → ${String(r2[0].thumbnailUrl).slice(-20)}`);

// 5 ── learning: entity promoted after 5 sightings
for (let i = 0; i < 5; i++) attachImages([A("lz" + i, `Perplexity signs distribution deal number ${i}`, "Perplexity expands enterprise search.", "Technology / Engineering / IT", "Artificial Intelligence")]);
const st = engineStats();
t("learning: 'Perplexity' promoted to dynamic concept", st.promoted.some((p) => p.name === "Perplexity"), `dynamic=${st.taxonomy.dynamic}`);

// 6 ── library: drop-in file indexed + preferred for a matching article
fs.mkdirSync("library/images/testing", { recursive: true });
fs.writeFileSync("library/images/testing/quarterly-earnings-report-finance.jpg", Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]));
const ri = reindex();
t("library: reindex sees dropped file", ri.images >= 1, `${ri.images} images`);
const lb = [A("lb", "Company posts strong quarterly earnings in latest report", "Finance results beat estimates.", "Finance", "Corporate Finance")];
attachImages(lb);
t("library: local image preferred for matching article", lb[0].imgTier === "library", lb[0].thumbnailUrl);
t("library: sidecar metadata auto-generated", fs.existsSync("library/metadata/testing/quarterly-earnings-report-finance.jpg.json"));

// 7 ── analyze() API shape
const an = analyze(A("x", "Google Cloud partners with SAP on AI", "Enterprise integration deal.", "Technology / Engineering / IT", "Enterprise Software"));
t("analyze: entities extracted", an.entities.some((e) => /Google|SAP/.test(e.name)), an.entities.map((e) => e.name).slice(0, 3).join(","));
t("analyze: keywords extracted", an.keywords.length >= 5);

// cleanup test artifacts
try { fs.rmSync("library/images/testing", { recursive: true, force: true }); fs.rmSync("library/metadata/testing", { recursive: true, force: true }); reindex(); } catch { }

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
