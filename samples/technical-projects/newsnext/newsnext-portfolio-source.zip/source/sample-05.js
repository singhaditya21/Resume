// Dependency-free RSS + Atom fetcher/parser.
// Stale-while-revalidate: /api/news returns the last-known stories INSTANTLY and
// refreshes feeds in the background, so page loads never wait on 100+ feeds.
// The last good result is also cached to disk, so restarts are instant too.
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "node:crypto";
import zlib from "node:zlib";
import { SOURCES, CONFIG } from "../config.js";
// (sample-news.js removed — NewsNext never serves invented stories)
import { effectiveSources } from "./admin-store.js";
import { attachImages } from "./image-engine/engine.js";
import { recordFetch } from "./source-health.js";
import { warmPreviews } from "./preview.js";
import { decodeEntities as decodeAllEntities } from "./entities.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CACHE_FILE = path.join(__dirname, "..", "data", "news-cache.json");

let cache = { at: 0, stories: [], sources: [], payload: null };
let refreshing = false, refreshStartedAt = 0;
// True once a refresh attempt has finished. Until then the client shows
// "Fetching live feeds…"; afterwards, if nothing was reachable, it must say so
// honestly instead of spinning forever.
let firstAttemptDone = false;

// Warm the in-memory cache from disk on startup (instant first response after a restart).
(function loadDiskCache() {
  try {
    const d = JSON.parse(fs.readFileSync(CACHE_FILE, "utf8"));
    if (d && Array.isArray(d.stories) && d.stories.length) {
      cache = { at: d.at || 0, stories: d.stories, sources: d.sources || [], payload: { live: true, stories: d.stories, sources: d.sources || [], fetchedAt: d.fetchedAt || new Date(d.at || Date.now()).toISOString() } };
    }
  } catch { /* no cache yet */ }
})();
function saveDiskCache() {
  try {
    fs.mkdirSync(path.dirname(CACHE_FILE), { recursive: true });
    fs.writeFileSync(CACHE_FILE, JSON.stringify({ at: cache.at, fetchedAt: cache.payload?.fetchedAt, stories: cache.stories, sources: cache.sources }));
  } catch { /* best-effort */ }
}
// Force the next getNews() to kick a background refresh (used when sources change).
export function clearNewsCache() { cache.at = 0; }
// id → story index, rebuilt once per refresh. These lookups sit on /r/<id>,
// /api/share, /api/preview and the Governance comment log (one call per row),
// where a linear .find() over thousands of stories turned a page load into a
// million string comparisons.
// Pre-rendered response bodies for the unfiltered feed, rebuilt once per
// refresh: raw JSON, gzip, and a manifest (ids + fetchedAt) that lets a client
// ask "anything new?" for ~1% of the bytes.
let _wire = null;
export function payloadWire() { if (!_wire) buildPayloadCache(); return _wire; }
function buildPayloadCache() {
  try {
    if (!cache.payload) { _wire = null; return; }
    const json = Buffer.from(JSON.stringify(cache.payload));
    const etag = '"' + crypto.createHash("sha1").update(json).digest("hex").slice(0, 24) + '"';
    const manifest = Buffer.from(JSON.stringify({
      fetchedAt: cache.payload.fetchedAt, live: true,
      count: (cache.stories || []).length,
      sources: cache.sources || [],
      ids: (cache.stories || []).map((s) => s.id),
    }));
    _wire = { json, gzip: zlib.gzipSync(json, { level: 6 }), etag, manifest, manifestEtag: '"m' + etag.slice(1) };
  } catch { _wire = null; }
}
let _byId = new Map(), _byIdFor = null;
function storyIndex() {
  // Keyed on the ARRAY IDENTITY, not its length: a refresh that happens to
  // return the same number of (different) stories would otherwise keep serving
  // the previous snapshot's links from a stale index.
  if (_byIdFor !== cache.stories) {
    _byIdFor = cache.stories;
    _byId = new Map((cache.stories || []).map((s) => [s.id, s]));
  }
  return _byId;
}
// The current article URL for a story id (used by the /r/<id> short share link).
export function linkForId(id) { const s = storyIndex().get(id); return s ? s.link : null; }
// The full story object for a id (used by the HTML share email: title, image…).
export function storyForId(id) { return storyIndex().get(id) || null; }

// Entity decoding lives in lib/entities.js — the ONE decoder for all inbound
// text, with the complete named set and CI coverage (test-entities.mjs).
function decodeEntities(s = "") {
  return decodeAllEntities(s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1"));
}
function stripTags(s = "") { return decodeEntities(s).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim(); }
function tag(block, name) {
  const m = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, "i").exec(block);
  return m ? m[1].trim() : "";
}
function attr(block, name, at) {
  const m = new RegExp(`<${name}[^>]*\\b${at}=["']([^"']+)["']`, "i").exec(block);
  return m ? m[1] : "";
}
function extractImage(block, desc) {
  let img = attr(block, "enclosure", "url")
    || attr(block, "media:content", "url")
    || attr(block, "media:thumbnail", "url");
  if (!img) { const m = /<img[^>]+src=["']([^"']+)["']/i.exec(decodeEntities(desc || "")); if (m) img = m[1]; }
  return /^https?:\/\//.test(img) ? img : null;
}
function parseFeed(xml, src) {
  const blocks = [];
  const re = /<(item|entry)[\s>]([\s\S]*?)<\/\1>/gi;
  let m;
  while ((m = re.exec(xml)) && blocks.length < 8) blocks.push(m[2]);
  return blocks.map((b) => {
    const title = stripTags(tag(b, "title")) || "Untitled";
    let link = tag(b, "link");
    if (!link || /</.test(link)) link = attr(b, "link", "href") || "";
    const desc = tag(b, "description") || tag(b, "summary") || tag(b, "content") || tag(b, "content:encoded");
    const pub = tag(b, "pubDate") || tag(b, "published") || tag(b, "updated") || tag(b, "dc:date");
    const img = extractImage(b, desc);
    let published = new Date(pub);
    if (isNaN(published)) published = new Date();
    // Some publishers stamp future dates (broken feed timezones). A story
    // cannot be from the future: clamp to now (10 min clock-skew slack), so
    // it can't squat at the top of "newest" with a permanent freshness boost.
    // Marked so refreshFeeds can keep the FIRST clamp for stories that stay
    // future-dated across refreshes — re-clamping to "now" every cycle would
    // hand them the permanent freshness boost the clamp exists to prevent.
    let futureClamped = false;
    if (published.getTime() > Date.now() + 10 * 60e3) { published = new Date(); futureClamped = true; }
    return {
      id: `${src.id}-${hash(title)}`,
      source: src.name, title,
      summary: stripTags(desc).slice(0, 240) || "Open the source for the full story.",
      dept: src.dept, topic: src.topic, type: src.type,
      published: published.toISOString(),
      ...(futureClamped ? { futureClamped: true } : {}),
      link: link || src.url, thumbnailUrl: img, alert: null,
    };
  });
}
function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; } return Math.abs(h); }

// --- Deduplication: the same story is often published by several outlets with
// slightly different headlines. We compare significant-word signatures and drop
// near-duplicates so each story appears once. Stories are pre-sorted newest-first,
// so the earliest (most recent) copy is the one kept.
const STOPWORDS = new Set("the a an and or of to in for on with is are was were be as at by from into over after amid new latest report reports say says said will can could how why what who when where this that these those its his her their your our you we it he she they them than then but not no yes about more most just now here there up down out off via vs".split(" "));
// Google News (and many aggregators) append the publisher to the headline:
// "… per Watt | NVIDIA Technical Blog - NVIDIA Developer". Those suffix words
// pollute similarity in both directions, so strip up to two short trailing
// " - X" / " | X" segments before comparing — as long as a real headline
// (≥5 words) remains. Display titles are untouched; this is signature-only.
function coreTitle(title) {
  let parts = String(title).split(/\s+[|–—-]\s+/);
  while (parts.length > 1) {
    const tail = parts[parts.length - 1].trim().split(/\s+/);
    const headWords = parts.slice(0, -1).join(" ").trim().split(/\s+/).length;
    if (tail.length <= 5 && headWords >= 5) parts = parts.slice(0, -1); else break;
  }
  return parts.join(" ");
}
// Light plural fold so "Sets a Standard"/"Set a Standard" and "AI Agents"/
// "Agentic AI" partially align without a real stemmer.
const stemWord = (w) => (w.length > 3 ? w.replace(/s$/, "") : w);
// Calendar + live-blog boilerplate (post-stem forms): common to unrelated
// same-day stories, so never phrase evidence.
const BIGRAM_NOISE = new Set("january february march april may june july august september october november december monday tuesday wednesday thursday friday saturday sunday today live update 2024 2025 2026 2027".split(" "));
function signature(title) {
  const seq = (coreTitle(title).toLowerCase().match(/[a-z0-9]+/g) || [])
    .map(stemWord)
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));
  // Bigrams are "distinctive phrase" evidence, so template filler must not
  // count: dates and live-blog boilerplate ("plans in Australia for August
  // 2026") would otherwise hand two DIFFERENT product listicles 3 shared
  // bigrams. Words still count toward jaccard — only phrase evidence is gated.
  const bigrams = new Set();
  for (let i = 1; i < seq.length; i++) {
    if (BIGRAM_NOISE.has(seq[i - 1]) || BIGRAM_NOISE.has(seq[i])) continue;
    bigrams.add(seq[i - 1] + " " + seq[i]);
  }
  return { words: new Set(seq), bigrams, first: seq[0] || "" };
}
function isDuplicate(sigA, sigB) {
  if (!sigA.words.size || !sigB.words.size) return false;
  // Subject guard: formulaic finance headlines make DIFFERENT companies look
  // alike ("Infosys Q2 profit rises 5% on strong deal wins" / "Wipro Q2 …").
  // If each headline leads with a different word that the other never mentions
  // at all, they are parallel stories about different subjects — never dupes.
  if (sigA.first !== sigB.first && !sigB.words.has(sigA.first) && !sigA.words.has(sigB.first)) return false;
  let inter = 0; for (const w of sigA.words) if (sigB.words.has(w)) inter++;
  const union = sigA.words.size + sigB.words.size - inter;
  const jaccard = inter / union;                       // overall similarity
  const contain = inter / Math.min(sigA.words.size, sigB.words.size); // one headline inside the other
  if (jaccard >= 0.55 || (contain >= 0.8 && inter >= 4)) return true;
  // Rewritten same-story headlines ("NVIDIA Vera Rubin … per Watt" from two
  // NVIDIA blogs) fail plain word overlap but share distinctive PHRASES.
  // ≥3 shared content bigrams is strong evidence when overall overlap isn't tiny.
  let big = 0; for (const b of sigA.bigrams) if (sigB.bigrams.has(b)) big++;
  return big >= 3 && jaccard >= 0.3;
}
// Near-duplicate window: the input is sorted newest-first, and the same story
// from different outlets lands within hours of itself — so scanning the
// trailing window catches real dupes while keeping the pass linear. A full
// all-pairs scan at thousands of stories would block the event loop for
// seconds every refresh. Identical headlines stay checked across the WHOLE
// set (the Set lookup is O(1) regardless of size).
const DEDUPE_WINDOW = 600;
function dedupe(stories) {
  const out = [];
  const sigs = [];
  const exact = new Map();                              // exact title -> the kept story
  // As duplicates collapse, remember how many DISTINCT outlets ran essentially
  // the same headline. That count ("coverage") is a real trending signal: a
  // story that many of our sources are all covering right now is genuinely hot
  // across business media. It rides on the kept story and ships to the client.
  const fold = (keeper, dupSrc) => { (keeper._srcs || (keeper._srcs = new Set([keeper.source]))).add(dupSrc); };
  for (const s of stories) {
    // Key on the CORE title (publisher suffix stripped) so the same article
    // surfaced by two different queries collapses on the exact path too.
    const ek = coreTitle(s.title).toLowerCase().replace(/\s+/g, " ").trim();
    const exHit = exact.get(ek);
    if (exHit) { fold(exHit, s.source); continue; }     // identical headline, different outlet
    const sig = signature(s.title);
    let dupOf = null;
    const stop = Math.max(0, sigs.length - DEDUPE_WINDOW);
    for (let i = sigs.length - 1; i >= stop; i--) { if (isDuplicate(sig, sigs[i])) { dupOf = out[i]; break; } }
    if (dupOf) { fold(dupOf, s.source); continue; }
    out.push(s); sigs.push(sig); exact.set(ek, s);
  }
  for (const s of out) { s.coverage = s._srcs ? s._srcs.size : 1; delete s._srcs; }
  return out;
}

async function fetchSource(src) {
  try {
    const res = await fetch(src.url, {
      signal: AbortSignal.timeout(8500),
      redirect: "follow",
      headers: {
        // Browser-like UA: Google News, Bing News and Reddit refuse bot-style
        // user agents (403/429) while publisher feeds don't care either way.
        "User-Agent": "PORTFOLIO_REDACTED",
        "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml, */*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });
    if (!res.ok) return { ok: false, src: src.name, error: `HTTP ${res.status}` };
    // Honor the feed's declared charset — .text() always assumes UTF-8, which
    // mojibakes ISO-8859-1 / windows-1252 feeds (ø → �). Content-Type header
    // first, then the XML declaration; unknown labels fall back to UTF-8.
    const buf = Buffer.from(await res.arrayBuffer());
    let charset = ((res.headers.get("content-type") || "").match(/charset=["']?([\w-]+)/i) || [])[1];
    if (!charset) charset = (buf.subarray(0, 200).toString("latin1").match(/encoding=["']([\w-]+)["']/i) || [])[1];
    let xml;
    try { xml = new TextDecoder(charset || "utf-8", { fatal: false }).decode(buf); }
    catch { xml = buf.toString("utf8"); }
    const stories = parseFeed(xml, src);
    return { ok: stories.length > 0, src: src.name, stories };
  } catch (e) {
    return { ok: false, src: src.name, error: e.message };
  }
}

// Actually fetch every source and rebuild the cache. Runs in the background.
async function refreshFeeds(gen = null) {
  const SRC = effectiveSources(SOURCES);
  const BATCH = 32;   // ~2,000 sources: 32-wide batches keep a full refresh to a few minutes
  // Belt over the per-fetch abort signal: NOTHING may hold a batch open past
  // 25s. Even if a socket edge-case ignores its abort, the batch moves on and
  // the refresh always completes — the feed can never freeze on one source.
  const deadline = (p, src) => Promise.race([
    p,
    new Promise((r) => { const t = setTimeout(() => r({ ok: false, src, error: "deadline" }), 25000); if (t.unref) t.unref(); }),
  ]);
  const results = [];
  for (let i = 0; i < SRC.length; i += BATCH) {
    results.push(...await Promise.all(SRC.slice(i, i + BATCH).map((s) => deadline(fetchSource(s), s.name))));
  }
  const all = [];
  // First-seen memory for future-dated stories: a story whose feed keeps
  // stamping tomorrow gets clamped ONCE (its first appearance) and keeps that
  // timestamp on every later refresh, instead of being re-stamped "just now"
  // each cycle and squatting at the top of the feed forever.
  const prevPub = new Map((cache.stories || []).map((s) => [s.id, s.published]));
  for (const r of results) {
    if (r.stories) for (const s of r.stories) {
      if (s.futureClamped) { if (prevPub.has(s.id)) s.published = prevPub.get(s.id); delete s.futureClamped; }
      all.push(s);
    }
  }
  // Parse each timestamp ONCE. Sorting ~20k raw stories with a comparator that
  // built two Date objects per comparison cost hundreds of thousands of parses
  // (and the age filter below re-parsed them all again) — a visible event-loop
  // stall every 10 minutes at full source count.
  for (const s of all) s._t = Date.parse(s.published) || 0;
  all.sort((a, b) => b._t - a._t);
  // Latest-news-only window: drop entries older than the configured cap so a
  // week-old story can never headline the feed. If the window leaves too few
  // stories (quiet news day / few reachable sources), the newest older ones
  // top it up to minFreshStories.
  const cutoff = Date.now() - (CONFIG.maxStoryAgeHours || 48) * 3600e3;
  const freshOnly = all.filter((s) => s._t >= cutoff);
  // Every deduped story inside the age window ships. maxStories is a safety
  // ceiling for payload/render cost, not a quota — log when it actually trims
  // so a silent cap can never masquerade as "that's all the news there was".
  const ceiling = CONFIG.maxStories || 2000;
  const deduped = dedupe(freshOnly);
  if (deduped.length > ceiling) console.log(`  ⚠ story ceiling: ${deduped.length} deduped stories, keeping newest ${ceiling} (raise CONFIG.maxStories to keep more)`);
  let capped = deduped.slice(0, ceiling);
  if (capped.length < (CONFIG.minFreshStories || 60)) {
    capped = dedupe(all).slice(0, Math.max(CONFIG.minFreshStories || 60, capped.length));
  }
  // Intelligent Image Engine: guarantee every story has a relevant image
  // (semantic match against the taxonomy + library; see lib/image-engine/).
  try { attachImages(capped); } catch { /* engine failure must never block news */ }
  const sources = results.map((r) => ({ name: r.src, ok: r.ok, error: r.error || null }));
  // Feed every refresh into the source-health record, so Governance → Trust
  // Metrics is scored from observed behaviour rather than a hash of the name.
  try {
    recordFetch(results.map((r) => {
      let newestT = 0;
      for (const s of r.stories || []) { const t = s._t || Date.parse(s.published) || 0; if (t > newestT) newestT = t; }
      const newestAt = newestT ? new Date(newestT).toISOString() : null;
      return { name: r.src, ok: r.ok, error: r.error || null, items: (r.stories || []).length, newestAt };
    }));
  } catch (e) { console.log("  ⚠ source-health: record failed —", e.message); }
  // A superseded run (watchdog started a newer one over it) must not publish:
  // its stories were fetched before the newer run's, and stamping them with a
  // fresh fetchedAt would roll the feed back while claiming it just updated.
  if (gen !== null && gen !== refreshGen) {
    console.log("  ⚠ superseded feed refresh finished late — result discarded");
    return cache.payload;
  }
  if (capped.length) {
    for (const s of capped) delete s._t;     // internal sort key — never ships to a client
    const fetchedAt = new Date().toISOString();
    cache = { at: Date.now(), stories: capped, sources, payload: { live: true, stories: capped, sources, fetchedAt } };
    // Serialize and compress ONCE per refresh instead of per request: the feed
    // payload is megabytes, and every client re-fetches it on a 10-minute
    // cadence. buildPayloadCache also produces the ETag that lets an unchanged
    // feed answer 304 with no body at all.
    buildPayloadCache();
    saveDiskCache();
    // Heartbeat for docker logs: one line per refresh proves the loop is
    // alive and says how fresh the newest story is — the first thing to
    // check whenever the feed looks stale.
    const newest = Math.round((Date.now() - new Date(capped[0].published || 0).getTime()) / 60e3);
    console.log(`  ↻ feeds refreshed: ${capped.length} stories from ${sources.filter((s) => s.ok).length}/${sources.length} sources, newest ${newest} min old`);
    // Pre-fetch publisher summaries in the background so story opens never
    // wait on (or get throttled by) Google's resolver.
    try { warmPreviews(capped); } catch { /* warming must never block news */ }
  } else {
    // Nothing reachable: remember source statuses but keep any prior stories.
    cache.sources = sources; cache.at = Date.now();
    if (cache.payload) cache.payload.sources = sources;
    buildPayloadCache();   // the payload changed (source health), so the wire copy must too
  }
  firstAttemptDone = true;
  return cache.payload;
}
// Watchdog: a wedged refresh (one hung await, however unlikely) would leave
// `refreshing` true forever and freeze the feed at its last snapshot — the
// exact "everything is 18 hours old" failure. If a run exceeds 15 minutes,
// declare it dead, log loudly, and let a new one start.
const REFRESH_DEADLINE_MS = 15 * 60e3;
function refreshLooksWedged() {
  return refreshing && Date.now() - refreshStartedAt > REFRESH_DEADLINE_MS;
}
// Run generation: when the watchdog starts run B over a wedged run A, A's
// eventual completion must not clear the `refreshing` flag out from under B
// (which would let a third run start concurrently). Only the newest run's
// finally may release the flag.
let refreshGen = 0;
function bgRefresh() {
  if (refreshing && !refreshLooksWedged()) return;
  if (refreshing) console.log(`  ⚠ feed refresh watchdog: previous run exceeded ${REFRESH_DEADLINE_MS / 60e3} min — starting a fresh one`);
  refreshing = true; refreshStartedAt = Date.now();
  const gen = ++refreshGen;
  refreshFeeds(gen).catch(() => {}).finally(() => { if (gen === refreshGen) refreshing = false; firstAttemptDone = true; });
}

// Kick off a warm-up fetch shortly after boot so the first visitor already has live data.
setTimeout(bgRefresh, 300);

// Standing refresh: every cache-window, around the clock, whether or not
// anyone is browsing. Before this, refreshes only ran when a request found
// the cache stale — overnight with zero traffic nothing refreshed, so the
// first person at 5–6am saw yesterday's snapshot. Now the morning warm-up is
// automatic (as is every other hour of the day): no login ever finds a feed
// older than one cache window. The watchdog inside bgRefresh un-wedges a
// stuck run, and per-source deadlines guarantee every run completes.
const _standing = setInterval(bgRefresh, Math.max(10 * 60e3, CONFIG.newsCacheMs || 30 * 60e3));
if (_standing.unref) _standing.unref();

// Returns { live, stories, sources, fetchedAt, cached } — INSTANTLY.
export async function getNews({ force = false } = {}) {
  const fresh = cache.payload && (Date.now() - cache.at < CONFIG.newsCacheMs);
  if (force) {
    // Explicit refresh: fetch now and return the fresh result (awaited).
    // A wedged background run must not block this — take over from it.
    if (!refreshing || refreshLooksWedged()) {
      refreshing = true; refreshStartedAt = Date.now();
      const gen = ++refreshGen;
      try { await refreshFeeds(gen); } finally { if (gen === refreshGen) refreshing = false; }
    }
    else { await new Promise((r) => setTimeout(r, 400)); }
    if (cache.payload) return { ...cache.payload, cached: false };
  } else if (!fresh) {
    bgRefresh(); // stale or empty → refresh in the background, don't block
  }
  if (cache.payload && cache.stories.length) return { ...cache.payload, cached: fresh };
  // No invented stories. NewsNext previously served 48 fabricated headlines from
  // data/sample-news.js here so a demo was never empty; a dashboard that shows
  // made-up news when the network is down is worse than one that admits it.
  // `warming` distinguishes "still fetching" from "fetched and nothing worked".
  return { live: false, stories: [], sources: cache.sources || [], fetchedAt: new Date().toISOString(), cached: false, warming: !firstAttemptDone, unavailable: firstAttemptDone };
}
