// ═══════════════════════════════════════════════════════════════════════════
//  Image Engine · taxonomy.js — the concept graph.
//
//  A two-level taxonomy (domain → concept) designed from the data NewsNext
//  actually aggregates: business/tech RSS, Google/Bing News queries, Reddit,
//  YouTube. Each concept owns a term set; concepts are embedded into the
//  shared vector space at load. The taxonomy is NOT closed: the learning
//  loop (engine.js) promotes recurring unknown entities into dynamic
//  concepts persisted in data/image-taxonomy.json — so new companies,
//  products and domains grow the tree without code changes.
// ═══════════════════════════════════════════════════════════════════════════
import { embed, tokenize } from "./text.js";

// domain → concepts. Terms are what the concept "means" in vector space.
export const SEED = [
  // ── Artificial Intelligence ──
  { id: "ai-models", domain: "ai", name: "AI Models & LLMs", terms: "artificial intelligence llm large language model gpt chatgpt openai anthropic claude gemini llama mistral foundation model transformer neural network deep learning inference reasoning multimodal" },
  { id: "ai-agents", domain: "ai", name: "AI Agents & Automation", terms: "ai agent agentic autonomous workflow automation copilot assistant orchestration tool use rag retrieval augmented mcp" },
  { id: "ml-datasci", domain: "ai", name: "Machine Learning & Data Science", terms: "machine learning data science model training dataset pytorch tensorflow feature engineering mlops prediction analytics statistics python notebook kaggle" },
  { id: "ai-chips", domain: "ai", name: "AI Hardware & Chips", terms: "gpu nvidia chip semiconductor tpu accelerator data center compute cuda silicon fab tsmc intel amd" },
  { id: "ai-ethics", domain: "ai", name: "Responsible AI & Regulation", terms: "ai regulation responsible ai safety alignment bias governance eu ai act policy ethics deepfake misinformation copyright" },
  { id: "genai-media", domain: "ai", name: "Generative Media", terms: "generative ai image generation video generation diffusion midjourney stable diffusion sora text to image synthetic media avatar voice cloning" },
  // ── Software & Cloud ──
  { id: "software-eng", domain: "technology", name: "Software Engineering", terms: "software engineering programming developer code github git open source repository framework javascript typescript python java rust api sdk library refactoring testing debugging" },
  { id: "cloud", domain: "technology", name: "Cloud & Infrastructure", terms: "cloud computing aws azure google cloud kubernetes docker container serverless infrastructure devops terraform microservices scalability deployment sre observability" },
  { id: "cybersecurity", domain: "technology", name: "Cybersecurity", terms: "cybersecurity security breach hacker ransomware phishing malware vulnerability exploit zero day encryption firewall threat attack credential dark web incident response" },
  { id: "data-platforms", domain: "technology", name: "Data Platforms & Databases", terms: "database sql postgres data warehouse snowflake databricks etl pipeline analytics big data lakehouse streaming kafka vector database" },
  { id: "consumer-tech", domain: "technology", name: "Consumer Tech & Gadgets", terms: "smartphone iphone android apple samsung gadget laptop wearable device app store tablet headset vr ar console gaming" },
  { id: "enterprise-saas", domain: "technology", name: "Enterprise Software & SaaS", terms: "enterprise software saas crm erp salesforce sap oracle workday platform subscription b2b integration workflow digital workplace collaboration" },
  { id: "telecom", domain: "technology", name: "Telecom & Networks", terms: "telecom 5g network broadband spectrum fiber carrier verizon airtel jio connectivity satellite starlink" },
  { id: "quantum-science", domain: "technology", name: "Quantum & Frontier Science", terms: "quantum computing qubit research breakthrough physics laboratory science experiment fusion space nasa spacex satellite rocket" },
  // ── Finance ──
  { id: "markets", domain: "finance", name: "Markets & Trading", terms: "stock market shares equities trading wall street nasdaq sensex nifty index bond yield investor bull bear rally selloff ipo valuation" },
  { id: "banking", domain: "finance", name: "Banking & Payments", terms: "bank banking payments credit card upi visa mastercard lending loan deposit rbi federal reserve central bank interest rate settlement swift treasury" },
  { id: "fintech", domain: "finance", name: "Fintech & Crypto", terms: "fintech digital wallet neobank blockchain crypto bitcoin ethereum stablecoin defi tokenization payment gateway embedded finance" },
  { id: "corp-finance", domain: "finance", name: "Corporate Finance & Deals", terms: "merger acquisition m&a earnings revenue profit quarterly results cfo budget funding round venture capital private equity valuation deal buyout stake" },
  { id: "economy", domain: "finance", name: "Economy & Policy", terms: "economy gdp inflation recession growth employment jobs report trade tariff economic policy fiscal monetary imf world bank consumer spending" },
  { id: "insurance-risk", domain: "finance", name: "Insurance & Risk", terms: "insurance underwriting actuarial claims risk management compliance audit fraud aml kyc basel solvency" },
  // ── Go-to-market ──
  { id: "sales-crm", domain: "sales", name: "Sales & CRM", terms: "sales pipeline crm quota deal enterprise sales account executive revenue operations prospecting cold outreach negotiation win rate forecast" },
  { id: "marketing-digital", domain: "marketing", name: "Digital Marketing", terms: "marketing campaign seo search engine content marketing social media brand advertising ads ppc email marketing engagement conversion funnel" },
  { id: "marketing-brand", domain: "marketing", name: "Brand & Creative", terms: "brand creative design agency storytelling advertisement commercial sponsorship influencer audience reach awareness" },
  { id: "customer-exp", domain: "customer", name: "Customer Experience", terms: "customer experience support service helpdesk satisfaction nps churn retention onboarding loyalty contact center chatbot self service" },
  // ── People & Org ──
  { id: "hr-people", domain: "people", name: "HR & Talent", terms: "hr human resources hiring recruiting talent acquisition employee workforce layoffs attrition benefits payroll onboarding skills upskilling" },
  { id: "workplace", domain: "people", name: "Workplace & Culture", terms: "workplace culture remote work hybrid office return to office wellbeing burnout diversity inclusion engagement collaboration productivity" },
  { id: "leadership", domain: "leadership", name: "Leadership & Strategy", terms: "leadership ceo executive strategy management board decision vision transformation organizational change innovation competitive advantage" },
  { id: "startups", domain: "leadership", name: "Startups & Entrepreneurship", terms: "startup founder entrepreneur seed unicorn accelerator incubator pitch product market fit bootstrapped scaleup" },
  { id: "legal-reg", domain: "legal", name: "Legal & Regulation", terms: "lawsuit court ruling regulator antitrust compliance gdpr privacy legislation law legal settlement fine penalty investigation" },
  // ── Product & Design ──
  { id: "product-mgmt", domain: "product", name: "Product Management", terms: "product management roadmap feature launch user research backlog prioritization product led growth metrics north star discovery mvp" },
  { id: "ux-design", domain: "product", name: "UX & Design", terms: "design ux ui user experience interface prototype figma usability accessibility design system typography visual" },
  // ── Operations ──
  { id: "supply-chain", domain: "operations", name: "Supply Chain & Logistics", terms: "supply chain logistics shipping freight warehouse inventory procurement supplier manufacturing factory port container delivery" },
  { id: "energy", domain: "industry", name: "Energy & Climate", terms: "energy renewable solar wind battery ev electric vehicle climate carbon emissions sustainability grid oil gas nuclear power" },
  { id: "healthcare", domain: "industry", name: "Healthcare & Biotech", terms: "healthcare hospital pharma drug biotech clinical trial fda vaccine medical device patient diagnosis telemedicine genomics" },
  { id: "retail", domain: "industry", name: "Retail & E-commerce", terms: "retail ecommerce amazon flipkart store shopping consumer brand grocery marketplace checkout fulfillment d2c" },
  { id: "auto-mobility", domain: "industry", name: "Automotive & Mobility", terms: "automotive car vehicle tesla ev autonomous driving mobility ride sharing scooter truck battery charging" },
  { id: "media-ent", domain: "industry", name: "Media & Entertainment", terms: "streaming netflix disney film music podcast youtube creator content entertainment gaming esports box office" },
  { id: "real-estate", domain: "industry", name: "Real Estate & Construction", terms: "real estate property housing construction commercial office rent mortgage reit infrastructure building" },
  { id: "education", domain: "industry", name: "Education & Learning", terms: "education university school edtech learning course student teacher curriculum certification training mooc" },
  { id: "travel", domain: "industry", name: "Travel & Hospitality", terms: "travel airline flight hotel tourism booking hospitality airport vacation cruise destination" },
  { id: "agri-food", domain: "industry", name: "Food & Agriculture", terms: "food agriculture farming crop restaurant delivery fmcg beverage nutrition agritech harvest" },
  // ── General ──
  { id: "news-general", domain: "general", name: "General Business News", terms: "business news update announcement industry market company organization global world report analysis" },
];

// Pre-computed concept vectors (built once at module load — ~75 × 256 floats).
export function buildConceptIndex(extraConcepts = []) {
  const all = [...SEED, ...extraConcepts];
  return all.map((c) => ({
    ...c,
    tokens: tokenize(c.terms),
    vector: embed(tokenize(c.terms)),
  }));
}

export const DOMAINS = [...new Set(SEED.map((c) => c.domain))];
