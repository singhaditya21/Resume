// NewsNext database — SQLite via Node's built-in node:sqlite (zero npm deps).
//
// One file: data/newsnext.db (WAL mode, ACID). Two kinds of storage:
//   - Real tables for the high-churn, row-shaped data: comments, shares,
//     activity — indexed, appended row by row.
//   - A documents table for registry/config stores (users, userdata,
//     approvals, reports, guardrail, digests, …): each store is one JSON
//     document, read/written atomically in a transaction. Their business
//     logic is document-oriented and stays byte-identical — only the
//     persistence engine changed from a loose file to the database.
//
// Analytics deliberately stays OUT of the database: data/analytics.json is
// snapshotted daily (backup layer) and can be recomputed from those snaps.
// Caches (news, previews, images, directory) also stay as files — regenerable.
//
// First boot migrates every legacy JSON store into the database, then renames
// the file to <name>.migrated so it is archived, never double-imported.
import { DatabaseSync } from "node:sqlite";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR = path.join(__dirname, "..", "data");
const DB_FILE = path.join(DIR, "newsnext.db");

fs.mkdirSync(DIR, { recursive: true });
export const db = new DatabaseSync(DB_FILE);
export const DB_PATH = DB_FILE;
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA synchronous = NORMAL");
db.exec("PRAGMA foreign_keys = ON");
db.exec("PRAGMA busy_timeout = 5000");   // side scripts (verify-sources) may write while the app runs

db.exec(`
CREATE TABLE IF NOT EXISTS documents (
  name      TEXT PRIMARY KEY,
  value     TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS comments (
  id       TEXT PRIMARY KEY,
  storyId  TEXT NOT NULL,
  email    TEXT NOT NULL,
  author   TEXT NOT NULL,
  role     TEXT NOT NULL,
  text     TEXT NOT NULL,
  at       TEXT NOT NULL,
  edited   INTEGER NOT NULL DEFAULT 0,
  parentId TEXT,
  likes    TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS ix_comments_story ON comments(storyId, at);
CREATE INDEX IF NOT EXISTS ix_comments_at    ON comments(at DESC);
CREATE TABLE IF NOT EXISTS shares (
  id      TEXT PRIMARY KEY,
  at      TEXT NOT NULL,
  by      TEXT NOT NULL,
  toEmail TEXT NOT NULL DEFAULT '',
  channel TEXT NOT NULL,
  storyId TEXT NOT NULL,
  title   TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_shares_at ON shares(at DESC);
CREATE TABLE IF NOT EXISTS activity (
  id      TEXT PRIMARY KEY,
  at      TEXT NOT NULL,
  actor   TEXT NOT NULL,
  action  TEXT NOT NULL,
  summary TEXT NOT NULL,
  via     TEXT NOT NULL,
  meta    TEXT
);
CREATE INDEX IF NOT EXISTS ix_activity_at ON activity(at DESC);
CREATE TABLE IF NOT EXISTS userdata (
  email     TEXT PRIMARY KEY,
  value     TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
`);

/* ---------- document store (JSON per logical store, transactional) ---------- */
const _getDoc = db.prepare("SELECT value FROM documents WHERE name = ?");
const _putDoc = db.prepare(
  "INSERT INTO documents(name, value, updatedAt) VALUES(?, ?, ?) " +
  "ON CONFLICT(name) DO UPDATE SET value = excluded.value, updatedAt = excluded.updatedAt");

export function dbRead(name, fallback) {
  const row = _getDoc.get(name);
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch { return fallback; }
}
export function dbWrite(name, obj) {
  _putDoc.run(name, JSON.stringify(obj), new Date().toISOString());
}

/* ---------- live backup (safe while the app runs — WAL-aware) ----------
 * Restore procedure: stop the app, DELETE data/newsnext.db-wal and -shm
 * (a stale WAL would replay over the restored file), copy the snapshot's
 * newsnext.db into data/, start the app. */
export function backupDbTo(destFile) {
  const tmp = destFile + ".tmp";
  try { fs.rmSync(tmp, { force: true }); } catch { /* fresh target */ }
  const esc = String(tmp).replace(/'/g, "''");
  db.exec(`VACUUM INTO '${esc}'`);
  fs.renameSync(tmp, destFile);   // atomic: a crash mid-backup never leaves a truncated snapshot
}

/* ---------- one-time migration from the legacy JSON files ---------- */
const DOC_FILES = [
  "users.json", "userdata.json", "subscriptions.json", "feedback.json",
  "reports.json", "suppressed.json", "approvals.json", "sources.json",
  "guardrail.json", "digests.json", "moderation.json",
];

// Absent legacy files are normal (fresh install → fallback). An UNREADABLE
// one is not: importing "nothing" for a store that exists but is torn would
// silently erase it while reporting success — abort loudly instead, so the
// operator can restore the file from a backup and boot again.
function readLegacy(file, fallback) {
  let raw;
  try { raw = fs.readFileSync(path.join(DIR, file), "utf8"); }
  catch { return fallback; }
  try { return JSON.parse(raw); }
  catch { throw new Error(`migration aborted: data/${file} exists but is not valid JSON — restore it from a backup (or move it away if it is truly disposable), then start again`); }
}
function archive(file) {
  try { fs.renameSync(path.join(DIR, file), path.join(DIR, file + ".migrated")); } catch { /* absent */ }
}

const LEGACY_FILES = [...DOC_FILES, "comments.json", "shares.json", "activity.json"];

(function migrateLegacyJson() {
  if (dbRead("_migrated", null)) {
    // Already imported — but a crash between COMMIT and the archive loop can
    // leave live-looking legacy files behind. Sweep them on every boot so a
    // later "delete the db and re-migrate" can never resurrect stale data.
    for (const f of LEGACY_FILES) if (f !== "subscriptions.json" && fs.existsSync(path.join(DIR, f))) archive(f);
    return;
  }
  db.exec("BEGIN");
  try {
    for (const f of DOC_FILES) {
      const data = readLegacy(f, null);
      if (data !== null) dbWrite(f.replace(/\.json$/, ""), data);
    }
    // Legacy comment ids were only unique per story; the table needs global
    // uniqueness. A colliding id gets a fresh suffix rather than being
    // dropped, and replies within the story follow their renamed parent
    // (parents always precede replies in the legacy arrays).
    const cm = readLegacy("comments.json", {});
    const insC = db.prepare("INSERT INTO comments(id,storyId,email,author,role,text,at,edited,parentId,likes) VALUES(?,?,?,?,?,?,?,?,?,?)");
    const seenIds = new Set();
    for (const [storyId, list] of Object.entries(cm)) {
      const remap = {};
      for (const c of list || []) {
        if (!c || typeof c !== "object") continue;   // a malformed row must never block the boot
        const baseId = c.id || "c-mig-" + Math.random().toString(36).slice(2, 10);
        let id = baseId;
        while (seenIds.has(id)) id = baseId + "-" + Math.random().toString(36).slice(2, 6);
        if (c.id && id !== c.id) remap[c.id] = id;
        seenIds.add(id);
        const pid = c.parentId ? (remap[c.parentId] || c.parentId) : null;
        insC.run(id, storyId, c.email || "", c.author || "", c.role || "Employee", c.text || "",
          c.at || new Date().toISOString(), c.edited ? 1 : 0, pid, JSON.stringify(c.likes || []));
      }
    }
    const insS = db.prepare("INSERT OR IGNORE INTO shares(id,at,by,toEmail,channel,storyId,title) VALUES(?,?,?,?,?,?,?)");
    for (const s of readLegacy("shares.json", [])) {
      if (!s || typeof s !== "object") continue;
      insS.run(s.id || "sh-mig-" + Math.random().toString(36).slice(2, 10), s.at || new Date().toISOString(),
        s.by || "", s.to || "", s.channel || "outlook", s.storyId || "", s.title || "");
    }
    const insA = db.prepare("INSERT OR IGNORE INTO activity(id,at,actor,action,summary,via,meta) VALUES(?,?,?,?,?,?,?)");
    for (const a of readLegacy("activity.json", [])) {
      if (!a || typeof a !== "object") continue;
      insA.run(a.id || "ac-mig-" + Math.random().toString(36).slice(2, 10), a.at || new Date().toISOString(),
        a.actor || "system", a.action || "", a.summary || "", a.via || "direct",
        a.meta && typeof a.meta === "object" ? JSON.stringify(a.meta) : null);
    }
    dbWrite("_migrated", { at: new Date().toISOString() });
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;                       // a failed migration must be loud, not silent
  }
  for (const f of LEGACY_FILES) archive(f);
  console.log("  ⛁ database: legacy JSON stores migrated into data/newsnext.db");
})();

// Second-stage migration: userdata used to be one document holding every
// user; each person now gets their own row (email-keyed, written through
// instantly) so one save never rewrites anyone else's data.
(function splitUserdataPerUser() {
  if (dbRead("_userdata_split", null)) return;
  const doc = dbRead("userdata", null);
  db.exec("BEGIN");
  try {
    if (doc && typeof doc === "object") {
      const put = db.prepare(
        "INSERT INTO userdata(email,value,updatedAt) VALUES(?,?,?) " +
        "ON CONFLICT(email) DO UPDATE SET value = excluded.value, updatedAt = excluded.updatedAt");
      for (const [email, u] of Object.entries(doc)) {
        put.run(String(email).toLowerCase(), JSON.stringify(u), (u && u.updatedAt) || new Date().toISOString());
      }
      db.prepare("DELETE FROM documents WHERE name = 'userdata'").run();
    }
    dbWrite("_userdata_split", { at: new Date().toISOString() });
    db.exec("COMMIT");
    if (doc) console.log("  ⛁ database: userdata split into per-user rows (" + Object.keys(doc).length + " users)");
  } catch (e) { db.exec("ROLLBACK"); throw e; }
})();
