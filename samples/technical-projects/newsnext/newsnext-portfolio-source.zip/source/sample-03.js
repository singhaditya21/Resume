// ═══════════════════════════════════════════════════════════════════════════
//  Image Engine · text.js — the shared semantic space.
//
//  Articles, taxonomy concepts and library images are ALL embedded into the
//  same 256-dimensional vector space using feature hashing (the "hashing
//  trick"), so matching is cosine similarity between meanings — not exact
//  keyword equality. Zero dependencies, deterministic, microsecond-fast,
//  and works fully offline (a hard requirement for NewsNext's runtime).
// ═══════════════════════════════════════════════════════════════════════════

export const DIM = 256;

const STOP = new Set(("the a an and or but of to in for on with as at by from into over after amid under about is are was were be been being this that these those it its his her their your our you we he she they them than then not no yes if so do does did done can could will would should may might must have has had having more most many much just also very new latest today daily says said announce announced report reports reported top big how why what who when where which while during between across against through per via vs amp up down out off all any some each other same own get gets got make makes made take takes took use uses used using year years week weeks day days month months time first last next one two three").split(" "));

// Very light suffix stemmer — enough to make "banking/banks/bank" and
// "engineers/engineering" collide without a real NLP dependency.
export function stem(w) {
  if (w.length <= 4) return w;
  return w
    .replace(/(ations|ation)$/, "ate")
    .replace(/(ities|ity)$/, "")
    .replace(/(ingly|edly)$/, "")
    .replace(/(ing|ed|ers|er|ies|es|s|ly)$/, "")
    .replace(/(tion|ment|ness)$/, "");
}

export function tokenize(text) {
  return (String(text || "").toLowerCase().match(/[a-z0-9][a-z0-9+#.-]*/g) || [])
    .map((w) => w.replace(/^[.-]+|[.-]+$/g, ""))
    .filter((w) => w.length > 1 && !STOP.has(w) && !/^\d+$/.test(w));
}

// FNV-1a → two independent hash streams (index + sign) per token.
function fnv(str, seed) {
  let h = 2166136261 ^ seed;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

// Embed a list of tokens (optionally weighted) into the shared space.
// Unigrams + adjacent bigrams so short phrases ("interest rates", "supply
// chain") carry their own meaning. L2-normalised so cosine = dot product.
export function embed(tokens, weights = null) {
  const v = new Float32Array(DIM);
  const add = (feat, w) => {
    const h1 = fnv(feat, 0x9747b28c), h2 = fnv(feat, 0x85ebca6b);
    v[h1 % DIM] += (h2 & 1 ? 1 : -1) * w;
  };
  for (let i = 0; i < tokens.length; i++) {
    const t = stem(tokens[i]);
    const w = weights ? (weights[i] ?? 1) : 1;
    add(t, w);
    if (i + 1 < tokens.length) add(t + "_" + stem(tokens[i + 1]), w * 0.6);
  }
  let n = 0; for (let i = 0; i < DIM; i++) n += v[i] * v[i];
  if (n > 0) { n = Math.sqrt(n); for (let i = 0; i < DIM; i++) v[i] /= n; }
  return v;
}

export function cosine(a, b) {
  let s = 0; for (let i = 0; i < DIM; i++) s += a[i] * b[i];
  return s;
}

export function embedText(text) { return embed(tokenize(text)); }

// ── Entity extraction ──────────────────────────────────────────────────────
// Named entities = capitalised word runs ("Goldman Sachs", "Google Cloud")
// and acronyms ("RBI", "GDPR", "LLM"). These drive both retrieval boosts and
// the learning loop that discovers new companies/products over time.
// Entity-quality gate. Words capitalised for GRAMMAR (sentence starts,
// headline title-case) or generic acronyms (protocols, roles, units) are not
// proper nouns and must never become taxonomy concepts — that is what put
// "Find", "Six", "SSL", "TCP" into the learning loop next to Infosys.
const ENT_STOP = new Set(("The A An And Or But Of To In For On With As At By From Into Over After How Why What Who When Where Which While New Its This That Your Our These Those Here There Not Are Is Was Were").split(" "));
const ENT_COMMON = new Set((
  "the a an and or but nor of to in for on with as at by from into onto over under above below after before amid despite during since until through across against between about is are was were be been being am this that these those it its his her their our your you we he she they them who whom whose not no yes if so do does did done can could will would shall should may might must have has had having more most many much few less least just also very too then than now today tomorrow yesterday new latest next last first second third fourth fifth sixth here there when why what which while per via vs versus up down out off all any some each every another other same own get got make made take took give gave go goes went come came see saw know knew think thought say said tell told find found show showed shows use used one two three four five six seven eight nine ten eleven twelve twenty thirty forty fifty hundred thousand million billion trillion monday tuesday wednesday thursday friday saturday sunday jan feb mar apr may jun jul aug sep sept oct nov dec january february march april june july august september october november december mr mrs ms dr prof sir according including plus meanwhile however therefore thus still yet even once again ever never always often big small good bad best worst top high low major minor early late soon later"
).split(" "));
// Editorial / section / byline labels. Capitalised in headlines and bylines
// but never a subject: "Opinion", "Govt", "Explained", "Watch", "Exclusive".
// These flooded the loop as much as the sentence-starters did.
const ENT_LABEL = new Set((
  "opinion opinions analysis explainer explained editorial column columns feature features interview interviews review reviews preview previews update updates report reports reported roundup recap recaps live liveblog blog watch video videos photos photo gallery podcast podcasts newsletter poll polls quiz survey exclusive breaking developing sponsored advertisement advertorial promoted trending highlights summary factbox timeline govt government official officials statement statements source sources press release releases briefing brief bulletin coverage story stories update alert alerts news views special report full read watch listen"
).split(" "));
// Generic single-word nouns/adjectives/demonyms that read as capitalised words
// in headlines ("Foreign", "Experts", "Indians", "Growth") but are not brands.
// Generic single tokens that surface capitalised in headlines but are ordinary
// English words, not brands. Deliberately excludes words that ARE major brands
// (Meta, Apple, Oracle, Visa, Amazon, Gemini, Alphabet, Mercury, Boeing…), so
// those still promote. Also feeds RUN_BAD, so a multi-word run containing any of
// them ("Growth Analysis Report") is rejected as a headline fragment.
const ENT_EXTRA = new Set((
  // nouns / adjectives / demonyms
  "month months week weeks day days hour hours moment moments times season seasons back check help foreign local global national regional domestic year years quarter result results expert experts recent growth rate rates sale sales upgrade downgrade rating best worse worst better read data figures numbers move moves deal deals talk talks push boost jump surge slump plunge rise fall gain gains loss losses profit profits revenue earnings guidance outlook forecast target price prices stock stocks share shares market markets economy sector industry firm firms company companies group unit only guide guides trend trends buy valuation billion million trillion here there ways way tips tip reasons reason things thing steps step list lists decade decades cyber fiscal budget automation era future past present strategy strategies annual monthly weekly daily quarterly team teams start end plan plans idea ideas story stories deal note notes take takes fix fixes need needs wave hub era edge core power boom bust risk risks trend cash fund funds loan loans debt tax taxes job jobs hire hiring layoff layoffs deal " +
  // verbs (incl. -s / -ed / -ing forms that title-case turns into pseudo-nouns)
  "start starts started starting expand expands expanded expanding grow grows grew grown growing drive drives drove driven driving build builds built building join joins joined joining win wins won winning lose loses lost seek seeks sought seeking eye eyes eyed eyeing weigh weighs mull mulls mulled face faces faced need needs needed want wants wanted call calls called bring brings brought hold holds held turn turns turned open opens opened close closes closed stop stops stopped keep keeps kept run runs ran launch launches launched launching boost boosts boosted raise raises raised cut cuts cutting add adds added hit hits jump jumps jumped surge surges surged plan plans planned planning meet meets meeting set sets see sees seen show shows showed find finds found tell tells told use uses used help helps helped explore explores explored exploring reveal reveals revealed unveil unveils unveiled announce announces announced report reports reported push pushes pushed pull pulls pulled back backs backed name names named move moves moved make makes made take takes took give gives gave " +
  // demonyms
  "indian indians american americans russian russians japanese chinese europeans european britons british german germans french koreans korean pakistani pakistanis australian australians canadian canadians africans african israeli israelis ukrainian ukrainians spanish italian dutch swiss turkish arab arabs asian asians"
).trim().split(/\s+/));
// Generic acronyms that are NOT brands. Real-company acronyms (IBM, SAP, TCS,
// CUSTOMER_REDACTED, NASA, NPCI, RBI) are deliberately absent and still pass through.
const ENT_ACRONYM_STOP = new Set((
  "SSL TLS TCP UDP HTTP HTTPS HTML CSS JSON XML API SDK URL URI USB HDMI RAM ROM CPU GPU SSD HDD PC OS DNS VPN LAN WAN SQL PDF DOC PPT CSV FAQ DIY ASAP FYI AKA ETA VP MD GM CEO CFO CTO COO CMO CIO CXO HR PR QA UX UI KPI ROI CAGR EPS AR VR NLP IOT EV SME SMB KYC AML OTP PIN ATM EMI GST VAT TDS USD INR EUR GBP JPY USA UAE UK EU UN US NEWS LIVE FREE NEW TOP WSJ NYT PTI ANI IANS AFP"
).split(" "));
// Words that never appear inside a real entity run — labels, generic nouns, and
// verbs/gerunds from title-case headlines ("Growth Analysis Report", "Gold Rate
// Today", "Exploring Sale"). Excludes structural words (of/&) and honorifics,
// which legitimately sit inside real runs ("Bank of America", "Dr Reddy").
const RUN_BAD = new Set([...ENT_LABEL, ...ENT_EXTRA,
  "shows", "show", "says", "said", "eyeing", "exploring", "launching", "announcing",
  "unveiling", "revealing", "weighing", "mulling", "planning", "seeking", "raising",
  "cutting", "backing", "pushing", "building", "setting", "getting", "making", "taking",
  "today", "tomorrow", "yesterday", "amid", "estimates", "analysis"]);
// News outlets are proper nouns but not visual subjects — promoting them as
// concepts just adds noise. Multi-word outlet names auto-pass the run test, so
// suppress the frequent ones explicitly, plus any run ending in an outlet word.
const PUBLISHER_STOP = new Set(
  ("the economic times|economic times|times of india|hindustan times|the hindu|indian express|the indian express|financial express|business standard|business today|livemint|mint|moneycontrol|the print|the wire|news18|cnbc|cnbc tv18|bloomberg|reuters|associated press|press trust of india|asian news international|the guardian|the new york times|new york times|the washington post|washington post|the wall street journal|wall street journal|financial times|cnn|bbc|bbc news|fox news|al jazeera|the verge|techcrunch|ars technica|engadget|wired|deccan herald|the statesman|firstpost|the quint|outlook|forbes|fortune|the economist|yahoo finance|india today|times now|ndtv|zee news|scroll")
    .split("|")
);
const OUTLET_TAIL = new Set("Times Herald Tribune Chronicle Gazette Newswire Newspaper Post Journal Journals Wire Weekly Magazine Review Digest Ledger Reporter".split(" "));
// True only for things that read like real proper nouns: a multi-word
// capitalised run (that is not an outlet name), a genuine acronym, or a single
// capitalised word that is not a common / label word. Filters extraction AND
// gates promotion into the taxonomy.
export function isProperEntity(name) {
  const n = String(name || "").trim();
  if (n.length < 3) return false;
  const low = n.toLowerCase();
  if (PUBLISHER_STOP.has(low)) return false;                // named news outlet
  if (/\s/.test(n)) {                                        // multi-word run
    const words = n.split(/\s+/);
    if (OUTLET_TAIL.has(words[words.length - 1])) return false;      // "… Times/Herald" → outlet
    if (words.some((w) => RUN_BAD.has(w.toLowerCase()))) return false; // headline fragment, not an entity
    return true;                                             //   otherwise a proper-noun run
  }
  if (ENT_ACRONYM_STOP.has(n.toUpperCase())) return false;   // generic acronym
  if (ENT_COMMON.has(low) || ENT_LABEL.has(low) || ENT_EXTRA.has(low)) return false; // common / editorial / generic word
  if (/^[A-Z]{3,}$/.test(n)) return true;                    // real acronym (TCS, CUSTOMER_REDACTED)
  if (/^[A-Z][A-Z0-9]*[&.+][A-Z0-9&.+]*$/.test(n)) return true; // symbol acronym (S&P, AT&T)
  if (/^[A-Z][a-z].{1,}/.test(n)) return true;               // Capitalised word (Infosys)
  return false;
}
export function extractEntities(text) {
  const found = new Map();
  const push = (name) => {
    const key = name.trim();
    if (key.length < 2 || ENT_STOP.has(key)) return;
    found.set(key, (found.get(key) || 0) + 1);
  };
  // Capitalised runs (allow inner "of/&": "Bank of America"). "and" is NOT a
  // connective here — it merges distinct entities ("Infosys and CUSTOMER_REDACTED Bank").
  const runRe = /\b([A-Z][a-zA-Z0-9.+-]*(?:\s+(?:of|&)?\s*[A-Z][a-zA-Z0-9.+-]*){0,4})\b/g;
  let m;
  while ((m = runRe.exec(text))) { if (m[1].length > 2 || /^[A-Z]{2,}$/.test(m[1])) push(m[1]); }
  // Acronyms
  const acRe = /\b[A-Z]{2,6}\b/g;
  while ((m = acRe.exec(text))) push(m[0]);
  return [...found.entries()]
    .filter(([n]) => isProperEntity(n))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12)
    .map(([name, count]) => ({ name, count }));
}

// TF-weighted keyword list (title tokens count double).
export function extractKeywords(title, summary, topN = 14) {
  const tf = new Map();
  for (const t of tokenize(title)) tf.set(t, (tf.get(t) || 0) + 2);
  for (const t of tokenize(summary)) tf.set(t, (tf.get(t) || 0) + 1);
  return [...tf.entries()].sort((a, b) => b[1] - a[1]).slice(0, topN).map(([w]) => w);
}
