// Automatic snapshots of every persistent store in data/ — the layer that
// protects analytics and user saves against what the Docker volume can't:
// disk failure, an accidental `docker volume rm`, a fat-fingered prune.
//
// A snapshot is taken at every boot (so each deploy leaves a restore point at
// its boundary) and daily at 03:30 IST. Snapshots go to backups/ — in prod
// that's a bind mount to the Spark's own filesystem (./data-backups), a
// different physical location than the data volume. Newest 14 are kept.
//
// Restore: stop the app, DELETE data/newsnext.db-wal and -shm (a stale WAL
// would replay over the restored file), copy the snapshot's files into
// data/, then start the app.
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "..", "data");
const DEST = path.join(__dirname, "..", "backups");
const KEEP = 14;

// What gets snapshotted: the SQLite database (users, userdata, comments,
// shares, approvals, reports, activity, …) via VACUUM INTO — the only safe
// way to copy a live WAL database — plus analytics.json, which deliberately
// stays file-based (daily snapshots are its recovery story). Caches (news,
// images, directory) are regenerable and excluded to keep snapshots tiny.
import { backupDbTo } from "./db.js";
const STORES = ["analytics.json"];

const stamp = () => {
  const d = new Date(), p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
};

export function backupNow(log = console.log) {
  try {
    const dir = path.join(DEST, "backup-" + stamp());
    fs.mkdirSync(dir, { recursive: true });
    let n = 0, bytes = 0;
    const dbCopy = path.join(dir, "newsnext.db");
    backupDbTo(dbCopy);                          // consistent point-in-time copy, WAL-safe
    n++; bytes += fs.statSync(dbCopy).size;
    for (const f of STORES) {
      const src = path.join(DATA, f);
      if (!fs.existsSync(src)) continue;
      fs.copyFileSync(src, path.join(dir, f));   // sources are written atomically (tmp+rename)
      n++; bytes += fs.statSync(src).size;
    }
    // rotate: newest KEEP snapshot folders stay, the rest go
    const all = fs.readdirSync(DEST).filter((d) => d.startsWith("backup-")).sort();
    for (const old of all.slice(0, Math.max(0, all.length - KEEP))) {
      fs.rmSync(path.join(DEST, old), { recursive: true, force: true });
    }
    log(`  ⛁ backup: ${n} stores → ${path.basename(dir)} (${(bytes / 1024).toFixed(0)}KB, keeping ${Math.min(all.length, KEEP)})`);
    return dir;
  } catch (e) { log("  ⚠ backup failed —", e.message); return null; }
}

// Daily at 03:30 IST (fixed UTC+5:30, no DST — same arithmetic as the
// directory sync). The timer never holds the process open.
const IST_OFFSET_MS = 5.5 * 3600e3;
function msUntil0330IST(now = Date.now()) {
  const shifted = now + IST_OFFSET_MS;
  const day = 86400e3, target = 3.5 * 3600e3;                 // 03:30
  let delta = (Math.floor(shifted / day) * day + target) - shifted;
  if (delta < 1000) delta += day;
  return delta;
}
export function scheduleBackups(log = console.log) {
  backupNow(log);                                             // boot = deploy-boundary restore point
  const arm = () => {
    const t = setTimeout(() => { backupNow(log); arm(); }, msUntil0330IST());
    if (t.unref) t.unref();
  };
  arm();
  return msUntil0330IST();
}
