"""Validation pipeline v3 — orchestrates the full validation flow.

v3: Multi-strategy element discovery (AX tree + DOM + LLM) + HAR cross-validation.
Writes detailed logs to a file for real-time SSE streaming to frontend.
"""

import logging
import os
import traceback
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import create_standalone_session_factory
from app.models.configuration import Configuration
from app.models.execution_run import ExecutionRun
from app.models.page_model import PageModel
from app.models.element_registry import ElementRegistry
from app.models.test_case_result import TestCaseResult
from app.utils.crypto import decrypt
from app.services.playwright_engine import PlaywrightEngine
from app.services.dom_analyzer import DomAnalyzer
from app.services.evidence_service import EvidenceService
from app.services.healing_engine import HealingEngine
from app.services.visual_regression import VisualRegressionService
from app.services.api_engine import APIEngine
from app.routers.websocket import broadcast_run_update, broadcast_action

settings = get_settings()


async def run_validation_pipeline(run_id: str):
    """Execute the full validation pipeline for a given run.

    Flow: decrypt creds → login → discover pages → for each page:
      capture DOM → discover elements → validate each → evidence → results

    All steps are logged to EVIDENCE_DIR/{run_id}/pipeline.log for live SSE streaming.
    """
    # Set up file-based logging for this run
    from app.services.log_store import setup_pipeline_logger
    logger = setup_pipeline_logger(run_id)
    logger.info(f"╔══════════════════════════════════════════════════")
    logger.info(f"║ Pipeline started for run: {run_id}")
    logger.info(f"╚══════════════════════════════════════════════════")

    # Initialize self-learning knowledge store
    try:
        from app.services.learning_store import LearningStore
        learning = LearningStore()
        learning.start_run()
    except Exception as e:
        logger.warning(f"Learning store init failed (non-fatal): {e}")

    # Create a standalone session factory for this subprocess
    session_factory = create_standalone_session_factory()
    async with session_factory() as db:
        engine = PlaywrightEngine()
        all_elements = []  # Initialize before try — needed in finally block for HAR
        try:
            # 1. Load run and configuration
            logger.info("⏳ Step 1: Loading run and configuration...")
            run = await _load_run(db, run_id)
            if not run:
                logger.error(f"Run {run_id} not found in database")
                return

            config = await _load_config(db, run.configuration_id)
            if not config:
                logger.error("Configuration not found")
                await _fail_run(db, run, "Configuration not found", logger)
                return

            logger.info(f"✓ Configuration: {config.name} ({config.target_url})")
            logger.info(f"✓ Target roles: {run.selected_target_roles}")
            logger.info(f"✓ Selected pages: {run.selected_pages}")

            analyzer = DomAnalyzer()
            evidence_svc = EvidenceService(str(run_id))

            # Mark running
            run.status = "running"
            run.started_at = datetime.utcnow()
            await db.commit()

            # 2. Decrypt credentials
            logger.info("⏳ Step 2: Decrypting credentials...")
            target_url = config.target_url
            username = decrypt(config.encrypted_username)
            password = REDACTED_SECRET
            logger.info(f"✓ Credentials decrypted for user: {username[:3]}***")

            # 3. API-Level Backend Validation
            api_endpoints = config.api_endpoints or []
            if api_endpoints:
                logger.info(f"")
                logger.info(f"⏳ Step 3: Executing {len(api_endpoints)} API Endpoint Tests...")
                
                api_engine = APIEngine()
                try:
                    # Execute all REST API endpoints configured (with Jinja2 payload compilation)
                    api_results = await api_engine.execute_endpoints(
                        base_url=target_url, 
                        endpoints=api_endpoints
                    )
                    
                    # Store results in the same database table alongside UI tests
                    for ep_result in api_results:
                        db.add(TestCaseResult(
                            run_id=run.id,
                            test_type="api",
                            test_name=ep_result["test_name"],
                            status=ep_result["status"],
                            expected_value=ep_result["expected_value"],
                            actual_value=ep_result["actual_value"],
                            error_message=ep_result.get("error_message"),
                            duration_ms=ep_result["duration_ms"],
                            executed_at=datetime.utcnow()
                        ))
                        # Update rolling counters based on API results
                        if ep_result["status"] == "passed":
                            run.passed_count += 1
                        elif ep_result["status"] == "failed":
                            run.failed_count += 1
                        else:
                            run.error_count += 1
                            
                    await db.flush()
                    logger.info("✓ API-Level Validation Complete.")
                except Exception as e:
                    logger.error(f"❌ Critical API Execution Error: {e}")
                finally:
                    await api_engine.close()
            else:
                logger.info(f"⏳ Step 3: Skipping API Validation (No endpoints configured)")

            # 4. Start browser with HAR capture
            logger.info(f"⏳ Step 4: Launching {run.browser_type.capitalize()} browser...")
            har_dir = os.path.join(settings.EVIDENCE_DIR, str(run_id))
            await engine.start(headless=False, har_dir=har_dir, browser_type=run.browser_type)
            logger.info(f"✓ {run.browser_type.capitalize()} browser launched (headed mode)")

            # 4. Login to target system
            logger.info(f"⏳ Step 4: Logging into {target_url}...")
            await broadcast_action(str(run.id), "login", target_url, "started", "Logging into target system")
            await engine.login(target_url, username, password)
            await broadcast_action(str(run.id), "login", target_url, "success", "Login successful")
            logger.info("✓ Login successful!")

            # Broadcast login success
            await broadcast_run_update(str(run.id), {
                "type": "run_update",
                "status": "running",
                "step": "login_complete",
                "message": "Login successful, starting visual scan...",
                "passed_count": run.passed_count or 0,
                "failed_count": run.failed_count or 0,
                "error_count": run.error_count or 0,
                "total_elements": 0,
            })

            # ── Phase 1: SCAN — Visual Discovery ──────────────────────
            # Screenshot every tab, chart, and link BEFORE validation
            scan_manifest = None
            try:
                from app.services.scanner import PageScanner
                scanner = PageScanner(
                    engine=engine,
                    evidence_dir=os.path.join(settings.EVIDENCE_DIR, str(run_id)),
                    logger_override=logger,
                )
                logger.info(f"⏳ Step 4.5: Visual SCAN — screenshotting all tabs and charts...")
                await broadcast_action(str(run.id), "scan", "Summary Page", "started", "Visual scan: tabs, charts, links")
                scan_manifest = await scanner.scan_page("Summary Page")
                await broadcast_action(str(run.id), "scan", "Summary Page", "success",
                                       f"{len(scan_manifest.get('charts', []))} charts, {len(scan_manifest.get('screenshots', []))} screenshots")
                logger.info(f"✓ Visual scan done: {len(scan_manifest.get('charts', []))} charts, "
                            f"{len(scan_manifest.get('screenshots', []))} screenshots")
            except Exception as scan_err:
                logger.warning(f"⚠️ Visual scan failed (non-fatal): {scan_err}")
                logger.warning(traceback.format_exc())

            # ── Phase 1b: VIDEO PLAYBOOK — Replay exact video sequence ──
            playbook_results = None
            try:
                from app.services.video_playbook import VideoPlaybook
                playbook = VideoPlaybook(
                    engine=engine,
                    evidence_dir=os.path.join(settings.EVIDENCE_DIR, str(run_id)),
                    run_id=str(run_id),
                    logger_override=logger,
                )
                logger.info(f"⏳ Step 4.55: VIDEO PLAYBOOK — replaying {186}s navigation sequence...")
                await broadcast_action(str(run.id), "playbook", "Administrator Summary", "started",
                                       "Replaying video navigation: 5 phases, 40 steps")
                playbook_results = await playbook.execute()
                pb_rate = (
                    round(playbook_results['succeeded'] / max(1, playbook_results['total_steps']) * 100, 1)
                )
                await broadcast_action(str(run.id), "playbook", "Administrator Summary", "success",
                                       f"{playbook_results['succeeded']}/{playbook_results['total_steps']} steps OK ({pb_rate}%)")
                logger.info(f"✓ Video Playbook: {playbook_results['succeeded']}/{playbook_results['total_steps']} steps OK, "
                            f"{len(playbook_results['screenshots'])} screenshots")

                # Generate test cases from playbook results + feed autoresearch
                try:
                    from app.services.playbook_test_generator import PlaybookTestGenerator
                    pb_gen = PlaybookTestGenerator(
                        run_id=str(run.id),
                        evidence_dir=os.path.join(settings.EVIDENCE_DIR, str(run_id)),
                        logger_override=logger,
                    )
                    pb_summary = await pb_gen.generate_from_results(playbook_results, db)

                    # Update run counters with playbook test results
                    run.passed_count = (run.passed_count or 0) + playbook_results['succeeded']
                    run.failed_count = (run.failed_count or 0) + playbook_results['failed']
                    run.total_elements = (run.total_elements or 0) + playbook_results['total_steps']
                    await db.commit()

                    if pb_summary.get("suggestions"):
                        for sug in pb_summary["suggestions"]:
                            logger.info(f"  💡 {sug['type']}: {sug['detail']}")
                except Exception as gen_err:
                    logger.warning(f"⚠️ Playbook test generation failed (non-fatal): {gen_err}")

            except Exception as pb_err:
                logger.warning(f"⚠️ Video playbook failed (non-fatal): {pb_err}")
                logger.warning(traceback.format_exc())

            # ── Phase 2: TRAIN — Analyze screenshots with vision LLM ──
            catalog = None
            if scan_manifest and scan_manifest.get("charts"):
                try:
                    from app.services.trainer import ChartTrainer
                    trainer = ChartTrainer(
                        evidence_dir=os.path.join(settings.EVIDENCE_DIR, str(run_id)),
                        logger_override=logger,
                    )
                    logger.info(f"⏳ Step 4.6: TRAIN — analyzing {len(scan_manifest['charts'])} charts with LLM...")
                    await broadcast_action(str(run.id), "train", f"{len(scan_manifest['charts'])} charts", "started", "LLM chart analysis")
                    catalog = await trainer.train(scan_manifest)
                    await broadcast_action(str(run.id), "train", f"{len(catalog.get('elements', []))} elements", "success", "Chart classification complete")
                    logger.info(f"✓ Training done: {len(catalog.get('elements', []))} elements cataloged")
                except Exception as train_err:
                    logger.warning(f"⚠️ Chart training failed (non-fatal): {train_err}")

            # ── Phase 3: WRITE — Auto-generate test cases ─────────────
            if catalog and catalog.get("elements"):
                try:
                    from app.services.test_writer import TestWriter
                    writer = TestWriter(
                        evidence_dir=os.path.join(settings.EVIDENCE_DIR, str(run_id)),
                        logger_override=logger,
                    )
                    logger.info(f"⏳ Step 4.7: WRITE — generating test cases for {len(catalog['elements'])} charts...")
                    test_script = writer.generate(catalog)
                    if test_script:
                        logger.info(f"✓ Generated test script: {test_script}")
                except Exception as write_err:
                    logger.warning(f"⚠️ Test generation failed (non-fatal): {write_err}")

            # 5. Determine pages to validate
            pages_to_validate = run.selected_pages or []
            if not pages_to_validate or pages_to_validate == ["auto"]:
                logger.info("⏳ Step 5: Auto-discovering pages from navigation...")
                nav_items = await engine.discover_navigation_items()
                pages_to_validate = [item["label"] for item in nav_items[:10]]
                logger.info(f"✓ Auto-discovered {len(pages_to_validate)} pages: {pages_to_validate}")
            else:
                logger.info(f"⏳ Step 5: Using selected pages: {pages_to_validate}")

            # 6. For each page: capture → discover → validate
            all_elements = []
            for page_idx, page_name in enumerate(pages_to_validate):
                logger.info(f"")
                logger.info(f"━━━ Page {page_idx + 1}/{len(pages_to_validate)}: {page_name} ━━━")

                # Capture DOM
                logger.info(f"  📸 Capturing DOM snapshot...")
                await broadcast_action(str(run.id), "navigate", page_name, "started", f"Page {page_idx + 1}/{len(pages_to_validate)}")

                # Broadcast page progress
                await broadcast_run_update(str(run.id), {
                    "type": "run_update",
                    "status": "running",
                    "step": f"capturing_page_{page_idx + 1}",
                    "message": f"Capturing DOM for page {page_idx + 1}/{len(pages_to_validate)}: {page_name}",
                    "passed_count": run.passed_count or 0,
                    "failed_count": run.failed_count or 0,
                    "error_count": run.error_count or 0,
                    "total_elements": len(all_elements),
                })

                dom_data = await engine.capture_page_dom(page_name)
                await broadcast_action(str(run.id), "navigate", page_name, "success", f"DOM captured from {dom_data.get('url', 'unknown')[:60]}")
                logger.info(f"  ✓ DOM captured (URL: {dom_data.get('url', 'unknown')})")

                # Visual Regression Testing Loop
                try:
                    logger.info(f"  👁️ Running visual regression check...")
                    vis_svc = VisualRegressionService()
                    scr_path = evidence_svc.get_screenshot_path(f"fullpage_{page_name}")
                    if await engine.take_full_page_screenshot(scr_path):
                        vis_result = vis_svc.compare_screenshot(
                            page_name=page_name, 
                            role=(run.selected_target_roles or ["Administrator"])[0], 
                            current_screenshot_path=scr_path
                        )
                        
                        # Add test case result for visual regression
                        vis_status = "passed" if vis_result["status"] in ["passed", "baseline_set"] else "failed"
                        db.add(TestCaseResult(
                            run_id=run.id,
                            test_type="visual",
                            test_name=f"Visual Regression Check: {page_name}",
                            page_name=page_name,
                            status=vis_status,
                            expected_value="Pixels match baseline (<=1% diff)",
                            actual_value=f"{vis_result['diff_pct']:.3f}% difference",
                            error_message=vis_result["message"] if vis_status == "failed" else None,
                            screenshot_path=vis_result["diff_path"] or scr_path,
                            duration_ms=0,
                            executed_at=datetime.utcnow()
                        ))
                        await db.flush()
                        
                        if vis_status == "passed":
                            logger.info(f"  ✓ {vis_result['message']}")
                        else:
                            logger.error(f"  ❌ {vis_result['message']}")
                except Exception as ve:
                    logger.warning(f"  ⚠️ Visual regression failed context: {ve}")

                # 6a. Accessibility Testing (WCAG 2.1 via axe-core) — non-fatal
                try:
                    from app.services.accessibility_service import AccessibilityService
                    a11y_svc = AccessibilityService()
                    logger.info(f"  ♿ Running accessibility audit (WCAG 2.1)...")
                    a11y_result = await a11y_svc.audit_page(engine.page, page_name)

                    for tr_data in a11y_result.get("test_results", []):
                        db.add(TestCaseResult(
                            run_id=run.id,
                            test_name=tr_data["test_name"],
                            page_name=tr_data.get("page_name", page_name),
                            test_type=tr_data.get("test_type", "accessibility"),
                            status=tr_data.get("status", "skipped"),
                            expected_value=tr_data.get("expected_value"),
                            actual_value=tr_data.get("actual_value"),
                            error_message=tr_data.get("error_message"),
                            duration_ms=0,
                            executed_at=datetime.utcnow(),
                        ))
                    await db.flush()
                except Exception as a11y_err:
                    logger.warning(f"  ⚠️ Accessibility audit failed (non-fatal): {a11y_err}")

                # Detect page context
                page_context = analyzer.detect_page_context(
                    dom_data["structure"], dom_data.get("url", "")
                )
                logger.info(f"  📋 Page context: {page_context}")

                # Store page model
                page_model = PageModel(
                    configuration_id=config.id,
                    run_id=run.id,
                    page_name=page_context.get("page_name", page_name),
                    target_role_context=(run.selected_target_roles or ["Administrator"])[0],
                    dom_snapshot=dom_data.get("structure"),
                    dom_html=dom_data.get("html", "")[:500000],
                )
                db.add(page_model)
                await db.flush()

                # Discover elements using multi-strategy approach (AX tree + DOM patterns)
                logger.info(f"  🔍 Discovering elements (multi-strategy)...")
                ax_tree = dom_data.get("ax_tree")
                dom_tree = dom_data.get("structure")
                await broadcast_action(str(run.id), "discover", page_name, "started", "Multi-strategy element discovery")
                discovered = analyzer.discover_all(ax_tree, dom_tree)
                await broadcast_action(str(run.id), "discover", page_name, "success", f"{len(discovered)} elements found")
                logger.info(f"  ✓ Found {len(discovered)} elements on {page_name}")


                # 6a-ii. LLM element discovery DISABLED — was hallucinating fake elements
                # (e.g., "Highcharts Chart: Revenue Growth", "KPI Card: Sales Performance")
                # that don't exist on the page, causing 100% failure rate on those test cases.
                # LLM is still used later for: element enrichment, chart click analysis, healing.

                # 6a-iii. Capture elements from drill-down popup windows
                try:
                    popup_elements = await engine.capture_popup_elements()
                    if popup_elements:
                        existing_names = {e["name"].lower() for e in discovered}
                        new_popups = [p for p in popup_elements if p["name"].lower() not in existing_names]
                        discovered.extend(new_popups)
                        logger.info(f"  ✓ Popups added {len(new_popups)} drill-down elements")
                except Exception as e:
                    logger.warning(f"  ⚠️ Popup capture failed (non-fatal): {e}")

                # Broadcast element discovery progress
                await broadcast_run_update(str(run.id), {
                    "type": "run_update",
                    "status": "running",
                    "step": f"elements_discovered_{page_idx + 1}",
                    "message": f"Found {len(discovered)} elements on {page_name}",
                    "passed_count": run.passed_count or 0,
                    "failed_count": run.failed_count or 0,
                    "error_count": run.error_count or 0,
                    "total_elements": len(all_elements) + len(discovered),
                })

                for elem in discovered:
                    all_elements.append({
                        "page_model_id": page_model.id,
                        "page_name": page_name,
                        **elem,
                    })

                    # Map element type to valid enum values
                    valid_types = {
                        "chart", "report", "tab", "card", "button", "menu",
                        "link", "side_panel", "container", "widget",
                        "input", "table", "other",
                    }
                    elem_type = elem.get("type", "other")
                    if elem_type not in valid_types:
                        elem_type = "other"

                    # Store in registry
                    registry_entry = ElementRegistry(
                        page_model_id=page_model.id,
                        element_name=elem["name"][:255],
                        element_type=elem_type,
                        css_selector=elem.get("selector", "")[:1024],
                        text_content=elem.get("text", "")[:500],
                        is_active=True,
                    )
                    db.add(registry_entry)

                    logger.info(f"    → {elem_type}: {elem['name'][:60]}")

            # Update totals
            run.total_elements = len(all_elements)
            await db.commit()

            logger.info(f"")
            logger.info(f"╔══════════════════════════════════════════════════")
            logger.info(f"║ Total elements discovered: {len(all_elements)}")
            logger.info(f"╚══════════════════════════════════════════════════")

            # Check for 0 elements — this is an error
            if len(all_elements) == 0:
                error_msg = (
                    "No elements discovered on any page. "
                    "This may indicate: login failed silently, the page didn't load fully, "
                    "or the DOM analyzer couldn't match any elements."
                )
                logger.error(f"❌ {error_msg}")
                await _fail_run(db, run, error_msg, logger)
                return

            # 6c. Recursive drill-down exploration (non-fatal)
            try:
                from app.services.drill_down_engine import DrillDownEngine
                drill_evidence = os.path.join(settings.EVIDENCE_DIR, str(run_id))
                drill_engine = DrillDownEngine(
                    engine=engine, analyzer=analyzer,
                    max_depth=3, max_elements_per_level=10,
                    max_total_time_s=120,
                    evidence_dir=drill_evidence,
                    logger_override=logger,
                )
                # Run drill-down for each page's elements
                for page_name_dd in set(e.get("page_name", "") for e in all_elements):
                    page_elems = [e for e in all_elements if e.get("page_name") == page_name_dd]
                    logger.info(f"")
                    logger.info(f"🔽 Step 6c: Recursive drill-down for '{page_name_dd}'...")
                    drill_report = await drill_engine.explore_drilldowns(page_elems, page_name_dd)

                    if drill_report.discovered_elements:
                        # Tag and append drill-discovered elements
                        for de in drill_report.discovered_elements:
                            de["page_name"] = page_name_dd
                            all_elements.append(de)
                        logger.info(f"  ✓ Drill-down added {drill_report.total_sub_elements} sub-elements")

                    # Store drill-down test results in DB
                    for tr_data in drill_report.test_results:
                        from app.models.test_case_result import TestCaseResult as TCR
                        db.add(TCR(
                            run_id=run.id,
                            test_name=tr_data["test_name"],
                            page_name=tr_data.get("page_name", "Unknown"),
                            test_type=tr_data.get("test_type", "drill_down"),
                            status=tr_data.get("status", "skipped"),
                            expected_value=tr_data.get("expected_value"),
                            actual_value=tr_data.get("actual_value"),
                            error_message=tr_data.get("error_message"),
                            duration_ms=tr_data.get("duration_ms"),
                        ))

                    # Update run totals after drill-down
                    run.total_elements = len(all_elements)
                    await db.commit()

                    if drill_report.warnings:
                        for w in drill_report.warnings:
                            logger.warning(f"  ⚠️ {w}")

                    logger.info(f"  📊 Drill summary: {drill_report.summary}")
            except Exception as e:
                logger.warning(f"⚠️ Drill-down exploration failed (non-fatal): {e}")

            # 6b. LLM enhancement (optional — falls back gracefully)
            try:
                from app.services.llm_service import LLMService
                llm = LLMService()
                if await llm.is_available():
                    logger.info("🤖 LLM server detected — enriching elements with AI...")
                    all_elements = await llm.classify_elements(all_elements, {"pages": pages_to_validate})
                    logger.info("✓ LLM enrichment complete")
                else:
                    logger.info("ℹ️ LLM server not running — using pattern-based classification only")
            except Exception as e:
                logger.warning(f"⚠️ LLM enrichment failed (non-fatal): {e}")

            # 7. Validate each element
            logger.info(f"")
            logger.info(f"⏳ Step 7: Validating {len(all_elements)} elements...")
            passed = 0
            failed = 0
            errors = 0

            for idx, elem in enumerate(all_elements):
                try:
                    # Broadcast validation start
                    await broadcast_action(str(run.id), "validate", elem['name'][:80],
                                           "started", f"[{idx+1}/{len(all_elements)}] Checking visibility",
                                           action_index=idx+1, total_actions=len(all_elements))

                    # Visibility validation
                    result = await engine.check_element_visible(elem["selector"])
                    is_visible = result.get("visible", False) if isinstance(result, dict) else result

                    status = "passed" if is_visible else "failed"
                    actual_value = "visible" if is_visible else "not visible"

                    # ── Self-Healing Loop ──
                    screenshot_path = None
                    if status == "failed":
                        logger.info(f"  [Healing] Attempting to self-heal '{elem['name'][:30]}'...")
                        await broadcast_action(str(run.id), "heal", elem['name'][:80],
                                               "started", "Self-healing: trying alternative selectors",
                                               action_index=idx+1, total_actions=len(all_elements))
                        healer = HealingEngine()
                        page_elems = [e for e in all_elements if e.get("page_name") == elem.get("page_name")]
                        
                        new_selector = await healer.attempt_heal(
                            failed_elem=elem,
                            current_page_elements=page_elems,
                            page_context={"page_name": elem.get("page_name", "Unknown")}
                        )

                        if new_selector:
                            heal_result = await engine.check_element_visible(new_selector)
                            is_still_visible = heal_result.get("visible", False) if isinstance(heal_result, dict) else heal_result
                            
                            if is_still_visible:
                                status = "passed"
                                actual_value = f"Auto-healed from [{elem['selector']}] to [{new_selector}]"
                                logger.info(f"  [Healing] ✅ Successfully healed element. New selector works!")
                                await broadcast_action(str(run.id), "heal", elem['name'][:80],
                                                       "success", f"Healed: {new_selector[:60]}",
                                                       action_index=idx+1, total_actions=len(all_elements))
                                
                                db_elem_result = await db.execute(
                                    select(ElementRegistry)
                                    .where(ElementRegistry.page_model_id == elem["page_model_id"])
                                    .where(ElementRegistry.element_name == elem["name"][:255])
                                )
                                db_elem = db_elem_result.scalar_one_or_none()
                                if db_elem:
                                    db_elem.css_selector = new_selector[:1024]
                            else:
                                logger.info(f"  [Healing] ❌ Deduced selector '{new_selector}' was also not visible.")
                                await broadcast_action(str(run.id), "heal", elem['name'][:80],
                                                       "failed", "Healed selector also not visible",
                                                       action_index=idx+1, total_actions=len(all_elements))
                        
                        if status == "failed":
                            screenshot_path = await evidence_svc.capture_screenshot(
                                engine.page,
                                f"failed_{elem['name'][:60]}",
                            )

                    if status == "passed":
                        passed += 1
                    else:
                        failed += 1

                    # Broadcast validation result
                    await broadcast_action(str(run.id), "validate", elem['name'][:80],
                                           "success" if status == "passed" else "failed",
                                           actual_value[:100],
                                           action_index=idx+1, total_actions=len(all_elements),
                                           screenshot_url=screenshot_path or "")

                    # Store test result
                    test_result = TestCaseResult(
                        run_id=run.id,
                        test_name=f"Visibility: {elem['name']}"[:512],
                        page_name=elem.get('page_name', 'Unknown'),
                        test_type="visibility",
                        status=status,
                        expected_value="visible",
                        actual_value=actual_value,
                        screenshot_path=screenshot_path,
                    )
                    db.add(test_result)

                    icon = "✅" if status == "passed" else "❌"
                    status_display = f"healed" if "Auto-healed" in actual_value else status
                    logger.info(f"  {icon} [{idx+1}/{len(all_elements)}] {elem['name'][:50]} → {status_display}")

                    # Commit + broadcast every element for live feed
                    run.passed_count = passed
                    run.failed_count = failed
                    run.error_count = errors
                    if (idx + 1) % 3 == 0 or idx == len(all_elements) - 1:
                        await db.commit()
                    
                    # Broadcast live counters to frontends
                    await broadcast_run_update(str(run.id), {
                        "type": "run_update",
                        "status": run.status,
                        "passed_count": passed,
                        "failed_count": failed,
                        "error_count": errors,
                        "total_elements": len(all_elements),
                    })

                except Exception as e:
                    errors += 1
                    logger.warning(f"  ⚠️ [{idx+1}/{len(all_elements)}] {elem['name'][:50]} → error: {e}")
                    test_result = TestCaseResult(
                        run_id=run.id,
                        test_name=f"Visibility: {elem['name']}",
                        page_name=elem.get('page_name', 'Unknown'),
                        test_type="visibility",
                        status="error",
                        error_message=str(e)[:500],
                        actual_value=str(e)[:500],
                    )
                    db.add(test_result)

            # 8. Finalize
            run.passed_count = passed
            run.failed_count = failed
            run.error_count = errors
            run.status = "passed" if failed == 0 and errors == 0 else "failed"
            run.completed_at = datetime.utcnow()
            await db.commit()

            logger.info(f"")
            logger.info(f"╔══════════════════════════════════════════════════")
            logger.info(f"║ Pipeline complete: {run.status.upper()}")
            logger.info(f"║ {passed} passed / {failed} failed / {errors} errors")
            logger.info(f"║ ({len(all_elements)} total elements)")
            logger.info(f"╚══════════════════════════════════════════════════")

        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.error(f"❌ Pipeline error: {error_msg}")
            logger.error(traceback.format_exc())
            try:
                await _fail_run(db, run, error_msg, logger)
            except Exception:
                logger.error(f"Failed to save error state: {traceback.format_exc()}")
        finally:
            logger.info("🔒 Closing browser...")
            har_path = await engine.stop()
            if har_path:
                logger.info(f"📁 HAR saved: {har_path}")

            # ── HAR Cross-Validation (v2: fuzzy, errors, perf, historical) ──
            if har_path and os.path.exists(har_path):
                try:
                    from app.services.har_analyzer import HarAnalyzer
                    logger.info("📊 Step 8b: Running HAR API cross-validation (v2)...")
                    har = HarAnalyzer(har_path)
                    if har.load():
                        report = har.generate_validation_report(
                            all_elements, run_id=str(run.id)
                        )

                        # Log comprehensive summary
                        logger.info(
                            f"  📊 HAR Report: {report['total_api_responses']} API responses, "
                            f"{report['total_api_numeric_values']} numeric + "
                            f"{report['total_api_string_values']} string values"
                        )
                        logger.info(
                            f"  ✅ {report['passed']} passed | "
                            f"❌ {report['failed']} failed | "
                            f"⚠️ {report['warnings']} warnings"
                        )
                        if report['total_error_responses'] > 0:
                            logger.warning(
                                f"  🔴 {report['total_error_responses']} API error responses (4xx/5xx)"
                            )
                        if report['total_slow_responses'] > 0:
                            logger.warning(
                                f"  🐌 {report['total_slow_responses']} slow API calls (>2s)"
                            )
                        if report['historical_regressions'] > 0:
                            logger.warning(
                                f"  📉 {report['historical_regressions']} data regressions vs previous run"
                            )

                        # Store results as test cases
                        async with create_standalone_session_factory()() as har_db:
                            for cr in report.get("results", []):
                                har_test = TestCaseResult(
                                    run_id=run.id,
                                    test_name=cr.get("test_name", "HAR Check")[:512],
                                    test_type=cr.get("test_type", "api_cross_validation"),
                                    status=cr.get("status", "warning"),
                                    expected_value=cr.get("ui_value", "")[:500],
                                    actual_value=(
                                        cr.get("api_value", "N/A")[:500]
                                        if cr.get("api_value") else "No API match"
                                    ),
                                    error_message=cr.get("message", "")[:500],
                                    executed_at=datetime.utcnow(),
                                )
                                har_db.add(har_test)

                            # Update run counters
                            har_passed = report["passed"]
                            har_failed = report["failed"]
                            run_result = await har_db.execute(
                                select(ExecutionRun).where(ExecutionRun.id == run.id)
                            )
                            run_obj = run_result.scalar_one_or_none()
                            if run_obj:
                                run_obj.passed_count = (run_obj.passed_count or 0) + har_passed
                                run_obj.failed_count = (run_obj.failed_count or 0) + har_failed
                            await har_db.commit()

                        logger.info(
                            f"  ✓ HAR v2 complete: {har_passed} passed, "
                            f"{har_failed} failed, {report['warnings']} warnings"
                        )
                    else:
                        logger.warning("  ⚠️ HAR file could not be loaded")
                except Exception as e:
                    logger.warning(f"  ⚠️ HAR cross-validation failed (non-fatal): {e}")

            logger.info("🏁 Pipeline subprocess exiting")


async def _load_run(db: AsyncSession, run_id: str) -> ExecutionRun | None:
    result = await db.execute(select(ExecutionRun).where(ExecutionRun.id == run_id))
    return result.scalar_one_or_none()


async def _load_config(db: AsyncSession, config_id) -> Configuration | None:
    result = await db.execute(
        select(Configuration).where(Configuration.id == str(config_id))
    )
    return result.scalar_one_or_none()


async def _fail_run(db: AsyncSession, run: ExecutionRun, error_msg: str, logger=None):
    run.status = "error"
    run.error_message = error_msg[:2000]
    run.completed_at = datetime.utcnow()
    await db.commit()
    if logger:
        logger.error(f"Run marked as ERROR: {error_msg[:200]}")

