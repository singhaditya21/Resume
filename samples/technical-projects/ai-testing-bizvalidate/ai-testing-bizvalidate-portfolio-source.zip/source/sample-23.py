"""Fix permissions: grant schema access to bizvalidate user."""
import sys

try:
    import psycopg2
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "psycopg2-binary", "-q"])
    import psycopg2

# Connect as superuser
passwords = ["postgres", "admin", "password", "root", "1234", ""]
conn = None
for pwd in passwords:
    try:
        conn = psycopg2.connect(host="localhost", user="PORTFOLIO_REDACTED", password=pwd, dbname="bizvalidate")
        conn.autocommit = True
        print(f"Connected as postgres to bizvalidate DB")
        break
    except Exception:
        continue

if not conn:
    print("ERROR: Could not connect as postgres")
    sys.exit(1)

cur = conn.cursor()

# Grant all privileges
commands = [
    "GRANT ALL ON SCHEMA public TO bizvalidate",
    "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO bizvalidate",
    "GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO bizvalidate",
    "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO bizvalidate",
    "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO bizvalidate",
    "GRANT CREATE ON SCHEMA public TO bizvalidate",
]

for cmd in commands:
    try:
        cur.execute(cmd)
        print(f"OK: {cmd}")
    except Exception as e:
        print(f"WARN: {cmd} -> {e}")

conn.close()
print("\nPermissions granted! Restart the backend now.")
