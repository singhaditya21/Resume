"""Healing Engine — Autonomous self-healing for broken validation selectors.

When a previously working CSS selector or pattern fails to find its target element,
the healing engine kicks in. It provides the LLM with the page context and the
broken element's metadata, asking the LLM to deduce the *new* selector based on
the available DOM structure. If the new selector works, the database is permanently
updated, achieving a zero-maintenance test suite.
"""

import logging
import json

from app.services.llm_service import LLMService

logger = logging.getLogger("bizvalidate.healing_engine")


class HealingEngine:
    """Agentic loop to repair broken locators via LLM deduction."""

    def __init__(self):
        self.llm = LLMService()

    async def attempt_heal(
        self,
        failed_elem: dict,
        current_page_elements: list[dict],
        page_context: dict
    ) -> str | None:
        """Attempt to deduce a new valid selector for a broken element.

        Args:
            failed_elem: {name, type, old_selector, text_content}
            current_page_elements: List of freshly discovered elements on the page
            page_context: Context dict from dom_analyzer

        Returns:
            The new CSS selector string, or None if healing failed.
        """
        if not await self.llm.is_available():
            logger.warning("HealingEngine: LLM is not available for self-healing.")
            return None

        logger.info(f"HealingEngine: Attempting to heal broken locator for '{failed_elem.get('name')}'")

        # Prepare a lightweight summary of available elements to fit the LLM context
        candidates = []
        for i, elem in enumerate(current_page_elements[:40]):
            candidates.append({
                "id": str(i),
                "type": elem.get("type", "other"),
                "selector": elem.get("selector", ""),
                "text_snippet": (elem.get("text") or "")[:80]
            })

        old_meta = {
            "name": failed_elem.get("name", "Unknown Element"),
            "expected_type": failed_elem.get("type", "other"),
            "old_broken_selector": failed_elem.get("old_selector", ""),
            "old_text_snippet": (failed_elem.get("text_content") or "")[:80]
        }

        prompt = f"""You are an autonomous self-healing test agent.
A UI test just failed because the locator for an element broke (likely due to a code change or UI framework update).

Page Context: {json.dumps(page_context)}

Broken Element Metadata (what it used to look like):
{json.dumps(old_meta, indent=2)}

Here are {len(candidates)} elements currently visible on the newly rendered page:
{json.dumps(candidates, indent=2)}

Task: Identify which of these current elements is the updated version of the broken element.
- Look for matching text snippets, similar component roles/types, or structure.
- Do NOT hallucinate CSS. You must strictly pick the "selector" value from the matching candidate element.

Return ONLY a valid JSON object with:
- "healed": true or false
- "new_selector": the exact CSS selector of the matched candidate (if healed=true)
- "reason": a 1-sentence explanation of why this match is correct (e.g. "Text content 'Save' matches despite CSS class hash changing.")

No markdown fences, no other text. Just the JSON object.
"""

        try:
            response = await self.llm._complete(prompt, max_tokens=300, temperature=0.1)
            if not response:
                return None

            cleaned = response.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("\n", 1)[1]
                if cleaned.endswith("```"):
                    cleaned = cleaned.rsplit("```", 1)[0]
                cleaned = cleaned.strip()

            result = json.loads(cleaned)

            if result.get("healed") and result.get("new_selector"):
                logger.info(f"HealingEngine SUCCESS: {result['reason']}")
                logger.info(f"HealingEngine deduced new selector: {result['new_selector']}")
                return result["new_selector"]

            logger.info(f"HealingEngine could not confidently match the element: {result.get('reason', 'No match found')}")
            return None

        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"HealingEngine LLM parsing error: {e}")
            return None
        except Exception as e:
            logger.error(f"HealingEngine fatal error: {e}")
            return None
