"use client";

export function SkeletonCard() {
    return (
        <div className="skeleton-card">
            <div className="skeleton-line skeleton-line-lg" />
            <div className="skeleton-line skeleton-line-sm" style={{ marginTop: "0.5rem" }} />
        </div>
    );
}

export function SkeletonTable({ rows = 5, cols = 4 }) {
    return (
        <div className="skeleton-table">
            <div className="skeleton-row skeleton-header">
                {Array.from({ length: cols }).map((_, i) => (
                    <div key={i} className="skeleton-line skeleton-line-sm" />
                ))}
            </div>
            {Array.from({ length: rows }).map((_, r) => (
                <div key={r} className="skeleton-row">
                    {Array.from({ length: cols }).map((_, c) => (
                        <div key={c} className="skeleton-line skeleton-line-md" />
                    ))}
                </div>
            ))}
        </div>
    );
}

export function SkeletonText({ lines = 3, widths = [] }) {
    return (
        <div className="skeleton-text">
            {Array.from({ length: lines }).map((_, i) => (
                <div
                    key={i}
                    className="skeleton-line"
                    style={{ width: widths[i] || `${80 - i * 15}%` }}
                />
            ))}
        </div>
    );
}
