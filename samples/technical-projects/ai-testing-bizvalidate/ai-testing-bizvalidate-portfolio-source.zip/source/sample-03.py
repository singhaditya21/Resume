"""DOM Analyzer v4 — Multi-strategy element discovery.

v4: Accessibility tree (primary) + DOM pattern/heuristic (fallback).
The accessibility tree provides framework-agnostic, iframe-aware discovery.
The old DOM-based passes are kept as fallback strategies.
"""

import logging
import re

from app.services.crmnext_patterns import CRMNextPatternMatcher, is_stable_class

logger = logging.getLogger("bizvalidate.dom_analyzer")

# Map ARIA roles to our internal element types
_ROLE_TYPE_MAP = {
    # Interactive
    "button": "button",
    "link": "link",
    "menuitem": "button",
    "menuitemcheckbox": "button",
    "menuitemradio": "button",
    "option": "input",
    "switch": "input",
    "searchbox": "input",
    "spinbutton": "input",
    "slider": "input",
    "combobox": "input",
    "textbox": "input",
    "checkbox": "input",
    "radio": "input",
    # Navigation
    "tab": "tab",
    "tablist": "tab",
    "tabpanel": "container",
    "navigation": "menu",
    "menu": "menu",
    "menubar": "menu",
    "toolbar": "container",
    # Data display
    "table": "table",
    "grid": "table",
    "treegrid": "table",
    "row": None,  # Skip — we capture the table itself
    "rowgroup": None,
    "cell": None,
    "gridcell": None,
    "columnheader": None,
    "rowheader": None,
    # Content
    "heading": "container",
    "img": "widget",
    "figure": "widget",
    "dialog": "container",
    "alertdialog": "container",
    "alert": "widget",
    "status": "widget",
    "progressbar": "widget",
    "meter": "widget",
    # Structure (skip)
    "group": None,
    "region": None,
    "generic": None,
    "presentation": None,
    "none": None,
    "separator": None,
    "complementary": None,
    "contentinfo": None,
    "banner": None,
    "main": None,
    "form": None,
    "list": None,
    "listitem": None,
}


class DomAnalyzer:
    """Analyzes a page to discover testable elements.

    v4: Multi-strategy discovery engine:
      - Primary: Accessibility tree (framework-agnostic, iframe-aware)
      - Fallback: DOM pattern matching + universal heuristics
    """

    def __init__(self):
        self.matcher = CRMNextPatternMatcher()

    # ── Primary: Accessibility tree discovery ──────────

    def discover_from_accessibility_tree(self, ax_tree: dict | None) -> list[dict]:
        """Discover elements from Playwright's accessibility snapshot.

        This is the PRIMARY discovery strategy — framework-agnostic, works
        across iframes, and uses semantic ARIA roles instead of CSS classes.

        Returns: [{name, type, selector, text, confidence, pattern_source}]
        """
        if not ax_tree:
            logger.warning("Accessibility tree is None — skipping AX discovery")
            return []

        elements = []
        self._walk_ax_tree(ax_tree, elements, depth=0)

        # Deduplicate by name+type
        unique = self._deduplicate_ax(elements)
        unique.sort(key=lambda e: e.get("confidence", 0), reverse=True)

        logger.info(
            f"♿ AX tree discovery: {len(unique)} elements "
            f"({sum(1 for e in unique if e['type'] == 'button')} buttons, "
            f"{sum(1 for e in unique if e['type'] == 'tab')} tabs, "
            f"{sum(1 for e in unique if e['type'] == 'link')} links, "
            f"{sum(1 for e in unique if e['type'] == 'input')} inputs, "
            f"{sum(1 for e in unique if e['type'] == 'table')} tables, "
            f"{sum(1 for e in unique if e['type'] == 'widget')} widgets, "
            f"{sum(1 for e in unique if e['type'] == 'container')} containers)"
        )
        return unique

    def _walk_ax_tree(self, node: dict, elements: list, depth: int):
        """Recursively walk the accessibility tree and extract elements."""
        if not node or depth > 20:
            return

        role = (node.get("role") or "").lower()
        name = (node.get("name") or "").strip()
        value = node.get("value", "")

        # Map ARIA role to our internal type
        elem_type = _ROLE_TYPE_MAP.get(role)

        if elem_type and name:
            # Build Playwright-compatible selector from ARIA role + name
            selector = self._build_ax_selector(role, name, node)
            display_name = f"{elem_type.capitalize()}: {name[:60]}"

            # Assign confidence based on specificity
            confidence = self._ax_confidence(role, name, depth)

            # Extract numeric values from text
            numeric_values = []
            text_content = name or str(value or "")
            if text_content:
                numeric_values = self._extract_numeric_from_text(text_content)

            elements.append({
                "name": display_name,
                "type": elem_type,
                "selector": selector,
                "text": text_content[:200],
                "confidence": confidence,
                "pattern_source": "accessibility_tree",
                "numeric_values": numeric_values,
                "dom_path": f"ax/{role}/{name[:30]}",
            })

        # Recurse into children
        for child in node.get("children", []):
            self._walk_ax_tree(child, elements, depth + 1)

    def _build_ax_selector(self, role: str, name: str, node: dict) -> str:
        """Build a stable Playwright locator from ARIA role + name.

        Uses Playwright's role-based locator format which is the most
        resilient selector strategy available.
        """
        # Escape quotes in name for CSS selector
        safe_name = name.replace('"', '\\"').replace("'", "\\'")

        # Prefer role-based selector (most stable)
        if role in ("button", "link", "tab", "heading", "textbox", "checkbox",
                     "radio", "combobox", "menuitem", "option", "switch",
                     "searchbox", "slider", "spinbutton"):
            return f'role={role}[name="{safe_name}"]'

        # For tables/grids, use role locator
        if role in ("table", "grid", "treegrid"):
            return f'role={role}[name="{safe_name}"]' if safe_name else f'role={role}'

        # For navigation elements
        if role in ("navigation", "menu", "menubar", "toolbar"):
            return f'role={role}[name="{safe_name}"]' if safe_name else f'role={role}'

        # For images
        if role == "img":
            return f'role=img[name="{safe_name}"]'

        # Fallback: text-based
        if safe_name:
            return f'text="{safe_name}"'

        return f'role={role}'

    def _ax_confidence(self, role: str, name: str, depth: int) -> float:
        """Calculate confidence score for an AX element."""
        base = 0.90  # AX tree elements are inherently high-confidence

        # Interactive elements are more valuable for testing
        if role in ("button", "link", "tab", "textbox", "checkbox", "combobox"):
            base = 0.95
        elif role in ("table", "grid", "treegrid"):
            base = 0.92
        elif role in ("heading", "img"):
            base = 0.80
        elif role in ("navigation", "menu"):
            base = 0.85
        elif role in ("dialog", "alert", "status"):
            base = 0.88

        # Slight penalty for deep nesting
        depth_penalty = min(depth * 0.01, 0.1)
        return round(max(base - depth_penalty, 0.5), 2)

    def _extract_numeric_from_text(self, text: str) -> list[dict]:
        """Extract numeric values from text content."""
        if not text or len(text) > 500:
            return []

        values = []
        patterns = [
            (r"[₹$€£]\s*[\d,]+(?:\.\d+)?", "currency"),
            (r"[\d,.]+\s*%", "percentage"),
            (r"\b[\d,]+(?:\.\d+)?\b", "number"),
        ]

        for pattern, label in patterns:
            for match in re.finditer(pattern, text):
                raw = match.group()
                try:
                    clean = re.sub(r"[₹$€£%,\s]", "", raw)
                    if clean:
                        val = float(clean)
                        values.append({"value": val, "label": label, "raw_text": raw.strip()})
                except (ValueError, TypeError):
                    pass

        return values[:10]

    def _deduplicate_ax(self, elements: list) -> list:
        """Deduplicate AX elements by name+type, keeping highest confidence."""
        seen = {}
        for elem in elements:
            key = f"{elem['type']}:{elem['name']}"
            if key not in seen or elem.get("confidence", 0) > seen[key].get("confidence", 0):
                seen[key] = elem
        return list(seen.values())

    # ── Combined multi-strategy discovery ──────────────

    def discover_all(self, ax_tree: dict | None, dom_tree: dict | None) -> list[dict]:
        """Run all discovery strategies and merge results.

        v5: 6 strategies total:
          1. Accessibility tree (primary)
          2. DOM pattern matching (CRMNEXT-specific)
          3. DOM heuristics (universal)
          4. Canvas/SVG chart detection (Chart.js, Highcharts)
          5. Div-grid pseudo-table detection
          6. Color-coded section header detection
        """
        # Strategy 1: Accessibility tree (primary)
        ax_elements = self.discover_from_accessibility_tree(ax_tree)

        # Strategy 2+3: DOM pattern + heuristic (fallback)
        dom_elements = self.discover_elements(dom_tree)

        if not ax_elements and not dom_elements and not dom_tree:
            logger.warning("⚠️ No elements found by any strategy (no DOM tree)")
            return []

        if not ax_elements and not dom_elements:
            merged = []  # Strategies 4-6 will populate
        elif not ax_elements:
            logger.info("AX tree empty — using DOM-only discovery")
            merged = list(dom_elements)
        elif not dom_elements:
            logger.info("DOM tree empty — using AX-only discovery")
            merged = list(ax_elements)
        else:
            # Merge: AX elements take priority, add unique DOM elements
            merged = list(ax_elements)
            ax_names = {e["name"].lower() for e in ax_elements}
            for dom_elem in dom_elements:
                if dom_elem["name"].lower() not in ax_names:
                    merged.append(dom_elem)

        # Strategy 4: Canvas/SVG chart detection
        if dom_tree:
            chart_elements = self._discover_charts(dom_tree)
            if chart_elements:
                existing = {e["name"].lower() for e in merged}
                new_charts = [c for c in chart_elements if c["name"].lower() not in existing]
                merged.extend(new_charts)
                logger.info(f"📊 Chart detector found {len(new_charts)} new chart elements")

        # Strategy 5: Div-grid pseudo-table detection
        if dom_tree:
            grid_elements = self._discover_div_tables(dom_tree)
            if grid_elements:
                existing = {e["name"].lower() for e in merged}
                new_grids = [g for g in grid_elements if g["name"].lower() not in existing]
                merged.extend(new_grids)
                logger.info(f"🏗️ Div-grid detector found {len(new_grids)} pseudo-tables")

        # Strategy 6: Section header detection
        if dom_tree:
            header_elements = self._discover_section_headers(dom_tree)
            if header_elements:
                existing = {e["name"].lower() for e in merged}
                new_headers = [h for h in header_elements if h["name"].lower() not in existing]
                merged.extend(new_headers)
                logger.info(f"🏷️ Section header detector found {len(new_headers)} headers")

        # Deduplicate final set
        unique = self._deduplicate(merged)
        unique.sort(key=lambda e: e.get("confidence", 0), reverse=True)

        logger.info(
            f"🔀 Multi-strategy merge: {len(ax_elements)} AX + "
            f"{len(dom_elements)} DOM + extras → {len(unique)} unique elements"
        )
        return unique

    # ── Strategy 4: Canvas/SVG Chart Detection ─────────

    def _discover_charts(self, dom_tree: dict) -> list[dict]:
        """Detect charts rendered as <canvas> or <svg> (invisible to AX tree).

        Chart.js uses: <div class="chart-wrapper"><canvas/></div>
        Highcharts uses: <div class="highcharts-container"><svg/></div>
        BusinessNext uses: Various wrappers with chart-like class names.
        """
        charts = []
        self._walk_for_charts(dom_tree, charts, depth=0)
        return charts

    def _walk_for_charts(self, node: dict, charts: list, depth: int):
        """Walk DOM looking for canvas/svg chart containers."""
        if not node or depth > 12:
            return

        tag = (node.get("tag") or "").lower()
        classes = " ".join(node.get("classes", []))
        classes_lower = classes.lower()

        # Check 1: <canvas> element (Chart.js, ChartJS, amCharts)
        if tag == "canvas":
            parent_text = self._get_nearby_heading(node)
            name = parent_text or "Chart (canvas)"
            charts.append({
                "name": f"Chart: {name[:60]}",
                "type": "chart",
                "selector": self._build_chart_selector(node, "canvas"),
                "text": name[:200],
                "confidence": 0.85,
                "pattern_source": "canvas_chart_detector",
                "numeric_values": [],
                "dom_path": f"canvas/{name[:30]}",
            })
            return  # Don't recurse into canvas

        # Check 2: Highcharts container
        if re.search(r"highcharts[-_]?container|highcharts[-_]?root", classes_lower):
            title = self._get_text_from_children(node, ["highcharts-title", "chart-title"])
            name = title or "Highcharts Widget"
            charts.append({
                "name": f"Chart: {name[:60]}",
                "type": "chart",
                "selector": self._build_chart_selector(node, "highcharts"),
                "text": name[:200],
                "confidence": 0.88,
                "pattern_source": "highcharts_detector",
                "numeric_values": [],
                "dom_path": f"highcharts/{name[:30]}",
            })
            return  # Don't recurse into this Highcharts container

        # Check 2b: amCharts container (BusinessNext primary chart library)
        # amCharts v4 wraps charts in divs — check for amcharts-main-div or chartdiv patterns
        if re.search(r"amcharts[-_]main|chartdiv|amchart", classes_lower) or \
           (node.get("id") or "").lower().startswith("chartdiv"):
            title = self._get_nearby_heading(node) or "amCharts Widget"
            has_svg = self._has_child_tag(node, ("svg", "canvas"))
            if has_svg:
                charts.append({
                    "name": f"Chart: {title[:60]}",
                    "type": "chart",
                    "selector": self._build_chart_selector(node, "amcharts"),
                    "text": title[:200],
                    "confidence": 0.90,
                    "pattern_source": "amcharts_detector",
                    "numeric_values": [],
                    "dom_path": f"amcharts/{title[:30]}",
                })
                return  # Don't recurse into this amCharts container

        # Check 3: Generic chart wrapper classes
        if re.search(
            r"chart[-_]?(?:container|wrapper|box|area|widget)|"
            r"canvas[-_]?wrapper|graph[-_]?container|"
            r"amcharts|echarts|plotly|d3[-_]chart|recharts",
            classes_lower
        ):
            # Verify it has a <canvas> or <svg> child
            has_visual = self._has_child_tag(node, ("canvas", "svg"))
            if has_visual:
                title = self._get_nearby_heading(node) or "Chart Widget"
                charts.append({
                    "name": f"Chart: {title[:60]}",
                    "type": "chart",
                    "selector": self._build_chart_selector(node, "chart-wrapper"),
                    "text": title[:200],
                    "confidence": 0.80,
                    "pattern_source": "generic_chart_detector",
                    "numeric_values": [],
                    "dom_path": f"chart/{title[:30]}",
                })
                return  # Don't recurse into this chart wrapper

        # Check 4: Standalone <svg> that looks like a chart (large, has <path> children)
        if tag == "svg":
            rect = node.get("rect", {})
            w = rect.get("width", 0)
            h = rect.get("height", 0)
            if w > 150 and h > 100:
                # Likely a chart SVG, not an icon
                title = self._get_nearby_heading(node) or "SVG Chart"
                charts.append({
                    "name": f"Chart: {title[:60]}",
                    "type": "chart",
                    "selector": self._build_chart_selector(node, "svg"),
                    "text": title[:200],
                    "confidence": 0.75,
                    "pattern_source": "svg_chart_detector",
                    "numeric_values": [],
                    "dom_path": f"svg-chart/{title[:30]}",
                })
                # Don't return — keep walking siblings to find more charts

        for child in node.get("children", []):
            self._walk_for_charts(child, charts, depth + 1)

    # ── Strategy 5: Div-Grid Table Detection ───────────

    def _discover_div_tables(self, dom_tree: dict) -> list[dict]:
        """Detect tables built with <div> CSS grids instead of <table>.

        BusinessNext uses div-based grids for some summary tables.
        Pattern: parent div with multiple child divs of identical structure.
        """
        tables = []
        self._walk_for_div_tables(dom_tree, tables, depth=0)
        return tables

    def _walk_for_div_tables(self, node: dict, tables: list, depth: int):
        """Walk DOM looking for div-based table patterns."""
        if not node or depth > 10:
            return

        tag = (node.get("tag") or "").lower()
        classes = " ".join(node.get("classes", []))
        classes_lower = classes.lower()
        children = node.get("children", [])

        # Heuristic: a div with class containing "grid", "row", "table" and 3+ similar children
        if tag == "div" and len(children) >= 3:
            is_grid_like = re.search(
                r"grid|data[-_]?table|row[-_]?container|list[-_]?view|"
                r"summary[-_]?table|report[-_]?body|detail[-_]?rows",
                classes_lower
            )

            if is_grid_like:
                # Check if children have uniform structure (same tag, similar class count)
                child_tags = [c.get("tag", "").lower() for c in children[:10]]
                dominant_tag = max(set(child_tags), key=child_tags.count) if child_tags else ""
                uniformity = child_tags.count(dominant_tag) / len(child_tags)

                if uniformity >= 0.6 and dominant_tag == "div":
                    title = self._get_nearby_heading(node) or "Data Grid"
                    # Extract numeric values from the grid content
                    text_content = self._collect_text(node, max_len=500)
                    numerics = self._extract_numeric_from_text(text_content)

                    tables.append({
                        "name": f"Table: {title[:60]}",
                        "type": "table",
                        "selector": self.matcher.build_stable_selector(node),
                        "text": text_content[:200],
                        "confidence": 0.78,
                        "pattern_source": "div_grid_detector",
                        "numeric_values": numerics,
                        "dom_path": f"div-grid/{title[:30]}",
                    })
                    return  # Don't recurse into detected grids

        for child in children:
            self._walk_for_div_tables(child, tables, depth + 1)

    # ── Strategy 6: Section Header Detection ───────────

    def _discover_section_headers(self, dom_tree: dict) -> list[dict]:
        """Detect color-coded section headers (like 'ARR Health CFY', 'Glossary').

        Pattern: wide div with solid background color and short text.
        """
        headers = []
        self._walk_for_section_headers(dom_tree, headers, depth=0)
        return headers

    def _walk_for_section_headers(self, node: dict, headers: list, depth: int):
        """Walk DOM looking for section header bars."""
        if not node or depth > 10:
            return

        tag = (node.get("tag") or "").lower()
        classes = " ".join(node.get("classes", []))
        classes_lower = classes.lower()
        text = (node.get("text") or "").strip()
        rect = node.get("rect", {})
        style = node.get("style", "")

        # Section header patterns:
        # - Has a background color (via class or inline style)
        # - Wide (>200px width)
        # - Short text (5-80 chars)
        # - Not a button or link
        if tag == "div" and text and 3 < len(text) < 100:
            is_header_class = re.search(
                r"section[-_]?header|section[-_]?title|panel[-_]?header|"
                r"card[-_]?header|module[-_]?title|block[-_]?title|"
                r"heading[-_]?bar|title[-_]?bar|summary[-_]?header|"
                r"report[-_]?title|widget[-_]?title|group[-_]?title",
                classes_lower
            )
            is_wide = rect.get("width", 0) > 200
            has_bg = "background" in style.lower() if style else False

            if (is_header_class or (is_wide and has_bg)) and tag not in ("button", "a"):
                headers.append({
                    "name": f"Section: {text[:60]}",
                    "type": "container",
                    "selector": self.matcher.build_stable_selector(node),
                    "text": text[:200],
                    "confidence": 0.72,
                    "pattern_source": "section_header_detector",
                    "numeric_values": [],
                    "dom_path": f"section/{text[:30]}",
                })
                return

        for child in node.get("children", []):
            self._walk_for_section_headers(child, headers, depth + 1)

    # ── Chart helper methods ───────────────────────────

    def _build_chart_selector(self, node: dict, chart_type: str) -> str:
        """Build a selector for a chart element."""
        # Try standard selector first
        css_selector = self.matcher.build_stable_selector(node)
        if css_selector and css_selector != "div":
            return css_selector

        # Fallback: use chart type + nearby context
        classes = node.get("classes", [])
        if classes:
            stable = [c for c in classes if is_stable_class(c)]
            if stable:
                return f"div.{stable[0]}"

        return f"{chart_type}"

    def _get_nearby_heading(self, node: dict) -> str:
        """Try to find a heading/title near a chart or grid element."""
        # Check for title in parent's siblings or text content
        text = (node.get("text") or "").strip()
        if text and len(text) < 100 and not text.startswith("<"):
            return text

        # Look in attributes
        for attr in ("aria-label", "title", "data-title", "alt"):
            val = node.get("attributes", {}).get(attr, "")
            if val and len(val) < 100:
                return val.strip()

        return ""

    def _get_text_from_children(self, node: dict, class_hints: list[str]) -> str:
        """Find text in child elements matching class hints."""
        for child in node.get("children", []):
            child_classes = " ".join(child.get("classes", [])).lower()
            for hint in class_hints:
                if hint in child_classes:
                    text = (child.get("text") or "").strip()
                    if text:
                        return text
            # Recurse one level
            result = self._get_text_from_children(child, class_hints)
            if result:
                return result
        return ""

    def _has_child_tag(self, node: dict, tags: tuple, depth: int = 0) -> bool:
        """Check if any descendant has one of the given tags."""
        if depth > 3:
            return False
        for child in node.get("children", []):
            if (child.get("tag") or "").lower() in tags:
                return True
            if self._has_child_tag(child, tags, depth + 1):
                return True
        return False

    def _collect_text(self, node: dict, max_len: int = 500, depth: int = 0) -> str:
        """Collect all text content from a node tree."""
        if depth > 5:
            return ""
        parts = []
        text = (node.get("text") or "").strip()
        if text:
            parts.append(text)
        for child in node.get("children", []):
            child_text = self._collect_text(child, max_len, depth + 1)
            if child_text:
                parts.append(child_text)
            if sum(len(p) for p in parts) > max_len:
                break
        return " ".join(parts)[:max_len]

    # ── Fallback: DOM-based discovery (v3 legacy) ─────

    def discover_elements(self, dom_tree: dict | None) -> list[dict]:
        """Walk the DOM tree and return discovered elements.

        Two-pass discovery:
          1. Pattern-based (CRMNEXT-specific CSS class matching)
          2. Heuristic-based (tag, size, text, role, interactivity)

        Each element: {name, type, selector, text, confidence, numeric_values}
        """
        if not dom_tree:
            return []

        # Pass 1: Pattern-based discovery
        pattern_elements = []
        self._walk_patterns(dom_tree, pattern_elements, depth=0, parent_path="")

        # Pass 2: Heuristic-based discovery (catches everything patterns miss)
        heuristic_elements = []
        self._walk_heuristics(dom_tree, heuristic_elements, depth=0, parent_path="")

        # Merge: pattern elements take priority, then add unique heuristic ones
        all_elements = list(pattern_elements)
        pattern_selectors = {e.get("selector", "") for e in pattern_elements}
        for elem in heuristic_elements:
            if elem.get("selector", "") not in pattern_selectors:
                all_elements.append(elem)

        # Deduplicate by selector
        unique = self._deduplicate(all_elements)

        # Sort by confidence descending
        unique.sort(key=lambda e: e.get("confidence", 0), reverse=True)

        logger.info(
            f"Discovered {len(unique)} elements "
            f"({sum(1 for e in unique if e['type'] == 'chart')} charts, "
            f"{sum(1 for e in unique if e['type'] == 'widget')} widgets, "
            f"{sum(1 for e in unique if e['type'] == 'table')} tables, "
            f"{sum(1 for e in unique if e['type'] == 'button')} buttons, "
            f"{sum(1 for e in unique if e['type'] == 'tab')} tabs, "
            f"{sum(1 for e in unique if e['type'] == 'link')} links, "
            f"{sum(1 for e in unique if e['type'] == 'input')} inputs)"
        )
        return unique

    # ── Pass 1: Pattern-based discovery ─────────────────

    def _walk_patterns(self, node: dict, elements: list, depth: int, parent_path: str):
        """Recursively walk the DOM tree and classify elements via CRMNEXT patterns."""
        if not node or depth > 15:
            return

        tag = node.get("tag", "")
        is_visible = node.get("isVisible", True)
        rect = node.get("rect", {})

        if not is_visible:
            return
        if rect and tag not in ("svg", "canvas"):
            if rect.get("w", 0) < 8 or rect.get("h", 0) < 8:
                return

        node_id = node.get("id", "")
        path = f"{parent_path}/{tag}" + (f"#{node_id}" if node_id else "")

        match = self.matcher.match(node)
        if match:
            selector = self.matcher.build_stable_selector(node)
            name = self.matcher.build_element_name(node, match["type"], match["description"])
            numeric_values = self._extract_numeric_values(node)

            elements.append({
                "name": name,
                "type": match["type"],
                "selector": selector,
                "text": (node.get("text") or "")[:200],
                "confidence": match["confidence"],
                "pattern_source": match["pattern_source"],
                "numeric_values": numeric_values,
                "dom_path": path,
            })

        for child in node.get("children", []):
            self._walk_patterns(child, elements, depth + 1, path)

    # ── Pass 2: Universal heuristic discovery ───────────

    def _walk_heuristics(self, node: dict, elements: list, depth: int, parent_path: str):
        """Discover elements using universal heuristics — no class dependency.

        Finds: tabs, buttons, links, inputs, tables, charts (canvas/svg),
               significant text blocks, clickable containers, and any
               element with meaningful text content.
        """
        if not node or depth > 15:
            return

        tag = node.get("tag", "")
        is_visible = node.get("isVisible", True)
        rect = node.get("rect", {})
        classes = node.get("classes", [])
        class_str = " ".join(classes).lower()
        role = (node.get("role") or "").lower()
        attrs = node.get("attrs", {})
        text = (node.get("text") or "").strip()
        node_id = node.get("id", "")
        w = rect.get("w", 0)
        h = rect.get("h", 0)

        if not is_visible:
            return
        # Skip very tiny elements (but allow SVG/canvas for charts)
        if tag not in ("svg", "canvas") and (w < 10 or h < 10):
            return

        path = f"{parent_path}/{tag}" + (f"#{node_id}" if node_id else "")
        discovered = None

        # ── 1. Tabs (by role or class patterns) ──
        if role in ("tab", "tablist", "tabpanel") or \
           re.search(r"tab|pill|segment", class_str, re.I):
            if text and len(text) < 100:
                discovered = self._make_element(
                    node, "tab", f"Tab: {text[:60]}", 0.85, path
                )

        # ── 2. Buttons (by tag or role) ──
        elif tag == "button" or role == "button" or \
             (tag == "input" and attrs.get("type") in ("button", "submit")):
            if text and len(text) < 80:
                discovered = self._make_element(
                    node, "button", f"Button: {text[:60]}", 0.75, path
                )

        # ── 3. Links with meaningful text (drill-downs) ──
        elif tag == "a" and attrs.get("href") and text and len(text) < 100:
            href = attrs.get("href", "")
            # Skip anchors and javascript
            if href and href != "#" and not href.startswith("javascript:"):
                label = text.split("\n")[0].strip()[:60]
                if label and len(label) > 1:
                    discovered = self._make_element(
                        node, "link", f"Link: {label}", 0.65, path
                    )

        # ── 4. Form inputs ──
        elif tag in ("input", "select", "textarea"):
            input_type = attrs.get("type", "text")
            if input_type not in ("hidden",):
                label = attrs.get("aria-label", "") or attrs.get("placeholder", "") or node_id or tag
                discovered = self._make_element(
                    node, "input", f"Input: {label[:60]}", 0.6, path
                )

        # ── 5. Tables ──
        elif tag == "table" or role in ("grid", "table", "treegrid"):
            label = text[:60] if text else "Data Table"
            discovered = self._make_element(
                node, "table", f"Table: {label}", 0.8, path
            )

        # ── 6. Charts (canvas/svg with significant size) ──
        elif tag in ("canvas", "svg") and w > 50 and h > 50:
            discovered = self._make_element(
                node, "chart", f"Chart: {node_id or class_str[:40] or tag}", 0.75, path
            )

        # ── 7. Images with alt text ──
        elif tag == "img" and w > 30 and h > 30:
            alt = attrs.get("alt", "") or node_id or ""
            if alt:
                discovered = self._make_element(
                    node, "widget", f"Image: {alt[:60]}", 0.5, path
                )

        # ── 8. Significant containers with text (KPI cards, widgets) ──
        elif w > 80 and h > 40 and text:
            # Check for numeric values (likely KPI cards)
            has_numbers = bool(re.search(r"\d+[,.]?\d*", text))
            short_text = text.split("\n")[0].strip()[:60]

            # Large significant containers with numbers = widget/card
            if has_numbers and 80 < w < 600 and 40 < h < 400 and len(text) < 300:
                if short_text and len(short_text) > 2:
                    discovered = self._make_element(
                        node, "widget", f"Widget: {short_text}", 0.55, path
                    )

            # Headings are important page landmarks
            elif tag in ("h1", "h2", "h3", "h4"):
                discovered = self._make_element(
                    node, "container", f"Heading: {short_text}", 0.4, path
                )

        # ── 9. Navigation landmarks ──
        elif tag == "nav" or role in ("navigation", "menu", "menubar"):
            discovered = self._make_element(
                node, "menu", f"Navigation: {node_id or class_str[:40] or 'nav'}", 0.7, path
            )

        # ── 10. iframes (embedded content) ──
        elif tag == "iframe" and w > 100 and h > 100:
            src = attrs.get("src", "")[:60]
            discovered = self._make_element(
                node, "container", f"IFrame: {src or 'embedded'}", 0.5, path
            )

        if discovered:
            elements.append(discovered)

        # Recurse into children
        for child in node.get("children", []):
            self._walk_heuristics(child, elements, depth + 1, path)

    def _make_element(self, node: dict, elem_type: str, name: str,
                      confidence: float, path: str) -> dict:
        """Create an element dict from a heuristic match."""
        selector = self.matcher.build_stable_selector(node)
        return {
            "name": name,
            "type": elem_type,
            "selector": selector,
            "text": (node.get("text") or "")[:200],
            "confidence": confidence,
            "pattern_source": "heuristic",
            "numeric_values": self._extract_numeric_values(node),
            "dom_path": path,
        }

    # ── Shared helpers ──────────────────────────────────

    def _deduplicate(self, elements: list) -> list:
        """Deduplicate elements by selector, keeping highest confidence."""
        seen = {}
        for elem in elements:
            key = elem.get("selector", "") or elem["name"]
            if key not in seen or elem.get("confidence", 0) > seen[key].get("confidence", 0):
                seen[key] = elem
        return list(seen.values())

    def _extract_numeric_values(self, node: dict) -> list[dict]:
        """Extract numeric values from text content for KPI cross-validation."""
        text = (node.get("text") or "").strip()
        if not text or len(text) > 500:
            return []

        values = []
        patterns = [
            (r"[₹$€£]\s*[\d,]+(?:\.\d+)?", "currency"),
            (r"[\d,.]+\s*%", "percentage"),
            (r"\b[\d,]+(?:\.\d+)?\b", "number"),
        ]

        for pattern, label in patterns:
            for match in re.finditer(pattern, text):
                raw = match.group()
                try:
                    clean = re.sub(r"[₹$€£%,\s]", "", raw)
                    if clean:
                        val = float(clean)
                        values.append({"value": val, "label": label, "raw_text": raw.strip()})
                except (ValueError, TypeError):
                    pass

        return values[:10]

    def detect_page_context(self, dom_tree: dict, url: str = "") -> dict:
        """Auto-detect the current page context from DOM + URL."""
        result = {"page_name": "Unknown", "page_type": "generic", "breadcrumb": ""}

        if url:
            url_match = re.search(r"/([^/?#]+?)(?:/\d+)?(?:\?|#|$)", url)
            if url_match:
                segment = url_match.group(1)
                result["page_name"] = segment.replace("-", " ").replace("_", " ").title()
                result["page_type"] = self._classify_page_type(segment)

        if dom_tree:
            title = self._find_page_title(dom_tree)
            if title:
                result["page_name"] = title
                result["page_type"] = self._classify_page_type(title)

        return result

    def _find_page_title(self, node: dict, depth: int = 0) -> str | None:
        """Find the page title from h1 or page-title class."""
        if not node or depth > 5:
            return None

        tag = node.get("tag", "")
        classes = " ".join(node.get("classes", []))

        if tag == "h1" or re.search(r"page[-_]?title|pageTitle|heading", classes, re.I):
            text = (node.get("text") or "").strip()
            if text and len(text) < 100:
                return text.split("\n")[0].strip()

        for child in node.get("children", []):
            result = self._find_page_title(child, depth + 1)
            if result:
                return result

        return None

    def _classify_page_type(self, name: str) -> str:
        """Classify page type from name."""
        name_lower = name.lower()
        if any(k in name_lower for k in ["summary", "dashboard", "home", "overview"]):
            return "dashboard"
        if any(k in name_lower for k in ["account", "contact", "lead", "opportunity"]):
            return "entity_list"
        if any(k in name_lower for k in ["detail", "profile", "view"]):
            return "entity_detail"
        if any(k in name_lower for k in ["report", "analytics", "insight"]):
            return "report"
        if any(k in name_lower for k in ["setting", "config", "admin"]):
            return "settings"
        return "generic"
