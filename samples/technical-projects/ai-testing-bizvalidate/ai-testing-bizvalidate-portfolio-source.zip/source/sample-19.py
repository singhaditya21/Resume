"""Audit logging utility — records user actions to the database."""

import logging
from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import AuditLog

logger = logging.getLogger("bizvalidate.audit")


async def log_action(
    db: AsyncSession,
    action: str,
    resource_type: str = None,
    resource_id: str = None,
    details: str = None,
    user_id: str = None,
    username: str = None,
    ip_address: str = None,
):
    """Record an audit log entry."""
    try:
        entry = AuditLog(
            user_id=user_id,
            username=username or "system",
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            details=details,
            ip_address=ip_address,
        )
        db.add(entry)
        await db.commit()
        logger.debug(f"Audit: {username}:{action} on {resource_type}/{resource_id}")
    except Exception as e:
        logger.warning(f"Audit log failed: {e}")
