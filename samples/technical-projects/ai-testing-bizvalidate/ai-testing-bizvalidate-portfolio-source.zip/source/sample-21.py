"""AES-256-GCM encryption/decryption for credential storage (PRD §8.1)."""

import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import get_settings


def _get_key() -> bytes:
    """Derive a 32-byte AES key from the ENCRYPTION_KEY setting."""
    settings = get_settings()
    key_str = settings.ENCRYPTION_KEY
    # If the key looks like hex, decode it; otherwise hash it to 32 bytes
    try:
        key_bytes = bytes.fromhex(key_str)
        if len(key_bytes) == 32:
            return key_bytes
    except ValueError:
        pass
    # Fallback: use SHA-256 hash of the key string
    import hashlib
    return hashlib.sha256(key_str.encode()).digest()


def encrypt(plaintext: str) -> bytes:
    """Encrypt a plaintext string using AES-256-GCM.

    Returns: nonce (12 bytes) + ciphertext (variable length)
    """
    key = _get_key()
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce + ciphertext


def decrypt(data: bytes) -> str:
    """Decrypt AES-256-GCM encrypted data.

    Expects: nonce (first 12 bytes) + ciphertext (remaining bytes)
    """
    key = _get_key()
    aesgcm = AESGCM(key)
    nonce = data[:12]
    ciphertext = data[12:]
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")
