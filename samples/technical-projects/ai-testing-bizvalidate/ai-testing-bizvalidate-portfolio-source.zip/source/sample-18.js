import "./globals.css";
import { ToastProvider } from "@/components/Toast";

export const metadata = {
  title: "BizValidate — Validation Platform",
  description: "Web-based validation and operations application for BusinessNext",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
