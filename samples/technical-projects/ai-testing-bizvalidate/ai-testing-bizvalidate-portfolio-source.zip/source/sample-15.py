"""autoresearch package — 9 self-improving modules."""
