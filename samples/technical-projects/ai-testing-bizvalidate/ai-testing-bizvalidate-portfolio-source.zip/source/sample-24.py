import requests

# 1. Login to get token
resp = requests.post("http://127.0.0.1:8000/api/auth/login", data={"username": "PORTFOLIO_REDACTED", "password": "REDACTED_SECRET"})
token = REDACTED_SECRET
# 2. Add config if none exist
headers = {"Authorization": f"Bearer {token}"}
resp = requests.get("http://127.0.0.1:8000/api/configurations", headers=headers)
configs = resp.json()

if not configs:
    # Need to match the backend ConfigurationCreate schema exactly
    cfg_data = {
        "name": "Healing Test",
        "target_url": "http://localhost:3000/login",
        "username": "PORTFOLIO_REDACTED",
        "password": "REDACTED_SECRET",
        "mapped_target_roles": ["Administrator"]
    }
    create_resp = requests.post("http://127.0.0.1:8000/api/configurations", headers=headers, json=cfg_data)
    print("Create API:", create_resp.status_code, create_resp.text)
    
    resp = requests.get("http://127.0.0.1:8000/api/configurations", headers=headers)
    configs = resp.json()
    print("Configs after create:", configs)

if not configs or "id" not in configs[0]:
    print("Failed to get or create config list. Exiting.", configs)
    exit(1)

config_id = configs[0]["id"]

# 3. Trigger run
data = {
    "configuration_id": config_id,
    "selected_target_roles": ["Administrator"],
    "selected_pages": ["auto"]
}
resp = requests.post("http://127.0.0.1:8000/api/runs", headers=headers, json=data)
print("Run triggered:", resp.json())
