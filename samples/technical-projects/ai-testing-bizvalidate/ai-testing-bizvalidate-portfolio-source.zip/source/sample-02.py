"""LLM Service — connects to Cerebras AI cloud API for enhanced element classification.

Uses Cerebras API (OpenAI-compatible) with llama3.1-8b / gpt-oss-120b models.
Rate limits respected: 30 RPM, 60K tokens/min for llama3.1-8b.
Falls back gracefully if API is unreachable.
"""

import logging
import httpx
import json
import time
from typing import Optional

logger = logging.getLogger("bizvalidate.llm")

# ── Cerebras API Configuration ──────────────────────
CEREBRAS_API_URL = "https://example.invalid"
CEREBRAS_API_KEY = REDACTED_SECRET
# Models available on Cerebras
MODEL_FAST = "llama3.1-8b"       # 8,192 context, faster, 30 RPM
MODEL_SMART = "llama-3.3-70b"    # Larger, smarter, same rate limits

# Rate limiter: max 30 requests per minute (enforced as ~1 req/sec)
_last_request_time = 0.0
_request_count_minute = 0
_minute_start = 0.0


def _rate_limit():
    """Enforce Cerebras rate limits: 30 RPM, ~1 req/sec."""
    global _last_request_time, _request_count_minute, _minute_start

    now = time.time()

    # Reset minute counter
    if now - _minute_start > 60:
        _request_count_minute = 0
        _minute_start = now

    # Check minute limit
    if _request_count_minute >= 28:  # Leave 2 req buffer
        wait = 60 - (now - _minute_start)
        if wait > 0:
            logger.info(f"Rate limit: waiting {wait:.1f}s (28/30 RPM used)")
            time.sleep(wait)
            _request_count_minute = 0
            _minute_start = time.time()

    # Enforce ~1 req/sec minimum gap
    elapsed = now - _last_request_time
    if elapsed < 1.1:
        time.sleep(1.1 - elapsed)

    _last_request_time = time.time()
    _request_count_minute += 1


class LLMService:
    """Interface to Cerebras AI cloud API for AI-enhanced validation."""

    def __init__(self, model: str = MODEL_FAST, timeout: float = 30.0):
        self.base_url = CEREBRAS_API_URL
        self.api_key = REDACTED_SECRET
        self.model = model
        self.timeout = timeout
        self._available: Optional[bool] = None

    async def is_available(self) -> bool:
        """Check if Cerebras API is reachable."""
        if self._available is not None:
            return self._available
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    f"{self.base_url}/models",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                )
                self._available = resp.status_code == 200
        except Exception:
            self._available = False
        return self._available

    async def _complete(self, prompt: str, max_tokens: int = 1024, temperature: float = 0.1) -> str:
        """Send a completion request to Cerebras API."""
        try:
            _rate_limit()  # Enforce rate limits

            payload = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": "You are a web application testing assistant. Respond with valid JSON only. No markdown, no explanation."},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": False,
            }

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()
                content = data["choices"][0]["message"]["content"]
                logger.debug(f"LLM response ({self.model}): {content[:200]}...")
                return content
        except httpx.HTTPStatusError as e:
            logger.warning(f"Cerebras API error {e.response.status_code}: {e.response.text[:200]}")
            return ""
        except Exception as e:
            logger.warning(f"LLM request failed: {e}")
            return ""

    def _parse_json_response(self, response: str) -> any:
        """Parse JSON from LLM response, stripping markdown fences."""
        if not response:
            return None
        cleaned = response.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned[3:]
            if cleaned.endswith("```"):
                cleaned = cleaned.rsplit("```", 1)[0]
            cleaned = cleaned.strip()
        # Remove 'json' language tag if present
        if cleaned.startswith("json"):
            cleaned = cleaned[4:].strip()
        return json.loads(cleaned)

    # ── Element Classification ────────────────────────

    async def classify_elements(self, elements: list[dict], page_context: dict) -> list[dict]:
        """Use LLM to enhance element classification.

        Enriches elements with better names, type corrections, importance scores.
        """
        if not await self.is_available():
            logger.info("ℹ️ LLM server not running — using pattern-based classification only")
            return elements

        elem_summary = []
        for i, elem in enumerate(elements[:30]):
            elem_summary.append({
                "idx": i,
                "name": elem.get("name", "")[:100],
                "type": elem.get("type", "other"),
                "selector": elem.get("selector", "")[:80],
                "text": (elem.get("text") or "")[:100],
            })

        prompt = f"""Analyze these UI elements from a CRM application page.
Page context: {json.dumps(page_context)}

Elements: {json.dumps(elem_summary, indent=2)}

For each element, return a JSON array with objects containing:
- "idx": original index
- "better_name": improved human-readable name
- "type": corrected type (chart|report|tab|card|button|menu|link|widget|input|table|container|other)
- "importance": test priority 1-10 (10=critical business element, 1=decorative)
- "validation_hint": suggested validation approach

Return ONLY the JSON array, no explanation."""

        response = await self._complete(prompt, max_tokens=2048)
        if not response:
            return elements

        try:
            enrichments = self._parse_json_response(response)
            if not isinstance(enrichments, list):
                return elements

            enrichment_map = {e["idx"]: e for e in enrichments if isinstance(e, dict)}
            for i, elem in enumerate(elements):
                if i in enrichment_map:
                    enrichment = enrichment_map[i]
                    if enrichment.get("better_name"):
                        elem["name"] = enrichment["better_name"]
                    if enrichment.get("type"):
                        elem["type"] = enrichment["type"]
                    elem["importance"] = enrichment.get("importance", 5)
                    elem["validation_hint"] = enrichment.get("validation_hint", "")

            logger.info(f"🤖 LLM enriched {len(enrichment_map)} elements")
            return elements

        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Failed to parse LLM response: {e}")
            return elements

    # ── Chart Element Discovery ───────────────────────

    async def find_chart_clickable_selectors(self, html_snippet: str, page_context: dict) -> list[str]:
        """Use LLM to identify clickable chart element CSS selectors.

        Given HTML from the chart area, the LLM analyzes the SVG/canvas structure
        and returns CSS selectors for clickable data points (bars, segments, etc.).
        """
        if not await self.is_available():
            return []

        # Truncate HTML
        html = html_snippet[:6000] if html_snippet else ""
        if not html:
            return []

        prompt = f"""You are an expert web automation engineer. Analyze this HTML from a CRM dashboard chart.

Page: {json.dumps(page_context)}

Chart HTML:
{html}

Find CSS selectors for clickable chart data elements (bars, points, segments).
These are typically SVG <rect>, <path>, <circle> elements inside chart containers.
CRMNEXT/BusinessNext uses Highcharts — look for:
- rect elements with fill colors (chart bars)
- path elements (line chart segments)
- Elements with cursor:pointer or onclick handlers
- Data series elements

Return a JSON array of CSS selector strings, most specific first. Example:
["svg rect.highcharts-point", "svg g.highcharts-series rect", "svg rect[fill='#6B5DD3']"]

Return ONLY the JSON array."""

        response = await self._complete(prompt, max_tokens=500, temperature=0.1)
        if not response:
            return []

        try:
            selectors = self._parse_json_response(response)
            if isinstance(selectors, list):
                logger.info(f"🤖 LLM found {len(selectors)} chart selectors")
                return [s for s in selectors if isinstance(s, str)]
            return []
        except (json.JSONDecodeError, KeyError):
            return []

    # ── Test Case Generation ──────────────────────────

    async def generate_test_cases(self, page_context: dict, elements: list[dict]) -> list[dict]:
        """Generate additional test cases beyond simple visibility checks."""
        if not await self.is_available():
            return []

        elem_summary = [
            {"name": e.get("name", "")[:80], "type": e.get("type", ""), "text": (e.get("text") or "")[:60]}
            for e in elements[:20]
        ]

        prompt = f"""Given a CRM application page with these elements:
Page: {json.dumps(page_context)}
Elements: {json.dumps(elem_summary)}

Generate 5-10 meaningful test cases beyond simple visibility checks.
Focus on:
- Data integrity (numbers should be non-zero, dates should be valid)
- Navigation (links should be clickable)
- Content correctness (labels should match expected text)
- Layout (critical elements should be above the fold)

Return a JSON array: [{{"test_name": "...", "test_type": "content|number|drill|presence", "element_name": "...", "expected_value": "...", "validation_hint": "..."}}]

Return ONLY the JSON array."""

        response = await self._complete(prompt, max_tokens=1500)
        if not response:
            return []

        try:
            return self._parse_json_response(response) or []
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Failed to parse LLM test cases: {e}")
            return []

    # ── Failure Analysis ──────────────────────────────

    async def analyze_failure(self, test_name: str, expected: str, actual: str, page_context: dict) -> str:
        """Analyze why a test failed and suggest a fix."""
        if not await self.is_available():
            return ""

        prompt = f"""A validation test failed on a CRM page.
Test: {test_name}
Expected: {expected}
Actual: {actual}
Page: {json.dumps(page_context)}

In 1-2 sentences, explain why this might have failed and suggest a fix."""

        return await self._complete(prompt, max_tokens=200, temperature=0.3)

    # ── Login Selector Deduction ──────────────────────

    async def deduce_login_selector(self, html_context: str, field_type: str) -> str | None:
        """Ask LLM to deduce the CSS selector for a login field."""
        if not await self.is_available():
            return None

        html_snippet = html_context[:6000]

        prompt = f"""You are an expert Automation Engineer writing Playwright tests.
Analyze the following HTML snippet from a login page and find the CSS selector for the '{field_type}' input field.
BusinessNext systems often use custom attributes like aria-label, name, or id.

HTML Context:
{html_snippet}

Return ONLY a JSON object: {{"selector": "#TxtPassword"}}"""

        response = await self._complete(prompt, max_tokens=200, temperature=0.1)
        if not response:
            return None

        try:
            data = self._parse_json_response(response)
            return data.get("selector") if isinstance(data, dict) else None
        except (json.JSONDecodeError, KeyError):
            return None

    # ── Element Discovery ─────────────────────────────

    async def discover_elements_from_page(
        self,
        ax_tree_summary: list[dict],
        page_context: dict,
        html_snippet: str = "",
    ) -> list[dict]:
        """Use LLM to discover testable elements that patterns might have missed."""
        if not await self.is_available():
            logger.info("LLM server not available for AI element discovery.")
            return []

        ax_summary = ax_tree_summary[:40] if ax_tree_summary else []
        html_context = html_snippet[:3000] if html_snippet else ""

        prompt = f"""You are an expert QA automation engineer analyzing a CRM dashboard page.
Page context: {json.dumps(page_context)}

Elements already found via accessibility tree:
{json.dumps(ax_summary, indent=1)}

{f"HTML snippet (partial): {html_context}" if html_context else ""}

Identify ADDITIONAL testable elements the accessibility tree may have MISSED.
Common missed elements on CRMNEXT/BusinessNext dashboards:
- Highcharts charts rendered as <svg> (no ARIA role)
- KPI cards showing metrics
- Data grids with virtual scrolling
- Notification badges or counters

For each, provide:
- "name": human-readable name
- "type": (chart|widget|table|button|link|input|tab|container|other)
- "selector_hint": CSS selector to find it
- "importance": 1-10
- "validation_hint": how to validate

Return ONLY a JSON array. If no additional elements, return []."""

        response = await self._complete(prompt, max_tokens=1500, temperature=0.2)
        if not response:
            return []

        try:
            discovered = self._parse_json_response(response)
            if not isinstance(discovered, list):
                return []

            elements = []
            for item in discovered:
                if not isinstance(item, dict):
                    continue
                elements.append({
                    "name": item.get("name", "LLM-Discovered Element")[:100],
                    "type": item.get("type", "other"),
                    "selector": item.get("selector_hint", ""),
                    "text": item.get("name", "")[:200],
                    "confidence": min(item.get("importance", 5) / 10.0, 0.85),
                    "pattern_source": "llm_discovery",
                    "numeric_values": [],
                    "dom_path": "llm/discovered",
                    "validation_hint": item.get("validation_hint", ""),
                })

            logger.info(f"🤖 LLM discovered {len(elements)} additional elements")
            return elements

        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Failed to parse LLM discovery response: {e}")
            return []
