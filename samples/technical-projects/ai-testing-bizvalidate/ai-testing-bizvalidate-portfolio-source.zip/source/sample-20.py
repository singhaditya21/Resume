import os
from pathlib import Path
from pydantic_settings import BaseSettings
from functools import lru_cache

# Compute the absolute path for the SQLite DB file inside backend/data/
_BACKEND_DIR = Path(__file__).resolve().parent.parent
_DB_DIR = _BACKEND_DIR / "data"
_DB_DIR.mkdir(parents=True, exist_ok=True)
_DB_PATH = _DB_DIR / "bizvalidate.db"
_DEFAULT_DB_URL = f"sqlite+aiosqlite:///{_DB_PATH}"


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Database (SQLite — stored in backend/data/bizvalidate.db)
    DATABASE_URL: str = _DEFAULT_DB_URL

    # Security
    SECRET_KEY: str = "REDACTED_OPAQUE_VALUE"
    ENCRYPTION_KEY: str = "change-me-to-a-32-byte-hex-key"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480  # 8 hours

    # Target system defaults
    CRMNEXT_USERNAME: str = ""
    CRMNEXT_PASSWORD: str = ""
    CRMNEXT_URL: str = ""

    # Application
    EVIDENCE_DIR: str = "./evidence"
    LOG_LEVEL: str = "INFO"

    # Playwright
    PLAYWRIGHT_TIMEOUT_MS: int = 30000
    DOM_CAPTURE_TIMEOUT_S: int = 45
    SESSION_INACTIVITY_TIMEOUT_S: int = 1800  # 30 minutes

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


@lru_cache()
def get_settings() -> Settings:
    return Settings()
