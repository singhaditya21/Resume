"""Playwright automation engine v3 — multi-strategy element discovery.

v3: Accessibility tree + network interception + session persistence.
Keeps v2 DOM serializer as fallback.
"""

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from app.config import get_settings

logger = logging.getLogger("bizvalidate.playwright")
settings = get_settings()

# Session state directory for auth persistence
_SESSION_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "sessions"
_SESSION_DIR.mkdir(parents=True, exist_ok=True)

# SSO button locators — multi-strategy (BusinessNext patterns)
SSO_LOCATORS = [
    "button:has-text('BUSINESSNEXT Employee Login')",
    "button:has-text('Employee Login')",
    "a:has-text('Employee Login')",
    "[class*='sso'] button",
    "[class*='login'] button",
]


class PlaywrightEngine:
    """Manages Playwright browser lifecycle and page automation.

    v2: Dynamic hydration detection, HAR capture, auto-page discovery.
    """

    def __init__(self):
        self._playwright = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self.page: Page | None = None
        self._har_dir: str | None = None
        self._pending_requests: set = set()
        self._network_idle_event: asyncio.Event | None = None
        self._intercepted_responses: list[dict] = []  # Real-time API capture
        self._popup_pages: list[Page] = []  # Drill-down popup windows

    async def start(self, headless: bool = True, har_dir: str | None = None, browser_type: str = "chromium"):
        """Launch browser and create context."""
        logger.info(f"Starting Playwright {browser_type} (headless={headless})")
        self._playwright = await async_playwright().start()
        
        # Select browser engine dynamically
        browser_launcher = getattr(self._playwright, browser_type.lower(), self._playwright.chromium)
        
        launch_args = ["--no-sandbox", "--disable-dev-shm-usage"]
        if browser_type.lower() == "chromium":
            launch_args.append("--disable-gpu")
            
        self._browser = await browser_launcher.launch(
            headless=headless,
            args=launch_args,
        )
        self._har_dir = har_dir

        context_opts = {
            "viewport": {"width": 1920, "height": 1080},
            "user_agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0 Safari/537.36 BizValidate/1.0"
            ),
        }

        # Enable HAR capture if directory specified
        if har_dir:
            os.makedirs(har_dir, exist_ok=True)
            context_opts["record_har_path"] = os.path.join(har_dir, "capture.har")
            context_opts["record_har_url_filter"] = "**/*"
            # Enable MP4/WebM Video Recording
            context_opts["record_video_dir"] = har_dir
            context_opts["record_video_size"] = {"width": 1920, "height": 1080}

        # Session persistence — reuse auth state to avoid CAPTCHA
        session_file = _SESSION_DIR / "auth_state.json"
        if session_file.exists():
            try:
                context_opts["storage_state"] = str(session_file)
                logger.info(f"♻️ Restoring saved session from {session_file}")
            except Exception as e:
                logger.warning(f"Failed to load session state: {e}")

        self._context = await self._browser.new_context(**context_opts)
        
        # Start comprehensive execution trace
        if har_dir:
            await self._context.tracing.start(screenshots=True, snapshots=True, sources=True)
            
        self._context.set_default_timeout(settings.PLAYWRIGHT_TIMEOUT_MS)
        self.page = await self._context.new_page()

        # Set up network request tracking for deterministic wait
        self._setup_network_tracking()

        # Set up popup handler for drill-down windows
        self._setup_popup_handler()

        logger.info("Playwright browser launched")

    def _setup_popup_handler(self):
        """Set up handler to capture drill-down popup windows.

        CRMNEXT opens chart drill-downs as separate browser windows.
        This handler auto-captures them for element discovery.
        """
        self._popup_pages = []

        async def on_popup(popup: Page):
            """Capture new popup windows (drill-down reports)."""
            try:
                logger.info(f"📌 Popup captured: {popup.url[:80]}...")
                self._popup_pages.append(popup)

                # Wait for the popup to load
                try:
                    await popup.wait_for_load_state("domcontentloaded", timeout=15000)
                except Exception:
                    pass

                # Wait for skeleton placeholders to resolve into real data
                await self.wait_for_skeleton_resolve(popup)

                logger.info(f"✓ Popup ready: {len(self._popup_pages)} total windows")
            except Exception as e:
                logger.warning(f"Failed to capture popup: {e}")

        if self.page:
            self.page.on("popup", on_popup)
            logger.debug("Popup handler registered")

    async def wait_for_skeleton_resolve(self, target_page: Page = None, timeout_ms: int = 10000):
        """Wait for skeleton/shimmer placeholder elements to disappear.

        Drill-down popup tables in CRMNEXT show grey placeholder blocks
        (skeleton loading) before the real data renders. This method polls
        for those placeholders and waits until they're gone.

        Args:
            target_page: The page to check (defaults to self.page)
            timeout_ms: Maximum wait time in milliseconds (default 10s)
        """
        page = target_page or self.page
        if not page:
            return

        skeleton_selectors = [
            ".skeleton",
            "[class*='shimmer']",
            "[class*='placeholder']",
            "[class*='loading-skeleton']",
            ".skeleton-loader",
            "[class*='skeleton-']",
        ]

        combined = ", ".join(skeleton_selectors)
        poll_interval = 500  # ms
        elapsed = 0

        try:
            while elapsed < timeout_ms:
                count = await page.locator(combined).count()
                visible_count = 0
                for i in range(min(count, 10)):  # Check up to 10 elements
                    try:
                        if await page.locator(combined).nth(i).is_visible(timeout=200):
                            visible_count += 1
                    except Exception:
                        pass

                if visible_count == 0:
                    if elapsed > 0:
                        logger.info(f"  ✓ Skeleton placeholders resolved ({elapsed}ms)")
                    return

                await page.wait_for_timeout(poll_interval)
                elapsed += poll_interval

            logger.warning(f"  ⚠️ Skeleton placeholders still visible after {timeout_ms}ms")
        except Exception as e:
            logger.debug(f"  Skeleton wait skipped: {e}")

    async def capture_popup_elements(self) -> list[dict]:
        """Capture DOM and AX tree from all drill-down popup windows.

        Returns elements discovered in popups, each tagged with the popup source.
        Call this after navigating to pages that trigger drill-downs.
        """
        all_popup_elements = []

        if not self._popup_pages:
            return all_popup_elements

        logger.info(f"📌 Analyzing {len(self._popup_pages)} popup window(s)...")

        for i, popup in enumerate(self._popup_pages):
            try:
                if popup.is_closed():
                    continue

                popup_url = popup.url
                logger.info(f"  Popup {i+1}: {popup_url[:80]}...")

                # Wait for content to stabilize
                try:
                    await popup.wait_for_load_state("networkidle", timeout=5000)
                except Exception:
                    pass
                await asyncio.sleep(1)

                # Capture accessibility tree
                ax_tree = None
                try:
                    ax_tree = await popup.accessibility.snapshot()
                except Exception as e:
                    logger.debug(f"  AX tree failed in popup: {e}")

                # Capture DOM tree (serialize)
                dom_data = None
                try:
                    dom_data = await popup.evaluate("""() => {
                        function serialize(el, depth) {
                            if (depth > 8) return null;
                            const tag = el.tagName?.toLowerCase() || '';
                            const text = el.innerText?.substring(0, 200) || '';
                            const classes = Array.from(el.classList || []);
                            const children = [];
                            for (let c of el.children || []) {
                                const s = serialize(c, depth + 1);
                                if (s) children.push(s);
                            }
                            return { tag, text, classes, children,
                                     attributes: {
                                       id: el.id || '',
                                       'aria-label': el.getAttribute('aria-label') || '',
                                     },
                                     rect: el.getBoundingClientRect ?
                                       {width: el.offsetWidth, height: el.offsetHeight} :
                                       {}
                            };
                        }
                        return serialize(document.body, 0);
                    }""")
                except Exception as e:
                    logger.debug(f"  DOM serialize failed in popup: {e}")

                # Use DomAnalyzer to discover elements
                if ax_tree or dom_data:
                    from app.services.dom_analyzer import DomAnalyzer
                    analyzer = DomAnalyzer()
                    popup_elements = analyzer.discover_all(ax_tree, dom_data)

                    # Tag each element with popup source
                    for elem in popup_elements:
                        elem["pattern_source"] = f"popup_{elem.get('pattern_source', 'unknown')}"
                        elem["dom_path"] = f"popup[{i}]/{elem.get('dom_path', '')}"
                        elem["name"] = f"[Drill] {elem['name']}"

                    all_popup_elements.extend(popup_elements)
                    logger.info(f"  ✓ Popup {i+1}: found {len(popup_elements)} elements")

                # Take a screenshot for evidence
                if self._har_dir:
                    try:
                        popup_screenshot = os.path.join(
                            self._har_dir, f"popup_{i+1}.png"
                        )
                        await popup.screenshot(path=popup_screenshot, full_page=True)
                        logger.info(f"  📸 Popup screenshot: {popup_screenshot}")
                    except Exception:
                        pass

            except Exception as e:
                logger.warning(f"  Failed to analyze popup {i+1}: {e}")

        logger.info(f"📌 Total popup elements: {len(all_popup_elements)}")
        return all_popup_elements

    async def stop(self) -> str | None:
        """Close browser and return HAR file path if captured."""
        har_path = None
        try:
            if self._context:
                # Save session state for future runs (avoids CAPTCHA)
                try:
                    session_file = _SESSION_DIR / "auth_state.json"
                    await self._context.storage_state(path=str(session_file))
                    logger.info(f"💾 Session saved to {session_file}")
                except Exception as e:
                    logger.warning(f"Failed to save session state: {e}")

                if self._har_dir:
                    # Save the trace ZIP before closing context
                    trace_path = os.path.join(self._har_dir, "trace.zip")
                    await self._context.tracing.stop(path=trace_path)
                    logger.info(f"Trace captured: {trace_path}")
                    
                await self._context.close()
                if self._har_dir:
                    har_path = os.path.join(self._har_dir, "capture.har")
                    if os.path.exists(har_path):
                        logger.info(f"HAR captured: {har_path}")
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
            logger.info("Playwright browser closed")
        except Exception as e:
            logger.warning(f"Error closing Playwright: {e}")
        return har_path

    async def login(self, url: str, username: str, password: str):
        """Log into the target system — always uses direct credential form.
        
        BusinessNext pages may show an "Employee Login" SSO button that 
        redirects to Azure AD. We ALWAYS skip it and enter credentials
        directly into the username/password fields instead.
        """
        logger.info(f"Navigating to {url}")
        await self.page.goto(url, wait_until="domcontentloaded")
        await asyncio.sleep(2)

        # ── Session-restore redirect detection ──
        # If saved session cookies are valid, the server may redirect us
        # straight to the dashboard (e.g., /Home/Summary). In that case,
        # we should NOT try to fill login credentials.
        current_url = self.page.url.lower()
        login_indicators = ["login", "signin", "sign-in", "authenticate", "loginfmt"]
        still_on_login = any(ind in current_url for ind in login_indicators)

        if not still_on_login:
            logger.info(f"✓ Session restored — already redirected to: {self.page.url}")
            return  # Already logged in via session restore

        # Detect (but SKIP) SSO buttons — log them for visibility
        sso_found = False
        for locator_str in SSO_LOCATORS:
            try:
                locator = self.page.locator(locator_str).first
                if await locator.is_visible(timeout=2000):
                    sso_found = True
                    logger.info(f"SSO button detected but SKIPPED: {locator_str}")
                    break
            except Exception:
                continue

        if not sso_found:
            logger.info("No SSO button found — assuming direct login form")

        # Always fill credentials directly (never click SSO)
        await self._fill_credentials(username, password)

        # Handle "Stay signed in?" prompt (Microsoft SSO — in case of redirect)
        try:
            stay_signed = self.page.locator("#idSIButton9, button:has-text('Yes')").first
            if await stay_signed.is_visible(timeout=5000):
                await stay_signed.click()
                logger.info("Handled 'Stay signed in?' prompt")
        except Exception:
            pass

        # Wait for post-login navigation
        await asyncio.sleep(5)

        # Verify login succeeded — URL should have changed from the login page
        current_url = self.page.url.lower()
        login_indicators = ["login", "signin", "sign-in", "authenticate", "loginfmt"]
        still_on_login = any(ind in current_url for ind in login_indicators)

        # Handle CAPTCHA if we are still on the login page
        if still_on_login:
            captcha_detected = await self.page.evaluate("""
                () => {
                    const selectors = [
                        'iframe[src*="recaptcha"]', 'iframe[src*="hcaptcha"]', 'iframe[title*="recaptcha"]',
                        'img[src*="captcha"]', 'img[alt*="captcha"]', '#captcha', '.g-recaptcha',
                        '[class*="captcha"]', '[id*="captcha"]', '[name*="captcha"]'
                    ];
                    for (const sel of selectors) {
                        const el = document.querySelector(sel);
                        if (el && el.offsetWidth > 0 && el.offsetHeight > 0) return true;
                    }
                    if (document.body.innerText.toLowerCase().includes("captcha")) return true;
                    return false;
                }
            """)

            if captcha_detected:
                logger.warning("🛡️ CAPTCHA detected! Pausing automation for up to 60 seconds for manual resolution...")
                try:
                    # Wait for the user to solve it and for the URL to change
                    await self.page.wait_for_url(
                        lambda url: not any(ind in url.lower() for ind in login_indicators), 
                        timeout=60000
                    )
                    logger.info("✅ CAPTCHA manually solved! Proceeding with pipeline...")
                    still_on_login = False
                except Exception:
                    logger.error("Timeout waiting for manual CAPTCHA resolution.")
                    raise RuntimeError("Login failed — CAPTCHA detected but not solved within 60 seconds.")

        if still_on_login:
            # Check if there's an error message on the page
            error_text = await self.page.evaluate("""
                () => {
                    const errorEls = document.querySelectorAll(
                        '.error, .alert-danger, [class*="error"], [class*="Error"], .validation-summary-errors'
                    );
                    for (const el of errorEls) {
                        const t = el.textContent?.trim();
                        if (t && t.length > 0 && t.length < 500) return t;
                    }
                    return '';
                }
            """)
            if error_text:
                raise RuntimeError(f"Login failed — error on page: {error_text[:200]}")
            else:
                logger.warning("Still on login page after credentials — login may have failed")
                raise RuntimeError(
                    f"Login failed — still on login page ({current_url}). "
                    f"Check that the credentials in the configuration are correct."
                )

        logger.info(f"Login succeeded — now at: {self.page.url}")

        # Wait for post-login hydration
        await self._wait_for_hydration()

    async def navigate_to_page(self, page_url: str):
        """Navigate to any page and wait for full hydration."""
        logger.info(f"Navigating to: {page_url}")
        
        # If we are already on the page, don't trigger a full reload wait
        if self.page.url == page_url or self.page.url.rstrip("/") == page_url.rstrip("/"):
             await self._wait_for_hydration()
             return

        # Perform the navigation
        try:
            await self.page.goto(page_url, wait_until="commit", timeout=30000)
            await self._wait_for_hydration()
        except Exception as e:
            logger.warning(f"Warning during navigation to {page_url}: {e}")
            # Try to recover by waiting for network idle
            try:
                await self.page.wait_for_load_state("networkidle", timeout=15000)
            except:
                pass

    async def capture_page_dom(self, page_name: str = "auto") -> dict:
        """Capture the live DOM using multi-strategy approach.

        v3: Uses network idle wait + accessibility tree + DOM serializer.
        """
        logger.info(f"Capturing DOM for: {page_name}")

        # ── Strategy 1: Wait for network idle (deterministic) ──
        await self._wait_for_network_idle(timeout_s=15)

        # Extra buffer for jQuery AJAX callbacks
        await asyncio.sleep(3)

        # Scroll to trigger lazy content
        await self._scroll_page()

        # Trigger tabs
        await self._trigger_tabs()

        # Brief stability wait after interactions
        await self._wait_for_dom_stability(stabilize_ms=800, hard_timeout_ms=5000)

        # ── Strategy 2: Capture accessibility tree (framework-agnostic) ──
        ax_tree = await self.capture_accessibility_tree()

        # ── Strategy 3: Capture DOM structure (legacy fallback) ──
        dom_structure = await self._serialize_dom()

        # Get raw HTML
        dom_html = await self.page.content()
        current_url = self.page.url

        ax_count = self._count_ax_nodes(ax_tree) if ax_tree else 0
        logger.info(f"DOM captured for {page_name} ({current_url}) — "
                    f"accessibility tree: {ax_count} nodes, "
                    f"DOM tree: {'present' if dom_structure else 'empty'}")

        return {
            "structure": dom_structure,
            "ax_tree": ax_tree,
            "html": dom_html,
            "url": current_url,
            "har": None,
        }

    async def capture_accessibility_tree(self) -> dict | None:
        """Capture the page's accessibility tree via Playwright.

        Returns the full ARIA tree — roles, names, values. Framework-agnostic,
        works across iframes, and ignores decorative/invisible elements.
        """
        try:
            tree = await self.page.accessibility.snapshot()
            if tree:
                node_count = self._count_ax_nodes(tree)
                logger.info(f"♿ Accessibility tree captured: {node_count} nodes")
            else:
                logger.warning("Accessibility tree returned None")
            return tree
        except Exception as e:
            logger.warning(f"Failed to capture accessibility tree: {e}")
            return None

    def _count_ax_nodes(self, node: dict, count: int = 0) -> int:
        """Count nodes in an accessibility tree."""
        if not node:
            return count
        count += 1
        for child in node.get("children", []):
            count = self._count_ax_nodes(child, count)
        return count

    async def _serialize_dom(self) -> dict | None:
        """Serialize the DOM tree (legacy v2 approach, kept as fallback)."""
        try:
            return await self.page.evaluate("""
                () => {
                    function serializeNode(node, depth = 0) {
                        if (depth > 15) return null;
                        if (node.nodeType !== 1) return null;

                        const tag = node.tagName.toLowerCase();
                        const rect = node.getBoundingClientRect();

                        const attrs = {};
                        const keepAttrs = new Set([
                            'aria-label', 'aria-labelledby', 'aria-describedby',
                            'role', 'href', 'type', 'name', 'value',
                            'placeholder', 'alt', 'title', 'src',
                            'onclick', 'tabindex', 'draggable',
                        ]);
                        for (const attr of node.attributes) {
                            if (attr.name.startsWith('data-') || keepAttrs.has(attr.name)) {
                                attrs[attr.name] = (attr.value || '').substring(0, 200);
                            }
                        }

                        const result = {
                            tag: tag,
                            id: node.id || null,
                            classes: Array.from(node.classList),
                            text: null,
                            role: node.getAttribute('role'),
                            dataTestId: node.getAttribute('data-testid'),
                            attrs: attrs,
                            isVisible: !!(node.offsetWidth || node.offsetHeight || node.getClientRects().length),
                            rect: {
                                x: Math.round(rect.x),
                                y: Math.round(rect.y),
                                w: Math.round(rect.width),
                                h: Math.round(rect.height),
                            },
                            children: [],
                        };

                        const directText = Array.from(node.childNodes)
                            .filter(n => n.nodeType === 3)
                            .map(n => n.textContent.trim())
                            .join(' ').trim();
                        const fullText = (node.textContent || '').trim().substring(0, 300);
                        result.text = directText || fullText;

                        for (const child of node.children) {
                            const serialized = serializeNode(child, depth + 1);
                            if (serialized) result.children.push(serialized);
                        }

                        return result;
                    }
                    return serializeNode(document.body);
                }
            """)
        except Exception as e:
            logger.warning(f"DOM serialization failed: {e}")
            return None

    async def discover_navigation_items(self) -> list[dict]:
        """Auto-discover available pages from the sidebar/navigation.

        Returns: [{label, url, selector}]
        """
        logger.info("Discovering navigation items...")

        nav_items = await self.page.evaluate("""
            () => {
                const items = [];
                const navSelectors = [
                    'nav a', '.sidebar a', '[role="navigation"] a',
                    '.side-nav a', '.main-nav a', '[class*="menu"] a',
                    '[class*="nav"] a[href]',
                ];

                const seen = new Set();

                for (const selector of navSelectors) {
                    for (const el of document.querySelectorAll(selector)) {
                        const href = el.getAttribute('href');
                        const text = el.textContent?.trim();
                        if (href && text && !seen.has(href) && text.length < 100) {
                            // Skip external links, anchors, and javascript
                            if (href.startsWith('http') && !href.includes(location.host)) continue;
                            if (href === '#' || href.startsWith('javascript:')) continue;

                            seen.add(href);
                            items.push({
                                label: text.split('\\n')[0].trim(),
                                url: href.startsWith('/') ? location.origin + href : href,
                                selector: el.id ? `#${el.id}` : null,
                            });
                        }
                    }
                }
                return items;
            }
        """)

        logger.info(f"Found {len(nav_items)} navigation items")
        return nav_items

    async def check_element_visible(self, css_selector: str) -> dict:
        """Check if an element is visible and get its current state.

        Returns: {visible, text, rect, screenshot_clip}
        """
        if not css_selector:
            return {"visible": False}
        try:
            locator = self.page.locator(css_selector).first
            is_visible = await locator.is_visible(timeout=5000)
            if not is_visible:
                return {"visible": False}

            # Get element details
            details = await locator.evaluate("""
                el => ({
                    text: (el.textContent || '').trim().substring(0, 200),
                    rect: (() => {
                        const r = el.getBoundingClientRect();
                        return {x: Math.round(r.x), y: Math.round(r.y),
                                w: Math.round(r.width), h: Math.round(r.height)};
                    })(),
                    tagName: el.tagName.toLowerCase(),
                    childCount: el.children.length,
                })
            """)
            return {"visible": True, **details}
        except Exception:
            return {"visible": False}

    async def take_element_screenshot(self, css_selector: str, path: str) -> bool:
        """Take a screenshot of a specific element."""
        try:
            locator = self.page.locator(css_selector).first
            if await locator.is_visible(timeout=3000):
                await locator.screenshot(path=path, type="webp", quality=80)
                return True
        except Exception as e:
            logger.warning(f"Element screenshot failed for {css_selector}: {e}")
        return False

    async def take_full_page_screenshot(self, path: str) -> bool:
        """Take a full page screenshot. Used for visual regression baseline comparison."""
        try:
            # We save as PNG format for precise pixel comparison with Pillow
            await self.page.screenshot(path=path, type="png", full_page=True)
            return True
        except Exception as e:
            logger.warning(f"Full page screenshot failed: {e}")
            return False

    async def _heal_login_field_with_llm(self, field_type: str) -> str | None:
        """Use the local LLM to find obscure login fields and cache the result."""
        import json
        import os
        from app.services.llm_service import LLMService
        
        # Check cache first
        data_dir = os.path.join(os.path.dirname(__file__), "..", "..", "data")
        os.makedirs(data_dir, exist_ok=True)
        cache_file = os.path.join(data_dir, "login_locators.json")
        
        # Hash cache by path without transient query params
        url_hostname = self.page.url.split("?")[0]
        cache_key = f"{url_hostname}_{field_type}"
        
        try:
            if os.path.exists(cache_file):
                with open(cache_file, "r") as f:
                    cache = json.load(f)
                if cache_key in cache:
                    cached_sel = cache[cache_key]
                    if await self.page.locator(cached_sel).first.is_visible(timeout=1000):
                        logger.info(f"Using cached LLM selector for {field_type}: {cached_sel}")
                        return cached_sel
        except Exception as e:
            logger.warning(f"Failed to read locator cache: {e}")

        logger.info(f"Heuristic failed for '{field_type}'. Falling back to OpenClaw LLM Vision for URL: {url_hostname}")
        llm = LLMService()
        
        # Grab the HTML of the form or body
        html_context = await self.page.evaluate("""() => {
            const form = document.querySelector('form');
            if (form) return form.outerHTML;
            return document.body.innerHTML;
        }""")
        
        selector = await llm.deduce_login_selector(html_context, field_type)
        
        if selector:
            # Verify the suggested selector
            try:
                locator = self.page.locator(selector).first
                if await locator.is_visible(timeout=3000):
                    logger.info(f"LLM successfully healed '{field_type}' selector to: {selector} (verified)")
                    
                    # Update cache
                    try:
                        cache = {}
                        if os.path.exists(cache_file):
                            with open(cache_file, "r") as f:
                                cache = json.load(f)
                        cache[cache_key] = selector
                        with open(cache_file, "w") as f:
                            json.dump(cache, f, indent=2)
                        logger.info(f"Cached LLM selector {selector} for future runs")
                    except Exception as e:
                        logger.warning(f"Failed to write locator cache: {e}")
                    
                    return selector
                else:
                    logger.warning(f"LLM suggested {selector} but it is not visible on page")
            except Exception as e:
                logger.warning(f"LLM suggested invalid selector {selector}: {e}")
                
        return None

    # ── Private helpers ────────────────────────────────

    async def _fill_credentials(self, username: str, password: str):
        """Fill username and password using smart DOM auto-detection.
        
        Scans the page for visible form fields automatically — works for
        any login page (CRMNEXT, Microsoft SSO, generic forms, etc.).
        """
        # Step 1: Auto-detect form fields via JavaScript DOM scanning
        fields = await self.page.evaluate("""
            () => {
                function findVisibleInput(types, excludeTypes = []) {
                    // Strategy 1: Find by type attribute
                    for (const type of types) {
                        const inputs = document.querySelectorAll(`input[type='${type}']`);
                        for (const el of inputs) {
                            if (el.offsetWidth > 0 && el.offsetHeight > 0 && !el.disabled && !el.readOnly) {
                                return buildSelector(el);
                            }
                        }
                    }
                    // Strategy 2: Find any visible text-like input (for forms that don't use type=)
                    if (types.includes('text')) {
                        const allInputs = document.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="password"])');
                        for (const el of allInputs) {
                            if (el.offsetWidth > 0 && el.offsetHeight > 0 && !el.disabled && !el.readOnly) {
                                return buildSelector(el);
                            }
                        }
                    }
                    return null;
                }
                
                function findSubmitButton() {
                    // Strategy 1: input[type=submit] or button[type=submit]
                    const submits = document.querySelectorAll("input[type='submit'], button[type='submit']");
                    for (const el of submits) {
                        if (el.offsetWidth > 0 && el.offsetHeight > 0) return buildSelector(el);
                    }
                    // Strategy 2: Buttons with login/sign-in text
                    const buttons = document.querySelectorAll('button, input[type="button"], a.btn, [role="button"]');
                    const loginWords = ['login', 'log in', 'sign in', 'submit', 'enter', 'go'];
                    for (const el of buttons) {
                        const text = (el.textContent || el.value || '').trim().toLowerCase();
                        if (loginWords.some(w => text.includes(w)) && el.offsetWidth > 0 && el.offsetHeight > 0) {
                            return buildSelector(el);
                        }
                    }
                    return null;
                }
                
                function buildSelector(el) {
                    // Build a robust selector
                    if (el.id) return '#' + el.id;
                    if (el.name) return `${el.tagName.toLowerCase()}[name='${el.name}']`;
                    if (el.type && el.type !== 'text') return `${el.tagName.toLowerCase()}[type='${el.type}']`;
                    // Use nth-of-type as fallback
                    const parent = el.parentElement;
                    if (parent) {
                        const siblings = parent.querySelectorAll(el.tagName.toLowerCase());
                        for (let i = 0; i < siblings.length; i++) {
                            if (siblings[i] === el) {
                                return `${el.tagName.toLowerCase()}:nth-of-type(${i + 1})`;
                            }
                        }
                    }
                    return null;
                }
                
                return {
                    username: findVisibleInput(['text', 'email']),
                    password: findVisibleInput(['password']),
                    submit: findSubmitButton(),
                };
            }
        """)
        
        logger.info(f"Auto-detected login fields: {fields}")
        
        # Step 2: Fill username
        if not fields.get("username"):
            fields["username"] = await self._heal_login_field_with_llm("username")
            if not fields.get("username"):
                raise RuntimeError("Login failed — could not auto-detect username field on the page via heuristic or LLM")
        
        username_field = self.page.locator(fields["username"]).first
        await username_field.fill(username)
        logger.info(f"Username entered via auto-detected: {fields['username']}")
        
        # For 2-step SSO flows (e.g., Microsoft), try clicking submit after username
        if fields.get("submit") and not fields.get("password"):
            await self.page.locator(fields["submit"]).first.click()
            await asyncio.sleep(2)
            # Re-detect password field after page transition
            pw_sel = await self.page.evaluate("""
                () => {
                    const pw = document.querySelector("input[type='password']");
                    if (pw && pw.offsetWidth > 0 && pw.offsetHeight > 0) {
                        return pw.id ? '#' + pw.id : pw.name ? `input[name='${pw.name}']` : "input[type='password']";
                    }
                    return null;
                }
            """)
            if pw_sel:
                fields["password"] = pw_sel
        
        # Step 3: Fill password
        if not fields.get("password"):
            pw_fallback = await self.page.evaluate("""
                () => {
                    const selectors = ['input[type="password"]', '#TxtPassword', '#password', '[name="password"]', '[name="pwd"]', '#login_password'];
                    for (const sel of selectors) {
                        const el = document.querySelector(sel);
                        // Be more lenient with visibility for fallbacks
                        if (el) return sel;
                    }
                    return null;
                }
            """)
            if pw_fallback:
                fields["password"] = pw_fallback

        if not fields.get("password"):
            fields["password"] = await self._heal_login_field_with_llm("password")
            if not fields.get("password"):
                raise RuntimeError("Login failed — could not auto-detect password field on the page via heuristic or LLM")
        
        password_field = REDACTED_SECRET
        await password_field.is_visible(timeout=5000)
        await password_field.fill(password)
        logger.info(f"Password entered via auto-detected: {fields['password']}")
        
        # Step 4: Click submit
        if not fields.get("submit"):
            # Re-detect submit after filling fields (some forms show submit only after filling)
            fields["submit"] = await self.page.evaluate("""
                () => {
                    const submits = document.querySelectorAll("input[type='submit'], button[type='submit']");
                    for (const el of submits) {
                        if (el.offsetWidth > 0 && el.offsetHeight > 0) {
                            return el.id ? '#' + el.id : el.name ? `${el.tagName.toLowerCase()}[name='${el.name}']` : `${el.tagName.toLowerCase()}[type='submit']`;
                        }
                    }
                    return null;
                }
            """)
        
        if not fields.get("submit"):
            fields["submit"] = await self._heal_login_field_with_llm("submit button")
            if not fields.get("submit"):
                raise RuntimeError("Login failed — could not auto-detect submit button on the page via heuristic or LLM")
        
        submit_btn = self.page.locator(fields["submit"]).first
        await submit_btn.click()
        logger.info(f"Submit clicked via auto-detected: {fields['submit']}")

    async def _wait_for_hydration(self, timeout=20000):
        """Wait for page to be interactive (React/jQuery/Angular)."""
        logger.debug("Waiting for post-load hydration...")
        try:
            # 1. Wait for standard load state
            await self.page.wait_for_load_state("domcontentloaded", timeout=timeout)
            
            # 2. Wait until there are no more than 2 active network connections
            try:
                 await self.page.wait_for_load_state("networkidle", timeout=5000)
            except:
                 pass # Acceptable if there's long-polling

            # 3. Custom Javascript evaluators for common frameworks
            await self.page.evaluate("""
                () => new Promise(resolve => {
                    // Check if document is ready
                    if (document.readyState !== 'complete' && document.readyState !== 'interactive') {
                        let interval = setInterval(() => {
                            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                                clearInterval(interval);
                                resolve();
                            }
                        }, 100);
                        setTimeout(() => { clearInterval(interval); resolve(); }, 3000);
                        return;
                    }
                    resolve();
                })
            """)
        except Exception:
            pass

        # Signal 4: DOM stability (with hard cap)
        await self._wait_for_dom_stability()

    async def _wait_for_dom_stability(self, stabilize_ms: int = 800, hard_timeout_ms: int = 8000):
        """Wait until the DOM stops mutating for stabilize_ms milliseconds.
        
        Has a hard_timeout_ms cap to prevent infinite hangs on dynamic pages
        (e.g., CRMNEXT dashboards with live charts/tickers).
        """
        try:
            await self.page.evaluate(f"""
                () => new Promise((resolve) => {{
                    let timer = null;
                    // HARD CAP: always resolve after {hard_timeout_ms}ms regardless
                    const hardCap = setTimeout(() => {{
                        if (typeof observer !== 'undefined') observer.disconnect();
                        resolve(true);
                    }}, {hard_timeout_ms});
                    
                    const observer = new MutationObserver(() => {{
                        clearTimeout(timer);
                        timer = setTimeout(() => {{
                            observer.disconnect();
                            clearTimeout(hardCap);
                            resolve(true);
                        }}, {stabilize_ms});
                    }});
                    observer.observe(document.body, {{
                        childList: true, subtree: true, attributes: true
                    }});
                    // Start timer in case no mutations happen at all
                    timer = setTimeout(() => {{
                        observer.disconnect();
                        clearTimeout(hardCap);
                        resolve(true);
                    }}, {stabilize_ms});
                }})
            """)
        except Exception:
            await asyncio.sleep(min(stabilize_ms / 1000, 3))

    def _setup_network_tracking(self):
        """Set up request/response tracking for deterministic network idle detection.

        Also captures JSON API response bodies in real-time for live validation.
        """
        self._pending_requests = set()
        self._network_idle_event = asyncio.Event()
        self._network_idle_event.set()  # Start as idle
        self._intercepted_responses = []

        def on_request(request):
            if request.resource_type in ("xhr", "fetch", "document", "script"):
                self._pending_requests.add(request.url)
                self._network_idle_event.clear()

        def on_response(response):
            url = response.url
            self._pending_requests.discard(url)
            if len(self._pending_requests) == 0:
                self._network_idle_event.set()

            # Real-time API response capture
            try:
                content_type = response.headers.get("content-type", "")
                if "json" in content_type and 200 <= response.status < 300:
                    self._intercepted_responses.append({
                        "url": url,
                        "status": response.status,
                        "content_type": content_type,
                        "timestamp": time.time(),
                    })
            except Exception:
                pass

        def on_request_failed(request):
            self._pending_requests.discard(request.url)
            if len(self._pending_requests) == 0:
                self._network_idle_event.set()

        self.page.on("request", on_request)
        self.page.on("response", on_response)
        self.page.on("requestfailed", on_request_failed)
        logger.debug("Network request tracking initialized (with real-time API capture)")

    def get_intercepted_responses(self) -> list[dict]:
        """Get all API responses captured in real-time during page load."""
        return list(self._intercepted_responses)

    async def _wait_for_network_idle(self, timeout_s: int = 15, quiet_period_s: float = 2.0):
        """Wait until all XHR/fetch requests complete and stay quiet for quiet_period_s.

        Much more reliable than MutationObserver for detecting when AJAX content
        has finished loading on dynamic pages like CRMNEXT dashboards.
        """
        logger.debug(f"Waiting for network idle (timeout={timeout_s}s, quiet={quiet_period_s}s)")
        deadline = time.time() + timeout_s
        last_activity = time.time()

        while time.time() < deadline:
            if len(self._pending_requests) == 0:
                if time.time() - last_activity >= quiet_period_s:
                    logger.debug(f"Network idle achieved after {time.time() - (deadline - timeout_s):.1f}s")
                    return
            else:
                last_activity = time.time()

            await asyncio.sleep(0.25)

        pending_count = len(self._pending_requests)
        if pending_count > 0:
            logger.warning(f"Network idle timeout ({timeout_s}s) with {pending_count} pending requests")
        else:
            logger.debug("Network idle achieved at timeout")

    async def _scroll_page(self):
        """Scroll the page to trigger lazy-loaded content."""
        try:
            total_height = await self.page.evaluate("document.body.scrollHeight")
            viewport_height = 1080
            current = 0
            while current < total_height:
                current += viewport_height
                await self.page.evaluate(f"window.scrollTo(0, {current})")
                await asyncio.sleep(0.3)
            await self.page.evaluate("window.scrollTo(0, 0)")
            await asyncio.sleep(0.5)
        except Exception as e:
            logger.warning(f"Scroll error: {e}")

    async def _trigger_tabs(self):
        """Click visible tabs to force lazy tab content loading."""
        try:
            tabs = self.page.locator("[role='tab'], [class*='tab-header'], [class*='nav-tab']")
            count = await tabs.count()
            for i in range(min(count, 10)):
                try:
                    tab = tabs.nth(i)
                    if await tab.is_visible(timeout=1000):
                        await tab.click()
                        await asyncio.sleep(0.5)
                except Exception:
                    continue
            if count > 0:
                try:
                    await tabs.first.click()
                except Exception:
                    pass
        except Exception as e:
            logger.warning(f"Tab trigger error: {e}")
