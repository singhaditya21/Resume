#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE="${1:-portable}"

if [ "$PROFILE" = "portable" ]; then
  while IFS= read -r variable; do
    unset "$variable"
  done < <(compgen -A variable DBPROD_TEST_POSTGRES_ || true)
fi

cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT/work/redash_schema"

uv run --no-sync --python 3.11 \
  python scripts/validate_repository.py check

case "$PROFILE" in
  portable)
    TEST_MODULES=()
    while IFS= read -r module; do
      [ -n "$module" ] && TEST_MODULES+=("$module")
    done < <(
      uv run --no-sync --python 3.11 \
        python scripts/validate_repository.py test-modules --profile portable
    )
    if [ "${#TEST_MODULES[@]}" -eq 0 ]; then
      echo "Portable test profile is empty." >&2
      exit 2
    fi
    uv run --no-sync --python 3.11 python -m unittest -v \
      "${TEST_MODULES[@]}"
    ;;
  retrieval)
    TEST_MODULES=()
    while IFS= read -r module; do
      [ -n "$module" ] && TEST_MODULES+=("$module")
    done < <(
      uv run --locked --extra retrieval --python 3.11 \
        python scripts/validate_repository.py test-modules --profile retrieval
    )
    if [ "${#TEST_MODULES[@]}" -eq 0 ]; then
      echo "Retrieval test profile is empty." >&2
      exit 2
    fi
    uv run --locked --extra retrieval --python 3.11 python -m unittest -v \
      "${TEST_MODULES[@]}"
    ;;
  database)
    if [ -z "${DBPROD_TEST_POSTGRES_DSN:-}" ] || \
      [ -z "${DBPROD_TEST_POSTGRES_APP_DSN:-}" ] || \
      [ -z "${DBPROD_TEST_POSTGRES_APP_ROLE:-}" ]; then
      echo "Database tests require migrator DSN, app DSN, and app role variables." >&2
      exit 2
    fi
    if [ "${DBPROD_TEST_POSTGRES_CONFIRM_DISPOSABLE:-}" != \
      "dbprod_learning_test" ]; then
      echo "Database tests require the exact disposable-database confirmation." >&2
      exit 2
    fi
    uv run --locked --python 3.11 python - <<'PY'
import os
import re
import sys
from urllib.parse import unquote, urlsplit

database_name = "dbprod_learning_test"
role = os.environ["DBPROD_TEST_POSTGRES_APP_ROLE"]
if not re.fullmatch(r"dbprod_test_[a-z0-9_]{1,40}", role):
    sys.exit("Database test app role must use the disposable dbprod_test_ prefix.")

parsed = {}
for name in ("DBPROD_TEST_POSTGRES_DSN", "DBPROD_TEST_POSTGRES_APP_DSN"):
    value = os.environ[name]
    try:
        candidate = urlsplit(value)
        port = candidate.port
    except ValueError:
        sys.exit(f"{name} is not a valid PostgreSQL DSN.")
    if candidate.scheme not in {"postgres", "postgresql"}:
        sys.exit(f"{name} must use the PostgreSQL URL scheme.")
    if candidate.hostname not in {"127.0.0.1", "::1"}:
        sys.exit(f"{name} must target an exact numeric loopback address.")
    if port is None or not 1 <= port <= 65535:
        sys.exit(f"{name} must include an explicit loopback port.")
    if unquote(candidate.path) != f"/{database_name}":
        sys.exit(f"{name} must target the exact disposable database name.")
    if candidate.query or candidate.fragment:
        sys.exit(f"{name} must not contain query or fragment components.")
    if not candidate.username:
        sys.exit(f"{name} must include an explicit database role.")
    parsed[name] = candidate

if parsed["DBPROD_TEST_POSTGRES_APP_DSN"].username != role:
    sys.exit("The app DSN user must exactly match the declared app role.")
if parsed["DBPROD_TEST_POSTGRES_DSN"].username == role:
    sys.exit("Migrator and application test roles must be separate.")
if (
    parsed["DBPROD_TEST_POSTGRES_DSN"].hostname,
    parsed["DBPROD_TEST_POSTGRES_DSN"].port,
) != (
    parsed["DBPROD_TEST_POSTGRES_APP_DSN"].hostname,
    parsed["DBPROD_TEST_POSTGRES_APP_DSN"].port,
):
    sys.exit("Migrator and application test DSNs must share one endpoint.")
if os.environ["DBPROD_TEST_POSTGRES_DSN"] == os.environ["DBPROD_TEST_POSTGRES_APP_DSN"]:
    sys.exit("Migrator and application test DSNs must be separate.")
PY
    TEST_MODULES=()
    while IFS= read -r module; do
      [ -n "$module" ] && TEST_MODULES+=("$module")
    done < <(
      uv run --locked --python 3.11 \
        python scripts/validate_repository.py test-modules --profile database
    )
    if [ "${#TEST_MODULES[@]}" -eq 0 ]; then
      echo "Database test profile is empty." >&2
      exit 2
    fi
    uv run --locked --python 3.11 python -m unittest -v \
      "${TEST_MODULES[@]}"
    ;;
  full)
    uv run --no-sync --python 3.11 \
      python scripts/check_runtime_artifacts.py
    uv run --no-sync --python 3.11 \
      python -m unittest discover \
        -s work/redash_schema \
        -p 'test_*.py' \
        -v
    ;;
  *)
    echo "Unknown test profile: $PROFILE (expected portable, retrieval, database, or full)" >&2
    exit 2
    ;;
esac

pnpm check:assets
node --check work/redash_schema/query_studio_assets/app.js
uv run --no-sync python scripts/scan_repository_secrets.py
git diff --check
