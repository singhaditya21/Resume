#!/usr/bin/env python3
"""Fail clearly when a DBProd checkout has not been hydrated."""

from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.runtime_artifacts import REQUIRED_ARTIFACT_PATHS  # noqa: E402


REQUIRED_FILES = tuple(sorted(REQUIRED_ARTIFACT_PATHS))


def main() -> int:
    missing = []
    for relative_path in REQUIRED_FILES:
        path = ROOT / relative_path
        if not path.is_file() or path.stat().st_size == 0:
            missing.append(relative_path)

    if missing:
        print("DBProd runtime artifacts are not hydrated:")
        for relative_path in missing:
            print(f"- {relative_path}")
        print("See docs/ARTIFACTS.md for the governed build and hydration process.")
        return 1

    print(f"DBProd runtime artifact preflight passed ({len(REQUIRED_FILES)} files).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
