#!/usr/bin/env python3
"""Fail-closed validation for non-secret Schema Brain systemd configuration."""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.parse


IMAGE_REFERENCE_RE = re.compile(
    r"^[A-Za-z0-9][A-Za-z0-9._:/-]*@sha256:[0-9a-f]{64}$"
)
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
MEMORY_RE = re.compile(r"^[1-9][0-9]*(?:[kKmMgGtT][bB]?)?$")
CPU_RE = re.compile(r"^(?:[1-9][0-9]*(?:\.[0-9]+)?|0\.[0-9]*[1-9][0-9]*)$")
POSTGRES_ROLE_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")


def validate_pilot_config(environ=None):
    environment = os.environ if environ is None else environ
    image_reference = str(environment.get("SCHEMA_BRAIN_IMAGE_REFERENCE") or "")
    advisor_mode = str(
        environment.get("SCHEMA_BRAIN_MODEL_ADVISOR_MODE") or "disabled"
    ).strip().lower()
    advisor_origin = str(
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    ).strip()
    advisor_insecure_transport = any(
        str(environment.get(name) or "").strip().lower()
        in {"1", "true", "yes", "on"}
        for name in (
            "REDACTED_OPAQUE_VALUE",
            "REDACTED_OPAQUE_VALUE",
        )
    )
    postgres_role = str(
        environment.get("SCHEMA_BRAIN_POSTGRES_APP_ROLE") or ""
    ).strip()
    try:
        parsed_advisor_origin = urllib.parse.urlsplit(advisor_origin)
        advisor_origin_valid = bool(
            parsed_advisor_origin.scheme == "https"
            and parsed_advisor_origin.hostname
            and parsed_advisor_origin.username is None
            and parsed_advisor_origin.password is None
            and parsed_advisor_origin.path in {"", "/"}
            and not parsed_advisor_origin.query
            and not parsed_advisor_origin.fragment
        )
    except ValueError:
        advisor_origin_valid = False
    checks = {
        "image_digest_reference": bool(
            IMAGE_REFERENCE_RE.fullmatch(image_reference)
            and not image_reference.startswith(("http://", "https://", "-", "/"))
        ),
        "artifact_manifest_pin": bool(
            SHA256_RE.fullmatch(
                str(
                    environment.get(
                        "REDACTED_OPAQUE_VALUE"
                    )
                    or ""
                )
            )
        ),
        "memory_limit": bool(
            MEMORY_RE.fullmatch(
                str(environment.get("SCHEMA_BRAIN_MEMORY_LIMIT") or "")
            )
        ),
        "cpu_limit": bool(
            CPU_RE.fullmatch(
                str(environment.get("SCHEMA_BRAIN_CPU_LIMIT") or "")
            )
        ),
        "model_advisor": bool(
            advisor_mode in {"disabled", "shadow", "assist"}
            and not advisor_insecure_transport
            and (advisor_mode == "disabled" or advisor_origin_valid)
        ),
        "postgres_application_role": bool(
            POSTGRES_ROLE_RE.fullmatch(postgres_role)
            and not postgres_role.startswith("pg_")
            and postgres_role != "postgres"
        ),
    }
    failed = sorted(name for name, passed in checks.items() if not passed)
    return {
        "status": "passed" if not failed else "failed",
        "failed_checks": failed,
    }


def main() -> int:
    report = validate_pilot_config()
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
