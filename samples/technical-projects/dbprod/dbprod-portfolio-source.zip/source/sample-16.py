#!/usr/bin/env python3
"""Apply checked DBProd migrations with a separate PostgreSQL migrator role."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "work/redash_schema"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

from learning_runtime import resolve_postgres_dsn
from postgres_learning_store import PostgresLearningStore


MIGRATOR_DSN_ENV = "REDACTED_OPAQUE_VALUE"
CONFIRMATION = "REDACTED_OPAQUE_VALUE"


def _migrator_dsn(environ, *, production):
    value = str(environ.get(MIGRATOR_DSN_ENV) or "").strip()
    if not value:
        raise RuntimeError("PostgreSQL migrator credential is unavailable")
    validation_environment = dict(environ)
    validation_environment["SCHEMA_BRAIN_POSTGRES_DSN"] = value
    validation_environment.pop("SCHEMA_BRAIN_POSTGRES_DSN_FILE", None)
    return resolve_postgres_dsn(
        validation_environment,
        production=production,
    )


def apply_migrations(dsn, app_role):
    with PostgresLearningStore(dsn, owner_id=2, migrate=True) as store:
        role = store.configure_application_role(app_role)
        integrity = store.integrity_check()
        if integrity.get("status") != "passed":
            raise RuntimeError("PostgreSQL control-plane verification failed")
        return {
            "status": "applied",
            "backend": "postgresql",
            "schema": role["schema"],
            "schema_version": store.schema_version(),
            "owner_id": store.owner_id,
            "application_role": role["role"],
        }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Apply DBProd PostgreSQL migrations and app-role grants"
    )
    parser.add_argument("--app-role", required=True)
    parser.add_argument("--confirm", required=True)
    parser.add_argument(
        "--development",
        action="store_true",
        help="Allow a local non-TLS development database; never use for deployment",
    )
    return parser.parse_args(argv)


def main(argv=None, *, environ=None):
    args = parse_args(argv)
    environment = os.environ if environ is None else environ
    try:
        if args.confirm != CONFIRMATION:
            raise RuntimeError("Exact migration confirmation is required")
        report = apply_migrations(
            _migrator_dsn(environment, production=not args.development),
            args.app_role,
        )
    except Exception:
        print(
            json.dumps(
                {"status": "failed", "error": "PostgreSQL migration failed safely"},
                sort_keys=True,
            )
        )
        return 1
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
