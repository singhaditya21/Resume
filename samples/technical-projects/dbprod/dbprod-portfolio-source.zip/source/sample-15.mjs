import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const source = resolve(root, "node_modules/lucide/dist/umd/lucide.min.js");
const target = resolve(
  root,
  "work/redash_schema/query_studio_assets/lucide.min.js",
);
const expectedVersion = "1.24.0";

function digest(content) {
  return createHash("sha256").update(content).digest("hex");
}

const sourceContent = await readFile(source);
if (!sourceContent.subarray(0, 256).toString("utf8").includes(`lucide v${expectedVersion}`)) {
  throw new Error(`Installed Lucide asset is not the pinned v${expectedVersion} build`);
}

if (process.argv.includes("--check")) {
  const targetContent = await readFile(target);
  if (digest(sourceContent) !== digest(targetContent)) {
    throw new Error("Generated Lucide asset differs from the pinned dependency");
  }
  console.log(`Lucide v${expectedVersion} asset is reproducible.`);
} else {
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, sourceContent);
  console.log(`Built Lucide v${expectedVersion} asset.`);
}
