#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE="${1:-core}"

cd "$ROOT"

if ! command -v uv >/dev/null 2>&1; then
  echo "uv is required; install it through the approved developer tooling channel." >&2
  exit 1
fi
if ! command -v pnpm >/dev/null 2>&1; then
  echo "pnpm is required; install the version declared in package.json." >&2
  exit 1
fi

case "$PROFILE" in
  core|portable)
    PROFILE="core"
    uv sync --locked --python 3.11
    ;;
  runtime|full)
    PROFILE="runtime"
    uv sync --locked --python 3.11 --extra neural
    ;;
  *)
    echo "Unknown bootstrap profile: $PROFILE (expected core or runtime)" >&2
    exit 2
    ;;
esac

pnpm install --frozen-lockfile
pnpm build:assets
uv run --no-sync python scripts/preflight.py --profile "$PROFILE"
if [ "$PROFILE" = "core" ]; then
  "$ROOT/scripts/run_tests.sh" portable
else
  "$ROOT/scripts/run_tests.sh" full
fi
