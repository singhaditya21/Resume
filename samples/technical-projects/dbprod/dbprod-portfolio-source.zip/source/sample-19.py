#!/usr/bin/env python3
"""Prepare or audit an immutable DBProd artifact release tree."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import stat
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.runtime_artifacts import (  # noqa: E402
    HYDRATED_MANIFEST_NAME,
    VERIFIED_MARKER_NAME,
    verify_manifest,
)


SERVICE_UID = 0
SERVICE_GID = 10001
DIRECTORY_MODE = 0o750
FILE_MODE = 0o440
RELEASE_PATH = re.compile(
    r"^/srv/schema-brain/artifacts/releases/(?P<digest>[0-9a-f]{64})$"
)
SHA256 = re.compile(r"^[0-9a-f]{64}$")


class ReleasePermissionError(ValueError):
    """Raised when a release tree is unsafe or has incorrect metadata."""


def _release_entries(release_root):
    release_root = pathlib.Path(release_root)
    if release_root.is_symlink() or not release_root.is_dir():
        raise ReleasePermissionError("release_root_invalid")
    yield release_root, True
    for directory, directory_names, file_names in os.walk(
        release_root,
        topdown=True,
        followlinks=False,
    ):
        directory_path = pathlib.Path(directory)
        for name in sorted(directory_names):
            path = directory_path / name
            metadata = path.lstat()
            if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
                raise ReleasePermissionError("release_directory_entry_invalid")
            yield path, True
        for name in sorted(file_names):
            path = directory_path / name
            metadata = path.lstat()
            if (
                stat.S_ISLNK(metadata.st_mode)
                or not stat.S_ISREG(metadata.st_mode)
                or metadata.st_nlink != 1
            ):
                raise ReleasePermissionError("release_file_entry_invalid")
            yield path, False


def prepare_release_permissions(release_root):
    if os.geteuid() != 0:
        raise ReleasePermissionError("root_required")
    entries = list(_release_entries(release_root))
    for path, is_directory in entries:
        os.chown(path, SERVICE_UID, SERVICE_GID, follow_symlinks=False)
        os.chmod(
            path,
            DIRECTORY_MODE if is_directory else FILE_MODE,
            follow_symlinks=False,
        )
    return len(entries)


def audit_release_permissions(
    release_root,
    *,
    expected_uid=SERVICE_UID,
    expected_gid=SERVICE_GID,
    directory_mode=DIRECTORY_MODE,
    file_mode=FILE_MODE,
):
    count = 0
    for path, is_directory in _release_entries(release_root):
        metadata = path.lstat()
        expected_mode = directory_mode if is_directory else file_mode
        if (
            metadata.st_uid != expected_uid
            or metadata.st_gid != expected_gid
            or stat.S_IMODE(metadata.st_mode) != expected_mode
        ):
            raise ReleasePermissionError("release_permission_mismatch")
        count += 1
    return count


def verify_prepared_release(
    release_root,
    manifest_sha256,
    *,
    require_current_drift_evidence,
):
    """Verify a prepared release under an explicit activation or rollback policy."""

    release_root = pathlib.Path(release_root)
    if SHA256.fullmatch(str(manifest_sha256 or "")) is None:
        raise ReleasePermissionError("manifest_pin_invalid")
    audit_count = audit_release_permissions(release_root)
    for required_name in (HYDRATED_MANIFEST_NAME, VERIFIED_MARKER_NAME):
        if not (release_root / required_name).is_file():
            raise ReleasePermissionError("REDACTED_OPAQUE_VALUE")
    verification = verify_manifest(
        release_root,
        release_root / HYDRATED_MANIFEST_NAME,
        expected_manifest_sha256=manifest_sha256,
        reject_unmanifested_allowed=True,
        require_exact_runtime_tree=True,
        require_current_drift_evidence=require_current_drift_evidence,
    )
    return {
        "status": "prepared",
        "manifest_sha256": verification["manifest_sha256"],
        "entry_count": audit_count,
        "file_count": verification["file_count"],
    }


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=(
            "prepare",
            "check-candidate-mounted",
            "check-rollback-mounted",
        ),
    )
    parser.add_argument("--release-dir", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args(argv)
    release_root = pathlib.Path(args.release_dir)
    try:
        if args.command == "prepare":
            match = RELEASE_PATH.fullmatch(str(release_root))
            if (
                args.release_dir != str(release_root)
                or match is None
                or match.group("digest") != args.manifest_sha256
            ):
                raise ReleasePermissionError("canonical_release_path_invalid")
            prepare_release_permissions(release_root)
        elif str(release_root) != "/release":
            raise ReleasePermissionError("mounted_release_path_invalid")
        report = verify_prepared_release(
            release_root,
            args.manifest_sha256,
            # A candidate must carry current drift evidence. A preserved
            # rollback release remains valid when its exact, already-approved
            # bytes and metadata verify under that prior image's own contract;
            # age alone must not destroy the rollback anchor.
            require_current_drift_evidence=(
                args.command != "check-rollback-mounted"
            ),
        )
    except (OSError, ReleasePermissionError) as exc:
        code = str(exc) if isinstance(exc, ReleasePermissionError) else "filesystem_error"
        print(
            json.dumps({"status": "error", "error": code}, sort_keys=True),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
