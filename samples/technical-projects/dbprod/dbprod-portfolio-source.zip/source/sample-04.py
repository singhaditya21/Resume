#!/usr/bin/env python3
"""Local ChatGPT-style validation studio for the BusinessNext schema brain."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import mimetypes
import os
import pathlib
import re
import signal
import threading
import time
import urllib.parse
import uuid
from collections import Counter, defaultdict, deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from access_control import (
    AuthenticationError,
    AuthorizationError,
    authenticate_request,
    authorize,
    effective_permissions,
)
from answer_question import answer_declarative_capability_plan, answer_question
from benchmark_business_queries import BENCHMARKS
from business_reports import build_business_report_plan
from lazy_obsidian import (
    ACTIVE_VAULT,
    SOURCE_VAULT,
    archive_old_traces,
    ensure_active_vault,
    materialize_active_neighborhood,
)
from learning_loop import DEFAULT_LEARNING_LOOP
from learning_service import (
    CANDIDATE_VALIDATION_STATES,
    DEFAULT_LEARNING_SERVICE,
    LearningConflictError,
    LearningSLAReconciler,
)
from model_advisory_context import model_advisor_status
from metadata_uncertainty import DEFAULT_REPORT as UNCERTAINTY_REPORT
from obsidian_graph import DEFAULT_VAULT, load_json, open_obsidian_note, trace_graph, write_trace
from observability import METRICS, operational_event
from planner_events import browser_safe_payload
from redash_live import redash_datasource_access_probe, redash_key_available, run_query
from runtime_config import (
    PRODUCTION_CONTEXT,
    REDASH_BASE_URL,
    REDASH_DATA_SOURCE_ID,
    TENANT_OWNER_ID,
)
from runtime_paths import resolve_runtime_paths
from runtime_preflight import RuntimePreflight, runtime_lock_sha256, runtime_source_commit
from schema_drift import SchemaDriftMonitor, drift_evidence_gate
from validate_generated_answers import load_dbo_catalog
from workload_calibration import collect_production_baseline, load_production_baseline


ROOT = pathlib.Path(__file__).resolve().parents[2]
ASSET_DIR = ROOT / "REDACTED_OPAQUE_VALUE"
RUNTIME_PATHS = resolve_runtime_paths()
OUTPUT_DIR = RUNTIME_PATHS.artifact_path("outputs/redash_schema")
PROMOTION_REGRESSION_EVIDENCE = OUTPUT_DIR / "evaluation/promotion_regression_evidence.json"
OBSIDIAN_REST_BASE_URL = "https://127.0.0.1:27124"
VAULT_DIR = ensure_active_vault(source=SOURCE_VAULT, active=ACTIVE_VAULT)
TRACE_LOCK = threading.Lock()
PREVIEW_LOCK = threading.Lock()
PREVIEW_CATALOG = None
OBJECT_MAP = None
DRIFT_MONITOR = SchemaDriftMonitor(
    run_query,
    on_report=DEFAULT_LEARNING_SERVICE.invalidate_for_drift,
)
SLA_RECONCILER = LearningSLAReconciler(DEFAULT_LEARNING_SERVICE)
RATE_LOCK = threading.Lock()
RATE_WINDOWS = defaultdict(deque)
LIVE_QUERY_SLOTS = threading.BoundedSemaphore(4)
HEALTH_EVIDENCE_SCHEMA = "businessnext.dbprod.health-readiness-evidence/v1"
HEALTH_EVIDENCE_TTL = dt.timedelta(minutes=5)
RUNTIME_PREFLIGHT = RuntimePreflight(
    learning_store=lambda: DEFAULT_LEARNING_SERVICE.store,
    redash_key_available=lambda: redash_key_available(),
)
KNOWN_OPERATIONAL_ROUTES = {
    "/livez",
    "/readyz",
    "/api/health",
    "/api/metrics",
    "/api/examples",
    "/api/graph",
    "/api/traces",
    "/api/note",
    "/api/feedback",
    "/api/learning/dashboard",
    "/api/drift",
    "/api/chat",
    "/api/chat/stream",
    "/api/preview",
    "/api/feedback/corrections",
    "/api/learning/actions",
    "/api/drift/refresh",
    "/api/obsidian/open",
}


def health_readiness_evidence(now=None):
    """Return a short-lived, exact-source envelope without request identity."""

    captured_at = now or dt.datetime.now(dt.timezone.utc)
    if captured_at.tzinfo is None:
        captured_at = captured_at.replace(tzinfo=dt.timezone.utc)
    captured_at = captured_at.astimezone(dt.timezone.utc)
    return {
        "schema": HEALTH_EVIDENCE_SCHEMA,
        "version": 1,
        "captured_at": captured_at.isoformat(),
        "expires_at": (captured_at + HEALTH_EVIDENCE_TTL).isoformat(),
        "source_commit": runtime_source_commit(),
        "uv_lock_sha256": runtime_lock_sha256(),
        "scope": {
            "redash_base_url": REDASH_BASE_URL,
            "redash_data_source_name": PRODUCTION_CONTEXT.datasource,
            "redash_data_source_id": REDASH_DATA_SOURCE_ID,
            "owner_id": TENANT_OWNER_ID,
        },
    }


def safe_operational_route(raw_path):
    path = urllib.parse.urlparse(str(raw_path or "")).path
    if path in KNOWN_OPERATIONAL_ROUTES:
        return path
    if path.startswith("/api/learning/jobs/"):
        return "/api/learning/jobs/:id"
    if path.startswith("/api/"):
        return "/api/unknown"
    return "/asset"


def current_drift_evidence():
    return drift_evidence_gate(DRIFT_MONITOR.status())


def runtime_readiness():
    preflight_ready = RUNTIME_PREFLIGHT.public_status().get("status") == "ready"
    drift = current_drift_evidence()
    redash_access = redash_datasource_access_probe()
    drift_ready = (
        drift.get("status") == "accepted"
        and drift.get("freshness") == "current"
        and drift.get("owner_id") == TENANT_OWNER_ID
    )
    return (
        preflight_ready
        and drift_ready
        and redash_access.get("status") == "ready",
        drift,
        redash_access,
    )


def enforce_request_rate(actor_id, operation, limit, window_seconds=60):
    now = time.monotonic()
    key = (str(actor_id), str(operation))
    with RATE_LOCK:
        window = RATE_WINDOWS[key]
        while window and now - window[0] >= window_seconds:
            window.popleft()
        if len(window) >= int(limit):
            retry_after = max(1, int(window_seconds - (now - window[0])))
            METRICS.increment("rate_limit_rejections_total")
            raise APIError(
                "Request rate limit exceeded",
                HTTPStatus.TOO_MANY_REQUESTS,
                {"retry_after_seconds": retry_after, "operation": operation},
            )
        window.append(now)


def acquire_live_query_slot(timeout_seconds=5):
    if not LIVE_QUERY_SLOTS.acquire(timeout=max(0, timeout_seconds)):
        METRICS.increment("REDACTED_OPAQUE_VALUE")
        raise APIError(
            "The live-query concurrency limit is busy; retry shortly",
            HTTPStatus.SERVICE_UNAVAILABLE,
            {"concurrency_limit": 4},
        )


def install_sigterm_shutdown(server):
    """Stop accepting work once on SIGTERM without deadlocking serve_forever."""

    if threading.current_thread() is not threading.main_thread():
        return None
    shutdown_requested = threading.Event()

    def request_shutdown(_signum, _frame):
        if shutdown_requested.is_set():
            return
        shutdown_requested.set()
        threading.Thread(
            target=server.shutdown,
            name="studio-graceful-shutdown",
            daemon=True,
        ).start()

    return signal.signal(signal.SIGTERM, request_shutdown)


class APIError(Exception):
    def __init__(self, message, status=HTTPStatus.BAD_REQUEST, details=None):
        super().__init__(message)
        self.status = status
        self.details = details or {}


def json_ready(value):
    return json.loads(json.dumps(value, default=str))


def pinned_obsidian_rest_url(requested=None):
    if requested and str(requested).rstrip("/") != OBSIDIAN_REST_BASE_URL:
        raise ValueError("Obsidian REST URL is fixed to the local loopback endpoint")
    return OBSIDIAN_REST_BASE_URL


def read_report(path):
    try:
        return load_json(path)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def preview_catalog():
    global PREVIEW_CATALOG
    if PREVIEW_CATALOG is None:
        with PREVIEW_LOCK:
            if PREVIEW_CATALOG is None:
                PREVIEW_CATALOG = load_dbo_catalog()
    return PREVIEW_CATALOG


def graph_object_map():
    global OBJECT_MAP
    if OBJECT_MAP is None:
        OBJECT_MAP = read_report(VAULT_DIR / ".schema-brain/object_map.json")
    return OBJECT_MAP


def calibration_summary():
    evidence = read_report(PROMOTION_REGRESSION_EVIDENCE)
    suites = evidence.get("suites") or {}
    generated = suites.get("certainty_calibration") or {}
    holdout = suites.get("holdout_questions") or {}
    return {
        "generated": {
            "status": generated.get("status"),
            "passed": generated.get("passed_count", 0),
            "total": generated.get("case_count", 0),
        },
        "holdout": {
            "status": holdout.get("status"),
            "passed": holdout.get("passed_count", 0),
            "total": holdout.get("case_count", 0),
        },
        "live_unique_sql": {
            "status": "not_exposed",
            "passed": 0,
            "total": 0,
        },
    }


def build_question_preview(question):
    plan = build_business_report_plan(question, preview_catalog())
    if not plan:
        graph = GRAPH.draft_navigation(question)
        return {
            "status": "catalog_navigation" if graph.get("nodes") else "unresolved_draft",
            "resolved": False,
            "question": question,
            "sql": None,
            "query_metrics": None,
            "graph": graph,
        }
    intent = plan.get("intent")
    if intent == "needs_report_clarification":
        answer = "Multiple report providers remain plausible."
    elif intent == "needs_report_parameter":
        answer = "A required typed parameter is still missing."
    else:
        answer = "Draft provider and SQL structure resolved."
    result = {
        "status": "draft_preview",
        "question": question,
        "resolved_intent": plan,
        "sql": plan.get("sql"),
        "answer": answer,
        "validation": plan.get("sql_validation"),
        "live_execution": {"requested": False, "status": "draft_not_executed"},
        "certainty": plan.get("certainty"),
        "query_metrics": plan.get("query_metrics"),
        "row_count": 0,
    }
    graph = trace_graph(result, object_map=graph_object_map())
    if intent == "needs_report_clarification":
        root_id = graph["nodes"][0]["id"] if graph["nodes"] else None
        for candidate in plan.get("candidates") or []:
            candidate_id = f"draft-candidate:{candidate.get('intent')}"
            provider_id = f"draft-provider:{candidate.get('intent')}"
            graph["nodes"].append(
                {
                    "id": candidate_id,
                    "label": str(candidate.get("intent") or "candidate").replace("_", " ").title(),
                    "kind": "intent",
                    "detail": f"score {candidate.get('score')}",
                }
            )
            graph["nodes"].append(
                {
                    "id": provider_id,
                    "label": candidate.get("provider") or "provider",
                    "kind": "provider",
                }
            )
            if root_id:
                graph["edges"].append({"source": root_id, "target": candidate_id, "relation": "could_mean"})
            graph["edges"].append({"source": candidate_id, "target": provider_id, "relation": "uses"})
    return {
        "status": "resolved_draft" if intent not in {"needs_report_clarification", "needs_report_parameter"} else intent,
        "resolved": True,
        "question": question,
        "intent": intent,
        "provider": plan.get("provider"),
        "match_score": plan.get("match_score"),
        "score_margin": plan.get("score_margin"),
        "missing_parameters": plan.get("missing_parameters") or [],
        "sql": plan.get("sql"),
        "validation": plan.get("sql_validation"),
        "certainty": plan.get("certainty"),
        "query_metrics": plan.get("query_metrics"),
        "graph": graph,
    }


class CatalogGraph:
    def __init__(self, vault_dir):
        self.vault_dir = pathlib.Path(vault_dir)
        self.nodes = {}
        self.edges = []
        self.adjacency = defaultdict(list)
        self.kind_counts = Counter()
        self.loaded = False
        self.lock = threading.Lock()

    def ensure_loaded(self):
        if self.loaded:
            return
        with self.lock:
            if self.loaded:
                return
            nodes_path = self.vault_dir / ".schema-brain/graph_nodes.jsonl"
            edges_path = self.vault_dir / ".schema-brain/graph_edges.jsonl"
            if nodes_path.exists():
                with nodes_path.open(encoding="utf-8") as handle:
                    for line in handle:
                        if line.strip():
                            node = json.loads(line)
                            node["search_text"] = " ".join(
                                str(node.get(key) or "") for key in ("label", "id", "kind", "schema", "table")
                            ).lower()
                            self.nodes[node["id"]] = node
                            self.kind_counts[node.get("kind") or "unknown"] += 1
            if edges_path.exists():
                with edges_path.open(encoding="utf-8") as handle:
                    for line in handle:
                        if line.strip():
                            edge = json.loads(line)
                            self.edges.append(edge)
                            self.adjacency[edge["source"]].append((edge["target"], edge))
                            self.adjacency[edge["target"]].append((edge["source"], edge))
            self.loaded = True

    def summary(self):
        self.ensure_loaded()
        root = {"id": "catalog-root", "label": "BusinessNext Catalog", "kind": "root"}
        nodes = [root]
        edges = []
        priority = [
            "table",
            "view",
            "materialized_view",
            "procedure",
            "function",
            "lowcode_object",
            "custom_field",
            "layout",
            "role",
            "lookup_group",
            "lowcode_relationship",
            "intent",
            "provider",
            "schema",
            "type",
            "constraint",
            "trigger",
            "index",
            "sequence",
        ]
        for kind in priority:
            count = self.kind_counts.get(kind)
            if not count:
                continue
            node_id = f"kind:{kind}"
            nodes.append({"id": node_id, "label": kind.replace("_", " ").title(), "kind": kind, "count": count, "detail": f"{count:,} nodes"})
            edges.append({"source": "catalog-root", "target": node_id, "relation": "contains"})
        return {"nodes": nodes, "edges": edges, "total_nodes": len(self.nodes), "total_edges": len(self.edges)}

    def search(self, query, limit=80, kinds=None):
        self.ensure_loaded()
        query = str(query or "").strip().lower()
        terms = [term for term in query.split() if term]
        kinds = {value for value in (kinds or []) if value}
        scored = []
        for node in self.nodes.values():
            if kinds and node.get("kind") not in kinds:
                continue
            text = node.get("search_text", "")
            if terms and not all(term in text for term in terms):
                continue
            label = str(node.get("label") or "").lower()
            score = (100 if query and query == label else 0) + (50 if query and label.startswith(query) else 0)
            score += sum(10 for term in terms if label.startswith(term))
            score -= len(label) / 1000
            scored.append((score, node))
        scored.sort(key=lambda item: (item[0], item[1].get("label", "")), reverse=True)
        return [{key: value for key, value in node.items() if key != "search_text"} for _, node in scored[: max(1, min(limit, 250))]]

    def draft_navigation(self, question, limit=18):
        self.ensure_loaded()
        stopwords = {
            "all",
            "and",
            "are",
            "ask",
            "count",
            "data",
            "for",
            "from",
            "give",
            "have",
            "including",
            "list",
            "many",
            "show",
            "that",
            "the",
            "their",
            "this",
            "where",
            "with",
        }

        def singular(word):
            if word.endswith("ies") and len(word) > 4:
                return word[:-3] + "y"
            if word.endswith("s") and not word.endswith("ss") and len(word) > 4:
                return word[:-1]
            return word

        raw_terms = re.findall(r"[a-z0-9_]+", str(question).lower())
        terms = []
        for raw in raw_terms:
            value = singular(raw)
            if len(value) >= 3 and value not in stopwords and not value.isdigit() and value not in terms:
                terms.append(value)
        if not terms:
            return {"nodes": [], "edges": []}
        kind_weight = {
            "lowcode_object": 22,
            "table": 18,
            "view": 16,
            "custom_field": 14,
            "layout": 7,
            "lookup_group": 7,
            "provider": 6,
            "intent": 6,
        }
        scored = []
        for node in self.nodes.values():
            if node.get("kind") not in kind_weight:
                continue
            text = node.get("search_text", "")
            label = str(node.get("label") or "").lower()
            label_words = {singular(value) for value in re.findall(r"[a-z0-9_]+", label)}
            exact_matches = sum(1 for term in terms if term in label_words)
            partial_matches = sum(1 for term in terms if term not in label_words and term in text)
            if not exact_matches and not partial_matches:
                continue
            score = kind_weight[node.get("kind")] + exact_matches * 24 + partial_matches * 6
            if exact_matches >= 2:
                score += 18
            scored.append((score, node))
        scored.sort(key=lambda item: (item[0], -len(str(item[1].get("label") or ""))), reverse=True)
        selected = []
        seen_labels = set()
        score_floor = max(40, (scored[0][0] - 40) if scored else 40)
        for score, node in scored:
            if score < score_floor and selected:
                break
            label_key = str(node.get("label") or "").lower()
            if label_key in seen_labels:
                continue
            seen_labels.add(label_key)
            selected.append(node)
            if len(selected) >= min(limit, 12):
                break
        if not selected:
            selected = [node for _, node in scored[: min(limit, 6)]]
        root_id = "draft-question"
        output_nodes = [{"id": root_id, "label": "Draft Question", "kind": "question", "detail": question}]
        output_nodes.extend(
            {key: value for key, value in node.items() if key != "search_text"}
            for node in selected
        )
        output_edges = [
            {"source": root_id, "target": node["id"], "relation": "mentions"}
            for node in selected
        ]
        return {"nodes": output_nodes, "edges": output_edges, "matched_terms": terms}

    def neighborhood(self, root_id, depth=1, limit=180):
        self.ensure_loaded()
        if root_id not in self.nodes:
            return {"nodes": [], "edges": [], "root": root_id}
        depth = max(0, min(int(depth), 3))
        limit = max(10, min(int(limit), 500))
        selected = {root_id}
        queue = deque([(root_id, 0)])
        selected_edges = {}
        while queue and len(selected) < limit:
            current, current_depth = queue.popleft()
            if current_depth >= depth:
                continue
            neighbors = sorted(
                self.adjacency.get(current, []),
                key=lambda pair: (
                    0 if pair[1].get("relation") in {"reads_from", "resolved_by", "stored_in", "foreign_key"} else 1,
                    str((self.nodes.get(pair[0]) or {}).get("label") or ""),
                ),
            )
            for neighbor, edge in neighbors:
                if neighbor not in self.nodes:
                    continue
                selected_edges[edge["id"]] = edge
                if neighbor not in selected and len(selected) < limit:
                    selected.add(neighbor)
                    queue.append((neighbor, current_depth + 1))
        return {
            "nodes": [
                {key: value for key, value in self.nodes[node_id].items() if key != "search_text"}
                for node_id in selected
            ],
            "edges": [
                edge
                for edge in selected_edges.values()
                if edge["source"] in selected and edge["target"] in selected
            ],
            "root": root_id,
            "truncated": len(selected) >= limit,
        }


GRAPH = CatalogGraph(SOURCE_VAULT)


class StudioHandler(BaseHTTPRequestHandler):
    server_version = "SchemaBrainStudio/2.0"

    def log_message(self, format_string, *args):
        # The default handler logs raw request lines. Structured events below
        # deliberately use an allowlist and never contain question text.
        return

    def begin_observation(self):
        self._request_started = time.monotonic()
        self._request_id = uuid.uuid4().hex
        self._response_observed = False

    def observe_response(self, status, outcome="completed"):
        if getattr(self, "_response_observed", False):
            return
        self._response_observed = True
        duration_ms = max(
            0.0,
            (time.monotonic() - getattr(self, "_request_started", time.monotonic()))
            * 1000.0,
        )
        identity = getattr(self, "_studio_identity", None)
        METRICS.increment("http_requests_total")
        METRICS.observe("http_duration_ms", duration_ms)
        if int(status) >= 500:
            METRICS.increment("http_server_errors_total")
        operational_event(
            "request_completed",
            actor_id=getattr(identity, "actor_id", None),
            request_id=getattr(self, "_request_id", None),
            route=safe_operational_route(self.path),
            method=self.command,
            status_code=int(status),
            duration_ms=round(duration_ms, 3),
            outcome=outcome,
        )

    def end_headers(self):
        if getattr(self, "_request_id", None):
            self.send_header("X-Request-ID", self._request_id)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'",
        )
        super().end_headers()

    def origin_allowed(self):
        origin = self.headers.get("Origin")
        if origin:
            parsed = urllib.parse.urlparse(origin)
            host = self.headers.get("Host", "")
            return parsed.scheme in {"http", "https"} and parsed.netloc == host
        # No Origin header: fail closed unless browser fetch metadata proves a
        # same-origin (or direct top-level) request. Cross-site/same-site
        # requests, and clients that send neither Origin nor Sec-Fetch-Site,
        # are rejected.
        fetch_site = str(self.headers.get("Sec-Fetch-Site") or "").strip().lower()
        return fetch_site in {"same-origin", "none"}

    def send_internal_error(self, exc):
        # Never disclose exception detail to the browser; record the type
        # server-side (allowlisted) and correlate via the request id.
        request_id = getattr(self, "_request_id", None)
        operational_event(
            "request_failed",
            request_id=request_id,
            route=safe_operational_route(self.path),
            method=self.command,
            error_type=type(exc).__name__,
        )
        self.send_json(
            {"error": "internal_error", "request_id": request_id},
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )

    def send_json(self, payload, status=HTTPStatus.OK, headers=None):
        encoded = json.dumps(payload, default=str, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(str(name), str(value))
        self.end_headers()
        self.wfile.write(encoded)
        self.observe_response(status)

    def identity(self):
        if not hasattr(self, "_studio_identity"):
            self._studio_identity = authenticate_request(
                self.client_address[0],
                self.headers,
                method=self.command,
                path=self.path.split("?", 1)[0],
            )
        return self._studio_identity

    def require(self, permission):
        identity = self.identity()
        try:
            return authorize(identity, permission)
        except AuthorizationError:
            DEFAULT_LEARNING_SERVICE._audit(
                "authorization_decision",
                identity.actor_id,
                "permission",
                permission,
                outcome="denied",
                details={
                    "role": identity.role,
                    "path": safe_operational_route(self.path),
                },
            )
            raise

    @staticmethod
    def permission_for(method, path):
        if method == "GET":
            if path in {"/api/health", "/api/metrics"}:
                return "health:read"
            if path.startswith("/api/learning") or path == "/api/feedback":
                return "learning:read"
            return "catalog:read"
        if path in {"/api/chat", "/api/chat/stream", "/api/preview"}:
            return "query:execute"
        if path == "/api/feedback/corrections":
            return "feedback:create"
        if path == "/api/drift/refresh":
            return "admin:drift"
        if path == "/api/obsidian/open":
            return "admin:obsidian"
        if path == "/api/learning/actions":
            return "learning:read"
        return "catalog:read"

    def send_api_error(self, exc):
        if isinstance(exc, AuthenticationError):
            self.send_json(
                {"error": str(exc), "type": type(exc).__name__},
                HTTPStatus.UNAUTHORIZED,
                headers={"WWW-Authenticate": "Bearer"},
            )
            return
        if isinstance(exc, AuthorizationError):
            self.send_json(
                {"error": str(exc), "type": type(exc).__name__},
                HTTPStatus.FORBIDDEN,
            )
            return
        if isinstance(exc, APIError):
            self.send_json(
                {"error": str(exc), "type": type(exc).__name__, **exc.details},
                exc.status,
            )
            return
        if isinstance(exc, LearningConflictError):
            self.send_json(
                {"error": str(exc), "type": type(exc).__name__},
                HTTPStatus.CONFLICT,
            )
            return
        raise exc

    def read_json(self, max_bytes=131072):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > max_bytes:
            raise ValueError("Request body is empty or too large")
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        self.begin_observation()
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/livez":
            self.send_json({"status": "live"})
            return
        if parsed.path == "/readyz":
            try:
                ready, _drift, _redash_access = runtime_readiness()
            except Exception:
                ready = False
            payload = {"status": "ready" if ready else "not_ready"}
            status = HTTPStatus.OK if ready else HTTPStatus.SERVICE_UNAVAILABLE
            self.send_json(payload, status)
            return
        if not parsed.path.startswith("/api/"):
            self.serve_asset(parsed.path)
            return
        try:
            self.require(self.permission_for("GET", parsed.path))
            query = urllib.parse.parse_qs(parsed.query)
            if parsed.path == "/api/health":
                self.handle_health()
            elif parsed.path == "/api/metrics":
                self.handle_metrics()
            elif parsed.path == "/api/examples":
                self.handle_examples()
            elif parsed.path == "/api/graph":
                self.handle_graph(query)
            elif parsed.path == "/api/traces":
                self.handle_traces(query)
            elif parsed.path == "/api/note":
                self.handle_note(query)
            elif parsed.path == "/api/feedback":
                self.handle_feedback(query)
            elif parsed.path == "/api/learning/dashboard":
                self.handle_learning_dashboard(query)
            elif parsed.path.startswith("/api/learning/jobs/"):
                self.handle_learning_job(parsed.path)
            elif parsed.path == "/api/drift":
                self.send_json(DRIFT_MONITOR.status())
            else:
                self.send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except (AuthenticationError, AuthorizationError, LearningConflictError, APIError) as exc:
            self.send_api_error(exc)
        except KeyError as exc:
            self.send_json({"error": str(exc)}, HTTPStatus.NOT_FOUND)
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self.send_internal_error(exc)

    def do_POST(self):
        self.begin_observation()
        parsed = urllib.parse.urlparse(self.path)
        try:
            identity = self.identity()
            # CSRF: only browser-ambient (signed SSO proxy) credentials can be
            # driven cross-site by a malicious page. Bearer-token and loopback
            # development callers present non-ambient credentials, so the
            # same-origin proof is enforced only on the proxy path.
            if identity.auth_method == "signed_sso_proxy" and not self.origin_allowed():
                self.send_json({"error": "Origin not allowed"}, HTTPStatus.FORBIDDEN)
                return
            self.require(self.permission_for("POST", parsed.path))
            if parsed.path in {"/api/chat", "/api/chat/stream"}:
                enforce_request_rate(
                    self.identity().actor_id,
                    "live_query",
                    30,
                )
            elif parsed.path == "/api/preview":
                enforce_request_rate(
                    self.identity().actor_id,
                    "draft_preview",
                    180,
                )
            elif parsed.path in {
                "/api/learning/actions",
                "/api/feedback/corrections",
                "/api/drift/refresh",
                "/api/obsidian/open",
            }:
                enforce_request_rate(
                    self.identity().actor_id,
                    "state_mutation",
                    60,
                )
            if parsed.path == "/api/chat":
                self.handle_chat()
            elif parsed.path == "/api/chat/stream":
                self.handle_chat_stream()
            elif parsed.path == "/api/preview":
                self.handle_preview()
            elif parsed.path == "/api/feedback/corrections":
                self.handle_feedback_correction()
            elif parsed.path == "/api/learning/actions":
                self.handle_learning_action()
            elif parsed.path == "/api/drift/refresh":
                self.handle_drift_refresh()
            elif parsed.path == "/api/obsidian/open":
                self.handle_obsidian_open()
            else:
                self.send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except (AuthenticationError, AuthorizationError, LearningConflictError, APIError) as exc:
            self.send_api_error(exc)
        except KeyError as exc:
            self.send_json({"error": str(exc)}, HTTPStatus.NOT_FOUND)
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self.send_internal_error(exc)

    def handle_health(self):
        readiness_evidence = health_readiness_evidence()
        source_bound = bool(
            re.fullmatch(
                r"[0-9a-f]{40}",
                str(readiness_evidence.get("source_commit") or ""),
            )
            and readiness_evidence.get("source_commit") != "0" * 40
            and re.fullmatch(
                r"[0-9a-f]{64}",
                str(readiness_evidence.get("uv_lock_sha256") or ""),
            )
        )
        manifest = read_report(SOURCE_VAULT / ".schema-brain/manifest.json")
        uncertainty = read_report(UNCERTAINTY_REPORT)
        workload = load_production_baseline()
        learning_metrics = DEFAULT_LEARNING_SERVICE.metrics_snapshot(
            max_age_seconds=30
        )
        learning_metrics_observation = learning_metrics.get("metrics_snapshot") or {}
        learning_store_snapshot = learning_metrics.get("store_snapshot") or {}
        learning_store = learning_store_snapshot.get("stats") or {}
        learning_integrity = learning_store_snapshot.get("integrity") or {
            "status": "unavailable"
        }
        advisor_health = {
            **model_advisor_status(),
            "metrics": learning_metrics.get("model_advisor"),
        }
        identity = self.identity()
        try:
            ready, drift, redash_access = runtime_readiness()
        except Exception:
            ready = False
            drift = drift_evidence_gate(None)
            redash_access = {"status": "unavailable", "access": "unverified"}
        ready = bool(
            ready
            and redash_access.get("status") == "ready"
            and source_bound
            and learning_metrics_observation.get("freshness") == "current"
            and learning_store.get("status") == "ready"
            and learning_integrity.get("status") == "passed"
        )
        self.send_json(
            {
                "status": "ready" if ready else "not_ready",
                "datasource": PRODUCTION_CONTEXT.datasource,
                "redash_base_url": REDASH_BASE_URL,
                "redash_data_source_id": REDASH_DATA_SOURCE_ID,
                "owner_id": TENANT_OWNER_ID,
                "readiness_evidence": readiness_evidence,
                "execution_mode": PRODUCTION_CONTEXT.execution_mode,
                "redash_key_available": redash_key_available(),
                "redash_env_key_available": bool(os.environ.get("REDASH_API_KEY")),
                "redash_credential_source": (
                    "environment"
                    if os.environ.get("REDASH_API_KEY")
                    else "macos_keychain"
                    if redash_key_available()
                    else "unavailable"
                ),
                "redash_access": redash_access,
                "vault_status": manifest.get("status"),
                "graph_nodes": manifest.get("graph_nodes", 0),
                "graph_edges": manifest.get("graph_edges", 0),
                "coverage": manifest.get("coverage") or {},
                "calibration": calibration_summary(),
                "workload_baseline": {
                    "status": workload.get("status"),
                    "captured_at": workload.get("captured_at"),
                    "statement_count": workload.get("statement_count", 0),
                },
                # Public health exposes only the sanitized gate contract. The
                # full drift report remains on the admin-only /api/drift route.
                "schema_drift": drift,
                "owner_uncertainty": {
                    "canonical_fields": uncertainty.get("canonical_fields") or {},
                    "resolution_queue_count": uncertainty.get("resolution_queue_count", 0),
                },
                "learning_loop": {
                    "status": learning_store.get("status"),
                    "backend": learning_store.get("backend"),
                    "integrity": learning_integrity,
                    "schema_version": learning_store.get("schema_version"),
                    "counts": learning_store.get("counts"),
                    "counts_observation": learning_store_snapshot.get(
                        "observation"
                    ),
                    "metrics": learning_metrics,
                    "sla_reconciler": SLA_RECONCILER.status(),
                },
                "model_advisor": advisor_health,
                "access": {
                    "actor_id": identity.actor_id,
                    "role": identity.role,
                    "auth_method": identity.auth_method,
                    "permissions": effective_permissions(identity),
                },
                "operational_limits": {
                    "live_query_concurrency": 4,
                    "REDACTED_OPAQUE_VALUE": 30,
                    "REDACTED_OPAQUE_VALUE": 60,
                    "REDACTED_OPAQUE_VALUE": 180,
                },
            }
        )

    def handle_metrics(self):
        learning = DEFAULT_LEARNING_SERVICE.metrics_snapshot(max_age_seconds=30)
        backlog = learning.get("learning_backlog") or {}
        METRICS.gauge("learning_backlog_open", backlog.get("open_jobs") or 0)
        METRICS.gauge("learning_backlog_overdue", backlog.get("overdue_jobs") or 0)
        capture_rate = learning.get("unknown_capture_rate")
        if isinstance(capture_rate, (int, float)) and not isinstance(capture_rate, bool):
            METRICS.gauge("learning_unknown_capture_rate", capture_rate)
        self.send_json(
            {
                "operational": METRICS.snapshot(),
                "learning": {
                    "metrics_snapshot": learning.get("metrics_snapshot"),
                    "unknown_capture_rate": capture_rate,
                    "unknown_capture_measurement": learning.get(
                        "unknown_capture_measurement"
                    ),
                    "learning_measurement": learning.get(
                        "learning_measurement"
                    ),
                    "learning_backlog": backlog,
                    "model_advisor": learning.get("model_advisor"),
                },
            }
        )

    def handle_examples(self):
        examples = [
            {"id": f"benchmark-{index + 1}", "intent": intent, "question": question}
            for index, (intent, question) in enumerate(BENCHMARKS)
        ]
        examples.extend(
            [
                {
                    "id": "metadata-opportunity-owner",
                    "intent": "metadata_count_by_field",
                    "question": "Give me count of opportunities by opportunity owner where owner id = 2",
                },
                {
                    "id": "ambiguity-example",
                    "intent": "needs_report_clarification",
                    "question": "Show Service ARR and the billing pipeline for Account ID 57 in FY27",
                },
            ]
        )
        self.send_json({"examples": examples})

    def handle_graph(self, query):
        root = (query.get("root") or [None])[0]
        search = (query.get("q") or [""])[0]
        depth = int((query.get("depth") or [1])[0])
        limit = int((query.get("limit") or [180])[0])
        if root:
            self.send_json(GRAPH.neighborhood(root, depth=depth, limit=limit))
            return
        if search:
            matches = GRAPH.search(search, limit=30)
            if not matches:
                self.send_json({"nodes": [], "edges": [], "matches": []})
                return
            graph = GRAPH.neighborhood(matches[0]["id"], depth=depth, limit=limit)
            graph["matches"] = matches
            self.send_json(graph)
            return
        self.send_json(GRAPH.summary())

    def handle_traces(self, query):
        limit = max(1, min(int((query.get("limit") or [50])[0]), 250))
        trace_path = VAULT_DIR / ".schema-brain/traces.jsonl"
        rows = []
        if trace_path.exists():
            with trace_path.open(encoding="utf-8") as handle:
                rows = [json.loads(line) for line in handle if line.strip()]
        self.send_json({"traces": list(reversed(rows[-limit:]))})

    def safe_vault_path(self, relative):
        candidate = (VAULT_DIR / relative).resolve()
        if VAULT_DIR.resolve() not in candidate.parents and candidate != VAULT_DIR.resolve():
            raise ValueError("Invalid vault path")
        return candidate

    def handle_note(self, query):
        relative = (query.get("path") or [""])[0]
        target = self.safe_vault_path(relative)
        if not target.exists():
            source_target = (SOURCE_VAULT / relative).resolve()
            if SOURCE_VAULT.resolve() in source_target.parents and source_target.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source_target.read_bytes())
        if not target.exists() or not target.is_file():
            self.send_json({"error": "Note not found"}, HTTPStatus.NOT_FOUND)
            return
        content = target.read_text(encoding="utf-8")
        self.send_json({"path": relative, "content": content[:250000], "truncated": len(content) > 250000})

    def handle_chat(self):
        payload = self.read_json()
        question = str(payload.get("question") or "").strip()
        if not question:
            raise ValueError("Question is required")
        if len(question) > 6000:
            raise ValueError("Question is too long")
        if payload.get("open_obsidian"):
            self.require("admin:obsidian")
        obsidian_key = self.headers.get("X-Obsidian-Api-Key") or None
        identity = self.identity()
        acquire_live_query_slot()
        try:
            result = answer_question(
                question,
                preview_limit=max(1, min(int(payload.get("preview_limit") or 100), 500)),
                live=True,
                live_timeout=max(
                    10,
                    min(
                        int(payload.get("timeout") or PRODUCTION_CONTEXT.timeout_seconds),
                        PRODUCTION_CONTEXT.timeout_seconds,
                    ),
                ),
                live_max_age=0,
                remember=True,
                actor=identity.actor_id,
            )
        finally:
            LIVE_QUERY_SLOTS.release()
        self.finalize_trace(result, payload, obsidian_key)
        DEFAULT_LEARNING_SERVICE.record_query_audit(result, actor=identity.actor_id)
        self.send_json(json_ready(result))

    def finalize_trace(self, result, payload, obsidian_key=None):
        with TRACE_LOCK:
            trace = write_trace(
                result,
                vault_dir=VAULT_DIR,
                open_in_obsidian=bool(payload.get("open_obsidian")),
                rest_key=obsidian_key or os.environ.get("OBSIDIAN_REST_API_KEY"),
                rest_base=pinned_obsidian_rest_url(
                    payload.get("obsidian_rest_url")
                ),
            )
            trace["lazy_materialization"] = materialize_active_neighborhood(result)
            trace["archive"] = archive_old_traces()
        result["trace"] = trace
        return trace

    def send_sse_event(self, event_name, payload):
        encoded = json.dumps(payload, default=str, ensure_ascii=True)
        self.wfile.write(f"event: {event_name}\ndata: {encoded}\n\n".encode("utf-8"))
        self.wfile.flush()

    def handle_chat_stream(self):
        payload = self.read_json()
        question = str(payload.get("question") or "").strip()
        if not question:
            raise ValueError("Question is required")
        if len(question) > 6000:
            raise ValueError("Question is too long")
        if payload.get("open_obsidian"):
            self.require("admin:obsidian")
        acquire_live_query_slot()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        stream_outcome = "completed"
        try:
            identity = self.identity()
            result = answer_question(
                question,
                preview_limit=max(1, min(int(payload.get("preview_limit") or 100), 500)),
                live=True,
                live_timeout=max(
                    10,
                    min(
                        int(payload.get("timeout") or PRODUCTION_CONTEXT.timeout_seconds),
                        PRODUCTION_CONTEXT.timeout_seconds,
                    ),
                ),
                live_max_age=0,
                remember=True,
                event_sink=lambda event: self.send_sse_event("planner", event),
                actor=identity.actor_id,
            )
            self.finalize_trace(
                result,
                payload,
                self.headers.get("X-Obsidian-Api-Key") or None,
            )
            DEFAULT_LEARNING_SERVICE.record_query_audit(
                result,
                actor=identity.actor_id,
            )
            self.send_sse_event("result", json_ready(result))
            self.send_sse_event("done", {"status": "complete"})
            self.close_connection = True
        except (BrokenPipeError, ConnectionResetError):
            stream_outcome = "disconnected"
            return
        except Exception as exc:
            stream_outcome = "error"
            METRICS.increment("stream_errors_total")
            try:
                self.send_sse_event(
                    "error",
                    browser_safe_payload(
                        {"error": str(exc), "type": type(exc).__name__}
                    ),
                )
            except (BrokenPipeError, ConnectionResetError):
                pass
        finally:
            LIVE_QUERY_SLOTS.release()
            self.observe_response(HTTPStatus.OK, outcome=stream_outcome)

    def handle_feedback(self, query):
        identity = self.identity()
        state = (query.get("state") or ["open"])[0]
        limit = int((query.get("limit") or [100])[0])
        feedback_id = (query.get("feedback_id") or [None])[0]
        lifecycle = DEFAULT_LEARNING_LOOP.lifecycle_snapshot(feedback_id)
        unknown_questions = DEFAULT_LEARNING_LOOP.list_unknown(
            state=state,
            limit=limit,
        )
        if feedback_id:
            unknown_questions = [
                row
                for row in unknown_questions
                if row.get("feedback_id") == feedback_id
            ]
        learning = DEFAULT_LEARNING_SERVICE.dashboard(
            state=None if state in {"", "all", "open"} else state,
            limit=limit,
            actor_id=identity.actor_id,
            actor_role=identity.role,
            permissions=effective_permissions(identity),
        )
        self.send_json(
            {
                "unknown_questions": unknown_questions,
                "active_rules": DEFAULT_LEARNING_LOOP.active_rules(),
                "active_capabilities": DEFAULT_LEARNING_SERVICE.admitted_capability_versions(
                    limit=5000
                ),
                "lifecycle": lifecycle,
                "learning": learning,
                "jobs": learning.get("jobs") or [],
                "metrics": learning.get("metrics") or {},
                "notifications": learning.get("notifications") or [],
            }
        )

    def handle_learning_dashboard(self, query):
        identity = self.identity()
        state = (query.get("state") or [None])[0]
        if state in {"", "all"}:
            state = None
        limit = max(1, min(int((query.get("limit") or [100])[0]), 1000))
        after_job_id = (query.get("after_job_id") or [None])[0]
        self.send_json(
            DEFAULT_LEARNING_SERVICE.dashboard(
                state=state,
                limit=limit,
                actor_id=identity.actor_id,
                actor_role=identity.role,
                permissions=effective_permissions(identity),
                after_job_id=after_job_id,
            )
        )

    def handle_learning_job(self, path):
        prefix = "/api/learning/jobs/"
        job_id = urllib.parse.unquote(path[len(prefix) :]).strip()
        if not job_id:
            raise ValueError("job_id is required")
        identity = self.identity()
        self.send_json(
            DEFAULT_LEARNING_SERVICE.get_job(
                job_id,
                actor_id=identity.actor_id,
                actor_role=identity.role,
            )
        )

    def _learning_job_id(self, payload):
        job_id = str(payload.get("job_id") or "").strip()
        if job_id:
            return job_id
        feedback_id = str(payload.get("feedback_id") or "").strip()
        if not feedback_id:
            return None
        jobs = DEFAULT_LEARNING_SERVICE.store.list_learning_jobs(
            feedback_id=feedback_id,
            limit=2,
        )
        return jobs[-1].get("job_id") if jobs else None

    def _retry_answer(
        self,
        question,
        actor,
        learning=True,
        persist_operational_feedback=True,
        learning_job_id=None,
    ):
        acquire_live_query_slot()
        try:
            result = answer_question(
                question,
                preview_limit=100,
                live=True,
                live_timeout=PRODUCTION_CONTEXT.timeout_seconds,
                live_max_age=0,
                remember=bool(persist_operational_feedback),
                learning=bool(learning),
                actor=actor,
                persist_operational_feedback=bool(
                    persist_operational_feedback
                ),
            )
        finally:
            LIVE_QUERY_SLOTS.release()
        audit_result = result
        if learning_job_id and not result.get("learning_job"):
            audit_result = {
                **result,
                "learning_job": {"job_id": learning_job_id},
            }
        DEFAULT_LEARNING_SERVICE.record_query_audit(audit_result, actor=actor)
        return result

    def handle_learning_action(self):
        payload = self.read_json(max_bytes=262144)
        action = str(payload.get("action") or "").strip().lower()
        if action not in {
            "build",
            "validate",
            "approve",
            "clarify",
            "retry",
            "resolve",
            "rollback",
            "ack_notification",
            "generate_rule_evidence",
            "validate_rule",
            "approve_rule",
            "retire_rule",
        }:
            raise ValueError("Unsupported learning action")
        identity = self.identity()
        review_actions = {"build", "resolve", "rollback"}
        if action in {"generate_rule_evidence", "validate_rule"}:
            self.require("learning:validate")
        elif action == "approve_rule":
            self.require("learning:approve")
        elif action == "retire_rule":
            self.require("learning:retire")
        elif action == "validate":
            self.require("learning:validate")
        elif action == "approve":
            self.require("learning:approve")
        elif action == "clarify":
            self.require("learning:clarify")
        elif action in review_actions:
            self.require("learning:review")
        elif action == "retry":
            self.require("learning:retry")
        elif action == "ack_notification":
            # Acknowledgement is available to every reader, but the learning
            # service still enforces exact personal/team notification
            # visibility before changing durable state.
            self.require("learning:read")

        if action in {
            "generate_rule_evidence",
            "validate_rule",
            "approve_rule",
            "retire_rule",
        }:
            rule_id = str(payload.get("rule_id") or "").strip()
            if not rule_id:
                raise ValueError("rule_id is required")
            try:
                evidence = None
                if action in {"generate_rule_evidence", "validate_rule"}:
                    evidence = DEFAULT_LEARNING_LOOP.generate_rule_validation_evidence(
                        rule_id,
                        actor=identity.actor_id,
                        actor_role=identity.role,
                        expected_version=payload.get("expected_version"),
                        expected_state=payload.get("expected_state"),
                    )
                if action == "generate_rule_evidence":
                    response = {
                        "status": "evidence_generated",
                        "message": "Current owner-2 rule validation evidence was generated.",
                        "validation_evidence": evidence,
                    }
                elif action == "validate_rule":
                    rule = DEFAULT_LEARNING_LOOP.validate_rule_candidate(
                        rule_id,
                        evidence,
                        actor=identity.actor_id,
                        actor_role=identity.role,
                        expected_version=payload.get("expected_version"),
                        expected_state=payload.get("expected_state"),
                    )
                    response = {
                        "status": "validated",
                        "message": "The learned rule passed current generated validation.",
                        "rule": rule,
                        "validation_evidence": evidence,
                    }
                elif action == "approve_rule":
                    rule = DEFAULT_LEARNING_LOOP.approve_rule_candidate(
                        rule_id,
                        actor=identity.actor_id,
                        actor_role=identity.role,
                        expected_version=payload.get("expected_version"),
                        expected_state=payload.get("expected_state"),
                    )
                    response = {
                        "status": "active",
                        "message": "The independently validated learned rule is active.",
                        "rule": rule,
                    }
                else:
                    rule = DEFAULT_LEARNING_LOOP.retire_rule(
                        rule_id,
                        actor=identity.actor_id,
                        actor_role=identity.role,
                        reason=payload.get("reason"),
                        expected_version=payload.get("expected_version"),
                        expected_state=payload.get("expected_state"),
                    )
                    response = {
                        "status": "retired",
                        "message": "The learned rule was retired immediately.",
                        "rule": rule,
                    }
            except KeyError as exc:
                raise APIError(str(exc), HTTPStatus.NOT_FOUND) from exc
            except ValueError as exc:
                raise APIError(str(exc), HTTPStatus.CONFLICT) from exc
            DEFAULT_LEARNING_SERVICE._audit(
                "learned_rule_%s" % action,
                identity.actor_id,
                "learned_rule",
                rule_id,
                details={
                    "role": identity.role,
                    "state": response.get("status"),
                },
            )
            response["history"] = DEFAULT_LEARNING_LOOP.rule_history(rule_id)
            self.send_json(response)
            return

        if action == "ack_notification":
            notification_id = str(payload.get("notification_id") or "").strip()
            if not notification_id:
                raise ValueError("notification_id is required")
            try:
                notification = DEFAULT_LEARNING_SERVICE.acknowledge_notification(
                    notification_id,
                    actor=identity.actor_id,
                    actor_role=identity.role,
                )
            except (KeyError, PermissionError) as exc:
                # Do not disclose whether a deterministic ID belongs to a
                # notification hidden from the current personal/team queue.
                raise APIError(
                    "Notification unavailable.", HTTPStatus.NOT_FOUND
                ) from exc
            self.send_json(
                {
                    "status": "acknowledged",
                    "message": "Notification acknowledged.",
                    "notification": notification,
                }
            )
            return

        if action == "rollback":
            capability_id = str(payload.get("capability_id") or "").strip()
            if not capability_id:
                raise ValueError("capability_id is required")
            try:
                capability = DEFAULT_LEARNING_SERVICE.rollback_capability(
                    capability_id,
                    target_version=payload.get("target_version"),
                    reason=payload.get("reason"),
                    actor=identity.actor_id,
                    expected_current_version=payload.get("capability_version"),
                )
            except ValueError as exc:
                raise APIError(str(exc), HTTPStatus.CONFLICT) from exc
            self.send_json(
                {
                    "status": "rolled_back",
                    "message": "Capability rollback was appended as a new active version.",
                    "capability": capability,
                    "lifecycle": DEFAULT_LEARNING_LOOP.lifecycle_snapshot(),
                }
            )
            return

        job_id = self._learning_job_id(payload)
        if not job_id:
            raise APIError("Learning job was not found", HTTPStatus.NOT_FOUND)
        current = DEFAULT_LEARNING_SERVICE.get_job(job_id)
        expected_state = payload.get("expected_state")
        if expected_state is None or not str(expected_state).strip():
            raise APIError(
                "expected_state is required for learning job actions",
                HTTPStatus.CONFLICT,
                {"current_state": current.get("state")},
            )
        expected_state = str(expected_state).strip()
        if expected_state != str(current.get("state")):
            raise APIError(
                "Learning job state changed; refresh before acting.",
                HTTPStatus.CONFLICT,
                {
                    "expected_state": expected_state,
                    "current_state": current.get("state"),
                },
            )

        if action == "build":
            job = DEFAULT_LEARNING_SERVICE.build_candidate(
                job_id,
                patch=payload.get("candidate_patch") or {},
                actor=identity.actor_id,
                expected_state=expected_state,
            )
            response = {
                "status": "candidate_built",
                "message": "A versioned declarative capability candidate was built.",
                "job": job,
            }
        elif action == "validate":
            if current.get("state") not in CANDIDATE_VALIDATION_STATES:
                raise APIError(
                    "Capability candidate cannot be validated from state %s"
                    % current.get("state"),
                    HTTPStatus.CONFLICT,
                    {"current_state": current.get("state")},
                )
            candidate_evaluation = DEFAULT_LEARNING_SERVICE.compile_candidate(
                job_id,
                preview_catalog(),
            )
            candidate_plan = candidate_evaluation.get("plan")
            if candidate_plan:
                acquire_live_query_slot()
                try:
                    answer_result = answer_declarative_capability_plan(
                        current.get("question"),
                        candidate_plan,
                        preview_limit=100,
                        live=True,
                        live_timeout=PRODUCTION_CONTEXT.timeout_seconds,
                        live_max_age=0,
                    )
                finally:
                    LIVE_QUERY_SLOTS.release()
            else:
                answer_result = {
                    "status": "candidate_compile_failed",
                    "question": current.get("question"),
                    "validation": {"status": "failed"},
                    "semantic_validation": {"status": "failed"},
                    "live_execution": {
                        "requested": False,
                        "status": "REDACTED_OPAQUE_VALUE",
                    },
                }
            answer_result["capability_validation"] = candidate_evaluation.get(
                "suite"
            )
            answer_result["schema_drift"] = current_drift_evidence()
            DEFAULT_LEARNING_SERVICE.record_query_audit(
                answer_result,
                actor=identity.actor_id,
            )
            validation = DEFAULT_LEARNING_SERVICE.validate_job(
                job_id,
                answer_result=answer_result,
                actor=identity.actor_id,
                expected_state=expected_state,
                expected_candidate_binding=candidate_evaluation.get(
                    "candidate_binding"
                ),
            )
            response = {
                "status": validation["validation"].get("status"),
                "message": (
                    "All promotion gates passed."
                    if validation["validation"].get("status") == "passed"
                    else "Validation is incomplete; the capability remains blocked."
                ),
                **validation,
            }
        elif action == "approve":
            resumed_activation = expected_state == "activation_pending"
            try:
                approval = DEFAULT_LEARNING_SERVICE.approve_job(
                    job_id,
                    actor=identity.actor_id,
                    expected_state=expected_state,
                )
            except LearningConflictError:
                raise
            except ValueError as exc:
                raise APIError(str(exc), HTTPStatus.UNPROCESSABLE_ENTITY) from exc
            retry = DEFAULT_LEARNING_SERVICE.retry_job(
                job_id,
                lambda question: self._retry_answer(question, identity.actor_id),
                actor=identity.actor_id,
                expected_state="promoted",
            )
            response = {
                "status": "promoted" if retry["job"].get("state") == "resolved" else "promoted_retry_incomplete",
                "message": (
                    "Authorized activation resumed; the capability was promoted and the original question now resolves."
                    if resumed_activation and retry["job"].get("state") == "resolved"
                    else "Authorized activation resumed and promoted, but the original question still cannot be answered safely."
                    if resumed_activation
                    else "Capability promoted and the original question now resolves."
                    if retry["job"].get("state") == "resolved"
                    else "Capability promoted, but the original question still cannot be answered safely."
                ),
                "approval": approval,
                "retry": retry,
                "lifecycle": DEFAULT_LEARNING_LOOP.lifecycle_snapshot(current.get("feedback_id")),
            }
        elif action == "retry":
            retry = DEFAULT_LEARNING_SERVICE.retry_job(
                job_id,
                lambda question: self._retry_answer(question, identity.actor_id),
                actor=identity.actor_id,
                expected_state=expected_state,
            )
            response = {
                "status": retry["job"].get("state"),
                "message": "The original question was retried against current prod-my data.",
                **retry,
            }
        elif action == "clarify":
            try:
                clarification = DEFAULT_LEARNING_SERVICE.submit_clarification(
                    job_id,
                    payload.get("clarifications"),
                    lambda question: self._retry_answer(
                        question,
                        identity.actor_id,
                        learning=False,
                        persist_operational_feedback=False,
                        learning_job_id=job_id,
                    ),
                    actor=identity.actor_id,
                    expected_state=expected_state,
                    allow_requester_override=identity.role == "admin",
                )
            except PermissionError as exc:
                raise APIError(str(exc), HTTPStatus.FORBIDDEN) from exc
            response = {
                "status": clarification["job"].get("state"),
                "message": (
                    "The clarification resolved the original question."
                    if clarification["job"].get("state") == "resolved"
                    else "The clarification was applied, but the question still needs work."
                ),
                **clarification,
            }
        else:
            outcome = str(payload.get("outcome") or "").strip()
            job = DEFAULT_LEARNING_SERVICE.resolve_job(
                job_id,
                outcome,
                note=payload.get("note"),
                actor=identity.actor_id,
                expected_state=expected_state,
            )
            response = {
                "status": outcome,
                "message": "The governed non-answer outcome was recorded.",
                "job": job,
            }
        self.send_json(response)

    def handle_feedback_correction(self):
        payload = self.read_json()
        actor = self.identity().actor_id
        result = DEFAULT_LEARNING_LOOP.submit_correction(
            str(payload.get("feedback_id") or ""),
            payload.get("correction") or {},
            actor=actor,
        )
        jobs = DEFAULT_LEARNING_SERVICE.store.list_learning_jobs(
            feedback_id=str(payload.get("feedback_id") or ""),
            limit=1,
        )
        if jobs:
            # Corrections are append-only learning-rule inputs.  They must not
            # reopen or rewrite a capability job after validation/promotion.
            result["learning_job"] = DEFAULT_LEARNING_SERVICE.public_job(jobs[0])
            result["learning_job_status"] = "unchanged_rule_review_required"
        self.send_json(result, HTTPStatus.CREATED)

    def handle_drift_refresh(self):
        self.send_json(DRIFT_MONITOR.run_once())

    def handle_preview(self):
        payload = self.read_json(max_bytes=32768)
        question = str(payload.get("question") or "").strip()
        if len(question) < 8:
            self.send_json(
                {
                    "status": "draft_too_short",
                    "resolved": False,
                    "question": question,
                    "sql": None,
                    "query_metrics": None,
                    "graph": {"nodes": [], "edges": []},
                }
            )
            return
        if len(question) > 6000:
            raise ValueError("Question is too long")
        self.send_json(json_ready(build_question_preview(question)))

    def handle_obsidian_open(self):
        payload = self.read_json()
        self.require("admin:obsidian")
        relative = str(payload.get("path") or "Current Trace.md")
        target = self.safe_vault_path(relative)
        if not target.exists():
            source_target = (SOURCE_VAULT / relative).resolve()
            if SOURCE_VAULT.resolve() in source_target.parents and source_target.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source_target.read_bytes())
        result = open_obsidian_note(
            relative,
            api_key=self.headers.get("X-Obsidian-Api-Key") or os.environ.get("OBSIDIAN_REST_API_KEY"),
            base_url=pinned_obsidian_rest_url(
                payload.get("obsidian_rest_url")
            ),
        )
        self.send_json(result, HTTPStatus.OK if result.get("status") == "opened" else HTTPStatus.BAD_GATEWAY)

    def serve_asset(self, request_path):
        relative = "index.html" if request_path in {"", "/"} else request_path.lstrip("/")
        target = (ASSET_DIR / relative).resolve()
        if ASSET_DIR.resolve() not in target.parents and target != ASSET_DIR.resolve():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        if not target.exists() or not target.is_file():
            target = ASSET_DIR / "index.html"
        content = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type + ("; charset=utf-8" if content_type.startswith("text/") or content_type == "application/javascript" else ""))
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache" if target.name == "index.html" else "public, max-age=3600")
        self.end_headers()
        self.wfile.write(content)
        self.observe_response(HTTPStatus.OK)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    require_auth = str(os.environ.get("SCHEMA_BRAIN_REQUIRE_AUTH") or "").lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if args.host not in {"127.0.0.1", "::1", "localhost"} and not require_auth:
        parser.error(
            "Non-loopback binding requires SCHEMA_BRAIN_REQUIRE_AUTH=1 and configured identities"
        )
    DEFAULT_LEARNING_SERVICE.reconcile_stranded_approvals(
        actor="startup-reconciler",
        limit=1000,
    )
    # Assess every latest active row before accepting traffic. Ungoverned
    # legacy rows remain available for append-only remediation and health
    # reporting, but are excluded from runtime capability admission.
    DEFAULT_LEARNING_SERVICE.capability_admission_report(limit=5000)
    metrics_prewarm = DEFAULT_LEARNING_SERVICE.refresh_metrics_snapshot()
    if metrics_prewarm.get("status") != "refreshed":
        raise RuntimeError("Learning metrics prewarm was not stable")
    server = ThreadingHTTPServer((args.host, args.port), StudioHandler)
    server.quiet = args.quiet
    server.daemon_threads = False
    server.block_on_close = True
    prior_sigterm_handler = install_sigterm_shutdown(server)
    try:
        threading.Thread(
            target=lambda: collect_production_baseline(run_query),
            name="workload-baseline-refresh",
            daemon=True,
        ).start()
        DRIFT_MONITOR.start()
        SLA_RECONCILER.start()
        host, port = server.server_address
        print(
            json.dumps(
                {
                    "status": "listening",
                    "url": f"https://example.invalid}:{port}",
                    "liveness": "/livez",
                    "readiness": "/readyz",
                },
                sort_keys=True,
            ),
            flush=True,
        )
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        SLA_RECONCILER.stop()
        DRIFT_MONITOR.stop()
        server.server_close()
        if prior_sigterm_handler is not None:
            signal.signal(signal.SIGTERM, prior_sigterm_handler)


if __name__ == "__main__":
    main()
