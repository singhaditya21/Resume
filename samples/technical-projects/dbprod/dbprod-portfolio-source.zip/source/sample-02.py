#!/usr/bin/env python3
"""Typed semantic intermediate representation and deterministic compiler gates."""

from __future__ import annotations

import dataclasses
import datetime as dt
import enum
import re
from typing import Any, Callable

from planner_events import (
    emit_planner_event,
    emit_semantic_graph_delta,
    emit_sql_clause_events,
    emit_sql_draft_completed,
)
from runtime_config import PRODUCTION_CONTEXT, TENANT_OWNER_ID, enforce_owner_id
from security_policy import owner_scope_decision


class HistoryMode(str, enum.Enum):
    CURRENT = "current"
    LATEST = "latest"
    AS_OF = "as_of"
    FULL = "full"


class Cardinality(str, enum.Enum):
    ONE_TO_ONE = "1:1"
    MANY_TO_ONE = "N:1"
    ONE_TO_MANY = "1:N"
    MANY_TO_MANY = "N:M"
    AGGREGATED_TO_ONE = "N:1_aggregated"


@dataclasses.dataclass(frozen=True)
class SemanticObject:
    name: str
    provider: str
    itemtype: int | None = None
    physical_sources: tuple[str, ...] = ()


@dataclasses.dataclass(frozen=True)
class Measure:
    name: str
    aggregation: str = "none"
    value_type: str = "unknown"
    source_expression: str | None = None


@dataclasses.dataclass(frozen=True)
class Dimension:
    name: str
    value_type: str = "text"
    source_expression: str | None = None


@dataclasses.dataclass(frozen=True)
class Filter:
    field: str
    operator: str
    value: Any
    value_type: str
    source: str = "question"
    mandatory: bool = False


@dataclasses.dataclass(frozen=True)
class TimeRange:
    field: str
    start: str | None = None
    end_exclusive: str | None = None
    timezone: str = "Asia/Kolkata"
    interpretation: str = "event_time"


@dataclasses.dataclass(frozen=True)
class Grain:
    name: str
    key_fields: tuple[str, ...]
    description: str


@dataclasses.dataclass(frozen=True)
class Join:
    left: str
    right: str
    cardinality: Cardinality
    condition: str
    purpose: str
    required: bool = True
    preaggregated: bool = False
    preserves_output_grain: bool = True


@dataclasses.dataclass(frozen=True)
class SecurityScope:
    owner_id: int = TENANT_OWNER_ID
    requesting_principal: str = "local_owner2_analyst"
    business_role: str = "owner2_read_only_analytics"
    database_role: str = "redash_read_only"
    field_visibility_policy: str = "REDACTED_OPAQUE_VALUE"
    row_limit: int = PRODUCTION_CONTEXT.result_row_limit
    statement_timeout_seconds: int = PRODUCTION_CONTEXT.timeout_seconds
    pii_policy: str = PRODUCTION_CONTEXT.pii_policy
    audit_required: bool = True


@dataclasses.dataclass(frozen=True)
class SemanticPlan:
    intent: str
    question: str
    object: SemanticObject
    measures: tuple[Measure, ...]
    dimensions: tuple[Dimension, ...]
    filters: tuple[Filter, ...]
    time_range: TimeRange | None
    grain: Grain
    history_mode: HistoryMode
    security: SecurityScope
    joins: tuple[Join, ...]
    parameters: dict[str, Any]
    provider_kind: str
    version: str = "semantic-ir/v1"

    def as_dict(self):
        def normalize(value):
            if dataclasses.is_dataclass(value):
                return {field.name: normalize(getattr(value, field.name)) for field in dataclasses.fields(value)}
            if isinstance(value, enum.Enum):
                return value.value
            if isinstance(value, (dt.date, dt.datetime)):
                return value.isoformat()
            if isinstance(value, tuple):
                return [normalize(item) for item in value]
            if isinstance(value, list):
                return [normalize(item) for item in value]
            if isinstance(value, dict):
                return {str(key): normalize(item) for key, item in value.items()}
            return value

        return normalize(self)


def _semantic_slug(value):
    return re.sub(r"[^a-z0-9]+", "-", str(value or "item").lower()).strip("-") or "item"


def _semantic_node_id(kind, value, index=None):
    parts = ["semantic", _semantic_slug(kind)]
    if index is not None:
        parts.append(str(index))
    parts.append(_semantic_slug(value))
    return ":".join(parts)


def _semantic_edge_id(source, relation, target):
    return f"semantic:edge:{_semantic_slug(source)}:{_semantic_slug(relation)}:{_semantic_slug(target)}"


def _node_change(operation, node_id, status, **payload):
    return {
        "operation": operation,
        "id": node_id,
        "status": status,
        **payload,
    }


def _edge_change(operation, source, target, relation, status, **payload):
    return {
        "operation": operation,
        "id": _semantic_edge_id(source, relation, target),
        "source": source,
        "target": target,
        "relation": relation,
        "status": status,
        **payload,
    }


def _semantic_graph_components(plan, status="tentative"):
    request_id = "semantic:request"
    plan_id = "semantic:plan"
    nodes = [
        _node_change("add", request_id, status, kind="question"),
        _node_change(
            "add",
            plan_id,
            status,
            label=plan.intent,
            kind="semantic_plan",
            detail=f"{plan.provider_kind} semantic plan",
        ),
    ]
    edges = [_edge_change("add", request_id, plan_id, "plans", status)]

    object_id = _semantic_node_id("object", plan.object.name)
    nodes.append(
        _node_change(
            "add",
            object_id,
            status,
            label=plan.object.name,
            kind="lowcode_object",
            detail=f"Provider: {plan.object.provider}",
        )
    )
    edges.append(_edge_change("add", plan_id, object_id, "queries", status))

    for index, measure in enumerate(plan.measures):
        node_id = _semantic_node_id("measure", measure.name, index)
        nodes.append(
            _node_change(
                "add",
                node_id,
                status,
                label=measure.name,
                kind="measure",
                detail=f"{measure.aggregation} · {measure.value_type}",
            )
        )
        edges.append(_edge_change("add", plan_id, node_id, "measures", status))

    for index, dimension in enumerate(plan.dimensions):
        node_id = _semantic_node_id("dimension", dimension.name, index)
        nodes.append(
            _node_change(
                "add",
                node_id,
                status,
                label=dimension.name,
                kind="dimension",
                detail=dimension.value_type,
            )
        )
        edges.append(_edge_change("add", plan_id, node_id, "groups_by", status))

    for index, filter_row in enumerate(plan.filters):
        node_id = _semantic_node_id("filter", filter_row.field, index)
        nodes.append(
            _node_change(
                "add",
                node_id,
                status,
                label=f"{filter_row.field} {filter_row.operator}",
                kind="filter",
                detail=(
                    f"{filter_row.value_type} · {filter_row.source}"
                    + (" · mandatory" if filter_row.mandatory else "")
                ),
            )
        )
        edges.append(_edge_change("add", plan_id, node_id, "filters", status))

    if plan.time_range is not None:
        node_id = _semantic_node_id("time", plan.time_range.field)
        nodes.append(
            _node_change(
                "add",
                node_id,
                status,
                label=plan.time_range.field,
                kind="history",
                detail=f"{plan.time_range.interpretation} · {plan.time_range.timezone}",
            )
        )
        edges.append(_edge_change("add", plan_id, node_id, "constrains_time", status))

    grain_id = _semantic_node_id("grain", plan.grain.name)
    nodes.append(
        _node_change(
            "add",
            grain_id,
            status,
            label=plan.grain.name,
            kind="grain",
            detail="Keys: " + ", ".join(plan.grain.key_fields),
        )
    )
    edges.append(_edge_change("add", plan_id, grain_id, "has_grain", status))

    history_id = _semantic_node_id("history", plan.history_mode.value)
    nodes.append(
        _node_change(
            "add",
            history_id,
            status,
            label=plan.history_mode.value,
            kind="history",
            detail="History interpretation",
        )
    )
    edges.append(_edge_change("add", plan_id, history_id, "uses_history", status))

    security_id = _semantic_node_id("security", "owner-scope")
    nodes.append(
        _node_change(
            "add",
            security_id,
            status,
            label="Owner scope",
            kind="security",
            detail=f"ownerid {plan.security.owner_id} · row limit {plan.security.row_limit}",
        )
    )
    edges.append(_edge_change("add", plan_id, security_id, "secured_by", status))

    for index, join in enumerate(plan.joins):
        node_id = _semantic_node_id("join", f"{join.left}-{join.right}", index)
        nodes.append(
            _node_change(
                "add",
                node_id,
                status,
                label=f"{join.left} → {join.right}",
                kind="join",
                detail=f"{join.cardinality.value} · {join.purpose}",
            )
        )
        edges.append(_edge_change("add", plan_id, node_id, "joins", status))

    return nodes, edges


def _emit_semantic_plan_graph(plan):
    """Grow the proposed graph in small deltas so SSE clients can render it live."""
    nodes, edges = _semantic_graph_components(plan, status="tentative")
    edge_by_target = {edge["target"]: edge for edge in edges}
    initial_ids = {"semantic:request", "semantic:plan"}
    emit_semantic_graph_delta(
        nodes=[node for node in nodes if node["id"] in initial_ids],
        edges=[edge_by_target["semantic:plan"]],
        status="tentative",
    )
    for node in nodes:
        if node["id"] in initial_ids:
            continue
        emit_semantic_graph_delta(
            nodes=[node],
            edges=[edge_by_target[node["id"]]],
            status="tentative",
        )


def _emit_semantic_plan_resolution(plan, status):
    nodes, edges = _semantic_graph_components(plan, status=status)
    emit_semantic_graph_delta(
        nodes=[
            _node_change("update", node["id"], status)
            for node in nodes
        ],
        edges=[
            {
                "operation": "update",
                "id": edge["id"],
                "source": edge["source"],
                "target": edge["target"],
                "relation": edge["relation"],
                "status": status,
            }
            for edge in edges
        ],
        status=status,
    )


def _typed_parameter_filters(parameters):
    filters = []
    for name, value in parameters.items():
        if value is None:
            continue
        if isinstance(value, dict) and {"start_date", "end_date"} <= set(value):
            continue
        if isinstance(value, bool):
            value_type = "boolean"
        elif isinstance(value, int):
            value_type = "integer"
        elif isinstance(value, (dt.date, dt.datetime)):
            value_type = "date"
        else:
            value_type = "text"
        filters.append(Filter(field=name, operator="=", value=value, value_type=value_type))
    filters.append(
        Filter(
            field="ownerid",
            operator="=",
            value=TENANT_OWNER_ID,
            value_type="integer",
            source="security_scope",
            mandatory=True,
        )
    )
    return tuple(filters)


def build_report_semantic_plan(question, contract, parameters):
    semantic = contract.get("semantic") or {}
    time_range = None
    if parameters.get("start_date") is not None:
        time_range = TimeRange(
            field=semantic.get("time_field", "event_date"),
            start=str(parameters["start_date"]),
            interpretation=semantic.get("time_interpretation", "event_time"),
        )
    elif isinstance(parameters.get("fiscal_year"), dict):
        fiscal = parameters["fiscal_year"]
        time_range = TimeRange(
            field=semantic.get("time_field", "fiscal_event_date"),
            start=str(fiscal.get("start_date")),
            end_exclusive=str(fiscal.get("end_date")),
            interpretation="financial_year_april_to_march",
        )

    joins = tuple(
        Join(
            left=row["left"],
            right=row["right"],
            cardinality=Cardinality(row["cardinality"]),
            condition=row.get("condition", "declared_provider_contract"),
            purpose=row.get("purpose", "dimension_resolution"),
            required=row.get("required", True),
            preaggregated=row.get("preaggregated", False),
            preserves_output_grain=row.get("preserves_output_grain", True),
        )
        for row in semantic.get("joins") or []
    )
    plan = SemanticPlan(
        intent=contract["intent"],
        question=question,
        object=SemanticObject(
            name=semantic.get("object", contract["intent"]),
            provider=contract["provider"],
            itemtype=semantic.get("itemtype"),
            physical_sources=tuple(semantic.get("physical_sources") or ()),
        ),
        measures=tuple(
            Measure(
                name=row["name"] if isinstance(row, dict) else str(row),
                aggregation=row.get("aggregation", "none") if isinstance(row, dict) else "none",
                value_type=row.get("value_type", "unknown") if isinstance(row, dict) else "unknown",
                source_expression=row.get("source_expression") if isinstance(row, dict) else None,
            )
            for row in semantic.get("measures") or []
        ),
        dimensions=tuple(
            Dimension(
                name=row["name"] if isinstance(row, dict) else str(row),
                value_type=row.get("value_type", "text") if isinstance(row, dict) else "text",
                source_expression=row.get("source_expression") if isinstance(row, dict) else None,
            )
            for row in semantic.get("dimensions") or contract.get("expected_columns") or []
        ),
        filters=_typed_parameter_filters(parameters),
        time_range=time_range,
        grain=Grain(
            name=semantic.get("grain", "provider_row"),
            key_fields=tuple(semantic.get("grain_keys") or ("provider_row",)),
            description=semantic.get("grain_description", "One row per provider result row."),
        ),
        history_mode=HistoryMode(semantic.get("history_mode", "current")),
        security=SecurityScope(),
        joins=joins,
        parameters=dict(parameters),
        provider_kind=contract["provider_kind"],
    )
    return plan


def validate_semantic_plan(plan):
    errors = []
    warnings = []
    owner_id = enforce_owner_id(plan.security.owner_id)
    owner_filters = [row for row in plan.filters if row.field.lower().endswith("ownerid")]
    if not any(row.mandatory and int(row.value) == owner_id for row in owner_filters):
        errors.append("mandatory ownerid security filter is missing")
    if not plan.grain.key_fields:
        errors.append("output grain has no key fields")

    join_proofs = []
    for join_index, join in enumerate(plan.joins):
        status = "proved"
        reason = "join preserves the declared output grain"
        if join.cardinality == Cardinality.MANY_TO_MANY:
            status = "rejected"
            reason = "N:M joins require an explicit bridge and aggregation contract"
            errors.append(f"unsafe many-to-many join: {join.left} -> {join.right}")
        elif join.cardinality == Cardinality.ONE_TO_MANY and not (
            join.preaggregated or join.preserves_output_grain
        ):
            status = "rejected"
            reason = "1:N join can multiply output rows without aggregation"
            errors.append(f"grain-multiplying join: {join.left} -> {join.right}")
        elif join.cardinality == Cardinality.ONE_TO_MANY:
            reason = "1:N detail relationship is the declared output grain"
        elif join.cardinality == Cardinality.AGGREGATED_TO_ONE:
            reason = "child rows are aggregated to one row per parent before the join"
        join_proofs.append(
            {
                "left": join.left,
                "right": join.right,
                "cardinality": join.cardinality.value,
                "status": status,
                "reason": reason,
                "condition": join.condition,
            }
        )
        emit_planner_event(
            "join_considered",
            status="rejected" if status == "rejected" else "confirmed",
            left=join.left,
            right=join.right,
            cardinality=join.cardinality.value,
            reason=reason,
        )
        join_status = "rejected" if status == "rejected" else "confirmed"
        join_id = _semantic_node_id("join", f"{join.left}-{join.right}", join_index)
        emit_semantic_graph_delta(
            nodes=[_node_change("update", join_id, join_status)],
            edges=[
                _edge_change(
                    "update",
                    "semantic:plan",
                    join_id,
                    "joins",
                    join_status,
                )
            ],
            status=join_status,
        )

    report = {
        "status": "passed" if not errors else "failed",
        "owner_id": owner_id,
        "grain": dataclasses.asdict(plan.grain),
        "join_proofs": join_proofs,
        "errors": errors,
        "warnings": warnings,
    }
    emit_planner_event(
        "grain_verified",
        status="confirmed" if not errors else "rejected",
        grain=plan.grain.name,
        keys=list(plan.grain.key_fields),
        join_count=len(join_proofs),
        errors=errors,
    )
    grain_status = "confirmed" if not errors else "rejected"
    grain_id = _semantic_node_id("grain", plan.grain.name)
    emit_semantic_graph_delta(
        nodes=[_node_change("update", grain_id, grain_status)],
        edges=[
            _edge_change(
                "update",
                "semantic:plan",
                grain_id,
                "has_grain",
                grain_status,
            )
        ],
        status=grain_status,
    )
    return report


def validate_owner_scope_sql(sql, owner_id=TENANT_OWNER_ID):
    """Owner-scope check for compiled SQL.

    Delegates to the single authoritative proof in ``security_policy`` (a
    deterministic lexer that keeps literals opaque, requires a positive literal
    ``ownerid = 2`` WHERE predicate, and proves every relation / set-operation
    branch is scoped) instead of re-implementing owner detection here.  This
    keeps the compiler gate and the execution gate on one shared implementation.
    """
    owner_id = enforce_owner_id(owner_id)
    report = owner_scope_decision(sql, owner_id)
    return {
        "status": report["status"],
        "required_owner_id": report.get("required_owner_id", owner_id),
        "observed_owner_ids": report.get("observed_owner_ids", []),
        "errors": report["errors"],
    }


def compile_provider_plan(plan: SemanticPlan, builder: Callable[[dict[str, Any]], str]):
    _emit_semantic_plan_graph(plan)
    validation = validate_semantic_plan(plan)
    if validation["status"] != "passed":
        _emit_semantic_plan_resolution(plan, "rejected")
        raise ValueError("Semantic plan failed validation: " + "; ".join(validation["errors"]))
    emit_planner_event(
        "history_mode_selected",
        history_mode=plan.history_mode.value,
        object=plan.object.name,
    )
    try:
        sql = builder(plan.parameters)
    except Exception as exc:
        _emit_semantic_plan_resolution(plan, "rejected")
        emit_planner_event(
            "sql_compilation_failed",
            status="rejected",
            provider=plan.object.provider,
            error_type=type(exc).__name__,
        )
        raise
    fragments = emit_sql_clause_events(sql, provider=plan.object.provider)
    owner_validation = validate_owner_scope_sql(sql, plan.security.owner_id)
    if owner_validation["status"] != "passed":
        emit_sql_draft_completed(
            sql,
            status="rejected",
            provider=plan.object.provider,
            fragments=fragments,
            validation="owner_scope_failed",
        )
        _emit_semantic_plan_resolution(plan, "rejected")
        raise ValueError("Compiled SQL failed owner scope validation: " + "; ".join(owner_validation["errors"]))
    emit_sql_draft_completed(
        sql,
        status="confirmed",
        provider=plan.object.provider,
        fragments=fragments,
        validation="owner_scope_passed",
    )
    _emit_semantic_plan_resolution(plan, "confirmed")
    return sql, {**validation, "owner_scope": owner_validation}


def infer_result_semantic_ir(question, result):
    """Create a typed envelope for legacy metadata paths that predate the IR compiler."""
    resolved = result.get("resolved_intent") or {}
    intent = resolved.get("intent") or resolved.get("matched_intent") or result.get("status") or "unresolved"
    sql = result.get("sql") or ""
    relations = tuple(
        sorted(
            set(
                match.group(1).lower()
                for match in re.finditer(
                    r"\b(?:from|join)\s+([a-z_][a-z0-9_$]*\.[a-z_][a-z0-9_$]*)",
                    sql,
                    re.I,
                )
            )
        )
    )
    history_mode = resolved.get("history_mode") or "current"
    if history_mode not in {mode.value for mode in HistoryMode}:
        history_mode = "current"
    grain_name = resolved.get("grain") or ("grouped_result" if "group by" in sql.lower() else "provider_row")
    return {
        "version": "semantic-ir/v1-legacy-envelope",
        "intent": intent,
        "question": question,
        "object": {
            "name": resolved.get("entity") or intent,
            "provider": resolved.get("provider") or "metadata_resolver",
            "physical_sources": list(relations),
        },
        "measures": [],
        "dimensions": [],
        "filters": [
            {
                "field": "ownerid",
                "operator": "=",
                "value": TENANT_OWNER_ID,
                "value_type": "integer",
                "source": "security_scope",
                "mandatory": True,
            }
        ],
        "time_range": None,
        "grain": {
            "name": grain_name,
            "key_fields": resolved.get("group_expression") and [resolved.get("group_expression")] or ["provider_row"],
            "description": "Legacy metadata plan wrapped in the typed semantic envelope.",
        },
        "history_mode": history_mode,
        "security": dataclasses.asdict(SecurityScope()),
        "joins": [],
        "parameters": resolved.get("parameters") or {},
        "provider_kind": resolved.get("provider_kind") or "metadata_resolver",
    }
