#!/usr/bin/env python3
"""Validate a private, privacy-reviewed owner-2 gold-question dataset."""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import hmac
import json
import math
import pathlib
import re


ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "schemas/gold-question.schema.json"
SCHEMA_BYTES = SCHEMA_PATH.read_bytes()
SCHEMA = json.loads(SCHEMA_BYTES)
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\d ()-]{7,}\d)(?!\d)")
SENSITIVE_FILTER_RE = re.compile(
    r"(?:^|_)(?:address|aadhaar|birth|dob|email|mobile|name|passport|phone|ssn)(?:_|$)",
    re.I,
)
OWNER_ALIASES = {"ownerid", "tenant_owner_id"}
SUPPORTED_SCHEMA_KEYWORDS = {
    "$id",
    "$schema",
    "additionalProperties",
    "anyOf",
    "const",
    "enum",
    "format",
    "items",
    "maxItems",
    "maxLength",
    "minItems",
    "minLength",
    "not",
    "oneOf",
    "pattern",
    "properties",
    "required",
    "title",
    "type",
    "uniqueItems",
}


def _assert_supported_schema(schema, path="schema"):
    unsupported = sorted(set(schema) - SUPPORTED_SCHEMA_KEYWORDS)
    if unsupported:
        raise RuntimeError(
            f"{path} uses unsupported JSON-Schema keywords: {', '.join(unsupported)}"
        )
    for key, child in (schema.get("properties") or {}).items():
        _assert_supported_schema(child, f"{path}.properties.{key}")
    if isinstance(schema.get("items"), dict):
        _assert_supported_schema(schema["items"], f"{path}.items")
    for keyword in ("anyOf", "oneOf"):
        for index, child in enumerate(schema.get(keyword) or []):
            _assert_supported_schema(child, f"{path}.{keyword}[{index}]")
    if isinstance(schema.get("not"), dict):
        _assert_supported_schema(schema["not"], f"{path}.not")


_assert_supported_schema(SCHEMA)


def _json_type_matches(value, expected):
    return {
        "object": lambda: isinstance(value, dict),
        "array": lambda: isinstance(value, list),
        "string": lambda: isinstance(value, str),
        "integer": lambda: type(value) is int,
        "number": lambda: type(value) in {int, float} and math.isfinite(value),
        "boolean": lambda: type(value) is bool,
        "null": lambda: value is None,
    }.get(expected, lambda: False)()


def _same_json_value(left, right):
    if type(left) is bool or type(right) is bool:
        return type(left) is type(right) and left == right
    return left == right


def _aware_datetime(value):
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed


def _schema_errors(value, schema, path="row"):
    """Evaluate the JSON-Schema keywords used by the checked-in contract."""
    errors = []
    declared_type = schema.get("type")
    if declared_type is not None:
        types = declared_type if isinstance(declared_type, list) else [declared_type]
        if not any(_json_type_matches(value, expected) for expected in types):
            return [f"{path}: type is invalid"]

    if "const" in schema and not _same_json_value(value, schema["const"]):
        errors.append(f"{path}: value is not the required constant")
    if "enum" in schema and not any(_same_json_value(value, item) for item in schema["enum"]):
        errors.append(f"{path}: value is outside the allowlist")

    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            errors.append(f"{path}: value is too short")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            errors.append(f"{path}: value is too long")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errors.append(f"{path}: format is invalid")
        if schema.get("format") == "date-time" and _aware_datetime(value) is None:
            errors.append(f"{path}: must be an ISO date-time with a timezone")

    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0):
            errors.append(f"{path}: contains too few items")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            errors.append(f"{path}: contains too many items")
        if schema.get("uniqueItems"):
            encoded = [json.dumps(item, sort_keys=True, separators=(",", ":")) for item in value]
            if len(encoded) != len(set(encoded)):
                errors.append(f"{path}: items must be unique")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                errors.extend(_schema_errors(item, item_schema, f"{path}[{index}]"))

    if isinstance(value, dict):
        required = schema.get("required") or []
        missing = sorted(set(required) - set(value))
        if missing:
            errors.append(f"{path}: missing required fields {', '.join(missing)}")
        properties = schema.get("properties") or {}
        for key, child in properties.items():
            if key in value:
                errors.extend(_schema_errors(value[key], child, f"{path}.{key}"))
        if schema.get("additionalProperties") is False:
            unknown = sorted(set(value) - set(properties))
            if unknown:
                errors.append(f"{path}: contains fields outside the allowlist")

    if "not" in schema and not _schema_errors(value, schema["not"], path):
        errors.append(f"{path}: matches a forbidden schema")
    if "oneOf" in schema:
        matches = sum(not _schema_errors(value, branch, path) for branch in schema["oneOf"])
        if matches != 1:
            errors.append(f"{path}: must match exactly one approved case shape")
    if "anyOf" in schema:
        if not any(not _schema_errors(value, branch, path) for branch in schema["anyOf"]):
            errors.append(f"{path}: does not match an approved value shape")
    return errors


def _contains_direct_identifier(value):
    return isinstance(value, str) and bool(EMAIL_RE.search(value) or PHONE_RE.search(value))


def _future_timestamp(value):
    parsed = _aware_datetime(value)
    return bool(parsed and parsed > dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=5))


def _nested(mapping, *keys):
    value = mapping
    for key in keys:
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return value


def _review_content_provenance(row):
    stable = {
        key: copy.deepcopy(value)
        for key, value in row.items()
        if key not in {"admission", "privacy_review"}
    }
    anonymization = stable.get("anonymization")
    if isinstance(anonymization, dict):
        stable["anonymization"] = {
            key: copy.deepcopy(value)
            for key, value in anonymization.items()
            if key not in {"verification_status", "direct_identifiers_retained"}
        }
    payload = json.dumps(stable, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def validate_row(row: object, line_number: int) -> list[str]:
    prefix = f"line {line_number}"
    if not isinstance(row, dict):
        return [f"{prefix}: row must be an object"]
    errors = [f"{prefix}: {error}" for error in _schema_errors(row, SCHEMA)]

    filters = row.get("required_filters")
    if isinstance(filters, dict):
        aliases = sorted(OWNER_ALIASES.intersection(filters))
        if aliases:
            errors.append(f"{prefix}: required_filters contains forbidden owner aliases")
        if type(filters.get("owner_id")) is not int or filters.get("owner_id") != 2:
            errors.append(f"{prefix}: required_filters must contain exactly canonical owner_id=2")
        criteria = filters.get("criteria")
        if isinstance(criteria, list):
            fields = [
                item.get("field")
                for item in criteria
                if isinstance(item, dict) and isinstance(item.get("field"), str)
            ]
            if len(fields) != len(set(fields)):
                errors.append(f"{prefix}: required filter criteria fields must be unique")
            if any(field == "owner_id" or field in OWNER_ALIASES for field in fields):
                errors.append(f"{prefix}: owner scope cannot be repeated or aliased in criteria")
            if any(
                isinstance(field, str) and SENSITIVE_FILTER_RE.search(field)
                for field in fields
            ):
                errors.append(f"{prefix}: required filter field may carry a direct identifier")
            if any(
                isinstance(item, dict) and _contains_direct_identifier(item.get("value"))
                for item in criteria
            ):
                errors.append(f"{prefix}: required filter value contains a direct identifier")

    for field in ("department", "persona", "question"):
        if _contains_direct_identifier(row.get(field)):
            errors.append(f"{prefix}: {field} contains a direct email or phone identifier")

    anonymization = row.get("anonymization")
    privacy_review = row.get("privacy_review")
    if isinstance(anonymization, dict) and isinstance(privacy_review, dict):
        provenance = str(privacy_review.get("content_provenance") or "")
        recomputed = _review_content_provenance(row)
        if not hmac.compare_digest(provenance.encode("utf-8"), recomputed.encode("utf-8")):
            errors.append(f"{prefix}: privacy review is not bound to the reviewed case content")

    timestamps = [
        ("privacy_review.dlp.scanned_at", _nested(row, "privacy_review", "dlp", "scanned_at")),
        (
            "privacy_review.manual.reviewed_at",
            _nested(row, "privacy_review", "manual", "reviewed_at"),
        ),
        ("admission.promoted_at", _nested(row, "admission", "promoted_at")),
        ("approval.approved_at", _nested(row, "approval", "approved_at")),
    ]
    for label, value in timestamps:
        if _future_timestamp(value):
            errors.append(f"{prefix}: {label} cannot be in the future")
    scanned_at = _aware_datetime(_nested(row, "privacy_review", "dlp", "scanned_at"))
    reviewed_at = _aware_datetime(_nested(row, "privacy_review", "manual", "reviewed_at"))
    promoted_at = _aware_datetime(_nested(row, "admission", "promoted_at"))
    if scanned_at and reviewed_at and reviewed_at < scanned_at:
        errors.append(f"{prefix}: manual review cannot predate the DLP scan")
    if reviewed_at and promoted_at and promoted_at < reviewed_at:
        errors.append(f"{prefix}: admission cannot predate manual review")

    artifact = row.get("approved_sql_artifact")
    if artifact:
        path = pathlib.PurePosixPath(str(artifact).replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts or not path.parts:
            errors.append(f"{prefix}: approved_sql_artifact must be a safe relative path")
    return errors


def validate_dataset(path: pathlib.Path) -> dict:
    errors = []
    rows = []
    ids = set()
    provenance_tokens = REDACTED_SECRET
    normalized_questions = set()
    with pathlib.Path(path).open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                errors.append(f"line {line_number}: invalid JSON")
                continue
            errors.extend(validate_row(row, line_number))
            identifier = str(row.get("id") or "") if isinstance(row, dict) else ""
            provenance = (
                str(_nested(row, "anonymization", "provenance_token") or "")
                if isinstance(row, dict)
                else ""
            )
            normalized_question = (
                re.sub(r"\s+", " ", str(row.get("question") or "").strip().casefold())
                if isinstance(row, dict)
                else ""
            )
            if identifier in ids:
                errors.append(f"line {line_number}: duplicate id")
            if provenance and provenance in provenance_tokens:
                errors.append(f"line {line_number}: duplicate question provenance")
            if normalized_question and normalized_question in normalized_questions:
                errors.append(f"line {line_number}: duplicate normalized question")
            ids.add(identifier)
            provenance_tokens.add(provenance)
            normalized_questions.add(normalized_question)
            rows.append(row)
    if not rows:
        errors.append("dataset contains no questions")
    return {
        "contract_version": "dbprod-gold-questions/v2",
        "schema_sha256": hashlib.sha256(SCHEMA_BYTES).hexdigest(),
        "status": "passed" if not errors else "failed",
        "question_count": len(rows),
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset")
    args = parser.parse_args()
    report = validate_dataset(pathlib.Path(args.dataset))
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
