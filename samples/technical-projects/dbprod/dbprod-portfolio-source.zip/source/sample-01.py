#!/usr/bin/env python3
import argparse
import difflib
import json
import pathlib
import re
from collections import defaultdict

import joblib
import numpy as np
from scipy import sparse

from build_neural_index import (
    EMBEDDING_DOCUMENT_BINDING,
    INDEX_DOCUMENT_BINDING,
    embedding_document_provenance,
    index_document_provenance,
)
from runtime_paths import resolve_runtime_paths


RUNTIME_PATHS = resolve_runtime_paths()
DEFAULT_INDEX_DIR = RUNTIME_PATHS.artifact_path(
    "REDACTED_OPAQUE_VALUE"
)

DOMAIN_EXPANSIONS = {
    "account": "PORTFOLIO_REDACTED",
    "accounts": "PORTFOLIO_REDACTED",
    "customer": "PORTFOLIO_REDACTED",
    "client": "PORTFOLIO_REDACTED",
    "case": "case cases ticket complaint complaints issue incident service request grievance",
    "cases": "case cases ticket complaint complaints issue incident service request grievance",
    "ticket": "ticket case cases complaint issue service request",
    "complaint": "complaint complaints case cases ticket grievance",
    "issue": "issue case cases ticket complaint",
    "lead": "lead leads prospect enquiry inquiry",
    "prospect": "prospect lead leads",
    "opportunity": "opportunity opportunities deal pipeline sales proposal revenue",
    "opportunities": "opportunity opportunities deal pipeline sales proposal revenue",
    "deal": "deal opportunity opportunities pipeline value revenue",
    "pipeline": "pipeline opportunity opportunities deal stage",
    "activity": "activity activities task call meeting event appointment followup follow-up interaction",
    "task": "task activity followup action",
    "call": "call activity interaction",
    "meeting": "meeting event activity appointment",
    "owner": "PORTFOLIO_REDACTED",
    "assignee": "assignee owner assignedto current owner",
    "branch": "branch region territory zone geography",
    "region": "region branch territory zone geography",
    "segment": "segment segmentation customer segment account segment",
    "status": "status statuscode statuscodeid stage state open closed active inactive",
    "stage": "stage status pipeline process",
    "open": "open active pending not closed status",
    "closed": "closed resolved completed inactive status",
}

DOMAIN_TERMS = sorted(
    {
        term
        for key, expansion in DOMAIN_EXPANSIONS.items()
        for term in (key + " " + expansion).replace("-", " ").split()
    }
)

# Absolute evidence gates are evaluated before relative score normalization.
# A normalized top score is only meaningful for ranking accepted evidence; it
# must never turn an unrelated best-of-a-bad-set match into a confident hit.
LEXICAL_EVIDENCE_FLOOR = 0.20
DENSE_EVIDENCE_FLOOR = 0.25


def has_sufficient_retrieval_evidence(original_lexical_score=0.0, dense_score=None):
    return bool(
        float(original_lexical_score or 0.0) >= LEXICAL_EVIDENCE_FLOOR
        or (
            dense_score is not None
            and float(dense_score) >= DENSE_EVIDENCE_FLOOR
        )
    )


def result_has_sufficient_evidence(result):
    if "evidence_accepted" in result:
        return result.get("evidence_accepted") is True
    return has_sufficient_retrieval_evidence(
        result.get("original_lexical_score"),
        result.get("dense_score"),
    )


def iter_jsonl(path):
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def clean(value):
    if value is None:
        return ""
    value = str(value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def expand_query(query):
    tokens = re.findall(r"[a-zA-Z0-9]+", query.lower())
    additions = []
    for token in tokens:
        if len(token) < 4:
            continue
        if token in DOMAIN_EXPANSIONS:
            additions.append(DOMAIN_EXPANSIONS[token])
            continue
        # Correct likely near-miss CRM terms: custmr -> customer, tckt -> ticket,
        # opprtunity -> opportunity, brnch -> branch, ownr -> owner, etc.
        matches = difflib.get_close_matches(token, DOMAIN_TERMS, n=2, cutoff=0.66)
        for match in matches:
            additions.append(match)
            if match in DOMAIN_EXPANSIONS:
                additions.append(DOMAIN_EXPANSIONS[match])
    if not additions:
        return query
    return f"{query} {' '.join(additions)}"


def top_indices(scores, limit):
    if scores.size == 0 or limit <= 0:
        return np.array([], dtype=np.int64)
    limit = min(limit, scores.size)
    idx = np.argpartition(scores, -limit)[-limit:]
    return idx[np.argsort(scores[idx])[::-1]]


def minmax(scores):
    scores = np.asarray(scores, dtype=np.float32)
    if scores.size == 0:
        return scores
    lo = float(scores.min())
    hi = float(scores.max())
    if hi - lo < 1e-9:
        return np.zeros_like(scores)
    return (scores - lo) / (hi - lo)


class SemanticSearch:
    def __init__(
        self,
        index_dir=DEFAULT_INDEX_DIR,
        model_name=None,
        *,
        local_files_only=False,
    ):
        self.index_dir = pathlib.Path(index_dir)
        self.meta = json.loads((self.index_dir / "index_meta.json").read_text(encoding="utf-8"))
        documents_path = self.index_dir / "documents.jsonl"
        self.documents = list(iter_jsonl(documents_path))
        if self.meta.get("index_document_binding") != INDEX_DOCUMENT_BINDING:
            raise RuntimeError("Index document binding is missing or unsupported")
        try:
            observed_index_provenance = index_document_provenance(
                documents_path,
                self.documents,
            )
        except ValueError as exc:
            raise RuntimeError(f"Index document IDs are invalid: {exc}") from exc
        for key, observed in observed_index_provenance.items():
            if self.meta.get(key) != observed:
                raise RuntimeError(f"Index document provenance mismatch for {key}")
        self.vectorizer = joblib.load(self.index_dir / "lexical_vectorizer.joblib")
        self.lexical_matrix = sparse.load_npz(self.index_dir / "lexical_matrix.npz")
        if self.meta.get("doc_count") != len(self.documents):
            raise RuntimeError(
                "Index metadata/document count mismatch: "
                f"{self.meta.get('doc_count')} vs {len(self.documents)}"
            )
        if self.meta.get("lexical_shape") != list(self.lexical_matrix.shape):
            raise RuntimeError(
                "Lexical matrix metadata mismatch: "
                f"{self.meta.get('lexical_shape')} vs {list(self.lexical_matrix.shape)}"
            )
        if self.lexical_matrix.shape[0] != len(self.documents):
            raise RuntimeError(
                "Lexical matrix/document row mismatch: "
                f"{self.lexical_matrix.shape[0]} vs {len(self.documents)}"
            )
        self.embeddings = None
        self.model = None
        embedding_path = self.index_dir / "embeddings.npy"
        embedding_shape = self.meta.get("embedding_shape")
        embedding_model = self.meta.get("embedding_model")
        embedding_model_revision = self.meta.get("embedding_model_revision")
        dense_metadata = (
            embedding_model,
            embedding_model_revision,
            embedding_shape,
            self.meta.get("embedding_document_binding"),
            self.meta.get("embedding_document_sha256"),
            self.meta.get("embedding_document_ids_sha256"),
            self.meta.get("embedding_document_size"),
        )
        if not embedding_path.exists():
            if any(value is not None for value in dense_metadata):
                raise RuntimeError("Dense embedding metadata exists but embeddings.npy is missing")
            self.model_name = None
            return

        if not isinstance(embedding_model, str) or not embedding_model.strip():
            raise RuntimeError("Dense embedding model identifier is missing")
        if re.fullmatch(r"[0-9a-f]{40}", str(embedding_model_revision or "")) is None:
            raise RuntimeError("Dense embedding model revision is missing or not immutable")
        if model_name is not None and str(model_name) != embedding_model:
            raise RuntimeError("Dense query model override does not match the indexed model")
        if self.meta.get("embedding_document_binding") != EMBEDDING_DOCUMENT_BINDING:
            raise RuntimeError("Dense embedding document binding is missing or unsupported")
        try:
            observed_provenance = embedding_document_provenance(
                documents_path,
                self.documents,
            )
        except ValueError as exc:
            raise RuntimeError(f"Dense embedding document IDs are invalid: {exc}") from exc
        for key, observed in observed_provenance.items():
            if self.meta.get(key) != observed:
                raise RuntimeError(f"Dense embedding provenance mismatch for {key}")

        if (
            not isinstance(embedding_shape, list)
            or len(embedding_shape) != 2
            or any(isinstance(value, bool) or not isinstance(value, int) or value <= 0 for value in embedding_shape)
            or embedding_shape[0] != len(self.documents)
        ):
            raise RuntimeError("Dense embedding shape metadata is invalid")
        self.embeddings = np.load(embedding_path, mmap_mode="r")
        if list(self.embeddings.shape) != embedding_shape:
            raise RuntimeError(
                "Dense embedding file/metadata shape mismatch: "
                f"{list(self.embeddings.shape)} vs {embedding_shape}"
            )
        if self.embeddings.dtype != np.dtype(np.float32):
            raise RuntimeError("Dense embeddings must use float32")

        from sentence_transformers import SentenceTransformer

        self.model_name = embedding_model
        self.model = SentenceTransformer(
            self.model_name,
            revision=embedding_model_revision,
            local_files_only=local_files_only,
        )

    def search(self, query, limit=12, candidate_pool=250, kind=None, itemtype=None, ownerid=None, businessunitid=None):
        expanded_query = expand_query(query)
        lexical_query = self.vectorizer.transform([expanded_query])
        lexical_scores = (self.lexical_matrix @ lexical_query.T).toarray().ravel().astype(np.float32)
        if expanded_query == query:
            original_lexical_scores = lexical_scores
        else:
            original_query = self.vectorizer.transform([query])
            original_lexical_scores = (
                (self.lexical_matrix @ original_query.T)
                .toarray()
                .ravel()
                .astype(np.float32)
            )

        dense_scores = np.zeros(len(self.documents), dtype=np.float32)
        if self.model is not None and self.embeddings is not None:
            q_emb = self.model.encode(
                [expanded_query],
                normalize_embeddings=True,
                convert_to_numpy=True,
                show_progress_bar=False,
            ).astype(np.float32)[0]
            dense_scores = np.asarray(self.embeddings @ q_emb, dtype=np.float32)

        def allowed_by_filters(item):
            refs = item.get("refs") or {}
            payload = item.get("payload") or {}
            if itemtype is not None:
                item_itemtype = refs.get("itemtype", payload.get("itemtype", payload.get("source_itemtype")))
                if str(item_itemtype) != str(itemtype):
                    return False
            if ownerid is not None:
                item_ownerid = refs.get("ownerid", payload.get("ownerid"))
                if item_ownerid is not None and str(item_ownerid) not in {str(ownerid), "0"}:
                    return False
            if businessunitid is not None:
                item_businessunitid = refs.get("businessunitid", payload.get("businessunitid"))
                if item_businessunitid is not None and str(item_businessunitid) != str(businessunitid):
                    return False
            return True

        if kind or itemtype is not None or ownerid is not None or businessunitid is not None:
            kinds = {k.strip().lower() for k in kind.split(",") if k.strip()} if kind else set()
            allowed = np.array(
                [
                    idx
                    for idx, item in enumerate(self.documents)
                    if (not kinds or item.get("kind", "").lower() in kinds) and allowed_by_filters(item)
                ],
                dtype=np.int64,
            )
            if allowed.size == 0:
                return []
            lexical_allowed_top = allowed[top_indices(lexical_scores[allowed], candidate_pool)]
            if self.model is not None:
                dense_allowed_top = allowed[top_indices(dense_scores[allowed], candidate_pool)]
            else:
                dense_allowed_top = np.array([], dtype=np.int64)
            candidates = np.unique(np.concatenate([lexical_allowed_top, dense_allowed_top]))
        else:
            lexical_top = top_indices(lexical_scores, candidate_pool)
            dense_top = top_indices(dense_scores, candidate_pool) if self.model is not None else np.array([], dtype=np.int64)
            candidates = np.unique(np.concatenate([lexical_top, dense_top]))
        if candidates.size == 0:
            return []

        # Apply the production abstention policy to absolute, unnormalized
        # evidence. Query expansion may help ranking typo/paraphrase matches,
        # but cannot by itself authorize a result with no original-query or
        # dense support.
        evidence_mask = np.array(
            [
                has_sufficient_retrieval_evidence(
                    original_lexical_scores[int(idx)],
                    dense_scores[int(idx)] if self.model is not None else None,
                )
                for idx in candidates
            ],
            dtype=bool,
        )
        candidates = candidates[evidence_mask]
        if candidates.size == 0:
            return []

        lex_norm = minmax(lexical_scores[candidates])
        dense_norm = minmax(dense_scores[candidates]) if self.model is not None else np.zeros_like(lex_norm)
        combined = 0.58 * dense_norm + 0.42 * lex_norm if self.model is not None else lex_norm
        order = np.argsort(combined)[::-1][:limit]

        results = []
        for rank, local_idx in enumerate(order, start=1):
            idx = int(candidates[local_idx])
            item = self.documents[idx]
            results.append(
                {
                    "rank": rank,
                    "id": item.get("id"),
                    "score": round(float(combined[local_idx]), 4),
                    "dense_score": round(float(dense_scores[idx]), 4) if self.model is not None else None,
                    "lexical_score": round(float(lexical_scores[idx]), 4),
                    "original_lexical_score": round(
                        float(original_lexical_scores[idx]),
                        4,
                    ),
                    "evidence_accepted": True,
                    "kind": item.get("kind"),
                    "title": item.get("title"),
                    "model_advisory_safe": item.get("model_advisory_safe") is True,
                    "model_safe_label": item.get("model_safe_label"),
                    "refs": item.get("refs"),
                    "snippet": item.get("text", "")[:500],
                    "expanded_query": expanded_query if expanded_query != query else None,
                }
            )
        return results


def render_markdown(query, results):
    print(f"Query: {query}")
    print("")
    if not results:
        print("No matches.")
        return
    grouped = defaultdict(list)
    for row in results:
        grouped[row["kind"]].append(row)
    for kind, rows in grouped.items():
        print(f"## {kind}")
        for row in rows:
            refs = ", ".join(f"{k}={v}" for k, v in (row.get("refs") or {}).items() if v is not None)
            print(f"- {row['rank']}. score={row['score']} dense={row['dense_score']} lex={row['lexical_score']} `{row['title']}`")
            if refs:
                print(f"  refs: {refs}")
            print(f"  {row['snippet']}")
        print("")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("query", nargs="+")
    parser.add_argument("--index-dir", default=str(DEFAULT_INDEX_DIR))
    parser.add_argument("--limit", type=int, default=12)
    parser.add_argument("--candidate-pool", type=int, default=250)
    parser.add_argument("--kind", help="Comma-separated kind filter, for example entity,field,table")
    parser.add_argument("--itemtype", type=int, help="Restrict results to one low-code itemtype")
    parser.add_argument("--ownerid", type=int, help="Restrict owner-specific results, keeping owner 0 fallbacks")
    parser.add_argument("--businessunitid", type=int, help="Restrict layout-aware results to one business unit")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    query = " ".join(args.query)
    engine = SemanticSearch(args.index_dir)
    results = engine.search(
        query,
        limit=args.limit,
        candidate_pool=args.candidate_pool,
        kind=args.kind,
        itemtype=args.itemtype,
        ownerid=args.ownerid,
        businessunitid=args.businessunitid,
    )
    if args.json:
        print(json.dumps({"query": query, "results": results}, indent=2, sort_keys=True))
    else:
        render_markdown(query, results)


if __name__ == "__main__":
    main()
