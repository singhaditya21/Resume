#!/usr/bin/env python3
"""Run privacy-safe liveness, readiness, and optional pilot auth smoke checks."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable, Mapping


SMOKE_SCHEMA = "businessnext.dbprod.pilot-smoke/v1"
DEFAULT_BASE_URL = "http://127.0.0.1:8765"
MAX_RESPONSE_BYTES = 1024 * 1024
VALID_ROLES = {"viewer", "analyst", "steward", "admin"}


class SmokeError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def _validated_base_url(value: str, *, allow_non_loopback: bool) -> tuple[str, str]:
    parsed = urllib.parse.urlsplit(str(value or ""))
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise SmokeError("base_url_invalid", "Smoke target URL is invalid")
    loopback = parsed.hostname in {"127.0.0.1", "::1", "localhost"}
    if not loopback and not allow_non_loopback:
        raise SmokeError(
            "non_loopback_denied",
            "Non-loopback smoke target requires explicit approval",
        )
    if not loopback and parsed.scheme != "https":
        raise SmokeError("tls_required", "Non-loopback smoke target must use HTTPS")
    normalized = urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, "", "", "")
    ).rstrip("/")
    return normalized, "loopback" if loopback else "remote"


def _http_request(
    base_url: str,
    method: str,
    path: str,
    headers: Mapping[str, str],
    body: bytes | None,
    timeout: float,
) -> tuple[int, dict | None]:
    request_headers = {str(key): str(value) for key, value in headers.items()}
    if body is not None:
        request_headers["Content-Type"] = "application/json"
    request = urllib.request.Request(
        base_url + path,
        data=body,
        headers=request_headers,
        method=method,
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        response = opener.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    except (OSError, urllib.error.URLError) as exc:
        raise SmokeError("transport_failed", "Smoke request could not reach the target") from exc
    try:
        status = int(response.status)
        payload_bytes = response.read(MAX_RESPONSE_BYTES + 1)
    finally:
        response.close()
    if len(payload_bytes) > MAX_RESPONSE_BYTES:
        raise SmokeError("response_too_large", "Smoke response exceeded the safe size limit")
    payload = None
    if payload_bytes:
        try:
            decoded = json.loads(payload_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            decoded = None
        if isinstance(decoded, dict):
            payload = decoded
    return status, payload


def _signed_headers(
    actor: str, role: str, secret: str, method: str, path: str, *, now=None
) -> dict[str, str]:
    actor = str(actor or "").strip()
    role = str(role or "").strip().lower()
    if not actor or any(character in actor for character in "\r\n") or role not in VALID_ROLES:
        raise SmokeError("identity_invalid", "Smoke identity configuration is invalid")
    if len(str(secret or "")) < 32:
        raise SmokeError(
            "identity_secret_invalid",
            "Identity signing secret is unavailable or too short",
        )
    timestamp = int(time.time() if now is None else now)
    # Bind the assertion to the request method and path (audience binding).
    message = f"{actor}\n{role}\n{timestamp}\n{str(method).upper()}\n{path}"
    signature = hmac.new(
        str(secret).encode("utf-8"), message.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    return {
        "X-SchemaBrain-User": actor,
        "X-SchemaBrain-Role": role,
        "X-SchemaBrain-Timestamp": str(timestamp),
        "X-SchemaBrain-Signature": signature,
    }


def _health_is_safe_and_ready(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    learning = payload.get("learning_loop") or {}
    integrity = learning.get("integrity") or {}
    drift = payload.get("schema_drift") or {}
    redash_access = payload.get("redash_access") or {}
    return (
        payload.get("status") == "ready"
        and payload.get("datasource") == "prod-my"
        and payload.get("owner_id") == 2
        and payload.get("redash_env_key_available") is True
        and payload.get("redash_credential_source") == "environment"
        and isinstance(redash_access, dict)
        and redash_access.get("status") == "ready"
        and redash_access.get("access") == "verified"
        and isinstance(learning, dict)
        and isinstance(integrity, dict)
        and integrity.get("status") == "passed"
        and isinstance(drift, dict)
        and drift.get("contract") == "businessnext.schema-drift-gate/v1"
        and drift.get("status") == "accepted"
        and drift.get("report_status") in {"baseline_established", "unchanged"}
        and drift.get("freshness") == "current"
        and drift.get("owner_id") == 2
        and isinstance(drift.get("current_snapshot_id"), str)
        and drift.get("current_snapshot_id", "").startswith("drift:")
        and bool(drift.get("captured_at"))
        and drift.get("reason") is None
    )


def run_smoke(
    *,
    base_url: str = DEFAULT_BASE_URL,
    allow_non_loopback: bool = False,
    signed_health: bool = False,
    check_role_denials: bool = False,
    actor_id: str = "pilot-smoke",
    identity_secret: str | None = None,
    environ: Mapping[str, str] | None = None,
    timeout: float = 10,
    requester: Callable[
        [str, str, str, Mapping[str, str], bytes | None, float],
        tuple[int, dict | None],
    ] = _http_request,
    now=None,
) -> dict[str, object]:
    normalized, target_kind = _validated_base_url(
        base_url, allow_non_loopback=allow_non_loopback
    )
    checks = []

    def record(name: str, operation) -> None:
        try:
            passed = bool(operation())
            checks.append({"name": name, "status": "passed" if passed else "failed"})
        except SmokeError as exc:
            checks.append({"name": name, "status": "failed", "error_code": exc.code})
        except Exception:
            checks.append({"name": name, "status": "failed", "error_code": "unexpected_error"})

    record(
        "livez",
        lambda: requester(normalized, "GET", "/livez", {}, None, timeout)
        == (200, {"status": "live"}),
    )
    record(
        "readyz",
        lambda: requester(normalized, "GET", "/readyz", {}, None, timeout)
        == (200, {"status": "ready"}),
    )

    environment = os.environ if environ is None else environ
    secret = identity_secret if identity_secret is not None else environment.get(
        "SCHEMA_BRAIN_IDENTITY_SECRET"
    )
    if signed_health:
        def signed_health_check():
            headers = _signed_headers(
                actor_id, "viewer", str(secret or ""), "GET", "/api/health", now=now
            )
            status, payload = requester(
                normalized, "GET", "/api/health", headers, None, timeout
            )
            return status == 200 and _health_is_safe_and_ready(payload)

        record("signed_health", signed_health_check)

    if check_role_denials:
        denial_cases = (
            ("viewer_query_denied", "viewer", "/api/chat"),
            ("analyst_admin_denied", "analyst", "/api/obsidian/open"),
            ("steward_admin_denied", "steward", "/api/obsidian/open"),
        )
        for name, role, path in denial_cases:
            def denial_check(role=role, path=path):
                headers = {
                    **_signed_headers(
                        f"{actor_id}-{role}", role, str(secret or ""), "POST", path, now=now
                    ),
                    # The proxy forwards same-origin browser fetch metadata; the
                    # smoke client mirrors it so the request reaches the role
                    # check rather than being stopped by the CSRF gate.
                    "Sec-Fetch-Site": "same-origin",
                }
                status, _payload = requester(
                    normalized, "POST", path, headers, b"", timeout
                )
                return status == 403

            record(name, denial_check)

    failed = [row["name"] for row in checks if row["status"] != "passed"]
    return {
        "schema": SMOKE_SCHEMA,
        "status": "passed" if not failed else "failed",
        "target": target_kind,
        "checks": checks,
        "failed_checks": failed,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--allow-non-loopback", action="store_true")
    parser.add_argument("--signed-health", action="store_true")
    parser.add_argument("--check-role-denials", action="store_true")
    parser.add_argument("--actor-id", default="pilot-smoke")
    parser.add_argument("--timeout", type=float, default=10)
    args = parser.parse_args(argv)
    try:
        if args.timeout <= 0 or args.timeout > 60:
            raise SmokeError("timeout_invalid", "Smoke timeout must be between 0 and 60 seconds")
        report = run_smoke(
            base_url=args.base_url,
            allow_non_loopback=args.allow_non_loopback,
            signed_health=args.signed_health,
            check_role_denials=args.check_role_denials,
            actor_id=args.actor_id,
            timeout=args.timeout,
        )
    except SmokeError as exc:
        report = {
            "schema": SMOKE_SCHEMA,
            "status": "failed",
            "target": "unvalidated",
            "checks": [],
            "failed_checks": [exc.code],
        }
    except Exception:
        report = {
            "schema": SMOKE_SCHEMA,
            "status": "failed",
            "target": "unvalidated",
            "checks": [],
            "failed_checks": ["unexpected_error"],
        }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
