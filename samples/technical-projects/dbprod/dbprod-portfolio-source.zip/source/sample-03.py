#!/usr/bin/env python3
"""Fail-closed SQL, runtime, and result policies for the owner-2 service.

The SQL checks intentionally use a small deterministic lexer instead of a
database parser.  The lexer is not intended to prove that arbitrary SQL is
semantically correct; it establishes the much smaller execution contract this
service supports: one read-only SELECT/WITH statement, no comments or unsafe
constructs, literal owner-2 evidence, and bounded execution on the one approved
Redash datasource.
"""

from __future__ import annotations

import hashlib
import re
import urllib.parse

from runtime_config import (
    DATA_SOURCE_NAME,
    DEFAULT_QUERY_TIMEOUT_SECONDS,
    DEFAULT_RESULT_ROW_LIMIT,
    PRODUCTION_CONTEXT,
    REDASH_BASE_URL,
    REDASH_DATA_SOURCE_ID,
    TENANT_OWNER_ID,
)


POLICY_VERSION = "owner2-readonly/v2"
MAX_SAMPLE_LIMIT = 500
MAX_RESULT_ROW_LIMIT = DEFAULT_RESULT_ROW_LIMIT
MAX_QUERY_TIMEOUT_SECONDS = DEFAULT_QUERY_TIMEOUT_SECONDS
MAX_EXPLICIT_OFFSET = 100_000

CREDENTIAL_IDENTIFIER_RE = re.compile(
    r"(?:^|_)(?:password|passwd|passwordhash|rolpassword|secret|clientsecret|"
    r"api_?key|access_?token|refresh_?token|private_?key)(?:$|_)",
    re.I,
)
EMAIL_COLUMN_RE = re.compile(r"(?:^|_)(?:email|emailaddress)(?:$|_)", re.I)
PHONE_COLUMN_RE = re.compile(r"(?:^|_)(?:phone|mobile|telephone|whatsapp)(?:$|_)", re.I)
ADDRESS_COLUMN_RE = re.compile(r"(?:^|_)(?:address|street|postal|postcode|zipcode)(?:$|_)", re.I)

# These words are disallowed anywhere outside a string or quoted identifier.
# This catches data-changing CTEs as well as statements that merely begin with
# a harmless-looking WITH or SELECT.
DISALLOWED_KEYWORDS = frozenset(
    {
        "alter",
        "analyze",
        "call",
        "cluster",
        "comment",
        "copy",
        "create",
        "deallocate",
        "delete",
        "discard",
        "do",
        "drop",
        "execute",
        "grant",
        "insert",
        "listen",
        "load",
        "lock",
        "merge",
        "notify",
        "prepare",
        "reassign",
        "refresh",
        "reindex",
        "replace",
        "reset",
        "revoke",
        "set",
        "truncate",
        "unlisten",
        "update",
        "upsert",
        "vacuum",
    }
)

# Functions with side effects, filesystem/network reach, session mutation,
# unbounded delay, backend control, advisory locking, or sequence mutation.
UNSAFE_FUNCTIONS = frozenset(
    {
        "aws_s3_query_export_to_s3",
        "dblink",
        "dblink_connect",
        "dblink_connect_u",
        "dblink_disconnect",
        "dblink_exec",
        "dblink_send_query",
        "http_delete",
        "http_get",
        "http_head",
        "http_patch",
        "http_post",
        "http_put",
        "cursor_to_xml",
        "cursor_to_xmlschema",
        "database_to_xml",
        "database_to_xml_and_xmlschema",
        "database_to_xmlschema",
        "lo_create",
        "lo_export",
        "lo_from_bytea",
        "lo_import",
        "lo_open",
        "lo_put",
        "lo_truncate",
        "lo_unlink",
        "nextval",
        "pg_advisory_lock",
        "pg_advisory_lock_shared",
        "pg_advisory_unlock",
        "pg_advisory_unlock_all",
        "pg_advisory_unlock_shared",
        "pg_backup_start",
        "pg_backup_stop",
        "pg_cancel_backend",
        "REDACTED_OPAQUE_VALUE",
        "REDACTED_OPAQUE_VALUE",
        "pg_create_restore_point",
        "pg_drop_replication_slot",
        "pg_log_backend_memory_contexts",
        "pg_file_rename",
        "pg_file_unlink",
        "pg_file_write",
        "pg_ls_archive_statusdir",
        "pg_ls_logdir",
        "pg_ls_dir",
        "pg_ls_tmpdir",
        "pg_ls_waldir",
        "pg_notify",
        "pg_promote",
        "pg_read_binary_file",
        "pg_read_file",
        "pg_reload_conf",
        "pg_rotate_logfile",
        "pg_sleep",
        "pg_sleep_for",
        "pg_sleep_until",
        "pg_start_backup",
        "pg_stat_file",
        "pg_stop_backup",
        "pg_switch_wal",
        "pg_terminate_backend",
        "pg_try_advisory_lock",
        "pg_try_advisory_lock_shared",
        "pg_wal_replay_pause",
        "pg_wal_replay_resume",
        "pg_write_file",
        "query_export_to_s3",
        "query_import_from_s3",
        "query_to_xml",
        "query_to_xml_and_xmlschema",
        "query_to_xmlschema",
        "set_config",
        "setval",
        "table_to_xml",
        "table_to_xml_and_xmlschema",
        "table_to_xmlschema",
    }
)

SENSITIVE_SYSTEM_RELATIONS = frozenset(
    {
        "pg_authid",
        "pg_shadow",
        "pg_user_mapping",
        "pg_user_mappings",
    }
)


def _reason(code, message, **evidence):
    reason = {"code": code, "message": message}
    if evidence:
        reason["evidence"] = evidence
    return reason


def _dedupe_reasons(reasons):
    output = []
    seen = set()
    for reason in reasons:
        key = (reason.get("code"), reason.get("message"))
        if key in seen:
            continue
        seen.add(key)
        output.append(reason)
    return output


def _scan_quoted(sql, start, quote, doubled_quote=True, backslash_escapes=False):
    i = start + 1
    while i < len(sql):
        if backslash_escapes and sql[i] == "\\":
            i += 2
            continue
        if sql[i] == quote:
            if doubled_quote and i + 1 < len(sql) and sql[i + 1] == quote:
                i += 2
                continue
            return i + 1, True
        i += 1
    return len(sql), False


def _lex_sql(sql):
    """Return significant SQL tokens and lexical policy failures.

    String and quoted-identifier content remains opaque, so words such as DROP
    or comment markers inside a literal cannot create false decisions.
    """

    text = str(sql or "")
    tokens = REDACTED_SECRET
    reasons = []
    comments = []
    i = 0
    depth = 0
    while i < len(text):
        ch = text[i]
        if ch.isspace():
            i += 1
            continue

        if text.startswith("--", i):
            end = text.find("\n", i + 2)
            end = len(text) if end < 0 else end
            comments.append({"kind": "line", "offset": i})
            i = end
            continue
        if text.startswith("/*", i):
            start = i
            nesting = 1
            i += 2
            while i < len(text) and nesting:
                if text.startswith("/*", i):
                    nesting += 1
                    i += 2
                elif text.startswith("*/", i):
                    nesting -= 1
                    i += 2
                else:
                    i += 1
            comments.append({"kind": "block", "offset": start})
            if nesting:
                reasons.append(
                    _reason("sql.lexical.unterminated_comment", "SQL contains an unterminated block comment")
                )
            continue

        # PostgreSQL escape and Unicode string prefixes.
        if ch in "eE" and i + 1 < len(text) and text[i + 1] == "'":
            end, closed = _scan_quoted(text, i + 1, "'", backslash_escapes=True)
            tokens.append({"kind": "string", "value": "", "offset": i, "depth": depth})
            if not closed:
                reasons.append(
                    _reason("sql.lexical.unterminated_string", "SQL contains an unterminated string literal")
                )
            i = end
            continue
        if (
            ch in "uU"
            and i + 2 < len(text)
            and text[i + 1] == "&"
            and text[i + 2] == "'"
        ):
            end, closed = _scan_quoted(text, i + 2, "'", backslash_escapes=True)
            tokens.append({"kind": "string", "value": "", "offset": i, "depth": depth})
            if not closed:
                reasons.append(
                    _reason("sql.lexical.unterminated_string", "SQL contains an unterminated string literal")
                )
            i = end
            continue
        if ch == "'":
            end, closed = _scan_quoted(text, i, "'")
            tokens.append({"kind": "string", "value": "", "offset": i, "depth": depth})
            if not closed:
                reasons.append(
                    _reason("sql.lexical.unterminated_string", "SQL contains an unterminated string literal")
                )
            i = end
            continue

        # Dollar-quoted strings may legally contain quotes, semicolons, and
        # comment-looking text, all of which must remain opaque to the policy.
        if ch == "$":
            match = re.match(r"\$(?:[A-Za-z_][A-Za-z0-9_]*)?\$", text[i:])
            if match:
                delimiter = match.group(0)
                end = text.find(delimiter, i + len(delimiter))
                tokens.append({"kind": "string", "value": "", "offset": i, "depth": depth})
                if end < 0:
                    reasons.append(
                        _reason(
                            "sql.lexical.unterminated_dollar_string",
                            "SQL contains an unterminated dollar-quoted string",
                        )
                    )
                    i = len(text)
                else:
                    i = end + len(delimiter)
                continue

        if ch == '"':
            end, closed = _scan_quoted(text, i, '"')
            raw = text[i + 1 : max(i + 1, end - 1)]
            value = raw.replace('""', '"').lower()
            tokens.append(
                {"kind": "quoted_identifier", "value": value, "offset": i, "depth": depth}
            )
            if not closed:
                reasons.append(
                    _reason(
                        "sql.lexical.unterminated_identifier",
                        "SQL contains an unterminated quoted identifier",
                    )
                )
            i = end
            continue

        if ch.isalpha() or ch == "_":
            match = re.match(r"[A-Za-z_][A-Za-z0-9_$]*", text[i:])
            value = match.group(0)
            tokens.append(
                {"kind": "word", "value": value.lower(), "raw": value, "offset": i, "depth": depth}
            )
            i += len(value)
            continue

        if ch.isdigit():
            match = re.match(r"(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)", text[i:])
            value = match.group(0)
            tokens.append({"kind": "number", "value": value, "offset": i, "depth": depth})
            i += len(value)
            continue

        two = text[i : i + 2]
        if two in {"::", "<=", ">=", "<>", "!=", "=>", "||", "&&", "->", "#>"}:
            tokens.append({"kind": "operator", "value": two, "offset": i, "depth": depth})
            i += 2
            continue
        if ch == "(":
            tokens.append({"kind": "symbol", "value": ch, "offset": i, "depth": depth})
            depth += 1
            i += 1
            continue
        if ch == ")":
            depth = max(0, depth - 1)
            tokens.append({"kind": "symbol", "value": ch, "offset": i, "depth": depth})
            i += 1
            continue

        kind = "terminator" if ch == ";" else "operator" if ch in "=<>+-*/%" else "symbol"
        tokens.append({"kind": kind, "value": ch, "offset": i, "depth": depth})
        i += 1

    if comments:
        reasons.append(
            _reason(
                "sql.comment.disallowed",
                "SQL comments are not allowed",
                count=len(comments),
                kinds=sorted({row["kind"] for row in comments}),
            )
        )
    if depth:
        reasons.append(
            _reason("sql.lexical.unbalanced_parentheses", "SQL contains unbalanced parentheses")
        )
    return tokens, _dedupe_reasons(reasons), comments


def _word_tokens(tokens):
    return [token for token in tokens if token["kind"] == "word"]


def _token_is_identifier(token):
    return token.get("kind") in {"word", "quoted_identifier"}


def _has_sequence(tokens, sequence):
    values = [token.get("value") for token in tokens]
    size = len(sequence)
    return any(values[index : index + size] == list(sequence) for index in range(len(values) - size + 1))


def _owner_scope_report(tokens, requested_owner_id):
    reasons = []
    requested = TENANT_OWNER_ID if requested_owner_id is None else requested_owner_id
    try:
        requested = int(requested)
    except (TypeError, ValueError):
        reasons.append(
            _reason(
                "sql.owner_scope.invalid_requested_owner",
                f"owner id must be the fixed integer {TENANT_OWNER_ID}",
                observed=requested_owner_id,
            )
        )
    else:
        if requested != TENANT_OWNER_ID:
            reasons.append(
                _reason(
                    "sql.owner_scope.requested_owner_mismatch",
                    f"the service is permanently scoped to ownerid {TENANT_OWNER_ID}",
                    expected=TENANT_OWNER_ID,
                    observed=requested,
                )
            )

    observed_values = []
    accepted = []
    invalid_predicates = []
    owner_names = {"ownerid", "owner_id"}
    comparison_operators = {"=", "!=", "<>", "<", ">", "<=", ">="}
    clause_boundaries = {
        "except",
        "from",
        "group",
        "having",
        "intersect",
        "join",
        "limit",
        "on",
        "order",
        "select",
        "union",
        "where",
    }

    def owner_reference_at(index):
        """Recognize ownerid and the common alias.ownerid spelling."""
        if index >= len(tokens):
            return False
        token = REDACTED_SECRET
        if _token_is_identifier(token) and token.get("value") in owner_names:
            return True
        return (
            index + 2 < len(tokens)
            and _token_is_identifier(token)
            and tokens[index + 1].get("value") == "."
            and _token_is_identifier(tokens[index + 2])
            and tokens[index + 2].get("value") in owner_names
        )

    def predicate_context(index):
        owner_depth = tokens[index].get("depth", 0)
        for previous in range(index - 1, -1, -1):
            token = REDACTED_SECRET
            if token.get("depth", 0) > owner_depth or token.get("kind") != "word":
                continue
            if token.get("value") in clause_boundaries:
                return token.get("value"), previous
        return None, -1

    def predicate_is_negated(index, clause_index):
        boundary = clause_index
        for previous in range(index - 1, clause_index, -1):
            token = REDACTED_SECRET
            if token.get("kind") == "word" and token.get("value") in {"and", "or"}:
                boundary = previous
                break
        return any(
            token.get("kind") == "word" and token.get("value") == "not"
            for token in tokens[boundary + 1 : index]
        )

    for index, token in enumerate(tokens):
        if not _token_is_identifier(token) or token.get("value") not in owner_names:
            continue
        following = tokens[index + 1 : index + 3]
        context, clause_index = predicate_context(index)
        negated = predicate_is_negated(index, clause_index)
        if len(following) >= 2 and following[0].get("value") in comparison_operators:
            operator = following[0]["value"]
            value_token = REDACTED_SECRET
            if operator == "=" and value_token.get("kind") == "number" and re.fullmatch(
                r"[0-9]+", value_token.get("value", "")
            ):
                value = int(value_token["value"])
                observed_values.append(value)
                evidence = {
                    "column": token.get("value"),
                    "operator": operator,
                    "value": value,
                    "offset": token.get("offset"),
                }
                # A literal equality is policy evidence only when it is a
                # positive WHERE predicate.  A matching value in SELECT output
                # or a JOIN ON clause must not act as a decoy scope check.
                if value == TENANT_OWNER_ID and context == "where" and not negated:
                    evidence["clause"] = context
                    evidence["depth"] = token.get("depth", 0)
                    evidence["clause_offset"] = tokens[clause_index].get("offset")
                    accepted.append(evidence)
                elif context in {"where", "having", "on"}:
                    evidence["clause"] = context
                    evidence["negated"] = negated
                    invalid_predicates.append(evidence)
            elif operator == "=" and owner_reference_at(index + 2):
                # A join such as extension.ownerid = base.ownerid propagates
                # scope but is not sufficient literal owner evidence by itself.
                continue
            else:
                invalid_predicates.append(
                    {
                        "column": token.get("value"),
                        "operator": operator,
                        "value": value_token.get("value"),
                        "offset": token.get("offset"),
                    }
                )
        elif following and following[0].get("value") in {"between", "in", "is"}:
            invalid_predicates.append(
                {
                    "column": token.get("value"),
                    "operator": following[0].get("value"),
                    "offset": token.get("offset"),
                }
            )

    # Also recognize the equivalent literal-on-the-left spelling.
    for index in range(len(tokens) - 2):
        left, operator, right = tokens[index : index + 3]
        if (
            left.get("kind") == "number"
            and re.fullmatch(r"[0-9]+", left.get("value", ""))
            and operator.get("value") == "="
            and owner_reference_at(index + 2)
        ):
            value = int(left["value"])
            observed_values.append(value)
            evidence = {
                "column": "ownerid",
                "operator": "=",
                "value": value,
                "offset": right.get("offset"),
                "literal_on_left": True,
            }
            context, clause_index = predicate_context(index + 2)
            negated = predicate_is_negated(index + 2, clause_index)
            if value == TENANT_OWNER_ID and context == "where" and not negated:
                evidence["clause"] = context
                evidence["depth"] = right.get("depth", 0)
                evidence["clause_offset"] = tokens[clause_index].get("offset")
                accepted.append(evidence)
            elif context in {"where", "having", "on"}:
                evidence["clause"] = context
                evidence["negated"] = negated
                invalid_predicates.append(evidence)

    if not accepted:
        reasons.append(
            _reason(
                "sql.owner_scope.missing",
                f"SQL must contain explicit literal ownerid = {TENANT_OWNER_ID} policy evidence",
            )
        )
    if invalid_predicates:
        reasons.append(
            _reason(
                "sql.owner_scope.disallowed_predicate",
                "SQL contains a non-literal or disallowed owner predicate",
                predicates=invalid_predicates,
            )
        )

    # An OR in SELECT output cannot relax row scope.  In WHERE, it is accepted
    # only in a deeper parenthesized group dominated by an earlier literal
    # owner predicate in that exact WHERE clause.  This supports the compiler's
    # ``ownerid = 2 AND (business_filter OR business_filter)`` shape while
    # rejecting ``ownerid = 2 OR ...`` and other ambiguous spellings.
    for index, token in enumerate(tokens):
        if token.get("kind") != "word" or token.get("value") != "or":
            continue
        context, clause_index = predicate_context(index)
        if context not in {"where", "on"}:
            continue
        clause_offset = tokens[clause_index].get("offset") if clause_index >= 0 else None
        dominated = context == "where" and any(
            evidence.get("clause_offset") == clause_offset
            and evidence.get("offset", token.get("offset")) < token.get("offset")
            and evidence.get("depth", 0) < token.get("depth", 0)
            for evidence in accepted
        )
        if not dominated:
            reasons.append(
                _reason(
                    "sql.owner_scope.disjunction_not_supported",
                    "OR must be inside a parenthesized WHERE group dominated by ownerid = 2",
                    offset=token.get("offset"),
                    clause=context,
                )
            )

    reasons = _dedupe_reasons(reasons)
    return {
        "status": "passed" if not reasons else "failed",
        "required_owner_id": TENANT_OWNER_ID,
        "requested_owner_id": requested,
        "observed_owner_ids": sorted(set(observed_values)),
        "evidence": accepted,
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
    }


# Keywords that terminate a FROM relation list, and the set-operation keywords
# that begin an additional query branch.  Used by the shadow universality proof.
_SET_OPERATION_WORDS = {"union", "intersect", "except"}
_FROM_CLAUSE_TERMINATORS = {
    "where",
    "group",
    "having",
    "order",
    "limit",
    "union",
    "intersect",
    "except",
}


def _owner_scope_universal_report(tokens, owner_report):
    """Shadow (non-blocking) proof that *every* relation is owner-scoped.

    ``_owner_scope_report`` proves that at least one positive literal
    ``ownerid = 2`` WHERE predicate exists.  It does NOT prove that every joined
    relation and every set-operation branch is scoped, so three shapes can pass
    the presence check while still returning cross-owner rows:

      * a comma/cartesian ``FROM`` list where only one relation is scoped,
      * an unscoped ``UNION``/``INTERSECT``/``EXCEPT`` branch, and
      * owner scope that lives only inside a subquery while the outer query's
        relations are unscoped.

    This report flags those shapes over the existing lexer tokens.  As of P1 it
    is an ENFORCING gate: its findings enter ``validate_security_sql`` reasons
    and deny execution.  It was validated to produce zero false denials against
    the SQL the compiler, business-report, and metadata paths actually generate
    (every such query scopes each relation with a top-level ``ownerid = 2`` and
    uses explicit, owner-anchored joins rather than comma joins or set ops).
    """

    findings = []
    accepted = list((owner_report or {}).get("evidence") or [])

    # (A) Comma / cartesian join: a top-level comma inside a FROM relation list.
    # Scoping one relation does not scope the others in a comma join.
    for index, token in enumerate(tokens):
        if token.get("kind") != "word" or token.get("value") != "from":
            continue
        from_depth = token.get("depth", 0)
        for follower in tokens[index + 1 :]:
            depth = follower.get("depth", 0)
            if depth < from_depth:
                break
            if (
                follower.get("kind") == "word"
                and depth == from_depth
                and follower.get("value") in _FROM_CLAUSE_TERMINATORS
            ):
                break
            if follower.get("value") == "," and depth == from_depth:
                findings.append(
                    _reason(
                        "sql.owner_scope.universal.comma_join",
                        "FROM uses a comma/cartesian relation list; every relation must carry its own owner scope",
                        offset=follower.get("offset"),
                    )
                )
                break

    # Explicit CROSS JOIN cannot propagate owner scope to the crossed relation.
    if _has_sequence(_word_tokens(tokens), ("cross", "join")):
        findings.append(
            _reason(
                "sql.owner_scope.universal.cross_join",
                "CROSS JOIN cannot propagate owner scope to the crossed relation",
            )
        )

    # (B) Set-operation branches: each top-level UNION/INTERSECT/EXCEPT branch
    # needs its own accepted owner predicate.
    branch_separators = sum(
        1
        for token in tokens
        if token.get("kind") == "word"
        and token.get("value") in _SET_OPERATION_WORDS
        and token.get("depth", 0) == 0
    )
    if branch_separators:
        branches = branch_separators + 1
        if len(accepted) < branches:
            findings.append(
                _reason(
                    "sql.owner_scope.universal.unscoped_set_operation_branch",
                    "a UNION/INTERSECT/EXCEPT branch lacks its own literal ownerid = 2 predicate",
                    branches=branches,
                    accepted_owner_predicates=len(accepted),
                )
            )

    # (C) Subquery-only scope: the only accepted predicates live inside a
    # subquery while the outer query still selects from an unscoped relation.
    has_top_level_from = any(
        token.get("kind") == "word"
        and token.get("value") == "from"
        and token.get("depth", 0) == 0
        for token in tokens
    )
    if accepted and has_top_level_from and all(item.get("depth", 0) > 0 for item in accepted):
        findings.append(
            _reason(
                "sql.owner_scope.universal.subquery_only_scope",
                "owner scope is only present inside a subquery; the outer query relations are unscoped",
            )
        )

    findings = _dedupe_reasons(findings)
    return {
        "status": "passed" if not findings else "failed",
        "mode": "enforcing",
        "enforced": True,
        "findings": findings,
        "reasons": findings,
        "errors": [finding["message"] for finding in findings],
    }


def owner_scope_decision(sql, owner_id=TENANT_OWNER_ID):
    """Authoritative owner-scope decision over a SQL string.

    Single shared implementation combining the presence proof
    (``_owner_scope_report``) and the universality proof
    (``_owner_scope_universal_report``) so no caller re-implements owner-scope
    detection.  Owner-scope only — callers that need the full execution
    contract (bounds, runtime invariants, read-only) call ``validate_security_sql``.
    """
    tokens, _lexical_reasons, _comments = _lex_sql(sql)
    presence = _owner_scope_report(tokens, owner_id)
    universal = _owner_scope_universal_report(tokens, presence)
    reasons = _dedupe_reasons(
        list(presence.get("reasons") or []) + list(universal.get("reasons") or [])
    )
    return {
        "status": "passed" if not reasons else "failed",
        "required_owner_id": presence.get("required_owner_id"),
        "observed_owner_ids": presence.get("observed_owner_ids", []),
        "evidence": presence.get("evidence", []),
        "universal": universal,
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
    }


def validate_runtime_invariants(
    datasource=DATA_SOURCE_NAME,
    redash_base_url=REDASH_BASE_URL,
    redash_data_source_id=REDASH_DATA_SOURCE_ID,
    host=None,
):
    """Validate the immutable Redash datasource and host execution boundary."""

    reasons = []
    if datasource != DATA_SOURCE_NAME:
        reasons.append(
            _reason(
                "runtime.datasource.mismatch",
                "datasource does not match the fixed production datasource",
                expected=DATA_SOURCE_NAME,
                observed=datasource,
            )
        )
    try:
        source_id = int(redash_data_source_id)
    except (TypeError, ValueError):
        source_id = redash_data_source_id
    if isinstance(redash_data_source_id, bool) or source_id != REDASH_DATA_SOURCE_ID:
        reasons.append(
            _reason(
                "runtime.datasource_id.mismatch",
                "Redash datasource id does not match the fixed production datasource",
                expected=REDASH_DATA_SOURCE_ID,
                observed=redash_data_source_id,
            )
        )

    expected = urllib.parse.urlsplit(REDASH_BASE_URL)
    observed = urllib.parse.urlsplit(str(redash_base_url or ""))
    if observed.scheme.lower() != "https":
        reasons.append(
            _reason(
                "runtime.scheme.insecure",
                "Redash execution requires HTTPS",
                expected="https",
                observed=observed.scheme or None,
            )
        )
    try:
        observed_port = observed.port
    except ValueError:
        observed_port = None
        reasons.append(
            _reason("runtime.host.invalid", "Redash base URL contains an invalid port")
        )
    if (
        observed.hostname != expected.hostname
        or observed.username is not None
        or observed.password is not None
        or observed_port not in {None, 443}
        or observed.path not in {"", "/"}
        or observed.query
        or observed.fragment
    ):
        reasons.append(
            _reason(
                "runtime.host.mismatch",
                "Redash base URL does not match the fixed production host",
                expected=expected.hostname,
                observed=observed.hostname,
            )
        )

    if host is not None:
        parsed_host = urllib.parse.urlsplit("//" + str(host), scheme="https")
        try:
            host_port = parsed_host.port
        except ValueError:
            host_port = None
            reasons.append(_reason("runtime.request_host.invalid", "request host contains an invalid port"))
        if parsed_host.hostname != expected.hostname or host_port not in {None, 443}:
            reasons.append(
                _reason(
                    "runtime.request_host.mismatch",
                    "request host does not match the fixed production host",
                    expected=expected.hostname,
                    observed=parsed_host.hostname,
                )
            )

    reasons = _dedupe_reasons(reasons)
    return {
        "status": "passed" if not reasons else "failed",
        "decision": "allow" if not reasons else "deny",
        "expected": {
            "datasource": DATA_SOURCE_NAME,
            "redash_data_source_id": REDASH_DATA_SOURCE_ID,
            "scheme": "https",
            "host": expected.hostname,
        },
        "observed": {
            "datasource": datasource,
            "redash_data_source_id": redash_data_source_id,
            "redash_base_url": redash_base_url,
            "request_host": host,
        },
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
    }


def _bounded_integer(value, name, minimum, maximum, code, reasons):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        reasons.append(
            _reason(code, f"{name} must be an integer between {minimum} and {maximum}", observed=value)
        )
        return None
    if isinstance(value, bool) or parsed < minimum or parsed > maximum:
        reasons.append(
            _reason(
                code,
                f"{name} must be between {minimum} and {maximum}",
                minimum=minimum,
                maximum=maximum,
                observed=value,
            )
        )
    return parsed


def validate_query_bounds(
    sql_or_tokens,
    result_row_limit=DEFAULT_RESULT_ROW_LIMIT,
    sample_limit=50,
    timeout_seconds=DEFAULT_QUERY_TIMEOUT_SECONDS,
):
    """Validate caller bounds and any explicit top-level LIMIT/OFFSET."""

    if isinstance(sql_or_tokens, list):
        tokens = REDACTED_SECRET
    else:
        tokens, lexical_reasons, _ = _lex_sql(sql_or_tokens)
        # Lexical failures are owned by the SQL decision, but retaining them
        # here makes this standalone public validator fail closed as well.
        if lexical_reasons:
            return {
                "status": "failed",
                "decision": "deny",
                "errors": [reason["message"] for reason in lexical_reasons],
                "reasons": lexical_reasons,
            }

    reasons = []
    result_limit = _bounded_integer(
        result_row_limit,
        "result_row_limit",
        1,
        MAX_RESULT_ROW_LIMIT,
        "bounds.result_row_limit.invalid",
        reasons,
    )
    bounded_sample = _bounded_integer(
        sample_limit,
        "sample_limit",
        1,
        MAX_SAMPLE_LIMIT,
        "bounds.sample_limit.invalid",
        reasons,
    )
    bounded_timeout = _bounded_integer(
        timeout_seconds,
        "timeout_seconds",
        1,
        MAX_QUERY_TIMEOUT_SECONDS,
        "bounds.timeout.invalid",
        reasons,
    )

    explicit_limit = None
    explicit_offset = None
    top_level = [token for token in tokens if token.get("depth") == 0]
    for index, token in enumerate(top_level):
        if token.get("kind") != "word":
            continue
        if token.get("value") == "limit":
            value = top_level[index + 1] if index + 1 < len(top_level) else None
            if value and value.get("kind") == "number" and re.fullmatch(r"[0-9]+", value.get("value", "")):
                explicit_limit = int(value["value"])
                if explicit_limit < 1 or (result_limit is not None and explicit_limit > result_limit):
                    reasons.append(
                        _reason(
                            "bounds.explicit_limit.exceeds_policy",
                            "explicit top-level LIMIT exceeds the result policy",
                            limit=explicit_limit,
                            maximum=result_limit,
                        )
                    )
            else:
                reasons.append(
                    _reason(
                        "bounds.explicit_limit.dynamic",
                        "top-level LIMIT must be a positive integer literal",
                    )
                )
        elif token.get("value") == "offset":
            value = top_level[index + 1] if index + 1 < len(top_level) else None
            if value and value.get("kind") == "number" and re.fullmatch(r"[0-9]+", value.get("value", "")):
                explicit_offset = int(value["value"])
                if explicit_offset > MAX_EXPLICIT_OFFSET:
                    reasons.append(
                        _reason(
                            "bounds.explicit_offset.exceeds_policy",
                            "explicit top-level OFFSET exceeds the scan policy",
                            offset=explicit_offset,
                            maximum=MAX_EXPLICIT_OFFSET,
                        )
                    )
            else:
                reasons.append(
                    _reason(
                        "bounds.explicit_offset.dynamic",
                        "top-level OFFSET must be a non-negative integer literal",
                    )
                )

    reasons = _dedupe_reasons(reasons)
    return {
        "status": "passed" if not reasons else "failed",
        "decision": "allow" if not reasons else "deny",
        "result_row_limit": result_limit,
        "sample_limit": bounded_sample,
        "timeout_seconds": bounded_timeout,
        "explicit_limit": explicit_limit,
        "explicit_offset": explicit_offset,
        "limit_enforcement": "explicit_and_runtime_wrapper" if explicit_limit is not None else "runtime_wrapper_required",
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
    }


def _sql_contract_report(sql, tokens, lexical_reasons):
    reasons = list(lexical_reasons)
    significant = [token for token in tokens if token.get("kind") != "terminator"]
    terminators = [token for token in tokens if token.get("kind") == "terminator"]

    if not significant:
        reasons.append(_reason("sql.empty", "SQL is empty"))
    if len(terminators) > 1 or (terminators and tokens[-1].get("kind") != "terminator"):
        reasons.append(
            _reason(
                "sql.statement.multiple",
                "exactly one SQL statement is allowed",
                terminator_count=len(terminators),
            )
        )

    first = significant[0] if significant else None
    if not first or first.get("kind") != "word" or first.get("value") not in {"select", "with"}:
        reasons.append(
            _reason("sql.statement.type_not_allowed", "SQL must start with SELECT or WITH")
        )

    disallowed = sorted(
        {
            token["value"]
            for token in _word_tokens(significant)
            if token.get("value") in DISALLOWED_KEYWORDS
        }
    )
    for keyword in disallowed:
        reasons.append(
            _reason(
                "sql.keyword.disallowed",
                f"SQL keyword is not allowed: {keyword}",
                keyword=keyword,
            )
        )

    # In the supported SELECT/WITH grammar an unquoted INTO can only be the
    # table-creating SELECT INTO construct (INSERT is already denied above).
    if any(token.get("kind") == "word" and token.get("value") == "into" for token in significant):
        reasons.append(
            _reason("sql.construct.select_into", "SELECT INTO is not allowed")
        )

    values = [token.get("value") for token in significant]
    locking_sequences = (
        ("for", "update"),
        ("for", "no", "key", "update"),
        ("for", "share"),
        ("for", "key", "share"),
    )
    for sequence in locking_sequences:
        size = len(sequence)
        if any(values[index : index + size] == list(sequence) for index in range(len(values) - size + 1)):
            reasons.append(
                _reason(
                    "sql.construct.locking_clause",
                    "row-locking SELECT clauses are not allowed",
                    clause=" ".join(sequence),
                )
            )

    unsafe_functions = []
    for index, token in enumerate(significant[:-1]):
        if not _token_is_identifier(token) or significant[index + 1].get("value") != "(":
            continue
        name = token.get("value")
        normalized = name.replace(".", "_")
        if name in UNSAFE_FUNCTIONS or normalized in UNSAFE_FUNCTIONS:
            unsafe_functions.append(name)
    for name in sorted(set(unsafe_functions)):
        reasons.append(
            _reason(
                "sql.function.unsafe",
                f"unsafe SQL function is not allowed: {name}",
                function=name,
            )
        )

    sensitive_relations = sorted(
        {
            token.get("value")
            for token in significant
            if _token_is_identifier(token) and token.get("value") in SENSITIVE_SYSTEM_RELATIONS
        }
    )
    for relation in sensitive_relations:
        reasons.append(
            _reason(
                "sql.relation.sensitive_system_catalog",
                f"sensitive system relation is not queryable: {relation}",
                relation=relation,
            )
        )

    reasons = _dedupe_reasons(reasons)
    normalized = str(sql or "").strip()
    if len(terminators) == 1 and tokens and tokens[-1].get("kind") == "terminator":
        normalized = normalized[:-1].rstrip()
    return {
        "status": "passed" if not reasons else "failed",
        "decision": "allow" if not reasons else "deny",
        "read_only": not reasons,
        "single_statement": not any(reason["code"] == "sql.statement.multiple" for reason in reasons),
        "statement_count": 1 if significant and len(terminators) <= 1 else max(0, len(terminators) + 1),
        "statement_type": first.get("value") if first and first.get("kind") == "word" else None,
        "normalized_sql": normalized if not reasons else None,
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
    }


def validate_security_sql(
    sql,
    owner_id=TENANT_OWNER_ID,
    *,
    datasource=DATA_SOURCE_NAME,
    redash_base_url=REDASH_BASE_URL,
    redash_data_source_id=REDASH_DATA_SOURCE_ID,
    host=None,
    result_row_limit=DEFAULT_RESULT_ROW_LIMIT,
    sample_limit=50,
    timeout_seconds=DEFAULT_QUERY_TIMEOUT_SECONDS,
):
    """Return a machine-readable allow/deny decision for live execution.

    The original ``sql`` and ``owner_id`` positional interface, top-level
    ``status``, ``owner_scope``, ``credential_identifiers``, and ``errors`` are
    preserved for existing callers.
    """

    tokens, lexical_reasons, _comments = _lex_sql(sql)
    sql_contract = _sql_contract_report(sql, tokens, lexical_reasons)
    owner = _owner_scope_report(tokens, owner_id)
    # Enforcing (P1) proof that every relation/branch is owner-scoped; its
    # findings feed the deny decision below (see reasons).
    owner_scope_universal = _owner_scope_universal_report(tokens, owner)
    runtime = validate_runtime_invariants(
        datasource=datasource,
        redash_base_url=redash_base_url,
        redash_data_source_id=redash_data_source_id,
        host=host,
    )
    bounds = validate_query_bounds(
        tokens,
        result_row_limit=result_row_limit,
        sample_limit=sample_limit,
        timeout_seconds=timeout_seconds,
    )

    credential_identifiers = sorted(
        {
            token.get("value")
            for token in tokens
            if _token_is_identifier(token) and CREDENTIAL_IDENTIFIER_RE.search(token.get("value", ""))
        }
    )
    credential_reasons = []
    if credential_identifiers:
        credential_reasons.append(
            _reason(
                "sql.column.credential_identifier",
                "credential-bearing columns are not queryable: " + ", ".join(credential_identifiers),
                identifiers=credential_identifiers,
            )
        )

    reasons = _dedupe_reasons(
        list(sql_contract.get("reasons") or [])
        + list(owner.get("reasons") or [])
        + list(owner_scope_universal.get("reasons") or [])
        + list(runtime.get("reasons") or [])
        + list(bounds.get("reasons") or [])
        + credential_reasons
    )
    allowed = not reasons
    return {
        "policy_version": POLICY_VERSION,
        "status": "passed" if allowed else "failed",
        "decision": "allow" if allowed else "deny",
        "allowed": allowed,
        "owner_scope": owner,
        "owner_scope_universal": owner_scope_universal,
        "runtime_invariants": runtime,
        "query_bounds": bounds,
        "sql_contract": sql_contract,
        "credential_identifiers": credential_identifiers,
        "errors": [reason["message"] for reason in reasons],
        "reasons": reasons,
        "reason_codes": [reason["code"] for reason in reasons],
        "checks": {
            "single_statement_read_only": sql_contract.get("status"),
            "owner_scope": owner.get("status"),
            "owner_scope_universal": owner_scope_universal.get("status"),
            "runtime_invariants": runtime.get("status"),
            "query_bounds": bounds.get("status"),
            "credential_identifiers": "passed" if not credential_identifiers else "failed",
        },
        "pii_masking": "email_phone_address_columns",
        "production_context": {
            "datasource": PRODUCTION_CONTEXT.datasource,
            "redash_data_source_id": PRODUCTION_CONTEXT.redash_data_source_id,
            "host": urllib.parse.urlsplit(PRODUCTION_CONTEXT.redash_base_url).hostname,
            "owner_id": PRODUCTION_CONTEXT.tenant_owner_id,
        },
    }


def _mask_email(value):
    text = str(value or "")
    if "@" not in text:
        return "[masked]" if text else text
    local, domain = text.split("@", 1)
    visible = local[:1]
    return f"{visible}***@{domain}"


def _mask_phone(value):
    digits = re.sub(r"\D", "", str(value or ""))
    if not digits:
        return "" if value in {None, ""} else "[masked]"
    return "***" + digits[-4:]


def _mask_address(value):
    if value in {None, ""}:
        return value
    digest = hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:8]
    return f"[masked:{digest}]"


def mask_result_rows(rows):
    masked_columns = set()
    output = []
    for row in rows or []:
        if not isinstance(row, dict):
            output.append(row)
            continue
        masked = {}
        for key, value in row.items():
            name = str(key)
            if EMAIL_COLUMN_RE.search(name):
                masked[name] = _mask_email(value)
                masked_columns.add(name)
            elif PHONE_COLUMN_RE.search(name):
                masked[name] = _mask_phone(value)
                masked_columns.add(name)
            elif ADDRESS_COLUMN_RE.search(name):
                masked[name] = _mask_address(value)
                masked_columns.add(name)
            else:
                masked[name] = value
        output.append(masked)
    return output, sorted(masked_columns)
