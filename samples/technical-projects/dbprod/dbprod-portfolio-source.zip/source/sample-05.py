#!/usr/bin/env python3
"""Product orchestration for the governed unknown-to-answer learning loop."""

from __future__ import annotations

import bisect
import copy
import datetime as dt
import hashlib
import json
import pathlib
import re
import threading
import time
import urllib.parse
from collections import Counter

from capability_compiler import compile_question_from_capabilities
from learning_contract import (
    FAILURE_TYPES,
    LEARNING_LEVELS,
    RESOLUTION_OUTCOMES,
    build_capability_artifact,
    classify_failure_type,
    learning_level_for_failure,
    recommended_outcome,
    validate_capability_artifact,
)
from learning_loop import (
    DEFAULT_LEARNING_LOOP,
    LearningLoop,
    classify_failure,
    safe_answer_decision,
    safe_answer_decision_is_known,
    stable_id,
)
from learning_store import (
    DEFAULT_DB_PATH,
    LearningStore,
    StateConflictError,
    stable_id as store_stable_id,
    utc_now,
)
from learning_runtime import get_default_learning_store
from model_advisory_context import (
    aggregate_model_interactions,
    shadow_dispatch_status,
)
from runtime_config import TENANT_OWNER_ID
from runtime_paths import resolve_runtime_paths
from runtime_preflight import runtime_lock_sha256, runtime_source_commit
from schema_drift import drift_evidence_gate
from scripts.runtime_artifacts import (
    PROMOTION_EVIDENCE_PATH,
    ArtifactContractError,
    validate_promotion_regression_evidence,
)


RUNTIME_PATHS = resolve_runtime_paths()
OUTPUT_DIR = RUNTIME_PATHS.artifact_path("outputs/redash_schema")
DRIFT_REPORT_PATH = RUNTIME_PATHS.schema_drift_dir / "latest_drift_report.json"
REGRESSION_EVIDENCE_PATH = RUNTIME_PATHS.artifact_path(PROMOTION_EVIDENCE_PATH)

VALIDATION_GATES = (
    "artifact_schema",
    "catalog",
    "grain_cardinality",
    "owner_scope",
    "read_only_ast",
    "structural_postgresql",
    "explain",
    "bounded_live",
    "result_shape",
    "paraphrase_typo",
    "negative_adversarial",
    "regression",
    "drift",
)

TERMINAL_JOB_STATES = {
    "resolved",
    "needs_business_definition",
    "blocked_by_metadata",
    "engineering_required",
    "rejected",
}
CANDIDATE_BUILD_STATES = {
    "awaiting_steward",
    "candidate_ready",
    "validation_incomplete",
}
CANDIDATE_VALIDATION_STATES = frozenset(CANDIDATE_BUILD_STATES)
ACTIVATION_PROTECTED_STATES = frozenset(
    {"approving", "activation_pending", "activating"}
)

# These are product operating targets, not claims about an external ticketing
# system.  The workspace derives deadlines from durable job timestamps and
# labels an escalation as notified only when a matching durable notification
# exists.
LEARNING_SLA_HOURS = {1: 4, 2: 24, 3: 72}
TRANSIENT_RECOVERY_GRACE_SECONDS = 300
LEARNING_QUEUE_POLICY = {
    "awaiting_clarification": {
        "queue_id": "requester_clarification",
        "responsible_role": "analyst",
        "responsible_team": "requester",
        "next_action": "clarify",
        "required_permission": "learning:clarify",
    },
    "candidate_ready": {
        "queue_id": "steward_build",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "build",
        "required_permission": "learning:review",
    },
    "awaiting_steward": {
        "queue_id": "steward_build",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "build",
        "required_permission": "learning:review",
    },
    "validation_incomplete": {
        "queue_id": "steward_validation",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "validate",
        "required_permission": "learning:validate",
    },
    "validated": {
        "queue_id": "steward_approval",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "approve",
        "required_permission": "learning:approve",
    },
    "activation_pending": {
        "queue_id": "steward_activation",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "approve",
        "required_permission": "learning:approve",
    },
    "promoted": {
        "queue_id": "steward_retry",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "retry",
        "required_permission": "learning:retry",
    },
    "retry_failed": {
        "queue_id": "steward_retry",
        "responsible_role": "steward",
        "responsible_team": "analytics_stewards",
        "next_action": "retry",
        "required_permission": "learning:retry",
    },
    "approving": {
        "queue_id": "system_recovery",
        "responsible_role": "admin",
        "responsible_team": "runtime_operators",
        "next_action": None,
        "required_permission": None,
    },
    "activating": {
        "queue_id": "system_recovery",
        "responsible_role": "admin",
        "responsible_team": "runtime_operators",
        "next_action": None,
        "required_permission": None,
    },
    "retrying": {
        "queue_id": "system_recovery",
        "responsible_role": "admin",
        "responsible_team": "runtime_operators",
        "next_action": None,
        "required_permission": None,
    },
    "needs_business_definition": {
        "queue_id": "business_definition_external",
        "responsible_role": "steward",
        "responsible_team": "business_stewards",
        "next_action": None,
        "required_permission": None,
    },
    "blocked_by_metadata": {
        "queue_id": "engineering_external",
        "responsible_role": "admin",
        "responsible_team": "engineering",
        "next_action": None,
        "required_permission": None,
    },
    "engineering_required": {
        "queue_id": "engineering_external",
        "responsible_role": "admin",
        "responsible_team": "engineering",
        "next_action": None,
        "required_permission": None,
    },
}
FAILURE_PRIORITY_WEIGHT = {
    "permission_or_policy_failure": 36,
    "unsafe_cardinality": 34,
    "schema_drift": 32,
    "catalog_mismatch": 30,
    "execution_failure": 28,
    "unsupported_expression": 26,
    "missing_join": 22,
    "missing_provider": 20,
    "unknown_object_or_field": 18,
    "ambiguous_business_definition": 16,
    "unknown_intent": 14,
    "missing_parameter": 8,
}

CANDIDATE_BINDING_SCHEMA = "capability-candidate-binding/v1"
APPROVAL_RESERVATION_SCHEMA = "REDACTED_OPAQUE_VALUE"
APPROVAL_RESERVATION_LEASE_SECONDS = 300
LEGACY_APPROVAL_STALE_SECONDS = 300
ACTIVATION_CLAIM_SCHEMA = "capability-activation-claim/v1"
ACTIVATION_CLAIM_LEASE_SECONDS = 300
CLARIFICATION_TYPES = {
    "integer",
    "decimal",
    "text",
    "date",
    "boolean",
    "integer_list",
    "text_list",
}
CLARIFICATION_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

EVIDENCE_PATHS = (
    ("postgres_catalog", OUTPUT_DIR / "schema_catalog.json"),
    ("semantic_brain", OUTPUT_DIR / "semantic_brain.json"),
    ("schema_graph", OUTPUT_DIR / "relationship_graph.jsonl"),
    ("provider_contracts", OUTPUT_DIR / "reasoning_brain/service_provider_resolver.jsonl"),
    ("lookup_relationships", OUTPUT_DIR / "reasoning_brain/lookup_join_model.jsonl"),
    ("metadata_uncertainty", OUTPUT_DIR / "reasoning_brain/owner2_uncertainty_report.json"),
    ("schema_drift", DRIFT_REPORT_PATH),
    (
        "approved_corrections",
        RUNTIME_PATHS.state_path("learning_loop/corrections.jsonl"),
    ),
)


def _runtime_relative_path(path):
    for root in (RUNTIME_PATHS.artifact_dir, RUNTIME_PATHS.state_dir):
        try:
            return str(path.relative_to(root))
        except ValueError:
            continue
    return path.name


def _notification_id(kind, subject_type, subject_id, unique_suffix=None):
    identity = "%s:%s:%s:%s" % (
        kind,
        subject_type,
        subject_id,
        unique_suffix or "current",
    )
    return store_stable_id("notification", identity)


class LearningConflictError(ValueError):
    """Raised when an optimistic state/version precondition is stale."""


def _deep_merge(base, patch):
    output = copy.deepcopy(base)
    for key, value in (patch or {}).items():
        if isinstance(value, dict) and isinstance(output.get(key), dict):
            output[key] = _deep_merge(output[key], value)
        else:
            output[key] = copy.deepcopy(value)
    return output


def _canonical_json_bytes(value):
    """Return the exact canonical bytes used for candidate evidence binding."""
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def candidate_binding(candidate):
    """Bind validation and approval evidence to one exact candidate version."""
    candidate = copy.deepcopy(candidate or {})
    candidate_id = str(candidate.get("artifact_id") or "").strip()
    version = candidate.get("version")
    if not candidate_id or type(version) is not int or version < 1:
        raise ValueError("Capability candidate identity is incomplete")
    return {
        "schema": CANDIDATE_BINDING_SCHEMA,
        "candidate_id": candidate_id,
        "candidate_version": version,
        "candidate_sha256": hashlib.sha256(_canonical_json_bytes(candidate)).hexdigest(),
    }


def duplicate_group_id(classification):
    """Return a stable group for semantically equivalent learning gaps.

    Exact questions retain independent jobs and audit trails.  The group is an
    operational prioritization key only, derived from the generalized semantic
    shape and governed failure type rather than question text.
    """
    classification = classification if isinstance(classification, dict) else {}
    semantic_shape_id = str(classification.get("semantic_shape_id") or "").strip()
    failure_type = str(classification.get("failure_type") or "").strip()
    if not semantic_shape_id or failure_type not in FAILURE_TYPES:
        return None
    return store_stable_id(
        "learning-gap-group",
        "%s:%s:%s" % (TENANT_OWNER_ID, failure_type, semantic_shape_id),
    )


def _referenced_validation_ids(records):
    """Extract exact validation references without trusting nested shapes."""
    identifiers = set()
    for row in records or ():
        if not isinstance(row, dict):
            continue
        for value in (row.get("validation_id"), row.get("validation_run_id")):
            if isinstance(value, str) and value.strip():
                identifiers.add(value.strip())
        promotion = row.get("promotion_evidence")
        if not isinstance(promotion, dict):
            continue
        target_validation_id = promotion.get("target_validation_id")
        if isinstance(target_validation_id, str) and target_validation_id.strip():
            identifiers.add(target_validation_id.strip())
        evidence = promotion.get("evidence")
        if not isinstance(evidence, dict):
            continue
        approval = evidence.get("approval")
        if not isinstance(approval, dict):
            continue
        validation_id = approval.get("validation_id")
        if isinstance(validation_id, str) and validation_id.strip():
            identifiers.add(validation_id.strip())
    return identifiers


def _object_or_empty(value):
    return value if isinstance(value, dict) else {}


def _nonnegative_int(value, default=0):
    if isinstance(value, bool):
        return default
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def _normalized_actor(actor):
    value = str(actor or "").strip().casefold()
    if not value or len(value) > 320 or any(ord(character) < 32 for character in value):
        raise ValueError("A valid actor identity is required")
    return value


def _utc_timestamp(value):
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def _utc_deadline(now, seconds):
    parsed = _utc_timestamp(now)
    if parsed is None:
        raise ValueError("A valid UTC reservation timestamp is required")
    return (parsed + dt.timedelta(seconds=max(1, int(seconds)))).isoformat()


def _safe_learning_level(payload):
    value = _object_or_empty(payload).get("learning_level")
    if isinstance(value, bool):
        return 3
    try:
        level = int(value or 2)
    except (TypeError, ValueError):
        return 3
    return level if level in LEARNING_SLA_HOURS else 3


def _approval_reservation_status(job, now):
    now_timestamp = _utc_timestamp(now)
    if now_timestamp is None:
        raise ValueError("A valid UTC reconciliation timestamp is required")
    payload = _object_or_empty((job or {}).get("payload"))
    reservation = payload.get("approval_reservation")
    lease_owner = (job or {}).get("lease_owner")
    lease_expires_at = (job or {}).get("lease_expires_at")
    if reservation is not None or lease_owner is not None or lease_expires_at is not None:
        if not isinstance(reservation, dict):
            return "unproven_reservation"
        reservation_id = reservation.get("reservation_id")
        reserved_at = _utc_timestamp(reservation.get("reserved_at"))
        expires_at = _utc_timestamp(reservation.get("lease_expires_at"))
        if (
            reservation.get("schema") != APPROVAL_RESERVATION_SCHEMA
            or not isinstance(reservation_id, str)
            or not reservation_id.strip()
            or lease_owner != reservation_id
            or lease_expires_at != reservation.get("lease_expires_at")
            or reserved_at is None
            or expires_at is None
            or expires_at <= reserved_at
        ):
            return "unproven_reservation"
        return (
            "expired_reservation"
            if expires_at <= now_timestamp
            else "live_reservation"
        )
    updated_at = _utc_timestamp((job or {}).get("updated_at"))
    if updated_at is None:
        return "unproven_reservation"
    if updated_at <= now_timestamp - dt.timedelta(
        seconds=LEGACY_APPROVAL_STALE_SECONDS
    ):
        return "stale_legacy_reservation"
    return "recent_legacy_reservation"


def _activation_claim_status(job, now):
    now_timestamp = _utc_timestamp(now)
    if now_timestamp is None:
        raise ValueError("A valid UTC activation recovery timestamp is required")
    payload = _object_or_empty((job or {}).get("payload"))
    claim = _object_or_empty(payload.get("activation")).get("claim")
    if not isinstance(claim, dict):
        return "unproven_activation_claim"
    claimed_at = _utc_timestamp(claim.get("claimed_at"))
    expires_at = _utc_timestamp(claim.get("lease_expires_at"))
    claim_id = claim.get("claim_id")
    if (
        claim.get("schema") != ACTIVATION_CLAIM_SCHEMA
        or not isinstance(claim_id, str)
        or not claim_id.strip()
        or (job or {}).get("lease_owner") != claim_id
        or (job or {}).get("lease_expires_at") != claim.get("lease_expires_at")
        or claimed_at is None
        or expires_at is None
        or expires_at <= claimed_at
    ):
        return "unproven_activation_claim"
    return (
        "expired_activation_claim"
        if expires_at <= now_timestamp
        else "live_activation_claim"
    )


def _job_operational_snapshot(job, *, now=None, duplicate_job_count=1, escalation=None):
    """Derive an honest, executable-text-free operating view for one job."""
    job = _object_or_empty(job)
    payload = _object_or_empty(job.get("payload"))
    state = str(job.get("state") or "unknown")
    policy = LEARNING_QUEUE_POLICY.get(state) or {
        "queue_id": "closed_history" if state in TERMINAL_JOB_STATES else "unclassified",
        "responsible_role": None,
        "responsible_team": None,
        "next_action": None,
        "required_permission": None,
    }
    requester = str(payload.get("requester") or "").strip() or None
    responsible_actor = requester if state == "awaiting_clarification" else None
    level = _safe_learning_level(payload)
    target_hours = LEARNING_SLA_HOURS[level]
    current = _utc_timestamp(now or utc_now())
    created = _utc_timestamp(job.get("created_at"))
    updated = _utc_timestamp(job.get("updated_at"))
    lease_expires = _utc_timestamp(job.get("lease_expires_at"))
    recovery_proof = "not_applicable"
    transient_in_progress = False
    if state == "approving":
        recovery_proof = _approval_reservation_status(job, current)
        transient_in_progress = recovery_proof in {
            "live_reservation",
            "recent_legacy_reservation",
        }
        if recovery_proof == "recent_legacy_reservation" and updated:
            lease_expires = updated + dt.timedelta(
                seconds=LEGACY_APPROVAL_STALE_SECONDS
            )
    elif state == "activating":
        recovery_proof = _activation_claim_status(job, current)
        transient_in_progress = recovery_proof == "live_activation_claim"
    elif state == "retrying" and current and updated:
        recovery_proof = "bounded_retry_grace"
        lease_expires = updated + dt.timedelta(
            seconds=TRANSIENT_RECOVERY_GRACE_SECONDS
        )
        transient_in_progress = current < lease_expires
        if not transient_in_progress:
            recovery_proof = "retry_grace_expired"
    if transient_in_progress:
        policy = {
            "queue_id": "system_in_progress",
            "responsible_role": "admin",
            "responsible_team": "runtime_operators",
            "next_action": None,
            "required_permission": None,
        }
    terminal = state in TERMINAL_JOB_STATES
    due = created + dt.timedelta(hours=target_hours) if created else None
    observed = updated if terminal and updated else current
    age_hours = (
        max(0.0, (observed - created).total_seconds() / 3600.0)
        if observed and created
        else None
    )
    overdue_by_hours = (
        max(0.0, (current - due).total_seconds() / 3600.0)
        if current and due and not terminal
        else 0.0
    )
    remaining_hours = (
        (due - current).total_seconds() / 3600.0
        if current and due and not terminal
        else None
    )
    if created is None:
        sla_status = "unavailable"
    elif terminal:
        completion = "resolved" if state == "resolved" else "routed"
        sla_status = "%s_%s" % (
            completion,
            "within_target" if observed <= due else "breached",
        )
    elif overdue_by_hours > 0:
        sla_status = "overdue"
    elif remaining_hours is not None and remaining_hours <= max(1.0, target_hours * 0.25):
        sla_status = "due_soon"
    else:
        sla_status = "within_target"

    try:
        occurrences = max(0, int(payload.get("occurrences") or 0))
    except (TypeError, ValueError):
        occurrences = 0
    try:
        duplicate_count = max(1, int(duplicate_job_count or 1))
    except (TypeError, ValueError):
        duplicate_count = 1
    recurrence_score = min(20, max(0, occurrences - 1) * 4)
    duplicate_score = min(12, max(0, duplicate_count - 1) * 3)
    level_score = {1: 4, 2: 10, 3: 18}[level]
    overdue_score = 30 if sla_status == "overdue" else 12 if sla_status == "due_soon" else 0
    terminal_discount = 35 if terminal else 0
    priority_score = max(
        0,
        min(
            100,
            int(FAILURE_PRIORITY_WEIGHT.get(payload.get("failure_type"), 20))
            + level_score
            + recurrence_score
            + duplicate_score
            + overdue_score
            - terminal_discount,
        ),
    )
    priority_band = (
        "urgent"
        if priority_score >= 75
        else "high"
        if priority_score >= 50
        else "normal"
        if priority_score >= 25
        else "low"
    )
    escalation_required = sla_status == "overdue" and not transient_in_progress
    escalation_recipient = (
        responsible_actor
        or policy.get("responsible_team")
        or policy.get("responsible_role")
        or "runtime_operators"
    )
    routing_generation = store_stable_id(
        "sla-route",
        "%s:%s:%s:%s" % (
            str(job.get("job_id") or ""),
            due.isoformat() if due else "unknown",
            str(policy.get("queue_id") or "unclassified"),
            str(escalation_recipient),
        ),
    )
    escalation_record = escalation if isinstance(escalation, dict) else None
    escalation_status = (
        "acknowledged"
        if escalation_record and escalation_record.get("status") == "delivered"
        else "notified"
        if escalation_record
        else "required"
        if escalation_required
        else "not_required"
    )
    job_id = str(job.get("job_id") or "")
    encoded_job_id = urllib.parse.quote(job_id, safe="")
    return {
        "priority": {
            "score": priority_score,
            "band": priority_band,
            "factors": {
                "failure_risk": int(
                    FAILURE_PRIORITY_WEIGHT.get(payload.get("failure_type"), 20)
                ),
                "learning_level": level_score,
                "recurrence": recurrence_score,
                "duplicate_group": duplicate_score,
                "sla_urgency": overdue_score,
                "terminal_completion_discount": -terminal_discount,
            },
        },
        "responsibility": {
            "assignment_type": "requester" if responsible_actor else "role_policy",
            "actor_id": responsible_actor,
            "role": policy.get("responsible_role"),
            "team": policy.get("responsible_team"),
        },
        "queue": {
            "queue_id": policy.get("queue_id"),
            "next_action": policy.get("next_action"),
            "required_permission": policy.get("required_permission"),
            "in_product_action": bool(policy.get("next_action")),
        },
        "sla": {
            "learning_level": level,
            "target_hours": target_hours,
            "status": sla_status,
            "started_at": created.isoformat() if created else None,
            "due_at": due.isoformat() if due else None,
            "age_hours": age_hours,
            "remaining_hours": remaining_hours,
            "overdue_by_hours": overdue_by_hours,
        },
        "escalation": {
            "required": escalation_required,
            "status": escalation_status,
            "routing_generation": routing_generation,
            "notification_id": (
                escalation_record.get("notification_id")
                if escalation_record
                else None
            ),
        },
        "recovery": {
            "state": (
                "in_progress"
                if transient_in_progress
                else "recovery_required"
                if state in {"approving", "activating", "retrying"}
                else "not_applicable"
            ),
            "check_after": (
                lease_expires.isoformat()
                if transient_in_progress and lease_expires
                else None
            ),
            "proof": recovery_proof,
        },
        "links": {
            "learning_job": (
                "/#learning/job/%s" % encoded_job_id if encoded_job_id else None
            ),
            "learning_job_api": (
                "/api/learning/jobs/%s" % encoded_job_id if encoded_job_id else None
            ),
        },
    }


def _clarification_type(name, candidate):
    compiler = (candidate or {}).get("compiler") or {}
    for spec in compiler.get("parameters") or []:
        if isinstance(spec, dict) and spec.get("name") == name:
            value_type = str(spec.get("type") or "")
            if value_type in CLARIFICATION_TYPES:
                return value_type
    if name.endswith("_id") or name in {"year", "quarter", "month"}:
        return "integer"
    if name.endswith("_date") or name in {"date", "start_date", "end_date"}:
        return "date"
    return "text"


def _clarification_contract(classification, candidate):
    ambiguity = (classification or {}).get("ambiguity") or {}
    names = sorted(
        {
            str(name).strip().lower()
            for name in ambiguity.get("missing_parameters") or []
            if CLARIFICATION_NAME_RE.fullmatch(str(name).strip().lower())
        }
    )
    return {
        "schema": "learning-clarification/v1",
        "status": "awaiting_input" if names else "not_required",
        "parameters": [
            {
                "name": name,
                "type": _clarification_type(name, candidate),
                "required": True,
            }
            for name in names
        ],
        "values_persisted": False,
        "requester_owned": True,
    }


def _coerce_clarification(value, value_type):
    """Validate a transient clarification without returning persistence metadata."""
    if value_type == "integer":
        text = str(value).strip()
        if not re.fullmatch(r"[-+]?\d+", text):
            raise ValueError("expected integer")
        return str(int(text))
    if value_type == "decimal":
        text = str(value).strip()
        if not re.fullmatch(r"[-+]?(?:\d+(?:\.\d+)?|\.\d+)", text):
            raise ValueError("expected decimal")
        return text
    if value_type == "date":
        try:
            return dt.date.fromisoformat(str(value).strip()).isoformat()
        except ValueError as exc:
            raise ValueError("expected ISO date") from exc
    if value_type == "boolean":
        if isinstance(value, bool):
            return "true" if value else "false"
        normalized = str(value).strip().casefold()
        if normalized in {"true", "yes", "1"}:
            return "true"
        if normalized in {"false", "no", "0"}:
            return "false"
        raise ValueError("expected boolean")
    if value_type in {"integer_list", "text_list"}:
        values = value if isinstance(value, list) else str(value).split(",")
        if not 1 <= len(values) <= 100:
            raise ValueError("expected a bounded list")
        child_type = "integer" if value_type == "integer_list" else "text"
        return ", ".join(_coerce_clarification(child, child_type) for child in values)
    if value_type == "text":
        text = str(value).strip()
        if not text or len(text) > 200 or any(ord(character) < 32 for character in text):
            raise ValueError("expected bounded text")
        return text
    raise ValueError("unsupported clarification type")


def _clarified_question(question, submitted):
    fragments = []
    for row in submitted:
        label = row["name"].replace("_", " ")
        value = row["value"]
        if row["type"] in {"text", "text_list"}:
            value = json.dumps(value, ensure_ascii=True)
        fragments.append("%s: %s" % (label, value))
    return "%s; %s" % (str(question).rstrip(" ;"), "; ".join(fragments))


def _result_summary(result):
    result = result or {}
    decision = safe_answer_decision(result)
    resolved = result.get("resolved_intent") or {}
    if not isinstance(resolved, dict):
        resolved = {}
    return {
        "status": result.get("status"),
        "intent": resolved.get("intent") or resolved.get("matched_intent"),
        "provider": resolved.get("provider"),
        "validation_status": (result.get("validation") or {}).get("status"),
        "semantic_validation_status": (result.get("semantic_validation") or {}).get("status"),
        "live_execution_status": (result.get("live_execution") or {}).get("status"),
        "execution_id": (result.get("live_execution") or {}).get("execution_id"),
        "answer_state": (result.get("certainty") or {}).get("answer_state"),
        "row_count": result.get("row_count"),
        "schema_drift_status": (result.get("schema_drift") or {}).get("status"),
        "capability_validation": result.get("capability_validation"),
        "error_type": result.get("error_type"),
        "error": result.get("error"),
        "safe_answer_decision": decision,
    }


def _status(value):
    if isinstance(value, dict):
        value = value.get("status")
    value = str(value or "").lower()
    return "passed" if value in {"passed", "executed", "live_revalidated", "unchanged", "not_impacted"} else value or "not_run"


def _latest_by_capability(rows):
    latest = {}
    for row in rows:
        capability_id = row.get("capability_id")
        if not capability_id:
            continue
        if capability_id not in latest or int(row.get("version") or 0) > int(latest[capability_id].get("version") or 0):
            latest[capability_id] = row
    return latest


def _open_duplicate_groups(jobs):
    grouped = {}
    for row in jobs:
        if row.get("state") in TERMINAL_JOB_STATES:
            continue
        payload = _object_or_empty(row.get("payload"))
        group_id = payload.get("duplicate_group_id") or duplicate_group_id(
            payload.get("classification")
        )
        if not group_id:
            continue
        group = grouped.setdefault(
            group_id,
            {
                "duplicate_group_id": group_id,
                "job_ids": [],
                "states": Counter(),
                "occurrences": 0,
                "latest_updated_at": None,
            },
        )
        group["job_ids"].append(row.get("job_id"))
        group["states"][str(row.get("state") or "unknown")] += 1
        group["occurrences"] += _nonnegative_int(payload.get("occurrences"))
        updated_at = row.get("updated_at")
        if updated_at and (
            group["latest_updated_at"] is None
            or updated_at > group["latest_updated_at"]
        ):
            group["latest_updated_at"] = updated_at
    duplicates = []
    for group in grouped.values():
        if len(group["job_ids"]) < 2:
            continue
        duplicates.append(
            {
                **group,
                "job_ids": sorted(group["job_ids"]),
                "job_count": len(group["job_ids"]),
                "states": {
                    key: group["states"][key] for key in sorted(group["states"])
                },
            }
        )
    return sorted(
        duplicates,
        key=lambda row: (
            -int(row.get("job_count") or 0),
            str(row.get("duplicate_group_id") or ""),
        ),
    )


class LearningService:
    """Coordinates the compiler loop, durable state, proof gates, and review UX."""

    def __init__(
        self,
        store=None,
        loop=None,
        db_path=DEFAULT_DB_PATH,
        migrate_legacy=True,
        drift_report_path=None,
        regression_evidence_path=None,
    ):
        if store is not None:
            self.store = store
        elif db_path != DEFAULT_DB_PATH:
            self.store = LearningStore(db_path)
        else:
            self.store = get_default_learning_store()
        if loop is not None:
            self.loop = loop
        elif getattr(DEFAULT_LEARNING_LOOP, "repository", None) is self.store:
            self.loop = DEFAULT_LEARNING_LOOP
        else:
            self.loop = LearningLoop(repository=self.store)
        self.drift_report_path = (
            DRIFT_REPORT_PATH
            if drift_report_path is None
            else pathlib.Path(drift_report_path)
        )
        self.regression_evidence_path = (
            REGRESSION_EVIDENCE_PATH
            if regression_evidence_path is None
            else pathlib.Path(regression_evidence_path)
        )
        self.lock = threading.RLock()
        self._metrics_cache = None
        self._audit_metrics_state = None
        self._metrics_generation = 0
        self._metrics_refresh_thread = None
        self._metrics_refresh_error = None
        if migrate_legacy:
            self.migrate_legacy_records()

    @staticmethod
    def job_id_for_feedback(feedback_id):
        return store_stable_id(
            "learning-job", "%s:%s" % (TENANT_OWNER_ID, feedback_id)
        )

    @staticmethod
    def capability_id_for_artifact(artifact):
        return stable_id(
            "capability",
            "%s:%s:%s"
            % (
                TENANT_OWNER_ID,
                artifact.get("semantic_shape_id")
                or (artifact.get("provenance") or {}).get("semantic_shape_id"),
                artifact.get("kind") or "typed_semantic_compiler",
            ),
        )

    @staticmethod
    def _assert_expected_state(job, expected_state):
        if expected_state is None:
            return
        current = str((job or {}).get("state") or "")
        if str(expected_state) != current:
            raise LearningConflictError(
                "stale learning job state: expected %s, current %s"
                % (expected_state, current)
            )

    def evidence_inventory(self):
        rows = []
        for name, path in EVIDENCE_PATHS:
            if name == "schema_drift":
                path = self.drift_report_path
            exists = path.exists()
            row = {
                "name": name,
                "available": exists,
                "path": _runtime_relative_path(path),
            }
            if exists:
                stat = path.stat()
                row.update(
                    {
                        "size_bytes": stat.st_size,
                        "modified_at": dt.datetime.fromtimestamp(
                            stat.st_mtime, tz=dt.timezone.utc
                        ).isoformat(),
                    }
                )
            rows.append(row)
        return rows

    def current_drift_evidence(self):
        try:
            report = json.loads(self.drift_report_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            report = None
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            report = "invalid"
        return drift_evidence_gate(report)

    def migrate_legacy_records(self):
        """Idempotently import prior JSONL lifecycle state into the durable store."""
        imported_jobs = 0
        imported_events = 0
        imported_capabilities = 0
        try:
            records = self.loop.list_unknown(state=None, limit=1000)
        except Exception:
            records = []
        for record in records:
            if int(record.get("unknown_occurrences") or 0) < 1:
                continue
            feedback_id = record.get("feedback_id")
            if not feedback_id:
                continue
            job_id = self.job_id_for_feedback(feedback_id)
            if not self.store.get_learning_job(job_id):
                classification = record.get("classification") or classify_failure(
                    record.get("question"),
                    {"status": record.get("last_status") or "unresolved"},
                )
                if not classification.get("failure_type"):
                    failure_type = classify_failure_type(
                        {"status": record.get("last_status")}, classification
                    )
                    classification.update(
                        {
                            "failure_type": failure_type,
                            "learning_level": learning_level_for_failure(failure_type),
                            "recommended_outcome": recommended_outcome(failure_type),
                        }
                    )
                candidate = record.get("candidate_definition") or build_capability_artifact(
                    classification,
                    provenance=["legacy_learning_loop"],
                )
                candidate.setdefault("kind", "typed_semantic_compiler")
                candidate.setdefault("semantic_shape_id", classification.get("semantic_shape_id"))
                candidate.setdefault("semantic_shape", classification.get("semantic_shape") or {})
                candidate.setdefault("scope", "tenant")
                candidate.setdefault(
                    "safety_contract",
                    {
                        "stores_executable_sql": False,
                        "compile_per_request": True,
                        "REDACTED_OPAQUE_VALUE": True,
                        "owner_scope_validation_required": True,
                        "REDACTED_OPAQUE_VALUE": True,
                    },
                )
                binding = candidate_binding(candidate)
                legacy_state = record.get("state")
                state_map = {
                    "open": "awaiting_steward",
                    "classified": "awaiting_steward",
                    "corrected": "awaiting_steward",
                    "candidate": "awaiting_steward",
                    "validated": "validated",
                    "promoted": "promoted",
                    "resolved": "resolved",
                }
                state = state_map.get(legacy_state, self._initial_state(classification))
                self.store.upsert_learning_job(
                    {
                        "job_id": job_id,
                        "owner_id": TENANT_OWNER_ID,
                        "feedback_id": feedback_id,
                        "job_type": "capability_learning",
                        "state": state,
                        "priority": min(100, int(record.get("occurrences") or 1) * 10),
                        "payload": {
                            "contract_version": "unknown-to-capability/v1",
                            "question": record.get("question"),
                            "classification": classification,
                            "failure_type": classification.get("failure_type"),
                            "learning_level": classification.get("learning_level"),
                            "recommended_outcome": classification.get("recommended_outcome"),
                            "duplicate_group_id": duplicate_group_id(classification),
                            "candidate": candidate,
                            "candidate_binding": binding,
                            "evidence_inventory": self.evidence_inventory(),
                            "occurrences": int(record.get("occurrences") or 1),
                            "unknown_occurrences": int(record.get("unknown_occurrences") or 1),
                            "waiting_questions": [feedback_id],
                            "requester": "legacy_local_user",
                            "promoted_capability": (
                                {
                                    "capability_id": record.get("capability_id"),
                                    "version": record.get("promoted_capability_version"),
                                }
                                if record.get("capability_id")
                                else None
                            ),
                            "migrated_from": "jsonl_learning_loop",
                        },
                        "result": (
                            {"outcome": "resolved", "migrated": True}
                            if state == "resolved"
                            else None
                        ),
                        "created_at": record.get("first_unknown_at") or record.get("first_seen_at"),
                    }
                )
                imported_jobs += 1
            try:
                snapshot = self.loop.lifecycle_snapshot(feedback_id)
            except Exception:
                snapshot = {}
            for event in snapshot.get("transitions") or []:
                migrated = dict(event)
                migrated["event_id"] = event.get("transition_id")
                migrated["actor"] = "legacy_migration"
                migrated["occurred_at"] = event.get("created_at")
                try:
                    result = self.store.append_lifecycle_event(migrated)
                    imported_events += int(result.status == "inserted")
                except Exception:
                    # A conflicting historical event is left untouched and can
                    # be inspected in its source JSONL artifact.
                    continue
        for capability in self.loop.capability_history():
            try:
                result = self._persist_capability(capability)
                imported_capabilities += int(bool(result))
            except Exception:
                continue
        return {
            "status": "migrated",
            "jobs": imported_jobs,
            "events": imported_events,
            "capabilities": imported_capabilities,
        }

    @staticmethod
    def _initial_state(classification):
        if classification.get("failure_type") == "missing_parameter":
            return "awaiting_clarification"
        level = int(classification.get("learning_level") or 2)
        if level == 1:
            return "candidate_ready"
        if level == 2:
            return "awaiting_steward"
        return "engineering_required"

    def _append_lifecycle(self, feedback_id, from_state, to_state, reason, actor, evidence=None):
        now = utc_now()
        return self.store.append_lifecycle_event(
            {
                "event_id": store_stable_id(
                    "learning-transition",
                    "%s:%s:%s:%s" % (feedback_id, from_state, to_state, now),
                ),
                "owner_id": TENANT_OWNER_ID,
                "feedback_id": feedback_id,
                "from_state": from_state,
                "to_state": to_state,
                "reason": reason,
                "evidence": evidence or {},
                "actor": actor,
                "occurred_at": now,
            }
        ).record

    def _audit(self, action, actor, subject_type, subject_id, outcome="succeeded", details=None):
        now = utc_now()
        result = self.store.append_audit_event(
            {
                "event_id": store_stable_id(
                    "audit", "%s:%s:%s:%s" % (action, subject_id, outcome, now)
                ),
                "owner_id": TENANT_OWNER_ID,
                "action": action,
                "actor": actor,
                "subject_type": subject_type,
                "subject_id": subject_id,
                "outcome": outcome,
                "details": details or {},
                "occurred_at": now,
            }
        ).record
        # Query decisions and shadow-model observations may be reflected in
        # monitoring with the bounded snapshot lag. Governance mutations must
        # invalidate immediately so operators never act on stale state.
        if action != "query_execution_decision":
            self._invalidate_metrics_cache()
        return result

    def _invalidate_metrics_cache(self):
        with self.lock:
            self._metrics_generation += 1
            if self._metrics_cache is not None:
                self._metrics_cache["dirty"] = True

    def _notify(
        self,
        kind,
        subject_type,
        subject_id,
        payload,
        recipient=None,
        unique_suffix=None,
        *,
        return_write_result=False,
        expected_status=None,
    ):
        notification_id = _notification_id(
            kind,
            subject_type,
            subject_id,
            unique_suffix,
        )
        result = self.store.upsert_notification(
            {
                "notification_id": notification_id,
                "owner_id": TENANT_OWNER_ID,
                "kind": kind,
                "status": "pending",
                "recipient": recipient,
                "subject_type": subject_type,
                "subject_id": subject_id,
                "payload": payload,
                "available_at": utc_now(),
            },
            expected_status=expected_status,
        )
        if result.status != "unchanged":
            # Notifications affect queue and pending-count metrics. This audit
            # must trail the notification commit so another service cannot
            # advance its metrics cursor past a notification it did not scan.
            # Dirty the local snapshot first: if the audit backend fails after
            # the durable notification commit, this process must still rebuild
            # from store truth instead of publishing stale pending counts.
            self._invalidate_metrics_cache()
            self._audit(
                "notification_upserted",
                "learning_system",
                "notification",
                notification_id,
                details={
                    "kind": kind,
                    "write_status": result.status,
                    "notification_subject_type": subject_type,
                    "notification_subject_id": subject_id,
                },
            )
        return result if return_write_result else result.record

    def _write_job(
        self,
        job,
        *,
        actor,
        reason,
        prior_state=None,
        audit_action="learning_job_updated",
        expected_state=None,
        expected_lease_owner=None,
        expected_updated_at=None,
        lifecycle_evidence=None,
        audit_details=None,
    ):
        with self.lock:
            return self._write_job_locked(
                job,
                actor=actor,
                reason=reason,
                prior_state=prior_state,
                audit_action=audit_action,
                expected_state=expected_state,
                expected_lease_owner=expected_lease_owner,
                expected_updated_at=expected_updated_at,
                lifecycle_evidence=lifecycle_evidence,
                audit_details=audit_details,
            )

    def _write_job_locked(
        self,
        job,
        *,
        actor,
        reason,
        prior_state=None,
        audit_action="learning_job_updated",
        expected_state=None,
        expected_lease_owner=None,
        expected_updated_at=None,
        lifecycle_evidence=None,
        audit_details=None,
    ):
        try:
            expected = {"expected_state": expected_state}
            if expected_lease_owner is not None:
                expected["expected_lease_owner"] = expected_lease_owner
            if expected_updated_at is not None:
                expected["expected_updated_at"] = expected_updated_at
            result = self.store.upsert_learning_job(job, **expected)
        except StateConflictError as exc:
            raise LearningConflictError(str(exc)) from exc
        self._invalidate_metrics_cache()
        stored = result.record
        if prior_state != stored.get("state"):
            evidence = {"job_id": stored.get("job_id")}
            evidence.update(copy.deepcopy(lifecycle_evidence or {}))
            self._append_lifecycle(
                stored.get("feedback_id"),
                prior_state,
                stored.get("state"),
                reason,
                actor,
                evidence,
            )
        details = {
            "write_status": result.status,
            "state": stored.get("state"),
            "feedback_id": stored.get("feedback_id"),
            "reason": reason,
        }
        details.update(copy.deepcopy(audit_details or {}))
        self._audit(
            audit_action,
            actor,
            "learning_job",
            stored.get("job_id"),
            details=details,
        )
        return stored

    @staticmethod
    def _immutable_learning_level_floor(payload):
        """Return the durable job's fail-closed approval-tier floor."""
        payload = payload or {}
        classification = payload.get("classification") or {}
        if not isinstance(classification, dict):
            return 3
        failure_types = [
            value
            for value in (
                payload.get("failure_type"),
                classification.get("failure_type"),
            )
            if value is not None
        ]
        if not failure_types or any(
            not isinstance(value, str) for value in failure_types
        ):
            return 3
        floor = max(learning_level_for_failure(value) for value in failure_types)
        for stored_level in (
            payload.get("learning_level"),
            classification.get("learning_level"),
        ):
            if stored_level is None:
                continue
            if isinstance(stored_level, bool):
                return 3
            try:
                stored_level = int(stored_level)
            except (TypeError, ValueError):
                return 3
            if stored_level not in LEARNING_LEVELS:
                return 3
            floor = max(floor, stored_level)
        return floor

    @classmethod
    def _enforce_candidate_learning_level_floor(cls, payload, candidate):
        level = (candidate.get("approval") or {}).get("learning_level")
        if type(level) is not int or level not in LEARNING_LEVELS:
            raise ValueError("Capability candidate has an invalid approval tier")
        floor = cls._immutable_learning_level_floor(payload)
        if level < floor:
            raise ValueError(
                "Capability candidate approval tier cannot be below immutable "
                "job floor %s" % floor
            )
        return level

    def capture_outcome(self, question, result, feedback, actor="learning_system"):
        """Persist every unknown and close its job after a later safe answer."""
        actor = _normalized_actor(actor)
        feedback = feedback or {}
        feedback_id = feedback.get("feedback_id")
        if not feedback_id:
            return None
        decision = safe_answer_decision(result)
        unknown = not safe_answer_decision_is_known(decision)
        job_id = self.job_id_for_feedback(feedback_id)
        with self.lock:
            existing = self.store.get_learning_job(job_id)
            # Approval and activation are fenced state transitions.  A repeated
            # answer/capture may observe them, but must never rewrite their
            # immutable evidence or clear their lease with an unfenced upsert.
            if existing and existing.get("state") in ACTIVATION_PROTECTED_STATES:
                return self.public_job(existing)
            if not unknown:
                if not existing:
                    return None
                payload = dict(existing.get("payload") or {})
                # Promotion is admitted only through the governed approval and
                # activation state machine. Caller/legacy feedback can never
                # supply a durable capability.
                promoted = payload.get("promoted_capability") or {}
                payload["last_result"] = _result_summary(result)
                payload["resolved_at"] = utc_now()
                job = {
                    **existing,
                    "state": "resolved",
                    "payload": payload,
                    "result": {
                        "outcome": "resolved",
                        "answer_status": result.get("status"),
                        "capability_id": (promoted or {}).get("capability_id"),
                        "capability_version": (promoted or {}).get("version"),
                    },
                    "error": None,
                }
                try:
                    stored = self._write_job(
                        job,
                        actor=actor,
                        reason="REDACTED_OPAQUE_VALUE",
                        prior_state=existing.get("state"),
                        audit_action="learning_job_resolved",
                        expected_state=existing.get("state"),
                    )
                except LearningConflictError:
                    current = self.store.get_learning_job(job_id)
                    if current and current.get("state") in ACTIVATION_PROTECTED_STATES:
                        return self.public_job(current)
                    raise
                self._notify(
                    "learning_job_resolved",
                    "learning_job",
                    job_id,
                    {
                        "job_id": job_id,
                        "feedback_id": feedback_id,
                        "answer_status": result.get("status"),
                    },
                    recipient=(payload.get("requester") or "analytics_stewards"),
                    unique_suffix=str(stored.get("updated_at")),
                )
                return self.public_job(stored)

            classification = feedback.get("classification") or classify_failure(question, result)
            if not classification.get("failure_type"):
                failure_type = classify_failure_type(result, classification)
                classification = {
                    **classification,
                    "failure_type": failure_type,
                    "learning_level": learning_level_for_failure(failure_type),
                    "recommended_outcome": recommended_outcome(failure_type),
                }
            evidence = self.evidence_inventory()
            artifact = build_capability_artifact(
                classification,
                provenance=[row["name"] for row in evidence if row.get("available")],
            )
            artifact.update(
                {
                    "kind": "typed_semantic_compiler",
                    "semantic_shape_id": classification.get("semantic_shape_id"),
                    "semantic_shape": classification.get("semantic_shape") or {},
                    "scope": "tenant",
                    "safety_contract": {
                        "stores_executable_sql": False,
                        "compile_per_request": True,
                        "REDACTED_OPAQUE_VALUE": True,
                        "owner_scope_validation_required": True,
                        "REDACTED_OPAQUE_VALUE": True,
                    },
                }
            )
            prior_payload = (existing or {}).get("payload") or {}
            occurrences = int(prior_payload.get("occurrences") or 0) + 1
            if existing and existing.get("state") in {
                "awaiting_steward",
                "candidate_ready",
                "validation_incomplete",
                "validated",
            }:
                state = existing.get("state")
            elif existing and existing.get("state") in {"promoted", "retrying"}:
                state = "retry_failed"
            else:
                state = self._initial_state(classification)
            payload = {
                **prior_payload,
                "contract_version": "unknown-to-capability/v1",
                "question": str(question),
                "classification": classification,
                "failure_type": classification.get("failure_type"),
                "learning_level": classification.get("learning_level"),
                "recommended_outcome": classification.get("recommended_outcome"),
                "duplicate_group_id": duplicate_group_id(classification),
                "candidate": prior_payload.get("candidate") or artifact,
                "candidate_binding": (
                    prior_payload.get("candidate_binding")
                    or candidate_binding(prior_payload.get("candidate") or artifact)
                ),
                "evidence_inventory": evidence,
                "last_result": _result_summary(result),
                "occurrences": occurrences,
                "unknown_occurrences": int(feedback.get("occurrences") or occurrences),
                "waiting_questions": [feedback_id],
                "requester": prior_payload.get("requester") or actor,
            }
            payload["clarification"] = (
                prior_payload.get("clarification")
                or _clarification_contract(classification, payload["candidate"])
            )
            job = {
                **(existing or {}),
                "job_id": job_id,
                "owner_id": TENANT_OWNER_ID,
                "feedback_id": feedback_id,
                "job_type": "capability_learning",
                "state": state,
                "priority": min(100, occurrences * 10),
                "payload": payload,
                "result": None,
                "error": None,
            }
            try:
                stored = self._write_job(
                    job,
                    actor=actor,
                    reason="REDACTED_OPAQUE_VALUE",
                    prior_state=(existing or {}).get("state"),
                    audit_action="unknown_question_captured",
                    expected_state=(existing or {}).get("state"),
                )
            except LearningConflictError:
                current = self.store.get_learning_job(job_id)
                if current and current.get("state") in ACTIVATION_PROTECTED_STATES:
                    return self.public_job(current)
                raise
            self._notify(
                "learning_job_requires_action",
                "learning_job",
                job_id,
                {
                    "job_id": job_id,
                    "feedback_id": feedback_id,
                    "failure_type": classification.get("failure_type"),
                    "learning_level": classification.get("learning_level"),
                    "state": state,
                    "occurrences": occurrences,
                },
                recipient=(
                    actor
                    if classification.get("failure_type") == "missing_parameter"
                    else "analytics_stewards"
                    if int(classification.get("learning_level") or 2) == 2
                    else "engineering"
                ),
            )
            return self.public_job(stored)

    @staticmethod
    def public_job(job, *, now=None, duplicate_job_count=1, escalation=None):
        if not job:
            return None
        payload = _object_or_empty(job.get("payload"))
        operations = _job_operational_snapshot(
            job,
            now=now,
            duplicate_job_count=duplicate_job_count,
            escalation=escalation,
        )
        return {
            "job_id": job.get("job_id"),
            "feedback_id": job.get("feedback_id"),
            "state": job.get("state"),
            "priority": job.get("priority"),
            "attempt_count": job.get("attempt_count"),
            "created_at": job.get("created_at"),
            "updated_at": job.get("updated_at"),
            "question": payload.get("question"),
            "failure_type": payload.get("failure_type"),
            "learning_level": payload.get("learning_level"),
            "recommended_outcome": payload.get("recommended_outcome"),
            "duplicate_group_id": payload.get("duplicate_group_id")
            or duplicate_group_id(payload.get("classification")),
            "occurrences": payload.get("occurrences"),
            "classification": payload.get("classification"),
            "candidate": payload.get("candidate"),
            "candidate_binding": payload.get("candidate_binding"),
            "validation_id": payload.get("validation_id"),
            "validator_id": payload.get("validator_id"),
            "clarification": payload.get("clarification"),
            "evidence_inventory": payload.get("evidence_inventory"),
            "promoted_capability": payload.get("promoted_capability"),
            "activation": payload.get("activation"),
            "drift_invalidation": payload.get("drift_invalidation"),
            "last_result": payload.get("last_result"),
            "result": job.get("result"),
            "error": job.get("error"),
            "operations": operations,
            "links": operations.get("links"),
        }

    def _all_learning_jobs(self, *, page_size=1000):
        """Read every owner-scoped job through the durable cursor contract.

        The legacy list method intentionally caps interactive reads at 1,000.
        Product-wide metrics, provenance, drift handling, and duplicate counts
        must not silently inherit that presentation limit.
        """
        try:
            page_size = max(1, min(int(page_size), 1000))
        except (TypeError, ValueError) as exc:
            raise ValueError("learning-job page size must be an integer") from exc
        jobs = []
        after_job_id = None
        while True:
            page = self.store.list_learning_jobs_page(
                after_job_id=after_job_id,
                limit=page_size,
            )
            if not page:
                return jobs
            for row in page:
                job_id = str((row or {}).get("job_id") or "")
                if not job_id or (
                    after_job_id is not None and job_id <= after_job_id
                ):
                    raise LearningConflictError(
                        "Learning-job cursor page is not strictly ordered"
                    )
                jobs.append(row)
                after_job_id = job_id

    def _all_capability_versions(self):
        rows = self.store.snapshot_capability_versions()
        prior = None
        for row in rows:
            capability_id = str((row or {}).get("capability_id") or "")
            version = (row or {}).get("version")
            if not capability_id or type(version) is not int:
                raise LearningConflictError(
                    "Capability snapshot has no stable identity"
                )
            cursor = (capability_id, version)
            if prior is not None and cursor <= prior:
                raise LearningConflictError(
                    "Capability snapshot is not strictly ordered"
                )
            prior = cursor
        return rows

    def _all_audit_events(self, *, subject_type=None, subject_id=None):
        rows = []
        after_sequence = 0
        while True:
            page = self.store.list_audit_events(
                subject_type=subject_type,
                subject_id=subject_id,
                after_sequence=after_sequence,
                limit=5000,
            )
            if not page:
                return rows
            for row in page:
                try:
                    sequence = int((row or {}).get("sequence"))
                except (TypeError, ValueError) as exc:
                    raise LearningConflictError(
                        "Audit cursor page has no stable sequence"
                    ) from exc
                if sequence <= after_sequence:
                    raise LearningConflictError(
                        "Audit cursor page is not strictly ordered"
                    )
                rows.append(row)
                after_sequence = sequence

    def get_job(self, job_id, *, actor_id=None, actor_role=None):
        job = self.store.get_learning_job(job_id)
        if not job:
            raise KeyError("Unknown learning job: %s" % job_id)
        jobs = self._all_learning_jobs()
        duplicate_counts = self._duplicate_counts(jobs)
        payload = _object_or_empty(job.get("payload"))
        group_id = payload.get("duplicate_group_id") or duplicate_group_id(
            payload.get("classification")
        )
        preflight = _job_operational_snapshot(
            job,
            duplicate_job_count=duplicate_counts.get(group_id, 1),
        )
        generation = (preflight.get("escalation") or {}).get(
            "routing_generation"
        )
        escalation = self.store.get_notification(
            _notification_id(
                "learning_job_sla_overdue",
                "learning_job",
                job_id,
                generation,
            )
        )
        if escalation is not None and actor_role is not None and not self._notification_visible_to(
            escalation, actor_id, actor_role
        ):
            escalation = None
        public = self.public_job(
            job,
            duplicate_job_count=duplicate_counts.get(group_id, 1),
            escalation=escalation,
        )
        public["lifecycle"] = self.store.list_lifecycle_events(job.get("feedback_id"))
        recent_validations = self.store.list_validation_runs(
            feedback_id=job.get("feedback_id"),
            limit=1000,
            newest_first=True,
        )
        validation_by_id = {
            str(row.get("validation_id") or ""): row
            for row in recent_validations
            if row.get("validation_id")
        }
        exact_validation_id = _object_or_empty(job.get("payload")).get(
            "validation_id"
        )
        if isinstance(exact_validation_id, str) and exact_validation_id.strip():
            exact_validation = self.store.get_validation_run(exact_validation_id)
            if exact_validation:
                validation_by_id[exact_validation_id] = exact_validation
        public["validations"] = sorted(
            validation_by_id.values(),
            key=lambda row: (
                str(row.get("created_at") or ""),
                str(row.get("validation_id") or ""),
            ),
            reverse=True,
        )
        relevant_capability_ids = {
            str(value).strip()
            for value in (
                _object_or_empty(public.get("promoted_capability")).get(
                    "capability_id"
                ),
                _object_or_empty(public.get("result")).get("capability_id"),
                _object_or_empty(public.get("candidate")).get("capability_id"),
            )
            if isinstance(value, str) and value.strip()
        }
        capability_versions = (
            [
                row
                for row in self._all_capability_versions()
                if row.get("capability_id") in relevant_capability_ids
            ]
            if relevant_capability_ids
            else []
        )
        if capability_versions:
            admission = self.capability_admission_report(
                capability_versions=capability_versions,
                learning_jobs=jobs,
            )
            public["capability_versions"] = sorted(
                capability_versions,
                key=lambda row: (
                    str(row.get("capability_id") or ""),
                    int(row.get("version") or 0),
                ),
                reverse=True,
            )
            public["capabilities"] = admission["latest"]
            public["capability_rollback_reviews"] = (
                self.capability_rollback_reviews(
                    capability_versions,
                    admission_report=admission,
                )
            )
        else:
            public["capability_versions"] = []
            public["capabilities"] = []
            public["capability_rollback_reviews"] = {}
        return public

    @staticmethod
    def _duplicate_counts(jobs):
        counts = Counter()
        for row in jobs:
            payload = _object_or_empty(row.get("payload"))
            group_id = payload.get("duplicate_group_id") or duplicate_group_id(
                payload.get("classification")
            )
            if group_id and row.get("state") not in TERMINAL_JOB_STATES:
                counts[group_id] += 1
        return counts

    def list_jobs(
        self,
        state=None,
        limit=100,
        *,
        actor_id=None,
        actor_role=None,
        now=None,
        jobs=None,
        notifications=None,
    ):
        source = list(
            jobs
            if jobs is not None
            else self._all_learning_jobs()
        )
        if state is not None:
            source = [row for row in source if row.get("state") == state]
        duplicate_counts = self._duplicate_counts(source)
        prepared = []
        for row in source:
            payload = _object_or_empty(row.get("payload"))
            group_id = payload.get("duplicate_group_id") or duplicate_group_id(
                payload.get("classification")
            )
            duplicate_count = duplicate_counts.get(group_id, 1)
            preflight = _job_operational_snapshot(
                row,
                now=now,
                duplicate_job_count=duplicate_count,
            )
            generation = (preflight.get("escalation") or {}).get(
                "routing_generation"
            )
            notification_id = _notification_id(
                "learning_job_sla_overdue",
                "learning_job",
                str(row.get("job_id") or ""),
                generation,
            )
            prepared.append((row, duplicate_count, notification_id))
        if notifications is not None:
            notification_by_id = {
                str(record.get("notification_id")): record
                for record in notifications
                if isinstance(record, dict) and record.get("notification_id")
            }
        else:
            notification_by_id = {
                str(record.get("notification_id")): record
                for record in self.store.get_notifications(
                    [item[2] for item in prepared]
                )
                if isinstance(record, dict) and record.get("notification_id")
            }
        output = []
        for row, duplicate_count, notification_id in prepared:
            escalation = notification_by_id.get(notification_id)
            if escalation is not None and actor_role is not None and not self._notification_visible_to(
                escalation, actor_id, actor_role
            ):
                escalation = None
            output.append(
                self.public_job(
                    row,
                    now=now,
                    duplicate_job_count=duplicate_count,
                    escalation=escalation,
                )
            )
        output.sort(
            key=lambda row: (
                -int(((row.get("operations") or {}).get("priority") or {}).get("score") or 0),
                str(((row.get("operations") or {}).get("sla") or {}).get("due_at") or "9999"),
                str(row.get("job_id") or ""),
            )
        )
        if limit is None:
            return output
        return output[: max(1, min(int(limit), 1000))]

    def capability_admission_report(
        self,
        capability_versions=None,
        *,
        learning_jobs=None,
        limit=5000,
    ):
        """Admit only latest capabilities with exact governed provenance.

        Legacy rows remain append-only evidence, but are represented as
        quarantined and never reach the runtime compiler. Rollbacks are trusted
        only when they trace to an already governed activation and an audited
        steward rollback.
        """
        rows = [
            row
            for row in (
                capability_versions
                if capability_versions is not None
                else self._all_capability_versions()
            )
            if isinstance(row, dict)
        ]
        jobs = {
            row.get("feedback_id"): row
            for row in (
                learning_jobs
                if learning_jobs is not None
                else self._all_learning_jobs()
            )
            if isinstance(row, dict)
            and isinstance(row.get("feedback_id"), str)
            and row.get("feedback_id")
        }
        referenced_validation_ids = _referenced_validation_ids(rows)
        referenced_validation_ids.update(
            _referenced_validation_ids(
                [
                    job.get("payload")
                    if isinstance(job.get("payload"), dict)
                    else {}
                    for job in jobs.values()
                ]
            )
        )
        validations = {
            row.get("validation_id"): row
            for row in self.store.get_validation_runs(
                referenced_validation_ids
            )
            if isinstance(row, dict)
            and isinstance(row.get("validation_id"), str)
            and row.get("validation_id")
        }
        audits = [
            row
            for row in self._all_audit_events(subject_type="capability")
            if isinstance(row, dict)
        ]
        by_key = {
            (str(row.get("capability_id") or ""), int(row.get("version") or 0)): row
            for row in rows
            if row.get("capability_id") and type(row.get("version")) is int
        }
        assessments = {}

        def reject(reason):
            return {"admitted": False, "reason": reason}

        def admitted_actor(value):
            try:
                return _normalized_actor(value)
            except ValueError:
                return None

        def positive_int(value):
            return value if type(value) is int and value > 0 else None

        def assess(row, stack=()):
            key = (str(row.get("capability_id") or ""), int(row.get("version") or 0))
            if key in assessments:
                return assessments[key]
            if key in stack:
                return reject("rollback_provenance_cycle")
            if row.get("owner_id") != TENANT_OWNER_ID:
                result = reject("owner_scope_mismatch")
            elif row.get("state") != "active":
                result = reject("latest_version_not_active")
            else:
                promotion_value = row.get("promotion_evidence") or {}
                promotion = promotion_value if isinstance(promotion_value, dict) else {}
                evidence_value = promotion.get("evidence") or {}
                evidence = evidence_value if isinstance(evidence_value, dict) else {}
                approval_value = evidence.get("approval") or {}
                approval = approval_value if isinstance(approval_value, dict) else {}
                activation_id = evidence.get("activation_id")
                if (
                    not isinstance(promotion_value, dict)
                    or not isinstance(evidence_value, dict)
                    or not isinstance(approval_value, dict)
                ):
                    result = reject("malformed_promotion_evidence")
                elif activation_id or approval:
                    feedback_id_value = promotion.get("feedback_id")
                    feedback_id = (
                        feedback_id_value.strip()
                        if isinstance(feedback_id_value, str)
                        else None
                    )
                    job = jobs.get(feedback_id) if feedback_id else None
                    payload_value = (job or {}).get("payload") or {}
                    payload = payload_value if isinstance(payload_value, dict) else {}
                    validation_id_value = approval.get("validation_id")
                    validation_id = (
                        validation_id_value.strip()
                        if isinstance(validation_id_value, str)
                        else None
                    )
                    validation = validations.get(validation_id) if validation_id else None
                    binding_value = approval.get("candidate_binding") or {}
                    binding = binding_value if isinstance(binding_value, dict) else {}
                    validation_evidence_value = (validation or {}).get("evidence") or {}
                    validation_evidence = (
                        validation_evidence_value
                        if isinstance(validation_evidence_value, dict)
                        else {}
                    )
                    validator = admitted_actor(approval.get("validator_id"))
                    approver = admitted_actor(approval.get("approver_id"))
                    reservation_id = approval.get("reservation_id")
                    expected_activation_id = (
                        store_stable_id(
                            "capability-activation",
                            "%s:%s" % ((job or {}).get("job_id"), reservation_id),
                        )
                        if job and isinstance(reservation_id, str) and reservation_id.strip()
                        else None
                    )
                    try:
                        exact_definition_binding = (
                            candidate_binding(row.get("definition") or {}) == binding
                        )
                    except (AttributeError, TypeError, ValueError):
                        exact_definition_binding = False
                    checks_value = (validation or {}).get("checks") or {}
                    checks = checks_value if isinstance(checks_value, dict) else {}
                    promoted_value = payload.get("promoted_capability") or {}
                    promoted = promoted_value if isinstance(promoted_value, dict) else {}
                    activation_value = payload.get("activation") or {}
                    activation = activation_value if isinstance(activation_value, dict) else {}
                    if (
                        not isinstance(payload_value, dict)
                        or not isinstance(binding_value, dict)
                        or not isinstance(validation_evidence_value, dict)
                        or not isinstance(checks_value, dict)
                        or not isinstance(promoted_value, dict)
                        or not isinstance(activation_value, dict)
                    ):
                        result = reject("malformed_governed_binding")
                    elif approval.get("schema") != "capability-approval/v1" or approval.get("status") != "approved":
                        result = reject("governed_approval_missing")
                    elif not activation_id or activation_id != expected_activation_id:
                        result = reject("activation_id_mismatch")
                    elif not validator or not approver or validator == approver:
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif row.get("validation_run_id") != validation_id:
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif not validation or validation.get("status") != "passed":
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif any(checks.get(name) != "passed" for name in VALIDATION_GATES):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif (
                        validation.get("feedback_id") != feedback_id
                        or validation.get("candidate_id") != binding.get("candidate_id")
                        or validation.get("capability_id") != row.get("capability_id")
                        or validation_evidence.get("candidate_binding") != binding
                        or admitted_actor(validation_evidence.get("validator_id")) != validator
                    ):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif not exact_definition_binding:
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif (
                        not job
                        or job.get("state") not in {"promoted", "retrying", "retry_failed", "resolved"}
                        or payload.get("approval") != approval
                        or payload.get("candidate_binding") != binding
                        or payload.get("validation_id") != validation_id
                        or activation.get("status") != "active"
                        or activation.get("activation_id") != activation_id
                        or promoted.get("capability_id") != row.get("capability_id")
                        or positive_int(promoted.get("version")) != positive_int(
                            row.get("version")
                        )
                    ):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    else:
                        result = {
                            "admitted": True,
                            "kind": "governed_activation",
                            "activation_id": activation_id,
                            "validation_id": validation_id,
                        }
                else:
                    rollback = promotion
                    target_version = positive_int(rollback.get("target_version")) or 0
                    from_version = positive_int(rollback.get("from_version")) or 0
                    rollback_actor = admitted_actor(rollback.get("actor"))
                    rollback_reason = rollback.get("reason")
                    rollback_reason = (
                        rollback_reason.strip()
                        if isinstance(rollback_reason, str)
                        else None
                    )
                    rollback_id = rollback.get("rollback_id")
                    rollback_id = (
                        rollback_id.strip()
                        if isinstance(rollback_id, str)
                        else None
                    )
                    expected_rollback_id = stable_id(
                        "capability-rollback",
                        "%s:%s:%s"
                        % (key[0], key[1], row.get("created_at")),
                    )
                    target = by_key.get((key[0], target_version))
                    target_assessment = (
                        assess(target, stack + (key,)) if target else reject("rollback_target_missing")
                    )
                    rollback_audited = any(
                        event.get("action") == "capability_rolled_back"
                        and event.get("outcome") == "succeeded"
                        and admitted_actor(event.get("actor")) == rollback_actor
                        and positive_int(
                            (
                                event.get("details")
                                if isinstance(event.get("details"), dict)
                                else {}
                            ).get("new_version")
                        )
                        == key[1]
                        and positive_int(
                            (
                                event.get("details")
                                if isinstance(event.get("details"), dict)
                                else {}
                            ).get("target_version")
                        )
                        == target_version
                        and positive_int(
                            (
                                event.get("details")
                                if isinstance(event.get("details"), dict)
                                else {}
                            ).get("from_version")
                        )
                        == from_version
                        and (
                            event.get("details")
                            if isinstance(event.get("details"), dict)
                            else {}
                        ).get("reason")
                        == rollback_reason
                        and (
                            event.get("details")
                            if isinstance(event.get("details"), dict)
                            else {}
                        ).get("rollback_id")
                        == rollback_id
                        for event in audits
                        if event.get("subject_id") == key[0]
                    )
                    if (
                        not rollback_actor
                        or not rollback_reason
                        or not rollback_id
                        or rollback_id != expected_rollback_id
                        or from_version != key[1] - 1
                    ):
                        result = reject("rollback_provenance_malformed")
                    elif not target_assessment.get("admitted"):
                        result = reject("rollback_target_not_governed")
                    elif row.get("definition") != target.get("definition"):
                        result = reject("rollback_definition_mismatch")
                    elif rollback.get("target_activation_id") != target_assessment.get("activation_id"):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif rollback.get("target_validation_id") != target_assessment.get("validation_id"):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif row.get("validation_run_id") != target_assessment.get("validation_id"):
                        result = reject("REDACTED_OPAQUE_VALUE")
                    elif not rollback_audited:
                        result = reject("rollback_audit_missing")
                    else:
                        result = {
                            "admitted": True,
                            "kind": "governed_rollback",
                            "activation_id": target_assessment.get("activation_id"),
                            "validation_id": target_assessment.get("validation_id"),
                        }
            assessments[key] = result
            return result

        latest = {}
        for row in rows:
            capability_id = row.get("capability_id")
            version = row.get("version")
            if not isinstance(capability_id, str) or type(version) is not int:
                continue
            # Rollback authorization must be able to assess an older exact
            # governed target even though runtime admission considers only the
            # latest version for each capability.
            if row.get("state") == "active":
                assess(row)
            prior = latest.get(capability_id)
            if prior is None or version > prior.get("version", 0):
                latest[capability_id] = row
        admitted = []
        quarantined = []
        latest_records = []
        for capability_id in sorted(latest):
            row = latest[capability_id]
            assessment = assess(row)
            annotated = {**row, "admission": assessment}
            latest_records.append(annotated)
            if assessment.get("admitted"):
                admitted.append(row)
            elif row.get("state") == "active":
                quarantined.append(
                    {
                        "capability_id": capability_id,
                        "version": row.get("version"),
                        "reason": assessment.get("reason"),
                    }
                )
        reasons = Counter(row["reason"] for row in quarantined)
        return {
            "admitted": admitted,
            "latest": latest_records,
            "quarantined": quarantined,
            "summary": {
                "status": "quarantined" if quarantined else "passed",
                "latest_capabilities": len(latest),
                "admitted_active": len(admitted),
                "quarantined_active": len(quarantined),
                "reason_counts": {key: reasons[key] for key in sorted(reasons)},
            },
            "assessments": assessments,
        }

    def capability_rollback_reviews(
        self,
        capability_versions=None,
        *,
        admission_report=None,
    ):
        """Return the exact non-mutating rollback readiness shown to stewards."""
        rows = list(
            capability_versions
            if capability_versions is not None
            else self._all_capability_versions()
        )
        admission = admission_report or self.capability_admission_report(
            capability_versions=rows
        )
        assessments = admission.get("assessments") or {}
        grouped = {}
        for row in rows:
            capability_id = row.get("capability_id")
            if isinstance(capability_id, str) and type(row.get("version")) is int:
                grouped.setdefault(capability_id, []).append(row)
        drift = self.current_drift_evidence()
        drift_current = bool(
            drift.get("status") == "accepted"
            and drift.get("freshness") == "current"
        )
        regression_status = self._regression_status()
        output = {}
        for capability_id, history in grouped.items():
            ordered = sorted(history, key=lambda row: int(row.get("version") or 0))
            current = ordered[-1]
            current_version = int(current.get("version") or 0)
            current_assessment = assessments.get(
                (capability_id, current_version), {"admitted": False}
            )
            targets = [
                {
                    "version": int(row.get("version") or 0),
                    "state": row.get("state"),
                    "updated_at": row.get("updated_at") or row.get("created_at"),
                    "admission": assessments.get(
                        (capability_id, int(row.get("version") or 0)),
                        {"admitted": False, "reason": "not_assessed"},
                    ),
                }
                for row in reversed(ordered[:-1])
                if row.get("state") == "active"
                and assessments.get(
                    (capability_id, int(row.get("version") or 0)), {}
                ).get("admitted")
            ]
            blocked_reasons = []
            if not current_assessment.get("admitted"):
                blocked_reasons.append("current_version_not_governed")
            if not targets:
                blocked_reasons.append("no_governed_prior_target")
            if not drift_current or any(
                row.get("state") == "invalidated" for row in history
            ):
                blocked_reasons.append("REDACTED_OPAQUE_VALUE")
            if regression_status != "passed":
                blocked_reasons.append("regression_evidence_not_current")
            output[capability_id] = {
                "capability_id": capability_id,
                "current_version": current_version,
                "current_state": current.get("state"),
                "current_admission": current_assessment,
                "eligible": not blocked_reasons,
                "target_versions": targets,
                "recommended_target_version": (
                    targets[0].get("version") if targets else None
                ),
                "drift": {
                    "status": drift.get("status"),
                    "freshness": drift.get("freshness"),
                },
                "regression_status": regression_status,
                "blocked_reasons": blocked_reasons,
            }
        return output

    def admitted_capability_versions(self, *, limit=5000):
        return self.capability_admission_report(limit=limit)["admitted"]

    def build_candidate(self, job_id, patch=None, actor="learning_system", expected_state=None):
        with self.lock:
            existing = self.store.get_learning_job(job_id)
            if not existing:
                raise KeyError("Unknown learning job: %s" % job_id)
            if expected_state is None:
                raise LearningConflictError(
                    "candidate build requires an observed expected_state"
                )
            self._assert_expected_state(existing, expected_state)
            if existing.get("state") not in CANDIDATE_BUILD_STATES:
                raise ValueError(
                    "Capability candidate cannot be rebuilt from state %s"
                    % existing.get("state")
                )
            payload = dict(existing.get("payload") or {})
            candidate = _deep_merge(payload.get("candidate") or {}, patch or {})
            candidate["version"] = int((payload.get("candidate") or {}).get("version") or 0) + 1
            candidate.setdefault("state", "candidate")
            validation = validate_capability_artifact(candidate)
            if validation.get("status") != "passed":
                raise ValueError("Capability candidate is invalid: " + "; ".join(validation.get("errors") or []))
            level = self._enforce_candidate_learning_level_floor(payload, candidate)
            payload["candidate"] = candidate
            payload["candidate_binding"] = candidate_binding(candidate)
            payload.pop("validation_binding", None)
            payload.pop("validation_id", None)
            payload["candidate_contract_validation"] = validation
            payload["evidence_inventory"] = self.evidence_inventory()
            state = "candidate_ready" if level == 1 else "awaiting_steward" if level == 2 else "engineering_required"
            stored = self._write_job(
                {**existing, "state": state, "payload": payload, "error": None},
                actor=actor,
                reason="REDACTED_OPAQUE_VALUE",
                prior_state=existing.get("state"),
                audit_action="capability_candidate_built",
                expected_state=existing.get("state"),
            )
            return self.public_job(stored)

    def compile_candidate(self, job_id, catalog):
        """Compile and generalize a not-yet-active candidate for validation only."""
        job = self.store.get_learning_job(job_id)
        if not job:
            raise KeyError("Unknown learning job: %s" % job_id)
        if job.get("state") not in CANDIDATE_VALIDATION_STATES:
            raise ValueError(
                "Capability candidate cannot be validated from state %s"
                % job.get("state")
            )
        payload = job.get("payload") or {}
        candidate = payload.get("candidate") or {}
        binding = candidate_binding(candidate)
        stored_binding = payload.get("candidate_binding")
        if stored_binding and stored_binding != binding:
            raise LearningConflictError("Stored capability candidate binding is inconsistent")
        question = str(payload.get("question") or "").strip()
        capability_id = self.capability_id_for_artifact(candidate)
        record = {
            "capability_id": capability_id,
            "version": int(candidate.get("version") or 1),
            "state": "active",
            "definition": candidate,
        }
        plan = compile_question_from_capabilities(question, [record], catalog)
        cases = []

        def add_case(name, case_question, expected_match):
            compiled = compile_question_from_capabilities(
                case_question,
                [record],
                catalog,
            )
            matched = bool(
                compiled
                and compiled.get("status") == "REDACTED_OPAQUE_VALUE"
            )
            cases.append(
                {
                    "name": name,
                    "expected_match": expected_match,
                    "matched": matched,
                    "status": "passed" if matched == expected_match else "failed",
                }
            )

        add_case("original_question", question, True)
        routing = candidate.get("routing") or {}
        for index, phrase in enumerate((routing.get("phrases") or [])[:5]):
            add_case(
                "paraphrase_%s" % (index + 1),
                "%s %s" % (question, phrase),
                True,
            )
        typo_tested = False
        for alternatives in routing.get("required_terms") or []:
            values = alternatives if isinstance(alternatives, list) else [alternatives]
            for value in values:
                term = str(value or "").lower()
                if len(term) < 5 or term not in question.lower():
                    continue
                typo = term[:1] + term[2:]
                typo_question = question.lower().replace(term, typo, 1)
                add_case("common_typo", typo_question, True)
                typo_tested = True
                break
            if typo_tested:
                break
        if not typo_tested:
            cases.append(
                {
                    "name": "common_typo",
                    "expected_match": True,
                    "matched": False,
                    "status": "failed",
                    "reason": "no explicit typo route could be exercised",
                }
            )
        for index, excluded in enumerate((routing.get("excluded_terms") or [])[:5]):
            add_case(
                "negative_near_miss_%s" % (index + 1),
                "%s %s" % (question, excluded),
                False,
            )
        if not routing.get("excluded_terms"):
            cases.append(
                {
                    "name": "negative_near_miss",
                    "expected_match": False,
                    "matched": False,
                    "status": "failed",
                    "reason": "no excluded near-miss route is declared",
                }
            )
        suite = {
            "status": (
                "passed"
                if plan
                and plan.get("status") == "REDACTED_OPAQUE_VALUE"
                and cases
                and all(row.get("status") == "passed" for row in cases)
                else "failed"
            ),
            "validation_kind": "candidate_generalization/v1",
            "cases": cases,
            "case_count": len(cases),
        }
        if plan:
            plan["capability_validation"] = suite
        return {"plan": plan, "suite": suite, "candidate_binding": binding}

    def _regression_status(self):
        path = self.regression_evidence_path
        try:
            if path.is_symlink() or not path.is_file() or not (0 < path.stat().st_size <= 65536):
                return "not_run"
            payload = json.loads(path.read_text(encoding="utf-8"))
            source_commit = runtime_source_commit()
            lock_sha256 = runtime_lock_sha256()
            if source_commit is None or lock_sha256 is None:
                return "failed"
            validate_promotion_regression_evidence(
                payload,
                expected_source_commit=source_commit,
                expected_uv_lock_sha256=lock_sha256,
            )
        except (OSError, UnicodeError, json.JSONDecodeError, ArtifactContractError):
            return "failed"
        return "passed"

    def _validation_checks(self, job, provided=None, answer_result=None):
        payload = job.get("payload") or {}
        artifact = payload.get("candidate") or {}
        artifact_report = validate_capability_artifact(artifact)
        semantic = artifact.get("semantic_contract") or {}
        security = artifact.get("security_contract") or {}
        evidence = payload.get("evidence_inventory") or []
        catalog_available = any(row.get("name") == "postgres_catalog" and row.get("available") for row in evidence)
        unsafe_cardinality = any(str(value).upper() in {"N:M", "M:N", "MANY_TO_MANY"} for value in semantic.get("join_cardinalities") or [])
        drift_gate = self.current_drift_evidence()
        checks = {
            "artifact_schema": _status(artifact_report),
            "catalog": "passed" if catalog_available else "not_run",
            "grain_cardinality": "passed" if semantic.get("grain") and not unsafe_cardinality else "failed",
            "owner_scope": "PORTFOLIO_REDACTED" if security.get("owner_id") == TENANT_OWNER_ID and security.get("mandatory") is True else "failed",
            "read_only_ast": "passed" if security.get("read_only") is True and security.get("single_statement") is True and security.get("stores_executable_sql") is False else "failed",
            "structural_postgresql": "not_run",
            "explain": "not_run",
            "bounded_live": "not_run",
            "result_shape": "not_run",
            "paraphrase_typo": "not_run",
            "negative_adversarial": "not_run",
            "regression": self._regression_status(),
            "drift": (
                "passed"
                if drift_gate.get("status") == "accepted"
                and drift_gate.get("freshness") == "current"
                else str(drift_gate.get("reason") or "unknown")
            ),
        }
        if answer_result:
            execution = answer_result.get("live_execution") or {}
            phases = execution.get("phases") or {}
            shape_phase = phases.get("full_execution") or phases.get("bounded_sample") or phases.get("shape") or {}
            generalized = answer_result.get("capability_validation") or {}
            checks.update(
                {
                    "grain_cardinality": _status(answer_result.get("semantic_validation")),
                    "owner_scope": _status(execution.get("security_validation")),
                    "read_only_ast": _status(execution.get("read_only_validation")),
                    "structural_postgresql": _status(answer_result.get("validation")),
                    "explain": _status(phases.get("explain")),
                    "bounded_live": _status(execution.get("status")),
                    "result_shape": _status(shape_phase),
                    "paraphrase_typo": _status(generalized),
                    "negative_adversarial": _status(generalized),
                }
            )
        for name, value in (provided or {}).items():
            # Drift is a live, mutable-state proof. A caller-provided string or
            # an answer payload must never override the current evidence gate.
            if name in VALIDATION_GATES and name not in {"drift", "regression"}:
                checks[name] = _status(value)
        return checks, artifact_report, drift_gate

    def validate_job(
        self,
        job_id,
        provided=None,
        answer_result=None,
        actor="validation_system",
        expected_state=None,
        expected_candidate_binding=None,
    ):
        with self.lock:
            job = self.store.get_learning_job(job_id)
            if not job:
                raise KeyError("Unknown learning job: %s" % job_id)
            self._assert_expected_state(job, expected_state)
            if job.get("state") not in CANDIDATE_VALIDATION_STATES:
                raise ValueError(
                    "Capability candidate cannot be validated from state %s"
                    % job.get("state")
                )
            actor = _normalized_actor(actor)
            payload = dict(job.get("payload") or {})
            artifact = payload.get("candidate") or {}
            self._enforce_candidate_learning_level_floor(payload, artifact)
            binding = candidate_binding(artifact)
            stored_binding = payload.get("candidate_binding")
            if stored_binding and stored_binding != binding:
                raise LearningConflictError(
                    "Stored capability candidate binding is inconsistent"
                )
            if expected_candidate_binding is not None and expected_candidate_binding != binding:
                raise LearningConflictError(
                    "Capability candidate changed after compilation; compile and validate again"
                )
            checks, artifact_report, drift_gate = self._validation_checks(
                job, provided, answer_result
            )
            missing = [name for name in VALIDATION_GATES if checks.get(name) != "passed"]
            status = "passed" if not missing else "incomplete"
            capability_id = self.capability_id_for_artifact(artifact)
            now = utc_now()
            validation = self.store.upsert_validation_run(
                {
                    "validation_id": store_stable_id(
                        "validation", "%s:%s:%s" % (job_id, artifact.get("version"), now)
                    ),
                    "owner_id": TENANT_OWNER_ID,
                    "feedback_id": job.get("feedback_id"),
                    "candidate_id": artifact.get("artifact_id"),
                    "capability_id": capability_id,
                    "capability_version": None,
                    "status": status,
                    "checks": checks,
                    "evidence": {
                        "candidate_binding": binding,
                        "validator_id": actor,
                        "missing_or_failed_gates": missing,
                        "artifact_report": artifact_report,
                        "schema_drift": drift_gate,
                        "answer_result": _result_summary(answer_result) if answer_result else None,
                    },
                    "started_at": now,
                    "completed_at": now,
                }
            ).record
            self._invalidate_metrics_cache()
            new_state = "validated" if status == "passed" else "validation_incomplete"
            payload["candidate_binding"] = binding
            payload["validation_binding"] = binding
            payload["validation_id"] = validation.get("validation_id")
            payload["validator_id"] = actor
            stored = self._write_job(
                {**job, "state": new_state, "payload": payload, "error": None},
                actor=actor,
                reason="validation_gauntlet_%s" % status,
                prior_state=job.get("state"),
                audit_action="capability_candidate_validated",
                expected_state=job.get("state"),
            )
            return {"job": self.public_job(stored), "validation": validation}

    def _persist_capability(self, capability):
        if not capability:
            return None
        promotion = capability.get("promotion_evidence") or {}
        approval = ((promotion.get("evidence") or {}).get("approval") or {})
        rollback = capability.get("rollback") or {}
        validation_run_id = (
            approval.get("validation_id")
            or rollback.get("target_validation_id")
        )
        result = self.store.upsert_capability_version(
            {
                "capability_id": capability.get("capability_id"),
                "version": capability.get("version"),
                "owner_id": TENANT_OWNER_ID,
                "state": capability.get("state") or "active",
                "scope": capability.get("scope") or "tenant",
                "semantic_shape_id": capability.get("semantic_shape_id"),
                "definition": capability.get("definition") or {},
                "promotion_evidence": promotion or rollback or capability.get("invalidation") or {},
                # The outer LearningLoop validation ID is a local lifecycle
                # event. Runtime admission must join to the governed durable
                # validation authorized by the immutable human approval.
                "validation_run_id": validation_run_id,
                "created_at": capability.get("created_at"),
            }
        ).record
        self._invalidate_metrics_cache()
        return result

    def _complete_reserved_approval(
        self,
        job,
        payload,
        artifact,
        binding,
        validation,
        validator,
        actor,
    ):
        """Complete a previously compare-and-set approval reservation."""
        reservation_id = job.get("lease_owner")
        current = self.store.get_learning_job(job.get("job_id"))
        if (
            not current
            or current.get("state") != "approving"
            or current.get("lease_owner") != job.get("lease_owner")
            or self._approval_reservation_recovery_status(current, utc_now())
            != "live_reservation"
        ):
            raise LearningConflictError("Approval reservation is no longer active")
        current_payload = dict(current.get("payload") or {})
        if current_payload.get("approval_reservation") != payload.get(
            "approval_reservation"
        ):
            raise LearningConflictError("Approval reservation identity changed")
        self._enforce_candidate_learning_level_floor(current_payload, artifact)
        job = current
        payload = current_payload
        approval_evidence = {
            "schema": "capability-approval/v1",
            "status": "approved",
            "reservation_id": reservation_id,
            "validator_id": validator,
            "approver_id": actor,
            "approved_at": utc_now(),
            "validation_id": validation.get("validation_id"),
            "candidate_binding": binding,
        }
        feedback_id = job.get("feedback_id")
        snapshot = self.loop.lifecycle_snapshot(feedback_id)
        record = snapshot["records"][0]
        state = record.get("state")
        payload.pop("approval_reservation", None)
        payload["approval"] = approval_evidence
        payload["activation"] = {
            "schema": "capability-activation/v1",
            "status": "pending",
            "activation_id": store_stable_id(
                "capability-activation",
                "%s:%s" % (job.get("job_id"), reservation_id),
            ),
            "approved_at": approval_evidence["approved_at"],
        }
        job = self._write_job(
            {
                **current,
                "state": "activation_pending",
                "lease_owner": None,
                "lease_expires_at": None,
                "payload": payload,
                "error": None,
            },
            actor=actor,
            reason="REDACTED_OPAQUE_VALUE",
            prior_state="approving",
            audit_action="REDACTED_OPAQUE_VALUE",
            expected_state="approving",
            expected_lease_owner=reservation_id,
            lifecycle_evidence={
                "approval": approval_evidence,
                "activation": payload["activation"],
            },
            audit_details={
                "approval": approval_evidence,
                "activation": payload["activation"],
            },
        )
        return self._activate_authorized_capability(
            job,
            actor,
            snapshot=snapshot,
        )

    def _claim_authorized_activation(self, job, actor):
        payload = dict(job.get("payload") or {})
        activation = dict(payload.get("activation") or {})
        claimed_at = utc_now()
        lease_expires_at = _utc_deadline(
            claimed_at,
            ACTIVATION_CLAIM_LEASE_SECONDS,
        )
        claim_id = store_stable_id(
            "activation-claim",
            "%s:%s:%s:%s"
            % (
                job.get("job_id"),
                activation.get("activation_id"),
                actor,
                claimed_at,
            ),
        )
        claim = {
            "schema": ACTIVATION_CLAIM_SCHEMA,
            "claim_id": claim_id,
            "claimed_at": claimed_at,
            "lease_expires_at": lease_expires_at,
            "actor_id": actor,
        }
        activation.update({"status": "activating", "claim": claim})
        payload["activation"] = activation
        stored = self._write_job(
            {
                **job,
                "state": "activating",
                "lease_owner": claim_id,
                "lease_expires_at": lease_expires_at,
                "payload": payload,
                "error": None,
            },
            actor=actor,
            reason="REDACTED_OPAQUE_VALUE",
            prior_state="activation_pending",
            audit_action="capability_activation_claimed",
            expected_state="activation_pending",
            lifecycle_evidence={"activation_claim": claim},
            audit_details={"activation_claim": claim},
        )
        return stored, claim_id

    def _assert_activation_claim(self, job_id, claim_id):
        current = self.store.get_learning_job(job_id)
        if (
            not current
            or current.get("state") != "activating"
            or current.get("lease_owner") != claim_id
            or self._activation_claim_recovery_status(current, utc_now())
            != "live_activation_claim"
        ):
            raise LearningConflictError(
                "Capability activation claim is no longer active"
            )
        return current

    @staticmethod
    def _activation_claim_recovery_status(job, now):
        return _activation_claim_status(job, now)

    def _release_activation_claim(self, job_id, actor, claim_id, exc=None):
        current = self.store.get_learning_job(job_id)
        if (
            not current
            or current.get("state") != "activating"
            or current.get("lease_owner") != claim_id
        ):
            return current
        payload = dict(current.get("payload") or {})
        activation = dict(payload.get("activation") or {})
        claim = activation.get("claim") or {}
        if claim.get("claim_id") != claim_id:
            return current
        activation.pop("claim", None)
        activation["status"] = "pending"
        activation["last_released_at"] = utc_now()
        if exc is not None:
            activation["last_failure_type"] = type(exc).__name__
        payload["activation"] = activation
        return self._write_job(
            {
                **current,
                "state": "activation_pending",
                "lease_owner": None,
                "lease_expires_at": None,
                "payload": payload,
                "error": (
                    {
                        "type": type(exc).__name__,
                        "message": "Capability activation requires an explicit retry",
                    }
                    if exc is not None
                    else None
                ),
            },
            actor=actor,
            reason=(
                "REDACTED_OPAQUE_VALUE"
                if exc is not None
                else "REDACTED_OPAQUE_VALUE"
            ),
            prior_state="activating",
            audit_action=(
                "REDACTED_OPAQUE_VALUE"
                if exc is not None
                else "REDACTED_OPAQUE_VALUE"
            ),
            expected_state="activating",
            expected_lease_owner=claim_id,
            lifecycle_evidence={
                "activation_id": activation.get("activation_id"),
                "failure_type": type(exc).__name__ if exc is not None else None,
            },
            audit_details={
                "activation_id": activation.get("activation_id"),
                "failure_type": type(exc).__name__ if exc is not None else None,
            },
        )

    def _activate_authorized_capability(self, job, actor, *, snapshot=None):
        """Idempotently finish one durable, human-authorized activation."""
        actor = _normalized_actor(actor)
        current = self.store.get_learning_job(job.get("job_id"))
        if not current or current.get("state") != "activation_pending":
            raise LearningConflictError(
                "Capability activation is no longer pending"
            )
        payload = dict(current.get("payload") or {})
        artifact = copy.deepcopy(payload.get("candidate") or {})
        binding = candidate_binding(artifact)
        self._enforce_candidate_learning_level_floor(payload, artifact)
        assessment = self._stranded_approval_assessment(current)
        if not assessment.get("exact"):
            raise ValueError(
                "Authorized capability activation lost exact validation evidence"
            )
        validation = self.store.get_validation_run(payload.get("validation_id"))
        validation_evidence = (validation or {}).get("evidence") or {}
        validator = _normalized_actor(validation_evidence.get("validator_id"))
        approval_evidence = payload.get("approval") or {}
        approver = _normalized_actor(approval_evidence.get("approver_id"))
        reservation_id = approval_evidence.get("reservation_id")
        activation = payload.get("activation") or {}
        expected_activation_id = store_stable_id(
            "capability-activation",
            "%s:%s" % (current.get("job_id"), reservation_id),
        )
        if (
            approval_evidence.get("schema") != "capability-approval/v1"
            or approval_evidence.get("status") != "approved"
            or approval_evidence.get("validator_id") != validator
            or approval_evidence.get("validation_id") != validation.get("validation_id")
            or approval_evidence.get("candidate_binding") != binding
            or not isinstance(reservation_id, str)
            or not reservation_id.strip()
            or approver == validator
            or activation.get("schema") != "capability-activation/v1"
            or activation.get("status") != "pending"
            or activation.get("activation_id") != expected_activation_id
        ):
            raise ValueError(
                "Capability activation approval evidence is invalid"
            )
        drift_gate = self.current_drift_evidence()
        if (
            drift_gate.get("status") != "accepted"
            or drift_gate.get("freshness") != "current"
        ):
            raise ValueError(
                "Current owner-2 schema drift evidence is required for activation"
            )
        if self._regression_status() != "passed":
            raise ValueError(
                "Current source-bound regression evidence is required for activation"
            )
        claimed, claim_id = self._claim_authorized_activation(current, actor)
        try:
            return self._run_claimed_activation(
                claimed,
                actor,
                claim_id,
                snapshot=snapshot,
            )
        except Exception as exc:
            self._release_activation_claim(
                current.get("job_id"),
                actor,
                claim_id,
                exc,
            )
            raise

    def _run_claimed_activation(self, job, actor, claim_id, *, snapshot=None):
        current = self._assert_activation_claim(job.get("job_id"), claim_id)
        payload = dict(current.get("payload") or {})
        artifact = copy.deepcopy(payload.get("candidate") or {})
        binding = candidate_binding(artifact)
        self._enforce_candidate_learning_level_floor(payload, artifact)
        assessment = self._stranded_approval_assessment(current)
        if not assessment.get("exact"):
            raise ValueError(
                "Claimed capability activation lost exact validation evidence"
            )
        validation = self.store.get_validation_run(payload.get("validation_id"))
        validation_evidence = (validation or {}).get("evidence") or {}
        validator = _normalized_actor(validation_evidence.get("validator_id"))
        approval_evidence = payload.get("approval") or {}
        activation = payload.get("activation") or {}
        claim = activation.get("claim") or {}
        if (
            activation.get("status") != "activating"
            or claim.get("claim_id") != claim_id
        ):
            raise LearningConflictError("Capability activation claim identity changed")
        feedback_id = current.get("feedback_id")
        snapshot = snapshot or self.loop.lifecycle_snapshot(feedback_id)
        record = snapshot["records"][0]
        state = record.get("state")
        if state in {"open", "classified", "corrected"}:
            self._assert_activation_claim(current.get("job_id"), claim_id)
            self.loop.register_capability_candidate(
                feedback_id,
                capability=artifact,
                evidence={
                    "source": "learning_service",
                    "approval": approval_evidence,
                },
            )
            state = "candidate"
        if state == "candidate":
            self._assert_activation_claim(current.get("job_id"), claim_id)
            self.loop.validate_capability_candidate(
                feedback_id,
                {
                    "status": "passed",
                    "sql_validation": "passed",
                    "semantic_validation": "passed",
                    "live_validation": "passed",
                    "generalized_validation": "passed",
                    "product_validation_id": validation.get("validation_id"),
                },
                evidence={
                    "validator_id": validator,
                    "validation_id": validation.get("validation_id"),
                    "candidate_binding": binding,
                },
            )
            state = "validated"
        capability = None
        if state == "validated":
            self._assert_activation_claim(current.get("job_id"), claim_id)
            capability = self.loop.promote_validated_capability(
                feedback_id,
                evidence={
                    "approval": approval_evidence,
                    "activation_id": activation.get("activation_id"),
                },
            )
        elif state in {"promoted", "resolved"}:
            activation_id = activation.get("activation_id")
            activation_matches = [
                row
                for row in self.loop.capability_history(
                    record.get("capability_id")
                )
                if (
                    ((row.get("promotion_evidence") or {}).get("evidence") or {}).get(
                        "activation_id"
                    )
                    == activation_id
                )
            ]
            if (
                len(activation_matches) != 1
                or activation_matches[0].get("state") != "active"
                or activation_matches[0].get("definition") != artifact
            ):
                raise ValueError(
                    "Capability activation history is not bound to one exact active version"
                )
            capability = activation_matches[0]
        if not capability:
            raise ValueError("Capability promotion did not produce an active version")
        self._assert_activation_claim(current.get("job_id"), claim_id)
        durable = self._persist_capability(capability)
        payload["candidate"] = artifact
        payload["promoted_capability"] = {
            "capability_id": capability.get("capability_id"),
            "version": capability.get("version"),
        }
        payload["activation"] = {
            **activation,
            "status": "active",
            "activated_at": utc_now(),
            **payload["promoted_capability"],
        }
        payload["activation"].pop("claim", None)
        self._assert_activation_claim(current.get("job_id"), claim_id)
        stored = self._write_job(
            {
                **current,
                "state": "promoted",
                "lease_owner": None,
                "lease_expires_at": None,
                "payload": payload,
                "result": {
                    "outcome": "promoted",
                    **payload["promoted_capability"],
                },
            },
            actor=actor,
            reason="REDACTED_OPAQUE_VALUE",
            prior_state="activating",
            audit_action="capability_promoted",
            expected_state="activating",
            expected_lease_owner=claim_id,
        )
        self._notify(
            "capability_promoted",
            "capability",
            capability.get("capability_id"),
            {
                "capability_id": capability.get("capability_id"),
                "version": capability.get("version"),
                "job_id": current.get("job_id"),
                "retry_required": True,
            },
            recipient=(payload.get("requester") or "analytics_stewards"),
            unique_suffix=str(capability.get("version")),
        )
        return {
            "job": self.public_job(stored),
            "capability": durable,
            "retry_required": True,
        }

    def _restore_failed_approval_reservation(
        self,
        job_id,
        actor,
        binding,
        reservation_id,
        exc,
    ):
        current = self.store.get_learning_job(job_id)
        if not current:
            return current
        payload = dict(current.get("payload") or {})
        if current.get("state") == "activation_pending":
            if (payload.get("approval") or {}).get("reservation_id") != reservation_id:
                return current
            activation = dict(payload.get("activation") or {})
            activation.update(
                {
                    "status": "pending",
                    "last_failure_at": utc_now(),
                    "last_failure_type": type(exc).__name__,
                }
            )
            payload["activation"] = activation
            return self._write_job(
                {
                    **current,
                    "payload": payload,
                    "error": {
                        "type": type(exc).__name__,
                        "message": "Capability activation requires an explicit retry",
                    },
                },
                actor=actor,
                reason="REDACTED_OPAQUE_VALUE",
                prior_state="activation_pending",
                audit_action="REDACTED_OPAQUE_VALUE",
                expected_state="activation_pending",
                audit_details={
                    "activation_id": activation.get("activation_id"),
                    "failure_type": type(exc).__name__,
                },
            )
        reservation = payload.get("approval_reservation") or {}
        if (
            current.get("state") != "approving"
            or current.get("lease_owner") != reservation_id
            or reservation.get("reservation_id") != reservation_id
        ):
            return current
        payload.pop("approval_reservation", None)
        payload["last_approval_failure"] = {
            "failed_at": utc_now(),
            "error_type": type(exc).__name__,
            "candidate_binding": binding,
        }
        return self._write_job(
            {
                **current,
                "state": "validated",
                "lease_owner": None,
                "lease_expires_at": None,
                "payload": payload,
                "error": {
                    "type": type(exc).__name__,
                    "message": "Capability promotion failed before completion",
                },
            },
            actor=actor,
            reason="REDACTED_OPAQUE_VALUE",
            prior_state="approving",
            audit_action="capability_promotion_failed",
            expected_state="approving",
            expected_lease_owner=reservation_id,
        )

    def _stranded_approval_assessment(self, job):
        """Verify only the validation run explicitly bound by the job payload."""
        payload = (job or {}).get("payload") or {}
        validation_id = payload.get("validation_id")
        if not isinstance(validation_id, str) or not validation_id.strip():
            return {
                "exact": False,
                "reason_code": "missing_payload_validation_id",
                "validation_id": None,
                "candidate_binding": None,
            }
        if validation_id != validation_id.strip():
            return {
                "exact": False,
                "reason_code": "invalid_payload_validation_id",
                "validation_id": None,
                "candidate_binding": None,
            }
        artifact = copy.deepcopy(payload.get("candidate") or {})
        try:
            binding = candidate_binding(artifact)
            capability_id = self.capability_id_for_artifact(artifact)
        except (AttributeError, TypeError, ValueError, OverflowError):
            return {
                "exact": False,
                "reason_code": "invalid_candidate_binding",
                "validation_id": validation_id,
                "candidate_binding": None,
            }
        try:
            self._enforce_candidate_learning_level_floor(payload, artifact)
        except (AttributeError, TypeError, ValueError):
            return {
                "exact": False,
                "reason_code": "REDACTED_OPAQUE_VALUE",
                "validation_id": validation_id,
                "candidate_binding": binding,
            }
        validation = self.store.get_validation_run(validation_id)
        if not validation:
            return {
                "exact": False,
                "reason_code": "bound_validation_not_found",
                "validation_id": validation_id,
                "candidate_binding": binding,
            }
        evidence = validation.get("evidence") or {}
        checks = validation.get("checks") or {}
        evidence_is_valid = isinstance(evidence, dict)
        checks_are_valid = isinstance(checks, dict) and all(
            checks.get(name) == "passed" for name in VALIDATION_GATES
        )
        try:
            validator = _normalized_actor(
                evidence.get("validator_id") if evidence_is_valid else None
            )
            payload_validator = _normalized_actor(payload.get("validator_id"))
        except ValueError:
            validator = None
            payload_validator = None
        exact = all(
            (
                validation.get("owner_id") == TENANT_OWNER_ID,
                validation.get("feedback_id") == job.get("feedback_id"),
                validation.get("candidate_id") == artifact.get("artifact_id"),
                validation.get("capability_id") == capability_id,
                validation.get("status") == "passed",
                bool(validation.get("completed_at")),
                checks_are_valid,
                evidence_is_valid,
                not (
                    evidence.get("missing_or_failed_gates") or []
                    if evidence_is_valid
                    else ["invalid_evidence"]
                ),
                (
                    evidence.get("candidate_binding") if evidence_is_valid else None
                )
                == binding,
                payload.get("candidate_binding") == binding,
                payload.get("validation_binding") == binding,
                payload.get("validation_id") == validation.get("validation_id"),
                validator is not None,
                validator == payload_validator,
            )
        )
        return {
            "exact": exact,
            "reason_code": (
                "REDACTED_OPAQUE_VALUE"
                if exact
                else "validation_evidence_mismatch"
            ),
            "validation_id": validation_id,
            "candidate_binding": binding,
        }

    @staticmethod
    def _approval_reservation_recovery_status(job, now):
        """Classify whether an approval reservation is safe to reclaim."""
        return _approval_reservation_status(job, now)

    def reconcile_stranded_approvals(
        self,
        actor="startup-reconciler",
        limit=1000,
    ):
        """Release crash-stranded approval reservations without approving work.

        Exact, payload-bound validation evidence is returned to ``validated`` so
        a human can approve it again. Any ambiguity fails closed to
        ``validation_incomplete``. This method never promotes, retries, or
        activates a capability.
        """
        actor = _normalized_actor(actor)
        try:
            limit = max(1, min(int(limit), 1000))
        except (TypeError, ValueError) as exc:
            raise ValueError("reconciliation limit must be an integer") from exc
        summary = {
            "schema": "REDACTED_OPAQUE_VALUE",
            "status": "completed",
            "limit": limit,
            "limit_semantics": "cursor_page_size",
            "complete_scan": True,
            "scanned": 0,
            "restored_validated": 0,
            "validation_incomplete": 0,
            "state_conflicts": 0,
            "skipped_live": 0,
            "skipped_recent_legacy": 0,
            "skipped_unproven": 0,
            "activation_claims_scanned": 0,
            "activation_claims_released": 0,
            "activation_claims_skipped_live": 0,
            "REDACTED_OPAQUE_VALUE": 0,
        }
        now = utc_now()
        with self.lock:
            recovery_jobs = self._all_learning_jobs(page_size=limit)
            jobs = [
                row for row in recovery_jobs if row.get("state") == "approving"
            ]
            summary["scanned"] = len(jobs)
            for job in jobs:
                reservation_status = self._approval_reservation_recovery_status(
                    job,
                    now,
                )
                if reservation_status == "live_reservation":
                    summary["skipped_live"] += 1
                    continue
                if reservation_status == "recent_legacy_reservation":
                    summary["skipped_recent_legacy"] += 1
                    continue
                if reservation_status == "unproven_reservation":
                    summary["skipped_unproven"] += 1
                    continue
                assessment = self._stranded_approval_assessment(job)
                target_state = (
                    "validated" if assessment["exact"] else "validation_incomplete"
                )
                reconciliation = {
                    "schema": "approval-reconciliation/v1",
                    "status": "human_reapproval_required",
                    "reason_code": assessment["reason_code"],
                    "target_state": target_state,
                    "validation_id": assessment["validation_id"],
                    "candidate_binding": (
                        assessment["candidate_binding"]
                        if assessment["exact"]
                        else None
                    ),
                    "reservation_status": reservation_status,
                    "reconciled_at": utc_now(),
                }
                payload = dict(job.get("payload") or {})
                payload.pop("approval", None)
                payload.pop("approval_reservation", None)
                payload.pop("promoted_capability", None)
                payload["approval_reconciliation"] = reconciliation
                if assessment["exact"]:
                    payload["candidate_binding"] = assessment["candidate_binding"]
                else:
                    payload.pop("validation_binding", None)
                    payload.pop("validation_id", None)
                    payload.pop("validator_id", None)
                    if assessment["candidate_binding"] is None:
                        payload.pop("candidate_binding", None)
                    else:
                        payload["candidate_binding"] = assessment[
                            "candidate_binding"
                        ]
                error = (
                    None
                    if assessment["exact"]
                    else {
                        "type": "ApprovalReconciliationRequired",
                        "message": (
                            "Fresh candidate validation is required before approval"
                        ),
                    }
                )
                try:
                    stored = self._write_job(
                        {
                            **job,
                            "state": target_state,
                            "lease_owner": None,
                            "lease_expires_at": None,
                            "payload": payload,
                            "result": None,
                            "error": error,
                        },
                        actor=actor,
                        reason="REDACTED_OPAQUE_VALUE",
                        prior_state="approving",
                        audit_action="approval_reservation_reconciled",
                        expected_state="approving",
                        expected_lease_owner=job.get("lease_owner"),
                        lifecycle_evidence={
                            "approval_reconciliation": reconciliation,
                        },
                        audit_details={
                            "approval_reconciliation": reconciliation,
                        },
                    )
                except LearningConflictError:
                    summary["state_conflicts"] += 1
                    continue
                notification_suffix = store_stable_id(
                    "approval-reconciliation",
                    _canonical_json_bytes(
                        {
                            "job_id": stored.get("job_id"),
                            "target_state": target_state,
                            "reason_code": assessment["reason_code"],
                            "validation_id": assessment["validation_id"],
                            "candidate_binding": assessment["candidate_binding"],
                        }
                    ).decode("ascii"),
                )
                notification_identity = "%s:%s:%s:%s" % (
                    "REDACTED_OPAQUE_VALUE",
                    "learning_job",
                    stored.get("job_id"),
                    notification_suffix,
                )
                notification_id = store_stable_id(
                    "notification",
                    notification_identity,
                )
                if not self.store.get_notification(notification_id):
                    self._notify(
                        "REDACTED_OPAQUE_VALUE",
                        "learning_job",
                        stored.get("job_id"),
                        {
                            "schema": "REDACTED_OPAQUE_VALUE",
                            "job_id": stored.get("job_id"),
                            "feedback_id": stored.get("feedback_id"),
                            "state": target_state,
                            "reason_code": assessment["reason_code"],
                            "validation_id": assessment["validation_id"],
                            "human_approval_required": True,
                        },
                        recipient="analytics_stewards",
                        unique_suffix=notification_suffix,
                    )
                summary[
                    "restored_validated"
                    if target_state == "validated"
                    else "validation_incomplete"
                ] += 1
            activation_jobs = [
                row for row in recovery_jobs if row.get("state") == "activating"
            ]
            summary["activation_claims_scanned"] = len(activation_jobs)
            for job in activation_jobs:
                claim_status = self._activation_claim_recovery_status(job, now)
                if claim_status == "live_activation_claim":
                    summary["activation_claims_skipped_live"] += 1
                    continue
                if claim_status != "expired_activation_claim":
                    summary["REDACTED_OPAQUE_VALUE"] += 1
                    continue
                claim_id = job.get("lease_owner")
                try:
                    recovered = self._release_activation_claim(
                        job.get("job_id"),
                        actor,
                        claim_id,
                    )
                except LearningConflictError:
                    summary["state_conflicts"] += 1
                    continue
                if not recovered or recovered.get("state") != "activation_pending":
                    summary["state_conflicts"] += 1
                    continue
                activation = (recovered.get("payload") or {}).get("activation") or {}
                notification_suffix = str(
                    activation.get("activation_id") or recovered.get("job_id")
                )
                identity = "%s:%s:%s:%s" % (
                    "REDACTED_OPAQUE_VALUE",
                    "learning_job",
                    recovered.get("job_id"),
                    notification_suffix,
                )
                notification_id = store_stable_id("notification", identity)
                if not self.store.get_notification(notification_id):
                    self._notify(
                        "REDACTED_OPAQUE_VALUE",
                        "learning_job",
                        recovered.get("job_id"),
                        {
                            "schema": "REDACTED_OPAQUE_VALUE",
                            "job_id": recovered.get("job_id"),
                            "feedback_id": recovered.get("feedback_id"),
                            "state": "activation_pending",
                            "activation_id": activation.get("activation_id"),
                            "human_resume_required": True,
                        },
                        recipient="analytics_stewards",
                        unique_suffix=notification_suffix,
                    )
                summary["activation_claims_released"] += 1
        return summary

    def approve_job(self, job_id, actor="local_steward", expected_state=None):
        with self.lock:
            job = self.store.get_learning_job(job_id)
            if not job:
                raise KeyError("Unknown learning job: %s" % job_id)
            self._assert_expected_state(job, expected_state)
            actor = _normalized_actor(actor)
            if job.get("state") == "activating":
                claim_status = self._activation_claim_recovery_status(
                    job,
                    utc_now(),
                )
                if claim_status == "live_activation_claim":
                    raise LearningConflictError(
                        "Capability activation is already in progress"
                    )
                if claim_status != "expired_activation_claim":
                    raise LearningConflictError(
                        "Capability activation claim cannot be safely recovered"
                    )
                job = self._release_activation_claim(
                    job_id,
                    actor,
                    job.get("lease_owner"),
                )
            if job.get("state") == "activation_pending":
                pending_payload = dict(job.get("payload") or {})
                pending_artifact = pending_payload.get("candidate") or {}
                pending_binding = candidate_binding(pending_artifact)
                reservation_id = (pending_payload.get("approval") or {}).get(
                    "reservation_id"
                )
                try:
                    return self._activate_authorized_capability(job, actor)
                except Exception as exc:
                    self._restore_failed_approval_reservation(
                        job_id,
                        actor,
                        pending_binding,
                        reservation_id,
                        exc,
                    )
                    raise
            if job.get("state") != "validated":
                raise ValueError("Only a fully validated learning job can be approved")
            payload = dict(job.get("payload") or {})
            validation_id = payload.get("validation_id")
            validation = (
                self.store.get_validation_run(validation_id)
                if isinstance(validation_id, str) and validation_id.strip()
                else None
            )
            if not validation or validation.get("status") != "passed":
                raise ValueError("A passing validation run is required")
            artifact = copy.deepcopy(payload.get("candidate") or {})
            binding = candidate_binding(artifact)
            validation_evidence = validation.get("evidence") or {}
            validation_binding = validation_evidence.get("candidate_binding")
            if (
                validation_binding != binding
                or payload.get("candidate_binding") != binding
                or payload.get("validation_binding") != binding
                or payload.get("validation_id") != validation.get("validation_id")
            ):
                raise ValueError(
                    "Passing validation evidence does not match the current candidate bytes"
                )
            validator = _normalized_actor(validation_evidence.get("validator_id"))
            if actor == validator:
                raise ValueError(
                    "Capability approval requires an actor distinct from the validator"
                )
            drift_gate = self.current_drift_evidence()
            if (
                drift_gate.get("status") != "accepted"
                or drift_gate.get("freshness") != "current"
            ):
                raise ValueError(
                    "Current owner-2 schema drift evidence is required for promotion"
                )
            if self._regression_status() != "passed":
                raise ValueError(
                    "Current source-bound regression evidence is required for promotion"
                )
            level = self._enforce_candidate_learning_level_floor(payload, artifact)
            if level >= 3:
                raise ValueError("Level 3 gaps require a reviewed engineering release")
            reserved_at = utc_now()
            lease_expires_at = _utc_deadline(
                reserved_at,
                APPROVAL_RESERVATION_LEASE_SECONDS,
            )
            reservation_id = store_stable_id(
                "approval-reservation",
                "%s:%s:%s" % (job_id, actor, reserved_at),
            )
            payload["approval_reservation"] = {
                "schema": APPROVAL_RESERVATION_SCHEMA,
                "reservation_id": reservation_id,
                "reserved_at": reserved_at,
                "lease_expires_at": lease_expires_at,
                "approver_id": actor,
            }
            job = self._write_job(
                {
                    **job,
                    "state": "approving",
                    "lease_owner": reservation_id,
                    "lease_expires_at": lease_expires_at,
                    "payload": payload,
                    "error": None,
                },
                actor=actor,
                reason="capability_promotion_reserved",
                prior_state=job.get("state"),
                audit_action="capability_promotion_started",
                expected_state=job.get("state"),
            )
            try:
                return self._complete_reserved_approval(
                    job,
                    payload,
                    artifact,
                    binding,
                    validation,
                    validator,
                    actor,
                )
            except Exception as exc:
                self._restore_failed_approval_reservation(
                    job_id,
                    actor,
                    binding,
                    reservation_id,
                    exc,
                )
                raise

    def submit_clarification(
        self,
        job_id,
        clarifications,
        answerer,
        *,
        actor,
        expected_state=None,
        allow_requester_override=False,
    ):
        """Retry one original job with transient typed values that are never stored."""
        if not callable(answerer):
            raise ValueError("answerer is required")
        actor = _normalized_actor(actor)
        with self.lock:
            job = self.store.get_learning_job(job_id)
            if not job:
                raise KeyError("Unknown learning job: %s" % job_id)
            self._assert_expected_state(job, expected_state)
            if job.get("state") != "awaiting_clarification":
                raise LearningConflictError(
                    "Clarification is only accepted while awaiting requester input"
                )
            payload = dict(job.get("payload") or {})
            requester = _normalized_actor(payload.get("requester"))
            if actor != requester and not allow_requester_override:
                raise PermissionError(
                    "Only the original requester may submit clarification values"
                )
            contract = payload.get("clarification") or {}
            required = {
                row.get("name"): row.get("type")
                for row in contract.get("parameters") or []
                if isinstance(row, dict)
            }
            if not required:
                raise ValueError("Learning job has no typed clarification contract")
            if not isinstance(clarifications, list) or not 1 <= len(clarifications) <= 12:
                raise ValueError("clarifications must be a bounded list")
            submitted = []
            seen = set()
            for row in clarifications:
                if not isinstance(row, dict):
                    raise ValueError("Each clarification must be an object")
                name = str(row.get("name") or "").strip().lower()
                value_type = str(row.get("type") or "").strip().lower()
                if name in seen or name not in required or value_type != required[name]:
                    raise ValueError("Clarification name or type does not match the request")
                seen.add(name)
                try:
                    value = _coerce_clarification(row.get("value"), value_type)
                except ValueError as exc:
                    raise ValueError("Clarification value for %s is invalid: %s" % (name, exc)) from exc
                submitted.append({"name": name, "type": value_type, "value": value})
            if seen != set(required):
                raise ValueError("Every required clarification value must be supplied")
            question = str(payload.get("question") or "").strip()
            if not question:
                raise ValueError("Learning job has no retryable question")
            transient_question = _clarified_question(question, submitted)
            running = self._write_job(
                {**job, "state": "retrying", "error": None},
                actor=actor,
                reason="REDACTED_OPAQUE_VALUE",
                prior_state=job.get("state"),
                audit_action="REDACTED_OPAQUE_VALUE",
                expected_state=job.get("state"),
            )
            self._audit(
                "REDACTED_OPAQUE_VALUE",
                actor,
                "learning_job",
                job_id,
                details={
                    "parameter_names": sorted(seen),
                    "parameter_types": {name: required[name] for name in sorted(required)},
                    "values_persisted": False,
                    "requester_override": bool(actor != requester),
                },
            )
        try:
            result = answerer(transient_question)
        except Exception as exc:
            with self.lock:
                current = self.store.get_learning_job(job_id) or running
                failed_payload = dict(current.get("payload") or {})
                failed_payload["clarification"] = {
                    **contract,
                    "status": "retry_failed",
                    "last_submitted_at": utc_now(),
                    "last_submitted_by": actor,
                    "submitted_parameter_names": sorted(seen),
                    "values_persisted": False,
                }
                self._write_job(
                    {
                        **current,
                        "state": "awaiting_clarification",
                        "payload": failed_payload,
                        "error": {
                            "type": type(exc).__name__,
                            "message": "Clarification retry failed",
                        },
                    },
                    actor=actor,
                    reason="REDACTED_OPAQUE_VALUE",
                    prior_state=current.get("state"),
                    audit_action="REDACTED_OPAQUE_VALUE",
                    expected_state=current.get("state"),
                )
            raise RuntimeError("Learning clarification retry failed") from exc
        with self.lock:
            current = self.store.get_learning_job(job_id) or running
            feedback = result.get("feedback_loop") or {}
            decision = safe_answer_decision(result)
            unknown = not safe_answer_decision_is_known(decision)
            classification = feedback.get("classification") or (
                classify_failure(question, result) if unknown else {}
            )
            remains_missing = (
                unknown
                and classification.get("failure_type") == "missing_parameter"
            )
            if not unknown:
                final_state = "resolved"
                outcome = "resolved"
            elif remains_missing:
                final_state = "awaiting_clarification"
                outcome = "clarification_incomplete"
            else:
                final_state = "retry_failed"
                outcome = "engineering_required"
            current_payload = dict(current.get("payload") or {})
            current_payload["last_result"] = _result_summary(result)
            current_payload["last_safe_answer_decision"] = decision
            current_payload["last_retry_at"] = utc_now()
            current_payload["clarification"] = {
                **contract,
                "status": "resolved" if final_state == "resolved" else "awaiting_input",
                "last_submitted_at": utc_now(),
                "last_submitted_by": actor,
                "submitted_parameter_names": sorted(seen),
                "values_persisted": False,
            }
            stored = self._write_job(
                {
                    **current,
                    "state": final_state,
                    "payload": current_payload,
                    "result": {"outcome": outcome, "answer_status": result.get("status")},
                    "error": None,
                },
                actor=actor,
                reason="requester_clarification_%s" % outcome,
                prior_state=current.get("state"),
                audit_action="REDACTED_OPAQUE_VALUE",
                expected_state=current.get("state"),
            )
            return {"job": self.public_job(stored), "answer": result}

    def retry_job(
        self,
        job_id,
        answerer,
        actor="learning_system",
        expected_state=None,
    ):
        if not callable(answerer):
            raise ValueError("answerer is required")
        with self.lock:
            job = self.store.get_learning_job(job_id)
            if not job:
                raise KeyError("Unknown learning job: %s" % job_id)
            self._assert_expected_state(job, expected_state)
            if job.get("state") in ACTIVATION_PROTECTED_STATES:
                raise LearningConflictError(
                    "Capability approval or activation must finish before retry"
                )
            payload = job.get("payload") or {}
            question = str(payload.get("question") or "").strip()
            if not question:
                raise ValueError("Learning job has no retryable question")
            running = self._write_job(
                {**job, "state": "retrying", "error": None},
                actor=actor,
                reason="original_question_retry_started",
                prior_state=job.get("state"),
                audit_action="learning_job_retry_started",
                expected_state=job.get("state"),
            )
        try:
            result = answerer(question)
        except Exception as exc:
            with self.lock:
                current = self.store.get_learning_job(job_id) or running
                failed = self._write_job(
                    {
                        **current,
                        "state": "retry_failed",
                        "error": {"type": type(exc).__name__, "message": str(exc)},
                    },
                    actor=actor,
                    reason="original_question_retry_failed",
                    prior_state=current.get("state"),
                    audit_action="learning_job_retry_failed",
                    expected_state=current.get("state"),
                )
            raise RuntimeError("Learning job retry failed: %s" % exc) from exc
        with self.lock:
            current = self.store.get_learning_job(job_id) or running
            decision = safe_answer_decision(result)
            if not safe_answer_decision_is_known(decision):
                final_state = "retry_failed"
                resolution = {"outcome": "engineering_required", "answer_status": result.get("status")}
            else:
                final_state = "resolved"
                resolution = {"outcome": "resolved", "answer_status": result.get("status")}
            current_payload = dict(current.get("payload") or {})
            current_payload["last_result"] = _result_summary(result)
            current_payload["last_retry_at"] = utc_now()
            stored = self._write_job(
                {**current, "state": final_state, "payload": current_payload, "result": resolution, "error": None},
                actor=actor,
                reason="original_question_retry_%s" % ("resolved" if final_state == "resolved" else "remains_unknown"),
                prior_state=current.get("state"),
                audit_action="learning_job_retry_completed",
                expected_state=current.get("state"),
            )
            self._notify(
                "learning_job_retry_result",
                "learning_job",
                job_id,
                {"job_id": job_id, "state": final_state, "answer_status": result.get("status")},
                recipient=current_payload.get("requester") or "analytics_stewards",
                unique_suffix=str(stored.get("updated_at")),
            )
            return {"job": self.public_job(stored), "answer": result}

    def resolve_job(
        self,
        job_id,
        outcome,
        note=None,
        actor="local_steward",
        expected_state=None,
    ):
        if outcome not in RESOLUTION_OUTCOMES:
            raise ValueError("Unsupported resolution outcome: %s" % outcome)
        if outcome == "resolved":
            raise ValueError("Resolved requires a successful retry of the original question")
        with self.lock:
            job = self.store.get_learning_job(job_id)
            if not job:
                raise KeyError("Unknown learning job: %s" % job_id)
            self._assert_expected_state(job, expected_state)
            if job.get("state") in ACTIVATION_PROTECTED_STATES:
                raise LearningConflictError(
                    "Capability approval or activation must finish before resolution"
                )
            stored = self._write_job(
                {**job, "state": outcome, "result": {"outcome": outcome, "note": note}},
                actor=actor,
                reason="steward_resolution_recorded",
                prior_state=job.get("state"),
                audit_action="REDACTED_OPAQUE_VALUE",
                expected_state=job.get("state"),
            )
            return self.public_job(stored)

    def rollback_capability(
        self,
        capability_id,
        target_version=None,
        reason=None,
        actor="local_steward",
        expected_current_version=None,
    ):
        with self.lock:
            normalized_actor = _normalized_actor(actor)
            normalized_reason = str(
                reason or "steward_requested_rollback"
            ).strip()
            if (
                not normalized_reason
                or len(normalized_reason) > 1000
                or any(ord(character) < 32 for character in normalized_reason)
            ):
                raise ValueError("A valid rollback reason is required")
            if expected_current_version is None:
                raise LearningConflictError(
                    "capability rollback requires an observed current version"
                )
            history = self.loop.capability_history(capability_id)
            if not history:
                raise KeyError("Unknown capability id: %s" % capability_id)
            current_version = max(int(row.get("version") or 0) for row in history)
            if int(expected_current_version) != current_version:
                raise LearningConflictError(
                    "stale capability version: expected %s, current %s"
                    % (expected_current_version, current_version)
                )
            durable_history = [
                row
                for row in self._all_capability_versions()
                if row.get("capability_id") == capability_id
            ]
            admission = self.capability_admission_report(
                capability_versions=durable_history
            )
            current_assessment = admission["assessments"].get(
                (str(capability_id), current_version),
                {"admitted": False},
            )
            if not current_assessment.get("admitted"):
                raise ValueError(
                    "Current capability lacks governed activation provenance"
                )
            target = next(
                (
                    row
                    for row in sorted(
                        durable_history,
                        key=lambda item: int(item.get("version") or 0),
                        reverse=True,
                    )
                    if (
                        int(row.get("version") or 0) == int(target_version)
                        if target_version is not None
                        else int(row.get("version") or 0) < current_version
                    )
                    and row.get("state") == "active"
                    and admission["assessments"].get(
                        (str(capability_id), int(row.get("version") or 0)),
                        {},
                    ).get("admitted")
                ),
                None,
            )
            if target is None:
                raise ValueError("Rollback target lacks trusted active provenance")
            if validate_capability_artifact(target.get("definition") or {}).get("status") != "passed":
                raise ValueError("Rollback target capability contract is invalid")
            drift_gate = self.current_drift_evidence()
            if (
                drift_gate.get("status") != "accepted"
                or drift_gate.get("freshness") != "current"
                or any(row.get("state") == "invalidated" for row in history)
            ):
                raise ValueError(
                    "Current unchanged owner-2 drift evidence is required for rollback"
                )
            if self._regression_status() != "passed":
                raise ValueError(
                    "Current source-bound regression evidence is required for rollback"
                )
            capability = self.loop.rollback_capability(
                capability_id,
                target_version=int(target.get("version") or 0),
                actor=normalized_actor,
                reason=normalized_reason,
                expected_current_version=expected_current_version,
            )
            durable = self._persist_capability(capability)
            rollback = capability.get("rollback") or {}
            self._audit(
                "capability_rolled_back",
                normalized_actor,
                "capability",
                capability_id,
                details={
                    "rollback_id": rollback.get("rollback_id"),
                    "new_version": capability.get("version"),
                    "from_version": rollback.get("from_version"),
                    "target_version": rollback.get("target_version"),
                    "reason": normalized_reason,
                },
            )
            return durable

    def invalidate_for_drift(self, drift_report, actor="schema_drift_monitor"):
        result = self.loop.invalidate_capabilities_for_drift(drift_report, actor=actor)
        durable = [self._persist_capability(row) for row in result.get("invalidated") or []]
        invalidated_ids = {row.get("capability_id") for row in durable if row}
        reopened = []
        state_conflicts = 0
        unresolved_job_ids = []
        if invalidated_ids:
            for scanned_job in self._all_learning_jobs():
                job_id = str(scanned_job.get("job_id") or "")
                if not job_id:
                    continue
                for _attempt in range(3):
                    with self.lock:
                        # The cursor snapshot may be stale. Re-read immediately
                        # before deriving the replacement and bind the write to
                        # both lifecycle state and durable row version so another
                        # service can never have its payload overwritten.
                        job = self.store.get_learning_job(job_id)
                        if not job:
                            break
                        promoted = (
                            (
                                (job.get("payload") or {}).get(
                                    "promoted_capability"
                                )
                                or {}
                            ).get("capability_id")
                        )
                        if promoted not in invalidated_ids:
                            break
                        payload = dict(job.get("payload") or {})
                        payload["drift_invalidation"] = {
                            "snapshot_id": drift_report.get(
                                "current_snapshot_id"
                            ),
                            "at": utc_now(),
                        }
                        try:
                            reopened.append(
                                self._write_job_locked(
                                    {
                                        **job,
                                        "state": "blocked_by_metadata",
                                        "payload": payload,
                                    },
                                    actor=actor,
                                    reason="REDACTED_OPAQUE_VALUE",
                                    prior_state=job.get("state"),
                                    audit_action="REDACTED_OPAQUE_VALUE",
                                    expected_state=job.get("state"),
                                    expected_updated_at=job.get("updated_at"),
                                )
                            )
                            break
                        except LearningConflictError:
                            state_conflicts += 1
                            continue
                else:
                    with self.lock:
                        current = self.store.get_learning_job(job_id)
                        promoted = (
                            (
                                ((current or {}).get("payload") or {}).get(
                                    "promoted_capability"
                                )
                                or {}
                            ).get("capability_id")
                        )
                        if promoted in invalidated_ids:
                            unresolved_job_ids.append(job_id)
                            snapshot_id = str(
                                drift_report.get("current_snapshot_id")
                                or "unknown"
                            )
                            notification_id = _notification_id(
                                "REDACTED_OPAQUE_VALUE",
                                "learning_job",
                                job_id,
                                snapshot_id,
                            )
                            if not self.store.get_notification(notification_id):
                                self._notify(
                                    "REDACTED_OPAQUE_VALUE",
                                    "learning_job",
                                    job_id,
                                    {
                                        "schema": "drift-learning-remediation/v1",
                                        "job_id": job_id,
                                        "snapshot_id": snapshot_id,
                                        "human_or_worker_retry_required": True,
                                    },
                                    recipient="runtime_operators",
                                    unique_suffix=snapshot_id,
                                )
                            self._audit(
                                "REDACTED_OPAQUE_VALUE",
                                actor,
                                "learning_job",
                                job_id,
                                outcome="failed",
                                details={
                                    "snapshot_id": snapshot_id,
                                    "reason": "REDACTED_OPAQUE_VALUE",
                                },
                            )
        remediation_status = (
            "incomplete"
            if unresolved_job_ids
            else "complete"
            if invalidated_ids
            else "not_required"
        )
        return {
            **result,
            "status": (
                "invalidation_incomplete"
                if unresolved_job_ids
                else result.get("status")
            ),
            "invalidated": durable,
            "reopened_jobs": [self.public_job(row) for row in reopened],
            "state_conflicts": state_conflicts,
            "remediation_status": remediation_status,
            "unresolved_job_ids": unresolved_job_ids,
        }

    def acknowledge_notification(
        self,
        notification_id,
        actor="local_user",
        *,
        actor_role=None,
    ):
        notification = self.store.get_notification(notification_id)
        if not notification:
            raise KeyError("Unknown notification: %s" % notification_id)
        if actor_role is not None and not self._notification_visible_to(
            notification, actor, actor_role
        ):
            raise PermissionError("Notification is not visible to the current actor")
        if notification.get("status") == "delivered":
            return notification
        if notification.get("status") != "pending":
            raise LearningConflictError(
                "Only a pending notification can be acknowledged"
            )
        try:
            delivered = self.store.upsert_notification(
                {
                    **notification,
                    "status": "delivered",
                    "delivered_at": utc_now(),
                    "attempts": int(notification.get("attempts") or 0) + 1,
                },
                expected_status="pending",
            ).record
            self._invalidate_metrics_cache()
        except StateConflictError:
            current = self.store.get_notification(notification_id)
            if current and current.get("status") == "delivered":
                return current
            raise LearningConflictError(
                "Notification state changed before acknowledgement"
            ) from None
        self._audit(
            "notification_acknowledged",
            actor,
            "notification",
            notification_id,
        )
        return delivered

    def reconcile_overdue_escalations(self, *, now=None, jobs=None):
        """Create one durable, idempotent SLA escalation per overdue job.

        This is deliberately separate from ``metrics`` so a health read never
        claims that an escalation was sent. When ``jobs`` is omitted the scan
        uses deterministic owner-scoped cursor pages so every durable job is
        examined, independent of dashboard use or backlog size.
        """
        current = now or utc_now()
        created = []
        examined = 0

        def pages():
            if jobs is not None:
                yield list(jobs)
                return
            after_job_id = None
            while True:
                page = self.store.list_learning_jobs_page(
                    after_job_id=after_job_id,
                    limit=1000,
                )
                if not page:
                    return
                yield page
                after_job_id = str(page[-1].get("job_id") or "")
                if not after_job_id:
                    raise LearningConflictError(
                        "Learning-job page ended without a cursor"
                    )

        for source in pages():
            examined += len(source)
            for scanned_job in source:
                scanned_job_id = str(scanned_job.get("job_id") or "")
                if not scanned_job_id:
                    continue
                # Normal lifecycle mutations use the same service lock. Re-read
                # the durable job while holding it so a stale page snapshot can
                # never emit an alert for a superseded state or recipient.
                with self.lock:
                    job = self.store.get_learning_job(scanned_job_id)
                    if not job:
                        continue
                    job_id = str(job.get("job_id") or "")
                    operations = _job_operational_snapshot(job, now=current)
                    sla = operations.get("sla") or {}
                    if (
                        (operations.get("escalation") or {}).get("required")
                        is not True
                    ):
                        continue
                    responsibility = operations.get("responsibility") or {}
                    recipient = (
                        responsibility.get("actor_id")
                        or responsibility.get("team")
                        or responsibility.get("role")
                        or "runtime_operators"
                    )
                    routing_generation = str(
                        (operations.get("escalation") or {}).get(
                            "routing_generation"
                        )
                        or ""
                    )
                    notification_id = _notification_id(
                        "learning_job_sla_overdue",
                        "learning_job",
                        job_id,
                        routing_generation,
                    )
                    occurred_at = utc_now()
                    audit_event_id = store_stable_id(
                        "audit",
                        "learning_job_sla_escalated:%s" % notification_id,
                    )
                    try:
                        write = self.store.upsert_sla_escalation(
                            {
                                "notification_id": notification_id,
                                "kind": "learning_job_sla_overdue",
                                "recipient": recipient,
                                "subject_type": "learning_job",
                                "subject_id": job_id,
                                "payload": {
                                    "job_id": job_id,
                                    "learning_level": sla.get("learning_level"),
                                    "due_at": sla.get("due_at"),
                                    "queue_id": (
                                        operations.get("queue") or {}
                                    ).get("queue_id"),
                                    "routing_generation": routing_generation,
                                },
                                "available_at": occurred_at,
                            },
                            {
                                "event_id": audit_event_id,
                                "action": "learning_job_sla_escalated",
                                "actor": "learning_operations",
                                "subject_type": "learning_job",
                                "subject_id": job_id,
                                "outcome": "succeeded",
                                "details": {
                                    "due_at": sla.get("due_at"),
                                    "learning_level": sla.get("learning_level"),
                                    "recipient_policy": recipient,
                                    "routing_generation": routing_generation,
                                    "notification_id": notification_id,
                                },
                                "occurred_at": occurred_at,
                            },
                            expected_job_state=job.get("state"),
                            expected_job_updated_at=job.get("updated_at"),
                        )
                    except StateConflictError:
                        # A cross-process transition won the row lock after this
                        # scan. The alert and audit transaction is rolled back.
                        continue
                    if write.status == "inserted":
                        created.append(write.record)
                        self._invalidate_metrics_cache()
        return {
            "status": "reconciled",
            "examined_jobs": examined,
            "created_notifications": len(created),
            "notifications": created,
        }

    def record_query_audit(self, result, actor="learning_system"):
        """Audit a query decision without retaining SQL or result values."""
        result = result or {}
        if not result.get("request_context"):
            return {
                "status": "skipped_unscoped_result",
                "reason": "query result has no immutable production request context",
            }
        sql = str(result.get("sql") or "")
        execution = result.get("live_execution") or {}
        security = execution.get("security_validation") or {}
        read_only = execution.get("read_only_validation") or {}
        subject_id = execution.get("execution_id") or store_stable_id(
            "query-request",
            "%s:%s:%s" % (actor, result.get("question"), utc_now()),
        )
        decision = safe_answer_decision(result)
        learning_required = not safe_answer_decision_is_known(decision)
        learning_job = result.get("learning_job") or {}
        learning_job_id = learning_job.get("job_id")
        learning_capture_status = (
            "captured"
            if learning_required and learning_job_id
            else "missing"
            if learning_required
            else "not_required"
        )
        return self._audit(
            "query_execution_decision",
            actor,
            "query_execution",
            subject_id,
            outcome=(
                "executed"
                if execution.get("status") == "executed"
                else "denied"
                if security.get("status") == "failed" or read_only.get("status") == "failed"
                else "not_executed"
            ),
            details={
                "answer_status": result.get("status"),
                "intent": ((result.get("resolved_intent") or {}).get("intent") if isinstance(result.get("resolved_intent") or {}, dict) else None),
                "sql_sha256": hashlib.sha256(sql.encode("utf-8")).hexdigest() if sql else None,
                "sql_length": len(sql),
                "security_status": security.get("status"),
                "read_only_status": read_only.get("status"),
                "live_execution_status": execution.get("status"),
                "redash_execution_id": execution.get("execution_id"),
                "row_count": result.get("row_count"),
                "result_truncated": result.get("result_truncated"),
                "capability_id": (((result.get("learning_job") or {}).get("result") or {}).get("capability_id")),
                "learning_required": learning_required,
                "learning_capture_status": learning_capture_status,
                "learning_job_id": learning_job_id,
                "safe_answer_decision": decision,
                "request_context": result.get("request_context") or {},
            },
        )

    def _current_model_metrics(self):
        model_metrics_limit = 5000
        model_metrics_window = {
            "maximum_records": model_metrics_limit,
            "ordering": "append_order_oldest_first",
        }
        try:
            # Fetch one sentinel row beyond the reporting window so exactly
            # 5,000 observations are not incorrectly reported as truncated.
            model_probe = self.store.list_model_interactions(
                limit=model_metrics_limit + 1
            )
            model_rows = model_probe[:model_metrics_limit]
            model_metrics = aggregate_model_interactions(model_rows)
            model_metrics["truncated"] = len(model_probe) > model_metrics_limit
            model_metrics["window"] = {
                **model_metrics_window,
                "records_aggregated": len(model_rows),
            }
        except Exception:
            model_metrics = aggregate_model_interactions(())
            model_metrics["status"] = "unavailable"
            model_metrics["truncated"] = False
            model_metrics["window"] = {
                **model_metrics_window,
                "records_aggregated": 0,
            }
        model_metrics["shadow_dispatch"] = shadow_dispatch_status()
        return model_metrics

    @staticmethod
    def _audit_metrics_from_events(events, *, state=None):
        aggregate = copy.deepcopy(
            state
            or {
                "after_sequence": 0,
                "audit_events_scanned": 0,
                "owner_policy_denials": 0,
                "query_decisions": 0,
                "learning_required": 0,
                "learning_captured": 0,
            }
        )
        for row in events:
            if not isinstance(row, dict):
                continue
            try:
                sequence = int(row.get("sequence") or 0)
            except (TypeError, ValueError):
                sequence = 0
            aggregate["after_sequence"] = max(
                aggregate["after_sequence"], sequence
            )
            aggregate["audit_events_scanned"] += 1
            if row.get("action") != "query_execution_decision":
                continue
            if row.get("outcome") == "denied":
                aggregate["owner_policy_denials"] += 1
            details = _object_or_empty(row.get("details"))
            learning_required = details.get("learning_required")
            if not isinstance(learning_required, bool):
                continue
            aggregate["query_decisions"] += 1
            if learning_required:
                aggregate["learning_required"] += 1
                if details.get("learning_capture_status") == "captured":
                    aggregate["learning_captured"] += 1
        return aggregate

    def _advance_audit_metrics(self):
        state = copy.deepcopy(self._audit_metrics_state) or self._audit_metrics_from_events(
            self._all_audit_events()
        )
        if self._audit_metrics_state is None:
            self._audit_metrics_state = state
            return copy.deepcopy(state), False
        after_sequence = int(state.get("after_sequence") or 0)
        governance_change_observed = False
        while True:
            page = self.store.list_audit_events(
                after_sequence=after_sequence,
                limit=5000,
            )
            if not page:
                break
            governance_change_observed = governance_change_observed or any(
                isinstance(row, dict)
                and row.get("action") != "query_execution_decision"
                for row in page
            )
            state = self._audit_metrics_from_events(page, state=state)
            next_sequence = int(state.get("after_sequence") or 0)
            if next_sequence <= after_sequence:
                raise LearningConflictError(
                    "Audit metrics cursor did not advance"
                )
            after_sequence = next_sequence
        self._audit_metrics_state = state
        return copy.deepcopy(state), governance_change_observed

    @staticmethod
    def _apply_dynamic_metrics(metrics, audit_state, model_metrics):
        output = copy.deepcopy(metrics)
        query_decisions = int(audit_state.get("query_decisions") or 0)
        required = int(audit_state.get("learning_required") or 0)
        captured = int(audit_state.get("learning_captured") or 0)
        if not query_decisions:
            capture_status = "no_observations"
        elif not required:
            capture_status = "no_required_learning"
        else:
            capture_status = "measured"
        output["unknown_capture_rate"] = captured / required if required else None
        output["unknown_capture_measurement"] = {
            "status": capture_status,
            "query_decisions": query_decisions,
            "learning_required": required,
            "learning_captured": captured,
            "audit_events_scanned": int(
                audit_state.get("audit_events_scanned") or 0
            ),
            "complete_lifetime_scan": True,
            "incremental_after_sequence": int(
                audit_state.get("after_sequence") or 0
            ),
        }
        output["owner_policy_denials"] = int(
            audit_state.get("owner_policy_denials") or 0
        )
        output["model_advisor"] = copy.deepcopy(model_metrics)
        return output

    @staticmethod
    def _time_metrics_state_from_jobs(jobs):
        due_timestamps = []
        earliest_created_timestamp = None
        for row in jobs:
            if row.get("state") in TERMINAL_JOB_STATES:
                continue
            payload = _object_or_empty(row.get("payload"))
            try:
                level = int(payload.get("learning_level") or 2)
            except (TypeError, ValueError):
                level = 2
            level = level if level in LEARNING_SLA_HOURS else 2
            try:
                created = dt.datetime.fromisoformat(
                    str(row.get("created_at")).replace("Z", "+00:00")
                )
                created_timestamp = created.timestamp()
            except (TypeError, ValueError):
                continue
            if (
                earliest_created_timestamp is None
                or created_timestamp < earliest_created_timestamp
            ):
                earliest_created_timestamp = created_timestamp
            due_timestamps.append(
                created_timestamp + LEARNING_SLA_HOURS[level] * 3600
            )
        return {
            "due_timestamps": sorted(due_timestamps),
            "earliest_created_timestamp": earliest_created_timestamp,
        }

    @staticmethod
    def _apply_time_metrics(metrics, time_state, *, now=None):
        output = copy.deepcopy(metrics)
        backlog = _object_or_empty(output.get("learning_backlog"))
        due_timestamps = list(time_state.get("due_timestamps") or [])
        now_timestamp = (
            now.timestamp()
            if isinstance(now, dt.datetime)
            else dt.datetime.now(dt.timezone.utc).timestamp()
        )
        backlog["overdue_jobs"] = bisect.bisect_left(
            due_timestamps, now_timestamp
        )
        earliest = time_state.get("earliest_created_timestamp")
        backlog["oldest_open_hours"] = (
            max(0.0, (now_timestamp - earliest) / 3600.0)
            if isinstance(earliest, (int, float))
            and not isinstance(earliest, bool)
            else None
        )
        output["learning_backlog"] = backlog
        return output

    def metrics(
        self,
        *,
        jobs=None,
        audit_events=None,
        store_stats=None,
        capability_admission=None,
        model_metrics=None,
    ):
        jobs = list(jobs if jobs is not None else self._all_learning_jobs())
        duplicate_groups = _open_duplicate_groups(jobs)
        states = Counter(str(row.get("state") or "unknown") for row in jobs)
        total = len(jobs)
        resolved = states.get("resolved", 0)
        repeat_unknowns = sum(
            1
            for row in jobs
            if _nonnegative_int(
                _object_or_empty(row.get("payload")).get("occurrences")
            )
            > 1
            and row.get("state") != "resolved"
        )
        capability_admission = (
            capability_admission
            if capability_admission is not None
            else self.capability_admission_report(
                learning_jobs=jobs,
                limit=5000,
            )
        )
        active = capability_admission["admitted"]
        classified = sum(
            1
            for row in jobs
            if (
                _object_or_empty(row.get("payload")).get("failure_type")
                in FAILURE_TYPES
            )
        )
        learned_resolutions = sum(
            1
            for row in jobs
            if row.get("state") == "resolved"
            and isinstance(
                _object_or_empty(row.get("payload")).get("promoted_capability"),
                dict,
            )
        )
        resolution_hours = []
        resolved_hours_by_level = {1: [], 2: [], 3: []}
        for row in jobs:
            if row.get("state") != "resolved":
                continue
            try:
                created = dt.datetime.fromisoformat(str(row.get("created_at")).replace("Z", "+00:00"))
                updated = dt.datetime.fromisoformat(str(row.get("updated_at")).replace("Z", "+00:00"))
                resolution_hours.append(max(0.0, (updated - created).total_seconds() / 3600.0))
                try:
                    learning_level = int(
                        (_object_or_empty(row.get("payload")).get("learning_level") or 2)
                    )
                except (TypeError, ValueError):
                    learning_level = 2
                if learning_level not in resolved_hours_by_level:
                    learning_level = 2
                resolved_hours_by_level[learning_level].append(
                    resolution_hours[-1]
                )
            except (TypeError, ValueError):
                continue
        now = dt.datetime.now(dt.timezone.utc)
        learning_sla_hours = dict(LEARNING_SLA_HOURS)
        open_ages = []
        overdue_jobs = 0
        backlog_by_level = Counter()
        for row in jobs:
            if row.get("state") in TERMINAL_JOB_STATES:
                continue
            payload = _object_or_empty(row.get("payload"))
            try:
                learning_level = int(payload.get("learning_level") or 2)
            except (TypeError, ValueError):
                learning_level = 2
            learning_level = learning_level if learning_level in learning_sla_hours else 2
            backlog_by_level[learning_level] += 1
            try:
                created = dt.datetime.fromisoformat(str(row.get("created_at")).replace("Z", "+00:00"))
                age_hours = max(0.0, (now - created).total_seconds() / 3600.0)
                open_ages.append(age_hours)
                if age_hours > learning_sla_hours[learning_level]:
                    overdue_jobs += 1
            except (TypeError, ValueError):
                continue
        audit = list(
            audit_events
            if audit_events is not None
            else self._all_audit_events()
        )
        store_stats = store_stats or self.store.stats()
        owner_policy_denials = sum(
            1
            for row in audit
            if row.get("action") == "query_execution_decision"
            and row.get("outcome") == "denied"
        )
        measured_query_decisions = [
            row
            for row in audit
            if row.get("action") == "query_execution_decision"
            and isinstance(
                _object_or_empty(row.get("details")).get("learning_required"),
                bool,
            )
        ]
        required_learning = sum(
            1
            for row in measured_query_decisions
            if _object_or_empty(row.get("details")).get("learning_required")
            is True
        )
        captured_learning = sum(
            1
            for row in measured_query_decisions
            if _object_or_empty(row.get("details")).get("learning_required")
            is True
            and _object_or_empty(row.get("details")).get(
                "learning_capture_status"
            )
            == "captured"
        )
        unknown_capture_rate = (
            captured_learning / required_learning if required_learning else None
        )
        if not measured_query_decisions:
            capture_status = "no_observations"
        elif not required_learning:
            capture_status = "no_required_learning"
        else:
            capture_status = "measured"
        model_metrics = (
            copy.deepcopy(model_metrics)
            if model_metrics is not None
            else self._current_model_metrics()
        )
        return {
            "unknown_capture_rate": unknown_capture_rate,
            "unknown_capture_measurement": {
                "status": capture_status,
                "query_decisions": len(measured_query_decisions),
                "learning_required": required_learning,
                "learning_captured": captured_learning,
                "audit_events_scanned": len(audit),
                "complete_lifetime_scan": True,
            },
            "learning_measurement": {
                "status": "measured" if total else "no_observations",
                "jobs": total,
            },
            "classification_rate": (classified / total if total else None),
            "classified_jobs": classified,
            "jobs": total,
            "by_state": {key: states[key] for key in sorted(states)},
            "unknown_to_resolved_rate": (resolved / total if total else None),
            "resolved_jobs": resolved,
            "repeat_open_unknown_rate": (repeat_unknowns / total if total else None),
            "repeat_open_unknowns": repeat_unknowns,
            "duplicate_learning_gaps": {
                "open_groups": len(duplicate_groups),
                "grouped_jobs": sum(
                    int(group.get("job_count") or 0) for group in duplicate_groups
                ),
                "largest_group_jobs": max(
                    (int(group.get("job_count") or 0) for group in duplicate_groups),
                    default=0,
                ),
            },
            "learned_answer_share": (
                learned_resolutions / resolved if resolved else None
            ),
            "mean_resolution_hours": (
                sum(resolution_hours) / len(resolution_hours)
                if resolution_hours
                else None
            ),
            "resolution_sla": {
                "by_learning_level": {
                    str(level): {
                        "target_hours": learning_sla_hours[level],
                        "resolved_jobs": len(resolved_hours_by_level[level]),
                        "within_target": sum(
                            1
                            for hours in resolved_hours_by_level[level]
                            if hours <= learning_sla_hours[level]
                        ),
                        "rate": (
                            sum(
                                1
                                for hours in resolved_hours_by_level[level]
                                if hours <= learning_sla_hours[level]
                            )
                            / len(resolved_hours_by_level[level])
                            if resolved_hours_by_level[level]
                            else None
                        ),
                    }
                    for level in sorted(learning_sla_hours)
                }
            },
            "learning_backlog": {
                "open_jobs": sum(backlog_by_level.values()),
                "overdue_jobs": overdue_jobs,
                "oldest_open_hours": max(open_ages) if open_ages else None,
                "by_learning_level": {
                    str(level): backlog_by_level[level]
                    for level in sorted(learning_sla_hours)
                },
                "sla_hours": {
                    str(level): hours
                    for level, hours in sorted(learning_sla_hours.items())
                },
            },
            "active_capabilities": len(active),
            "capability_admission": capability_admission["summary"],
            "validation_runs": store_stats["counts"]["validation_runs"],
            "pending_notifications": self.store.count_notifications(
                status="pending"
            ),
            "owner_policy_denials": owner_policy_denials,
            "model_advisor": model_metrics,
            "targets": {
                "unknown_capture_rate": 1.0,
                "classification_rate": 0.99,
                "unknown_to_resolved_rate": 0.8,
                "repeat_open_unknown_rate_max": 0.05,
                "owner_policy_violations": 0,
                "unsafe_promotions": 0,
                "rollback_minutes_max": 5,
                "learning_sla_hours": {
                    "1": 4,
                    "2": 24,
                    "3": 72,
                },
            },
        }

    def _build_full_metrics_cache(self):
        # Audit first, then materialize governed state. A writer persists its
        # governed row before appending the corresponding audit event, so any
        # governance event observed after this baseline means the materialized
        # scans might have missed its row and the build must be retried. This
        # cross-process fence complements the in-process generation fence.
        for _attempt in range(8):
            audit_events = self._all_audit_events()
            audit_state = self._audit_metrics_from_events(audit_events)
            audit_cursor = int(audit_state.get("after_sequence") or 0)
            jobs = self._all_learning_jobs()
            store_stats = self.store.stats()
            model_metrics = self._current_model_metrics()
            refreshed_metrics = self.metrics(
                jobs=jobs,
                audit_events=audit_events,
                store_stats=store_stats,
                model_metrics=model_metrics,
            )
            time_metrics_state = self._time_metrics_state_from_jobs(jobs)
            integrity = copy.deepcopy(self.store.integrity_check())

            # Drain query-only appends into the exact counters. Any governed
            # append invalidates this build because it may refer to state that
            # was committed after the materialized scans above.
            retry_for_governance = False
            while True:
                tail = self.store.list_audit_events(
                    after_sequence=audit_cursor,
                    limit=5000,
                )
                if not tail:
                    break
                if any(
                    isinstance(row, dict)
                    and row.get("action") != "query_execution_decision"
                    for row in tail
                ):
                    retry_for_governance = True
                    break
                audit_events.extend(tail)
                audit_state = self._audit_metrics_from_events(
                    tail,
                    state=audit_state,
                )
                next_cursor = int(audit_state.get("after_sequence") or 0)
                if next_cursor <= audit_cursor:
                    raise LearningConflictError(
                        "Full metrics audit fence did not advance"
                    )
                audit_cursor = next_cursor
            if retry_for_governance:
                continue

            refreshed_metrics = self._apply_dynamic_metrics(
                refreshed_metrics,
                audit_state,
                model_metrics,
            )
            refreshed_metrics = self._apply_time_metrics(
                refreshed_metrics,
                time_metrics_state,
            )
            refreshed_counts = _object_or_empty(store_stats.get("counts"))
            refreshed_counts["audit_events"] = int(
                audit_state.get("audit_events_scanned") or 0
            )
            store_stats["counts"] = refreshed_counts
            generated_at = utc_now()
            generated_monotonic = time.monotonic()
            return (
                {
                    "generated_at": generated_at,
                    "monotonic": generated_monotonic,
                    "metrics": refreshed_metrics,
                    "store_stats": {
                        key: copy.deepcopy(store_stats.get(key))
                        for key in (
                            "status",
                            "backend",
                            "schema",
                            "schema_version",
                            "owner_id",
                            "counts",
                        )
                        if key in store_stats
                    },
                    "integrity": integrity,
                    "time_metrics_state": time_metrics_state,
                    "store_generated_at": generated_at,
                    "store_monotonic": generated_monotonic,
                    "store_append_only_refreshed_at": generated_at,
                    "model_interactions_count_exact": True,
                    "dirty": False,
                    "last_refresh_kind": "full_governance_snapshot",
                },
                audit_state,
            )
        raise LearningConflictError(
            "Full metrics snapshot could not reach a stable governance tail"
        )

    def refresh_metrics_snapshot(self):
        """Synchronously prewarm a full snapshot outside request handling."""
        with self.lock:
            generation = self._metrics_generation
        cached, audit_state = self._build_full_metrics_cache()
        with self.lock:
            if generation != self._metrics_generation:
                return {"status": "REDACTED_OPAQUE_VALUE"}
            self._metrics_cache = cached
            self._audit_metrics_state = audit_state
            self._metrics_refresh_error = None
        return {
            "status": "refreshed",
            "generated_at": cached["generated_at"],
            "refresh_kind": "full_governance_snapshot",
        }

    def _refresh_metrics_snapshot_async(self, generation):
        try:
            cached, audit_state = self._build_full_metrics_cache()
        except BaseException as exc:
            with self.lock:
                self._metrics_refresh_error = type(exc).__name__
                self._metrics_refresh_thread = None
            return
        with self.lock:
            if generation == self._metrics_generation:
                self._metrics_cache = cached
                self._audit_metrics_state = audit_state
                self._metrics_refresh_error = None
            self._metrics_refresh_thread = None

    def _schedule_metrics_snapshot_refresh(self):
        worker = self._metrics_refresh_thread
        if worker is not None and worker.is_alive():
            return
        generation = self._metrics_generation
        worker = threading.Thread(
            target=self._refresh_metrics_snapshot_async,
            args=(generation,),
            name="learning-metrics-refresh",
            daemon=True,
        )
        self._metrics_refresh_thread = worker
        worker.start()

    @staticmethod
    def _validate_metrics_max_age(max_age_seconds):
        if isinstance(max_age_seconds, bool):
            raise ValueError("max_age_seconds must be a positive number")
        try:
            max_age = float(max_age_seconds)
        except (TypeError, ValueError) as exc:
            raise ValueError("max_age_seconds must be a positive number") from exc
        if max_age <= 0:
            raise ValueError("max_age_seconds must be a positive number")
        return max_age

    def metrics_snapshot(self, *, max_age_seconds=30):
        """Return a bounded, non-blocking monitoring snapshot.

        Production explicitly prewarms before listening. Governance dirtiness
        schedules a generation-fenced background rebuild and returns the prior
        snapshot as ``refresh_pending``; request handlers never perform that
        lifetime rebuild. Ordinary expiry advances append-only audit counters
        by sequence and refreshes only the fixed 5,001-row model window.
        """
        max_age = self._validate_metrics_max_age(max_age_seconds)
        with self.lock:
            cached = self._metrics_cache
            if cached is None:
                self._schedule_metrics_snapshot_refresh()
                return {
                    "store_snapshot": {
                        "stats": {"status": "warming"},
                        "integrity": {"status": "unavailable"},
                    },
                    "metrics_snapshot": {
                        "schema": "learning-metrics-snapshot/v1",
                        "generated_at": None,
                        "max_age_seconds": max_age,
                        "age_seconds": None,
                        "cache_status": "warming",
                        "freshness": "warming",
                        "refresh_kind": None,
                        "lifetime_rescan_required": True,
                    },
                }

            now_monotonic = time.monotonic()
            age = max(0.0, now_monotonic - cached["monotonic"])
            cache_status = "cached"
            freshness = "current"
            refresh_kind = cached.get("last_refresh_kind")
            lifetime_rescan_required = False
            if cached.get("dirty"):
                self._schedule_metrics_snapshot_refresh()
                cache_status = "refresh_pending"
                freshness = "refresh_pending"
                refresh_kind = "REDACTED_OPAQUE_VALUE"
                lifetime_rescan_required = True
            elif age > max_age:
                audit_state, governance_change_observed = (
                    self._advance_audit_metrics()
                )
                if governance_change_observed:
                    cached["dirty"] = True
                    self._metrics_cache = cached
                    self._schedule_metrics_snapshot_refresh()
                    cache_status = "refresh_pending"
                    freshness = "refresh_pending"
                    refresh_kind = "REDACTED_OPAQUE_VALUE"
                    lifetime_rescan_required = True
                else:
                    model_metrics = self._current_model_metrics()
                    refreshed_metrics = self._apply_dynamic_metrics(
                        cached["metrics"],
                        audit_state,
                        model_metrics,
                    )
                    refreshed_metrics = self._apply_time_metrics(
                        refreshed_metrics,
                        cached["time_metrics_state"],
                    )
                    refreshed_at = utc_now()
                    refreshed_store_stats = copy.deepcopy(
                        cached["store_stats"]
                    )
                    refreshed_counts = _object_or_empty(
                        refreshed_store_stats.get("counts")
                    )
                    refreshed_counts["audit_events"] = int(
                        audit_state.get("audit_events_scanned") or 0
                    )
                    model_count_exact = not bool(
                        model_metrics.get("truncated")
                    )
                    if model_count_exact:
                        refreshed_counts["model_interactions"] = int(
                            model_metrics.get("interactions") or 0
                        )
                    refreshed_store_stats["counts"] = refreshed_counts
                    cached = {
                        **cached,
                        "generated_at": refreshed_at,
                        "monotonic": time.monotonic(),
                        "metrics": refreshed_metrics,
                        "store_stats": refreshed_store_stats,
                        "store_append_only_refreshed_at": refreshed_at,
                        "model_interactions_count_exact": model_count_exact,
                        "dirty": False,
                        "last_refresh_kind": "incremental_append_only",
                    }
                    self._metrics_cache = cached
                    age = 0.0
                    cache_status = "refreshed"
                    refresh_kind = "incremental_append_only"
            output = copy.deepcopy(cached["metrics"])
            output["store_snapshot"] = {
                "stats": copy.deepcopy(cached["store_stats"]),
                "integrity": copy.deepcopy(cached["integrity"]),
                "observation": {
                    "generated_at": cached["store_generated_at"],
                    "age_seconds": round(
                        max(
                            0.0,
                            time.monotonic() - cached["store_monotonic"],
                        ),
                        6,
                    ),
                    "append_only_refreshed_at": cached[
                        "store_append_only_refreshed_at"
                    ],
                    "audit_events_count_exact": True,
                    "model_interactions_count_exact": cached[
                        "model_interactions_count_exact"
                    ],
                },
            }
            output["metrics_snapshot"] = {
                "schema": "learning-metrics-snapshot/v1",
                "generated_at": cached["generated_at"],
                "max_age_seconds": max_age,
                "age_seconds": round(age, 6),
                "cache_status": cache_status,
                "freshness": freshness,
                "refresh_kind": refresh_kind,
                "lifetime_rescan_required": lifetime_rescan_required,
                "last_refresh_error_type": self._metrics_refresh_error,
            }
            return output

    @staticmethod
    def _notification_visible_to(notification, actor_id, actor_role):
        if actor_role is None:
            return True
        if actor_role == "admin":
            return True
        recipient = str(notification.get("recipient") or "").strip()
        if recipient and recipient.casefold() == str(actor_id or "").strip().casefold():
            return True
        role_recipients = {
            "steward": {"steward", "analytics_stewards", "business_stewards"},
            "analyst": {"analyst"},
            "viewer": set(),
        }
        return recipient in role_recipients.get(str(actor_role), set())

    @staticmethod
    def _annotate_actor_queue(job, actor_id, actor_role, permissions):
        operations = job.get("operations") or {}
        responsibility = operations.get("responsibility") or {}
        queue = operations.get("queue") or {}
        permission_set = set(permissions or [])
        actor_matches = bool(
            responsibility.get("actor_id")
            and str(responsibility.get("actor_id")).casefold()
            == str(actor_id or "").casefold()
        )
        role_matches = bool(
            (
                actor_role == "admin"
                and queue.get("queue_id") != "closed_history"
            )
            or (
                not responsibility.get("actor_id")
                and responsibility.get("role")
                and responsibility.get("role") == actor_role
            )
        )
        in_my_queue = bool(actor_matches or role_matches)
        required_permission = queue.get("required_permission")
        action_available = bool(
            in_my_queue
            and queue.get("in_product_action")
            and (
                actor_role == "admin"
                or not required_permission
                or required_permission in permission_set
            )
        )
        actor_separation_blocked = bool(
            job.get("state") == "validated"
            and queue.get("next_action") == "approve"
            and job.get("validator_id")
            and str(job.get("validator_id")).casefold()
            == str(actor_id or "").casefold()
        )
        if actor_separation_blocked:
            action_available = False
        queue["in_current_role_queue"] = in_my_queue
        queue["REDACTED_OPAQUE_VALUE"] = action_available
        if action_available:
            queue["action_block_reason"] = None
        elif actor_separation_blocked:
            queue["action_block_reason"] = "REDACTED_OPAQUE_VALUE"
        elif not in_my_queue:
            queue["action_block_reason"] = "owned_by_another_role"
        elif not queue.get("in_product_action"):
            queue["action_block_reason"] = "external_or_system_managed"
        else:
            queue["action_block_reason"] = "permission_not_granted"
        operations["queue"] = queue
        job["operations"] = operations
        return job

    @classmethod
    def _work_queue_summary(cls, jobs):
        queues = {}
        for job in jobs:
            operations = job.get("operations") or {}
            queue = operations.get("queue") or {}
            queue_id = str(queue.get("queue_id") or "unclassified")
            if queue_id == "closed_history":
                continue
            summary = queues.setdefault(
                queue_id,
                {
                    "queue_id": queue_id,
                    "responsible_role": (operations.get("responsibility") or {}).get("role"),
                    "responsible_team": (operations.get("responsibility") or {}).get("team"),
                    "required_permission": queue.get("required_permission"),
                    "job_ids": [],
                    "job_count": 0,
                    "overdue_jobs": 0,
                    "highest_priority": 0,
                },
            )
            summary["job_count"] += 1
            if len(summary["job_ids"]) < 1000:
                summary["job_ids"].append(job.get("job_id"))
            if (operations.get("sla") or {}).get("status") == "overdue":
                summary["overdue_jobs"] += 1
            summary["highest_priority"] = max(
                summary["highest_priority"],
                int((operations.get("priority") or {}).get("score") or 0),
            )
        return [
            {
                **row,
                "job_ids_truncated": row["job_count"] > len(row["job_ids"]),
            }
            for row in sorted(
                queues.values(),
                key=lambda item: (
                    -int(item.get("overdue_jobs") or 0),
                    -int(item.get("highest_priority") or 0),
                    str(item.get("queue_id") or ""),
                ),
            )
        ]

    def dashboard(
        self,
        state=None,
        limit=100,
        *,
        actor_id=None,
        actor_role=None,
        permissions=None,
        after_job_id=None,
    ):
        all_jobs = self._all_learning_jobs()
        if actor_role is None or actor_role in {"steward", "admin"}:
            self.reconcile_overdue_escalations(jobs=all_jobs)
        all_notifications = self.store.list_notifications(
            limit=5000,
            newest_first=True,
        )
        visible_notifications = [
            row
            for row in all_notifications
            if self._notification_visible_to(row, actor_id, actor_role)
        ]
        all_public_jobs = self.list_jobs(
            state=state,
            limit=None,
            actor_id=actor_id,
            actor_role=actor_role,
            jobs=all_jobs,
        )
        all_public_jobs = [
            self._annotate_actor_queue(
                row,
                actor_id,
                actor_role,
                permissions,
            )
            for row in all_public_jobs
        ]
        page_limit = max(1, min(int(limit), 1000))
        public_by_id = {
            str(row.get("job_id") or ""): row
            for row in all_public_jobs
            if row.get("job_id")
        }
        stable_jobs = sorted(
            public_by_id.values(),
            key=lambda row: (
                str(row.get("created_at") or ""),
                str(row.get("job_id") or ""),
            ),
        )
        ordered_ids = [str(row.get("job_id")) for row in stable_jobs]
        cursor = str(after_job_id or "").strip() or None
        if cursor is None:
            remaining_ids = ordered_ids
        else:
            cursor_row = public_by_id.get(cursor)
            if cursor_row is None:
                raise ValueError(
                    "after_job_id is not present in the current learning-job view"
                )
            cursor_key = (
                str(cursor_row.get("created_at") or ""),
                cursor,
            )
            remaining_ids = [
                str(row.get("job_id"))
                for row in stable_jobs
                if (
                    str(row.get("created_at") or ""),
                    str(row.get("job_id") or ""),
                )
                > cursor_key
            ]
        page_ids = remaining_ids[:page_limit]
        page_id_set = set(page_ids)
        # The cursor uses immutable creation identity; display within that
        # stable page retains the current operational priority order.
        jobs = [
            row
            for row in all_public_jobs
            if str(row.get("job_id") or "") in page_id_set
        ]
        has_more_jobs = len(remaining_ids) > len(page_ids)
        work_queues = self._work_queue_summary(all_public_jobs)
        current_role_jobs = [
            row
            for row in all_public_jobs
            if ((row.get("operations") or {}).get("queue") or {}).get(
                "in_current_role_queue"
            )
        ]
        current_role_job_ids = [
            row.get("job_id") for row in current_role_jobs[:1000]
        ]
        all_capability_versions = self._all_capability_versions()
        capability_admission = self.capability_admission_report(
            capability_versions=all_capability_versions,
            learning_jobs=all_jobs,
        )
        rollback_reviews = self.capability_rollback_reviews(
            all_capability_versions,
            admission_report=capability_admission,
        )
        relevant_capability_ids = {
            str(value).strip()
            for job in jobs
            for value in (
                _object_or_empty(job.get("promoted_capability")).get(
                    "capability_id"
                ),
                _object_or_empty(job.get("result")).get("capability_id"),
            )
            if isinstance(value, str) and value.strip()
        }
        newest_capability_versions = sorted(
            all_capability_versions,
            key=lambda row: (
                str(row.get("updated_at") or row.get("created_at") or ""),
                str(row.get("capability_id") or ""),
                int(row.get("version") or 0),
            ),
            reverse=True,
        )[:1000]
        capability_version_by_key = {
            (str(row.get("capability_id") or ""), row.get("version")): row
            for row in newest_capability_versions
        }
        for row in all_capability_versions:
            if row.get("capability_id") in relevant_capability_ids:
                capability_version_by_key.setdefault(
                    (str(row.get("capability_id") or ""), row.get("version")),
                    row,
                )
        capability_versions = sorted(
            capability_version_by_key.values(),
            key=lambda row: (
                str(row.get("updated_at") or row.get("created_at") or ""),
                str(row.get("capability_id") or ""),
                int(row.get("version") or 0),
            ),
            reverse=True,
        )
        all_latest_capabilities = sorted(
            capability_admission["latest"],
            key=lambda row: (
                str(row.get("updated_at") or row.get("created_at") or ""),
                str(row.get("capability_id") or ""),
            ),
            reverse=True,
        )
        latest_capability_by_id = {
            str(row.get("capability_id") or ""): row
            for row in all_latest_capabilities[:1000]
        }
        for row in all_latest_capabilities:
            if row.get("capability_id") in relevant_capability_ids:
                latest_capability_by_id.setdefault(
                    str(row.get("capability_id") or ""), row
                )
        capabilities = sorted(
            latest_capability_by_id.values(),
            key=lambda row: (
                str(row.get("updated_at") or row.get("created_at") or ""),
                str(row.get("capability_id") or ""),
            ),
            reverse=True,
        )
        displayed_capability_keys = {
            (str(row.get("capability_id") or ""), row.get("version"))
            for row in capabilities
            if row.get("capability_id") and type(row.get("version")) is int
        }
        for row in all_capability_versions:
            key = (str(row.get("capability_id") or ""), row.get("version"))
            if key in displayed_capability_keys:
                capability_version_by_key.setdefault(key, row)
        capability_versions = sorted(
            capability_version_by_key.values(),
            key=lambda row: (
                str(row.get("updated_at") or row.get("created_at") or ""),
                str(row.get("capability_id") or ""),
                int(row.get("version") or 0),
            ),
            reverse=True,
        )
        referenced_validation_ids = _referenced_validation_ids(
            [*jobs, *capability_versions, *capabilities]
        )
        recent_validations = self.store.list_validation_runs(
            limit=1000,
            newest_first=True,
        )
        validation_by_id = {
            str(row.get("validation_id") or ""): row
            for row in recent_validations
            if row.get("validation_id")
        }
        for row in self.store.get_validation_runs(referenced_validation_ids):
            validation_by_id.setdefault(str(row.get("validation_id") or ""), row)
        validations = sorted(
            validation_by_id.values(),
            key=lambda row: (
                str(row.get("created_at") or ""),
                str(row.get("validation_id") or ""),
            ),
            reverse=True,
        )
        learned_rule_versions = self.loop.learned_rule_history()
        latest_rules = {}
        for row in learned_rule_versions:
            latest_rules[row["rule_id"]] = row
        all_audit_events = self._all_audit_events()
        audit = [
            row
            for row in reversed(all_audit_events)
            if row.get("action") != "query_execution_decision"
            or bool(_object_or_empty(row.get("details")).get("request_context"))
        ][:250]
        store_status = self.store.stats()
        return {
            "contract_version": "learning-workspace/v1",
            "owner_id": TENANT_OWNER_ID,
            "failure_types": list(FAILURE_TYPES),
            "resolution_outcomes": list(RESOLUTION_OUTCOMES),
            "learning_levels": LEARNING_LEVELS,
            "validation_gates": list(VALIDATION_GATES),
            "metrics": self.metrics(
                jobs=all_jobs,
                audit_events=all_audit_events,
                store_stats=store_status,
                capability_admission=capability_admission,
            ),
            "operator_context": {
                "actor_id": actor_id,
                "role": actor_role,
                "permissions": sorted(set(permissions or [])),
            },
            "jobs": jobs,
            "jobs_page": {
                "ordering": "REDACTED_OPAQUE_VALUE",
                "after_job_id": cursor,
                "next_after_job_id": (
                    page_ids[-1] if has_more_jobs and page_ids else None
                ),
                "page_end_job_id": page_ids[-1] if page_ids else None,
                "returned_jobs": len(jobs),
                "total_matching_jobs": len(ordered_ids),
                "has_more": has_more_jobs,
                "truncated": has_more_jobs,
            },
            "work_queues": work_queues,
            "current_role_queue": {
                "job_ids": current_role_job_ids,
                "job_ids_truncated": len(current_role_jobs) > len(current_role_job_ids),
                "job_count": len(current_role_jobs),
                "overdue_jobs": sum(
                    1
                    for row in current_role_jobs
                    if ((row.get("operations") or {}).get("sla") or {}).get(
                        "status"
                    )
                    == "overdue"
                ),
            },
            "duplicate_groups": _open_duplicate_groups(all_jobs),
            "capabilities": capabilities,
            "capability_versions": capability_versions,
            "capability_rollback_reviews": rollback_reviews,
            "drift_evidence": self.current_drift_evidence(),
            "learned_rules": sorted(
                latest_rules.values(),
                key=lambda row: row.get("created_at") or "",
                reverse=True,
            ),
            "learned_rule_versions": learned_rule_versions,
            "validations": validations,
            "notifications": visible_notifications[:250],
            "audit": audit,
            "evidence_windows": {
                "validations": {
                    "ordering": "REDACTED_OPAQUE_VALUE",
                    "returned": len(validations),
                    "total": store_status["counts"]["validation_runs"],
                    "truncated": store_status["counts"]["validation_runs"]
                    > len(validations),
                },
                "audit": {
                    "ordering": "newest_relevant_first",
                    "returned": len(audit),
                    "total": store_status["counts"]["audit_events"],
                    "truncated": store_status["counts"]["audit_events"]
                    > len(audit),
                },
                "capability_versions": {
                    "ordering": "REDACTED_OPAQUE_VALUE",
                    "returned": len(capability_versions),
                    "total": store_status["counts"]["capability_versions"],
                    "truncated": store_status["counts"]["capability_versions"]
                    > len(capability_versions),
                },
            },
            "store": store_status,
        }


# LearningSLAReconciler now lives in its own module; re-exported here so
# existing callers (e.g. query_studio) keep importing it from learning_service.
from learning_sla_reconciler import LearningSLAReconciler  # noqa: E402


_DEFAULT_LEARNING_SERVICE = None


def _default_learning_service():
    """Lazily build the process-wide default LearningService.

    Constructing it opens the learning store and reconciles legacy records, so
    it is deferred to first use instead of running as an import side effect: a
    module that imports ``LearningService`` (the class) or other names from here
    no longer pays that cost — and does not open a store — merely by importing.
    """
    global _DEFAULT_LEARNING_SERVICE
    if _DEFAULT_LEARNING_SERVICE is None:
        _DEFAULT_LEARNING_SERVICE = LearningService()
    return _DEFAULT_LEARNING_SERVICE


def __getattr__(name):
    # PEP 562 module-level lazy attribute. Accessing DEFAULT_LEARNING_SERVICE
    # (including ``from learning_service import DEFAULT_LEARNING_SERVICE``)
    # constructs it on demand and caches it.
    if name == "DEFAULT_LEARNING_SERVICE":
        return _default_learning_service()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "CANDIDATE_VALIDATION_STATES",
    "DEFAULT_LEARNING_SERVICE",
    "LearningSLAReconciler",
    "LearningService",
    "LearningConflictError",
    "TERMINAL_JOB_STATES",
    "VALIDATION_GATES",
]
