#!/usr/bin/env python3
"""Export only current, accepted owner-2 drift evidence into an artifact bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import sys
import tempfile


ROOT = pathlib.Path(__file__).resolve().parents[1]
WORK = ROOT / "work/redash_schema"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(WORK) not in sys.path:
    sys.path.insert(0, str(WORK))

from runtime_config import TENANT_OWNER_ID  # noqa: E402
from schema_drift import (  # noqa: E402
    DEFAULT_DRIFT_MAX_AGE_SECONDS,
    drift_evidence_gate,
)
from scripts.runtime_artifacts import (  # noqa: E402
    DRIFT_EVIDENCE_PATH,
    DRIFT_EVIDENCE_SCHEMA,
    PRODUCTION_SCOPE,
    validate_schema_drift_evidence,
)


DRIFT_ARTIFACT_PATH = pathlib.PurePosixPath(DRIFT_EVIDENCE_PATH)
MAX_REPORT_BYTES = 16 * 1024 * 1024


class DriftEvidenceExportError(ValueError):
    """Raised when runtime drift evidence is unsafe or ineligible for export."""


def _read_regular_json(path):
    path = pathlib.Path(path)
    if not path.is_absolute():
        raise DriftEvidenceExportError("source_path_not_absolute")
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise DriftEvidenceExportError("source_unavailable") from exc
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= MAX_REPORT_BYTES:
            raise DriftEvidenceExportError("source_not_bounded_regular_file")
        payload = bytearray()
        while len(payload) <= MAX_REPORT_BYTES:
            chunk = os.read(
                descriptor,
                min(1024 * 1024, MAX_REPORT_BYTES + 1 - len(payload)),
            )
            if not chunk:
                break
            payload += chunk
        after = os.fstat(descriptor)
        if (
            len(payload) > MAX_REPORT_BYTES
            or before.st_dev != after.st_dev
            or before.st_ino != after.st_ino
            or before.st_size != after.st_size
            or len(payload) != before.st_size
        ):
            raise DriftEvidenceExportError("source_changed_during_read")
    finally:
        os.close(descriptor)
    try:
        report = json.loads(bytes(payload).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DriftEvidenceExportError("source_json_invalid") from exc
    if not isinstance(report, dict):
        raise DriftEvidenceExportError("source_report_invalid")
    return report, bytes(payload)


def validate_exportable_drift_report(report, *, now=None):
    gate = drift_evidence_gate(
        report,
        now=now,
        max_age_seconds=DEFAULT_DRIFT_MAX_AGE_SECONDS,
        environ={},
    )
    if (
        gate.get("status") != "accepted"
        or gate.get("freshness") != "current"
        or gate.get("owner_id") != TENANT_OWNER_ID
        or report.get("status") != "unchanged"
        or report.get("previous_snapshot_id") != report.get("current_snapshot_id")
    ):
        raise DriftEvidenceExportError("drift_gate_not_accepted")
    if report.get("changed_count") not in {None, 0}:
        raise DriftEvidenceExportError("drift_changes_present")
    for section_name in ("catalog", "lowcode"):
        section = report.get(section_name)
        if not isinstance(section, dict) or any(
            section.get(bucket) not in (None, [])
            for bucket in ("added", "removed", "changed")
        ):
            raise DriftEvidenceExportError("drift_changes_present")
    for field in ("impacted_provider_contracts", "security_impacts"):
        if report.get(field) not in (None, []):
            raise DriftEvidenceExportError("drift_impacts_present")
    affected = report.get("affected_query_artifacts")
    if (
        not isinstance(affected, dict)
        or affected.get("traces") != []
        or affected.get("saved_patterns") != []
        or affected.get("truncated") is not False
    ):
        raise DriftEvidenceExportError("REDACTED_OPAQUE_VALUE")
    consumer = report.get("consumer_result")
    if (
        not isinstance(consumer, dict)
        or consumer.get("status") != "unchanged"
        or consumer.get("invalidated") != []
        or consumer.get("reopened_jobs") != []
        or type(consumer.get("state_conflicts")) is not int
        or consumer.get("state_conflicts") != 0
        or consumer.get("remediation_status") != "not_required"
        or consumer.get("unresolved_job_ids") != []
    ):
        raise DriftEvidenceExportError("drift_consumer_not_complete")
    return gate


def _project_binding():
    completed = subprocess.run(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
        timeout=10,
    )
    source_commit = completed.stdout.strip().lower()
    if completed.returncode != 0 or len(source_commit) != 40 or any(
        character not in "0123456789abcdef" for character in source_commit
    ):
        raise DriftEvidenceExportError("source_commit_unavailable")
    try:
        uv_lock_sha256 = hashlib.sha256((ROOT / "uv.lock").read_bytes()).hexdigest()
    except OSError as exc:
        raise DriftEvidenceExportError("uv_lock_unavailable") from exc
    return source_commit, uv_lock_sha256


def export_runtime_drift_evidence(source, destination_root, *, now=None):
    report, source_payload = _read_regular_json(source)
    gate = validate_exportable_drift_report(report, now=now)
    source_commit, uv_lock_sha256 = _project_binding()
    zero_counts = {"added_count": 0, "removed_count": 0, "changed_count": 0}
    envelope = {
        "schema": DRIFT_EVIDENCE_SCHEMA,
        "version": 1,
        "status": "unchanged",
        "captured_at": gate["captured_at"],
        "scope": dict(PRODUCTION_SCOPE),
        "source_commit": source_commit,
        "uv_lock_sha256": uv_lock_sha256,
        "source_report_sha256": hashlib.sha256(source_payload).hexdigest(),
        "previous_snapshot_id": gate["current_snapshot_id"],
        "current_snapshot_id": gate["current_snapshot_id"],
        "changed_count": 0,
        "catalog": dict(zero_counts),
        "lowcode": dict(zero_counts),
        "consumer": {
            "status": "unchanged",
            "invalidated_count": 0,
            "reopened_job_count": 0,
            "state_conflict_count": 0,
            "unresolved_job_count": 0,
            "remediation_status": "not_required",
        },
    }
    validate_schema_drift_evidence(
        envelope,
        expected_source_commit=source_commit,
        expected_uv_lock_sha256=uv_lock_sha256,
        now=now,
    )
    destination_root = pathlib.Path(destination_root)
    if (
        not destination_root.is_absolute()
        or destination_root.is_symlink()
        or not destination_root.is_dir()
    ):
        raise DriftEvidenceExportError("destination_root_invalid")
    current = destination_root
    for part in DRIFT_ARTIFACT_PATH.parent.parts:
        current = current / part
        if current.exists():
            if current.is_symlink() or not current.is_dir():
                raise DriftEvidenceExportError("destination_parent_invalid")
        else:
            current.mkdir(mode=0o700)
    destination = destination_root.joinpath(*DRIFT_ARTIFACT_PATH.parts)
    if destination.is_symlink() or (
        destination.exists() and not destination.is_file()
    ):
        raise DriftEvidenceExportError("destination_file_invalid")
    payload = (json.dumps(envelope, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    temporary_name = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            delete=False,
        ) as handle:
            temporary_name = handle.name
            os.chmod(handle.name, 0o600)
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
        temporary_name = None
    finally:
        if temporary_name is not None:
            pathlib.Path(temporary_name).unlink(missing_ok=True)
    return {
        "status": "exported",
        "owner_id": gate["owner_id"],
        "current_snapshot_id": gate["current_snapshot_id"],
        "captured_at": gate["captured_at"],
    }


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--destination-root", required=True)
    args = parser.parse_args(argv)
    try:
        report = export_runtime_drift_evidence(args.source, args.destination_root)
    except DriftEvidenceExportError as exc:
        parser.error(str(exc))
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
