#!/usr/bin/env python3
"""Start Schema Brain while holding the host service/restore lock end to end."""

from __future__ import annotations

import fcntl
import os
import pathlib
import re
import signal
import stat
import subprocess
import sys
from collections.abc import Callable, Mapping


SERVICE_RESTORE_LOCK = pathlib.Path("/run/schema-brain/service-restore.lock")
SECRETS_FILE = REDACTED_SECRET
ARTIFACT_DIR = pathlib.Path("REDACTED_OPAQUE_VALUE")
STATE_DIR = pathlib.Path("/var/lib/schema-brain/state")
PODMAN = "/usr/bin/podman"
POSTGRES_ROLE_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")
POSTGRES_BACKEND_ENV = "SCHEMA_BRAIN_LEARNING_" + "BACKEND"
POSTGRES_DATABASE_ENV = "SCHEMA_BRAIN_POSTGRES_" + "DATABASE"
POSTGRES_ROLE_ENV = "SCHEMA_BRAIN_POSTGRES_" + "APP_ROLE"


class StartupError(RuntimeError):
    """Fail-closed startup error whose code is safe for the service journal."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def _required_environment(environment: Mapping[str, str], name: str) -> str:
    value = environment.get(name)
    if not isinstance(value, str) or not value.strip():
        raise StartupError("required_environment_missing")
    return value


def _llm_environment_arguments(environment: Mapping[str, str]) -> list[str]:
    """Forward only reviewed non-secret LLM settings into the container."""
    insecure_transport = any(
        str(environment.get(name) or "").strip().lower()
        in {"1", "true", "yes", "on"}
        for name in (
            "REDACTED_OPAQUE_VALUE",
            "REDACTED_OPAQUE_VALUE",
        )
    )
    if insecure_transport:
        raise StartupError("REDACTED_OPAQUE_VALUE")
    mode = str(
        environment.get("SCHEMA_BRAIN_MODEL_ADVISOR_MODE") or "disabled"
    ).strip().lower()
    if mode not in {"disabled", "shadow", "assist"}:
        raise StartupError("llm_mode_invalid")
    arguments = [
        f"--env=SCHEMA_BRAIN_MODEL_ADVISOR_MODE={mode}",
    ]
    if mode != "disabled":
        endpoint = _required_environment(
            environment,
            "REDACTED_OPAQUE_VALUE",
        )
        if not endpoint.startswith("https://"):
            raise StartupError("llm_endpoint_https_required")
        arguments.append(
            f"--env=SCHEMA_BRAIN_MODEL_ADVISOR_ORIGIN={endpoint}"
        )
    return arguments


def _postgres_environment_arguments(environment: Mapping[str, str]) -> list[str]:
    """Forward the fixed backend and exact non-secret application role."""

    role_name = _required_environment(environment, POSTGRES_ROLE_ENV).strip()
    if (
        not POSTGRES_ROLE_RE.fullmatch(role_name)
        or role_name.startswith("pg_")
        or role_name == "postgres"
    ):
        raise StartupError("postgres_app_role_invalid")
    return [
        "--env=" + POSTGRES_BACKEND_ENV + "=postgresql",
        "--env=" + POSTGRES_DATABASE_ENV + "=dbprod_" + "learning",
        "--env=" + POSTGRES_ROLE_ENV + "=" + role_name,
    ]


def acquire_service_restore_lock(
    lock_path: pathlib.Path = SERVICE_RESTORE_LOCK,
    *,
    require_root: bool = True,
) -> int:
    """Open and exclusively lock a private coordination inode without following links."""

    if require_root and lock_path != SERVICE_RESTORE_LOCK:
        raise StartupError("REDACTED_OPAQUE_VALUE")
    if require_root and (not hasattr(os, "geteuid") or os.geteuid() != 0):
        raise StartupError("REDACTED_OPAQUE_VALUE")
    descriptor: int | None = None
    try:
        lock_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        parent_metadata = lock_path.parent.lstat()
        if (
            not stat.S_ISDIR(parent_metadata.st_mode)
            or stat.S_IMODE(parent_metadata.st_mode) != 0o700
        ):
            raise StartupError("REDACTED_OPAQUE_VALUE")
        if require_root and (
            parent_metadata.st_uid != 0 or parent_metadata.st_gid != 0
        ):
            raise StartupError("REDACTED_OPAQUE_VALUE")

        descriptor = os.open(
            lock_path,
            os.O_RDWR
            | os.O_CREAT
            | getattr(os, "O_CLOEXEC", 0)
            | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        lock_metadata = os.fstat(descriptor)
        if not stat.S_ISREG(lock_metadata.st_mode) or lock_metadata.st_nlink != 1:
            raise StartupError("REDACTED_OPAQUE_VALUE")
        if require_root and (lock_metadata.st_uid != 0 or lock_metadata.st_gid != 0):
            raise StartupError("REDACTED_OPAQUE_VALUE")
        os.fchmod(descriptor, 0o600)
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        if descriptor is not None:
            os.close(descriptor)
        raise StartupError("service_restore_lock_held") from exc
    except StartupError:
        if descriptor is not None:
            os.close(descriptor)
        raise
    except OSError as exc:
        if descriptor is not None:
            os.close(descriptor)
        raise StartupError("REDACTED_OPAQUE_VALUE") from exc
    return descriptor


def _preflight_command(environment: Mapping[str, str]) -> list[str]:
    manifest_digest = _required_environment(
        environment,
        "REDACTED_OPAQUE_VALUE",
    )
    image = _required_environment(environment, "SCHEMA_BRAIN_IMAGE_REFERENCE")
    command = [
        PODMAN,
        "run",
        "--rm",
        "--name",
        "schema-brain-preflight",
        "--pull=never",
        "--network=none",
        "--read-only",
        "--user=10001:10001",
        "--cap-drop=all",
        "REDACTED_OPAQUE_VALUE",
        "--tmpfs=/tmp:rw,noexec,nosuid,nodev,size=67108864",
        f"--env-file={SECRETS_FILE}",
        "REDACTED_OPAQUE_VALUE",
        "REDACTED_OPAQUE_VALUE",
        *_postgres_environment_arguments(environment),
        f"--env=DBPROD_EXPECTED_RUNTIME_ARTIFACT_MANIFEST_SHA256={manifest_digest}",
        f"--env=SCHEMA_BRAIN_ARTIFACT_DIR={ARTIFACT_DIR}",
        f"--env=SCHEMA_BRAIN_STATE_DIR={STATE_DIR}",
        *_llm_environment_arguments(environment),
        f"--mount=type=bind,source={ARTIFACT_DIR},target={ARTIFACT_DIR},readonly",
        f"--mount=type=bind,source={STATE_DIR},target={STATE_DIR}",
        image,
        "/app/.venv/bin/python",
        "-m",
        "runtime_preflight",
        "--production",
    ]
    return command


def _runtime_command(environment: Mapping[str, str]) -> list[str]:
    manifest_digest = _required_environment(
        environment,
        "REDACTED_OPAQUE_VALUE",
    )
    image = _required_environment(environment, "SCHEMA_BRAIN_IMAGE_REFERENCE")
    memory = _required_environment(environment, "SCHEMA_BRAIN_MEMORY_LIMIT")
    cpus = _required_environment(environment, "SCHEMA_BRAIN_CPU_LIMIT")
    command = [
        PODMAN,
        "run",
        "--rm",
        "--name",
        "schema-brain",
        "--pull=never",
        "--network=host",
        "--read-only",
        "--user=10001:10001",
        "--cap-drop=all",
        "REDACTED_OPAQUE_VALUE",
        "--pids-limit=512",
        f"--memory={memory}",
        f"--cpus={cpus}",
        "--tmpfs=/tmp:rw,noexec,nosuid,nodev,size=67108864",
        "--tmpfs=/run:rw,noexec,nosuid,nodev,size=16777216",
        f"--env-file={SECRETS_FILE}",
        "REDACTED_OPAQUE_VALUE",
        "REDACTED_OPAQUE_VALUE",
        *_postgres_environment_arguments(environment),
        f"--env=DBPROD_EXPECTED_RUNTIME_ARTIFACT_MANIFEST_SHA256={manifest_digest}",
        f"--env=SCHEMA_BRAIN_ARTIFACT_DIR={ARTIFACT_DIR}",
        f"--env=SCHEMA_BRAIN_STATE_DIR={STATE_DIR}",
        *_llm_environment_arguments(environment),
        "--env=HF_HUB_OFFLINE=1",
        "--env=TRANSFORMERS_OFFLINE=1",
        f"--mount=type=bind,source={ARTIFACT_DIR},target={ARTIFACT_DIR},readonly",
        f"--mount=type=bind,source={STATE_DIR},target={STATE_DIR}",
        "--log-driver=journald",
        image,
    ]
    return command


def _wait_for_runtime(
    command: list[str],
    environment: Mapping[str, str],
    *,
    popen_factory: Callable[..., subprocess.Popen] = subprocess.Popen,
) -> None:
    """Supervise Podman while the calling wrapper continues to own the lock."""

    process = popen_factory(command, env=dict(environment), close_fds=True)
    previous_handlers = {}

    def forward_signal(signum, _frame):
        if process.poll() is None:
            try:
                process.send_signal(signum)
            except ProcessLookupError:
                pass

    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            previous_handlers[signum] = signal.signal(signum, forward_signal)
        return_code = process.wait()
    finally:
        for signum, previous in previous_handlers.items():
            signal.signal(signum, previous)
    if return_code != 0:
        raise StartupError("runtime_process_failed")


def start_service(
    *,
    environ: Mapping[str, str] | None = None,
    lock_path: pathlib.Path = SERVICE_RESTORE_LOCK,
    state_dir: pathlib.Path = STATE_DIR,
    require_root: bool = True,
    runner: Callable[..., subprocess.CompletedProcess] = subprocess.run,
    popen_factory: Callable[..., subprocess.Popen] = subprocess.Popen,
) -> None:
    """Hold one lock across state preflight and the complete service lifetime."""

    environment = dict(os.environ if environ is None else environ)
    preflight_command = _preflight_command(environment)
    runtime_command = _runtime_command(environment)
    descriptor = acquire_service_restore_lock(lock_path, require_root=require_root)
    try:
        if not state_dir.is_dir():
            raise StartupError("state_directory_missing")
        if os.path.lexists(state_dir / "learning_store/.restore.lock"):
            raise StartupError("restore_activity_present")

        runner(
            [PODMAN, "rm", "--force", "--ignore", "schema-brain-preflight"],
            check=False,
        )
        runner(preflight_command, check=True)
        runner(
            [PODMAN, "rm", "--force", "--ignore", "schema-brain"],
            check=False,
        )

        _wait_for_runtime(
            runtime_command,
            environment,
            popen_factory=popen_factory,
        )
    except subprocess.CalledProcessError as exc:
        raise StartupError("container_preflight_failed") from exc
    except OSError as exc:
        raise StartupError("service_start_unavailable") from exc
    finally:
        os.close(descriptor)


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    if arguments:
        print("schema-brain startup failed: arguments_forbidden", file=sys.stderr)
        return 2
    try:
        start_service()
    except StartupError as exc:
        print(f"schema-brain startup failed: {exc.code}", file=sys.stderr)
        return 1
    except Exception:
        print("schema-brain startup failed: unexpected_failure", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
