#!/usr/bin/env python3
"""Side-effect-free repository and pilot preflight checks."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys
from typing import Iterable


ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_SCOPE = {
    "redash_base_url": "https://example.invalid",
    "datasource": "prod-my",
    "datasource_id": 25,
    "owner_id": 2,
}
FORBIDDEN_TRACKED_PREFIXES = (
    "outputs/",
    "REDACTED_OPAQUE_VALUE",
    "REDACTED_OPAQUE_VALUE",
)
FORBIDDEN_TRACKED_NAMES = {
    ".env",
    "work/redash_schema/query_studio_assets/lucide.min.js",
}
ALLOWED_TRACKED_ENV_PLACEHOLDERS = {".env.example"}
EXPECTED_MANIFEST_SHA256_ENV = "REDACTED_OPAQUE_VALUE"
NEURAL_MODULES = ("joblib", "numpy", "scipy", "sklearn", "sentence_transformers")


def result(name: str, passed: bool, detail: str) -> dict:
    return {"name": name, "status": "passed" if passed else "failed", "detail": detail}


def truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def tracked_files(root: pathlib.Path = ROOT) -> list[str]:
    completed = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=root,
        check=True,
        capture_output=True,
    )
    return sorted(
        item.decode("utf-8") for item in completed.stdout.split(b"\0") if item
    )


def check_tracked_hygiene(paths: Iterable[str]) -> dict:
    violations = []
    for raw in paths:
        path = str(raw).replace("\\", "/")
        name = pathlib.PurePosixPath(path).name
        if path in ALLOWED_TRACKED_ENV_PLACEHOLDERS:
            continue
        if path in FORBIDDEN_TRACKED_NAMES or path.startswith(FORBIDDEN_TRACKED_PREFIXES):
            violations.append(path)
        elif name == ".env" or name.startswith(".env."):
            violations.append(path)
        elif pathlib.PurePosixPath(path).suffix.lower() in {".pem", ".p12", ".pfx"}:
            violations.append(path)
    return result(
        "tracked_repository_hygiene",
        not violations,
        "no generated runtime artifacts or secret containers are tracked"
        if not violations
        else "forbidden tracked paths: " + ", ".join(sorted(violations)),
    )


def load_runtime_scope(root: pathlib.Path = ROOT) -> dict:
    path = root / "work/redash_schema/runtime_config.py"
    spec = importlib.util.spec_from_file_location("dbprod_runtime_config_preflight", path)
    if not spec or not spec.loader:
        raise RuntimeError("runtime_config.py could not be loaded")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(spec.name, None)
    return {
        "redash_base_url": module.REDASH_BASE_URL,
        "datasource": module.DATA_SOURCE_NAME,
        "datasource_id": module.REDASH_DATA_SOURCE_ID,
        "owner_id": module.TENANT_OWNER_ID,
    }


def check_production_scope(root: pathlib.Path = ROOT) -> dict:
    actual = load_runtime_scope(root)
    return result(
        "immutable_production_scope",
        actual == EXPECTED_SCOPE,
        "prod-my datasource 25 is fixed to owner 2"
        if actual == EXPECTED_SCOPE
        else "runtime production scope does not match the approved owner-2 contract",
    )


def check_python_files(root: pathlib.Path, paths: Iterable[str]) -> dict:
    checked = 0
    failures = []
    for relative in paths:
        if not relative.endswith(".py"):
            continue
        path = root / relative
        try:
            source = path.read_text(encoding="utf-8")
            compile(source, relative, "exec")
            checked += 1
        except (OSError, SyntaxError, UnicodeError) as exc:
            failures.append(f"{relative}: {type(exc).__name__}")
    return result(
        "python_source_compile",
        not failures,
        f"{checked} tracked Python files compile in memory"
        if not failures
        else "compile failures: " + ", ".join(failures),
    )


def check_lockfiles(root: pathlib.Path = ROOT) -> dict:
    required = ("uv.lock", "pnpm-lock.yaml", ".python-version", "requirements-ci.txt")
    missing = [name for name in required if not (root / name).is_file()]
    return result(
        "locked_toolchains",
        not missing,
        "Python and browser dependencies are locked"
        if not missing
        else "missing lock/pin files: " + ", ".join(missing),
    )


def check_json_contracts(root: pathlib.Path = ROOT) -> dict:
    paths = sorted((root / "schemas").glob("*.json"))
    paths.append(root / "package.json")
    failures = []
    for path in paths:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                failures.append(path.relative_to(root).as_posix())
        except (OSError, UnicodeError, json.JSONDecodeError):
            failures.append(path.relative_to(root).as_posix())
    return result(
        "json_contracts",
        bool(paths) and not failures,
        f"{len(paths)} JSON contracts parse"
        if paths and not failures
        else "invalid JSON contracts: " + ", ".join(failures),
    )


def check_browser_asset(root: pathlib.Path = ROOT) -> dict:
    path = root / "work/redash_schema/query_studio_assets/lucide.min.js"
    passed = path.is_file() and path.stat().st_size > 0
    return result(
        "generated_browser_asset",
        passed,
        "pinned Lucide browser asset is built" if passed else "run pnpm build:assets",
    )


def check_neural_modules() -> dict:
    missing = [name for name in NEURAL_MODULES if importlib.util.find_spec(name) is None]
    return result(
        "neural_runtime_dependencies",
        not missing,
        "neural runtime imports are installed"
        if not missing
        else "missing neural modules: " + ", ".join(missing),
    )


def check_production_environment(environment: dict[str, str] | os._Environ[str] = os.environ) -> list[dict]:
    require_auth = truthy(environment.get("SCHEMA_BRAIN_REQUIRE_AUTH"))
    identity_secret = str(environment.get("SCHEMA_BRAIN_IDENTITY_SECRET") or "")
    observability_secret = REDACTED_SECRET
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    )
    provenance_secret = REDACTED_SECRET
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    )
    runtime_hmac_values = (
        identity_secret.encode("utf-8"),
        observability_secret.encode("utf-8"),
        provenance_secret.encode("utf-8"),
    )
    runtime_hmac_keys_valid = (
        all(32 <= len(value) <= 4096 for value in runtime_hmac_values)
        and len(set(runtime_hmac_values)) == len(runtime_hmac_values)
    )
    redash_key = str(environment.get("REDASH_API_KEY") or "")
    legacy_replay = truthy(environment.get("REDACTED_OPAQUE_VALUE"))
    learning_backend = str(
        environment.get("SCHEMA_BRAIN_LEARNING_BACKEND") or ""
    ).strip().lower()
    postgres_secret = REDACTED_SECRET
        str(environment.get("SCHEMA_BRAIN_POSTGRES_DSN") or "").strip()
        or str(environment.get("SCHEMA_BRAIN_POSTGRES_DSN_FILE") or "").strip()
    )
    postgres_role = str(
        environment.get("SCHEMA_BRAIN_POSTGRES_APP_ROLE") or ""
    ).strip()
    postgres_role_valid = bool(
        re.fullmatch(r"[a-z_][a-z0-9_]{0,62}", postgres_role)
        and not postgres_role.startswith("pg_")
        and postgres_role != "postgres"
    )
    manifest_sha256 = str(
        environment.get(EXPECTED_MANIFEST_SHA256_ENV) or ""
    ).strip()
    manifest_pin_valid = bool(re.fullmatch(r"[0-9a-f]{64}", manifest_sha256))
    advisor_mode = str(
        environment.get("SCHEMA_BRAIN_MODEL_ADVISOR_MODE") or "disabled"
    ).strip().lower()
    advisor_origin = str(
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    ).strip()
    advisor_insecure_transport = any(
        truthy(environment.get(name))
        for name in (
            "REDACTED_OPAQUE_VALUE",
            "REDACTED_OPAQUE_VALUE",
        )
    )
    advisor_key = str(
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    )
    advisor_key_file = str(
        environment.get("REDACTED_OPAQUE_VALUE") or ""
    ).strip()
    advisor_credential_source_valid = bool(advisor_key) != bool(advisor_key_file)
    advisor_valid = (
        advisor_mode in {"disabled", "shadow", "assist"}
        and not advisor_insecure_transport
        and (
            advisor_mode == "disabled"
            or (
                advisor_origin.startswith("https://")
                and advisor_credential_source_valid
            )
        )
    )
    return [
        result(
            "REDACTED_OPAQUE_VALUE",
            require_auth,
            "remote authentication is mandatory" if require_auth else "SCHEMA_BRAIN_REQUIRE_AUTH must be enabled",
        ),
        result(
            "signed_identity_configured",
            len(identity_secret) >= 32,
            "identity signing secret is present" if len(identity_secret) >= 32 else "identity signing secret is missing or too short",
        ),
        result(
            "runtime_hmac_keys",
            runtime_hmac_keys_valid,
            "identity, observability, and provenance signing keys are strong and distinct"
            if runtime_hmac_keys_valid
            else "identity, observability, and provenance signing keys must each be 32-4096 bytes and pairwise distinct",
        ),
        result(
            "redash_credential_present",
            bool(redash_key),
            "Redash credential is present" if redash_key else "REDASH_API_KEY is unavailable",
        ),
        result(
            "legacy_sql_replay_disabled",
            not legacy_replay,
            "legacy SQL replay is disabled" if not legacy_replay else "legacy SQL replay must be disabled",
        ),
        result(
            "dedicated_postgresql_backend",
            learning_backend == "postgresql",
            "dedicated PostgreSQL learning backend is selected"
            if learning_backend == "postgresql"
            else "SCHEMA_BRAIN_LEARNING_BACKEND must be postgresql",
        ),
        result(
            "postgresql_secret_present",
            postgres_secret,
            "PostgreSQL credential source is present"
            if postgres_secret
            else "PostgreSQL DSN secret source is unavailable",
        ),
        result(
            "postgresql_application_role",
            postgres_role_valid,
            "PostgreSQL application role is fixed and unprivileged"
            if postgres_role_valid
            else "SCHEMA_BRAIN_POSTGRES_APP_ROLE must name the dedicated app role",
        ),
        result(
            "artifact_manifest_pin",
            manifest_pin_valid,
            "runtime artifact manifest is pinned by lowercase SHA-256"
            if manifest_pin_valid
            else f"{EXPECTED_MANIFEST_SHA256_ENV} must be a lowercase SHA-256",
        ),
        result(
            "model_advisor_configuration",
            advisor_valid,
            "model advisor is disabled or has an HTTPS origin and credential"
            if advisor_valid
            else "enabled model advisor requires an exact HTTPS origin and credential",
        ),
    ]


def run_preflight(
    *,
    root: pathlib.Path = ROOT,
    profile: str = "core",
    production: bool = False,
    environment: dict[str, str] | os._Environ[str] = os.environ,
) -> dict:
    paths = tracked_files(root)
    checks = [
        result(
            "python_version",
            sys.version_info[:2] == (3, 11),
            f"running Python {sys.version_info.major}.{sys.version_info.minor}; required 3.11",
        ),
        check_lockfiles(root),
        check_json_contracts(root),
        check_tracked_hygiene(paths),
        check_python_files(root, paths),
        check_production_scope(root),
        check_browser_asset(root),
    ]
    if profile == "runtime":
        checks.append(check_neural_modules())
    if production:
        checks.extend(check_production_environment(environment))
    passed = all(row["status"] == "passed" for row in checks)
    return {
        "contract_version": "dbprod-preflight/v1",
        "profile": profile,
        "production": production,
        "status": "passed" if passed else "failed",
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", choices=("core", "runtime"), default="core")
    parser.add_argument("--production", action="store_true")
    args = parser.parse_args()
    report = run_preflight(profile=args.profile, production=args.production)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
