"""
LLM Provider — Cerebras API (primary) + llama.cpp/Qwen 7B (backup)

Automatic failover: Cerebras rate-limited/down → llama.cpp local server.
Rate limiter enforces Cerebras quotas (30 req/min, 60K tokens/min).
"""

import os
import time
import threading
import requests
from collections import deque
from pathlib import Path

# ---------- Load .env ----------
try:
    from dotenv import load_dotenv
    _project_root = Path(__file__).resolve().parents[1]
    load_dotenv(_project_root / ".env", override=False)
except ImportError:
    pass

# ---------- Configuration ----------
CEREBRAS_API_KEY = os.environ.get("CEREBRAS_API_KEY", "")
CEREBRAS_MODEL = os.environ.get("CEREBRAS_MODEL", "llama3.1-8b")
CEREBRAS_BASE_URL = "https://example.invalid"

LLAMA_CPP_URL = os.environ.get("LLAMA_CPP_URL", "http://localhost:8081")
LLAMA_CPP_MODEL = os.environ.get("LLAMA_CPP_MODEL", "qwen2.5-7b-instruct")

# ---------- Rate Limiter ----------

class RateLimiter:
    """Sliding-window rate limiter for Cerebras quotas."""

    def __init__(self):
        self._lock = threading.Lock()
        # Track request timestamps
        self._req_times = deque()       # all request timestamps
        # Track token counts per window
        self._token_minute = deque()    # (timestamp, token_count)
        self._token_hour = deque()      # (timestamp, token_count)

        # Cerebras limits (llama3.1-8b)
        self.REQ_PER_MINUTE = 30
        self.REQ_PER_HOUR = 900
        self.REQ_PER_DAY = 14400
        self.TOKENS_PER_MINUTE = REDACTED_SECRET
        self.TOKENS_PER_HOUR = REDACTED_SECRET
        # Safety margin — pre-emptively failover at 85% capacity
        self.SAFETY_FACTOR = 0.85

    def _prune(self):
        """Remove expired entries."""
        now = time.time()
        # Prune requests older than 1 day
        while self._req_times and (now - self._req_times[0]) > 86400:
            self._req_times.popleft()
        # Prune token counts older than 1 hour
        while self._token_minute and (now - self._token_minute[0][0]) > 60:
            self._token_minute.popleft()
        while self._token_hour and (now - self._token_hour[0][0]) > 3600:
            self._token_hour.popleft()

    def can_make_request(self, estimated_tokens=500):
        """Check if we can make a Cerebras request without hitting limits."""
        with self._lock:
            self._prune()
            now = time.time()

            # Count requests in each window
            reqs_minute = sum(1 for t in self._req_times if (now - t) < 60)
            reqs_hour = sum(1 for t in self._req_times if (now - t) < 3600)
            reqs_day = len(self._req_times)

            # Count tokens in each window
            tokens_minute = sum(tc for ts, tc in self._token_minute)
            tokens_hour = sum(tc for ts, tc in self._token_hour)

            # Check all limits with safety margin
            if reqs_minute >= int(self.REQ_PER_MINUTE * self.SAFETY_FACTOR):
                return False, f"Rate limit: {reqs_minute}/{self.REQ_PER_MINUTE} req/min"
            if reqs_hour >= int(self.REQ_PER_HOUR * self.SAFETY_FACTOR):
                return False, f"Rate limit: {reqs_hour}/{self.REQ_PER_HOUR} req/hr"
            if reqs_day >= int(self.REQ_PER_DAY * self.SAFETY_FACTOR):
                return False, f"Rate limit: {reqs_day}/{self.REQ_PER_DAY} req/day"
            if (tokens_minute + estimated_tokens) > int(self.TOKENS_PER_MINUTE * self.SAFETY_FACTOR):
                return False, f"Token limit: {tokens_minute}/{self.TOKENS_PER_MINUTE} tok/min"
            if (tokens_hour + estimated_tokens) > int(self.TOKENS_PER_HOUR * self.SAFETY_FACTOR):
                return False, f"Token limit: {tokens_hour}/{self.TOKENS_PER_HOUR} tok/hr"

            return True, "OK"

    def record_request(self, token_count=0):
        """Record a successful request."""
        with self._lock:
            now = time.time()
            self._req_times.append(now)
            if token_count > 0:
                self._token_minute.append((now, token_count))
                self._token_hour.append((now, token_count))


# Singleton
_rate_limiter = RateLimiter()


# ---------- Provider Functions ----------

def _call_cerebras(system_prompt: str, user_content: str,
                   temperature: float = 0.0, max_tokens: int = 700) -> str:
    """Call Cerebras Cloud API (OpenAI-compatible)."""
    headers = {
        "Authorization": f"Bearer {CEREBRAS_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": CEREBRAS_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    resp = requests.post(
        f"{CEREBRAS_BASE_URL}/chat/completions",
        headers=headers,
        json=payload,
        timeout=30,
    )

    if resp.status_code == 429:
        raise RateLimitError(f"Cerebras 429: {resp.text}")
    resp.raise_for_status()

    data = resp.json()
    content = data["choices"][0]["message"]["content"].strip()

    # Record token usage
    usage = data.get("usage", {})
    total_tokens = usage.get("total_tokens", 0)
    _rate_limiter.record_request(total_tokens)

    return content


def _call_llama_cpp(system_prompt: str, user_content: str,
                    temperature: float = 0.0, max_tokens: int = 700) -> str:
    """Call local llama.cpp server (OpenAI-compatible API)."""
    payload = {
        "model": LLAMA_CPP_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    resp = requests.post(
        f"{LLAMA_CPP_URL}/v1/chat/completions",
        json=payload,
        timeout=120,  # local model can be slower
    )
    resp.raise_for_status()

    data = resp.json()
    return data["choices"][0]["message"]["content"].strip()


class RateLimitError(Exception):
    pass


# ---------- Main Entry Point ----------

def call_llm(system_prompt: str, user_content: str,
             temperature: float = 0.0, max_tokens: int = 700) -> str:
    """
    Call LLM with automatic failover.

    Priority:
      1. Cerebras API (if within rate limits and API key available)
      2. llama.cpp local server (Qwen 7B backup)

    Returns the LLM text response.
    Raises Exception only if ALL providers fail.
    """

    errors = []

    # --- Attempt 1: Cerebras ---
    if CEREBRAS_API_KEY:
        can_call, reason = _rate_limiter.can_make_request(estimated_tokens=max_tokens)
        if can_call:
            try:
                result = _call_cerebras(system_prompt, user_content, temperature, max_tokens)
                print(f"[LLM] ✅ Cerebras ({CEREBRAS_MODEL})")
                return result
            except RateLimitError as e:
                errors.append(f"Cerebras rate-limited: {e}")
                print(f"[LLM] ⚠️ Cerebras rate-limited, failing over to llama.cpp")
            except requests.exceptions.Timeout:
                errors.append("Cerebras timeout")
                print(f"[LLM] ⚠️ Cerebras timeout, failing over to llama.cpp")
            except Exception as e:
                errors.append(f"Cerebras error: {e}")
                print(f"[LLM] ⚠️ Cerebras error: {e}, failing over to llama.cpp")
        else:
            errors.append(f"Cerebras skipped: {reason}")
            print(f"[LLM] ⏸️ {reason} — routing to llama.cpp")

    # --- Attempt 2: llama.cpp ---
    try:
        result = _call_llama_cpp(system_prompt, user_content, temperature, max_tokens)
        print(f"[LLM] ✅ llama.cpp ({LLAMA_CPP_MODEL})")
        return result
    except requests.exceptions.ConnectionError:
        errors.append("llama.cpp server not reachable")
        print(f"[LLM] ❌ llama.cpp server not reachable at {LLAMA_CPP_URL}")
    except Exception as e:
        errors.append(f"llama.cpp error: {e}")
        print(f"[LLM] ❌ llama.cpp error: {e}")

    # --- All providers failed ---
    raise Exception(f"All LLM providers failed: {'; '.join(errors)}")


def get_provider_status():
    """Return current LLM provider health for monitoring."""
    status = {
        "cerebras": {
            "configured": bool(CEREBRAS_API_KEY),
            "model": CEREBRAS_MODEL,
        },
        "llama_cpp": {
            "url": LLAMA_CPP_URL,
            "model": LLAMA_CPP_MODEL,
            "reachable": False,
        },
    }

    # Check llama.cpp health
    try:
        resp = requests.get(f"{LLAMA_CPP_URL}/v1/models", timeout=3)
        status["llama_cpp"]["reachable"] = resp.status_code == 200
    except Exception:
        pass

    # Rate limiter stats
    with _rate_limiter._lock:
        _rate_limiter._prune()
        now = time.time()
        status["cerebras"]["requests_last_minute"] = sum(
            1 for t in _rate_limiter._req_times if (now - t) < 60
        )
        status["cerebras"]["requests_last_hour"] = sum(
            1 for t in _rate_limiter._req_times if (now - t) < 3600
        )

    return status
