"""
Cross-Encoder Re-Ranker — Post-FAISS precision boost.

Uses `cross-encoder/ms-marco-MiniLM-L-6-v2` to pairwise-score
query vs. each candidate, producing calibrated confidence scores.
"""

import os
from sentence_transformers import CrossEncoder

_MODEL_NAME = os.getenv("RERANKER_MODEL", "REDACTED_OPAQUE_VALUE")
_RERANKER = None


def _get_model():
    global _RERANKER
    if _RERANKER is None:
        print(f"[Reranker] Loading cross-encoder: {_MODEL_NAME}")
        _RERANKER = CrossEncoder(_MODEL_NAME, max_length=512)
        print("[Reranker] ✅ Ready")
    return _RERANKER


def rerank(query: str, candidates: list, top_k: int = 5,
           text_key: str = "mpr_subject") -> list:
    """
    Re-rank FAISS/BM25 candidates using a cross-encoder.

    Args:
        query: The search query
        candidates: List of result dicts from FAISS/BM25
        top_k: Number of results to return
        text_key: Key in each dict containing the text to score against

    Returns:
        Re-ranked list with updated 'confidence' and 'composite_confidence'
    """
    if not candidates or not query.strip():
        return candidates[:top_k]

    model = _get_model()

    # Build pairs: (query, candidate_text)
    pairs = []
    for c in candidates:
        text = str(c.get(text_key, ""))
        # Also include details if available for richer matching
        details = str(c.get("details", ""))[:200]
        combined = f"{text} {details}".strip()
        if not combined:
            combined = str(c.get("subject", ""))
        pairs.append((query, combined))

    # Score all pairs
    try:
        scores = model.predict(pairs)
    except Exception as e:
        print(f"[Reranker] Error: {e}")
        return candidates[:top_k]

    # Normalize scores to 0-100
    min_score = float(min(scores))
    max_score = float(max(scores))
    score_range = max_score - min_score if max_score != min_score else 1.0

    # Attach scores and sort
    for i, c in enumerate(candidates):
        raw = float(scores[i])
        normalized = ((raw - min_score) / score_range) * 100
        c["confidence"] = round(normalized, 2)
        c["composite_confidence"] = round(normalized, 2)
        c["reranker_score"] = round(raw, 4)

    # Sort by cross-encoder score (descending)
    candidates.sort(key=lambda x: x.get("reranker_score", 0), reverse=True)

    return candidates[:top_k]
