import sys
import os
from typing import Optional

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api", tags=["search"])


# ---------- Models ----------

class SearchRequest(BaseModel):
    query: str
    top_k: int = 5


class RecommendRequest(BaseModel):
    query: str
    case_results: list = []  # optional: pass matched cases for PDF linking


class FeedbackRequest(BaseModel):
    mpr_subject: str
    similarity_score: float
    quality_rating: int
    relevance_rating: int
    clarity_rating: int
    match_accuracy: str
    applicability: str


# ---------- Endpoints ----------

@router.post("/search")
def search_cases(req: SearchRequest):
    """Search for similar historical cases using keyword BM25 matching."""
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    try:
        from services.retriever import search_cases_keyword
        results = search_cases_keyword(req.query, top_k=req.top_k)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

    if not results:
        return {"results": [], "count": 0}

    # Sort by best available score
    results = sorted(
        results,
        key=lambda x: x.get("adaptive_score", x.get("confidence", 0)),
        reverse=True,
    )

    # Sanitize for JSON serialization
    import math
    clean_results = []
    for r in results:
        clean = {}
        for k, v in r.items():
            if v is None:
                clean[k] = None
            elif isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                clean[k] = 0
            else:
                clean[k] = str(v) if not isinstance(v, (int, float, bool, list, dict)) else v
        clean_results.append(clean)

    return {"results": clean_results, "count": len(clean_results)}


@router.post("/recommend")
def get_recommendation(req: RecommendRequest):
    """Get AI recommendation using hierarchical PDF RAG agent."""
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    try:
        from services.agent import pdf_agent
        api_key = REDACTED_SECRET
        result = pdf_agent(req.query, case_results=req.case_results, api_key=api_key)
        return {"recommendation": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Recommendation failed: {str(e)}")


@router.post("/feedback")
def submit_feedback(req: FeedbackRequest):
    """Save user feedback for a recommendation."""
    try:
        from services.feedback_manager import save_feedback
        reward = save_feedback({
            "mpr_subject": req.mpr_subject,
            "similarity_score": req.similarity_score,
            "quality_rating": req.quality_rating,
            "relevance_rating": req.relevance_rating,
            "clarity_rating": req.clarity_rating,
            "match_accuracy": req.match_accuracy,
            "applicability": req.applicability,
        })
        return {"status": "saved", "reward": reward}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Feedback save failed: {str(e)}")


@router.get("/feedback/subject-score/{subject}")
def get_subject_score(subject: str):
    """Get reliability score for a subject."""
    try:
        from services.feedback_manager import get_subject_success_rate
        score = get_subject_success_rate(subject)
        return {"subject": subject, "score": score}
    except Exception as e:
        return {"subject": subject, "score": 0.0}


# ──────────────────────────────────────────────────────────────────────
# Feature 1: Conversational AI Chat
# ──────────────────────────────────────────────────────────────────────
class ChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str

class ChatRequest(BaseModel):
    messages: list  # List of ChatMessage dicts
    query: str      # Latest user message

@router.post("/chat")
def chat_with_ai(req: ChatRequest):
    """Multi-turn conversational AI for MPR troubleshooting."""
    if not req.query.strip():
        return {"reply": "Please describe the issue you're facing."}

    try:
        from services.llm_provider import call_llm
        from services.pdf_search import search_pdf

        # Get PDF context
        pdf_context = ""
        try:
            chunks = search_pdf(req.query, top_k=3)
            if chunks:
                pdf_context = "\n".join(
                    c.get("text", "").strip()[:300] for c in chunks if c.get("text", "").strip()
                )
        except Exception:
            pass

        # Build conversation history for Groq
        system_prompt = (
            "You are an expert MPR support AI assistant having a conversation with a support engineer. "
            "You help diagnose and resolve Modification/Problem/Request cases. "
            "RULE/opt/portfolio/project"
            "1. Be conversational but concise.\n"
            "2. If the user's problem is vague, ask ONE specific clarifying question.\n"
            "3. When you have enough info, provide a numbered list of resolution steps (max 6 steps).\n"
            "4. Never invent information. Use only the knowledge base context provided.\n"
            "5. If you need more details, ask about: module, user type, error message, or environment.\n"
        )

        if pdf_context:
            system_prompt += f"\nPDF KNOWLEDGE BAS/opt/portfolio/project"

        # Build message history for the LLM
        conversation = ""
        for msg in req.messages[-6:]:  # Keep last 6 messages for context window
            role = msg.get("role", "user")
            content = msg.get("content", "")
            conversation += f"\n{role.upper()}: {content}"
        conversation += f"\nUSER: {req.query}"

        reply = call_llm(system_prompt, conversation)
        return {"reply": reply}

    except Exception as e:
        print(f"[chat] Error: {e}")
        return {"reply": f"I encountered an issue processing your request. Please try rephrasing your question."}


# ──────────────────────────────────────────────────────────────────────
# Feature 2: Predicted Resolution Time
# ──────────────────────────────────────────────────────────────────────
class PredictRequest(BaseModel):
    subject: str
    query: str = ""

@router.post("/predict-resolution")
def predict_resolution(req: PredictRequest):
    """Predict resolution time based on historical similar cases."""
    try:
        import pandas as pd
        from pathlib import Path

        data_dir = Path(ROOT_DIR) / "data"
        csv_path = data_dir / "redash_latest.csv"
        if not csv_path.exists():
            return {"predicted_days": 5, "confidence": "low", "sample_size": 0}

        df = pd.read_csv(csv_path)
        df["reportedon"] = pd.to_datetime(df.get("reportedon"), errors="coerce")
        df["closeddate"] = pd.to_datetime(df.get("closeddate"), errors="coerce")

        # Filter closed cases with matching subject
        subj_col = "mpr_subject" if "mpr_subject" in df.columns else "subject"
        if subj_col not in df.columns:
            return {"predicted_days": 5, "confidence": "low", "sample_size": 0}

        closed = df[df["closeddate"].notna()].copy()
        closed["resolution_days"] = (closed["closeddate"] - closed["reportedon"]).dt.days

        # Match by subject (fuzzy)
        subject_lower = req.subject.lower().strip()
        mask = closed[subj_col].astype(str).str.lower().str.contains(
            subject_lower[:20], na=False
        )
        matched = closed[mask]

        if len(matched) < 2:
            # Fallback to global average
            avg = float(closed["resolution_days"].median()) if len(closed) > 0 else 5
            return {
                "predicted_days": round(max(avg, 1), 1),
                "confidence": "low",
                "sample_size": len(closed),
                "method": "global_median"
            }

        avg_days = float(matched["resolution_days"].median())
        p75 = float(matched["resolution_days"].quantile(0.75))
        conf = "high" if len(matched) >= 10 else "medium" if len(matched) >= 5 else "low"

        return {
            "predicted_days": round(max(avg_days, 1), 1),
            "worst_case_days": round(max(p75, 1), 1),
            "confidence": conf,
            "sample_size": int(len(matched)),
            "method": "subject_match"
        }
    except Exception as e:
        print(f"[predict] Error: {e}")
        return {"predicted_days": 5, "confidence": "low", "sample_size": 0}


# ──────────────────────────────────────────────────────────────────────
# Feature 4: Smart Query Autocomplete
# ──────────────────────────────────────────────────────────────────────
@router.get("/autocomplete")
def autocomplete(q: str = ""):
    """Return top matching MPR subjects for autocomplete."""
    if not q or len(q) < 2:
        return {"suggestions": []}

    try:
        import pandas as pd
        from pathlib import Path

        data_dir = Path(ROOT_DIR) / "data"
        csv_path = data_dir / "redash_latest.csv"
        if not csv_path.exists():
            return {"suggestions": []}

        df = pd.read_csv(csv_path)
        subj_col = "mpr_subject" if "mpr_subject" in df.columns else "subject"
        if subj_col not in df.columns:
            return {"suggestions": []}

        # Get unique subjects, fuzzy match
        subjects = df[subj_col].dropna().astype(str).str.strip().unique()
        q_lower = q.lower()
        matches = [
            s for s in subjects
            if q_lower in s.lower()
        ]

        # Score by frequency
        freq = df[subj_col].astype(str).str.strip().value_counts().to_dict()
        matches = sorted(matches, key=lambda x: freq.get(x, 0), reverse=True)

        suggestions = [
            {"text": m, "count": freq.get(m, 0)}
            for m in matches[:8]
        ]
        return {"suggestions": suggestions}
    except Exception as e:
        print(f"[autocomplete] Error: {e}")
        return {"suggestions": []}


# ──────────────────────────────────────────────────────────────────────
# Feature 5: Attach & Diagnose (text extraction from error logs)
# ──────────────────────────────────────────────────────────────────────
class DiagnoseRequest(BaseModel):
    text: str  # Pasted error log or extracted text

@router.post("/diagnose")
def diagnose_error(req: DiagnoseRequest):
    """Extract key issue from error text and search for solutions."""
    if not req.text.strip():
        return {"extracted_query": "", "results": []}

    try:
        from services.llm_provider import call_llm

        # Use LLM to extract the core issue
        system_prompt = (
            "You are an expert at reading error logs and support tickets. "
            "Given the following error text or log, extract the SINGLE most important issue "
            "as a short, searchable query (max 10 words). "
            "Output ONLY the query, nothing else."
        )
        extracted_query = call_llm(system_prompt, req.text[:2000])
        extracted_query = extracted_query.strip().strip('"').strip("'")

        # Now search with the extracted query
        from services.retriever import search_cases_keyword
        results = search_cases_keyword(extracted_query, top_k=5)

        import math
        clean_results = []
        for r in (results or []):
            clean = {}
            for k, v in r.items():
                if v is None:
                    clean[k] = None
                elif isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                    clean[k] = 0
                else:
                    clean[k] = str(v) if not isinstance(v, (int, float, bool, list, dict)) else v
            clean_results.append(clean)

        return {
            "extracted_query": extracted_query,
            "results": clean_results[:5],
            "count": len(clean_results)
        }
    except Exception as e:
        print(f"[diagnose] Error: {e}")
        return {"extracted_query": "", "results": [], "error": str(e)}
