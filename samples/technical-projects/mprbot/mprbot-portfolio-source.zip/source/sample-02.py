"""
MPR Agent — PDF + Resolved Case RAG Agent.

Combines PDF FAISS chunks with resolved case context from case pairs
and LLM enrichments to produce high-quality resolution steps.
"""

import sys
import os

_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(_project_root, ".env"), override=False)
except ImportError:
    pass

from services.llm_provider import call_llm


def _build_system_prompt(query: str) -> str:
    """Strict system prompt for numbered resolution steps."""
    return (
        "You are a strict technical support resolution AI for an enterprise MPR (Modification/Problem/Request) system. "
        f"The user's issue is: \"{query}\". "
        "Your ONLY job is to produce a single, concise, numbered list of resolution steps. "
        "CRITICAL RULES — violating any will make your answer incorrec/opt/portfolio/project"
        "  1. Output ONLY a numbered list (1. ... 2. ... 3. ...). No other text.\n"
        "  2. DO NOT write any paragraph, introduction, conclusion, or explanation.\n"
        "  3. DO NOT mention case IDs, field names, column values, or raw database content.\n"
        "  4. Each step must be one short, actionable sentence.\n"
        "  5. Maximum 8 steps. Combine steps if needed.\n"
        "  6. If context is irrelevant, output: '1. No clear solution found. Escalate to Level 2 support.'\n"
        "  7. Use ONLY information from the context provided. Do NOT invent steps.\n"
        "  8. Prioritize RESOLVED CASE context over PDF context when available.\n"
    )


def _get_resolved_context(query: str, case_results: list = None) -> str:
    """Fetch resolution details from similar resolved cases."""
    resolved_parts = []

    # 1. Try case-pair retriever (structured problem→solution pairs)
    try:
        from services.case_pair_retriever import search_case_pairs
        pairs = search_case_pairs(query, top_k=3)
        for p in pairs:
            sol = p.get("solution_text", "").strip()
            subj = p.get("subject", p.get("caseid", ""))
            if sol and len(sol) > 20:
                resolved_parts.append(f"[Resolved Case: {subj}]\n{sol[:400]}")
    except Exception as e:
        print(f"[agent] Case pair retrieval: {e}")

    # 2. Try LLM enrichments for matched cases
    try:
        from services.llm_enricher import get_enrichment
        if case_results:
            for cr in case_results[:3]:
                cid = str(cr.get("caseid", ""))
                enrichment = get_enrichment(cid)
                if enrichment and enrichment.get("resolution_summary"):
                    resolved_parts.append(
                        f"[Case {cid} Resolution: {enrichment['resolution_summary']}]\n"
                        f"Root Cause: {enrichment.get('root_cause', 'Unknown')}\n"
                        f"Fix Type: {enrichment.get('fix_type', 'Other')}"
                    )
    except Exception as e:
        print(f"[agent] Enrichment lookup: {e}")

    # 3. Try solution extractor (BM25 keyword extraction)
    try:
        from services.solution_extractor import search_solutions
        solutions = search_solutions(query, top_k=2)
        for s in solutions:
            sol_text = s.get("solution", "").strip()
            if sol_text and len(sol_text) > 20:
                resolved_parts.append(f"[Extracted Solution]\n{sol_text[:300]}")
    except Exception as e:
        print(f"[agent] Solution extractor: {e}")

    return "\n\n".join(resolved_parts[:5])


def pdf_agent(question: str, case_results: list = None, api_key: str = None) -> str:
    """
    Enhanced RAG agent: PDF chunks + resolved case context → LLM.

    Flow:
      1. Retrieve PDF chunks via FAISS
      2. Retrieve resolved case context (case pairs + enrichments + solution extractor)
      3. Combine and pass to LLM for resolution steps
    """
    # --- Step 1: PDF chunks ---
    pdf_context = ""
    try:
        from services.pdf_search import search_pdf
        chunks = search_pdf(question, top_k=3)
        if chunks:
            pdf_context = "\n\n---\n".join(
                f"[Source: {c.get('source', 'PDF')}]\n{c.get('text', '').strip()}"
                for c in chunks
                if c.get("text", "").strip()
            )
    except Exception as e:
        print(f"[agent] PDF search error: {e}")

    print(f"[agent] PDF context length: {len(pdf_context)}")

    # --- Step 2: Resolved case context ---
    resolved_context = _get_resolved_context(question, case_results)

    # --- Step 3: Build combined context ---
    system_prompt = _build_system_prompt(question)

    context_parts = []
    if resolved_context:
        context_parts.append(f"RESOLVED CASE CONTEXT (HIGH PRIORITY — these are real resolutions):\n{resolved_context[:1500]}")
    if pdf_context:
        context_parts.append(f"PDF KNOWLEDGE BAS/opt/portfolio/project")

    print(f"[agent] resolved_context len: {len(resolved_context)}, pdf_context len: {len(pdf_context)}, context_parts: {len(context_parts)}")

    # --- Fallback 1: LLM-direct (Cerebras, no retrieval context) ---
    if not context_parts:
        try:
            direct_prompt = (
                "You are an enterprise IT support AI for an MPR (Modification/Problem/Request) system. "
                "Based ONLY on your general IT support knowledge, provide a numbered list of "
                "resolution steps for the following issue. Maximum 8 steps. "
                "Output ONLY a numbered list, nothing else."
            )
            result = call_llm(direct_prompt, f"Issue: {question}")
            if result and len(result.strip()) > 10:
                return result
        except Exception as e:
            print(f"[agent] LLM direct error: {e}")

    # --- Fallback 2: Generic Solutions (template-based, last resort) ---
    if not context_parts:
        try:
            from services.generic_solutions import find_best_baseline
            baseline = find_best_baseline(question)
            if baseline:
                return baseline
        except Exception as e:
            print(f"[agent] Generic solutions error: {e}")

        return (
            "1. No documented solution data found for this query in the knowledge base.\n"
            "2. Please use more specific keywords (feature name, error code, or subject).\n"
            "3. Escalate to Level 2 support if the issue is urgent."
        )

    user_content = "PORTFOLIO_REDACTED".join(context_parts)

    try:
        print(f"[agent] Calling LLM with {len(user_content)} chars of context")
        result = call_llm(system_prompt, user_content)
        print(f"[agent] LLM returned {len(result)} chars")
        return result
    except Exception as e:
        print(f"[agent] LLM error: {e}")
        # Final fallback: try generic solutions
        try:
            from services.generic_solutions import find_best_baseline
            baseline = find_best_baseline(question)
            if baseline:
                return baseline
        except Exception:
            pass
        return (
            "1. Query could not be processed by the AI engine.\n"
            "2. Ensure the API key quota has not been exceeded.\n"
            "3. Try again shortly."
        )