// RMG Governance · ALLOCATION HEALTH — expiry pipeline, stale records,
// over-allocation, PM load, long-term locks.
import React from 'react'
import { useRMGData, RMGPageShell } from '../../sections/rmg/RMGShared'

export default function RMGAllocationHealthPage() {
    const { data, loading, error, status } = useRMGData()
    return <RMGPageShell sectionKey="rmg_allocation_health" data={data} loading={loading} error={error} status={status} />
}
