/**
 * useIntelBot — Intelligence Engine v2
 *
 * Aligned with backend v2 data: healthV2, pipeRateV2, alertsByOwner,
 * agingHistogram, deploy metrics. Uses keyword scoring instead of
 * brittle regex. Supports person-specific and comparative queries.
 */
import { useState, useCallback, useMemo } from 'react'
import { useLLM } from './useLLM'

export function useIntelBot(pipelineData, workItemData) {
    const [messages, setMessages] = useState([])
    const [isOpen, setIsOpen] = useState(false)
    const [isThinking, setIsThinking] = useState(false)
    const { askLLM, llmAvailable, llmLoading } = useLLM()

    // ── Extract v2 data ──────────────────────────────────────
    const pipelines = Array.isArray(pipelineData) ? pipelineData : []
    const items = workItemData?.items || []
    const assignees = Object.values(workItemData?.byAssignee || {}).filter(a => a.name !== 'Unassigned')
    const sprint = workItemData?.sprint || {}
    const flow = workItemData?.flow || {}
    const alerts = workItemData?.alerts || []
    const alertsByOwner = workItemData?.alertsByOwner || []
    const alertCount = workItemData?.alertCount || alerts.length
    const alertTrend = workItemData?.alertTrend || 0
    const deploy = workItemData?.deployment || {}
    const hv2 = workItemData?.healthV2 || {}
    const components = hv2.components || {}
    const agingHistogram = flow.agingHistogram || []

    // ── V2 Metrics (from backend, not recomputed) ───────────
    const metrics = useMemo(() => {
        const healthScore = hv2.score ?? 0
        const healthLabel = hv2.label || 'N/A'
        const pipeRate = deploy.pipeRateV2 ?? 0
        const pipeSucceeded = deploy.pipeSucceeded ?? 0
        const pipeActiveTotal = deploy.pipeActiveTotal ?? 0
        const pipelineHealth = deploy.pipelineHealth || []
        const flakyPipes = deploy.flakyPipelines || []

        // Aging data from histogram
        const totalActive = agingHistogram.reduce((s, b) => s + b.total, 0)
        const aging21Plus = agingHistogram.length >= 5
            ? agingHistogram[3].total + agingHistogram[4].total : 0
        const agingPct = flow.agingHealthPct || 0

        // Critical alerts
        const criticalAlerts = alerts.filter(a => a.severity === 'critical').length

        // Per-person WIP stats from flow.wipByPerson
        const wipByPerson = flow.wipByPerson || []

        return {
            healthScore, healthLabel, pipeRate, pipeSucceeded, pipeActiveTotal,
            pipelineHealth, flakyPipes, totalActive, aging21Plus, agingPct,
            criticalAlerts, wipByPerson,
        }
    }, [hv2, deploy, agingHistogram, alerts, flow])

    // ── Person name matcher ──────────────────────────────────
    const findPerson = useCallback((query) => {
        const q = query.toLowerCase()
        // Try exact match first, then partial
        let match = assignees.find(a => q.includes(a.name.toLowerCase()))
        if (!match) {
            // Try first name
            match = assignees.find(a => {
                const firstName = a.name.split(' ')[0].toLowerCase()
                return firstName.length > 2 && q.includes(firstName)
            })
        }
        return match
    }, [assignees])

    // ── Response Generators ──────────────────────────────────

    const genStatus = useCallback(() => {
        const h = metrics.healthScore
        const lines = []
        lines.push(`🎯 **Project Status: ${metrics.healthLabel} (${h}/100)**`)

        if (h < 75) {
            const drivers = []
            const c = components
            if (c.velocity?.score < 50) drivers.push(`Velocity at ${c.velocity.score}%`)
            if (c.quality?.score < 50) drivers.push(`Quality at ${c.quality.score}%`)
            if (c.risk?.score < 50) drivers.push(`Risk score ${c.risk.score}%`)
            if (c.flow?.score < 50) drivers.push(`Flow at ${c.flow.score}%`)
            if (c.ops?.score < 50) drivers.push(`Ops at ${c.ops.score}%`)
            if (drivers.length > 0) lines.push(`Health drivers: ${drivers.join(', ')}`)
        }

        lines.push('')
        lines.push(`📊 **Key Numbers:**`)
        lines.push(`• Pipeline rate: ${metrics.pipeRate}% (${metrics.pipeSucceeded}/${metrics.pipeActiveTotal} active)`)
        lines.push(`• WIP: ${flow.wip || 0} active, ${flow.queueDepth || 0} queued`)
        lines.push(`• Alerts: ${alertCount} (${metrics.criticalAlerts} critical, trend: ${alertTrend > 0 ? '+' : ''}${alertTrend})`)
        lines.push(`• Aging: ${metrics.agingPct}% of active items untouched >21 days`)
        lines.push(`• Deploy freq: ${deploy.avgDeploysPerDay || 0} runs/day (${deploy.deployWeekLabel || 'this week'})`)

        if (sprint.burnRate != null) {
            lines.push(`• Burn rate: ${sprint.burnRate}% (week ${sprint.timeElapsed || 0}% elapsed)`)
        }

        if (alertsByOwner.length > 0) {
            lines.push('')
            lines.push(`🔴 **Top alert holders:**`)
            alertsByOwner.slice(0, 3).forEach(o => {
                lines.push(`• ${o.name}: ${o.critical} critical, ${o.warning} warning`)
            })
        }

        return lines.join('\n')
    }, [metrics, components, flow, alertCount, alertTrend, alertsByOwner, deploy, sprint])

    const genRisks = useCallback(() => {
        if (alertCount === 0) return '✅ **No active alerts.** All systems operational.'
        let resp = `🚨 **${alertCount} active alerts** (${metrics.criticalAlerts} critical)\n`
        resp += `Trend: ${alertTrend > 0 ? `⬆️ +${alertTrend} vs last week (worsening)` : alertTrend < 0 ? `⬇️ ${alertTrend} vs last week (improving)` : '→ unchanged'}\n\n`

        if (alertsByOwner.length > 0) {
            resp += `**By owner:**\n`
            alertsByOwner.slice(0, 5).forEach(o => {
                const badge = o.critical > 0 ? '🔴' : '🟡'
                resp += `${badge} **${o.name}**: ${o.critical} critical, ${o.warning} warning\n`
            })
        }

        if (alerts.length > 0) {
            resp += `\n**Top alerts:**\n`
            alerts.slice(0, 5).forEach(a => {
                const icon = a.severity === 'critical' ? '🔴' : '🟡'
                resp += `${icon} ${a.text}\n`
            })
        }
        return resp
    }, [alertCount, alertTrend, metrics.criticalAlerts, alertsByOwner, alerts])

    const genTeam = useCallback(() => {
        if (assignees.length === 0) return 'No team data available.'
        let resp = `👥 **${assignees.length} operatives** tracked.\n\n`
        const sorted = [...assignees].sort((a, b) => (b.active || 0) - (a.active || 0))
        sorted.slice(0, 8).forEach(a => {
            const load = (a.active || 0)
            const status = load > 8 ? '🔴' : load > 5 ? '🟡' : '🟢'
            const hygScore = a.hygiene?.score ?? '—'
            resp += `${status} **${a.name}**: ${a.active || 0} active, ${a.sp || 0} SP, hygiene: ${hygScore}/100\n`
        })

        // Avg WIP per person
        const avgWip = flow.avgWipPerPerson || 0
        resp += `\nAvg WIP/person: **${avgWip}** ${avgWip > 8 ? '(⚠️ too high)' : avgWip > 5 ? '(moderate)' : '(healthy)'}`
        return resp
    }, [assignees, flow])

    const genPipelines = useCallback(() => {
        const ph = metrics.pipelineHealth
        let resp = `🔧 **Pipeline Status:** ${metrics.pipeRate}% (${metrics.pipeSucceeded}/${metrics.pipeActiveTotal} active in 7d)\n\n`

        if (ph.length === 0) {
            resp += 'No active pipelines in the last 7 days.\n'
        } else {
            resp += `**Per-pipeline health (last 5 runs):**\n`
            ph.forEach(p => {
                const icon = p.lastStatus === 'succeeded' ? '✅' : p.lastStatus === 'failed' ? '❌' : '⏳'
                const rate = p.rate5 >= 0 ? `${p.rate5}%` : 'N/A'
                const failBadge = p.consecutiveFails > 0 ? ` ⚠️ ${p.consecutiveFails}x failing` : ''
                resp += `${icon} **${p.name}**: ${rate}${failBadge}\n`
            })
        }

        if (metrics.flakyPipes.length > 0) {
            resp += `\n⚠️ **Flaky pipelines:** ${metrics.flakyPipes.map(p => p.name).join(', ')}`
        }

        resp += `\n\n📊 Deploy freq: **${deploy.avgDeploysPerDay || 0}** runs/day (${deploy.deployWeekLabel || 'this week'})`
        resp += `\nMTTR: **${deploy.mttrHours || 0}h** | Avg build: **${Math.round((deploy.avgBuildDuration || 0) / 60)}min**`
        return resp
    }, [metrics, deploy])

    const genSanity = useCallback(() => {
        if (agingHistogram.length === 0) return 'No aging data available.'
        let resp = `🧹 **Work Item Aging Analysis:**\n\n`
        resp += `Active items: **${metrics.totalActive}** | Aging (>21d): **${metrics.aging21Plus}** (${metrics.agingPct}%)\n\n`

        resp += `**Buckets:**\n`
        agingHistogram.forEach(b => {
            const bar = '█'.repeat(Math.min(20, Math.round(b.total / Math.max(1, metrics.totalActive) * 20)))
            resp += `${b.label}: **${b.total}** ${bar}\n`
        })

        if (metrics.agingPct > 50) {
            resp += `\n⚠️ **${metrics.agingPct}% of active items are aging >21 days** — this indicates significant bottlenecks.`
        }

        // Show top owners from the worst bucket
        const worstBucket = agingHistogram[agingHistogram.length - 1]
        if (worstBucket && Object.keys(worstBucket.byOwner || {}).length > 0) {
            resp += `\n\n**30d+ items by owner:**\n`
            Object.entries(worstBucket.byOwner).sort((a, b) => b[1].length - a[1].length).slice(0, 5).forEach(([owner, items]) => {
                resp += `• ${owner}: ${items.length} items\n`
            })
        }
        return resp
    }, [agingHistogram, metrics])

    const genRecommendations = useCallback(() => {
        const recs = []
        if (metrics.agingPct > 50) recs.push(`🧹 **Reduce aging backlog** — ${metrics.agingPct}% of active items haven't been touched in 21+ days. Review and close stale items.`)
        if ((flow.wip || 0) > 30) recs.push(`📉 **Reduce WIP** — ${flow.wip} items active. Target <${Math.max(5, assignees.length * 3)} for your team size.`)
        if (metrics.criticalAlerts > 3) recs.push(`🚨 **Address critical alerts** — ${metrics.criticalAlerts} critical alerts. Top: ${alertsByOwner[0]?.name || 'Unknown'} (${alertsByOwner[0]?.critical || 0}).`)
        if (metrics.pipeRate < 50) recs.push(`🔧 **Fix pipeline failures** — ${metrics.pipeRate}% success rate. ${metrics.pipelineHealth.filter(p => p.consecutiveFails > 0).length} pipelines currently failing.`)
        if (alertTrend > 0) recs.push(`📈 **Alert trend worsening** — +${alertTrend} alerts vs last week. Focus on clearing blocked items.`)
        if (sprint.burnRate != null && sprint.burnRate < sprint.timeElapsed * 0.7) recs.push(`⏰ **Sprint at risk** — burn rate (${sprint.burnRate}%) is behind time elapsed (${sprint.timeElapsed}%).`)
        if (deploy.avgDeploysPerDay === 0) recs.push(`🚀 **Increase deploy frequency** — 0 deploys/day this week. Consider automating deployments.`)
        if (recs.length === 0) recs.push('✅ Looking good! No critical recommendations at this time.')
        return `💡 **Recommendations:**\n\n${recs.join('\n\n')}`
    }, [metrics, flow, assignees, alertsByOwner, alertTrend, sprint, deploy])

    const genPerson = useCallback((person) => {
        const a = person
        let resp = `👤 **${a.name}**\n\n`
        resp += `**Workload:**\n`
        resp += `• Active: **${a.active || 0}** items, **${a.sp || 0}** story points\n`
        resp += `• Stories: ${a.userStories || 0} | Tasks: ${a.tasks || 0} | Bugs: ${a.bugs || 0} | Features: ${a.features || 0} | Epics: ${a.epics || 0}\n`
        resp += `• Focus score: ${a.focusScore ?? '—'}/10 (${(a.areas || []).length} area${(a.areas || []).length !== 1 ? 's' : ''})\n`
        resp += `• Cycle time: ${a.personalCycleTime || '—'}d\n`
        resp += `\n**Hygiene:** ${a.hygiene?.score ?? '—'}/100\n`
        const v = a.hygiene?.violations || {}
        if ((v.stale_ids || []).length > 0) resp += `• ⚠️ ${v.stale_ids.length} stale items\n`
        if ((v.missing_sprint_ids || []).length > 0) resp += `• ⚠️ ${v.missing_sprint_ids.length} missing sprint\n`
        if ((v.no_sp_ids || []).length > 0) resp += `• ⚠️ ${v.no_sp_ids.length} no story points\n`
        if ((v.orphan_ids || []).length > 0) resp += `• ⚠️ ${v.orphan_ids.length} orphan tasks\n`

        resp += `\n**PR activity:** ${a.prsSubmitted || 0} submitted, ${a.prsReviewed || 0} reviewed, ${a.openPRs || 0} open`

        // Check alerts for this person
        const personAlerts = alertsByOwner.find(o => o.name === a.name)
        if (personAlerts) {
            resp += `\n\n**Alerts:** ${personAlerts.critical} critical, ${personAlerts.warning} warning`
        }
        return resp
    }, [alertsByOwner])

    // ── Keyword Scoring Question Router ──────────────────────
    const handlers = useMemo(() => [
        { id: 'status', keywords: ['status', 'health', 'overview', 'briefing', 'summary', 'how', 'doing', 'project', 'overall', 'report'], weight: 1, fn: genStatus },
        { id: 'risks', keywords: ['risk', 'risks', 'alert', 'alerts', 'danger', 'warning', 'attention', 'block', 'blocker', 'critical', 'urgent', 'issue'], weight: 1, fn: genRisks },
        { id: 'team', keywords: ['team', 'member', 'operative', 'assignee', 'people', 'everyone', 'all', 'workload', 'load', 'who'], weight: 1, fn: genTeam },
        { id: 'pipelines', keywords: ['pipeline', 'pipelines', 'ci', 'cd', 'build', 'deploy', 'devops', 'release', 'infrastructure', 'automation', 'mttr'], weight: 1, fn: genPipelines },
        { id: 'sanity', keywords: ['stale', 'hygiene', 'sanity', 'aging', 'clean', 'old', 'stuck', 'untouched', 'bottleneck', 'backlog', 'data'], weight: 1, fn: genSanity },
        { id: 'recommend', keywords: ['recommend', 'recommendations', 'suggest', 'suggestions', 'improve', 'fix', 'action', 'todo', 'priority', 'should', 'next', 'advice'], weight: 1, fn: genRecommendations },
    ], [genStatus, genRisks, genTeam, genPipelines, genSanity, genRecommendations])

    const answerQuestion = useCallback((question) => {
        const q = question.toLowerCase().trim()

        // Help
        if (q.match(/^(help|commands|what can|\?)$/)) {
            return `🤖 **BizTech Intel Bot v2**\n
• **"status"** — Full project health briefing (uses Health v2)
• **"risks"** — Alerts by owner with trend
• **"team"** — Team workload overview
• **"pipelines"** — CI/CD health (active pipelines, MTTR)
• **"sanity"** — Work item aging analysis
• **"suggest"** — AI recommendations
• **"[person name]"** — Individual operative profile
• **"who has highest WIP?"** — Comparative queries
• **"compare X and Y"** — Side-by-side comparison

All data is live from the dashboard — same numbers, same thresholds.`
        }

        // Person-specific query: detect a name
        const person = findPerson(q)
        if (person && !q.match(/who|highest|most|worst|best|compare|team|everyone/)) {
            return genPerson(person)
        }

        // Comparative: "who has highest/most X"
        if (q.match(/who.*(highest|most|worst|busiest|lowest|best|top)/)) {
            if (q.match(/wip|active|work|load|busy/)) {
                const sorted = [...assignees].sort((a, b) => (b.active || 0) - (a.active || 0))
                const top = sorted[0]
                if (!top) return 'No assignee data available.'
                return `📊 **Highest WIP:** ${top.name} with **${top.active || 0}** active items, **${top.sp || 0}** SP\n\n**Top 5:**\n${sorted.slice(0, 5).map((a, i) => `${i + 1}. ${a.name}: ${a.active || 0} active, ${a.sp || 0} SP`).join('\n')}`
            }
            if (q.match(/stale|aging|old|stuck/)) {
                // Use aging histogram byOwner from 30d+ bucket
                const oldBucket = agingHistogram[agingHistogram.length - 1]
                if (!oldBucket || !oldBucket.byOwner) return 'No aging data available.'
                const sorted = Object.entries(oldBucket.byOwner).sort((a, b) => b[1].length - a[1].length)
                return `🔴 **Most stale (30d+) by owner:**\n\n${sorted.slice(0, 5).map(([name, items], i) => `${i + 1}. **${name}**: ${items.length} items`).join('\n')}`
            }
            if (q.match(/hygiene|clean|best|score/)) {
                const sorted = [...assignees].sort((a, b) => (b.hygiene?.score || 0) - (a.hygiene?.score || 0))
                const top = sorted[0]
                if (!top) return 'No hygiene data available.'
                return `⭐ **Best hygiene:** ${top.name} with **${top.hygiene?.score || 0}/100**\n\n**Top 5:**\n${sorted.slice(0, 5).map((a, i) => `${i + 1}. ${a.name}: ${a.hygiene?.score ?? '—'}/100`).join('\n')}`
            }
            if (q.match(/alert|risk|critical/)) {
                if (alertsByOwner.length === 0) return '✅ No alerts to rank.'
                return `🚨 **Most alerts by owner:**\n\n${alertsByOwner.slice(0, 5).map((o, i) => `${i + 1}. **${o.name}**: ${o.critical} critical, ${o.warning} warning`).join('\n')}`
            }
            if (q.match(/focus|context|switch/)) {
                const sorted = [...assignees].sort((a, b) => (a.focusScore ?? 10) - (b.focusScore ?? 10))
                return `🎯 **Most context switching (lowest focus):**\n\n${sorted.slice(0, 5).map((a, i) => `${i + 1}. ${a.name}: focus ${a.focusScore ?? '—'}/10, ${(a.areas || []).length} areas`).join('\n')}`
            }
            // Default: sort by active
            const sorted = [...assignees].sort((a, b) => (b.active || 0) - (a.active || 0))
            return `📊 **Ranked by active items:**\n\n${sorted.slice(0, 5).map((a, i) => `${i + 1}. **${a.name}**: ${a.active || 0} active, ${a.sp || 0} SP`).join('\n')}`
        }

        // Compare: "compare X and Y"
        if (q.match(/compare/)) {
            const names = assignees.filter(a => q.includes(a.name.toLowerCase()) || q.includes(a.name.split(' ')[0].toLowerCase()))
            if (names.length >= 2) {
                const [a, b] = names
                let resp = `⚖️ **${a.name} vs ${b.name}:**\n\n`
                resp += `| Metric | ${a.name.split(' ')[0]} | ${b.name.split(' ')[0]} |\n`
                resp += `|---|---|---|\n`
                resp += `| Active | ${a.active || 0} | ${b.active || 0} |\n`
                resp += `| SP | ${a.sp || 0} | ${b.sp || 0} |\n`
                resp += `| Bugs | ${a.bugs || 0} | ${b.bugs || 0} |\n`
                resp += `| Hygiene | ${a.hygiene?.score ?? '—'} | ${b.hygiene?.score ?? '—'} |\n`
                resp += `| Focus | ${a.focusScore ?? '—'} | ${b.focusScore ?? '—'} |\n`
                resp += `| PRs submitted | ${a.prsSubmitted || 0} | ${b.prsSubmitted || 0} |\n`
                return resp
            }
            return 'Please mention two team member names to compare. Example: "compare Anubhav and Sagar"'
        }

        // Keyword scoring: pick best handler
        const tokens = q.split(/\s+/)
        let bestHandler = null
        let bestScore = 0
        for (const h of handlers) {
            let score = 0
            for (const token of tokens) {
                if (h.keywords.includes(token)) score += h.weight
                // Partial match
                for (const kw of h.keywords) {
                    if (kw.length > 3 && token.length > 3 && (kw.includes(token) || token.includes(kw))) score += 0.5
                }
            }
            if (score > bestScore) { bestScore = score; bestHandler = h }
        }

        if (bestHandler && bestScore >= 0.5) {
            return bestHandler.fn()
        }

        // Fallback: return null to signal "ask the LLM"
        return null
    }, [handlers, findPerson, genPerson, genStatus, assignees, agingHistogram, alertsByOwner])

    // ── System prompt for LLM context ────────────────────────
    const buildSystemPrompt = useCallback(() => {
        const m = metrics
        const teamSummary = assignees.slice(0, 8).map(a =>
            `${a.name}: ${a.active || 0} active, ${a.bugs || 0} bugs`
        ).join('; ')

        return `You are Intel Bot, a concise project analyst for a software engineering team.
You answer questions about the project using ONLY the data below. Be direct and actionable.

Current Metrics:
- Health Score: ${m.healthScore}/100 (${m.healthLabel})
- Pipeline Rate: ${m.pipeRate}% (${m.pipeSucceeded}/${m.pipeActiveTotal} active)
- WIP: ${m.totalActive} active items
- Alerts: ${alertCount} total, ${m.criticalAlerts} critical (trend: ${alertTrend >= 0 ? '+' : ''}${alertTrend})
- Aging: ${m.agingPct}% of active items untouched >21 days
- Deploy Freq: ${deploy.deployFreq || 0} runs/day this week
- Burn Rate: ${sprint.burnPct || 0}% (week ${sprint.weekPct || 0}% elapsed)
- Sprint Items: ${sprint.doneCount || 0}/${sprint.totalCount || 0}, Scope Creep: ${sprint.scopeCreep || 0} added

Team (${assignees.length} members): ${teamSummary}

Top Alerts: ${alerts.slice(0, 3).map(a => `${a.severity}: ${a.title?.substring(0, 60)}`).join(' | ')}

Instructions:
- Answer in 2-4 sentences maximum.
- Use specific numbers from the data.
- If asked something not in the data, say so.
- Use emojis sparingly for emphasis.`
    }, [metrics, assignees, alertCount, alertTrend, alerts, deploy, sprint])

    // ── Message Handling (hybrid: rule-based + LLM) ──────────
    const sendMessage = useCallback(async (text) => {
        const userMsg = { role: 'user', content: text, time: new Date() }
        const ruleResponse = answerQuestion(text)

        if (ruleResponse !== null) {
            // Rule-based hit → instant response
            const botMsg = { role: 'bot', content: ruleResponse, time: new Date(), source: 'rule' }
            setMessages(prev => [...prev, userMsg, botMsg])
            return
        }

        // No rule match → try LLM
        setMessages(prev => [...prev, userMsg])

        if (llmAvailable) {
            setIsThinking(true)
            const systemPrompt = buildSystemPrompt()
            const llmResponse = await askLLM(text, systemPrompt)
            setIsThinking(false)

            if (llmResponse) {
                const botMsg = { role: 'bot', content: `🧠 ${llmResponse}`, time: new Date(), source: 'llm' }
                setMessages(prev => [...prev, botMsg])
                return
            }
        }

        // LLM offline or failed → static fallback
        const fallback = llmAvailable
            ? `I couldn't process that question right now.\n\n${genStatus()}\n\nType **"help"** for available commands.`
            : `🔌 AI is offline. Showing status instea/opt/portfolio/project"help"** for commands.`
        const botMsg = { role: 'bot', content: fallback, time: new Date(), source: 'fallback' }
        setMessages(prev => [...prev, botMsg])
    }, [answerQuestion, llmAvailable, askLLM, buildSystemPrompt, genStatus])

    const open = useCallback(() => {
        setIsOpen(true)
        if (messages.length === 0) {
            const briefing = genStatus()
            setMessages([{
                role: 'bot',
                content: `🤖 **INTEL BOT v2 ONLINE**\n\n${briefing}\n\n---\nType a question or click a quick action below.`,
                time: new Date()
            }])
        }
    }, [messages.length, genStatus])

    const close = useCallback(() => setIsOpen(false), [])

    return { messages, sendMessage, isOpen, open, close, isThinking, llmAvailable }
}
