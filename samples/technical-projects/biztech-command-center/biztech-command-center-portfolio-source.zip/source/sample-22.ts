// Core types for the BizTech Dashboard

export interface WorkItemFields {
    "System.Title": string;
    "System.WorkItemType": string;
    "System.State": string;
    [key: string]: any;
}

export interface WorkItem {
    id: number;
    fields: WorkItemFields;
}

export interface HygieneViolations {
    stale_ids: number[];
    missing_sprint_ids: number[];
    no_sp_ids: number[];
    orphan_ids: number[];
}

export interface OperativeHygiene {
    score: number;
    violations: HygieneViolations;
}

export interface Operative {
    name: string;
    active: number;
    hygiene: OperativeHygiene;
    items?: WorkItem[];
}

export interface WorkItemData {
    byAssignee: Record<string, Operative>;
    items: WorkItem[];
    sanityScore: number;
}
