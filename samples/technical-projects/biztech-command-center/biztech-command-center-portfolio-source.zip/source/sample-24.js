// Chart catalogue — themed wrappers for every chart shape the dashboard uses.
// Each one accepts a simple `data + series` API and applies chartTheme
// defaults automatically (8-colour graph palette, Poppins ticks, gridline
// tone, tooltip card).  Pages migrate to these in Phase 5; recharts usage
// inside the existing modal stays untouched until then.

export { chartTheme } from './theme'

export { default as ThemedBarChart }      from './ThemedBarChart'
export { default as ThemedLineChart }     from './ThemedLineChart'
export { default as ThemedAreaChart }     from './ThemedAreaChart'
export { default as ThemedComposedChart } from './ThemedComposedChart'
export { default as OwnerBarChart }       from './OwnerBarChart'
export { default as NPSGauge }            from './NPSGauge'
export { default as WaterfallChart }      from './WaterfallChart'
