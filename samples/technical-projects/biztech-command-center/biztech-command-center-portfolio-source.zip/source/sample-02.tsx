import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react'
import { AuthProvider, useAuth } from './auth/AuthContext'
import {
    DEFAULT_TAB_KEY,
    PUBLIC_TAB_KEYS,
    RBAC_ADMIN_TAB,
    isKnownTab,
    isRetiredTab,
    getDefaultChildOfGroup,
    isGroupKey,
} from './config/tabs'
import { useData } from './hooks/useData'
import useAutoTour from './hooks/useAutoTour'
import Layout from './components/Layout'
import CommandPalette from './components/CommandPalette'
import ErrorBoundary from './components/ErrorBoundary'
import LoadingSkeleton from './components/LoadingSkeleton'
import IntelBot from './components/IntelBot'
import AccessDenied from './components/AccessDenied'
import { useIntelBot } from './hooks/useIntelBot'

const CommandPage = lazy(() => import('./pages/CommandPage'))
const PipelinesPage = lazy(() => import('./pages/PipelinesPage'))
const SanityPage = lazy(() => import('./pages/SanityPage'))
const MPRPage = lazy(() => import('./pages/MPRPage'))
const TeamPage = lazy(() => import('./pages/TeamPage'))
const PRsPage = lazy(() => import('./pages/PRsPage'))
const AzureQualityPage = lazy(() => import('./pages/AzureQualityPage'))
const HeadcountMatchingPage = lazy(() => import('./pages/HeadcountMatchingPage'))
const ITSMAnalyticsPage = lazy(() => import('./pages/ITSMAnalyticsPage'))
const ITDeskPage = lazy(() => import('./pages/ITDeskPage'))
const OperationalAnalyticsPage = lazy(() => import('./pages/OperationalAnalyticsPage'))
const IncidentsRequirementsPage = lazy(() => import('./pages/IncidentsRequirementsPage'))
const BillingCollectionsPage = lazy(() => import('./pages/BillingCollectionsPage'))
const RevOpsCSPage = lazy(() => import('./pages/RevOpsCSPage'))
const OKRDashboardPage = lazy(() => import('./pages/OKRDashboardPage'))
const OKRPlaceholderPage = lazy(() => import('./pages/OKRPlaceholderPage'))
const OKRRoleScorecardPage = lazy(() => import('./pages/OKRRoleScorecardPage'))
const GovernancePage = lazy(() => import('./pages/GovernancePage'))
const HermesPage = lazy(() => import('./pages/HermesPage'))
const DeliveryPMPage = lazy(() => import('./pages/DeliveryPMPage'))
const ProfitabilityPage = lazy(() => import('./pages/ProfitabilityPage'))
const OKRDeliveryDynamicScorecardPage = lazy(() => import('./pages/OKRDeliveryDynamicScorecardPage'))
const QualitySanityPage = lazy(() => import('./pages/QualitySanityPage'))
const PipelinesPRsPage = lazy(() => import('./pages/PipelinesPRsPage'))
const TeamRatingPage = lazy(() => import('./pages/TeamRatingPage'))
const AssistNextTestingPage = lazy(() => import('./pages/AssistNextTestingPage'))
const PSHeadcountPage = lazy(() => import('./pages/PSHeadcountPage'))
const RMGHeadcountMixPage = lazy(() => import('./pages/rmg/RMGHeadcountMixPage'))
const RMGGovernanceUnifiedPage = lazy(() => import('./pages/RMGGovernanceUnifiedPage'))
const RMGBillabilityPage = lazy(() => import('./pages/rmg/RMGBillabilityPage'))
const RMGAllocationHealthPage = lazy(() => import('./pages/rmg/RMGAllocationHealthPage'))
const RMGEmployeeProjectPage = lazy(() => import('./pages/rmg/RMGEmployeeProjectPage'))
const RMGExceptionsPage = lazy(() => import('./pages/rmg/RMGExceptionsPage'))
const RBACAdminPage = lazy(() => import('./pages/RBACAdminPage'))
const LoginPage = lazy(() => import('./pages/LoginPage'))

function getInitialPage(): string {
  try {
    const params = new URLSearchParams(window.location.search)
    const tab = params.get('tab')
    if (!tab) return DEFAULT_TAB_KEY
    // Group keys deep-link to their default child (e.g. tab=biztech_ops → command).
    if (isGroupKey(tab)) return getDefaultChildOfGroup(tab) || DEFAULT_TAB_KEY
    // Retired tabs (billing_collections) gracefully fall back so legacy
    // shared URLs / bookmarks never land on a 404 / empty screen.
    if (isRetiredTab(tab)) return DEFAULT_TAB_KEY
    if (isKnownTab(tab)) return tab
  } catch { /* ignore */ }
  return DEFAULT_TAB_KEY
}

function firstAllowedPublicTab(allowedTabs: string[]): string {
  return allowedTabs.find(tab => PUBLIC_TAB_KEYS.includes(tab)) || allowedTabs[0] || DEFAULT_TAB_KEY
}

function DashboardApp() {
  const auth = useAuth()
  const [page, setPage] = useState(getInitialPage)
  const [surge503, setSurge503] = useState(false)
  const [cmdOpen, setCmdOpen] = useState(false)
  const dataEnabled = !auth.rbacEnabled || auth.authenticated
  const { pipelineData, workItemData, recommendationsData, hermesLearningData, headcountData, loading, lastUpdate, countdown } = useData(30000, dataEnabled)
  const bot = useIntelBot(pipelineData, workItemData)

  const fallbackTab = useMemo(() => firstAllowedPublicTab(auth.allowedTabs || []), [auth.allowedTabs])
  const currentPageAllowed = !auth.rbacEnabled || auth.allowedTabs.includes(page)

  const handleSetPage = useCallback((key: string) => {
    // Translate a parent-group key into its default child so URL state
    // always carries a renderable leaf tab.  Retired tabs fall through
    // to the user's allowed fallback.
    let next: string
    if (isGroupKey(key)) next = getDefaultChildOfGroup(key) || fallbackTab
    else if (isRetiredTab(key)) next = fallbackTab
    else if (isKnownTab(key)) next = key
    else next = fallbackTab
    setPage(next)
    try {
      const url = new URL(window.location.href)
      url.searchParams.set('tab', next)
      window.history.pushState({ tab: next }, '', url.toString())
    } catch { /* ignore */ }
  }, [fallbackTab])

  // Auto-redirect when the resolved initial page is denied by RBAC.  Without
  // this, a user whose role doesn't include the default tab ('command') —
  // e.g. someone granted only BizTech.Incidents.ITDesk — lands on the
  // AccessDenied screen on every login even though they have access to other
  // tabs (their IT Desk).  We forward them to their first allowed public tab.
  // Guarded so it can't loop: once handleSetPage updates `page`, the next run
  // finds currentPageAllowed=true and exits.
  useEffect(() => {
    if (auth.loading) return
    if (!auth.rbacEnabled) return
    if (!auth.authenticated) return
    if (currentPageAllowed) return
    if (!fallbackTab || fallbackTab === page) return
    // Defer to next tick so we don't trigger a cascading render warning
    // from inside an effect.  The cleanup cancels the queued call if the
    // user navigates again before it fires.
    const t = setTimeout(() => handleSetPage(fallbackTab), 0)
    return () => clearTimeout(t)
  }, [auth.loading, auth.rbacEnabled, auth.authenticated, currentPageAllowed, fallbackTab, page, handleSetPage])

  const autoTour = useAutoTour({
    enabled: auth.rbacEnabled && auth.authenticated && auth.autoTourEnabled,
    page,
    allowedTabs: auth.allowedTabs,
    setPage: handleSetPage,
  })

  // Handle browser back/forward.
  useEffect(() => {
    const onPopState = () => {
      const next = getInitialPage()
      setPage(next)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [])

  // Detect Surge.sh 503 from jfk node.
  useEffect(() => {
    const check = () => {
      if ((window as unknown as { __SURGE_503_DETECTED?: boolean }).__SURGE_503_DETECTED) {
        setSurge503(true)
      }
    }
    check()
    const t = setInterval(check, 5000)
    return () => clearInterval(t)
  }, [])

  // Global keyboard shortcuts.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setCmdOpen(true)
        return
      }
      if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        e.preventDefault()
        setCmdOpen(true)
        return
      }
      if ((e.ctrlKey || e.metaKey) && ((e.key >= '1' && e.key <= '9') || e.key === '0')) {
        e.preventDefault()
        const idx = e.key === '0' ? 9 : parseInt(e.key, 10) - 1
        const keys = (auth.allowedTabs || PUBLIC_TAB_KEYS).filter(tab => PUBLIC_TAB_KEYS.includes(tab)).slice(0, 10)
        if (keys[idx]) handleSetPage(keys[idx])
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [auth.allowedTabs, handleSetPage])

  const pages: Record<string, React.ReactNode> = {
    command: <CommandPage pipelineData={pipelineData} workItemData={workItemData} recommendationsData={recommendationsData} />,
    // Legacy routes — still served so deep links and embedded references keep working.
    pipelines: <PipelinesPage pipelineData={pipelineData} recommendationsData={recommendationsData} />,
    prs: <PRsPage workItemData={workItemData} recommendationsData={recommendationsData} />,
    sanity: <SanityPage workItemData={workItemData} recommendationsData={recommendationsData} />,
    // Merged sub-tabs per 08-June change request (1.2, 1.3).
    pipelines_prs: <PipelinesPRsPage pipelineData={pipelineData} workItemData={workItemData} recommendationsData={recommendationsData} />,
    quality_sanity: <QualitySanityPage workItemData={workItemData} recommendationsData={recommendationsData} />,
    team_rating: <TeamRatingPage />,
    assistnext_testing: <AssistNextTestingPage />,
    ps_headcount: <PSHeadcountPage />,
    team: <TeamPage workItemData={workItemData} recommendationsData={recommendationsData} />,
    headcount: <HeadcountMatchingPage headcountData={headcountData} recommendationsData={recommendationsData} />,
    itsm: <ITSMAnalyticsPage recommendationsData={recommendationsData} />,
    it_desk: <ITDeskPage recommendationsData={recommendationsData} />,
    oeg: <OperationalAnalyticsPage kind="oeg" recommendationsData={recommendationsData} />,
    cloud: <OperationalAnalyticsPage kind="cloud" recommendationsData={recommendationsData} />,
    incidents_requirements: <IncidentsRequirementsPage recommendationsData={recommendationsData} />,
    billing_collections: <BillingCollectionsPage recommendationsData={recommendationsData} />,
    revops_cs: <RevOpsCSPage recommendationsData={recommendationsData} />,
    okr_company: <OKRDashboardPage recommendationsData={recommendationsData} view="company" setPage={handleSetPage} />,
    // Sales + KAM stay on OKRDashboardPage because they also surface the
    // shared filters / recommendations rail; both load their own live
    // okr-*-data.json artifacts from inside that page.
    okr_sales: <OKRDashboardPage recommendationsData={recommendationsData} view="role" role="Sales" setPage={handleSetPage} />,
    okr_kam: <OKRDashboardPage recommendationsData={recommendationsData} view="role" role="KAM" setPage={handleSetPage} />,
    // Slide-driven sub-tabs (5 published OKR balanced-scorecard slides).
    // Structure is live from per-role JSON in scripts/build_okr_static_scorecards.py;
    // every metric shows "pending" until an upstream data source is wired
    // (swap the static artifact for a live fetch using the Sales/KAM template).
    okr_product: <OKRRoleScorecardPage roleLabel="Product" file="okr-product-data.json" />,
    okr_delivery: <OKRDeliveryDynamicScorecardPage />,
    okr_cloud_ops: <OKRRoleScorecardPage roleLabel="Cloud OPS" file="okr-cloud-ops-data.json" />,
    okr_pd: <OKRRoleScorecardPage roleLabel="P & D" file="okr-pd-data.json" />,
    okr_finance: <OKRRoleScorecardPage roleLabel="Finance" file="okr-finance-data.json" />,
    // Sub-tabs with no slide structure yet — keep the activation-checklist placeholder.
    okr_marketing: <OKRPlaceholderPage roleLabel="Marketing" />,
    okr_infosec_itops: <OKRPlaceholderPage roleLabel="InfoSec + IT OPS" />,
    okr_solution_consulting: <OKRPlaceholderPage roleLabel="Solution Consulting" />,
    governance: <GovernancePage recommendationsData={recommendationsData} />,
    mpr: <MPRPage recommendationsData={recommendationsData} />,
    delivery_pm: <DeliveryPMPage auth={auth} />,
    profitability: <ProfitabilityPage />,
    rmg_governance: <RMGGovernanceUnifiedPage />,
    rmg_unified: <RMGGovernanceUnifiedPage />,
    rmg_mix: <RMGHeadcountMixPage />,
    rmg_billability: <RMGBillabilityPage />,
    rmg_allocation_health: <RMGAllocationHealthPage />,
    rmg_matrix: <RMGEmployeeProjectPage />,
    rmg_exceptions: <RMGExceptionsPage />,
    azure_quality: <AzureQualityPage workItemData={workItemData} recommendationsData={recommendationsData} />,
    hermes: <HermesPage recommendationsData={recommendationsData} hermesLearningData={hermesLearningData} />,
    [RBAC_ADMIN_TAB]: <RBACAdminPage setPage={handleSetPage} />,
  }

  if (auth.loading) {
    return <LoadingSkeleton />
  }

  if (auth.rbacEnabled && !auth.authenticated) {
    return (
      <Suspense fallback={<LoadingSkeleton />}>
        <LoginPage />
      </Suspense>
    )
  }

  return (
    <Layout
      page={page}
      setPage={handleSetPage}
      pipelineData={pipelineData}
      lastUpdate={lastUpdate}
      workItemData={workItemData}
      countdown={countdown}
      allowedTabs={auth.allowedTabs}
      auth={auth}
      autoTour={autoTour}
    >
      {surge503 && (
        <div style={{
          position: 'fixed', top: '48px', left: 0, right: 0, zIndex: 9998,
          background: 'var(--signal-red)', color: '#fff', padding: '10px 20px',
          fontSize: '12px', fontFamily: 'var(--font-mono)', textAlign: 'center',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px'
        }}>
          <span>Site migrated to Neocities. New URL:</span>
          <code style={{ background: 'rgba(0,0,0,0.3)', padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
            https://example.invalid
          </code>
          <button onClick={() => setSurge503(false)} style={{
            background: '#fff', color: 'var(--signal-red)', border: 'none',
            padding: '3px 10px', borderRadius: '4px', cursor: 'pointer',
            fontSize: '10px', fontWeight: 700
          }}>DISMISS</button>
        </div>
      )}
      {loading && !lastUpdate ? <LoadingSkeleton /> : (
        <ErrorBoundary key={page}>
          <Suspense fallback={<LoadingSkeleton />}>
            {currentPageAllowed ? (
              pages[page] || pages[fallbackTab] || pages.command
            ) : (fallbackTab && fallbackTab !== page) ? (
              // Render the LoadingSkeleton (not AccessDenied) while the
              // auto-redirect in our useEffect lands — avoids the brief
              // 'Access denied' flash on the legitimate role-based redirect
              // path (e.g. an IT-Desk-only user lands on the default tab).
              <LoadingSkeleton />
            ) : (
              <AccessDenied tab={page} setPage={handleSetPage} fallbackTab={fallbackTab} />
            )}
          </Suspense>
        </ErrorBoundary>
      )}
      <IntelBot
        messages={bot.messages}
        sendMessage={bot.sendMessage}
        isOpen={bot.isOpen}
        open={bot.open}
        close={bot.close}
        isThinking={bot.isThinking}
        llmAvailable={bot.llmAvailable}
      />
      <CommandPalette
        isOpen={cmdOpen}
        onClose={() => setCmdOpen(false)}
        workItemData={workItemData}
        pipelineData={pipelineData}
        setPage={handleSetPage}
        allowedTabs={auth.allowedTabs}
      />
    </Layout>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <DashboardApp />
    </AuthProvider>
  )
}
