export default function BarChart({ bars, height = 90 }) {
    const mx = Math.max(...bars.map(b => b.value), 1)
    return (
        <div className="cc-chart-row" style={{ height }}>
            {bars.map((b, i) => (
                <div key={i} className="cc-bar-col">
                    <div className="cc-bar-stick"
                        style={{ height: `${Math.max(6, (b.value / mx) * (height - 30))}px`, background: b.color || 'var(--accent)' }}>
                    </div>
                    <div className="cc-bar-label">{b.label}</div>
                    <div className="cc-bar-value">{b.value}</div>
                </div>
            ))}
        </div>
    )
}
