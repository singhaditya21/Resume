import KanbanRoadmap from '../sections/KanbanRoadmap'
import RecommendationsPanel from '../components/RecommendationsPanel'

export default function RoadmapPage({ pipelineData, workItemData, recommendationsData }) {
    return (
        <div className="page active" style={{ overflowY: 'auto', paddingBottom: '40px' }}>
            <RecommendationsPanel
                recommendationsData={recommendationsData}
                areas="Roadmap"
                title="ROADMAP RECOMMENDATIONS"
                limit={4}
                compact
            />
            <KanbanRoadmap pipelineData={pipelineData} workItemData={workItemData} />
        </div>
    )
}
