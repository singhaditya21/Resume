#!/usr/bin/env python3
"""
BizTech Intel recommendation and Hermes learning generator.

The dashboard remains deterministic first: this script builds trusted signals
from the published dashboard JSON, optionally asks Cerebras to improve the
recommendation wording, then validates the model output against the original
signals. Evidence and links are always restored from deterministic data.
"""
import json
import os
import re
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

import itdesk_signals  # shared rule engine for the IT Desk Action Center

import requests


ORG = os.environ.get("AZURE_DEVOPS_ORG", "acidaes")
PROJECT = os.environ.get("AZURE_DEVOPS_PROJECT", "BizTech")
DATA_DIR = Path(os.environ.get("OUTPUT_DIR") or Path(__file__).resolve().parents[1] / "data")
RECOMMENDATIONS_PATH = DATA_DIR / "recommendations.json"
HERMES_PATH = DATA_DIR / "hermes-learning.json"

DASHBOARD_BASE_URL = os.environ.get("DASHBOARD_URL", "https://example.invalid").rstrip("/") + "/"
PR_BASE_URL = f"https://example.invalid}/{PROJECT}/_git/BizTech/pullrequest"
WORK_ITEM_BASE_URL = f"https://example.invalid}/{PROJECT}/_workitems/edit"
PIPELINE_BASE_URL = f"https://example.invalid}/{PROJECT}/_build?definitionId="


def env_value(name, default=""):
    value = str(os.environ.get(name, "") or "").strip()
    if not value or value.startswith("$("):
        return default
    return value


def env_float(name, default):
    try:
        return float(env_value(name, str(default)))
    except (TypeError, ValueError):
        return default


def env_int(name, default):
    try:
        return int(float(env_value(name, str(default))))
    except (TypeError, ValueError):
        return default


CEREBRAS_URL = env_value("CEREBRAS_URL", "https://example.invalid")
CEREBRAS_MODEL = env_value("CEREBRAS_MODEL", env_value("HERMES_CEREBRAS_MODEL", "llama3.1-8b"))
CEREBRAS_API_KEY = env_value("CEREBRAS_API_KEY", "")
CEREBRAS_CONNECT_TIMEOUT_SECONDS = env_float("REDACTED_OPAQUE_VALUE", 10)
CEREBRAS_READ_TIMEOUT_SECONDS = env_float("CEREBRAS_READ_TIMEOUT_SECONDS", 60)
CEREBRAS_MAX_TOKENS = env_int("CEREBRAS_MAX_TOKENS", 3072)
CEREBRAS_TEMPERATURE = env_float("CEREBRAS_TEMPERATURE", 0.15)
CEREBRAS_TOP_P = env_float("CEREBRAS_TOP_P", 1.0)
CEREBRAS_MAX_RETRIES = env_int("CEREBRAS_MAX_RETRIES", 2)
CEREBRAS_RETRY_SLEEP_SECONDS = env_float("CEREBRAS_RETRY_SLEEP_SECONDS", 2.0)
CEREBRAS_MIN_CALL_INTERVAL_SECONDS = env_float("REDACTED_OPAQUE_VALUE", 0.0)
LLM_SIGNAL_LIMIT = env_int("CEREBRAS_SIGNAL_LIMIT", 28)
LLM_RECOMMENDATION_LIMIT = env_int("CEREBRAS_RECOMMENDATION_LIMIT", 16)
RECOMMENDATION_LIMIT = env_int("HERMES_RECOMMENDATION_LIMIT", 64)
SIGNALS_PER_AREA = env_int("HERMES_SIGNALS_PER_AREA", 4)

VALID_PRIORITIES = {"critical", "high", "medium", "low"}
AREA_TAB = {
    "Command": "command",
    "Roadmap": "roadmap",
    "Pipelines": "pipelines",
    "Pull Requests": "prs",
    "Data Sanity": "sanity",
    "Operatives": "team",
    "Headcount": "headcount",
    "ITSM Analytics": "itsm",
    "IT Desk": "it_desk",
    "OEG": "oeg",
    "Cloud": "cloud",
    "Incidents": "incidents_requirements",
    "Requirements": "incidents_requirements",
    "Billing & Collections": "billing_collections",
    "Rev Ops CS": "revops_cs",
    "OKR": "okr",
    "Governance": "governance",
    "Azure Quality": "azure_quality",
    "MPR": "mpr",
    # Product OKR scorecard (v2) — sourced from BusinessNext-SAFe-Transformation.
    # Drives recommendations on Release Predictability, Original-Plan
    # Adherence, Quality (Critical Bug Rate, Regression, Reopen,
    # False-Positive), Engineering Maturity (Best Practices, Unit
    # Tests, Security Checks, Defect Injection), Governance
    # (RAG Health, Production Readiness).
    "Product": "okr",
    # Delivery PM tab — Phase J added a Hermes RecommendationsPanel
    # so generated insights flow into the new Top At-Risk + Portfolio
    # Owner panels.
    "Delivery PM": "delivery_pm",
}
VALID_AREAS = set(AREA_TAB)


def now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_json(name, default):
    path = DATA_DIR / name
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(f"Wrote {path} ({path.stat().st_size} bytes)")


def priority_from_score(score):
    if score >= 80:
        return "critical"
    if score >= 60:
        return "high"
    if score >= 35:
        return "medium"
    return "low"


def clamp(value, lower, upper):
    return max(lower, min(upper, value))


def safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default


def safe_float(value, default=0.0):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def short_text(value, limit=220):
    value = str(value or "").strip()
    if len(value) <= limit:
        return value
    return value[: limit - 3].rstrip() + "..."


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-") or "item"


def age_label(hours):
    hours = safe_float(hours)
    if hours < 1:
        return "<1h"
    if hours < 24:
        return f"{round(hours)}h"
    return f"{round(hours / 24)}d"


def days_label(days):
    days = safe_float(days)
    if days < 1:
        return "<1d"
    return f"{round(days, 1)}d" if days < 10 else f"{round(days)}d"


def dashboard_url(tab, **params):
    query = {"tab": tab}
    query.update({key: value for key, value in params.items() if value is not None and value != ""})
    return f"{DASHBOARD_BASE_URL}?{urlencode(query)}"


def normalize_dashboard_url(url):
    value = str(url or "")
    if value.startswith("https://example.invalid"):
        return value.replace("https://example.invalid", DASHBOARD_BASE_URL + "?", 1)
    return value


def tab_link(area, label=None, **params):
    tab = AREA_TAB.get(area, "command")
    if area == "Incidents":
        params.setdefault("subtab", "incidents")
    if area == "Requirements":
        params.setdefault("subtab", "requirements")
    return {"label": label or f"Open {area}", "url": dashboard_url(tab, **params)}


def record_link(row, area, label=None):
    url = normalize_dashboard_url(row.get("dashboardUrl"))
    if not url:
        record_id = row.get("itemId") or row.get("caseId") or row.get("id")
        url = tab_link(area, label, record=record_id)["url"]
    return {"label": label or f"Open {row.get('itemId') or row.get('caseId') or row.get('id')}", "url": url}


def pr_url(pr_id):
    return f"{PR_BASE_URL}/{pr_id}"


def work_item_url(item_id):
    return f"{WORK_ITEM_BASE_URL}/{item_id}"


def pipeline_url(pipeline_id):
    return f"{PIPELINE_BASE_URL}{pipeline_id}"


def pr_link(pr):
    pr_id = pr.get("id")
    return {"label": f"Open PR #{pr_id}", "url": pr.get("adoUrl") or pr.get("url") or pr_url(pr_id)}


def build_signal(signal_id, area, category, score, title, owner, why, action_hint, links, evidence, entity_type, entity_id=None):
    return {
        "id": signal_id,
        "area": area,
        "category": category,
        "score": int(clamp(score, 0, 100)),
        "priority": priority_from_score(score),
        "title": short_text(title, 180),
        "owner": short_text(owner or "Unassigned", 80),
        "why": short_text(why, 300),
        "actionHint": short_text(action_hint, 300),
        "links": (links or [])[:6],
        "evidence": (evidence or [])[:8],
        "entityType": entity_type,
        "entityId": entity_id,
    }


def healthy_signal(area, title, why, evidence=None):
    return build_signal(
        signal_id=f"stable-{slug(area)}",
        area=area,
        category="stable_monitoring",
        score=20,
        title=title,
        owner="PORTFOLIO_REDACTED",
        why=why,
        action_hint="Keep monitoring the tab and use the drill views if the next refresh changes the risk profile.",
        links=[tab_link(area)],
        evidence=evidence or [{"label": "Status", "value": "No high-risk signal in current refresh"}],
        entity_type="tab_health",
    )


def load_core_with_chunks():
    core = load_json("workitems-core.json", {})
    by_assignee = dict(core.get("byAssignee") or {})
    for index in range(1, 5):
        chunk = load_json(f"assignees-{index}.json", {})
        for name, data in (chunk.get("byAssignee") or {}).items():
            merged = dict(by_assignee.get(name) or {})
            merged.update(data or {})
            by_assignee[name] = merged
    if by_assignee:
        core["byAssignee"] = by_assignee
    return core


def build_command_signals(core):
    alerts = core.get("alerts") or []
    checks = core.get("checks") or []
    signals = []
    critical_alerts = [alert for alert in alerts if alert.get("severity") == "critical"]
    failing_checks = [check for check in checks if check.get("severity") == "fail"]
    if critical_alerts:
        alert = critical_alerts[0]
        item_id = alert.get("id")
        links = [tab_link("Command")]
        if item_id:
            if alert.get("workItemType") == "PR" or alert.get("type", "").startswith("pr_"):
                links.insert(0, {"label": f"Open PR #{item_id}", "url": pr_url(item_id)})
            else:
                links.insert(0, {"label": f"Open work item #{item_id}", "url": work_item_url(item_id)})
        signals.append(build_signal(
            f"command-alert-{item_id or slug(alert.get('type'))}",
            "Command",
            "attention_queue",
            88,
            alert.get("text") or "Critical command-center alert",
            alert.get("owner") or "BizTech Operations",
            f"{len(critical_alerts)} critical alert(s) are currently present in the command queue.",
            "Clear the top command-center alert first, then rerun the dashboard refresh to verify the queue reduces.",
            links,
            [
                {"label": "Critical alerts", "value": str(len(critical_alerts))},
                {"label": "Total alerts", "value": str(len(alerts))},
                {"label": "Alert type", "value": alert.get("type", "unknown")},
            ],
            "command_alert",
            item_id,
        ))
    if failing_checks:
        check = failing_checks[0]
        ids = [item for item in check.get("ids") or [] if str(item).isdigit()]
        links = [{"label": f"Open work item #{item_id}", "url": work_item_url(item_id)} for item_id in ids[:3]] or [tab_link("Data Sanity")]
        signals.append(build_signal(
            f"command-check-{slug(check.get('name'))}",
            "Command",
            "failed_check",
            clamp(60 + safe_int(check.get("count")) * 2, 60, 92),
            f"{check.get('name', 'Dashboard check')} is failing",
            "BizTech Operations",
            check.get("detail") or f"{safe_int(check.get('count'))} items failed a command-center check.",
            "Assign a named owner for the failed check and fix the sample items before the next refresh.",
            links,
            [
                {"label": "Check", "value": check.get("name", "Unknown")},
                {"label": "Count", "value": str(check.get("count", 0))},
                {"label": "Sample IDs", "value": ", ".join(str(i) for i in ids[:5]) or "n/a"},
            ],
            "dashboard_check",
        ))
    if not signals:
        signals.append(healthy_signal(
            "Command",
            "Command center has no critical top-level alert",
            f"{len(alerts)} alert(s) and {len(checks)} check(s) were present in the latest refresh.",
            [{"label": "Alerts", "value": str(len(alerts))}, {"label": "Checks", "value": str(len(checks))}],
        ))
    return signals


def build_roadmap_signals(core):
    sprint = core.get("sprint") or {}
    total_items = safe_int(sprint.get("totalItems"))
    completed_items = safe_int(sprint.get("completedItems"))
    days_remaining = safe_float(sprint.get("daysRemaining"))
    remaining_sp = safe_int(sprint.get("remainingSP"))
    total_sp = safe_int(sprint.get("totalSP"))
    scope_creep = safe_int(sprint.get("scopeCreep"))
    completion = (completed_items / total_items * 100) if total_items else 0
    score = 20
    reasons = []
    if total_items and completion < 60:
        score += 25
        reasons.append(f"{round(completion)}% item completion")
    if remaining_sp > 0 and days_remaining <= 2:
        score += 25
        reasons.append(f"{remaining_sp} story point(s) left with {days_label(days_remaining)} remaining")
    if scope_creep > 0:
        score += min(25, scope_creep * 5)
        reasons.append(f"{scope_creep} scope-creep item(s)")
    if score >= 35:
        return [build_signal(
            "roadmap-current-sprint",
            "Roadmap",
            "sprint_execution",
            clamp(score, 35, 95),
            f"{sprint.get('name') or 'Current sprint'} needs execution review",
            "Sprint owners",
            "; ".join(reasons) or "Current sprint has execution risk.",
            "Review remaining scope, remove blocked work, and update the sprint plan before the next standup.",
            [tab_link("Roadmap")],
            [
                {"label": "Sprint", "value": sprint.get("name") or "Current"},
                {"label": "Items", "value": f"{completed_items}/{total_items} completed"},
                {"label": "Remaining SP", "value": str(remaining_sp)},
                {"label": "Scope creep", "value": str(scope_creep)},
            ],
            "sprint",
        )]
    return [healthy_signal(
        "Roadmap",
        f"{sprint.get('name') or 'Current sprint'} is tracking without a major roadmap signal",
        f"{completed_items}/{total_items} items are complete and {remaining_sp}/{total_sp} story points remain.",
        [{"label": "Verdict", "value": sprint.get("verdict") or "n/a"}, {"label": "Days remaining", "value": str(days_remaining)}],
    )]


def build_pr_signals(core):
    signals = []
    for pr in core.get("prs", []):
        pr_id = pr.get("id")
        if not pr_id:
            continue
        age = safe_float(pr.get("ageHours"))
        reviewers = safe_int(pr.get("reviewerCount"), len(pr.get("reviewers") or []))
        approved = len(pr.get("approvedBy") or []) > 0
        has_review = bool(pr.get("hasReview"))
        target = pr.get("targetBranch") or "unknown"
        linked_count = safe_int(pr.get("linkedWorkItemCount"), len(pr.get("linkedWorkItems") or []))
        active_threads = safe_int(pr.get("activeCommentThreadCount"))
        score = 0
        reasons = []

        if age >= 168:
            score += 40
            reasons.append(f"open for {age_label(age)}")
        elif age >= 48:
            score += 25
            reasons.append(f"open for {age_label(age)}")
        elif age >= 24:
            score += 12
            reasons.append(f"open for {age_label(age)}")
        if reviewers == 0:
            score += 25
            reasons.append("no reviewer assigned")
        elif not has_review:
            score += 25
            reasons.append("no reviewer vote")
        if approved and age >= 48:
            score += 20
            reasons.append("approved but not merged")
        if target in {"main", "MYProduction"}:
            score += 15
            reasons.append(f"targets {target}")
        if linked_count == 0:
            score += 10
            reasons.append("no linked Azure Boards work item")
        if active_threads > 0:
            score += 10
            reasons.append(f"{active_threads} active comment thread(s)")
        if score < 25:
            continue

        if reviewers == 0:
            action = "Assign an accountable reviewer today, or close the PR if it is no longer required."
        elif not has_review:
            action = "Get the first reviewer vote today; stale unreviewed PRs should be reassigned or abandoned."
        elif approved and age >= 48:
            action = "Merge the approved PR or explicitly abandon it to reduce release drift."
        elif linked_count == 0:
            action = "Link the PR to an Azure Boards work item before merge so release traceability is preserved."
        else:
            action = "Review the PR status and either progress it to merge or close it."

        signals.append(build_signal(
            signal_id=f"pr-{pr_id}",
            area="Pull Requests",
            category="review_bottleneck" if not has_review else "release_readiness",
            score=clamp(score, 0, 100),
            title=f"PR #{pr_id}: {pr.get('title') or 'Untitled PR'}",
            owner=pr.get("createdBy") or "Unknown",
            why="; ".join(reasons),
            action_hint=action,
            links=[pr_link(pr)],
            evidence=[
                {"label": "PR", "value": f"#{pr_id}"},
                {"label": "Age", "value": age_label(age)},
                {"label": "Target", "value": target},
                {"label": "Reviewers", "value": str(reviewers)},
                {"label": "Approved", "value": "yes" if approved else "no"},
                {"label": "Linked work items", "value": str(linked_count)},
            ],
            entity_type="pull_request",
            entity_id=pr_id,
        ))
    if not signals:
        signals.append(healthy_signal(
            "Pull Requests",
            "Pull request queue has no high-risk review bottleneck",
            f"{len(core.get('prs') or [])} active PR(s) were reviewed for age, reviewer coverage, and linkage.",
            [{"label": "Active PRs", "value": str(len(core.get("prs") or []))}],
        ))
    return signals


def build_data_sanity_signals(core):
    signals = []
    data_sanity = core.get("healthV2", {}).get("components", {}).get("dataSanity", {})
    for owner in data_sanity.get("blame", [])[:12]:
        owner_name = owner.get("name") or "Unassigned"
        for idx, issue in enumerate((owner.get("breakdown") or [])[:3], 1):
            count = safe_int(issue.get("count"))
            if count <= 0:
                continue
            ids = [int(item) for item in (issue.get("ids") or [])[:5] if str(item).isdigit()]
            reason = issue.get("reason") or "Data quality issue"
            item_type = issue.get("type") or "Work Item"
            links = [{"label": f"Open work item #{item_id}", "url": work_item_url(item_id)} for item_id in ids[:3]]
            if not links:
                links = [tab_link("Data Sanity")]
            signals.append(build_signal(
                signal_id=f"sanity-{slug(owner_name)}-{idx}",
                area="Data Sanity",
                category="data_quality",
                score=clamp(30 + count, 35, 95),
                title=f"{owner_name}: {count}x {reason}",
                owner=owner_name,
                why=f"{count} {item_type} item(s) are flagged for {reason}.",
                action_hint=f"Fix the top {min(count, 10)} {item_type} item(s), then rerun the refresh to reduce hygiene debt.",
                links=links,
                evidence=[
                    {"label": "Owner", "value": owner_name},
                    {"label": "Issue", "value": reason},
                    {"label": "Count", "value": str(count)},
                    {"label": "Type", "value": item_type},
                    {"label": "Samples", "value": ", ".join(str(i) for i in ids[:5]) or "n/a"},
                ],
                entity_type="work_item_group",
                entity_id=ids[0] if ids else None,
            ))
    if not signals:
        signals.append(healthy_signal(
            "Data Sanity",
            "Data sanity has no owner-level breach signal",
            "The latest health payload did not expose a high-count hygiene owner requiring action.",
            [{"label": "Sanity score", "value": str(core.get("sanityScore", "n/a"))}],
        ))
    return signals


def failure_streak(pipeline):
    streak = 0
    for status in pipeline.get("history") or []:
        if status == "failed":
            streak += 1
        else:
            break
    return streak


def build_pipeline_signals(pipelines):
    signals = []
    for pipeline in pipelines or []:
        pipeline_id = pipeline.get("id")
        if not pipeline_id:
            continue
        status = pipeline.get("lastStatus") or "none"
        state = pipeline.get("lastState") or "none"
        success_rate = safe_int(pipeline.get("successRate"), -1)
        streak = failure_streak(pipeline)
        score = 0
        reasons = []
        if state == "inProgress":
            score += 10
            reasons.append("run in progress")
        if status == "failed":
            score += 45
            reasons.append("last run failed")
        if streak >= 2:
            score += 25
            reasons.append(f"{streak} consecutive failures")
        if 0 <= success_rate < 60:
            score += 20
            reasons.append(f"{success_rate}% recent success rate")
        if not pipeline.get("lastTime"):
            score += 20
            reasons.append("no recent run time published")
        if score < 25:
            continue
        signals.append(build_signal(
            signal_id=f"pipeline-{pipeline_id}",
            area="Pipelines",
            category="pipeline_health",
            score=clamp(score, 0, 100),
            title=f"Pipeline {pipeline.get('name') or pipeline_id} needs attention",
            owner="PORTFOLIO_REDACTED",
            why="; ".join(reasons),
            action_hint="Open the run history, inspect the latest failure, and pause dependent promotion until the failure mode is understood.",
            links=[{"label": f"Open pipeline {pipeline_id}", "url": pipeline_url(pipeline_id)}],
            evidence=[
                {"label": "Pipeline", "value": pipeline.get("name") or str(pipeline_id)},
                {"label": "Last status", "value": status},
                {"label": "Failure streak", "value": str(streak)},
                {"label": "Success rate", "value": f"{success_rate}%" if success_rate >= 0 else "n/a"},
            ],
            entity_type="pipeline",
            entity_id=pipeline_id,
        ))
    if not signals:
        signals.append(healthy_signal(
            "Pipelines",
            "Pipeline estate has no failed high-risk run in the latest payload",
            f"{len(pipelines or [])} pipeline definition(s) were checked for status, streak, and success rate.",
            [{"label": "Pipelines checked", "value": str(len(pipelines or []))}],
        ))
    return signals


def build_operatives_signals(core):
    signals = []
    by_assignee = core.get("byAssignee") or {}
    for name, assignee in sorted(by_assignee.items(), key=lambda kv: safe_int(kv[1].get("active")), reverse=True)[:18]:
        active = safe_int(assignee.get("active"))
        stale = safe_int(assignee.get("stale"))
        open_prs = safe_int(assignee.get("openPRs"))
        hygiene_score = safe_int((assignee.get("hygiene") or {}).get("score"), 100)
        personal_ct = safe_float(assignee.get("personalCycleTime"))
        score = active * 3 + stale * 5 + open_prs * 8 + max(0, 70 - hygiene_score)
        if personal_ct >= 60:
            score += 12
        if score < 25:
            continue
        signals.append(build_signal(
            f"operative-{slug(name)}",
            "Operatives",
            "resource_focus",
            clamp(score, 35, 95),
            f"{name} has execution load requiring review",
            name,
            f"{active} active item(s), {stale} stale item(s), {open_prs} open PR(s), hygiene score {hygiene_score}.",
            "Review the operative detail table, rebalance WIP above four open items, and close stale hygiene gaps.",
            [tab_link("Operatives", "Open operative view", owner=name)],
            [
                {"label": "Active", "value": str(active)},
                {"label": "Stale", "value": str(stale)},
                {"label": "Open PRs", "value": str(open_prs)},
                {"label": "Hygiene", "value": str(hygiene_score)},
                {"label": "Avg CT", "value": days_label(personal_ct)},
            ],
            "assignee",
            name,
        ))
    if not signals:
        signals.append(healthy_signal(
            "Operatives",
            "Operative workload has no high-risk WIP signal",
            f"{len(by_assignee)} operative profile(s) were reviewed for active load, stale work, PRs, and hygiene score.",
            [{"label": "Operatives", "value": str(len(by_assignee))}],
        ))
    return signals


def build_headcount_signals(headcount):
    datasets = headcount.get("datasets") or {}
    user = datasets.get("user") or {}
    employee = datasets.get("employee") or {}
    user_total = safe_int(user.get("total"))
    employee_total = safe_int(employee.get("total"))
    user_buckets = {bucket.get("id"): safe_int(bucket.get("count")) for bucket in user.get("buckets") or []}
    employee_buckets = {bucket.get("id"): safe_int(bucket.get("count")) for bucket in employee.get("buckets") or []}
    delta = user_total - employee_total
    bucket_gap = sum(abs(user_buckets.get(key, 0) - employee_buckets.get(key, 0)) for key in set(user_buckets) | set(employee_buckets))
    score = abs(delta) * 4 + min(50, bucket_gap)
    if score >= 25:
        return [build_signal(
            "headcount-user-employee-gap",
            "Headcount",
            "source_reconciliation",
            clamp(score, 35, 95),
            "Headcount User vs Employee totals are not aligned",
            "People operations owners",
            f"User Intel count is {user_total}; Employee Intel count is {employee_total}; bucket absolute gap is {bucket_gap}.",
            "Review the bucket differences first, then reconcile missing or extra people at source.",
            [tab_link("Headcount")],
            [
                {"label": "User total", "value": str(user_total)},
                {"label": "Employee total", "value": str(employee_total)},
                {"label": "User - Employee", "value": str(delta)},
                {"label": "Bucket abs gap", "value": str(bucket_gap)},
            ],
            "headcount_reconciliation",
        )]
    return [healthy_signal(
        "Headcount",
        "Headcount User and Employee totals are closely aligned",
        f"User Intel count is {user_total}; Employee Intel count is {employee_total}.",
        [{"label": "User", "value": str(user_total)}, {"label": "Employee", "value": str(employee_total)}],
    )]


def top_owner_signal(area, summary, owner_rows, records, stale_key="stale"):
    owner_rows = owner_rows or []
    records = records or []
    top_owner = next((row for row in owner_rows if safe_int(row.get("open")) or safe_int(row.get(stale_key)) or safe_int(row.get("overdue"))), owner_rows[0] if owner_rows else None)
    open_count = safe_int(summary.get("open"))
    stale = safe_int(summary.get("stale"), safe_int(summary.get("staleOpen")))
    overdue = safe_int(summary.get("overdue"))
    critical = safe_int(summary.get("critical"), safe_int(summary.get("criticalAge")))
    score = min(100, stale * 2 + overdue * 4 + critical * 2 + min(30, open_count // 10))
    if top_owner:
        score += min(20, safe_int(top_owner.get("open")) // 2)
    risky_record = next((row for row in records if row.get("lifecycle") == "Open" and (row.get("isOverdue") or row.get("isStale") or safe_int(row.get("priorityRank"), 5) <= 2)), None)
    if score >= 25:
        links = []
        if risky_record:
            links.append(record_link(risky_record, area, f"Open item {risky_record.get('itemId') or risky_record.get('caseId') or risky_record.get('id')}"))
        links.append(tab_link(area))
        return build_signal(
            f"{slug(area)}-open-risk",
            area,
            "aging_ownership",
            clamp(score, 35, 98),
            f"{area} open queue has aging ownership risk",
            (top_owner or {}).get("name") or "Queue owners",
            f"{open_count} open, {stale} stale, {overdue} overdue, {critical} critical-age item(s).",
            "Open the tab drill table, assign accountable owners for the oldest open items, and publish the next action.",
            links,
            [
                {"label": "Open", "value": str(open_count)},
                {"label": "Stale", "value": str(stale)},
                {"label": "Overdue", "value": str(overdue)},
                {"label": "Critical", "value": str(critical)},
                {"label": "Top owner", "value": (top_owner or {}).get("name", "n/a")},
            ],
            "case_queue",
        )
    return healthy_signal(
        area,
        f"{area} has no high-risk open queue signal",
        f"{open_count} open item(s), {stale} stale, {overdue} overdue in the latest refresh.",
        [{"label": "Open", "value": str(open_count)}, {"label": "Stale", "value": str(stale)}],
    )


def build_itsm_signals(itsm):
    owner_rows = (itsm.get("ownerSummaries") or {}).get("currentOwner") or []
    return [top_owner_signal("ITSM Analytics", itsm.get("summary") or {}, owner_rows, itsm.get("cases") or [], "stale")]


def build_operational_signals(payload, area):
    owner_rows = (payload.get("summaries") or {}).get("currentOwner") or []
    return [top_owner_signal(area, payload.get("summary") or {}, owner_rows, payload.get("records") or [], "stale")]


def build_incident_requirement_signals(payload):
    # IT Desk is no longer derived from Requirements (Redash 539); see
    # build_itdesk_signals() which reads it-desk-data.json (Redash 540)
    # directly and emits the full action-card metadata for the Action Center.
    signals = []
    for key, area in (("incidents", "Incidents"), ("requirements", "Requirements")):
        section = payload.get(key) or {}
        owner_rows = (section.get("summaries") or {}).get("currentOwner") or []
        signals.append(top_owner_signal(area, section.get("summary") or {}, owner_rows, section.get("records") or [], "stale"))
    return signals


def _severity_to_score(severity):
    """Map Action Center severity → 0-100 score consumed by the LLM ranker."""
    return {"CRITICAL": 92, "HIGH": 78, "MEDIUM": 60, "LOW": 35}.get(severity, 40)


def build_itdesk_signals(itdesk_data, itdesk_history):
    """11 deterministic IT Desk rules → canonical build_signal() dicts.

    Each signal carries the standard fields the LLM/recommendations pipeline
    needs PLUS the extra Action Center fields (actionVerb, severity,
    urgency, subjectCaseIds, recipient, deadline, doneWhenText, rationale,
    persistedRuns, firstSeenAt, isNew) so the React panel can render
    server-side cards directly when present.
    """
    if not itdesk_data:
        return []
    records = itdesk_data.get("records") or []
    summary = itdesk_data.get("summary") or {}
    distributions = itdesk_data.get("distributions") or {}
    if not records:
        return []

    scoreboard = itdesk_signals.compute_scoreboard(records)
    raw = itdesk_signals.compute_signals(records, summary, distributions, scoreboard)
    enriched = itdesk_signals.merge_history_metadata(raw, itdesk_history)

    out = []
    for sig in enriched:
        # Build the canonical signal envelope (LLM/recommendations contract)
        envelope = build_signal(
            signal_id=sig["key"],
            area="IT Desk",
            category=sig["ruleId"],
            score=_severity_to_score(sig["severity"]),
            title=sig["title"],
            owner=sig.get("actor") or "IT Desk Lead",
            why=sig["rationale"],
            action_hint=sig["title"],   # the verb-led title IS the action
            links=[tab_link("IT Desk")],
            evidence=[
                {"label": e.get("label"), "value": str(e.get("value"))}
                for e in (sig.get("evidence") or []) if e.get("label") and e.get("value") is not None
            ],
            entity_type="itdesk_action",
            entity_id=(sig.get("subjectCaseIds") or [None])[0],
        )
        # Attach Action Center extensions — survive into the signals[] array
        envelope.update({
            "actionVerb": sig["actionVerb"],
            "severity": sig["severity"],
            "urgency": sig["urgency"],
            "subjectCaseIds": sig.get("subjectCaseIds") or [],
            "subjectPeople": sig.get("subjectPeople") or [],
            "recipient": sig.get("recipient") or "",
            "deadline": sig.get("deadline") or "",
            "doneWhenText": sig.get("doneWhenText") or "",
            "rationale": sig.get("rationale") or "",
            "ruleId": sig["ruleId"],
            "persistedRuns": sig.get("persistedRuns", 1),
            "firstSeenAt": sig.get("firstSeenAt"),
            "isNew": sig.get("isNew", True),
        })
        out.append(envelope)
    return out


def build_billing_collections_signals(payload):
    summary = payload.get("summary") or {}
    records = payload.get("records") or []
    billing_total = safe_float(summary.get("billingTotal"))
    collection_total = safe_float(summary.get("collectionTotal"))
    outstanding = safe_float(summary.get("outstanding"))
    collection_rate = safe_float(summary.get("collectionRate"))
    top_gtm = summary.get("topBillingGtm") or {}
    data_quality = summary.get("dataQuality") or {}
    quality_warnings = safe_int(data_quality.get("unknownDateRows")) + safe_int(data_quality.get("zeroAmountRows"))
    score = min(100, outstanding / max(billing_total, 1) * 70 + max(0, 60 - collection_rate) + min(20, quality_warnings))
    risk_record = next(
        (
            row for row in records
            if row.get("datasetKey") == "billing_all"
            and not row.get("isTotalRow")
            and safe_float(row.get("amount")) > 0
        ),
        None,
    )
    if score >= 25:
        links = [tab_link("Billing & Collections")]
        if risk_record:
            links.insert(0, record_link(risk_record, "Billing & Collections", f"Open {risk_record.get('primaryDimensionValue') or 'billing bucket'}"))
        return [build_signal(
            "billing-collections-outstanding",
            "Billing & Collections",
            "cash_conversion",
            clamp(score, 35, 95),
            "Billing to collections conversion needs attention",
            "Billing and collections owners",
            f"Billing is {round(billing_total, 2)} Cr; collections are {round(collection_total, 2)} Cr; collection rate is {round(collection_rate, 1)}%.",
            "Review GTM and billing-bucket drills, then assign follow-up actions for high outstanding buckets.",
            links,
            [
                {"label": "Billing", "value": f"{round(billing_total, 2)} Cr"},
                {"label": "Collections", "value": f"{round(collection_total, 2)} Cr"},
                {"label": "Outstanding", "value": f"{round(outstanding, 2)} Cr"},
                {"label": "Collection rate", "value": f"{round(collection_rate, 1)}%"},
                {"label": "Top billing GTM", "value": top_gtm.get("name", "n/a")},
            ],
            "billing_collection",
        )]
    return [healthy_signal(
        "Billing & Collections",
        "Billing and collection conversion is within the current watch range",
        f"Collection rate is {round(collection_rate, 1)}% against {round(billing_total, 2)} Cr billing.",
        [{"label": "Outstanding", "value": f"{round(outstanding, 2)} Cr"}],
    )]


def build_revops_cs_signals(payload):
    summary = payload.get("summary") or {}
    records = payload.get("records") or []
    accounts = payload.get("accounts") or []
    risks = payload.get("risks") or []
    outstanding = safe_float(summary.get("outstandingCr"))
    billing_due = safe_float(summary.get("billingDueCr"))
    collection_rate = safe_float(summary.get("collectionRate"))
    aged_leads = safe_int(summary.get("agedLeads"))
    stale_opps = safe_int(summary.get("staleOpportunities"))
    weighted_pipeline = safe_float(summary.get("weightedPipelineCr"))
    open_arr = safe_float(summary.get("openArrCr"))
    top_risk = risks[0] if risks else None
    top_account = accounts[0] if accounts else None

    signals = []
    cash_score = min(100, outstanding / 10 + billing_due / 20 + max(0, 70 - collection_rate))
    if cash_score >= 25:
        links = [tab_link("Rev Ops CS")]
        if top_risk:
            links.insert(0, record_link(top_risk, "Rev Ops CS", f"Open {top_risk.get('recordId') or top_risk.get('id')}"))
        signals.append(build_signal(
            "revops-cs-cash-risk",
            "Rev Ops CS",
            "cash_conversion",
            clamp(cash_score, 35, 96),
            "Rev Ops CS has billing and collection exposure",
            (top_risk or {}).get("owner") or "Revenue operations owners",
            f"Outstanding is {round(outstanding, 2)} Cr, billing due is {round(billing_due, 2)} Cr, and collection rate is {round(collection_rate, 1)}%.",
            "Open Rev Ops CS, filter Billing/Collection Pending, and assign follow-up for the largest outstanding accounts.",
            links,
            [
                {"label": "Outstanding", "value": f"{round(outstanding, 2)} Cr"},
                {"label": "Billing due", "value": f"{round(billing_due, 2)} Cr"},
                {"label": "Collection rate", "value": f"{round(collection_rate, 1)}%"},
                {"label": "Top risk account", "value": (top_account or {}).get("name", "n/a")},
            ],
            "revops_cash",
        ))

    pipeline_ratio = weighted_pipeline / max(open_arr, 1) * 100
    pipeline_score = min(100, stale_opps * 0.08 + max(0, 35 - pipeline_ratio) + min(25, aged_leads / 800))
    if pipeline_score >= 25:
        signals.append(build_signal(
            "revops-cs-pipeline-quality",
            "Rev Ops CS",
            "pipeline_quality",
            clamp(pipeline_score, 35, 92),
            "Rev Ops CS pipeline quality needs owner review",
            "Sales and CS owners",
            f"Open ARR is {round(open_arr, 2)} Cr, weighted pipeline is {round(weighted_pipeline, 2)} Cr, and {stale_opps} open opportunities are stale.",
            "Review stale open opportunities and aged leads before using open ARR as forecast confidence.",
            [tab_link("Rev Ops CS", "Open Rev Ops CS", statusBucket="Open")],
            [
                {"label": "Open ARR", "value": f"{round(open_arr, 2)} Cr"},
                {"label": "Weighted pipeline", "value": f"{round(weighted_pipeline, 2)} Cr"},
                {"label": "Weighted/Open", "value": f"{round(pipeline_ratio, 1)}%"},
                {"label": "Stale opportunities", "value": str(stale_opps)},
                {"label": "Aged leads", "value": str(aged_leads)},
            ],
            "revops_pipeline",
        ))

    if top_account and safe_float(top_account.get("riskScore")) >= 35:
        account_name = top_account.get("name") or "Top account"
        signals.append(build_signal(
            f"revops-cs-account-{slug(account_name)}",
            "Rev Ops CS",
            "account_risk",
            clamp(safe_float(top_account.get("riskScore")), 35, 95),
            f"{account_name} needs account-level Rev Ops review",
            "Account owners",
            f"{account_name} has {round(safe_float(top_account.get('outstandingCr')), 2)} Cr outstanding and {safe_int(top_account.get('riskItems'))} risk item(s).",
            "Open Account 360 in Rev Ops CS and combine lead, opportunity, billing, and collection actions into one owner plan.",
            [tab_link("Rev Ops CS", "Open account", account=account_name)],
            [
                {"label": "Account", "value": account_name},
                {"label": "Outstanding", "value": f"{round(safe_float(top_account.get('outstandingCr')), 2)} Cr"},
                {"label": "Open opportunities", "value": str(safe_int(top_account.get("openOpportunities")))},
                {"label": "Open leads", "value": str(safe_int(top_account.get("openLeads")))},
            ],
            "revops_account",
            account_name,
        ))

    if not signals:
        signals.append(healthy_signal(
            "Rev Ops CS",
            "Rev Ops CS has no high-risk cash or pipeline signal",
            f"{safe_int(summary.get('records'))} Rev Ops row(s) were reviewed across opportunities, leads, billing, and collections.",
            [{"label": "Open ARR", "value": f"{round(open_arr, 2)} Cr"}, {"label": "Outstanding", "value": f"{round(outstanding, 2)} Cr"}],
        ))
    return signals


def build_okr_signals(payload):
    source = payload.get("source") or {}
    scorecards = payload.get("scorecards") or []
    metrics = payload.get("metrics") or []
    source_status = source.get("status")
    if source_status == "unavailable":
        return [build_signal(
            "okr-source-unavailable",
            "OKR",
            "source_health",
            90,
            "OKR source view API is unavailable",
            "OKR platform owners",
            f"0/{source.get('viewCount', 0)} OKR source views were fetched successfully.",
            "Validate the existing OKRDashboard view API and rerun Dashboard Refresh after source recovery.",
            [tab_link("OKR")],
            [
                {"label": "Source", "value": source.get("system", "OKRDashboard")},
                {"label": "Successful views", "value": f"{source.get('successfulViews', 0)}/{source.get('viewCount', 0)}"},
                {"label": "Errors", "value": str(len(source.get("errors") or []))},
            ],
            "okr_source",
        )]

    risky_metrics = sorted(
        [
            metric for metric in metrics
            if metric.get("status") in {"red", "amber", "watch"}
        ],
        key=lambda metric: (
            {"red": 0, "amber": 1, "watch": 2}.get(metric.get("status"), 3),
            -safe_float(metric.get("weight")),
        ),
    )
    if risky_metrics:
        metric = risky_metrics[0]
        score = 80 if metric.get("status") == "red" else 62 if metric.get("status") == "amber" else 45
        if source_status == "partial":
            score += 8
        metric_id = metric.get("id")
        return [build_signal(
            f"okr-metric-{slug(metric_id)}",
            "OKR",
            "scorecard_gap",
            clamp(score, 35, 95),
            f"{metric.get('role')} {metric.get('fy')} OKR gap: {metric.get('name')}",
            f"{metric.get('role')} OKR owners",
            f"{metric.get('name')} is {metric.get('status')} with {metric.get('attainment', 'n/a')}% attainment and {metric.get('earnedWeight')}/{metric.get('weight')} weight earned.",
            "Open the OKR tab, drill the source rows for this metric, and publish the owner action for the largest gap.",
            [tab_link("OKR", "Open OKR metric", role=metric.get("role"), fy=metric.get("fy"), metric=metric_id)],
            [
                {"label": "Role/FY", "value": f"{metric.get('role')} {metric.get('fy')}"},
                {"label": "Metric", "value": metric.get("name")},
                {"label": "Status", "value": metric.get("status")},
                {"label": "Attainment", "value": f"{metric.get('attainment', 'n/a')}%"},
                {"label": "Source view", "value": metric.get("sourceView", "n/a")},
            ],
            "okr_metric",
            metric_id,
        )]

    best = max(scorecards, key=lambda card: safe_float(card.get("score")), default=None)
    return [healthy_signal(
        "OKR",
        "OKR scorecards have no red or amber metric signal",
        f"{len(scorecards)} scorecard(s) and {len(metrics)} metric(s) were generated from the existing OKR source views.",
        [
            {"label": "Best scorecard", "value": f"{(best or {}).get('role', 'n/a')} {(best or {}).get('fy', '')}".strip()},
            {"label": "Best score", "value": str((best or {}).get("score", "n/a"))},
        ],
    )]


def build_governance_signals(governance):
    summary = governance.get("summary") or {}
    items = (governance.get("operationalIndex") or {}).get("items") or []
    critical = safe_int(summary.get("criticalRiskCount"))
    data_warnings = safe_int(summary.get("dataTrustWarnings"))
    data_failures = safe_int(summary.get("dataTrustFailures"))
    top_item = items[0] if items else None
    score = critical * 5 + data_warnings * 10 + data_failures * 20
    if top_item:
        score = max(score, safe_int(top_item.get("riskScore")))
    if score >= 25:
        links = []
        if top_item:
            links.append({"label": f"Open {top_item.get('source')} {top_item.get('itemId')}", "url": normalize_dashboard_url(top_item.get("dashboardUrl")) or top_item.get("sourceUrl")})
        links.append(tab_link("Governance"))
        return [build_signal(
            "governance-risk-ledger",
            "Governance",
            "metric_governance",
            clamp(score, 35, 100),
            "Governance risk ledger has critical operational items",
            "BizTech Operations",
            f"{critical} critical risk item(s), {data_warnings} data warning(s), {data_failures} data failure(s).",
            "Use the governance index to close or explicitly defer the highest risk operational items.",
            links,
            [
                {"label": "Critical risks", "value": str(critical)},
                {"label": "Data warnings", "value": str(data_warnings)},
                {"label": "Data failures", "value": str(data_failures)},
                {"label": "Link coverage", "value": f"{summary.get('sourceLinkCoverage', 'n/a')}%"},
            ],
            "governance_index",
        )]
    return [healthy_signal(
        "Governance",
        "Governance layer has no critical data-trust signal",
        f"{summary.get('metricCount', 0)} metrics are documented with {summary.get('sourceLinkCoverage', 'n/a')}% source-link coverage.",
        [{"label": "Metrics", "value": str(summary.get("metricCount", 0))}],
    )]


def build_azure_quality_signals(core):
    quality = core.get("azureQuality") or {}
    by_assignee = quality.get("byAssignee") or {}
    score = safe_int(quality.get("score"), 100)
    worst = None
    if by_assignee:
        worst = sorted(by_assignee.items(), key=lambda kv: safe_int(kv[1].get("score"), 100))[0]
    risk_score = max(25, 100 - score)
    if worst and safe_int(worst[1].get("score"), 100) < 75:
        risk_score = max(risk_score, 100 - safe_int(worst[1].get("score"), 100) + 25)
    if risk_score >= 35:
        owner = worst[0] if worst else "Azure quality owners"
        owner_score = safe_int((worst or [None, {}])[1].get("score"), score)
        return [build_signal(
            "azure-quality-hygiene",
            "Azure Quality",
            "quality_score",
            clamp(risk_score, 35, 95),
            "Azure Quality score requires hygiene action",
            owner,
            f"Overall Azure Quality score is {score}; lowest assignee score is {owner_score}.",
            "Open Azure Quality, drill into the lowest score owner, and fix missing proof, descriptions, sprint and parentage issues.",
            [tab_link("Azure Quality", "Open Azure Quality", owner=owner)],
            [
                {"label": "Overall score", "value": str(score)},
                {"label": "Lowest owner", "value": owner},
                {"label": "Lowest score", "value": str(owner_score)},
            ],
            "azure_quality",
        )]
    return [healthy_signal(
        "Azure Quality",
        "Azure Quality has no low-score owner signal",
        f"Overall Azure Quality score is {score}.",
        [{"label": "Score", "value": str(score)}],
    )]


def build_mpr_signals(mpr_payload):
    rows = mpr_payload.get("query_result", {}).get("data", {}).get("rows", [])
    if not rows:
        return [healthy_signal("MPR", "MPR payload is present without open breach detail", "No MPR row was available for predictive breach analysis.")]
    mpr_data = rows[0].get("mpr_data") or {}
    kpi = mpr_data.get("kpi") or {}
    open_cases = mpr_data.get("all_open_cases") or []
    predicted = safe_int(kpi.get("predicted_breaches"))
    aging_gt_7d = safe_int(kpi.get("aging_gt_7d"))
    if predicted > 0 and open_cases:
        top = sorted(open_cases, key=lambda row: safe_float(row.get("elapsed_biz_hours") or row.get("new_hours")), reverse=True)[:5]
        links = [tab_link("MPR")]
        signals = [build_signal(
            signal_id="mpr-predicted-breaches",
            area="MPR",
            category="aging_work",
            score=clamp(45 + predicted * 2 + aging_gt_7d, 50, 95),
            title=f"{predicted} MPR cases are predicted to breach",
            owner="PORTFOLIO_REDACTED",
            why=f"{aging_gt_7d} open cases are older than 7 days and {predicted} are predicted breaches.",
            action_hint="Triage the oldest open cases first and rebalance ownership for cases in New or Awaiting Input.",
            links=links,
            evidence=[
                {"label": "Open", "value": str(kpi.get("total_open", 0))},
                {"label": "Aging >7d", "value": str(aging_gt_7d)},
                {"label": "Predicted breaches", "value": str(predicted)},
                {"label": "Oldest cases", "value": ", ".join(str(case.get("caseid")) for case in top if case.get("caseid"))},
            ],
            entity_type="mpr_group",
        )]
        return signals
    return [healthy_signal(
        "MPR",
        "MPR has no predicted breach signal in this refresh",
        f"{safe_int(kpi.get('total_open'))} open cases and {predicted} predicted breach(es).",
        [{"label": "Open", "value": str(kpi.get("total_open", 0))}, {"label": "Predicted breaches", "value": str(predicted)}],
    )]


def build_signals(core, pipelines, mpr_payload, headcount, itsm, oeg, cloud, incidents_requirements, billing_collections, revops_cs, okr, governance, itdesk_data=None, itdesk_history=None):
    signals = []
    signals.extend(build_command_signals(core))
    signals.extend(build_roadmap_signals(core))
    signals.extend(build_pr_signals(core))
    signals.extend(build_data_sanity_signals(core))
    signals.extend(build_pipeline_signals(pipelines))
    signals.extend(build_operatives_signals(core))
    signals.extend(build_headcount_signals(headcount))
    signals.extend(build_itsm_signals(itsm))
    signals.extend(build_operational_signals(oeg, "OEG"))
    signals.extend(build_operational_signals(cloud, "Cloud"))
    signals.extend(build_incident_requirement_signals(incidents_requirements))
    signals.extend(build_itdesk_signals(itdesk_data, itdesk_history))
    signals.extend(build_billing_collections_signals(billing_collections))
    signals.extend(build_revops_cs_signals(revops_cs))
    signals.extend(build_okr_signals(okr))
    signals.extend(build_governance_signals(governance))
    signals.extend(build_azure_quality_signals(core))
    signals.extend(build_mpr_signals(mpr_payload))
    return rank_signals_balanced(signals, SIGNALS_PER_AREA, max(RECOMMENDATION_LIMIT * 2, 80))


def rank_signals_balanced(signals, per_area=4, limit=80):
    groups = defaultdict(list)
    for signal in sorted(signals, key=lambda item: (item["score"], len(item.get("links", []))), reverse=True):
        groups[signal["area"]].append(signal)

    ranked = []
    seen = set()
    for area in AREA_TAB:
        if groups.get(area):
            signal = groups[area][0]
            ranked.append(signal)
            seen.add(signal["id"])
    for index in range(1, max(per_area, 1)):
        for area in AREA_TAB:
            if len(groups.get(area, [])) > index:
                signal = groups[area][index]
                if signal["id"] not in seen:
                    ranked.append(signal)
                    seen.add(signal["id"])
    for signal in sorted(signals, key=lambda item: item["score"], reverse=True):
        if signal["id"] not in seen:
            ranked.append(signal)
            seen.add(signal["id"])
        if len(ranked) >= limit:
            break
    return ranked[:limit]


def impact_for_signal(signal):
    area = signal.get("area")
    if area == "Command":
        return "Keeps the command center focused on the highest priority operational queue."
    if area == "Roadmap":
        return "Improves sprint predictability and reduces unmanaged scope movement."
    if area == "Pull Requests" and signal.get("category") == "release_readiness":
        return "Reduces release drift by resolving approved or aging code changes."
    if area == "Pull Requests":
        return "Reduces code review bottleneck risk and keeps branch promotion moving."
    if area == "Data Sanity":
        return "Improves sprint hygiene, ownership clarity, and downstream reporting reliability."
    if area == "Pipelines":
        return "Protects deployment confidence and reduces wasted reruns."
    if area == "Operatives":
        return "Improves WIP balance and makes resource-level execution risk visible."
    if area == "Headcount":
        return "Improves trust in user, employee, and PS-master reconciliation."
    if area in {"ITSM Analytics", "IT Desk", "OEG", "Cloud", "Incidents", "Requirements"}:
        return "Reduces aging queue exposure through owner-level action and drillable case focus."
    if area == "Billing & Collections":
        return "Improves cash visibility by focusing attention on billing readiness, collections, and outstanding exposure."
    if area == "Rev Ops CS":
        return "Connects pipeline quality, lead aging, billing, and collections into one customer-success action view."
    if area == "OKR":
        return "Improves strategy execution focus by connecting scorecard gaps to accountable metric owners and source views."
    if area == "Governance":
        return "Improves metric trust, documentation, and executive risk traceability."
    if area == "Azure Quality":
        return "Improves Azure Boards hygiene and downstream quality scoring."
    if area == "MPR":
        return "Reduces SLA breach exposure and aging operational backlog."
    return "Improves operational focus on the highest-risk dashboard signal."


def deterministic_recommendation(signal, rank):
    return {
        "id": f"rec-{signal['id']}",
        "priority": signal["priority"],
        "area": signal["area"],
        "category": signal["category"],
        "title": signal["title"],
        "why": signal["why"],
        "action": signal["actionHint"],
        "owner": signal["owner"],
        "dueBy": "Today" if signal["priority"] in {"critical", "high"} else "This week",
        "impact": impact_for_signal(signal),
        "confidence": 0.86 if signal["priority"] in {"critical", "high"} else 0.78,
        "evidence": signal["evidence"],
        "links": signal["links"],
        "sourceSignalIds": [signal["id"]],
        "explainability": {
            "method": "deterministic_signal_rank",
            "score": signal.get("score"),
            "sourceSignals": [signal["id"]],
            "guardrails": [
                "Uses only dashboard source signals.",
                "Links and evidence are attached from trusted deterministic data.",
                "No external facts are invented.",
            ],
            "reasoning": f"{signal['area']} signal scored {signal.get('score')} because {signal.get('why')}.",
        },
        "approval": {"state": "pending", "allowedStates": ["approved", "dismissed", "snoozed"]},
        "feedback": {"enabled": True, "storage": "browser_local"},
        "rank": rank,
    }


def deterministic_recommendations(signals, limit=RECOMMENDATION_LIMIT):
    return [deterministic_recommendation(signal, index + 1) for index, signal in enumerate(signals[:limit])]


def build_llm_prompt(signals):
    compact_signals = []
    for signal in signals[:LLM_SIGNAL_LIMIT]:
        compact_signals.append({
            "id": signal["id"],
            "area": signal["area"],
            "priority": signal["priority"],
            "score": signal["score"],
            "title": signal["title"],
            "owner": signal["owner"],
            "why": signal["why"],
            "actionHint": signal["actionHint"],
            "evidence": signal["evidence"][:5],
            "links": signal["links"][:3],
        })

    return [
        {
            "role": "system",
            "content": (
                "You are Hermes, the operational recommendation engine for the BizTech dashboard. "
                "Use only the supplied JSON signals. Do not invent IDs, owners, links, statuses, dates, counts, or systems. "
                "Choose the highest-value source signals across different dashboard tabs and write concise action text. "
                "Do not return evidence or links; the application attaches trusted evidence and drill links after validation. "
                "Return compact valid JSON only with this shape: "
                "{\"recommendations\":[{\"sourceSignalId\":\"signal-id\",\"title\":\"string\","
                "\"why\":\"string\",\"action\":\"string\",\"dueBy\":\"Today|This week\","
                "\"impact\":\"string\",\"confidence\":0.0}]}. "
                f"Return up to {LLM_RECOMMENDATION_LIMIT} recommendations. Keep title, why, action, and impact under 160 characters each."
            ),
        },
        {
            "role": "user",
            "content": json.dumps({"signals": compact_signals}, ensure_ascii=False, separators=(",", ":")),
        },
    ]


def api_key_available():
    key = (CEREBRAS_API_KEY or "").strip()
    return bool(key) and not key.startswith("$(") and " " not in key


def extract_json_object(text):
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.I).strip()
        text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start:end + 1])
    raise ValueError("No JSON object found in LLM response")


def llm_payload(signals):
    return {
        "model": CEREBRAS_MODEL,
        "messages": build_llm_prompt(signals),
        "max_tokens": CEREBRAS_MAX_TOKENS,
        "temperature": CEREBRAS_TEMPERATURE,
        "top_p": CEREBRAS_TOP_P,
        "stream": False,
    }


def parse_chat_response(response):
    payload = response.json()
    choice = (payload.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = message.get("content") or choice.get("text") or ""
    return extract_json_object(content)


def call_llm(signals):
    if not api_key_available():
        return None, "missing_api_key"
    if not signals:
        return None, "no_signals"

    headers = {
        "Authorization": f"Bearer {CEREBRAS_API_KEY.strip()}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    timeout = (CEREBRAS_CONNECT_TIMEOUT_SECONDS, CEREBRAS_READ_TIMEOUT_SECONDS)
    last_error = None
    for attempt in range(CEREBRAS_MAX_RETRIES + 1):
        if CEREBRAS_MIN_CALL_INTERVAL_SECONDS > 0:
            time.sleep(CEREBRAS_MIN_CALL_INTERVAL_SECONDS)
        try:
            response = requests.post(CEREBRAS_URL, headers=headers, json=llm_payload(signals), timeout=timeout)
            if response.status_code == 429 and attempt < CEREBRAS_MAX_RETRIES:
                time.sleep(CEREBRAS_RETRY_SLEEP_SECONDS * (attempt + 1))
                continue
            response.raise_for_status()
            return parse_chat_response(response), "ok_json"
        except Exception as exc:
            last_error = exc
            if attempt < CEREBRAS_MAX_RETRIES:
                time.sleep(CEREBRAS_RETRY_SLEEP_SECONDS * (attempt + 1))
                continue
    raise RuntimeError(f"cerebras_failed={type(last_error).__name__}: {str(last_error)[:180]}") from last_error


def valid_link(url):
    url = str(url or "")
    return (
        url.startswith(f"https://example.invalid}/{PROJECT}/")
        or url.startswith("https://example.invalid")
        or url.startswith("https://example.invalid")
    )


def normalize_evidence(evidence):
    out = []
    for item in evidence or []:
        if isinstance(item, dict):
            label = short_text(item.get("label"), 60)
            value = short_text(item.get("value"), 160)
        else:
            label = "Evidence"
            value = short_text(item, 160)
        if label and value:
            out.append({"label": label, "value": value})
    return out[:8]


def validate_recommendations(candidate, signals):
    signal_by_id = {signal["id"]: signal for signal in signals}
    valid = []
    errors = []
    raw_recs = candidate.get("recommendations", []) if isinstance(candidate, dict) else []
    if not isinstance(raw_recs, list):
        return [], ["recommendations_not_list"]

    for idx, rec in enumerate(raw_recs, 1):
        if not isinstance(rec, dict):
            errors.append(f"rec_{idx}_not_object")
            continue
        raw_source_ids = rec.get("sourceSignalIds", [])
        if not raw_source_ids and rec.get("sourceSignalId"):
            raw_source_ids = [rec.get("sourceSignalId")]
        if isinstance(raw_source_ids, str):
            raw_source_ids = [raw_source_ids]
        source_ids = [source_id for source_id in raw_source_ids if source_id in signal_by_id]
        if not source_ids:
            errors.append(f"rec_{idx}_missing_valid_source")
            continue
        source = signal_by_id[source_ids[0]]
        priority = str(rec.get("priority") or source["priority"]).lower()
        if priority not in VALID_PRIORITIES:
            priority = source["priority"]
        area = rec.get("area") if rec.get("area") in VALID_AREAS else source["area"]
        links = []
        for link in rec.get("links") or []:
            if isinstance(link, dict) and valid_link(link.get("url")):
                links.append({"label": short_text(link.get("label") or "Open item", 80), "url": normalize_dashboard_url(link["url"])})
        if not links:
            links = source.get("links", [])
        links = [{"label": link.get("label") or "Open", "url": normalize_dashboard_url(link.get("url"))} for link in links if valid_link(link.get("url"))][:6]
        if not links:
            errors.append(f"rec_{idx}_missing_valid_links")
            continue
        evidence = normalize_evidence(rec.get("evidence")) or source.get("evidence", [])
        if not evidence:
            errors.append(f"rec_{idx}_missing_evidence")
            continue
        try:
            confidence = float(rec.get("confidence", 0.75))
        except (TypeError, ValueError):
            confidence = 0.75
        valid.append({
            "id": short_text(rec.get("id") or f"rec-{source['id']}", 100),
            "priority": priority,
            "area": area,
            "category": short_text(rec.get("category") or source["category"], 80),
            "title": short_text(rec.get("title") or source["title"], 180),
            "why": short_text(rec.get("why") or source["why"], 280),
            "action": short_text(rec.get("action") or source["actionHint"], 300),
            "owner": short_text(rec.get("owner") or source["owner"], 80),
            "dueBy": short_text(rec.get("dueBy") or "Today", 80),
            "impact": short_text(rec.get("impact") or impact_for_signal(source), 240),
            "confidence": round(clamp(confidence, 0.0, 1.0), 2),
            "evidence": evidence[:8],
            "links": links,
            "sourceSignalIds": source_ids[:4],
            "rank": len(valid) + 1,
        })
    return valid[:LLM_RECOMMENDATION_LIMIT], errors


def enrich_recommendations(recommendations, signals, mode):
    signal_by_id = {signal["id"]: signal for signal in signals}
    enriched = []
    for rank, rec in enumerate(recommendations, 1):
        source_ids = [source_id for source_id in rec.get("sourceSignalIds", []) if source_id in signal_by_id]
        source = signal_by_id[source_ids[0]] if source_ids else None
        next_rec = dict(rec)
        next_rec["rank"] = rank
        next_rec.setdefault("approval", {"state": "pending", "allowedStates": ["approved", "dismissed", "snoozed"]})
        next_rec.setdefault("feedback", {"enabled": True, "storage": "browser_local"})
        next_rec["explainability"] = {
            "method": "REDACTED_OPAQUE_VALUE" if mode == "llm" else "deterministic_signal_rank",
            "score": source.get("score") if source else None,
            "sourceSignals": source_ids,
            "sourceCategories": [signal_by_id[source_id].get("category") for source_id in source_ids],
            "guardrails": [
                "Recommendation text is grounded only in supplied dashboard signals.",
                "Evidence and links are restored from deterministic source data after validation.",
                "LLM output is rejected if it references unknown signal IDs or unsupported links.",
            ],
            "reasoning": (
                f"Ranked from {source.get('area')} signal score {source.get('score')}: {source.get('why')}"
                if source else "No matching source signal found; retained deterministic recommendation text only."
            ),
        }
        enriched.append(next_rec)
    return enriched


def merge_llm_and_deterministic(llm_recs, deterministic_recs):
    merged = []
    used_signals = set()
    for rec in llm_recs:
        merged.append(rec)
        used_signals.update(rec.get("sourceSignalIds") or [])
    for rec in deterministic_recs:
        source_ids = set(rec.get("sourceSignalIds") or [])
        if source_ids and source_ids.issubset(used_signals):
            continue
        merged.append(rec)
        used_signals.update(source_ids)
    return [{**rec, "rank": index + 1} for index, rec in enumerate(merged[:RECOMMENDATION_LIMIT])]


def build_hermes_learning(signals, recommendations, mode, llm_status, llm_errors, meta):
    signals_by_area = Counter(signal["area"] for signal in signals)
    recs_by_area = Counter(rec["area"] for rec in recommendations)
    category_counts = Counter(signal["category"] for signal in signals)
    missing_areas = [area for area in AREA_TAB if signals_by_area.get(area, 0) == 0]
    top_by_area = {}
    for signal in signals:
        if signal["area"] not in top_by_area or signal["score"] > top_by_area[signal["area"]]["score"]:
            top_by_area[signal["area"]] = signal

    learnings = []
    for area, signal in top_by_area.items():
        learnings.append({
            "id": f"learn-{slug(signal['id'])}",
            "area": area,
            "priority": signal["priority"],
            "category": signal["category"],
            "title": signal["title"],
            "observation": signal["why"],
            "recommendedAction": signal["actionHint"],
            "score": signal["score"],
            "owner": signal["owner"],
            "evidence": signal["evidence"][:5],
            "links": signal["links"][:3],
            "sourceSignalIds": [signal["id"]],
        })
    learnings.sort(key=lambda row: row["score"], reverse=True)

    risks = [
        {
            "area": signal["area"],
            "title": signal["title"],
            "priority": signal["priority"],
            "score": signal["score"],
            "owner": signal["owner"],
            "links": signal["links"][:2],
        }
        for signal in sorted(signals, key=lambda row: row["score"], reverse=True)
        if signal["score"] >= 60
    ][:12]

    follow_ups = [
        {
            "id": rec["id"],
            "area": rec["area"],
            "priority": rec["priority"],
            "title": rec["title"],
            "owner": rec["owner"],
            "action": rec["action"],
            "links": rec["links"][:2],
        }
        for rec in recommendations
        if rec.get("priority") in {"critical", "high"}
    ][:16]

    return {
        "schemaVersion": 1,
        "generatedAt": now_iso(),
        "cadence": "Every 2 hours through Dashboard Refresh pipeline 486",
        "provider": "cerebras",
        "model": CEREBRAS_MODEL if api_key_available() else None,
        "mode": mode,
        "llmStatus": llm_status,
        "coverage": {
            "areasExpected": list(AREA_TAB.keys()),
            "areasWithSignals": sorted(signals_by_area),
            "missingAreas": missing_areas,
            "signalsByArea": dict(sorted(signals_by_area.items())),
            "recommendationsByArea": dict(sorted(recs_by_area.items())),
            "categoryCounts": dict(category_counts.most_common()),
        },
        "summary": {
            "signalCount": len(signals),
            "recommendationCount": len(recommendations),
            "highPriorityFollowUps": len(follow_ups),
            "riskCount": len(risks),
            "sourceGeneratedAt": meta.get("generatedAt") or meta.get("fetchedAt") or meta.get("timestamp"),
        },
        "learnings": learnings[:24],
        "risks": risks,
        "followUps": follow_ups,
        "guardrails": [
            "Hermes learns from dashboard JSON only.",
            "Cerebras can improve wording but cannot add untrusted IDs, links, owners, or evidence.",
            "A deterministic fallback is published if the LLM call fails or times out.",
        ],
        "errors": llm_errors[:12],
    }


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    core = load_core_with_chunks()
    pipelines = load_json("pipelines.json", [])
    mpr_payload = load_json("mpr_data.json", {})
    headcount = load_json("headcount-data.json", {})
    itsm = load_json("itsm-data.json", {})
    oeg = load_json("oeg-data.json", {})
    cloud = load_json("cloud-data.json", {})
    incidents_requirements = load_json("incidents-requirements-data.json", {})
    itdesk_data = load_json("it-desk-data.json", {})
    itdesk_history = load_json("it-desk-history.json", {})
    billing_collections = load_json("billing-collections-data.json", {})
    revops_cs = load_json("revops-cs-data.json", {})
    okr = load_json("okr-data.json", {})
    governance = load_json("governance-data.json", {})
    meta = load_json("meta.json", {})

    signals = build_signals(
        core, pipelines, mpr_payload, headcount, itsm, oeg, cloud,
        incidents_requirements, billing_collections, revops_cs, okr, governance,
        itdesk_data=itdesk_data, itdesk_history=itdesk_history,
    )

    llm_status = "not_called"
    llm_errors = []
    llm_recommendations = []
    mode = "deterministic"

    try:
        model_payload, llm_status = call_llm(signals)
        if model_payload:
            llm_recommendations, llm_errors = validate_recommendations(model_payload, signals)
            if llm_recommendations:
                mode = "llm"
            else:
                mode = "deterministic_fallback"
    except Exception as exc:
        llm_status = "error"
        llm_errors.append(f"{type(exc).__name__}: {str(exc)[:180]}")
        mode = "deterministic_fallback"

    deterministic = deterministic_recommendations(signals)
    if llm_recommendations:
        recommendations = merge_llm_and_deterministic(
            enrich_recommendations(llm_recommendations, signals, "llm"),
            enrich_recommendations(deterministic, signals, "deterministic"),
        )
    else:
        recommendations = enrich_recommendations(deterministic, signals, mode)

    payload = {
        "generatedAt": now_iso(),
        "mode": mode,
        "provider": "cerebras",
        "model": CEREBRAS_MODEL if api_key_available() else None,
        "source": {
            "coreFetchedAt": core.get("fetchedAt") or meta.get("fetchedAt"),
            "signalCount": len(signals),
            "recommendationCount": len(recommendations),
            "areasExpected": list(AREA_TAB.keys()),
            "areasCovered": sorted({rec["area"] for rec in recommendations}),
            "llmStatus": llm_status,
            "validationErrors": llm_errors[:12],
        },
        "recommendations": recommendations,
        "signals": signals[: min(len(signals), 80)],
    }
    hermes = build_hermes_learning(signals, recommendations, mode, llm_status, llm_errors, meta)

    write_json(RECOMMENDATIONS_PATH, payload)
    write_json(HERMES_PATH, hermes)
    print(f"Mode:{mode} Provider:cerebras Signals:{len(signals)} Recommendations:{len(recommendations)} LLM:{llm_status}")
    if llm_errors:
        print("LLMErrors:" + "; ".join(llm_errors[:3]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
