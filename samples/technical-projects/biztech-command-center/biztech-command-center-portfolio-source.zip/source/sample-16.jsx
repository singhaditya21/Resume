// RMG Governance · HEADCOUNT MIX — target vs actual headcount by
// engagement classification.  Pure shell: all rendering + drill logic
// lives in RMGPageShell.
import React from 'react'
import { useRMGData, RMGPageShell } from '../../sections/rmg/RMGShared'

export default function RMGHeadcountMixPage() {
    const { data, loading, error, status } = useRMGData()
    return <RMGPageShell sectionKey="rmg_mix" data={data} loading={loading} error={error} status={status} />
}
