import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import '../styles.css'
// Atomic Design System — self-hosted Poppins.  Loads ~31KB across 4 weights
// from /fonts/Poppins-{400,500,600,700}.woff2 with font-display: swap, so
// first paint isn't blocked.  No page yet uses Poppins (Phase 0 only lays
// the foundation); components migrate to <H1>/<Body>/<Caption>/etc. as each
// page is redesigned.
import './design/fontFace.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
