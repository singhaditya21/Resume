export default function HBar({ label, value, max, color, suffix = '' }) {
    const pct = max > 0 ? Math.round((value / max) * 100) : 0
    return (
        <div className="cc-hbar-row">
            <span className="cc-hbar-label">{label}</span>
            <div className="cc-hbar-track">
                <div className="cc-hbar-fill" style={{ width: `${pct}%`, background: color }}></div>
            </div>
            <span className="cc-hbar-val">{value}{suffix}</span>
        </div>
    )
}
