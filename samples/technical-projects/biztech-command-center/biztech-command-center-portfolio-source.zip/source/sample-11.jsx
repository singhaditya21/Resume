// RMG Governance · EMPLOYEE × PROJECT — monthly allocation matrix.
import React from 'react'
import { useRMGData, RMGPageShell } from '../../sections/rmg/RMGShared'

export default function RMGEmployeeProjectPage() {
    const { data, loading, error, status } = useRMGData()
    return <RMGPageShell sectionKey="rmg_matrix" data={data} loading={loading} error={error} status={status} />
}
