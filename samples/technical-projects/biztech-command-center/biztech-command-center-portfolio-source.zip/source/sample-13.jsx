// RMG Governance · BILLABILITY — billable %, allocation distribution,
// role split, metadata gaps.
import React from 'react'
import { useRMGData, RMGPageShell } from '../../sections/rmg/RMGShared'

export default function RMGBillabilityPage() {
    const { data, loading, error, status } = useRMGData()
    return <RMGPageShell sectionKey="rmg_billability" data={data} loading={loading} error={error} status={status} />
}
