/**
 * useLLM — Thin wrapper around the local llama-server OpenAI-compatible API.
 *
 * Provides:
 *   - `askLLM(userMessage, systemPrompt)` → returns AI response text
 *   - `llmAvailable` → boolean, true if server is reachable
 *   - `llmLoading` → boolean, true while waiting for response
 *
 * Falls back gracefully when llama-server is not running.
 */
import { useState, useCallback, useEffect, useRef } from 'react'

const LLM_URL = 'http://localhost:8081/v1/chat/completions'
const HEALTH_URL = 'http://localhost:8081/health'
const TIMEOUT_MS = 30000    // max wait for LLM response
const HEALTH_INTERVAL = 15000 // check health every 15s

export function useLLM() {
    const [llmAvailable, setLlmAvailable] = useState(false)
    const [llmLoading, setLlmLoading] = useState(false)
    const abortRef = useRef(null)

    // ── Health check ─────────────────────────────────────────
    useEffect(() => {
        const checkHealth = async () => {
            try {
                const r = await fetch(HEALTH_URL, { signal: AbortSignal.timeout(3000) })
                setLlmAvailable(r.ok)
            } catch {
                setLlmAvailable(false)
            }
        }
        checkHealth()
        const id = setInterval(checkHealth, HEALTH_INTERVAL)
        return () => clearInterval(id)
    }, [])

    // ── Ask the LLM ──────────────────────────────────────────
    const askLLM = useCallback(async (userMessage, systemPrompt) => {
        if (abortRef.current) abortRef.current.abort()
        const controller = new AbortController()
        abortRef.current = controller

        setLlmLoading(true)
        try {
            const res = await fetch(LLM_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                signal: controller.signal,
                body: JSON.stringify({
                    model: 'phi-3',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userMessage },
                    ],
                    max_tokens: 512,
                    temperature: 0.3,
                    top_p: 0.9,
                    stop: ['\n\n\n'],
                }),
            })

            if (!res.ok) throw new Error(`LLM error: ${res.status}`)

            const data = await res.json()
            const text = data.choices?.[0]?.message?.content?.trim()
            if (!text) throw new Error('Empty LLM response')

            setLlmAvailable(true)
            return text
        } catch (err) {
            if (err.name === 'AbortError') return null
            console.warn('LLM request failed:', err.message)
            setLlmAvailable(false)
            return null // caller will use rule-based fallback
        } finally {
            setLlmLoading(false)
            abortRef.current = null
        }
    }, [])

    // ── Timeout wrapper ──────────────────────────────────────
    const askWithTimeout = useCallback(async (userMessage, systemPrompt) => {
        const timeoutPromise = new Promise(resolve =>
            setTimeout(() => resolve(null), TIMEOUT_MS)
        )
        return Promise.race([
            askLLM(userMessage, systemPrompt),
            timeoutPromise,
        ])
    }, [askLLM])

    return { askLLM: askWithTimeout, llmAvailable, llmLoading }
}
