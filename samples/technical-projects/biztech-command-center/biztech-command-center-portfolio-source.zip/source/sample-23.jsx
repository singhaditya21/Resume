export default function KPICard({ label, value, sub, def, color, borderColor, onClick, clickable }) {
    return (
        <div
            className={`cc-kpi ${clickable ? 'cursor-pointer hover:border-accent hover:bg-slate-800' : ''}`}
            style={{
                ...(borderColor ? { borderLeft: `3px solid ${borderColor}` } : {}),
                ...(clickable ? { cursor: 'pointer', transition: 'all 0.2s', ':hover': { borderColor: 'var(--accent)' } } : {})
            }}
            onClick={onClick}
        >
            <div className="cc-kpi-label">{label}</div>
            <div className="cc-kpi-value" style={color ? { color } : {}}>{value}</div>
            <div className="cc-kpi-sub">{sub}</div>
            {def && <div className="cc-kpi-def">{def}</div>}
        </div>
    )
}
