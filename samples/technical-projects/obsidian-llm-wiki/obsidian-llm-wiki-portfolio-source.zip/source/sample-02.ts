import fs from "node:fs/promises";
import { ConfidentialClientApplication } from "@azure/msal-node";
import { AppConfig, SharePointItem, SharePointSyncResult, WikiDocument } from "./types";
import { hasSharePointCredentials } from "./config";
import { extractDocumentText, isExtractableFile } from "./document-extract";
import { saveWikiDocument, slugify } from "./vault";

const GRAPH_SCOPE = ["https://graph.microsoft.com/.default"];
const DEFAULT_MAX_ITEMS = 500;
const DEFAULT_MAX_FILE_BYTES = 25 * 1024 * 1024;
const MAX_NOTES = 80;

export function driveRelativePath(folderPath: string): string {
  return folderPath
    .replace(/^\/+/, "")
    .replace(/^Shared Documents\/?/i, "")
    .replace(/^Documents\/?/i, "");
}

function configuredMaxItems(): number {
  const value = Number(process.env.SHAREPOINT_SYNC_MAX_ITEMS || DEFAULT_MAX_ITEMS);
  return Number.isFinite(value) && value > 0 ? value : DEFAULT_MAX_ITEMS;
}

function configuredMaxFileBytes(): number {
  const value = Number(process.env.SHAREPOINT_MAX_FILE_BYTES || DEFAULT_MAX_FILE_BYTES);
  return Number.isFinite(value) && value > 0 ? value : DEFAULT_MAX_FILE_BYTES;
}

function graphPathForChildren(driveId: string, relativePath: string): string {
  if (!relativePath) return `/drives/${driveId}/root/children`;
  return `/drives/${driveId}/root:/${encodeURI(relativePath)}:/children`;
}

function childRelativePath(parentPath: string, name: string): string {
  return parentPath ? `${parentPath}/${name}` : name;
}

function addNote(notes: string[], note: string): void {
  if (notes.length < MAX_NOTES) {
    notes.push(note);
  } else if (notes.length === MAX_NOTES) {
    notes.push("Further notes omitted to keep the sync response compact.");
  }
}

export class SharePointSyncService {
  private accessToken?: string;

  constructor(private readonly config: AppConfig) {}

  async syncApprovedFolder(): Promise<SharePointSyncResult> {
    if (!hasSharePointCredentials(this.config)) {
      await this.writeMockWelcome();
      return {
        scanned: 1,
        imported: 1,
        skipped: 0,
        folderPath: this.config.sharePoint.folderPath,
        mode: "mock",
        notes: ["SharePoint credentials are not configured; wrote a local placeholder document."]
      };
    }

    const items = await this.listFolderItems();
    let imported = 0;
    let skipped = 0;
    const notes: string[] = [];
    if (items.length >= configuredMaxItems()) {
      addNote(notes, `Reached SHAREPOINT_SYNC_MAX_ITEMS=${configuredMaxItems()}; rerun with a higher value for a fuller library scan.`);
    }

    for (const item of items) {
      if (!item.downloadUrl || !isExtractableFile(item.name)) {
        skipped += 1;
        addNote(notes, `Skipped ${item.relativePath || item.name}; unsupported file type for extraction.`);
        continue;
      }

      if (item.size && item.size > configuredMaxFileBytes()) {
        skipped += 1;
        addNote(notes, `Skipped ${item.relativePath || item.name}; file exceeds SHAREPOINT_MAX_FILE_BYTES.`);
        continue;
      }

      let extracted;
      try {
        const buffer = await this.downloadBuffer(item.downloadUrl);
        extracted = await extractDocumentText(item.name, buffer);
      } catch (error) {
        skipped += 1;
        addNote(
          notes,
          `Could not extract ${item.relativePath || item.name}: ${error instanceof Error ? error.message : "unknown error"}`
        );
        continue;
      }

      if (!extracted.body.trim()) {
        skipped += 1;
        addNote(notes, `Skipped ${item.relativePath || item.name}; extraction returned no text.`);
        continue;
      }

      const document: WikiDocument = {
        slug: slugify(item.relativePath.replace(/\.[^.]+$/, "")),
        title: item.name.replace(/\.[^.]+$/, ""),
        source: "sharepoint",
        sourceUrl: item.webUrl,
        sourceId: item.id,
        modifiedAt: item.lastModifiedDateTime,
        tags: [
          "sharepoint",
          extracted.kind,
          ...item.relativePath.split("/").slice(0, -1).map(slugify).filter(Boolean)
        ],
        body: extracted.body
      };
      await saveWikiDocument(this.config, document);
      imported += 1;
    }

    return {
      scanned: items.length,
      imported,
      skipped,
      folderPath: this.config.sharePoint.folderPath,
      mode: "graph",
      notes
    };
  }

  async validateWebhook(clientState: string | null): Promise<boolean> {
    return Boolean(clientState && clientState === this.config.sharePoint.webhookClientState);
  }

  private async writeMockWelcome(): Promise<void> {
    await saveWikiDocument(this.config, {
      slug: "sharepoint-sync-placeholder",
      title: "SharePoint Sync Placeholder",
      source: "sharepoint",
      sourceUrl: `https://example.invalid}${this.config.sharePoint.sitePath}`,
      tags: ["sharepoint", "placeholder"],
      body: [
        "# SharePoint Sync Placeholder",
        "",
        `Configured source folder: \`${this.config.sharePoint.folderPath}\`.`,
        "",
        "Add Microsoft Graph credentials and run sync again to import approved documents."
      ].join("\n")
    });
  }

  private async getAccessToken(): Promise<string> {
    const app = new ConfidentialClientApplication({
      auth: {
        clientId: this.config.sharePoint.clientId,
        authority: `https://example.invalid}`,
        clientSecret: this.config.sharePoint.clientSecret
      }
    });
    if (!this.accessToken) {
      const response = await app.acquireTokenByClientCredential({ scopes: GRAPH_SCOPE });
      if (!response?.accessToken) throw new Error("Could not acquire Microsoft Graph token.");
      this.accessToken = response.accessToken;
    }
    return this.accessToken;
  }

  private async graph<T>(path: string): Promise<T> {
    const token = await this.getAccessToken();
    const url = path.startsWith("https://") ? path : `https://graph.microsoft.com/v1.0${path}`;
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Graph request failed ${response.status}: ${text}`);
    }
    return (await response.json()) as T;
  }

  private async listFolderItems(): Promise<SharePointItem[]> {
    const site = await this.graph<{ id: string }>(
      `/sites/${this.config.sharePoint.siteHost}:${this.config.sharePoint.sitePath}`
    );
    const drive = await this.graph<{ id: string }>(`/sites/${site.id}/drive`);
    const relativePath = driveRelativePath(this.config.sharePoint.folderPath);
    const queue = [relativePath];
    const files: SharePointItem[] = [];
    const maxItems = configuredMaxItems();

    while (queue.length && files.length < maxItems) {
      const currentPath = queue.shift() ?? "";
      let nextPath: string | undefined = graphPathForChildren(drive.id, currentPath);

      while (nextPath && files.length < maxItems) {
        const children: { value: Array<Record<string, unknown>>; "@odata.nextLink"?: string } =
          await this.graph(nextPath);
        for (const item of children.value) {
          const name = String(item.name ?? "");
          const itemPath = childRelativePath(currentPath, name);
          if (item.folder) {
            queue.push(itemPath);
            continue;
          }
          if (!item.file) continue;
          files.push({
            id: String(item.id),
            name,
            relativePath: itemPath,
            webUrl: String(item.webUrl ?? ""),
            size: typeof item.size === "number" ? item.size : undefined,
            lastModifiedDateTime: typeof item.lastModifiedDateTime === "string" ? item.lastModifiedDateTime : undefined,
            downloadUrl: typeof item["@microsoft.graph.downloadUrl"] === "string" ? item["@microsoft.graph.downloadUrl"] : undefined,
            mimeType:
              typeof (item.file as { mimeType?: unknown }).mimeType === "string"
                ? String((item.file as { mimeType?: unknown }).mimeType)
                : undefined
          });
          if (files.length >= maxItems) break;
        }
        nextPath = children["@odata.nextLink"];
      }
    }

    return files;
  }

  private async downloadBuffer(downloadUrl: string): Promise<Buffer> {
    const response = await fetch(downloadUrl);
    if (!response.ok) throw new Error(`SharePoint download failed ${response.status}`);
    return Buffer.from(await response.arrayBuffer());
  }
}

export async function writeGraphPermissionNote(config: AppConfig): Promise<string> {
  const content = [
    "# SharePoint Permissions",
    "",
    "Use Microsoft Graph Application permission `Sites.Selected`, then grant this app read access only to:",
    "",
    `- \`${config.sharePoint.siteHost}:${config.sharePoint.sitePath}\``,
    "",
    `The ingestion code is additionally restricted to \`${config.sharePoint.folderPath}\`.`
  ].join("\n");
  const filePath = `${config.dataDir}/sharepoint-permissions.md`;
  await fs.mkdir(config.dataDir, { recursive: true });
  await fs.writeFile(filePath, content, "utf8");
  return filePath;
}
