"use client";

import { SessionsReader } from "./sessions-reader";
import { CandidatesReader } from "./candidates-reader";

interface Props {
  adminBaseUrl: string;
}

export function InboxTab({ adminBaseUrl }: Props) {
  return (
    <div className="stack">
      <SessionsReader adminBaseUrl={adminBaseUrl} />
      <CandidatesReader adminBaseUrl={adminBaseUrl} />
    </div>
  );
}
