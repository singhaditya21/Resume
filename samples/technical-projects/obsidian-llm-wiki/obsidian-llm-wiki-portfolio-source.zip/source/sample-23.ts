import { askWiki, getConfig } from "@obsidian-llm-wiki/core";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { question?: string };
  if (!body.question) return Response.json({ error: "question is required" }, { status: 400 });
  const response = await askWiki(getConfig(), body.question);
  return Response.json(response);
}
