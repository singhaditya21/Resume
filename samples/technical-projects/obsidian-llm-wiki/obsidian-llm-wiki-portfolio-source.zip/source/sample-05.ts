import fs from "node:fs/promises";
import path from "node:path";
import { Locator, Page } from "playwright";
import { nanoid } from "nanoid";
import {
  ApprovedSkill,
  AppConfig,
  CapturedSelector,
  DryRunResult,
  ExecutionRecord,
  SkillSelfTestStepResult,
  StagedAction,
  TeachStep,
  TeachStepType
} from "./types";
import { hasBusinessNextCredentials } from "./config";
import { resolveSelectorStack } from "./selectors";
import { writeAuditRecord } from "./businessnext";
import { BusinessNextLoginError, openBusinessNextSession } from "./session";
import {
  DEFAULT_HITL_TIMEOUT_MS,
  createHitlDecision,
  waitForHitlDecision
} from "./hitl";
import { observeExecution } from "./hermes";

const NAVIGATIONAL_TYPES = new Set<TeachStepType>(["click", "type", "select", "select-custom", "upload", "submit", "confirm"]);
const VALIDATION_TYPES = new Set<TeachStepType>([
  "click",
  "type",
  "select",
  "select-custom",
  "upload",
  "submit",
  "confirm"
]);

export interface DryRunOptions {
  navigationTimeoutMs?: number;
  perStepTimeoutMs?: number;
}

export async function dryRunStagedAction(
  config: AppConfig,
  skill: ApprovedSkill,
  staged: StagedAction,
  options: DryRunOptions = {}
): Promise<DryRunResult> {
  const stageId = staged.stageId;
  if (staged.missingInputs.length) {
    const result: DryRunResult = {
      stageId,
      ok: false,
      ranAt: new Date().toISOString(),
      steps: [],
      reason: `Cannot dry-run: missing inputs ${staged.missingInputs.join(", ")}.`
    };
    await writeAuditRecord(config, { kind: "dry-run", ...result, skillId: skill.id });
    return result;
  }
  if (!hasBusinessNextCredentials(config)) {
    const result: DryRunResult = {
      stageId,
      ok: false,
      ranAt: new Date().toISOString(),
      steps: [],
      reason: "BUSINESSNEXT credentials are not configured; cannot reach the login page for dry-run."
    };
    await writeAuditRecord(config, { kind: "dry-run", ...result, skillId: skill.id });
    return result;
  }

  const stepsToCheck = validationSteps(skill.steps);
  const ranAt = new Date().toISOString();
  const results: SkillSelfTestStepResult[] = [];
  let session;
  try {
    session = await openBusinessNextSession(config, { navigationTimeoutMs: options.navigationTimeoutMs ?? 20000 });
  } catch (error) {
    const reason =
      error instanceof BusinessNextLoginError
        ? `Dry-run failed at login (${error.stage}): ${error.message}`
        : `Dry-run could not open BusinessNext: ${error instanceof Error ? error.message : "unknown"}`;
    const result: DryRunResult = { stageId, ok: false, ranAt, steps: [], reason };
    await writeAuditRecord(config, { kind: "dry-run", ...result, skillId: skill.id });
    return result;
  }

  try {
    const page = session.page;
    let lastUrl: string | undefined;
    for (const step of stepsToCheck) {
      if (step.url && step.url !== lastUrl) {
        try {
          await page.goto(step.url, {
            waitUntil: "domcontentloaded",
            timeout: options.navigationTimeoutMs ?? 15000
          });
          lastUrl = step.url;
        } catch (error) {
          results.push({
            stepId: step.id,
            label: step.label,
            resolved: false,
            attempted: [
              {
                kind: "navigate",
                value: step.url,
                ok: false,
                reason: error instanceof Error ? error.message.slice(0, 160) : "navigation failed"
              }
            ]
          });
          continue;
        }
      }
      if (step.type === "hitl-pause") {
        results.push({
          stepId: step.id,
          label: step.label,
          resolved: true,
          resolvedSelector: { kind: "hitl", value: step.hitl?.kind ?? "approve" },
          attempted: []
        });
        continue;
      }
      const stack = stackForStep(step);
      const { resolved, attempts } = await resolveSelectorStack(page, stack, {
        timeoutMs: options.perStepTimeoutMs ?? 1500
      });
      results.push({
        stepId: step.id,
        label: step.label,
        resolved: Boolean(resolved),
        resolvedSelector: resolved ? { kind: resolved.selector.kind, value: resolved.selector.value } : undefined,
        attempted: attempts.map((attempt) => ({
          kind: attempt.selector.kind,
          value: attempt.selector.value,
          ok: attempt.ok,
          reason: attempt.reason
        }))
      });
    }
  } finally {
    await session.close();
  }

  const failed = results.filter((step) => !step.resolved);
  const ok = results.length > 0 && failed.length === 0;
  const liveConfirmationToken = ok ? nanoid(24) : undefined;
  const result: DryRunResult = {
    stageId,
    ok,
    ranAt,
    steps: results,
    reason: ok
      ? undefined
      : `Dry-run failed: ${failed.length} of ${results.length} step(s) could not be located on the BusinessNext workflow pages.`,
    liveConfirmationToken
  };
  await writeAuditRecord(config, { kind: "dry-run", ...result, skillId: skill.id });
  return result;
}

export interface ExecuteOptions {
  jobId: string;
  hitlTimeoutMs?: number;
  navigationTimeoutMs?: number;
  perStepTimeoutMs?: number;
  suiteId?: string;
  seedInputs?: Record<string, string>;
}

export async function executeStagedActionLive(
  config: AppConfig,
  skill: ApprovedSkill,
  staged: StagedAction,
  options: ExecuteOptions
): Promise<ExecutionRecord> {
  const recordId = nanoid();
  const startedAt = new Date().toISOString();
  const stepResults: ExecutionRecord["steps"] = [];
  const capturedOutputs: Record<string, string> = { ...(options.seedInputs ?? {}) };
  let outcome: ExecutionRecord["outcome"] = "succeeded";

  let session;
  try {
    session = await openBusinessNextSession(config, { navigationTimeoutMs: options.navigationTimeoutMs ?? 20000 });
  } catch (error) {
    const errStage: ExecutionRecord["steps"][number] = {
      stepId: "login",
      label: "BusinessNext login",
      type: "navigate",
      status: "failed",
      error: error instanceof BusinessNextLoginError ? `${error.stage}: ${error.message}` : (error instanceof Error ? error.message.slice(0, 240) : "login failed")
    };
    const failedRecord: ExecutionRecord = {
      recordId,
      stageId: staged.stageId,
      idempotencyKey: staged.idempotencyKey,
      skillId: skill.id,
      skillName: skill.name,
      phase: "live",
      outcome: "failed",
      startedAt,
      finishedAt: new Date().toISOString(),
      steps: [errStage]
    };
    await writeAuditRecord(config, { kind: "execution", ...failedRecord });
    return failedRecord;
  }

  try {
    const page = session.page;
    let lastUrl: string | undefined;
    for (const step of skill.steps) {
      if (step.url && step.url !== lastUrl) {
        try {
          await page.goto(step.url, {
            waitUntil: "domcontentloaded",
            timeout: options.navigationTimeoutMs ?? 20000
          });
          lastUrl = step.url;
        } catch (error) {
          stepResults.push({
            stepId: step.id,
            label: step.label,
            type: step.type,
            status: "failed",
            error: `navigation: ${error instanceof Error ? error.message.slice(0, 200) : "failed"}`
          });
          outcome = "failed";
          break;
        }
      }

      if (step.type === "hitl-pause") {
        const result = await runHitlStep(config, skill, staged, options.jobId, step, page);
        stepResults.push(result.step);
        if (result.capturedOutput) capturedOutputs[result.capturedOutput.key] = result.capturedOutput.value;
        if (result.step.status === "hitl-rejected" || result.step.status === "hitl-timeout") {
          outcome = result.step.status === "hitl-rejected" ? "aborted" : "failed";
          break;
        }
        continue;
      }

      if (step.type === "observe" || step.type === "navigate") {
        stepResults.push({ stepId: step.id, label: step.label, type: step.type, status: "skipped" });
        continue;
      }

      if (step.type === "capture-output") {
        const captured = await runCaptureOutputStep(step, page, capturedOutputs);
        stepResults.push(captured);
        continue;
      }

      const stack = stackForStep(step);
      const { resolved } = await resolveSelectorStack(page, stack, { timeoutMs: options.perStepTimeoutMs ?? 3000 });
      if (!resolved) {
        if (step.optional) {
          stepResults.push({ stepId: step.id, label: step.label, type: step.type, status: "skipped", error: "no selector resolved (optional)" });
          continue;
        }
        stepResults.push({ stepId: step.id, label: step.label, type: step.type, status: "failed", error: "no selector resolved" });
        outcome = "failed";
        break;
      }
      try {
        await runStep(page, resolved.locator, step, { ...staged.providedInputs, ...capturedOutputs });
        stepResults.push({
          stepId: step.id,
          label: step.label,
          type: step.type,
          status: "ok",
          resolvedSelector: { kind: resolved.selector.kind, value: resolved.selector.value }
        });
      } catch (error) {
        stepResults.push({
          stepId: step.id,
          label: step.label,
          type: step.type,
          status: "failed",
          resolvedSelector: { kind: resolved.selector.kind, value: resolved.selector.value },
          error: error instanceof Error ? error.message.slice(0, 240) : "step failed"
        });
        outcome = "failed";
        break;
      }
    }
  } catch (error) {
    outcome = "failed";
    stepResults.push({
      stepId: "executor",
      label: "executor loop",
      status: "failed",
      error: error instanceof Error ? error.message.slice(0, 240) : "executor failed"
    });
  } finally {
    await session.close();
  }

  const finishedAt = new Date().toISOString();
  const record: ExecutionRecord = {
    recordId,
    stageId: staged.stageId,
    idempotencyKey: staged.idempotencyKey,
    skillId: skill.id,
    skillName: skill.name,
    phase: "live",
    outcome,
    startedAt,
    finishedAt,
    steps: stepResults,
    capturedOutputs: Object.keys(capturedOutputs).length ? capturedOutputs : undefined
  };
  await writeAuditRecord(config, { kind: "execution", ...record });
  await observeExecution(config, record, { suiteId: options.suiteId }).catch(() => undefined);
  return record;
}

function validationSteps(steps: TeachStep[]): TeachStep[] {
  return steps.filter((step) => VALIDATION_TYPES.has(step.type) || step.type === "hitl-pause");
}

function stackForStep(step: TeachStep): CapturedSelector[] {
  if (step.selectors?.length) return step.selectors;
  if (step.selector) return [{ kind: "css", value: step.selector, confidence: 0.3 }];
  return [];
}

async function runStep(
  page: Page,
  locator: Locator,
  step: TeachStep,
  inputs: Record<string, string>
): Promise<void> {
  switch (step.type) {
    case "type":
      await locator.fill(interpolate(step.valuePreview, inputs));
      return;
    case "select":
      await locator.selectOption({ label: interpolate(step.valuePreview, inputs) });
      return;
    case "select-custom":
      await runCustomDropdown(page, locator, interpolate(step.valuePreview, inputs));
      return;
    case "upload": {
      const filePath = interpolate(step.valuePreview, inputs);
      if (!filePath) throw new Error("upload step missing file path");
      await locator.setInputFiles(filePath);
      return;
    }
    case "click":
    case "submit":
    case "confirm":
      await locator.click();
      return;
    default:
      return;
  }
}

async function runCustomDropdown(page: Page, trigger: Locator, optionText: string): Promise<void> {
  await trigger.click();
  const candidates: Locator[] = [
    page.getByRole("option", { name: optionText, exact: false }),
    page.locator(`li:has-text("${optionText}")`).filter({ hasNotText: /^\s*$/ }),
    page.locator(`[role="option"]:has-text("${optionText}")`),
    page.locator(`.dropdown-menu :text-is("${optionText}")`),
    page.getByText(optionText, { exact: true })
  ];
  for (const candidate of candidates) {
    try {
      const first = candidate.first();
      await first.waitFor({ state: "visible", timeout: 1500 });
      await first.click();
      return;
    } catch {
      continue;
    }
  }
  throw new Error(`custom-dropdown option not found: ${optionText}`);
}

async function runCaptureOutputStep(
  step: TeachStep,
  page: Page,
  capturedOutputs: Record<string, string>
): Promise<ExecutionRecord["steps"][number]> {
  if (!step.capture) {
    return {
      stepId: step.id,
      label: step.label,
      type: step.type,
      status: "failed",
      error: "capture-output step missing config"
    };
  }
  const stack = stackForStep(step);
  const { resolved } = await resolveSelectorStack(page, stack, { timeoutMs: 3000 });
  if (!resolved) {
    return { stepId: step.id, label: step.label, type: step.type, status: "failed", error: "no selector resolved" };
  }
  let raw: string | null;
  try {
    raw = step.capture.fromAttribute
      ? await resolved.locator.getAttribute(step.capture.fromAttribute)
      : await resolved.locator.innerText();
  } catch (error) {
    return {
      stepId: step.id,
      label: step.label,
      type: step.type,
      status: "failed",
      error: error instanceof Error ? error.message.slice(0, 200) : "capture failed"
    };
  }
  if (raw == null) {
    return { stepId: step.id, label: step.label, type: step.type, status: "failed", error: "captured null" };
  }
  let value = raw.trim();
  if (step.capture.regex) {
    const match = value.match(new RegExp(step.capture.regex));
    if (!match) {
      return { stepId: step.id, label: step.label, type: step.type, status: "failed", error: "regex did not match" };
    }
    value = match[1] ?? match[0] ?? value;
  }
  capturedOutputs[step.capture.outputKey] = value;
  return {
    stepId: step.id,
    label: step.label,
    type: step.type,
    status: "ok",
    capturedOutput: { key: step.capture.outputKey, value },
    resolvedSelector: { kind: resolved.selector.kind, value: resolved.selector.value }
  };
}

interface HitlStepOutcome {
  step: ExecutionRecord["steps"][number];
  capturedOutput?: { key: string; value: string };
}

async function runHitlStep(
  config: AppConfig,
  skill: ApprovedSkill,
  staged: StagedAction,
  jobId: string,
  step: TeachStep,
  page: Page
): Promise<HitlStepOutcome> {
  const hitl = step.hitl ?? { kind: "approve", prompt: step.label };
  const screenshotsDir = path.join(config.dataDir, "decisions", "screenshots");
  await fs.mkdir(screenshotsDir, { recursive: true });
  const screenshotPath = path.join(screenshotsDir, `${jobId}-${step.id}.png`);
  await page.screenshot({ path: screenshotPath, fullPage: false }).catch(() => undefined);
  const visibleSnippet = await page
    .evaluate(() => (document.body?.innerText ?? "").replace(/\s+/g, " ").trim().slice(0, 600))
    .catch(() => undefined);
  const decision = await createHitlDecision(config, {
    jobId,
    stageId: staged.stageId,
    skillId: skill.id,
    skillName: skill.name,
    stepId: step.id,
    stepLabel: step.label,
    prompt: hitl.prompt,
    kind: hitl.kind,
    choices: hitl.choices,
    screenshotPath,
    visibleSnippet,
    url: page.url()
  });

  const resolved = await waitForHitlDecision(config, decision.decisionId, {
    pollIntervalMs: 1500
  });

  if (resolved.status === "rejected") {
    return {
      step: {
        stepId: step.id,
        label: step.label,
        type: step.type,
        status: "hitl-rejected",
        hitlDecision: { decisionId: decision.decisionId, choice: resolved.choice ?? "reject", operator: resolved.resolvedBy }
      }
    };
  }
  if (resolved.status === "timeout") {
    return {
      step: {
        stepId: step.id,
        label: step.label,
        type: step.type,
        status: "hitl-timeout",
        hitlDecision: { decisionId: decision.decisionId, choice: "timeout" }
      }
    };
  }

  const captured = hitl.kind === "value" && hitl.outputKey && resolved.value
    ? { key: hitl.outputKey, value: resolved.value }
    : undefined;
  return {
    step: {
      stepId: step.id,
      label: step.label,
      type: step.type,
      status: "ok",
      hitlDecision: {
        decisionId: decision.decisionId,
        choice: resolved.choice ?? "approve",
        value: resolved.value,
        operator: resolved.resolvedBy
      },
      capturedOutput: captured
    },
    capturedOutput: captured
  };
}

function interpolate(template: string | undefined, inputs: Record<string, string>): string {
  if (!template) return "";
  return template.replace(/\{\{(.+?)\}\}/g, (_, name) => inputs[name.trim()] ?? "");
}

// Re-export the default for callers
export { DEFAULT_HITL_TIMEOUT_MS };
