/**
 * Phase 6 — Planner.
 *
 * Composes a multi-step plan of skill invocations from an operator goal.
 * Uses NIM when available; falls back to a deterministic single-skill match
 * when NIM is unconfigured or returns nothing useful.
 *
 * The planner is ONLY composition — execution is delegated to the existing
 * ObservedSkill runner (one runner invocation per plan step). A separate
 * execution engine (`plan-engine.ts`) chains those calls.
 */

import fs from "node:fs/promises";
import path from "node:path";
import type { AppConfig } from "./types";
import { NvidiaNimClient } from "./nim";
import type { ObservedAgent } from "./observed-agents";
import { listObservedAgents } from "./observed-agents";
import type { ObservedSkill } from "./observed-skills";
import { listSkills, readSkill } from "./observed-skills";

// ─── Types ───────────────────────────────────────────────────────────────────

export type PlanStatus =
  | "proposed"
  | "confirmed"
  | "running"
  | "ok"
  | "failed"
  | "aborted"
  | "rejected";

export interface PlannedStep {
  /** 0-based index in the plan. */
  index: number;
  skillId: string;
  skillName: string;
  agentId?: string;
  agentName?: string;
  /** Parameter bindings — may be empty strings if the LLM couldn't infer. */
  parameters: Record<string, string>;
  /** Parameter names from the skill schema that the planner could NOT fill. */
  missingParameters: string[];
  rationale: string;
  confidence: number;
}

export interface PlanStepResult {
  stepIndex: number;
  status: "pending" | "running" | "ok" | "failed" | "skipped";
  runId?: string;
  startedAt?: string;
  finishedAt?: string;
  error?: string;
}

export interface Plan {
  planId: string;
  goal: string;
  status: PlanStatus;
  steps: PlannedStep[];
  overallRationale: string;
  warnings: string[];
  /** Did NIM compose this, or did we fall back to deterministic matching? */
  source: "nim" | "fallback" | "operator-edited";
  initiatedBy: string;
  createdAt: string;
  /** Operator who confirmed (separate from initiator — could be the same person). */
  confirmedBy?: string;
  confirmedAt?: string;
  startedAt?: string;
  finishedAt?: string;
  stepResults?: PlanStepResult[];
  /** When this plan is in `proposed` status, the operator may still edit before confirming. */
  needsHumanReview: boolean;
}

// ─── Paths ───────────────────────────────────────────────────────────────────

export function plansDir(config: Pick<AppConfig, "dataDir">): string {
  return path.join(config.dataDir, "plans");
}

export function planPath(config: Pick<AppConfig, "dataDir">, planId: string): string {
  return path.join(plansDir(config), `${planId}.json`);
}

async function atomicWriteJson(filePath: string, payload: unknown): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  const handle = await fs.open(tmp, "w");
  try {
    await handle.writeFile(JSON.stringify(payload, null, 2), "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await fs.rename(tmp, filePath);
}

export async function readPlan(
  config: Pick<AppConfig, "dataDir">,
  planId: string
): Promise<Plan | null> {
  try {
    return JSON.parse(await fs.readFile(planPath(config, planId), "utf8")) as Plan;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

export async function writePlan(config: Pick<AppConfig, "dataDir">, plan: Plan): Promise<void> {
  await atomicWriteJson(planPath(config, plan.planId), plan);
}

export async function listPlans(
  config: Pick<AppConfig, "dataDir">,
  options: { limit?: number; status?: PlanStatus } = {}
): Promise<Plan[]> {
  let entries;
  try {
    entries = await fs.readdir(plansDir(config));
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw error;
  }
  const plans: Plan[] = [];
  for (const name of entries) {
    if (!name.endsWith(".json")) continue;
    try {
      const plan = JSON.parse(await fs.readFile(path.join(plansDir(config), name), "utf8")) as Plan;
      if (options.status && plan.status !== options.status) continue;
      plans.push(plan);
    } catch {
      /* skip */
    }
  }
  plans.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (options.limit) return plans.slice(0, options.limit);
  return plans;
}

// ─── Composition ─────────────────────────────────────────────────────────────

function newPlanId(): string {
  return `plan_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export interface ProposeOptions {
  goal: string;
  initiatedBy: string;
  /** When set, only skills owned by these agentIds are considered. */
  agentIds?: string[];
  maxSteps?: number;
}

export async function proposePlan(config: AppConfig, options: ProposeOptions): Promise<Plan> {
  const goal = options.goal.trim();
  if (!goal) throw new Error("goal is required");

  const allSkills = await listSkills(config);
  const allAgents = await listObservedAgents(config);
  const candidateSkills = options.agentIds && options.agentIds.length
    ? allSkills.filter((s) => allAgents.find((a) => options.agentIds!.includes(a.agentId) && a.skillIds.includes(s.skillId)))
    : allSkills;

  if (candidateSkills.length === 0) {
    // No skills to plan with — return an empty proposal with a warning
    const empty: Plan = {
      planId: newPlanId(),
      goal,
      status: "proposed",
      steps: [],
      overallRationale: "No observed skills available. Confirm a candidate skill in the Inbox first.",
      warnings: ["zero-skills-available"],
      source: "fallback",
      initiatedBy: options.initiatedBy,
      createdAt: new Date().toISOString(),
      needsHumanReview: true
    };
    await writePlan(config, empty);
    return empty;
  }

  const skillSummaries = candidateSkills.map((s) => ({
    skillId: s.skillId,
    name: s.name,
    description: s.description,
    agentName: allAgents.find((a) => a.skillIds.includes(s.skillId))?.name,
    parameters: s.parameters.map((p) => ({
      name: p.name,
      type: p.type,
      required: p.required,
      examples: p.exampleValues.slice(0, 3)
    }))
  }));

  const nim = new NvidiaNimClient(config);
  const composition = await nim.composePlan(goal, skillSummaries, { maxSteps: options.maxSteps });

  let plan: Plan;
  if (composition && composition.steps.length > 0) {
    plan = await materialiseFromNim(config, goal, composition, options.initiatedBy, allSkills, allAgents);
  } else {
    plan = await materialiseFallback(goal, options.initiatedBy, allSkills, allAgents);
  }
  await writePlan(config, plan);
  return plan;
}

async function materialiseFromNim(
  _config: AppConfig,
  goal: string,
  composition: {
    steps: Array<{ skillId: string; parameters: Record<string, string>; rationale: string; confidence: number }>;
    overallRationale: string;
    warnings: string[];
  },
  initiatedBy: string,
  allSkills: ObservedSkill[],
  allAgents: ObservedAgent[]
): Promise<Plan> {
  const skillById = new Map(allSkills.map((s) => [s.skillId, s] as const));
  const warnings = [...composition.warnings];
  const steps: PlannedStep[] = [];

  for (let i = 0; i < composition.steps.length; i++) {
    const step = composition.steps[i]!;
    const skill = skillById.get(step.skillId);
    if (!skill) {
      warnings.push(`unknown-skill-id: ${step.skillId}`);
      continue;
    }
    const requiredParamNames = skill.parameters.filter((p) => p.required).map((p) => p.name);
    const missing = requiredParamNames.filter((n) => !step.parameters[n] || step.parameters[n].trim() === "");
    const agent = allAgents.find((a) => a.skillIds.includes(skill.skillId));
    steps.push({
      index: i,
      skillId: skill.skillId,
      skillName: skill.name,
      agentId: agent?.agentId,
      agentName: agent?.name,
      parameters: Object.fromEntries(
        Object.entries(step.parameters).filter(([k]) =>
          skill.parameters.some((p) => p.name === k)
        )
      ),
      missingParameters: missing,
      rationale: step.rationale,
      confidence: step.confidence
    });
  }

  return {
    planId: newPlanId(),
    goal,
    status: "proposed",
    steps,
    overallRationale: composition.overallRationale || `${steps.length}-step plan composed by NIM.`,
    warnings,
    source: "nim",
    initiatedBy,
    createdAt: new Date().toISOString(),
    needsHumanReview: steps.some((s) => s.missingParameters.length > 0 || s.confidence < 0.6)
  };
}

async function materialiseFallback(
  goal: string,
  initiatedBy: string,
  allSkills: ObservedSkill[],
  allAgents: ObservedAgent[]
): Promise<Plan> {
  // Deterministic match: case-insensitive substring of goal vs. skill name + description
  const goalLower = goal.toLowerCase();
  const tokenised = goalLower.split(/\W+/).filter((t) => t.length > 2);
  let best: ObservedSkill | null = null;
  let bestScore = 0;
  for (const skill of allSkills) {
    const haystack = `${skill.name} ${skill.description}`.toLowerCase();
    const score = tokenised.reduce((acc, t) => (haystack.includes(t) ? acc + 1 : acc), 0);
    if (score > bestScore) {
      bestScore = score;
      best = skill;
    }
  }

  const warnings = ["REDACTED_OPAQUE_VALUE"];
  if (!best) {
    return {
      planId: newPlanId(),
      goal,
      status: "proposed",
      steps: [],
      overallRationale: "Couldn't match any observed skill to this goal. Either re-phrase, or confirm a relevant skill first.",
      warnings: [...warnings, "no-skill-matched"],
      source: "fallback",
      initiatedBy,
      createdAt: new Date().toISOString(),
      needsHumanReview: true
    };
  }
  const agent = allAgents.find((a) => a.skillIds.includes(best!.skillId));
  const step: PlannedStep = {
    index: 0,
    skillId: best.skillId,
    skillName: best.name,
    agentId: agent?.agentId,
    agentName: agent?.name,
    parameters: {},
    missingParameters: best.parameters.filter((p) => p.required).map((p) => p.name),
    rationale: `Best substring match against the goal (${bestScore} tokens overlap).`,
    confidence: Math.min(0.4 + 0.1 * bestScore, 0.7)
  };
  return {
    planId: newPlanId(),
    goal,
    status: "proposed",
    steps: [step],
    overallRationale: `Deterministic fallback proposed "${best.name}".`,
    warnings,
    source: "fallback",
    initiatedBy,
    createdAt: new Date().toISOString(),
    needsHumanReview: true
  };
}

// ─── Operator edits ──────────────────────────────────────────────────────────

export interface PlanEdit {
  /** Per-step parameter overrides keyed by step index. */
  parameters?: Record<number, Record<string, string>>;
  /** Step indices to remove (e.g. operator decides not to run step 3). */
  removeSteps?: number[];
}

export async function applyPlanEdits(
  config: AppConfig,
  planId: string,
  edits: PlanEdit
): Promise<Plan> {
  const plan = await readPlan(config, planId);
  if (!plan) throw new Error(`No plan ${planId}`);
  if (plan.status !== "proposed") {
    throw new Error(`Plan ${planId} is in status ${plan.status} — only proposed plans can be edited.`);
  }
  const removeSet = new Set(edits.removeSteps ?? []);
  const next = plan.steps
    .filter((s) => !removeSet.has(s.index))
    .map((s, newIdx) => {
      const param = edits.parameters?.[s.index];
      const merged = param ? { ...s.parameters, ...param } : s.parameters;
      // Re-evaluate missing parameters against the skill schema
      // Note: we need the live skill to check this — but we trust the operator's edits.
      const stillMissing = s.missingParameters.filter((name) => !merged[name] || merged[name].trim() === "");
      return { ...s, index: newIdx, parameters: merged, missingParameters: stillMissing };
    });
  plan.steps = next;
  plan.source = "operator-edited";
  plan.needsHumanReview = next.some((s) => s.missingParameters.length > 0 || s.confidence < 0.6);
  await writePlan(config, plan);
  return plan;
}

// ─── Skill-schema validation ────────────────────────────────────────────────

/**
 * Walk through a proposed plan's steps and re-check each step's parameter
 * fills against the live skill schema. Used by the confirm endpoint as a
 * last sanity gate before executing.
 */
export async function validatePlanForExecution(
  config: AppConfig,
  plan: Plan
): Promise<{ ok: true } | { ok: false; problems: string[] }> {
  const problems: string[] = [];
  for (const step of plan.steps) {
    const skill = await readSkill(config, step.skillId);
    if (!skill) {
      problems.push(`Step ${step.index}: skill ${step.skillId} no longer exists.`);
      continue;
    }
    for (const p of skill.parameters) {
      const v = step.parameters[p.name];
      if (p.required && (!v || v.trim() === "")) {
        problems.push(`Step ${step.index}: missing required parameter "${p.name}".`);
      }
    }
  }
  if (problems.length) return { ok: false, problems };
  return { ok: true };
}
