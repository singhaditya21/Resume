import OpenAI from "openai";
import { AppConfig, ApprovedSkill, AskResponse, Citation, SearchResult } from "./types";
import { buildContext, searchWiki } from "./search";
import { hasNvidiaCredentials } from "./config";

export class NvidiaNimClient {
  private readonly openai: OpenAI | null;

  constructor(private readonly config: AppConfig) {
    this.openai = hasNvidiaCredentials(config)
      ? new OpenAI({
          apiKey: config.nvidia.apiKey,
          baseURL: config.nvidia.baseUrl
        })
      : null;
  }

  async ask(question: string, results: SearchResult[]): Promise<AskResponse> {
    const citations: Citation[] = results.map((result) => ({
      title: result.title,
      url: result.url,
      snippet: result.snippet
    }));

    if (!this.openai) {
      return { answer: localAnswer(results, "Configure NVIDIA_API_KEY to enable full NIM answers."), citations, provider: "local-fallback" };
    }

    try {
      const response = await this.openai.chat.completions.create({
        model: this.config.nvidia.chatModel,
        max_tokens: 2048,
        temperature: 0.15,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
        messages: [
          {
            role: "system",
            content:
              "Answer only from the provided wiki context. Include concise citations by title. If the answer is not in context, say what is missing."
          },
          {
            role: "user",
            content: `Question: ${question}\n\nWiki contex/opt/portfolio/project
          }
        ]
      });

      return {
        answer: response.choices[0]?.message.content?.trim() || "No answer returned by NIM.",
        citations,
        provider: "nvidia-nim"
      };
    } catch (error) {
      return {
        answer: localAnswer(results, `NVIDIA NIM could not answer with the configured model: ${safeErrorMessage(error)}.`),
        citations,
        provider: "local-fallback"
      };
    }
  }

  async embed(input: string): Promise<number[]> {
    if (!this.openai || !this.config.nvidia.embedModel) return [];
    const response = await this.openai.embeddings.create({
      model: this.config.nvidia.embedModel,
      input
    });
    return response.data[0]?.embedding ?? [];
  }

  async selectSkillForPrompt(
    prompt: string,
    skills: ApprovedSkill[]
  ): Promise<{ skillId: string | null; providedInputs: Record<string, string>; reason: string } | null> {
    if (!this.openai || !skills.length) return null;

    const response = await this.openai.chat.completions.create({
      model: this.config.nvidia.chatModel,
      max_tokens: 2048,
      temperature: 0,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "Select the best approved BusinessNext skill for the user's request. Return only JSON with keys skillId, providedInputs, and reason. Use null skillId if no skill fits. providedInputs must map required input names to values found in the request."
        },
        {
          role: "user",
          content: JSON.stringify({
            prompt,
            skills: skills.map((skill) => ({
              id: skill.id,
              name: skill.name,
              description: skill.description,
              requiredInputs: skill.requiredInputs
            }))
          })
        }
      ]
    });

    const raw = response.choices[0]?.message.content ?? "{}";
    try {
      const parsed = JSON.parse(raw) as {
        skillId?: string | null;
        providedInputs?: Record<string, string>;
        reason?: string;
      };
      return {
        skillId: parsed.skillId ?? null,
        providedInputs: parsed.providedInputs ?? {},
        reason: parsed.reason ?? "NVIDIA NIM selected the skill."
      };
    } catch {
      return null;
    }
  }

  /**
   * P6.1 — compose a multi-step plan from operator goal + observed skills.
   * Returns null if NIM is unavailable; caller should fall back to a
   * deterministic single-skill match.
   */
  async composePlan(
    goal: string,
    skills: Array<{
      skillId: string;
      name: string;
      description: string;
      agentName?: string;
      parameters: Array<{ name: string; type: string; required: boolean; examples: string[] }>;
    }>,
    options: { maxSteps?: number } = {}
  ): Promise<{
    steps: Array<{
      skillId: string;
      parameters: Record<string, string>;
      rationale: string;
      confidence: number;
    }>;
    overallRationale: string;
    warnings: string[];
  } | null> {
    if (!this.openai || !skills.length) return null;
    const maxSteps = options.maxSteps ?? 8;

    const systemPrompt =
      "You are Paperclip's planner. The operator asks you to do something; you compose a plan of skill invocations. " +
      "Use only the skills the operator owns (listed below). " +
      "For each step, supply parameter values: a literal string if you can infer from the goal, " +
      "otherwise leave the value empty so the operator fills it before running. " +
      `Compose at most ${maxSteps} steps. Set confidence between 0 and 1 honestly — lower if you're guessing parameters. ` +
      "Return ONLY JSON matching: " +
      `{"steps":[{"skillId":"...","parameters":{...},"rationale":"...","confidence":0.0}],"overallRationale":"...","warnings":["..."]}`;

    try {
      const response = await this.openai.chat.completions.create({
        model: this.config.nvidia.chatModel,
        max_tokens: 2048,
        temperature: 0.1,
        top_p: 1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: JSON.stringify({
              goal,
              availableSkills: skills
            })
          }
        ]
      });
      const raw = response.choices[0]?.message.content ?? "{}";
      const parsed = JSON.parse(raw) as {
        steps?: Array<{
          skillId?: string;
          parameters?: Record<string, string>;
          rationale?: string;
          confidence?: number;
        }>;
        overallRationale?: string;
        warnings?: string[];
      };
      return {
        steps: (parsed.steps ?? [])
          .filter((s): s is { skillId: string; parameters?: Record<string, string>; rationale?: string; confidence?: number } =>
            typeof s.skillId === "string" && s.skillId.length > 0
          )
          .map((s) => ({
            skillId: s.skillId,
            parameters: s.parameters ?? {},
            rationale: s.rationale ?? "",
            confidence: typeof s.confidence === "number" ? Math.max(0, Math.min(1, s.confidence)) : 0.5
          })),
        overallRationale: parsed.overallRationale ?? "",
        warnings: Array.isArray(parsed.warnings) ? parsed.warnings : []
      };
    } catch (err) {
      console.warn(`NIM composePlan failed: ${safeErrorMessage(err)}`);
      return null;
    }
  }
}

export async function askWiki(config: AppConfig, question: string): Promise<AskResponse> {
  const results = await searchWiki(config, question, 6, ["sharepoint"]);
  return new NvidiaNimClient(config).ask(question, results);
}

function localAnswer(results: SearchResult[], prefix: string): string {
  if (!results.length) {
    return `${prefix} I could not find matching wiki content yet. Run SharePoint sync or approve BusinessNext skills, then ask again.`;
  }

  const titles = results
    .slice(0, 3)
    .map((result) => result.title)
    .join(", ");
  return `${prefix} I found ${results.length} relevant wiki item(s) from the local Obsidian vault. Start with: ${titles}.`;
}

function safeErrorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message.replace(/\s+/g, " ").slice(0, 220);
  return "provider request failed";
}
