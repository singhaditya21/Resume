/**
 * Phase 7 — Trust ratchet.
 *
 * Each ObservedSkill has a trust tier that controls how much the operator
 * has to be in the loop when it runs:
 *
 *   confirm-each-step  — operator confirms every step (most cautious; default)
 *   confirm-before-run — operator confirms the whole run once at start
 *   autonomous         — runs without prompting (scheduled/webhook triggers OK)
 *
 * The tier is computed from the Hermes episode history. Operators can also
 * promote/demote manually via API. Demotion is sticky for 24h to avoid
 * thrashing.
 */

import fs from "node:fs/promises";
import path from "node:path";
import type { AppConfig } from "./types";
import { recallEpisodes } from "./hermes";

// ─── Types ───────────────────────────────────────────────────────────────────

export type TrustTier = "confirm-each-step" | "confirm-before-run" | "autonomous";

export interface TrustState {
  skillId: string;
  tier: TrustTier;
  /** True if the tier was set by the operator (sticky); false if auto-derived. */
  manuallySet: boolean;
  /** When manuallySet=true, the tier is pinned until this ISO timestamp expires. */
  pinnedUntil?: string;
  reason: string;
  computedAt: string;
}

export interface TrustEvidence {
  totalRuns: number;
  successCount: number;
  failureCount: number;
  consecutiveSuccesses: number;
  lastOutcome?: "ok" | "failed" | "skipped" | "aborted";
  lastRunAt?: string;
  lastFailureAt?: string;
  hoursSinceLastFailure?: number;
}

// ─── Tuning ──────────────────────────────────────────────────────────────────

export const PROMOTE_TO_CONFIRM_BEFORE = 5; // consecutive successes
export const PROMOTE_TO_AUTONOMOUS = 15; // consecutive successes
export const AUTONOMOUS_REQUIRES_DAYS_SINCE_FAILURE = 7;
export const CONFIRM_BEFORE_REQUIRES_HOURS_SINCE_FAILURE = 24;
export const MANUAL_PIN_DURATION_MS = 24 * 60 * 60 * 1000;

// ─── Paths ───────────────────────────────────────────────────────────────────

function trustPath(config: Pick<AppConfig, "dataDir">, skillId: string): string {
  return path.join(config.dataDir, "observed-skills", "skills", skillId, "trust.json");
}

async function atomicWriteJson(filePath: string, payload: unknown): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  const handle = await fs.open(tmp, "w");
  try {
    await handle.writeFile(JSON.stringify(payload, null, 2), "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await fs.rename(tmp, filePath);
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function readTrustState(
  config: Pick<AppConfig, "dataDir">,
  skillId: string
): Promise<TrustState | null> {
  try {
    return JSON.parse(await fs.readFile(trustPath(config, skillId), "utf8")) as TrustState;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

export async function writeTrustState(
  config: Pick<AppConfig, "dataDir">,
  state: TrustState
): Promise<void> {
  await atomicWriteJson(trustPath(config, state.skillId), state);
}

/**
 * Gather Hermes evidence for a skill — counts + streaks + recency.
 */
export async function gatherTrustEvidence(
  config: Pick<AppConfig, "dataDir">,
  skillId: string
): Promise<TrustEvidence> {
  const episodes = await recallEpisodes(config, { skillId, limit: 200 });
  // Episodes ordered newest-first per recallEpisodes contract. (If that
  // changes, this still works modulo direction.)
  const sorted = [...episodes].sort((a, b) => a.finishedAt.localeCompare(b.finishedAt));

  let successCount = 0;
  let failureCount = 0;
  let lastFailureAt: string | undefined;
  let lastRunAt: string | undefined;
  let lastOutcome: TrustEvidence["lastOutcome"];

  for (const ep of sorted) {
    if (ep.outcome === "succeeded") successCount += 1;
    else if (ep.outcome === "failed" || ep.outcome === "aborted") {
      failureCount += 1;
      lastFailureAt = ep.finishedAt;
    }
    lastRunAt = ep.finishedAt;
    lastOutcome =
      ep.outcome === "succeeded"
        ? "ok"
        : ep.outcome === "failed"
          ? "failed"
          : ep.outcome === "aborted"
            ? "aborted"
            : "skipped";
  }

  // Consecutive successes from the END (newest)
  let consecutive = 0;
  for (let i = sorted.length - 1; i >= 0; i--) {
    if (sorted[i]!.outcome === "succeeded") consecutive += 1;
    else break;
  }

  const hoursSinceLastFailure = lastFailureAt
    ? Math.floor((Date.now() - Date.parse(lastFailureAt)) / (60 * 60 * 1000))
    : undefined;

  return {
    totalRuns: sorted.length,
    successCount,
    failureCount,
    consecutiveSuccesses: consecutive,
    lastOutcome,
    lastRunAt,
    lastFailureAt,
    hoursSinceLastFailure
  };
}

/**
 * Derive the trust tier from evidence + (optionally) the existing pinned state.
 * If `existing.manuallySet === true` and the pin hasn't expired, return that
 * tier instead of recomputing.
 */
export function deriveTier(evidence: TrustEvidence, existing?: TrustState | null): TrustTier {
  if (existing?.manuallySet && existing.pinnedUntil && Date.parse(existing.pinnedUntil) > Date.now()) {
    return existing.tier;
  }
  // Any recent failure forces back to most cautious tier
  if (evidence.hoursSinceLastFailure !== undefined && evidence.hoursSinceLastFailure < 1) {
    return "confirm-each-step";
  }
  const hours = evidence.hoursSinceLastFailure ?? Infinity;
  const days = hours / 24;
  if (evidence.consecutiveSuccesses >= PROMOTE_TO_AUTONOMOUS && days >= AUTONOMOUS_REQUIRES_DAYS_SINCE_FAILURE) {
    return "autonomous";
  }
  if (
    evidence.consecutiveSuccesses >= PROMOTE_TO_CONFIRM_BEFORE &&
    hours >= CONFIRM_BEFORE_REQUIRES_HOURS_SINCE_FAILURE
  ) {
    return "confirm-before-run";
  }
  return "confirm-each-step";
}

export function explainTier(tier: TrustTier, evidence: TrustEvidence): string {
  switch (tier) {
    case "autonomous":
      return `${evidence.consecutiveSuccesses}/${PROMOTE_TO_AUTONOMOUS} successes; last failure ${
        evidence.hoursSinceLastFailure ?? "∞"
      }h ago — full autonomy.`;
    case "confirm-before-run":
      return `${evidence.consecutiveSuccesses}/${PROMOTE_TO_AUTONOMOUS} for autonomy; needs ${AUTONOMOUS_REQUIRES_DAYS_SINCE_FAILURE} clean days. Confirm once before run.`;
    case "confirm-each-step":
    default:
      if ((evidence.hoursSinceLastFailure ?? Infinity) < 1) return "Recent failure — held at confirm-each-step.";
      return `${evidence.consecutiveSuccesses}/${PROMOTE_TO_CONFIRM_BEFORE} successes needed to graduate to confirm-before-run.`;
  }
}

/**
 * Recompute + persist trust for a skill. Returns the resulting state.
 */
export async function refreshTrust(
  config: Pick<AppConfig, "dataDir">,
  skillId: string
): Promise<TrustState> {
  const existing = await readTrustState(config, skillId);
  const evidence = await gatherTrustEvidence(config, skillId);
  const tier = deriveTier(evidence, existing);
  const state: TrustState = {
    skillId,
    tier,
    manuallySet: false,
    reason: explainTier(tier, evidence),
    computedAt: new Date().toISOString()
  };
  // Preserve manual pin if still active
  if (existing?.manuallySet && existing.pinnedUntil && Date.parse(existing.pinnedUntil) > Date.now()) {
    state.tier = existing.tier;
    state.manuallySet = true;
    state.pinnedUntil = existing.pinnedUntil;
    state.reason = `${existing.reason} (pinned until ${existing.pinnedUntil})`;
  }
  await writeTrustState(config, state);
  return state;
}

/**
 * Operator-driven promotion / demotion. Pins the chosen tier for 24h so
 * Hermes recomputes don't immediately fight the operator.
 */
export async function setTrustManually(
  config: Pick<AppConfig, "dataDir">,
  skillId: string,
  tier: TrustTier,
  setBy: string
): Promise<TrustState> {
  const state: TrustState = {
    skillId,
    tier,
    manuallySet: true,
    pinnedUntil: new Date(Date.now() + MANUAL_PIN_DURATION_MS).toISOString(),
    reason: `Set to "${tier}" by ${setBy}.`,
    computedAt: new Date().toISOString()
  };
  await writeTrustState(config, state);
  return state;
}

/**
 * Check whether a skill is eligible to be promoted to the next tier. Useful
 * for the UI ratchet banner: "you've confirmed this 10× in a row — promote?"
 */
export function nextPromotionSuggestion(
  current: TrustTier,
  evidence: TrustEvidence
): { suggestedTier: TrustTier; reason: string } | null {
  const hours = evidence.hoursSinceLastFailure ?? Infinity;
  const days = hours / 24;
  if (current === "confirm-each-step") {
    if (
      evidence.consecutiveSuccesses >= PROMOTE_TO_CONFIRM_BEFORE &&
      hours >= CONFIRM_BEFORE_REQUIRES_HOURS_SINCE_FAILURE
    ) {
      return {
        suggestedTier: "confirm-before-run",
        reason: `${evidence.consecutiveSuccesses} successful runs in a row, no failures in ${hours}h.`
      };
    }
  } else if (current === "confirm-before-run") {
    if (evidence.consecutiveSuccesses >= PROMOTE_TO_AUTONOMOUS && days >= AUTONOMOUS_REQUIRES_DAYS_SINCE_FAILURE) {
      return {
        suggestedTier: "autonomous",
        reason: `${evidence.consecutiveSuccesses} successful runs, no failures in ${Math.floor(days)} days.`
      };
    }
  }
  return null;
}
