import { getConfig, getPaperclipAgentPlan, requireOperator } from "@obsidian-llm-wiki/core";

export async function GET(request: Request) {
  const config = getConfig();
  const { actor: _actor, response: unauthorized } = await requireOperator(request.headers, config);
  if (unauthorized) return unauthorized;

  return Response.json(getPaperclipAgentPlan(config));
}
