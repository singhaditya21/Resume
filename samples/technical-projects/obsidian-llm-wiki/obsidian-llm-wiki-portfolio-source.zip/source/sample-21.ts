import { getConfig, searchWiki } from "@obsidian-llm-wiki/core";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = url.searchParams.get("q") ?? "";
  const results = await searchWiki(getConfig(), q, 8, ["sharepoint"]);
  return Response.json({ query: q, results });
}
