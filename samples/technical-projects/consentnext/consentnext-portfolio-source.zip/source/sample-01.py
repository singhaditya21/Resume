import hashlib
import hmac
import json
import os
import time
from typing import List, Optional

from app.config import settings

# Signing provider (invariant I2). Pluggable: SoftwareKMS (HMAC) for Stage 1; CloudKMS for pilot/prod -
# same interface, per-key-id material + managed rotation. Signature format `sha256:<keyver>:<hex>` carries the
# key version so rotation never invalidates prior signatures (verification tries all retained keys).
#
# Availability is modelled explicitly: when the provider is unavailable, sign() raises KmsUnavailableError
# AFTER bounded retries - callers MUST block the commit rather than persist an unsigned record (AC-11-I01).


class KmsUnavailableError(Exception):
    """The KMS could not sign within the retry budget - the caller must abort, never write unsigned (AC-11-I01)."""


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _tenant_key(secret: str, tenant_id: Optional[str]) -> str:
    """Per-tenant key isolation (AC-TEN-04): derive a tenant-scoped subkey from the base key so one tenant's
    key material can never verify another tenant's records. Deterministic so verification is stable."""
    if not tenant_id:
        return secret
    return hmac.new(secret.encode(), f"tenant:{tenant_id}".encode(), hashlib.sha256).hexdigest()


class SoftwareKMS:
    def __init__(self, secrets: List[str]):
        self.secrets = list(secrets)  # current key first, then retired keys (for verification)
        self._available = True

    def set_available(self, value: bool) -> None:
        self._available = value

    def _digest(self, secret: str, payload: dict) -> str:
        return hmac.new(secret.encode(), _canonical(payload), hashlib.sha256).hexdigest()

    def sign(self, payload: dict, tenant_id: Optional[str] = None) -> str:
        if not self._available:
            raise KmsUnavailableError("software KMS marked unavailable")
        return f"sha256:{self._digest(_tenant_key(self.secrets[0], tenant_id), payload)}"

    def verify(self, payload: dict, signature: str, tenant_id: Optional[str] = None) -> bool:
        # Try the per-tenant subkey for each retained key first, then the legacy base keys (so records signed
        # before per-tenant derivation still verify - non-breaking rollout).
        candidates = []
        for s in self.secrets:
            if tenant_id:
                candidates.append(_tenant_key(s, tenant_id))
            candidates.append(s)
        return any(hmac.compare_digest(f"sha256:{self._digest(c, payload)}", signature) for c in candidates)

    def rotate(self, new_secret: str) -> None:
        self.secrets.insert(0, new_secret)  # new current; old keys retained


class CloudKMS:
    """Cloud-KMS-backed signer (pilot/prod). The adapter is real - it resolves versioned key material from the
    KMS keystore, signs over the canonical payload, supports rotation, and surfaces transport availability so
    the caller can fail closed. On localhost the keystore is local key material (env `KMS_KEY_<id>` or a
    derived dev key); in cloud the same shape wraps boto3 / google-cloud-kms calls. Signature carries the key
    id+version so verification selects the right key and rotation is non-breaking."""

    def __init__(self, key_id: str):
        self.key_id = key_id or "cn-primary"
        # Versioned keystore: {version:int -> key_material}. v1 is current; retired versions kept for verify.
        self._keys: dict = {1: self._resolve_material(self.key_id, 1)}
        self._current = 1
        self._available = True

    @staticmethod
    def _resolve_material(key_id: str, version: int) -> str:
        # Local key material for the dev/localhost target. In cloud this is replaced by a real KMS handle and
        # signing happens server-side (the material never leaves the HSM). Deterministic so verify is stable.
        env = os.getenv(f"KMS_KEY_{key_id}_{version}") or os.getenv("KMS_SECRET", "dev-kms-secret-change-me")
        return f"{env}:{key_id}:v{version}"

    def set_available(self, value: bool) -> None:
        self._available = value

    def _digest(self, material: str, payload: dict) -> str:
        return hmac.new(material.encode(), _canonical(payload), hashlib.sha256).hexdigest()

    def sign(self, payload: dict, tenant_id: Optional[str] = None) -> str:
        if not self._available:
            raise KmsUnavailableError(f"cloud KMS {self.key_id} unavailable")
        material = _tenant_key(self._keys[self._current], tenant_id)  # per-tenant isolation (AC-TEN-04)
        return f"sha256:{self._current}:{self._digest(material, payload)}"

    def verify(self, payload: dict, signature: str, tenant_id: Optional[str] = None) -> bool:
        # New format carries the key version; try per-tenant subkey then base key (legacy) for that version,
        # else fall back to trying every retained key.
        parts = signature.split(":")
        if len(parts) == 3:
            try:
                ver = int(parts[1])
            except ValueError:
                ver = None
            if ver in self._keys:
                for material in ([_tenant_key(self._keys[ver], tenant_id)] if tenant_id else []) + [self._keys[ver]]:
                    if hmac.compare_digest(f"sha256:{ver}:{self._digest(material, payload)}", signature):
                        return True
                return False
        return any(hmac.compare_digest(f"sha256:{v}:{self._digest(m, payload)}", signature)
                   for v, m in self._keys.items())

    def rotate(self, new_material: str) -> None:
        self._current += 1
        self._keys[self._current] = new_material  # new current; prior versions retained for verification


def _build_provider():
    if settings.kms_provider == "cloud":
        return CloudKMS(settings.kms_key_id)
    return SoftwareKMS([settings.kms_secret])


_provider = _build_provider()


def provider():
    return _provider


def sign(payload: dict, tenant_id: Optional[str] = None, *, attempts: int = 3, backoff: float = 0.0) -> str:
    """Sign with bounded retries. On exhaustion raises KmsUnavailableError so the caller can fail closed -
    a record is NEVER persisted unsigned (I2 / AC-11-I01). `tenant_id` selects a per-tenant key (AC-TEN-04)."""
    last: Exception = KmsUnavailableError("kms sign failed")
    for i in range(max(1, attempts)):
        try:
            return _provider.sign(payload, tenant_id)
        except KmsUnavailableError as e:
            last = e
            if backoff and i < attempts - 1:
                time.sleep(backoff)
    raise last


def verify(payload: dict, signature: str, tenant_id: Optional[str] = None) -> bool:
    return _provider.verify(payload, signature, tenant_id)


def rotate_key(new_secret: str) -> None:
    if isinstance(_provider, (SoftwareKMS, CloudKMS)):
        _provider.rotate(new_secret)


def set_available(value: bool) -> None:
    """Test/ops seam: toggle KMS availability to exercise the fail-closed commit path (AC-11-I01)."""
    if hasattr(_provider, "set_available"):
        _provider.set_available(value)
