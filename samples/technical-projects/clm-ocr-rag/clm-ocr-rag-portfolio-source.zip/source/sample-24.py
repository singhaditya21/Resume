"""
Cross-encoder reranker for improving retrieval precision.

After initial vector search retrieves a broad set of candidates,
the reranker scores each (query, chunk) pair with a cross-encoder
and returns only the top-N most relevant chunks.
"""

from __future__ import annotations

import time

from loguru import logger
from sentence_transformers import CrossEncoder

_reranker: CrossEncoder | None = None

RERANKER_MODEL = "REDACTED_OPAQUE_VALUE"


def get_reranker() -> CrossEncoder:
    """Load the cross-encoder model (singleton)."""
    global _reranker
    if _reranker is None:
        logger.info(f"Loading reranker model: {RERANKER_MODEL}")
        t0 = time.perf_counter()
        _reranker = CrossEncoder(RERANKER_MODEL, max_length=512, device="cpu")
        logger.info(f"Reranker model loaded in {time.perf_counter()-t0:.1f}s")
    return _reranker


def rerank(
    query: str,
    candidates: list[dict],
    top_n: int = 5,
) -> list[dict]:
    """
    Re-score and re-order retrieved chunks using a cross-encoder.

    Args:
        query:      User's question.
        candidates: List of dicts from initial retrieval (must have 'text' key).
        top_n:      Number of top results to return after reranking.

    Returns:
        Top-N candidates sorted by cross-encoder score (highest first).
    """
    if not candidates:
        return []
    if len(candidates) <= top_n:
        # Not enough candidates to rerank meaningfully
        return candidates

    reranker = get_reranker()

    # Build (query, chunk_text) pairs
    pairs = [(query, c["text"][:1000]) for c in candidates]  # truncate for speed

    t0 = time.perf_counter()
    scores = reranker.predict(pairs)
    elapsed = time.perf_counter() - t0

    # Attach scores and sort
    scored = list(zip(candidates, scores))
    scored.sort(key=lambda x: x[1], reverse=True)

    top = [item for item, _ in scored[:top_n]]
    logger.info(
        f"Reranked {len(candidates)}→{top_n} in {elapsed:.2f}s  "
        f"(best={scored[0][1]:.3f}, worst-kept={scored[top_n-1][1]:.3f})"
    )
    return top
