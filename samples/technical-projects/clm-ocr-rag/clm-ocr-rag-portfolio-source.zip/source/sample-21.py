"""Benchmark a non-cached RAG query (full pipeline)."""
import requests, time

API = "http://localhost:8000"

# This query should NOT be in QA cache - forces full RAG pipeline
questions = [
    "What are the intellectual property rights and data ownership clauses across all contracts?",
    "List the force majeure provisions in any of the agreements",
    "What is the governing law jurisdiction mentioned in the Jana Small escrow agreement?",
]

print("=== Full RAG Pipeline Benchmark (non-cached queries) ===")
for q in questions:
    t0 = time.time()
    r = requests.post(f"{API}/query", json={"question": q, "top_k": 5}, timeout=180)
    elapsed = time.time() - t0
    d = r.json()
    qt = d.get("query_type", "?")
    ans_len = len(d.get("answer", ""))
    qa_match = d.get("qa_match", None)
    if qa_match:
        print(f"  [{elapsed:.1f}s] [{qt}] (QA match={qa_match:.2f}) {q[:60]} ({ans_len}ch)")
    else:
        print(f"  [{elapsed:.1f}s] [{qt}] {q[:60]} ({ans_len}ch)")

print("\n=== Re-run same queries (should hit response cache) ===")
for q in questions:
    t0 = time.time()
    r = requests.post(f"{API}/query", json={"question": q, "top_k": 5}, timeout=120)
    elapsed = time.time() - t0
    d = r.json()
    qt = d.get("query_type", "?")
    print(f"  [{elapsed:.1f}s] [{qt}] {q[:60]}")
