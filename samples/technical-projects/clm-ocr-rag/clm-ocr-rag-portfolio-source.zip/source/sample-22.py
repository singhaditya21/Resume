"""
Render PDF pages to PNG images using Poppler's pdftoppm.
Used for scanned-PDF OCR fallback.
"""

import subprocess
import tempfile
from pathlib import Path

from loguru import logger

from app.config import PDFTOPPM_CMD, OCR_DPI


def render_pdf_to_images(pdf_path: str, output_dir: str | None = None) -> list[Path]:
    """
    Render every page of *pdf_path* to a PNG image at OCR_DPI.

    Args:
        pdf_path:   Path to the source PDF.
        output_dir: Directory for output PNGs (temp dir used if None).

    Returns:
        Sorted list of Path objects pointing to rendered PNGs.
    """
    if output_dir is None:
        output_dir = tempfile.mkdtemp(prefix="pdfrender_")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    prefix = out / "page"
    cmd = [
        PDFTOPPM_CMD,
        "-png",
        "-r", str(OCR_DPI),
        str(pdf_path),
        str(prefix),
    ]
    logger.info(f"Running pdftoppm: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except FileNotFoundError:
        logger.error(
            "pdftoppm not found! Install Poppler for Windows and add to PATH. "
            "See README.md for instructions."
        )
        raise RuntimeError("pdftoppm (Poppler) is not installed or not on PATH.")
    except subprocess.CalledProcessError as e:
        logger.error(f"pdftoppm failed: {e.stderr}")
        raise

    images = sorted(out.glob("page-*.png"))
    logger.info(f"Rendered {len(images)} page images from {pdf_path}")
    return images
