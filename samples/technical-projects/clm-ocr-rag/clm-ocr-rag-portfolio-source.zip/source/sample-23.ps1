# ─────────────────────────────────────────────────────────────────────────
# ingest_contracts_folder.ps1  –  Trigger reindex of CONTRACTS_DIR
# ─────────────────────────────────────────────────────────────────────────

$apiBase = "http://127.0.0.1:8000"

Write-Host "Triggering reindex of contracts folder..." -ForegroundColor Cyan

try {
    $response = Invoke-RestMethod -Uri "$apiBase/reindex" -Method POST -ContentType "application/json"
    Write-Host "`n═══════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  Reindex Results" -ForegroundColor Cyan
    Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  Added:   $($response.added)" -ForegroundColor Green
    Write-Host "  Skipped: $($response.skipped)" -ForegroundColor DarkYellow
    Write-Host "  Failed:  $($response.failed)" -ForegroundColor $(if ($response.failed -gt 0) { "Red" } else { "Green" })
    Write-Host "  Total:   $($response.total_files) files" -ForegroundColor White
    Write-Host "  Time:    $($response.time_s)s" -ForegroundColor White
    Write-Host "═══════════════════════════════════════════════════`n" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Failed to connect to API at $apiBase" -ForegroundColor Red
    Write-Host "   Make sure the API server is running: .\scripts\run_api.ps1" -ForegroundColor Yellow
    exit 1
}
