"""Extract ALL chunks from every indexed contract — no limit."""
import sys, os

# Set up PYTHONPATH so `app.*` imports work
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

from app.retrieval.retriever import retrieve_by_doc
from app.ingest.registry import list_documents

docs = list_documents()
print(f"Found {len(docs)} documents in registry\n")

out_path = os.path.join(ROOT, "scripts", "all_chunks_output.txt")
out = open(out_path, "w", encoding="utf-8")

total_chunks = 0
for info in docs:
    doc_id = info.get("doc_id", "")
    name = info.get("filename", doc_id)
    chunks = retrieve_by_doc(doc_id, max_chunks=500)
    total_chunks += len(chunks)
    out.write(f"\n{'='*80}\n")
    out.write(f"DOCUMENT: {name}  (doc_id: {doc_id})\n")
    out.write(f"TOTAL CHUNKS: {len(chunks)}\n")
    out.write(f"{'='*80}\n\n")
    for i, c in enumerate(chunks):
        page = c.get("page_start", "?")
        out.write(f"--- Chunk {i+1} | Page {page} ---\n")
        out.write(c.get("text", "") + "\n\n")
    print(f"  {name}: {len(chunks)} chunks")

out.close()
print(f"\nTotal: {total_chunks} chunks from {len(docs)} documents")
print(f"Written to: {out_path}")
