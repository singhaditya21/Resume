"""
OCR pipeline orchestrator.

For each file:
  - PDF: try digital extraction first; fall back to OCR if avg chars < threshold.
  - Image: OCR directly.
Produces a page-mapped dict {page_num: text}.
Caches OCR results by (file_hash + page_index).
"""

import hashlib
import json
import shutil
import tempfile
from pathlib import Path

import pytesseract
from PIL import Image
from loguru import logger

from app.config import (
    OCR_CACHE_DIR,
    OCR_CONFIG,
    SCANNED_THRESHOLD,
    TESSERACT_CMD,
)
from app.ocr.pdf_render import render_pdf_to_images
from app.ocr.pdf_text_extract import avg_chars_per_page, extract_text_from_pdf
from app.ocr.text_cleaner import clean_ocr_text

# Point pytesseract to the tesseract binary if overridden
pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD


# ── Helpers ───────────────────────────────────────────────────────────────

def compute_sha256(filepath: str) -> str:
    """Return hex sha256 of a file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_key(file_hash: str, page: int) -> Path:
    return OCR_CACHE_DIR / f"{file_hash}_p{page}.txt"


def _read_cache(file_hash: str, page: int) -> str | None:
    p = _cache_key(file_hash, page)
    if p.exists():
        return p.read_text(encoding="utf-8")
    return None


def _write_cache(file_hash: str, page: int, text: str) -> None:
    p = _cache_key(file_hash, page)
    p.write_text(text, encoding="utf-8")


def ocr_image(image_path: str) -> str:
    """Run Tesseract OCR on a single image file."""
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, config=OCR_CONFIG)
        return text.strip()
    except Exception as e:
        logger.error(f"Tesseract OCR failed on {image_path}: {e}")
        return ""


# ── Main pipeline ─────────────────────────────────────────────────────────

def process_file(filepath: str, file_hash: str | None = None) -> dict[int, str]:
    """
    Extract text from a PDF or image file.

    Args:
        filepath:  Absolute path to the file.
        file_hash: Pre-computed sha256 (computed if None).

    Returns:
        Dict mapping page number (1-indexed) → extracted text.
    """
    filepath = str(filepath)
    ext = Path(filepath).suffix.lower()
    if file_hash is None:
        file_hash = compute_sha256(filepath)

    if ext == ".pdf":
        return _process_pdf(filepath, file_hash)
    elif ext in {".png", ".jpg", ".jpeg", ".tiff"}:
        return _process_image(filepath, file_hash)
    else:
        raise ValueError(f"Unsupported file type: {ext}")


def _process_pdf(filepath: str, file_hash: str) -> dict[int, str]:
    """Digital-first extraction with scanned fallback."""
    logger.info(f"Processing PDF: {filepath}")

    # Step 1: try digital extraction
    pages = extract_text_from_pdf(filepath)
    avg = avg_chars_per_page(pages)
    logger.info(f"Digital extraction avg chars/page: {avg:.0f}")

    if avg >= SCANNED_THRESHOLD:
        logger.info("Treating as digital PDF")
        return {p: clean_ocr_text(t) for p, t in pages.items()}

    # Step 2: scanned PDF – render pages and OCR
    logger.info("Low text detected – treating as scanned PDF, running OCR")
    tmp_dir = tempfile.mkdtemp(prefix="ocr_render_")
    try:
        images = render_pdf_to_images(filepath, tmp_dir)
        ocr_pages: dict[int, str] = {}
        for idx, img_path in enumerate(images, start=1):
            cached = _read_cache(file_hash, idx)
            if cached is not None:
                logger.debug(f"Page {idx}: using cached OCR")
                ocr_pages[idx] = cached
            else:
                text = ocr_image(str(img_path))
                text = clean_ocr_text(text)
                _write_cache(file_hash, idx, text)
                ocr_pages[idx] = text
                logger.debug(f"Page {idx}: OCR'd {len(text)} chars")
        return ocr_pages
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _process_image(filepath: str, file_hash: str) -> dict[int, str]:
    """OCR a single image (treated as page 1)."""
    logger.info(f"Processing image: {filepath}")
    cached = _read_cache(file_hash, 1)
    if cached is not None:
        logger.debug("Using cached OCR for image")
        return {1: cached}
    text = ocr_image(filepath)
    _write_cache(file_hash, 1, text)
    return {1: text}
