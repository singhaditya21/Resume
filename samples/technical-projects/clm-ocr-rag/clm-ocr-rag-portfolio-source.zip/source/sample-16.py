"""
ChromaDB vector store – persistent local storage.
"""

from __future__ import annotations

import chromadb
from loguru import logger

from app.config import CHROMA_COLLECTION, CHROMA_DIR

_client: chromadb.ClientAPI | None = None
_collection = None


def get_client() -> chromadb.ClientAPI:
    global _client
    if _client is None:
        logger.info(f"Initialising ChromaDB at {CHROMA_DIR}")
        _client = chromadb.PersistentClient(path=str(CHROMA_DIR))
    return _client


def get_collection():
    """Get or create the contracts collection."""
    global _collection
    if _collection is None:
        client = get_client()
        _collection = client.get_or_create_collection(
            name=CHROMA_COLLECTION,
            metadata={"hnsw:space": "cosine"},
        )
        logger.info(
            f"ChromaDB collection '{CHROMA_COLLECTION}' ready "
            f"({_collection.count()} vectors)"
        )
    return _collection
