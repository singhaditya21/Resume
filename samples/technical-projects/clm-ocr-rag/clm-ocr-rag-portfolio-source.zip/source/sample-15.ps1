# ─────────────────────────────────────────────────────────────────────────
# run_api.ps1  –  Start the FastAPI server
# ─────────────────────────────────────────────────────────────────────────

$root = Split-Path -Parent $PSScriptRoot

# Activate venv if present
$activateScript = Join-Path $root ".venv\Scripts\Activate.ps1"
if (Test-Path $activateScript) {
    . $activateScript
}

Write-Host "Starting Contract RAG Bot API on http://127.0.0.1:8000" -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop`n" -ForegroundColor DarkYellow

Set-Location $root
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --log-level info
