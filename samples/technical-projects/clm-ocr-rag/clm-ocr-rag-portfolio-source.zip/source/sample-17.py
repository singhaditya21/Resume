"""
Digital PDF text extraction using pdfplumber (page-by-page).
Returns {page_num: text} dict (1-indexed pages).
"""

import pdfplumber
from loguru import logger


def extract_text_from_pdf(pdf_path: str) -> dict[int, str]:
    """
    Extract text from each page of a digital PDF.

    Returns:
        dict mapping page number (1-indexed) → extracted text.
    """
    pages: dict[int, str] = {}
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                text = page.extract_text() or ""
                pages[i] = text
                logger.debug(f"Page {i}: {len(text)} chars extracted")
    except Exception as e:
        logger.error(f"pdfplumber failed on {pdf_path}: {e}")
        raise
    return pages


def avg_chars_per_page(pages: dict[int, str]) -> float:
    """Return average character count per page."""
    if not pages:
        return 0.0
    return sum(len(t) for t in pages.values()) / len(pages)
