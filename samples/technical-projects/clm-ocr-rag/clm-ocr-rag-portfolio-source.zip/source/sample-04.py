"""
LLM generation via llama.cpp OpenAI-compatible API.
Supports both blocking and streaming generation.
"""

from __future__ import annotations

import json
import time
from typing import Generator

import requests
from loguru import logger

from app.config import (
    LLAMA_CPP_CHAT_ENDPOINT,
    LLAMA_MAX_TOKENS,
    LLAMA_MODEL_NAME,
    LLAMA_REPEAT_PENALTY,
    LLAMA_TEMPERATURE,
)


def generate(messages: list[dict]) -> str:
    """
    Send chat-completion request to llama.cpp server (blocking).

    Returns:
        Generated text content.
    """
    payload = {
        "model": LLAMA_MODEL_NAME,
        "messages": messages,
        "max_tokens": LLAMA_MAX_TOKENS,
        "temperature": LLAMA_TEMPERATURE,
        "repeat_penalty": LLAMA_REPEAT_PENALTY,
        "frequency_penalty": 0.5,
        "seed": 42,
        "stream": False,
    }

    t0 = time.perf_counter()
    try:
        resp = requests.post(
            LLAMA_CPP_CHAT_ENDPOINT,
            json=payload,
            timeout=180,
        )
        resp.raise_for_status()
    except requests.ConnectionError:
        logger.error(
            f"Cannot connect to llama.cpp server at {LLAMA_CPP_CHAT_ENDPOINT}."
        )
        raise RuntimeError("llama.cpp server is not reachable.")
    except requests.HTTPError as e:
        logger.error(f"llama.cpp server error: {e} – {resp.text}")
        raise RuntimeError(f"llama.cpp server error: {resp.status_code}")

    elapsed = time.perf_counter() - t0
    data = resp.json()
    content = data["choices"][0]["message"]["content"]
    logger.info(f"LLM generation took {elapsed:.1f}s ({len(content)} chars)")
    return content


def generate_stream(messages: list[dict]) -> Generator[str, None, None]:
    """
    Stream chat-completion from llama.cpp server.
    Yields text chunks (delta content) as they arrive.
    """
    payload = {
        "model": LLAMA_MODEL_NAME,
        "messages": messages,
        "max_tokens": LLAMA_MAX_TOKENS,
        "temperature": LLAMA_TEMPERATURE,
        "repeat_penalty": LLAMA_REPEAT_PENALTY,
        "frequency_penalty": 0.5,
        "seed": 42,
        "stream": True,
    }

    t0 = time.perf_counter()
    try:
        resp = requests.post(
            LLAMA_CPP_CHAT_ENDPOINT,
            json=payload,
            timeout=180,
            stream=True,
        )
        resp.raise_for_status()
    except requests.ConnectionError:
        raise RuntimeError("llama.cpp server is not reachable.")
    except requests.HTTPError as e:
        if resp.status_code == 400:
            raise RuntimeError(
                "The query context is too large for the model. "
                "Try selecting a specific document or asking a shorter question."
            )
        raise RuntimeError(f"llama.cpp server error: {resp.status_code}")

    total_chars = 0
    # ── Loop detection: abort if same line repeats 3+ times ──
    recent_lines: list[str] = []
    buffer = ""
    repeat_limit = 3
    aborted = False

    for line in resp.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data: "):
            continue
        data_str = line[6:]  # strip "data: "
        if data_str.strip() == "[DONE]":
            break
        try:
            data = json.loads(data_str)
            delta = data.get("choices", [{}])[0].get("delta", {})
            content = delta.get("content", "")
            if content:
                total_chars += len(content)
                # ── Loop detection ──
                buffer += content
                while "\n" in buffer:
                    line_text, buffer = buffer.split("\n", 1)
                    stripped = line_text.strip()
                    if stripped and len(stripped) > 10:
                        recent_lines.append(stripped)
                        if len(recent_lines) > repeat_limit:
                            recent_lines.pop(0)
                        # Check if last N lines are identical
                        if (len(recent_lines) >= repeat_limit
                                and len(set(recent_lines)) == 1):
                            logger.warning(
                                f"Loop detected: '{stripped[:50]}' repeated "
                                f"{repeat_limit}x — aborting generation"
                            )
                            aborted = True
                            break
                if aborted:
                    yield "\n\n*[Generation stopped — repetitive output detected]*"
                    break
                yield content
        except json.JSONDecodeError:
            continue

    elapsed = time.perf_counter() - t0
    status = "ABORTED (loop)" if aborted else "ok"
    logger.info(f"LLM streaming took {elapsed:.1f}s ({total_chars} chars, {status})")
    if aborted:
        resp.close()


def is_llama_server_ready() -> bool:
    """Check if the llama.cpp server is responding."""
    try:
        resp = requests.get(
            LLAMA_CPP_CHAT_ENDPOINT.replace("/v1/chat/completions", "/health"),
            timeout=3,
        )
        return resp.status_code == 200
    except Exception:
        return False
