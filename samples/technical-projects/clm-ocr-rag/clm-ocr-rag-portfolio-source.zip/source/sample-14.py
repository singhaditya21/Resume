"""Temporary script to extract chunks from all indexed contracts."""
from app.retrieval.retriever import retrieve_by_doc
from app.ingest.registry import list_documents

docs = list_documents()
for doc in docs:
    doc_id = doc["doc_id"]
    fname = doc["filename"]
    chunks = retrieve_by_doc(doc_id, max_chunks=8)
    print(f"=== {fname} ({len(chunks)} chunks, {doc['page_count']} pages) ===")
    for c in chunks:
        pg = c.get("page_start", "?")
        text = c["text"][:600].replace("\n", " ").strip()
        print(f"  [p{pg}] {text}")
        print()
    print()
