"""List all QA-cached questions grouped by source file to a markdown file."""
import json, os
from pathlib import Path

qa_dir = Path("d:/CLMOCR/contract-rag-bot/data/qa")
out = Path("d:/CLMOCR/contract-rag-bot/scripts/qa_list.md")

lines = []
total = 0
for jpath in sorted(qa_dir.glob("*.jsonl")):
    questions = []
    for line in jpath.read_text(encoding="utf-8").strip().splitlines():
        try:
            entry = json.loads(line)
            q = entry.get("question", "").strip()
            if q:
                questions.append(q)
        except json.JSONDecodeError:
            continue
    
    doc_name = jpath.stem.replace("_pdf", "").replace("_", " ").title()
    lines.append(f"\n### {doc_name} ({len(questions)} questions)\n")
    for i, q in enumerate(questions, 1):
        lines.append(f"{i}. {q}")
    total += len(questions)

lines.insert(0, f"# QA Cache — All {total} Questions\n")
lines.append(f"\n---\n**TOTAL: {total} QA-cached questions**")

out.write_text("\n".join(lines), encoding="utf-8")
print(f"Wrote {total} questions to {out}")
