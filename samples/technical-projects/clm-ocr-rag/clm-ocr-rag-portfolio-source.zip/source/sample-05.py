"""
Retriever – query the vector DB, optionally rerank, and return results.
Supports both top-K and document-scoped retrieval.
"""

from __future__ import annotations

from loguru import logger

from app.config import DEFAULT_TOP_K
from app.retrieval.embedder import get_embedder
from app.retrieval.vectordb import get_collection


# Reranking settings
RERANK_ENABLED = True
RETRIEVAL_OVERSAMPLE = 12   # fetch this many from vector DB
RERANK_TOP_N = 5            # keep this many after reranking


def retrieve(
    query: str,
    top_k: int = DEFAULT_TOP_K,
    filters: dict | None = None,
) -> list[dict]:
    """
    Embed the query, search ChromaDB, and optionally rerank.

    Returns:
        List of result dicts with keys:
            doc_id, filename, page_start, page_end, score, text
    """
    embedder = get_embedder()
    q_vec = embedder.embed_query(query)
    collection = get_collection()

    # If reranking, fetch more candidates for the cross-encoder
    fetch_k = RETRIEVAL_OVERSAMPLE if RERANK_ENABLED else top_k

    query_params: dict = {
        "query_embeddings": [q_vec],
        "n_results": fetch_k,
    }
    if filters:
        query_params["where"] = filters

    try:
        results = collection.query(**query_params)
    except Exception as e:
        logger.error(f"ChromaDB query failed: {e}")
        return []

    items = _parse_results(results)
    logger.debug(f"Retrieved {len(items)} candidates (fetch_k={fetch_k})")

    # Rerank if enabled
    if RERANK_ENABLED and len(items) > top_k:
        try:
            from app.retrieval.reranker import rerank
            items = rerank(query, items, top_n=top_k)
        except Exception as e:
            logger.warning(f"Reranking failed, using vector scores: {e}")
            items = items[:top_k]
    else:
        items = items[:top_k]

    logger.debug(f"Returning {len(items)} chunks after reranking")
    return items


def hybrid_retrieve(
    query: str,
    top_k: int = DEFAULT_TOP_K,
    filters: dict | None = None,
) -> list[dict]:
    """
    Hybrid retrieval: vector search + BM25 keyword search, fused via RRF.

    Runs both searches concurrently via ThreadPoolExecutor for lower latency.
    Falls back to vector-only if BM25 index is not available.
    """
    import time
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from app.config import RRF_K
    from app.retrieval.bm25_search import get_bm25_index

    t0 = time.perf_counter()

    bm25_index = get_bm25_index()
    if not bm25_index.is_built:
        logger.debug("BM25 index not built, using vector-only")
        return retrieve(query, top_k=top_k, filters=filters)

    # Run vector and BM25 search concurrently
    with ThreadPoolExecutor(max_workers=2) as pool:
        vec_future = pool.submit(retrieve, query, top_k, filters)
        bm25_future = pool.submit(bm25_index.search, query, top_k, filters)

        vector_results = vec_future.result()
        bm25_results = bm25_future.result()

    if not bm25_results:
        return vector_results

    # Reciprocal Rank Fusion
    rrf_scores: dict[str, float] = {}
    all_items: dict[str, dict] = {}

    for rank, item in enumerate(vector_results):
        item_id = item["id"]
        rrf_scores[item_id] = rrf_scores.get(item_id, 0) + 1.0 / (RRF_K + rank + 1)
        all_items[item_id] = item

    for rank, item in enumerate(bm25_results):
        item_id = item["id"]
        rrf_scores[item_id] = rrf_scores.get(item_id, 0) + 1.0 / (RRF_K + rank + 1)
        if item_id not in all_items:
            all_items[item_id] = item

    # Sort by fused RRF score
    sorted_ids = sorted(rrf_scores, key=lambda x: rrf_scores[x], reverse=True)
    fused = []
    for item_id in sorted_ids[:top_k]:
        item = all_items[item_id]
        item["score"] = round(rrf_scores[item_id], 4)
        fused.append(item)

    # Count how many BM25-only results made it into top-k
    vector_ids = {r["id"] for r in vector_results}
    bm25_only = sum(1 for r in fused if r["id"] not in vector_ids)
    elapsed = time.perf_counter() - t0
    logger.info(
        f"Hybrid retrieval: {len(fused)} results in {elapsed:.2f}s "
        f"(vector={len(fused) - bm25_only}, bm25_only={bm25_only})"
    )

    return fused


def retrieve_by_doc(doc_id: str, max_chunks: int = 12) -> list[dict]:
    """
    Retrieve ALL chunks for a specific document, sorted by page/chunk order.
    Used for document-scoped queries (summarization).

    Args:
        doc_id: The document ID to retrieve all chunks for.
        max_chunks: Maximum chunks to return (to keep prompt reasonable).

    Returns:
        List of result dicts ordered by page_start, chunk_index.
    """
    collection = get_collection()

    try:
        results = collection.get(
            where={"doc_id": doc_id},
            limit=max_chunks,
        )
    except Exception as e:
        logger.error(f"ChromaDB get failed for doc_id={doc_id}: {e}")
        return []

    if not results or not results.get("ids"):
        return []

    items = []
    ids = results["ids"]
    docs = results.get("documents", [""] * len(ids))
    metas = results.get("metadatas", [{}] * len(ids))

    for i, _id in enumerate(ids):
        meta = metas[i] or {}
        items.append({
            "id": _id,
            "doc_id": meta.get("doc_id", ""),
            "filename": meta.get("filename", ""),
            "page_start": meta.get("page_start", 0),
            "page_end": meta.get("page_end", 0),
            "chunk_index": meta.get("chunk_index", 0),
            "score": 1.0,  # all chunks are relevant for doc-scoped
            "text": docs[i],
        })

    # Sort by page order
    items.sort(key=lambda x: (x["page_start"], x["chunk_index"]))
    logger.info(f"Doc-scoped retrieval: {len(items)} chunks for doc_id={doc_id}")
    return items


def _parse_results(results: dict) -> list[dict]:
    """Parse Chroma query results into a list of dicts."""
    items: list[dict] = []
    if not results or not results.get("ids"):
        return items

    ids = results["ids"][0]
    docs = results["documents"][0] if results.get("documents") else [""] * len(ids)
    metas = results["metadatas"][0] if results.get("metadatas") else [{}] * len(ids)
    dists = results["distances"][0] if results.get("distances") else [0.0] * len(ids)

    for i, _id in enumerate(ids):
        meta = metas[i] or {}
        score = round(1.0 - dists[i], 4) if dists[i] is not None else 0.0
        items.append({
            "id": _id,
            "doc_id": meta.get("doc_id", ""),
            "filename": meta.get("filename", ""),
            "page_start": meta.get("page_start", 0),
            "page_end": meta.get("page_end", 0),
            "chunk_index": meta.get("chunk_index", 0),
            "score": score,
            "text": docs[i],
        })

    return items
