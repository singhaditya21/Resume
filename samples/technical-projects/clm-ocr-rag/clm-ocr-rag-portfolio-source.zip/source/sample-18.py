"""Quick benchmark for optimized RAG bot."""
import requests, time

API = "http://localhost:8000"

queries = [
    "What is the termination clause in the CUSTOMER_REDACTED agreement?",
    "Who are the parties in AMC Security Bank agreement?",
    "What are the SLA penalties in CUSTOMER_REDACTED contract?",
]

print("=== Benchmark: Optimized RAG Bot ===")
for q in queries:
    t0 = time.time()
    r = requests.post(f"{API}/query", json={"question": q, "top_k": 5}, timeout=120)
    elapsed = time.time() - t0
    d = r.json()
    qt = d.get("query_type", "?")
    ans_len = len(d.get("answer", ""))
    match = d.get("qa_match", "")
    match_str = f" match={match:.2f}" if match else ""
    print(f"  [{elapsed:.1f}s] [{qt}]{match_str} {q[:55]} ({ans_len}ch)")

print("\n=== Re-run (should hit caches) ===")
for q in queries:
    t0 = time.time()
    r = requests.post(f"{API}/query", json={"question": q, "top_k": 5}, timeout=120)
    elapsed = time.time() - t0
    d = r.json()
    qt = d.get("query_type", "?")
    print(f"  [{elapsed:.1f}s] [{qt}] {q[:55]}")
