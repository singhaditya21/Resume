"""
Citation extraction and formatting from retrieved chunks.

Each citation includes: doc_id, filename, page, snippet (≤80 words).
"""

from __future__ import annotations


def build_citations(retrieved: list[dict], max_snippet_words: int = 80) -> list[dict]:
    """
    Build citation objects from retrieved chunks.

    Args:
        retrieved: List of retriever result dicts.
        max_snippet_words: Maximum words in the snippet.

    Returns:
        List of citation dicts with keys: doc_id, filename, page, snippet.
    """
    citations: list[dict] = []
    seen: set[tuple] = set()

    for r in retrieved:
        doc_id = r.get("doc_id", "")
        filename = r.get("filename", "")
        page = r.get("page_start", 0)
        text = r.get("text", "")

        # De-duplicate by (doc_id, page)
        key = (doc_id, page)
        if key in seen:
            continue
        seen.add(key)

        # Truncate snippet to max_snippet_words
        words = text.split()
        snippet = " ".join(words[:max_snippet_words])
        if len(words) > max_snippet_words:
            snippet += "…"

        citations.append({
            "doc_id": doc_id,
            "filename": filename,
            "page": page,
            "snippet": snippet,
        })

    return citations


def format_retrieved_for_response(retrieved: list[dict]) -> list[dict]:
    """
    Format retrieved chunks for the API response's 'retrieved' field.
    Includes a text_preview (first 200 chars).
    """
    items = []
    for r in retrieved:
        items.append({
            "doc_id": r.get("doc_id", ""),
            "filename": r.get("filename", ""),
            "page_start": r.get("page_start", 0),
            "page_end": r.get("page_end", 0),
            "score": r.get("score", 0.0),
            "text_preview": (r.get("text", ""))[:200],
        })
    return items
