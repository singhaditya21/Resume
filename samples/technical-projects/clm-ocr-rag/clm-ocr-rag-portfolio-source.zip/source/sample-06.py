"""
Contract RAG Bot – FastAPI Application.

Endpoints:
  POST /ingest           – Upload and ingest a file
  POST /reindex          – Scan CONTRACTS_DIR, ingest new/changed files
  POST /query            – RAG query with citations (blocking)
  POST /query/stream     – RAG query with SSE streaming
  POST /export           – Export Q&A as Word document
  GET  /documents        – List ingested documents
  DELETE /documents/{id} – Remove a document
  GET  /health           – Health check
  GET  /                 – Serve UI
"""

from __future__ import annotations

import json
import shutil
import tempfile
import time
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from loguru import logger
from pydantic import BaseModel

from app.config import (
    ALLOWED_EXTENSIONS,
    API_KEY,
    CONTRACTS_DIR,
    HOST,
    MAX_FILE_SIZE_MB,
    PORT,
)
from app.ingest.folder_watcher import scan_and_ingest
from app.ingest.ingest_service import delete_document, ingest_file
from app.ingest.registry import list_documents as registry_list
from app.rag.cite import build_citations, format_retrieved_for_response
from app.rag.cache import clear_all_caches, get_response_cache
from app.rag.generate import generate, generate_stream, is_llama_server_ready
from app.rag.prompts import build_messages
from app.rag.query_router import route_query
from app.retrieval.retriever import hybrid_retrieve, retrieve, retrieve_by_doc

# ── App ───────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Contract RAG Bot",
    description="Local OCR + RAG for contract documents",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static UI files
UI_DIR = Path(__file__).resolve().parent.parent / "ui" / "static"
if UI_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")


@app.on_event("startup")
async def startup_warmup():
    """Preload ML models and QA cache to eliminate cold-start latency."""
    logger.info("Warming up ML models...")
    try:
        from app.retrieval.embedder import get_embedder
        embedder = get_embedder()  # loads sentence-transformer
        from app.retrieval.reranker import get_reranker
        get_reranker()  # loads cross-encoder
        # Build BM25 index (loads from disk or rebuilds)
        from app.retrieval.bm25_search import get_bm25_index
        get_bm25_index()
        # Load Q&A lookup cache (pre-embed 466 questions)
        from app.rag.qa_cache import get_qa_cache
        qa = get_qa_cache()
        qa.load(embedder)
        logger.info(f"QA lookup cache loaded: {qa.size} pairs")
        logger.info("ML models warmed up ✓")
    except Exception as e:
        logger.warning(f"Model warmup failed (will load on demand): {e}")


# ── Middleware: optional API key ──────────────────────────────────────────

@app.middleware("http")
async def check_api_key(request: Request, call_next):
    if API_KEY:
        path = request.url.path
        if not path.startswith("/static") and path not in ("/health", "/"):
            key = request.headers.get("X-API-Key", "")
            if key != API_KEY:
                return JSONResponse(status_code=401, content={"detail": "Invalid API key"})
    return await call_next(request)


# ── Models ────────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    question: str
    filters: Optional[dict] = None
    top_k: Optional[int] = 8
    history: Optional[list[dict]] = None  # conversation history


class QueryResponse(BaseModel):
    answer: str
    citations: list[dict]
    retrieved: list[dict]


# ── Helpers ───────────────────────────────────────────────────────────────

def _build_chroma_filter(filters: dict | None) -> dict | None:
    """Build ChromaDB where-filter from request filters."""
    if not filters:
        return None
    if filters.get("doc_id"):
        ids = filters["doc_id"]
        if isinstance(ids, list) and len(ids) == 1:
            return {"doc_id": ids[0]}
        elif isinstance(ids, list) and len(ids) > 1:
            return {"doc_id": {"$in": ids}}
    elif filters.get("filename"):
        fnames = filters["filename"]
        if isinstance(fnames, list) and len(fnames) == 1:
            return {"filename": fnames[0]}
        elif isinstance(fnames, list) and len(fnames) > 1:
            return {"filename": {"$in": fnames}}
    return None


def _smart_retrieve(question: str, top_k: int, filters: dict | None, explicit_doc_ids: list | None = None):
    """
    Smart retrieval using query routing.
    Returns (retrieved, query_type).
    """
    from app.rag.cache import get_retrieval_cache

    routed = route_query(question, explicit_doc_ids=explicit_doc_ids)

    # Check retrieval cache for extract queries
    retrieval_cache = get_retrieval_cache()
    chroma_filter = _build_chroma_filter(filters)
    if routed.query_type == "extract":
        cached = retrieval_cache.get(question, chroma_filter)
        if cached:
            logger.info(f"Retrieval cache HIT for: {question[:50]}...")
            return cached, routed.query_type

    if routed.query_type == "summarize" and routed.target_doc_ids:
        # Check for pre-generated summary first (instant response)
        from app.rag.summarizer import get_cached_summary
        cached_summary = get_cached_summary(routed.target_doc_ids[0])
        if cached_summary:
            logger.info(f"Serving pre-generated summary for {routed.target_doc_ids[0]}")
            # Return empty retrieved — the summary will be served directly
            return [{"text": cached_summary, "filename": routed.target_filenames[0] if routed.target_filenames else "", "page_start": 1, "page_end": 1, "doc_id": routed.target_doc_ids[0], "score": 1.0, "_presummary": True}], "summarize"

        # Document-scoped: get key chunks from the target document
        retrieved = []
        for doc_id in routed.target_doc_ids[:1]:  # max 1 doc for summarize (context budget)
            retrieved.extend(retrieve_by_doc(doc_id, max_chunks=8))
        if not retrieved:
            # Fallback to normal retrieval
            retrieved = retrieve(question, top_k=top_k, filters=chroma_filter)
    elif routed.query_type == "compare" and routed.target_doc_ids:
        # Comparison: retrieve from each named doc
        retrieved = []
        for doc_id in routed.target_doc_ids[:4]:
            chunks = retrieve_by_doc(doc_id, max_chunks=6)
            retrieved.extend(chunks)
        if not retrieved:
            retrieved = retrieve(question, top_k=top_k, filters=chroma_filter)
    else:
        # Standard extraction: normal top-K with reranking
        # If router matched specific docs, filter to those docs
        if not chroma_filter and routed.target_doc_ids:
            # Auto-scoped: query mentioned specific document(s)
            logger.info(f"Auto-scoping extract to: {routed.target_filenames}")
            if len(routed.target_doc_ids) == 1:
                chroma_filter = {"doc_id": routed.target_doc_ids[0]}
            else:
                chroma_filter = {"doc_id": {"$in": routed.target_doc_ids}}
        from app.config import HYBRID_ENABLED
        if HYBRID_ENABLED:
            retrieved = hybrid_retrieve(question, top_k=top_k, filters=chroma_filter)
        else:
            retrieved = retrieve(question, top_k=top_k, filters=chroma_filter)

    # Store in retrieval cache
    if retrieved and routed.query_type == "extract":
        retrieval_cache.put(question, chroma_filter, retrieved)

    return retrieved, routed.query_type


# ── Routes ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """Serve the main UI page."""
    index_path = UI_DIR / "index.html"
    if index_path.exists():
        return HTMLResponse(content=index_path.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>Contract RAG Bot</h1><p>UI not found.</p>")


@app.get("/analytics", response_class=HTMLResponse)
async def serve_analytics():
    """Serve the analytics dashboard."""
    analytics_path = UI_DIR / "static" / "analytics.html"
    if analytics_path.exists():
        return HTMLResponse(content=analytics_path.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>Analytics</h1><p>Dashboard not found.</p>")


@app.get("/health")
async def health():
    """Health check including llama.cpp server status."""
    llama_ok = is_llama_server_ready()
    return {
        "status": "ok",
        "llama_cpp_server": "connected" if llama_ok else "not reachable",
        "contracts_dir": str(CONTRACTS_DIR),
    }


@app.post("/ingest")
async def ingest_upload(file: UploadFile = File(...)):
    """Upload and ingest a single file."""
    t0 = time.perf_counter()
    filename = file.filename or "unknown"
    ext = Path(filename).suffix.lower()

    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Allowed: {ALLOWED_EXTENSIONS}")

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
    try:
        content = await file.read()
        if len(content) > MAX_FILE_SIZE_MB * 1024 * 1024:
            raise HTTPException(400, f"File exceeds {MAX_FILE_SIZE_MB} MB limit")
        tmp.write(content)
        tmp.close()

        dest = CONTRACTS_DIR / filename
        if not dest.exists():
            shutil.copy2(tmp.name, str(dest))
            logger.info(f"Copied uploaded file to {dest}")

        result = ingest_file(tmp.name)
        result["full_path"] = str(dest)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Ingest failed for {filename}: {e}")
        raise HTTPException(500, f"Ingest error: {e}")
    finally:
        Path(tmp.name).unlink(missing_ok=True)

    result["time_s"] = round(time.perf_counter() - t0, 2)
    return result


@app.post("/reindex")
async def reindex():
    """Scan CONTRACTS_DIR and ingest new/changed files."""
    logger.info(f"Reindex triggered for {CONTRACTS_DIR}")
    summary = scan_and_ingest()
    # Rebuild BM25 index after reindex
    from app.retrieval.bm25_search import rebuild_bm25_index
    rebuild_bm25_index()
    # Invalidate all caches after reindex
    cache_info = clear_all_caches()
    summary["caches_cleared"] = cache_info
    return summary


@app.post("/query")
async def query(req: QueryRequest):
    """RAG query: route → retrieve → generate → cite."""
    t0 = time.perf_counter()
    question = req.question.strip()
    if not question:
        raise HTTPException(400, "Question cannot be empty")

    top_k = req.top_k or 8

    # Extract explicit doc filter
    explicit_doc_ids = None
    if req.filters and req.filters.get("doc_id"):
        explicit_doc_ids = req.filters["doc_id"]

    # ── Check Q&A lookup cache (instant answer) ───────────────────────
    from app.rag.qa_cache import get_qa_cache
    from app.retrieval.embedder import get_embedder
    qa_cache = get_qa_cache()
    if qa_cache.loaded:
        qa_hit = qa_cache.lookup(question, get_embedder())
        if qa_hit:
            elapsed = round(time.perf_counter() - t0, 4)
            return {
                "answer": qa_hit["answer"],
                "citations": [{"source": qa_hit["source"], "page": qa_hit["page"]}] if qa_hit["source"] else [],
                "retrieved": [],
                "time_s": elapsed,
                "query_type": "qa_cache",
                "qa_match": qa_hit["similarity"],
            }

    # Smart retrieval with query routing
    retrieved, query_type = _smart_retrieve(question, top_k, req.filters, explicit_doc_ids)

    if not retrieved:
        return {
            "answer": "No matching content was retrieved from the contracts.",
            "citations": [],
            "retrieved": [],
            "time_s": round(time.perf_counter() - t0, 2),
            "query_type": query_type,
        }

    # Generate with query-type-specific prompt
    messages = build_messages(question, retrieved, query_type=query_type, history=req.history)
    try:
        answer = generate(messages)
    except RuntimeError as e:
        logger.warning(f"LLM unavailable: {e}")
        answer = (
            "⚠️ LLM server not available. Here are the most relevant excerpt/opt/portfolio/project"
            + "\n\n".join(
                f"[{r['filename']}, page {r['page_start']}]: {r['text'][:300]}"
                for r in retrieved[:3]
            )
        )

    citations = build_citations(retrieved)
    retrieved_formatted = format_retrieved_for_response(retrieved)
    elapsed = round(time.perf_counter() - t0, 2)
    logger.info(f"Query answered in {elapsed}s (type={query_type})")

    return {
        "answer": answer,
        "citations": citations,
        "retrieved": retrieved_formatted,
        "time_s": elapsed,
        "query_type": query_type,
    }


@app.post("/query/stream")
async def query_stream(req: QueryRequest):
    """
    Streaming RAG query: route → retrieve → generate SSE tokens → cite.
    Returns Server-Sent Events. Checks response cache first.
    """
    question = req.question.strip()
    if not question:
        raise HTTPException(400, "Question cannot be empty")

    top_k = req.top_k or 8
    explicit_doc_ids = None
    if req.filters and req.filters.get("doc_id"):
        explicit_doc_ids = req.filters["doc_id"]

    # ── Check Q&A lookup cache (instant answer from pre-generated pairs) ──
    from app.rag.qa_cache import get_qa_cache
    from app.retrieval.embedder import get_embedder
    qa_cache = get_qa_cache()
    if qa_cache.loaded:
        qa_hit = qa_cache.lookup(question, get_embedder())
        if qa_hit:
            qa_citations = [{"source": qa_hit["source"], "page": qa_hit["page"]}] if qa_hit["source"] else []
            async def qa_cached_response():
                sim_pct = f"{qa_hit['similarity']:.0%}"
                info_msg = f"\u26a1 QA cache hit (similarity: {sim_pct})"
                yield f"data: {json.dumps({'type': 'info', 'content': info_msg})}\n\n"
                yield f"data: {json.dumps({'type': 'token', 'content': qa_hit['answer']})}\n\n"
                yield f"data: {json.dumps({'type': 'done', 'citations': qa_citations, 'time_s': 0.0, 'query_type': 'qa_cache', 'cached': True})}\n\n"
            logger.info(f"QA cache HIT — instant answer for: {question[:50]}...")
            return StreamingResponse(qa_cached_response(), media_type="text/event-stream")

    # ── Check response cache ──────────────────────────────────────────
    cache = get_response_cache()
    doc_ids_for_cache = explicit_doc_ids if explicit_doc_ids else None
    cached = cache.get(question, doc_ids_for_cache)
    if cached:  # serve cached response instantly
        async def cached_response():
            # Send retrieval info
            yield f"data: {json.dumps({'type': 'info', 'content': '⚡ Serving from cache'})}\n\n"
            # Stream cached answer in one chunk
            yield f"data: {json.dumps({'type': 'token', 'content': cached['answer']})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'citations': cached['citations'], 'time_s': 0.0, 'query_type': cached['query_type'], 'cached': True})}\n\n"
        logger.info(f"Response cache HIT — returning instantly for: {question[:50]}...")
        return StreamingResponse(cached_response(), media_type="text/event-stream")

    # ── Smart retrieval with query routing ─────────────────────────────
    retrieved, query_type = _smart_retrieve(question, top_k, req.filters, explicit_doc_ids)

    if not retrieved:
        async def no_results():
            yield f"data: {json.dumps({'type': 'token', 'content': 'No matching content was retrieved from the contracts.'})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'citations': [], 'query_type': query_type})}\n\n"
        return StreamingResponse(no_results(), media_type="text/event-stream")

    # Build messages with routing + history
    messages = build_messages(question, retrieved, query_type=query_type, history=req.history)
    citations = build_citations(retrieved)

    # ── Send retrieval info before LLM starts ─────────────────────────
    doc_names = list({r['filename'] for r in retrieved})
    retrieval_info = f"📄 Retrieved {len(retrieved)} clauses from {', '.join(doc_names[:3])}"

    def event_generator():
        # Send retrieval info first
        yield f"data: {json.dumps({'type': 'info', 'content': retrieval_info, 'doc_count': len(doc_names), 'chunk_count': len(retrieved)})}\n\n"

        t0 = time.perf_counter()
        full_answer = []
        try:
            for chunk in generate_stream(messages):
                full_answer.append(chunk)
                yield f"data: {json.dumps({'type': 'token', 'content': chunk})}\n\n"
        except RuntimeError as e:
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

        elapsed = round(time.perf_counter() - t0, 2)

        # Store in response cache (only first-turn queries without history)
        answer_text = "".join(full_answer)
        if answer_text and not req.history:
            cache.put(question, doc_ids_for_cache, answer_text, citations, query_type, elapsed)

        yield f"data: {json.dumps({'type': 'done', 'citations': citations, 'time_s': elapsed, 'query_type': query_type})}\n\n"

        # Log to analytics (non-blocking)
        try:
            from app.analytics import log_query
            log_query(
                question=question,
                query_type=query_type,
                response_time_s=elapsed,
                doc_ids=doc_names,
                chunk_count=len(retrieved),
                cached=False,
                answer_length=len(answer_text),
            )
        except Exception:
            pass  # analytics should never break the response

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/documents")
async def list_docs():
    """List all ingested documents from registry."""
    docs = registry_list()
    return {"documents": docs, "count": len(docs)}


@app.delete("/documents/{doc_id}")
async def remove_doc(doc_id: str):
    """Delete a document from registry and vector DB."""
    success = delete_document(doc_id)
    if not success:
        raise HTTPException(404, f"Document '{doc_id}' not found")
    # Invalidate caches when document is removed
    clear_all_caches()
    return {"status": "deleted", "doc_id": doc_id}


@app.get("/cache/stats")
async def cache_stats():
    """Return current cache sizes."""
    from app.rag.cache import get_embedding_cache, get_retrieval_cache
    from app.rag.qa_cache import get_qa_cache
    return {
        "qa_lookup_cache": get_qa_cache().size,
        "response_cache": get_response_cache().size,
        "retrieval_cache": get_retrieval_cache().size,
        "embedding_cache": get_embedding_cache().size,
    }


@app.post("/cache/clear")
async def cache_clear():
    """Manually clear all caches."""
    info = clear_all_caches()
    return {"status": "cleared", "previous_sizes": info}


# ── Export ─────────────────────────────────────────────────────────────────

class ExportRequest(BaseModel):
    question: str
    answer: str
    citations: list[dict] = []


@app.post("/export")
async def export_word(req: ExportRequest):
    """Export a Q&A exchange as a Word document."""
    from app.rag.word_export import export_answer_to_docx
    buffer = export_answer_to_docx(req.question, req.answer, req.citations)
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": 'attachment; filename="contract_analysis.docx"'},
    )


# ── Contract Intelligence Endpoints ───────────────────────────────────────

@app.get("/documents/{doc_id}/metadata")
async def doc_metadata(doc_id: str):
    """Return extracted metadata for a document."""
    from app.ingest.registry import get_document
    doc = get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    return {
        "doc_id": doc_id,
        "filename": doc.get("filename"),
        "metadata": doc.get("metadata", {}),
        "has_summary": bool(doc.get("summary")),
    }


@app.get("/documents/{doc_id}/obligations")
async def doc_obligations(doc_id: str):
    """Extract and return obligations for a document."""
    from app.rag.obligation_tracker import extract_obligations
    obligations = extract_obligations(doc_id)
    return {"doc_id": doc_id, "obligations": obligations, "count": len(obligations)}


@app.get("/obligations/upcoming")
async def upcoming_obligations():
    """Return obligations across all documents, sorted by urgency."""
    from app.ingest.registry import list_documents
    from app.rag.obligation_tracker import extract_obligations

    all_obligations = []
    for doc in list_documents():
        try:
            obs = extract_obligations(doc["doc_id"], max_chunks=10)
            all_obligations.extend(obs)
        except Exception:
            continue

    # Sort: critical first, then high, then normal
    urgency_order = {"critical": 0, "high": 1, "normal": 2}
    all_obligations.sort(key=lambda x: urgency_order.get(x.get("urgency", "normal"), 2))
    return {"obligations": all_obligations[:50], "total": len(all_obligations)}


@app.post("/documents/{doc_id}/summarize")
async def generate_doc_summary(doc_id: str):
    """Generate or return a cached summary for a document."""
    from app.rag.summarizer import generate_summary, get_cached_summary

    cached = get_cached_summary(doc_id)
    if cached:
        return {"doc_id": doc_id, "summary": cached, "cached": True}

    summary = generate_summary(doc_id)
    if summary:
        return {"doc_id": doc_id, "summary": summary, "cached": False}
    raise HTTPException(500, "Could not generate summary")


@app.get("/documents/{doc_id}/pdf")
async def serve_pdf(doc_id: str):
    """Serve the original PDF file for viewing."""
    from app.ingest.registry import get_document
    doc = get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    pdf_path = Path(doc.get("full_path", ""))
    if not pdf_path.exists() or pdf_path.suffix.lower() != ".pdf":
        raise HTTPException(404, "PDF file not found")
    return FileResponse(str(pdf_path), media_type="application/pdf", filename=pdf_path.name)


# ── Analytics Endpoints ───────────────────────────────────────────────────

@app.get("/analytics/stats")
async def analytics_stats():
    """Return aggregate query statistics."""
    from app.analytics import get_stats
    return get_stats()


@app.get("/analytics/recent")
async def analytics_recent(limit: int = 20):
    """Return recent queries."""
    from app.analytics import get_recent
    return get_recent(limit=min(limit, 100))


@app.get("/analytics/trend")
async def analytics_trend(days: int = 7):
    """Return daily response time trends."""
    from app.analytics import get_response_time_trend
    return get_response_time_trend(days=min(days, 30))


# ── Entrypoint ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    logger.info(f"Starting Contract RAG Bot on {HOST}:{PORT}")
    uvicorn.run(
        "app.main:app",
        host=HOST,
        port=PORT,
        reload=False,
        log_level="info",
    )
