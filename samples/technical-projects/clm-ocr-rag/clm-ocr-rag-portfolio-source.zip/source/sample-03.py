"""
Ingest service – full pipeline:
  hash → OCR → chunk → embed → store in vector DB → register.
"""

from __future__ import annotations

import time
from pathlib import Path

from loguru import logger

from app.config import ALLOWED_EXTENSIONS, MAX_FILE_SIZE_MB
from app.ingest.chunking import chunk_pages
from app.ingest.registry import find_by_sha256, register_document
from app.ocr.ocr_pipeline import compute_sha256, process_file
from app.ocr.text_cleaner import clean_pages
from app.retrieval.embedder import get_embedder
from app.retrieval.vectordb import get_collection


def validate_file(filepath: str) -> None:
    """Raise ValueError if extension or size is invalid."""
    p = Path(filepath)
    if p.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError(
            f"Unsupported extension '{p.suffix}'. Allowed: {ALLOWED_EXTENSIONS}"
        )
    size_mb = p.stat().st_size / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise ValueError(f"File too large ({size_mb:.1f} MB > {MAX_FILE_SIZE_MB} MB)")


def ingest_file(
    filepath: str,
    *,
    force: bool = False,
) -> dict:
    """
    Full ingestion pipeline for a single file.

    Returns a summary dict with keys: doc_id, filename, status, page_count, chunk_count.
    Skips if sha256 already in registry (unless force=True).
    """
    t0 = time.perf_counter()
    p = Path(filepath)
    filename = p.name
    validate_file(filepath)

    # 1. Hash
    file_hash = compute_sha256(filepath)
    doc_id = file_hash[:16]  # short ID from hash prefix

    # 2. Dedup check
    if not force:
        existing = find_by_sha256(file_hash)
        if existing:
            logger.info(f"Skipping {filename} – already indexed (sha256 match)")
            return {
                "doc_id": existing["doc_id"],
                "filename": filename,
                "status": "skipped",
                "page_count": existing.get("page_count", 0),
                "chunk_count": 0,
                "time_s": 0,
            }

    # 3. OCR / extraction
    logger.info(f"Extracting text from {filename}")
    pages = process_file(filepath, file_hash=file_hash)

    # 3b. Cross-page OCR cleanup (headers, footers, page numbers, watermarks)
    pages = clean_pages(pages)

    # 3c. Extract contract metadata (parties, dates, type, value)
    from app.ingest.metadata_extractor import extract_metadata
    try:
        metadata = extract_metadata(pages)
        if metadata:
            logger.info(f"Extracted metadata: {list(metadata.keys())}")
    except Exception as e:
        logger.warning(f"Metadata extraction failed: {e}")
        metadata = {}

    # 4. Chunk
    chunks = chunk_pages(pages, doc_id=doc_id, filename=filename)
    logger.info(f"Created {len(chunks)} chunks from {len(pages)} pages")

    # 5. Embed
    embedder = get_embedder()
    texts = [c.text for c in chunks]
    embeddings = embedder.embed(texts)

    # 6. Store in Chroma
    collection = get_collection()
    ids = [f"{doc_id}_c{c.chunk_index}" for c in chunks]
    metadatas = [
        {
            "doc_id": doc_id,
            "filename": filename,
            "page_start": c.page_start,
            "page_end": c.page_end,
            "chunk_index": c.chunk_index,
        }
        for c in chunks
    ]

    # Delete old vectors for this doc_id if re-ingesting
    _delete_doc_vectors(collection, doc_id)

    if ids:
        collection.add(
            ids=ids,
            embeddings=embeddings,
            documents=texts,
            metadatas=metadatas,
        )

    # 7. Register
    register_document(
        doc_id=doc_id,
        filename=filename,
        full_path=str(p.resolve()),
        sha256=file_hash,
        page_count=len(pages),
    )

    # 7b. Store metadata in registry
    if metadata:
        from app.ingest.registry import update_metadata
        update_metadata(doc_id, metadata)

    elapsed = time.perf_counter() - t0
    logger.info(f"Ingested {filename} in {elapsed:.1f}s ({len(chunks)} chunks)")
    return {
        "doc_id": doc_id,
        "filename": filename,
        "status": "added",
        "page_count": len(pages),
        "chunk_count": len(chunks),
        "time_s": round(elapsed, 2),
        "metadata": metadata,
    }


def delete_document(doc_id: str) -> bool:
    """Remove a document from the vector DB and registry."""
    from app.ingest.registry import remove_document

    collection = get_collection()
    _delete_doc_vectors(collection, doc_id)
    return remove_document(doc_id)


def _delete_doc_vectors(collection, doc_id: str) -> None:
    """Remove all vectors belonging to a doc_id from ChromaDB."""
    try:
        results = collection.get(where={"doc_id": doc_id})
        if results and results["ids"]:
            collection.delete(ids=results["ids"])
            logger.debug(f"Deleted {len(results['ids'])} vectors for doc {doc_id}")
    except Exception as e:
        logger.warning(f"Could not delete vectors for {doc_id}: {e}")
