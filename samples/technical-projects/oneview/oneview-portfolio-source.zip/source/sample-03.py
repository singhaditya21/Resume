"""Assembles the per-customer QBR report payload.

Pulls from three source classes, mirroring the qbr-portal design reference:
  1. Adoption Analytics DB (live) — Overview & Platform KPIs, via metrics/*.
  2. FI Navigator export (snapshot) — the FI Growth block, via fi_navigator.
  3. BUSINESSNEXT CRM via Redash — Vision/Goals, OKRs, Roadmap, Decisions.
     Not wired up here, so those sections return available=False with the
     source that *would* feed them, exactly like the reference's "Not
     available" treatment. Nothing is estimated or faked.

Every value is pre-formatted to a `display` string here so the frontend is a
pure renderer; a value of None becomes {"na": True} and the UI shows the
shared "Not available" styling.
"""

import json

import qbr_redash
from db import get_cached_chart_insights, make_insight_cache_key, store_chart_insights
from insights import generate_crm_levers
from metrics import cases_metrics, complaints_metrics, leads_metrics, users_metrics

DB_SOURCE = "Adoption Analytics DB · live query"
FI_SOURCE = "FI Navigator export · snapshot"
FI_PROFILE_SOURCE = "FI Navigator Profile"
REDASH = "BUSINESSNEXT CRM · Redash"

# Curated, ordered metric selection per profile sheet — the export ships ~39
# metrics; the report surfaces the ones that matter for a QBR, grouped into
# named panels. Metrics not found in the export are simply skipped.
PROFILE_PANELS = [
    ("Profitability & Efficiency", "Profit", [
        "Return on Assets", "Return on Net Worth", "Net Interest Margin",
        "Operating Efficiency Ratio", "Non-Interest Expense", "Net Worth Leverage",
    ]),
    ("Growth", "Growth", [
        "Loan Growth Rate", "Share Account Growth", "Revenue Growth Rate",
        "Member Growth", "Share Accounts per Member", "Operating Fee Income",
    ]),
    ("Risk & Capital", "Risk", [
        "Net Worth Ratio", "Texas Ratio", "Funds Cost",
        "Loans Receivable to Shares", "Core Deposit Growth", "Quick Ratio",
    ]),
]

# FI institutions have no member-count field; deposit-account count is not the
# same thing, so member count is explicitly Not available (as in the reference).


def _na(reason=None):
    return {"na": True, "reason": reason}


def _pct(v, digits=1):
    if v is None:
        return _na()
    return {"display": f"{v * 100:.{digits}f}%", "value": v}


def _num(v):
    if v is None:
        return _na()
    return {"display": f"{v:,.0f}", "value": v}


def _hours(v):
    if v is None:
        return _na()
    return {"display": f"{v:.1f}h", "value": v}


def _money_k(v):
    """FI Navigator monetary values arrive in $thousands."""
    if v is None:
        return _na()
    dollars = v * 1000
    a = abs(dollars)
    if a >= 1e9:
        disp = f"${dollars / 1e9:.2f}B"
    elif a >= 1e6:
        disp = f"${dollars / 1e6:.1f}M"
    elif a >= 1e3:
        disp = f"${dollars / 1e3:.0f}K"
    else:
        disp = f"${dollars:,.0f}"
    return {"display": disp, "value": dollars}


def _money(v):
    """Adoption-DB monetary values are already in absolute dollars."""
    if v is None:
        return _na()
    a = abs(v)
    if a >= 1e9:
        disp = f"${v / 1e9:.2f}B"
    elif a >= 1e6:
        disp = f"${v / 1e6:.1f}M"
    elif a >= 1e3:
        disp = f"${v / 1e3:.0f}K"
    else:
        disp = f"${v:,.0f}"
    return {"display": disp, "value": v}


def _text(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return _na()
    return {"display": str(v), "value": v}


def _metric(label, cell, source, note=None):
    out = {"label": label, "source": source, **cell}
    if note:
        out["note"] = note
    return out


# ---- FI Growth (FI Navigator Profile — preferred) ----

def _fmt_unit(v, unit, digits=2):
    if v is None:
        return None
    if unit == "pct":
        return f"{v * 100:.{digits}f}%"
    if unit == "x":
        return f"{v:.2f}×"
    return f"{v:,.0f}"


def _delta(cur, prior, unit):
    """Current-vs-prior movement. Shown neutrally (raw direction only) — for
    ratios like Funds Cost or Efficiency 'up' isn't necessarily good, so the
    peer percentile carries the 'how good' signal, not the delta color."""
    if cur is None or prior is None:
        return None
    diff = cur - prior
    if abs(diff) < 1e-9:
        return {"display": "no change", "dir": "flat"}
    if unit == "pct":
        disp = f"{'+' if diff > 0 else '−'}{abs(diff) * 100:.2f} pts"
    elif unit == "x":
        disp = f"{'+' if diff > 0 else '−'}{abs(diff):.2f}×"
    else:
        disp = f"{'+' if diff > 0 else '−'}{abs(diff):,.0f}"
    return {"display": disp, "dir": "up" if diff > 0 else "down"}


def _profile_metric(m):
    unit = m["unit"]
    cur = m["cu_current"] if m["cu_current"] is not None else m["cu_value"]
    cell = {"label": m["metric"], "source": FI_PROFILE_SOURCE, "short_desc": m.get("short_desc")}
    if cur is None:
        cell.update(_na())
    else:
        cell["display"] = _fmt_unit(cur, unit)
        cell["value"] = cur
    cell["prior"] = _fmt_unit(m["cu_prior"], unit) if m.get("cu_prior") is not None else None
    cell["delta"] = _delta(m["cu_current"], m["cu_prior"], unit)
    cell["prior_label"] = m.get("prior_label")
    cell["current_label"] = m.get("current_label")
    cell["percentile"] = int(m["cu_percentile"]) if m.get("cu_percentile") is not None else None
    cell["peer"] = _fmt_unit(m["peer_value"], unit) if m.get("peer_value") is not None else None
    return cell


def _fi_profile_block(conn, customer):
    prof = conn.execute("SELECT * FROM fi_profile WHERE customer = ?", (customer,)).fetchone()
    if prof is None:
        return None
    p = dict(prof)
    mrows = conn.execute(
        "SELECT * FROM fi_profile_metric WHERE customer = ?", (customer,)
    ).fetchall()
    by_key = {(r["sheet"], r["metric"]): dict(r) for r in mrows}
    seg = json.loads(p.get("segmentation_json") or "{}")

    cur_label = mrows[0]["current_label"] if mrows else p.get("period")

    profile_card = [
        _metric("Charter", _text(p.get("charter")), FI_PROFILE_SOURCE),
        {"label": "Assets", "source": FI_PROFILE_SOURCE,
         **({"display": p["assets_text"], "value": p["assets_text"]} if p.get("assets_text") else _na())},
        _metric("Members", _num(p.get("members")), FI_PROFILE_SOURCE),
        _metric("Deposit Accounts", _num(p.get("deposit_accounts")), FI_PROFILE_SOURCE),
        _metric("Branches", _num(p.get("branches")), FI_PROFILE_SOURCE),
        _metric("Employees", _num(p.get("employees")), FI_PROFILE_SOURCE),
        _metric("Established", _text(str(int(p["established"])) if p.get("established") else None), FI_PROFILE_SOURCE),
        _metric("Market", _text(p.get("market_size")), FI_PROFILE_SOURCE),
    ]

    # --- Light, grouped two-panel layout (only the metrics that matter) ---
    def fi_m(sheet, name, label=None):
        m = by_key.get((sheet, name))
        if not m:
            return None
        cell = _profile_metric(m)
        if label:
            cell["label"] = label
        return cell

    def fi_s(label, cell):
        return {"label": label, "delta": None, "percentile": None, "peer": None, **cell}

    def disp(sheet, name):
        m = by_key.get((sheet, name))
        if not m:
            return "—"
        v = m["cu_current"] if m["cu_current"] is not None else m["cu_value"]
        return _fmt_unit(v, m["unit"]) if v is not None else "—"

    def pctl(sheet, name):
        m = by_key.get((sheet, name))
        return int(m["cu_percentile"]) if m and m.get("cu_percentile") is not None else None

    panel_a = {
        "title": "Growth & Balance Sheet", "source": "FI Navigator",
        "summary": (
            f"Membership {int(p['members']):,} with {disp('Growth', 'Member Growth')} growth; "
            f"loan growth {disp('Growth', 'Loan Growth Rate')} is outpacing core-deposit growth "
            f"{disp('Risk', 'Core Deposit Growth')} — a lending-led balance sheet."
            if p.get("members") else "Growth profile across membership, lending and deposits."
        ),
        "groups": [
            {"subhead": f"Size · {cur_label}", "rows": [r for r in [
                fi_s("Assets", {"display": p["assets_text"]} if p.get("assets_text") else _na()),
                fi_s("Members", _num(p.get("members"))),
                fi_s("Deposit Accounts", _num(p.get("deposit_accounts"))),
            ] if r]},
            {"subhead": "Growth", "rows": [r for r in [
                fi_m("Growth", "Member Growth"),
                fi_m("Growth", "Loan Growth Rate", "Loan Growth"),
                fi_m("Growth", "Share Account Growth", "Deposit Account Growth"),
                fi_m("Growth", "Revenue Growth Rate", "Revenue Growth"),
                fi_m("Risk", "Core Deposit Growth"),
            ] if r]},
        ],
    }

    panel_b = {
        "title": "Operational Ratios", "source": "FI Navigator",
        "summary": (
            f"ROA {disp('Profit', 'Return on Assets')} (peer pct {pctl('Profit', 'Return on Assets')}) and "
            f"efficiency ratio {disp('Profit', 'Operating Efficiency Ratio')}; net interest margin "
            f"{disp('Profit', 'Net Interest Margin')} sits at peer percentile {pctl('Profit', 'Net Interest Margin')} "
            f"vs the strategic-focus peer group."
        ),
        "groups": [
            {"subhead": "Profitability", "rows": [r for r in [
                fi_m("Profit", "Return on Assets"),
                fi_m("Profit", "Return on Net Worth", "Return on Equity"),
                fi_m("Profit", "Net Interest Margin"),
            ] if r]},
            {"subhead": "Efficiency & Risk", "rows": [r for r in [
                fi_m("Profit", "Operating Efficiency Ratio"),
                fi_m("Risk", "Funds Cost", "Cost of Funds"),
                fi_m("Risk", "Loans Receivable to Shares", "Loan-to-Share"),
                fi_m("Risk", "Net Worth Ratio", "Net Worth (Capital) Ratio"),
            ] if r]},
        ],
    }
    panels = [panel_a, panel_b]

    # Qualitative segmentation scores → compact chips, not a full table.
    segmentation = [{"label": k, "value": v} for k, v in seg.items() if v]

    # CRM Opportunity Mapping — real FI growth signals paired with the CRM
    # lever and target outcome (advisory template; account team refines).
    def sig(sheet, metric):
        m = by_key.get((sheet, metric))
        return _s(_profile_metric(m)) if m else None

    crm_specs = [
        ("Growth", "Member Growth", "Lead funnel widening · onboarding journeys",
         "Grow CRM-sourced new members"),
        ("Growth", "Loan Growth Rate", "KIT onboarding for new loan members · cross-sell pipeline",
         "Reduce new-loan-member churn"),
        ("Profit", "Operating Efficiency Ratio", "Case automation · first-time-right · CTI first-screen",
         "FTE savings · lower case handle time"),
        ("Profit", "Net Interest Margin", "Cross-sell higher-margin products via CRM pipeline",
         "Protect / grow retention income"),
        ("Risk", "Texas Ratio", "ChoiceMap-style early distress signals · proactive outreach",
         "Intervene before delinquency"),
        ("Risk", "Core Deposit Growth", "Deposit-gathering campaigns · member 360 targeting",
         "Deepen funding relationships"),
    ]
    crm_mapping = [
        {"signal": metric, "value": sig(sheet, metric), "lever": lever, "outcome": outcome}
        for sheet, metric, lever, outcome in crm_specs if sig(sheet, metric) is not None
    ]
    crm_summary = (
        f"Loan growth ({disp('Growth', 'Loan Growth Rate')}) and member growth "
        f"({disp('Growth', 'Member Growth')}) are the strongest signals — lead-funnel widening and "
        f"structured onboarding are the highest-leverage CRM plays; efficiency ratio "
        f"{disp('Profit', 'Operating Efficiency Ratio')} points to case-automation upside."
    )

    return {
        "available": True,
        "enhanced": True,  # tells the frontend to render current / Δ / peer-percentile columns
        "source": f"{FI_PROFILE_SOURCE} · period {p.get('period')} · peer-benchmarked",
        "institution": p.get("full_name"),
        "location": ", ".join(x for x in [p.get("city"), p.get("state")] if x),
        "website": p.get("website"),
        "period": p.get("period"),
        "current_label": cur_label,
        "prior_label": mrows[0]["prior_label"] if mrows else None,
        "assets_display": p.get("assets_text"),
        "members": p.get("members"),
        "profile": profile_card,
        "panels": panels,
        "segmentation": segmentation,
        "crm_mapping": crm_mapping,
        "crm_summary": crm_summary,
    }


# ---- FI Growth (flat FI Navigator export — fallback) ----

def _fi_block(conn, customer):
    profile = _fi_profile_block(conn, customer)
    if profile is not None:
        return profile
    row = conn.execute(
        "SELECT * FROM fi_navigator WHERE customer = ?", (customer,)
    ).fetchone()
    if row is None:
        return {
            "available": False,
            "source": FI_SOURCE,
            "reason": "No FI Navigator row maps to this customer — not in the export peer set.",
        }
    r = dict(row)

    # Ratios not native to the export, derived from balance-sheet fields.
    ncr = None
    if r.get("total_assets") and r.get("total_liabilities") is not None:
        ncr = (r["total_assets"] - r["total_liabilities"]) / r["total_assets"]
    dlq = None
    if r.get("total_loans_past_due") is not None and r.get("net_loans_leases"):
        dlq = r["total_loans_past_due"] / r["net_loans_leases"]

    profile = [
        _metric("Type", _text(r.get("fi_type")), FI_SOURCE),
        _metric("Assets", _money_k(r.get("assets")), FI_SOURCE),
        _metric("Members", _na("No member-count field in the FI Navigator export"), FI_SOURCE),
        _metric("Deposit Accounts", _num(r.get("deposit_accounts")), FI_SOURCE),
        _metric("Branches", _num(r.get("branches")), FI_SOURCE),
        _metric("Employees", _num(r.get("employees")), FI_SOURCE),
    ]

    balance_sheet = [
        _metric("Total Assets", _money_k(r.get("total_assets")), FI_SOURCE),
        _metric("Total Deposits", _money_k(r.get("total_deposits")), FI_SOURCE),
        _metric("Net Loans & Leases", _money_k(r.get("net_loans_leases")), FI_SOURCE),
        _metric("Net Income", _money_k(r.get("net_income")), FI_SOURCE),
        _metric("Net Capital Ratio", _pct(ncr), FI_SOURCE,
                note="Computed (Assets − Liabilities) / Assets — not a native export field."),
        _metric("Delinquency Rate", _pct(dlq, 2), FI_SOURCE,
                note="Computed Total Past-Due / Net Loans & Leases — not a native export field."),
        _metric("Total Asset Growth", _pct(r.get("total_asset_growth")), FI_SOURCE),
        _metric("Core Deposit Growth", _pct(r.get("core_deposit_growth")), FI_SOURCE),
        _metric("Revenue Growth", _pct(r.get("revenue_growth")), FI_SOURCE),
    ]

    operational = [
        _metric("Return on Assets", _pct(r.get("return_on_assets"), 2), FI_SOURCE),
        _metric("Return on Equity", _pct(r.get("return_on_equity")), FI_SOURCE),
        _metric("Loans to Deposits", _pct(r.get("loans_to_deposits_ratio")), FI_SOURCE),
        _metric("Core Deposits / FTE", _money_k(r.get("core_deposits_per_fte")), FI_SOURCE),
        _metric("Revenues / FTE", _money_k(r.get("revenues_per_fte")), FI_SOURCE),
        _metric("Consumer Loan Growth", _pct(r.get("consumer_loan_growth")), FI_SOURCE),
        _metric("Commercial Loan Growth", _pct(r.get("commercial_loan_growth")), FI_SOURCE),
    ]

    risk = [
        _metric("Enterprise Risk Score", _text(
            f"{r['enterprise_risk_score']:.2f}" if r.get("enterprise_risk_score") is not None else None), FI_SOURCE),
        _metric("Acquisition Risk", _text(r.get("acquisition_risk")), FI_SOURCE),
        _metric("Failure Risk", _text(r.get("failure_risk")), FI_SOURCE),
        _metric("Vendor Diversity", _text(r.get("vendor_diversity")), FI_SOURCE),
        _metric("Retail Services Innovation", _text(r.get("retail_services_innovation")), FI_SOURCE),
        _metric("Business Services Innovation", _text(r.get("business_services_innovation")), FI_SOURCE),
    ]

    return {
        "available": True,
        "source": f"{FI_SOURCE} ({r.get('period')}, {r.get('reporting_basis')})",
        "institution": r.get("full_name"),
        "location": ", ".join(x for x in [r.get("city"), r.get("state")] if x),
        "website": r.get("website"),
        "period": r.get("period"),
        "profile": profile,
        "panels": [
            {"title": "Balance Sheet Growth", "source": "FI Navigator", "metrics": balance_sheet},
            {"title": "Operational Ratios", "source": "FI Navigator", "metrics": operational},
            {"title": "Risk & Innovation", "source": "FI Navigator", "metrics": risk},
        ],
    }


# ---- Overview & Platform (Adoption Analytics DB) ----

def _year_month_names(conn, customer, year):
    """Month names that actually have data for this customer/created-year —
    used to compare the SAME window across years (avoids full-2025 vs
    partial-2026 skew)."""
    rows = conn.execute(
        """SELECT DISTINCT created_month FROM (
               SELECT created_month, created_month_no FROM cases WHERE customer = ? AND created_year = ?
               UNION SELECT created_month, created_month_no FROM leads WHERE customer = ? AND created_year = ?
           ) WHERE created_month IS NOT NULL ORDER BY created_month_no""",
        (customer, year, customer, year),
    ).fetchall()
    return [r["created_month"] for r in rows]


_MONTH_ABBR = {"January": "Jan", "February": "Feb", "March": "Mar", "April": "Apr",
               "May": "May", "June": "Jun", "July": "Jul", "August": "Aug",
               "September": "Sep", "October": "Oct", "November": "Nov", "December": "Dec"}


def _window_label(months, year):
    if not months:
        return f"FY {year}"
    if len(months) == 1:
        return f"{_MONTH_ABBR.get(months[0], months[0])} {year}"
    return f"{_MONTH_ABBR.get(months[0], months[0])}–{_MONTH_ABBR.get(months[-1], months[-1])} {year}"


def _yoy(cur, prior, kind, better):
    """Build a delta descriptor for an Overview card. kind: 'count'|'rate'|'money'.
    better: 'higher'|'lower'|None (None → neutral, no good/bad color)."""
    if cur is None or prior is None or (kind != "rate" and not prior):
        return None
    if kind == "rate":
        diff = (cur - prior) * 100
        disp = f"{'+' if diff >= 0 else '−'}{abs(diff):.1f} pts"
    else:
        diff = (cur - prior) / prior * 100
        disp = f"{'+' if diff >= 0 else '−'}{abs(diff):.0f}%"
    up = (cur - prior) >= 0
    if better is None:
        tone = "neutral"
    elif (better == "higher" and up) or (better == "lower" and not up):
        tone = "good"
    else:
        tone = "bad"
    return {"display": disp, "dir": "up" if up else "down", "tone": tone}


def _overview_kpis(conn, customer, year, month):
    prior_year = year - 1
    cur_months = _year_month_names(conn, customer, year)
    prior_months = cur_months  # same window in the prior year

    lc = leads_metrics.get_leads_kpis(conn, customer, year, month)
    cc = cases_metrics.get_cases_kpis(conn, customer, year, month)
    xc = complaints_metrics.get_complaints_kpis(conn, customer, year, month)
    # Prior-year, SAME month window.
    lp = leads_metrics.get_leads_kpis(conn, customer, prior_year, prior_months)
    cp = cases_metrics.get_cases_kpis(conn, customer, prior_year, prior_months)
    xp = complaints_metrics.get_complaints_kpis(conn, customer, prior_year, prior_months)

    sla = (1 - cc["sla_breach_rate"]) if cc.get("sla_breach_rate") is not None else None
    sla_p = (1 - cp["sla_breach_rate"]) if cp.get("sla_breach_rate") is not None else None

    def card(label, cell, cur, prior, kind, better):
        m = _metric(label, cell, DB_SOURCE)
        d = _yoy(cur, prior, kind, better)
        if d:
            m["delta"] = d
        return m

    return [
        card("Total Leads", _num(lc.get("total_leads")), lc.get("total_leads"), lp.get("total_leads"), "count", "higher"),
        card("Lead Conversion", _pct(lc.get("conversion_rate")), lc.get("conversion_rate"), lp.get("conversion_rate"), "rate", "higher"),
        card("Book of Business", _money(lc.get("book_of_business")), lc.get("book_of_business"), lp.get("book_of_business"), "money", "higher"),
        card("Total Cases", _num(cc.get("total_cases")), cc.get("total_cases"), cp.get("total_cases"), "count", None),
        card("SLA Attainment", _pct(sla), sla, sla_p, "rate", "higher"),
        card("First-Time-Right", _pct(cc.get("ftr_rate")), cc.get("ftr_rate"), cp.get("ftr_rate"), "rate", "higher"),
        card("Total Complaints", _num(xc.get("total_complaints")), xc.get("total_complaints"), xp.get("total_complaints"), "count", "lower"),
        card("Complaint FTR", _pct(xc.get("ftr_rate")), xc.get("ftr_rate"), xp.get("ftr_rate"), "rate", "higher"),
    ]


def _overview_window(conn, customer, year):
    months = _year_month_names(conn, customer, year)
    return f"{_window_label(months, year)} vs {_window_label(months, year - 1)}"


# ---- Platform Metrics — purpose-built panels mirroring the QBR reference:
# SLA Performance (by department), Case Quality, Lead Funnel (by member
# segment), plus Complaint Handling and User Adoption. All live from the DB. ----

def period_hint(month, year):
    return f"{month} {year}" if month else f"FY {year}"


def _s(cell):
    """A formatted metric cell → plain display string for a table row."""
    return "Not available" if cell.get("na") else cell.get("display")


def _group(subhead, rows):
    return {"subhead": subhead, "rows": rows}


def _cmp(label, cur, prior, kind, better):
    """A period-comparison row: prior value, current value, and the YoY change."""
    fmt = {"count": _num, "rate": _pct, "hours": _hours, "money": _money}[kind]
    return {
        "label": label,
        "prior": _s(fmt(prior)),
        "current": _s(fmt(cur)),
        "change": _yoy(cur, prior, kind, better),
    }


def _sla_panel(conn, customer, year, month):
    sla = cases_metrics.get_cases_sla(conn, customer, year, month)
    total = sla.get("total_cases") or 0
    breach_rate = sla.get("sla_breach_rate")
    attain = (1 - breach_rate) if breach_rate is not None else None

    # Top departments by volume — trimmed so the table stays readable at half width.
    depts = sorted(sla.get("by_category", []), key=lambda r: r["total_cases"], reverse=True)[:6]
    rows = []
    for d in depts:
        t = d["total_cases"] or 0
        br = d["sla_breaches"] or 0
        pct = ((t - br) / t) if t else None
        rows.append([
            {"value": d["category"], "align": "left"},
            {"value": f"{t:,}", "align": "right"},
            {"value": f"{br:,}", "align": "right"},
            {"value": _s(_pct(pct)), "align": "right", "strong": True},
        ])
    rows.append([
        {"value": "Grand Total", "align": "left", "strong": True},
        {"value": f"{total:,}", "align": "right", "strong": True},
        {"value": f"{int(round((breach_rate or 0) * total)):,}", "align": "right", "strong": True},
        {"value": _s(_pct(attain)), "align": "right", "strong": True},
    ])

    worst = min((d for d in depts if d["total_cases"]), key=lambda d: (d["total_cases"] - d["sla_breaches"]) / d["total_cases"], default=None)
    summary = (
        f"Overall SLA attainment is {_s(_pct(attain))} across {total:,} cases. "
        + (f"{worst['category']} is the biggest drag. " if worst else "")
        + "Contact-center process changes are the main lever to lift it."
    )
    return {
        "type": "sla", "width": "half", "title": "SLA Performance", "summary": summary,
        "hero": {"value": _s(_pct(attain)), "label": "Overall SLA Attainment",
                 "sub": f"{total:,} cases · {period_hint(month, year)}"},
        "columns": [
            {"label": "Department", "align": "left"},
            {"label": "Total", "align": "right"},
            {"label": "Breached", "align": "right"},
            {"label": "SLA %", "align": "right"},
        ],
        "rows": rows,
    }


def _case_quality_panel(conn, customer, year, month, py, pm, cl, pl):
    c = cases_metrics.get_cases_kpis(conn, customer, year, month)
    p = cases_metrics.get_cases_kpis(conn, customer, py, pm)
    return {
        "type": "compare", "width": "half", "title": "Case Quality & Efficiency",
        "columns": [pl, cl, "Change"],
        "summary": (
            f"{_s(_num(c.get('total_cases')))} cases at {_s(_pct(c.get('ftr_rate')))} first-time-right "
            f"(vs {_s(_pct(p.get('ftr_rate')))} prior); rework {_s(_pct(c.get('rework_rate')))}, "
            f"median resolution {_s(_hours(c.get('median_time_to_resolve_hours')))}."
        ),
        "groups": [
            _group("Efficiency & Scale", [
                _cmp("Total Cases", c.get("total_cases"), p.get("total_cases"), "count", None),
                _cmp("Cases Closed", c.get("closed_cases"), p.get("closed_cases"), "count", None),
            ]),
            _group("Quality & Rework", [
                _cmp("First-Time-Right", c.get("ftr_rate"), p.get("ftr_rate"), "rate", "higher"),
                _cmp("Rework (Reopen) Rate", c.get("rework_rate"), p.get("rework_rate"), "rate", "lower"),
                _cmp("Reassignment Rate", c.get("reassignment_rate"), p.get("reassignment_rate"), "rate", "lower"),
            ]),
            _group("Resolution Timelines", [
                _cmp("Avg Time to Resolve", c.get("avg_time_to_resolve_hours"), p.get("avg_time_to_resolve_hours"), "hours", "lower"),
                _cmp("Median Time to Resolve", c.get("median_time_to_resolve_hours"), p.get("median_time_to_resolve_hours"), "hours", "lower"),
            ]),
        ],
    }


def _lead_funnel_panel(conn, customer, year, month, py, pm, cl, pl):
    c = leads_metrics.get_leads_kpis(conn, customer, year, month)
    p = leads_metrics.get_leads_kpis(conn, customer, py, pm)
    cs = {s["segment"]: s for s in leads_metrics.get_leads_by_member_type(conn, customer, year, month)}
    ps = {s["segment"]: s for s in leads_metrics.get_leads_by_member_type(conn, customer, py, pm)}

    def seg(name, field, kind, better):
        cv = cs.get(name, {}).get(field)
        pv = ps.get(name, {}).get(field)
        return _cmp(name, cv, pv, kind, better)

    ex, nm = cs.get("Existing Member"), cs.get("Non-Member")
    return {
        "type": "compare", "width": "full", "title": "Lead Funnel Performance",
        "columns": [pl, cl, "Change"],
        "summary": (
            f"{_s(_num(c.get('total_leads')))} leads at {_s(_pct(c.get('conversion_rate')))} conversion "
            f"(vs {_s(_pct(p.get('conversion_rate')))} prior). "
            + (f"Existing members convert {_s(_pct(ex.get('conv_rate')))} vs {_s(_pct(nm.get('conv_rate')))} for non-members — "
               "the cross-sell base is where the funnel is strongest." if ex and nm else "")
        ),
        "groups": [
            _group("Growth", [
                _cmp("Total Leads Created", c.get("total_leads"), p.get("total_leads"), "count", "higher"),
                _cmp("Won Leads", c.get("won_leads"), p.get("won_leads"), "count", "higher"),
                _cmp("Overall Conversion", c.get("conversion_rate"), p.get("conversion_rate"), "rate", "higher"),
                _cmp("Book of Business", c.get("book_of_business"), p.get("book_of_business"), "money", "higher"),
                _cmp("Avg Deal Value", c.get("avg_deal_value"), p.get("avg_deal_value"), "money", "higher"),
            ]),
            _group("Conversion by Member Segment", [
                seg("Existing Member", "conv_rate", "rate", "higher"),
                seg("Non-Member", "conv_rate", "rate", "higher"),
                _cmp("Existing Member Share", c.get("existing_member_pct"), p.get("existing_member_pct"), "rate", None),
            ]),
            _group("Engagement Timelines", [
                _cmp("Avg Time to Touch", c.get("avg_time_to_touch_hours"), p.get("avg_time_to_touch_hours"), "hours", "lower"),
                _cmp("Avg Time to Qualify", c.get("avg_time_to_qualify_hours"), p.get("avg_time_to_qualify_hours"), "hours", "lower"),
            ]),
        ],
    }


def _complaints_panel(conn, customer, year, month, py, pm, cl, pl):
    c = complaints_metrics.get_complaints_kpis(conn, customer, year, month)
    p = complaints_metrics.get_complaints_kpis(conn, customer, py, pm)
    return {
        "type": "compare", "width": "half", "title": "Complaint Handling",
        "columns": [pl, cl, "Change"],
        "summary": (
            f"{_s(_num(c.get('total_complaints')))} complaints (vs {_s(_num(p.get('total_complaints')))} prior), "
            f"{_s(_pct(c.get('ftr_rate')))} first-time-right."
        ),
        "groups": [
            _group("Volume", [
                _cmp("Total Complaints", c.get("total_complaints"), p.get("total_complaints"), "count", "lower"),
                _cmp("Closed", c.get("closed_complaints"), p.get("closed_complaints"), "count", None),
            ]),
            _group("Quality & Timelines", [
                _cmp("First-Time-Right", c.get("ftr_rate"), p.get("ftr_rate"), "rate", "higher"),
                _cmp("Rework Rate", c.get("rework_rate"), p.get("rework_rate"), "rate", "lower"),
                _cmp("Avg Time to Resolve", c.get("avg_time_to_resolve_hours"), p.get("avg_time_to_resolve_hours"), "hours", "lower"),
            ]),
        ],
    }


def _user_adoption_panel(conn, customer, year, month):
    k = users_metrics.get_users_kpis(conn, customer, year, month)
    roles = users_metrics.get_users_by_role(conn, customer, year, month)[:6]
    role_rows = []
    for r in roles:
        tot = r.get("total_licensed") or 0
        lr = (r["active_users"] / tot) if tot else None
        role_rows.append([
            {"value": r["job_title"], "align": "left"},
            {"value": f"{tot:,}", "align": "right"},
            {"value": f"{r['active_users']:,}", "align": "right"},
            {"value": _s(_pct(lr)), "align": "right", "strong": True},
        ])
    return {
        "type": "table", "width": "half", "title": "User Adoption · by Role",
        "summary": (
            f"{_s(_num(k.get('total_licensed')))} licensed users at {_s(_pct(k.get('login_rate')))} login rate; "
            f"{_s(_num(k.get('inactive_licensed')))} inactive licences are the reclaim/retraining opportunity."
        ),
        "hero_stats": [
            {"label": "Licensed", "value": _s(_num(k.get("total_licensed")))},
            {"label": "Active", "value": _s(_num(k.get("active_users")))},
            {"label": "Login Rate", "value": _s(_pct(k.get("login_rate")))},
            {"label": "Avg Min / User", "value": _s(_num(k.get("avg_minutes")))},
        ],
        "columns": [
            {"label": "Role", "align": "left"},
            {"label": "Licensed", "align": "right"},
            {"label": "Active", "align": "right"},
            {"label": "Login %", "align": "right"},
        ],
        "rows": role_rows,
    }


def _platform_block(conn, customer, year, month, period_label):
    # Same matched-window YoY as the Overview cards (e.g. Jan–Jun '26 vs '25).
    months = _year_month_names(conn, customer, year)
    py, pm = year - 1, months
    cl, pl = _window_label(months, year), _window_label(months, year - 1)
    return {
        "available": True,
        "source": DB_SOURCE,
        "period_label": period_label,
        "compare_label": f"{cl} vs {pl}",
        "panels": [
            _sla_panel(conn, customer, year, month),
            _case_quality_panel(conn, customer, year, month, py, pm, cl, pl),
            _lead_funnel_panel(conn, customer, year, month, py, pm, cl, pl),
            _complaints_panel(conn, customer, year, month, py, pm, cl, pl),
            _user_adoption_panel(conn, customer, year, month),
        ],
    }


# ---- OKR Performance (business levers × adoption KPIs, AI-mapped) ----

def _kpi_catalog(conn, customer, year, month):
    """Return (cells, slim) — the full formatted Overview KPI cells plus a few
    adoption KPIs, and a slim [{label, value, change}] list for the AI mapper."""
    cells = [c for c in _overview_kpis(conn, customer, year, month) if not c.get("na")]
    k = users_metrics.get_users_kpis(conn, customer, year, month)
    for extra in (_metric("User Login Rate", _pct(k.get("login_rate")), DB_SOURCE),
                  _metric("Active Users", _num(k.get("active_users")), DB_SOURCE)):
        if not extra.get("na"):
            cells.append(extra)
    slim = []
    for c in cells:
        e = {"label": c["label"], "value": c.get("display")}
        d = c.get("delta")
        if d:
            e["change"] = f"{d.get('display')} {d.get('dir')}"
        slim.append(e)
    return cells, slim


# In-process memo so the report endpoint doesn't hit the LLM on every reload.
_OKR_CACHE = {}


def _okr_block(conn, customer, year, month, levers_section, vision_section):
    import insights
    source = f"{REDASH} × {DB_SOURCE}"
    if not levers_section.get("available"):
        return {"available": False, "source": source,
                "reason": levers_section.get("reason", "No business levers available for this customer.")}

    levers = levers_section["levers"]
    objectives = [o["objective"] for o in (vision_section.get("objectives") or [])] \
        if vision_section.get("available") else []
    cells, slim = _kpi_catalog(conn, customer, year, month)
    by_label = {c["label"]: c for c in cells}

    cache_key = (customer, year, month, tuple(l["lever"] for l in levers), tuple(c["label"] + str(c.get("display")) for c in cells))
    mapping = _OKR_CACHE.get(cache_key)
    ai_error = None
    if mapping is None:
        try:
            mapping = insights.generate_okr_assessment(
                customer,
                [{"lever": l["lever"], "definition": l.get("definition")} for l in levers],
                slim, objectives)
            _OKR_CACHE[cache_key] = mapping
        except Exception as e:  # never let the LLM break the report
            mapping, ai_error = {}, str(e)

    def kpi_cell(label):
        c = by_label.get(label)
        return {"label": c["label"], "display": c.get("display"), "delta": c.get("delta")} if c else None

    out = []
    for l in levers:
        m = mapping.get(l["lever"]) if isinstance(mapping, dict) else None
        m = m or {}
        kpis = [k for k in (kpi_cell(lbl) for lbl in (m.get("kpis") or [])) if k]
        assessment = m.get("assessment") or "unknown"
        if assessment not in ("on_track", "at_risk", "behind", "unknown"):
            assessment = "unknown"
        out.append({**l, "kpis": kpis, "assessment": assessment, "rationale": m.get("rationale")})

    return {
        "available": True,
        "source": source,
        "ai_generated": True,
        "ai_error": ai_error,
        "objectives": objectives,
        "levers": out,
        "kpi_catalog": [{"label": c["label"], "display": c.get("display"), "delta": c.get("delta")} for c in cells],
    }


# ---- Account narrative (AI synthesis over all available signals) ----

_NARRATIVE_CACHE = {}


def _account_narrative(conn, customer, year, month, kpi_cells, fi, redash):
    import insights

    kpis = []
    for c in kpi_cells:
        if c.get("na"):
            continue
        e = {"label": c["label"], "value": c.get("display")}
        d = c.get("delta")
        if d:
            e["change"] = f"{d.get('display')} {d.get('dir')}"
        kpis.append(e)

    fi_ctx = None
    if fi and fi.get("available"):
        fi_ctx = {
            "institution": fi.get("institution"),
            "assets": fi.get("assets_display"),
            "members": fi.get("members"),
            "highlights": [p.get("summary") for p in (fi.get("panels") or []) if p.get("summary")],
        }

    levers = redash["levers"].get("levers", []) if redash["levers"].get("available") else []
    roadmap = redash["roadmap"]
    horizon_counts = ({h["label"]: len(h["items"]) for h in roadmap["horizons"]}
                      if roadmap.get("available") else None)
    risks = redash["risks"]
    risk_ctx = risks.get("counts") if risks.get("available") else None

    context = {
        "period": f"{month} {year}" if month else f"FY {year}",
        "kpis": kpis,
        "fi_growth": fi_ctx,
        "business_levers": [l["lever"] for l in levers] or None,
        "roadmap_horizon_counts": horizon_counts,
        "open_discussion_points": risk_ctx,
    }

    cache_key = (customer, year, month, json.dumps(context, sort_keys=True, default=str))
    if cache_key in _NARRATIVE_CACHE:
        return _NARRATIVE_CACHE[cache_key]

    try:
        text = insights.generate_account_narrative(customer, context)
    except Exception as e:
        return {"available": False, "source": DB_SOURCE + " / AI",
                "reason": f"Account narrative could not be generated ({e})."}
    result = ({"available": True, "ai_generated": True, "source": "AI synthesis · Adoption Analytics DB + FI Navigator + CRM", "text": text}
              if text else {"available": False, "source": DB_SOURCE + " / AI", "reason": "No narrative returned."})
    _NARRATIVE_CACHE[cache_key] = result
    return result


# ---- Sections with no data source yet (Redash / manual) ----

def _unavailable(source, reason):
    return {"available": False, "source": source, "reason": reason}


def _apply_ai_crm_levers(conn, customer, fi_growth, redash, year):
    """Replace the CRM Opportunity Mapping's template levers with AI text grounded
    in the modules this customer actually runs.

    Signal and outcome stay fixed on purpose — they're the agreed catalogue. Only the
    lever is generated, because that's the column that read identically for all 11
    customers. Cached on (signals+values, modules) so it costs one call per real change.

    Deliberately best-effort: the report must render if OpenAI or Redash is down, so any
    failure leaves the template lever in place rather than blanking the column."""
    mapping = (fi_growth or {}).get("crm_mapping") or []
    if not mapping:
        return

    modules = ((redash or {}).get("tech_stack") or {}).get("modules") or []
    if not modules:
        # No module list (Redash down, or none onboarded) means nothing to ground the lever
        # in — a generic AI sentence would be no better than the template it replaced, and
        # caching it would make the ungrounded version stick. Keep the template.
        return

    signals = [{"signal": r["signal"], "value": r.get("value"), "outcome": r.get("outcome")} for r in mapping]
    cache_key = make_insight_cache_key(
        customer, "crm_levers", year, None, {"signals": signals, "modules": modules}
    )

    levers = get_cached_chart_insights(conn, cache_key)
    if levers is None:
        try:
            levers = generate_crm_levers(customer, signals, modules)
        except Exception:
            return
        if not levers:
            return
        store_chart_insights(conn, cache_key, customer, "crm_levers", year, None, levers)

    for row in mapping:
        text = levers.get(row["signal"])
        if text:
            row["lever"] = text
            row["lever_source"] = "AI · grounded in implemented CRM modules"


def build_qbr_report(conn, customer, year, month=None):
    period_label = f"{month} {year}" if month else f"FY {year}"
    redash = qbr_redash.build_sections(customer)
    okr = _okr_block(conn, customer, year, month, redash["levers"], redash["vision"])
    kpis = _overview_kpis(conn, customer, year, month)
    fi_growth = _fi_block(conn, customer)
    _apply_ai_crm_levers(conn, customer, fi_growth, redash, year)
    narrative = _account_narrative(conn, customer, year, month, kpis, fi_growth, redash)

    return {
        "customer": customer,
        "year": year,
        "month": month,
        "period_label": period_label,
        "provenance": {
            "db": DB_SOURCE,
            "fi": FI_SOURCE,
            "redash": REDASH,
        },
        "overview": {
            "available": True,
            "source": DB_SOURCE,
            "period_label": period_label,
            "compare_label": _overview_window(conn, customer, year),
            "kpis": kpis,
            "narrative": narrative,
            "levers": redash["levers"],
            "tech_stack": redash["tech_stack"],
        },
        "fi_growth": fi_growth,
        "platform": _platform_block(conn, customer, year, month, period_label),
        "vision_goals": redash["vision"],
        "okr": okr,
        "roadmap": redash["roadmap"],
        "decisions": redash["risks"],
    }
