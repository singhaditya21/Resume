export default function TabBar({ tabs, activeTab, onChange }) {
  return (
    <div className="bn-tab-bar">
      {tabs.map((tab) => (
        <div
          key={tab.key}
          className={`bn-tab${tab.key === activeTab ? ' active' : ''}`}
          onClick={() => onChange(tab.key)}
        >
          {tab.label}
        </div>
      ))}
    </div>
  )
}
