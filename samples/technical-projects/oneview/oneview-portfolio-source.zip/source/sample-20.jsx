export default function StatCard({ label, value, subLabel, variant = 'info', onClick }) {
  return (
    <div
      className={`bn-stat-card ${variant}${onClick ? ' clickable' : ''}`}
      onClick={onClick}
    >
      <span className="bn-stat-label">{label}</span>
      <span className="bn-stat-value">{value}</span>
      {subLabel && <span className="bn-stat-sublabel">{subLabel}</span>}
    </div>
  )
}
