export default function DrillDownModal({ open, onClose, title, children }) {
  if (!open) return null

  return (
    <div className="bn-modal-overlay" onClick={onClose}>
      <div className="bn-modal" onClick={(e) => e.stopPropagation()}>
        <div className="bn-modal-header">
          <h2>{title}</h2>
          <button className="bn-modal-close" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>
        <div className="bn-modal-body">{children}</div>
      </div>
    </div>
  )
}
