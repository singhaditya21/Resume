#!/usr/bin/env python3
"""Deterministic OneView demo data pipeline — bakes site/data/accounts.json.

Merges the three sanctioned sources for O BEE / SESLOC / CUSTOMER_REDACTED:
  - Redash query 657         -> account / commercial health
  - Azure DevOps boards      -> per-project delivery rollup (computed here, NOT by an agent)
  - FI Navigator xlsx        -> financial metrics

Secrets come from env only (REDASH_API_KEY, AZ_PAT); never committed. The output
JSON contains confidential FI Navigator data and is gitignored — LOCAL ONLY.
"""
import base64, json, os, re, sys, urllib.parse, urllib.request, datetime as dt
from collections import Counter

# ---------- progress ----------
# The refresh server (scripts/refresh_api.py) reads these lines off our stdout live and
# exposes them to the UI loader. Format: PROGRESS|<done>|<total>|<pct>|<label>
# <done> is steps completed so far; <label> is the step now starting. The final line is
# emitted at 100.00 so the loader always lands exactly on complete.
_P = {"n": 0, "total": 40}


def prog_total(t):
    _P["total"] = max(1, int(t))


def prog(label):
    n, total = _P["n"], _P["total"]
    pct = min(100.0, n / total * 100.0)
    print(f"PROGRESS|{n}|{total}|{pct:.2f}|{label}", flush=True)
    _P["n"] = min(total, n + 1)


def prog_done(label="Complete"):
    _P["n"] = _P["total"]
    print(f"PROGRESS|{_P['total']}|{_P['total']}|100.00|{label}", flush=True)


# ---------- data-integrity helpers ----------
# These add provenance, validation, resilience and reproducibility WITHOUT changing any
# value the pipeline already computes: every existing field is produced by the same code;
# these only wrap the source calls (to record status) and add new sibling fields.
import hashlib
import time as _time

_PROV = {}  # per-source provenance for this run: {name: {status, rowCount, fetchedAt, error?}}


def _now_iso():
    return _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())


def load_prev():
    """Previous output — used for last-known-good fallback and insight reuse. Never fabricated."""
    try:
        with open(OUT, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def source(name, fn, fallback=None, critical=False):
    """Run a source call, recording provenance. On failure keep the last-known-good `fallback`
    and mark the source stale — never blank or invent. A failing `critical` source aborts the
    whole build so a bad pull can't overwrite good data (see write_output's validation)."""
    try:
        res = fn()
        n = len(res) if hasattr(res, "__len__") else None
        _PROV[name] = {"status": "ok", "rowCount": n, "fetchedAt": _now_iso()}
        return res
    except Exception as e:  # noqa: BLE001
        _PROV[name] = {"status": "error" if fallback is None else "stale",
                       "error": str(e)[:200], "fetchedAt": _now_iso()}
        if critical:
            raise
        return fallback


# Keys excluded from the reuse hash: fetch timestamps (change every pull), the per-item drill-down
# list (order-unstable, not used by any prompt), and the AI OUTPUTS themselves (we hash INPUTS only).
_VOLATILE_KEYS = {"as_of", "fetchedAt", "generatedAt", "checkedAt", "at", "items"}
_AI_OUTPUT_KEYS = {"ai", "aiAccountRisks", "aiProjectRisks", "growthNextAction", "aiActionPlan", "financialHealth", "_aiInputHash"}


def _strip_volatile(obj):
    if isinstance(obj, dict):
        return {k: _strip_volatile(v) for k, v in obj.items()
                if k not in _VOLATILE_KEYS and not k.endswith(("At", "_at"))}
    if isinstance(obj, list):
        return [_strip_volatile(v) for v in obj]
    return obj


def ai_input_hash(acct):
    """Hash EVERY input an account's AI narrative depends on, so reuse can never serve a narrative
    that was generated from different data. Covers all assembled fields the prompts read (name,
    health, delivery, financial, growth, risk, caseSla, techStack, relationships, businessLevers,
    modules, projectRisks, accountRisks, ...) plus a signature of the FI Navigator PDF that
    financialHealth is vision-read from — timestamps and AI outputs excluded."""
    # ticketTrend + coeProjectHealth are display-only (not fed to the prompts), so they must not
    # trigger a re-roll — the underlying delivery/projectHealth signals are already hashed.
    basis = _strip_volatile({k: v for k, v in acct.items()
                             if k not in _AI_OUTPUT_KEYS and k not in ("ticketTrend", "coeProjectHealth")})
    pdf = FI_PDFS.get(acct.get("slug"))  # financialHealth reads the PDF, not the xlsx — sign it
    if pdf:
        try:
            st = os.stat(os.path.join(FIN_DIR, pdf))
            basis["_pdfSig"] = [int(st.st_mtime), st.st_size]
        except OSError:
            basis["_pdfSig"] = None
    return hashlib.sha256(json.dumps(basis, sort_keys=True, default=str).encode()).hexdigest()


def change_log(prev, out):
    """Deltas vs the previous run for the headline numbers — observability, not a data change."""
    log = []
    # A model swap re-rolls every narrative — surface it as a deliberate release event, not a silent change.
    pm, nm = (prev.get("sources") or {}).get("aiModel"), (out.get("sources") or {}).get("aiModel")
    if pm and nm and pm != nm:
        log.append({"slug": "*", "field": "AI model", "from": pm, "to": nm})
    prev_by = {a.get("slug"): a for a in (prev.get("accounts") or [])}
    for a in out.get("accounts", []):
        p = prev_by.get(a.get("slug"))
        if not p:
            log.append({"slug": a.get("slug"), "field": "account", "from": None, "to": "added"})
            continue
        for path, label in (("health.arr", "ARR"), ("delivery.total", "delivery total"),
                            ("delivery.open_bugs", "open bugs"), ("risk.tier", "risk tier")):
            k1, k2 = path.split(".")
            ov, nv = (p.get(k1) or {}).get(k2), (a.get(k1) or {}).get(k2)
            if ov != nv:
                log.append({"slug": a.get("slug"), "field": label, "from": ov, "to": nv})
    return log


_TIER_RANK = {"none": 0, "moderate": 1, "high": 2}


def compute_alerts(prev, out):
    """Exceptions worth pushing: an account whose risk tier WORSENED or whose open bugs jumped
    vs the previous run. Empty on a first run / unchanged data — never a false alarm."""
    alerts = []
    prev_by = {a.get("slug"): a for a in (prev.get("accounts") or [])}
    for a in out.get("accounts", []):
        p = prev_by.get(a.get("slug"))
        if not p:
            continue
        nt = (a.get("risk") or {}).get("tier")
        ot = (p.get("risk") or {}).get("tier")
        if _TIER_RANK.get(nt, 0) > _TIER_RANK.get(ot, 0):
            alerts.append({"slug": a.get("slug"), "name": a.get("name"),
                           "severity": "high" if nt == "high" else "medium",
                           "message": f"Risk tier worsened: {ot} → {nt}"})
        ob = (a.get("delivery") or {}).get("open_bugs")
        pb = (p.get("delivery") or {}).get("open_bugs")
        if isinstance(ob, int) and isinstance(pb, int) and pb > 0 and ob - pb >= 5 and ob >= pb * 1.5:
            alerts.append({"slug": a.get("slug"), "name": a.get("name"), "severity": "medium",
                           "message": f"Open bugs rose {pb} → {ob}"})
    return alerts


WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "")  # optional: POST alerts/changes here (e.g. an n8n webhook)


def emit_webhook(out):
    if not WEBHOOK_URL or not out.get("alerts"):
        return
    payload = {"generatedAt": out.get("generatedAt"), "alerts": out.get("alerts"), "changeLog": out.get("changeLog")}
    try:
        req = urllib.request.Request(WEBHOOK_URL, data=json.dumps(payload).encode(), method="POST")
        req.add_header("content-type", "application/json")
        urllib.request.urlopen(req, timeout=15)
        print(f"posted {len(out['alerts'])} alert(s) to webhook", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"webhook post failed: {e}", flush=True)


def validate(out):
    """Gate a build before it can replace the live file. Returns [] if OK, else a list of
    problems. Rejects a structurally-broken or empty pull so it cannot overwrite good data."""
    problems = []
    accts = out.get("accounts")
    if not isinstance(accts, list) or not accts:
        return ["no accounts in output"]
    slugs = {a.get("slug") for a in accts}
    if slugs != set(ACCOUNTS):
        problems.append(f"account set changed: {sorted(slugs)} != {sorted(ACCOUNTS)}")
    for a in accts:
        if not a.get("name"):
            problems.append(f"{a.get('slug')}: missing account name")
        # An account with no linked Azure project (or whose delivery pull failed with no
        # last-known-good) legitimately has delivery=None — shown as N/A, not an error. Only a
        # PRESENT-but-malformed delivery (a dict missing an int total) is a real structural problem.
        d = a.get("delivery")
        if d is not None and not isinstance(d.get("total"), int):
            problems.append(f"{a.get('slug')}: delivery present but delivery.total not an int")
    return problems


def write_output(out, prev):
    """Validate, snapshot, then write atomically. If validation fails we DO NOT touch the live
    file — the previous good data keeps serving."""
    problems = validate(out)
    out["validation"] = {"ok": not problems, "problems": problems, "checkedAt": _now_iso()}
    if problems:
        raise SystemExit("VALIDATION FAILED — not writing accounts.jso/opt/portfolio/project" + "\n  - ".join(problems))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    tmp = OUT + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    os.replace(tmp, OUT)  # atomic: readers never see a half-written file
    try:
        os.chmod(OUT, 0o666)  # the refresh server may run as a different uid than the deploy user
    except OSError:
        pass
    # Keep a small rolling history for audit / "what changed". NOTE: outside site/ so nginx never
    # serves these — they carry the same confidential data as accounts.json.
    try:
        snapdir = os.environ.get("SNAP_DIR", "snapshots")
        os.makedirs(snapdir, exist_ok=True)
        stamp = (out.get("generatedAt") or _now_iso()).replace(":", "").replace("-", "")
        with open(os.path.join(snapdir, f"accounts-{stamp}.json"), "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False)
        snaps = sorted(fn for fn in os.listdir(snapdir) if fn.startswith("accounts-"))
        for old in snaps[:-10]:  # keep last 10
            os.remove(os.path.join(snapdir, old))
    except Exception:
        pass

# Per-query Redash API keys live in scripts/redash_query_keys.json (gitignored, never committed)
# or REDASH_KEY_<id> env vars. No API keys are hard-coded in this file.
_QKEYS = {}
try:
    with open(os.path.join(os.path.dirname(__file__), "redash_query_keys.json"), encoding="utf-8") as _f:
        _QKEYS = json.load(_f)
except Exception:
    pass

# Account 360 Action Plan query (Redash 700) — id + key configurable via env so prod can supply
# them through the root .env instead of the mounted key file (mirrors the 675 user-directory).
ACTIONPLAN_QID = os.environ.get("REDASH_ACTIONPLAN_QUERY_ID", "700")


def qkey(qid):
    # Named override for the action-plan query, then the generic per-query env (REDASH_KEY_<id>),
    # then the key file, then a global user key that can read any query the user has access to.
    if str(qid) == str(ACTIONPLAN_QID):
        k = os.environ.get("REDASH_ACTIONPLAN_API_KEY")
        if k:
            return k
    return (os.environ.get(f"REDASH_KEY_{qid}") or _QKEYS.get(str(qid))
            or os.environ.get("REDASH_GLOBAL_KEY") or _QKEYS.get("_global", ""))


# Azure DevOps PAT lives in scripts/azure_pat.json (gitignored, never committed) or AZ_PAT env var.
_AZPAT = {}
try:
    with open(os.path.join(os.path.dirname(__file__), "azure_pat.json"), encoding="utf-8") as _f:
        _AZPAT = json.load(_f)
except Exception:
    pass

REDASH_KEY = os.environ.get("REDASH_API_KEY") or qkey("657")
AZ_PAT = os.environ.get("AZ_PAT") or _AZPAT.get("AZ_PAT", "")
ORG = "https://example.invalid"
# The FI Navigator inputs (xlsx, growth json, per-account PDFs) are licensed files kept
# outside git. Override FIN_DIR to run this anywhere but the original Windows box.
FIN_DIR = os.environ.get("FIN_DIR", r"/opt/portfolio/project")
FIN = os.environ.get("FIN_XLSX") or os.path.join(FIN_DIR, "fi-data-2026-07-01 (1).xlsx")
GROWTH_FILE = os.environ.get("GROWTH_FILE") or os.path.join(FIN_DIR, "growth-metrics.json")
OUT = os.path.join("site", "data", "accounts.json")


def growth_metrics():
    try:
        with open(GROWTH_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

# Business config (accounts + health/risk thresholds) is data-driven: edit scripts/oneview_config.json
# to add/remove an account or retune thresholds, no code change. The hardcoded values below are the
# fallback if the file is missing, and are the canonical defaults (config values must match them).
_DEFAULT_ACCOUNTS = {
    "obee":       {"redash": "O BEE Credit Union",           "project": "PORTFOLIO_REDACTED",              "fi": ["o bee", "obee"]},
    "sesloc":     {"redash": "SESLOC",                        "project": "PORTFOLIO_REDACTED",                            "fi": ["sesloc"]},
    "CUSTOMER_REDACTED":     {"redash": "CUSTOMER_REDACTED Community Credit Union", "project": "PORTFOLIO_REDACTED", "fi": ["CUSTOMER_REDACTED"]},
    "familytrust": {"redash": "FAMILY TRUST",                  "project": "PORTFOLIO_REDACTED",                 "fi": ["family trust"]},
}
_DEFAULT_THRESHOLDS = {
    "healthWeights":  {"adoption": 0.30, "support": 0.15, "engagement": 0.25, "project": 0.15, "financial": 0.15},
    "renewalWeights": {"adoption": 0.50, "support": 0.10, "engagement": 0.20, "project": 0.20},
    "healthBands":  {"good": 85, "moderate": 60},
    "renewalBands": {"low": 85, "moderate": 60},
    "riskSeverityTier": {"high": 3, "moderate": 2},
}
_CFG = {}
try:
    with open(os.path.join(os.path.dirname(__file__), "oneview_config.json"), encoding="utf-8") as _f:
        _CFG = json.load(_f)
except Exception:
    pass
ACCOUNTS = _CFG.get("accounts") or _DEFAULT_ACCOUNTS
THRESHOLDS = {**_DEFAULT_THRESHOLDS, **(_CFG.get("thresholds") or {})}

DONE = {"Done", "Closed", "Resolved", "Completed", "SA Passed in UAT"}  # SA Passed in UAT = closed
DEAD = {"Removed", "Duplicate", "Invalid", "Not a Bug"}

# Account-360 detail queries: out_key -> (query id, columns to keep). Keys resolved via qkey().
EXTRA = {
    "techStack":      ("659", ["systemtype", "systemname", "integrated"]),
    "relationships":  ("660", ["name", "stakeholder", "role", "phone", "email", "influence", "focusarea", "relationshipstatus",
                               "sentiment", "says", "think", "does", "feel", "individualstrategy"]),
    "businessLevers": ("661", ["businesslever", "definition", "direction"]),
    "modules":        ("662", ["modulename", "currentstatus", "adoptionstatus"]),
    "projectRisks":   ("663", ["riskstatement", "projectname", "projectid", "severity", "statuscode", "assignedtoname", "riskpendingon", "originationdate"]),
    "accountRisks":   ("664", ["risktype", "impact", "riskseverity", "riskdetail", "assignedto", "owner", "createdon", "plannedclouredate", "actualclosuredate", "riskcomments"]),
    "engagement":     ("665", {"cadencetype": "cadencetype", "startdate": "startdate", "duedate": "duedate",
                               "assignedto": "assignedto", "priority": "priority", "fathomrecordinglink": "fathomrecordinglink",
                               "Fathom Notes": "fathomNotes", "Outcome and Action Items": "outcomeActionItems"}),
    "onboardingPlaybook": ("668", ["layoutid", "layoutname", "timeline", "category", "actionitem", "owner", "platform", "status", "successindicator"]),
    # Account 360 Action Plan (Redash 700 by default; REDASH_ACTIONPLAN_QUERY_ID overrides) — CRM
    # columns have spaces/caps, so map to clean keys.
    "actionPlan":     (ACTIONPLAN_QID, {"Category": "category", "Owner Type": "ownerType", "Due Date": "dueDate",
                                        "Dependency": "dependency", "Priority": "priority",
                                        "createdon": "createdOn",
                                        "Created By": "createdBy", "detail": "detail"}),
    # Account 360 Business Objectives (Redash 705) — the account's own strategic goals + descriptions.
    "businessObjectives": ("705", {"Business Objective": "objective", "Description": "description"}),
}


# ---------- Redash ----------
def redash_rows():
    url = f"https://example.invalid"
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.loads(r.read().decode())["query_result"]["data"]["rows"]


def redash_query(qid, key):
    url = f"https://example.invalid}/results.json?api_key={key}"
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.loads(r.read().decode())["query_result"]["data"]["rows"]


def extra_index():
    """Fetch the account-360 queries; return {out_key: {accountid(str): [projected rows]}}.
    `cols` is either a list (output key == source column) or a dict {source_col: output_key}
    for queries whose columns need renaming (e.g. 700's 'Owner Type' -> 'ownerType')."""
    idx = {}
    for out_key, (qid, cols) in EXTRA.items():
        by_acct = {}
        for row in redash_query(qid, qkey(qid)):
            aid = str(row.get("accountid"))
            proj = ({out: row.get(src) for src, out in cols.items()} if isinstance(cols, dict)
                    else {c: row.get(c) for c in cols})
            # Drop rows where every displayed column is blank — no all-empty rows on the dashboard.
            if not any(v is not None and str(v).strip() != "" for v in proj.values()):
                continue
            by_acct.setdefault(aid, []).append(proj)
        idx[out_key] = by_acct
    return idx


# ---------- US Project Health (COE) ----------
# OneView's Project Health dimension + the Pre-Delivery/Delivery tab reuse the COE app's calc-RAG
# (US Project Health) so both dashboards agree on delivery health. We pull COE's already-computed
# per-project RAG server-to-server and match it to our accounts by Azure project name. COE is the
# single source of truth for the weighted formula — we never recompute it here.
COE_URL = os.environ.get("COE_INTERNAL_URL", "http://127.0.0.1:8000").rstrip("/")


def coe_project_index():
    """{azure_project_name: {calcRag, calcRagClass, weightedScore, ragTooltip, phase, pm}} keyed by
    Azure project name so it matches ACCOUNTS[*]['project']. `?force=false` returns COE's cached
    compute (no slow re-pull). Raises on an unreachable COE — source() then keeps last-known-good and
    the frontend falls back to OneView's own project-health score for any unmatched account."""
    with urllib.request.urlopen(COE_URL + "/api/refresh?force=false", timeout=120) as r:
        data = json.loads(r.read().decode())
    idx = {}
    for p in data.get("projects") or []:
        name = p.get("azure_project_name")
        if not name:
            continue
        idx[name] = {
            "calcRag": p.get("calc_rag"),
            "calcRagClass": p.get("calc_rag_class"),
            "weightedScore": p.get("weighted_score"),
            "ragTooltip": p.get("rag_tooltip"),
            "phase": p.get("phase"),
            "pm": p.get("pm"),
        }
    return idx


# ---------- Azure ----------
AZAUTH = "Basic " + base64.b64encode((":" + AZ_PAT).encode()).decode()


def az(url, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", AZAUTH)
    if data:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode())


def delivery(project):
    P = urllib.parse.quote(project, safe="")
    wiql = {"query": "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = @project"}
    ids = [w["id"] for w in az(f"{ORG}/{P}/_apis/wit/wiql?api-version=7.1", "POST", wiql).get("workItems", [])]
    items = []
    for i in range(0, len(ids), 200):
        csv = ",".join(map(str, ids[i:i + 200]))
        d = az(f"{ORG}/_apis/wit/workitems?ids={csv}&fields=System.WorkItemType,System.State,System.Title,Microsoft.VSTS.Common.Priority&api-version=7.1")
        items += d.get("value", [])
    types, states, prio = Counter(), Counter(), Counter()
    ts = {}
    recs = []  # per-item records for drill-downs
    for w in items:
        f = w["fields"]
        t = f.get("System.WorkItemType", "?"); s = f.get("System.State", "?")
        types[t] += 1; states[s] += 1
        p = f.get("Microsoft.VSTS.Common.Priority")
        if p is not None:
            prio[str(p)] += 1
        ts.setdefault(t, Counter())[s] += 1
        title = (f.get("System.Title") or "").strip()
        recs.append({"id": w.get("id"), "type": t, "state": s,
                     "priority": p, "title": title[:140]})

    def dt_(t):
        c = ts.get(t, Counter())
        return sum(v for s, v in c.items() if s in DONE), sum(c.values())

    fd, ftot = dt_("Feature")
    pd_, pt = dt_("Product Backlog Item")
    ud, ut = dt_("User Story")
    bugs = ts.get("Bug", Counter())
    imp = ts.get("Impediment", Counter())
    total = len(items)
    done_all = sum(v for s, v in states.items() if s in DONE)
    return {
        "project": project,
        "as_of": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "total": total,
        "by_type": dict(types.most_common()),
        "by_state": dict(states.most_common()),
        "priority": {k: prio[k] for k in sorted(prio)},
        "features": {"done": fd, "total": ftot, "pct": round(fd / ftot * 100, 1) if ftot else None},
        "pbis": {"done": pd_ + ud, "total": pt + ut, "pct": round((pd_ + ud) / (pt + ut) * 100, 1) if (pt + ut) else None},
        "open_bugs": sum(v for s, v in bugs.items() if s not in DONE and s not in DEAD and s != "Fixed"),
        "total_bugs": sum(bugs.values()),
        "open_impediments": sum(v for s, v in imp.items() if s not in DONE and s not in DEAD),
        "total_impediments": sum(imp.values()),
        "completion_pct": round(done_all / total * 100, 1) if total else None,
        "uat_states": {s: states[s] for s in states if "uat" in s.lower()},
        "items": recs,
    }


def iteration_dates(project_raw):
    """Sprint/phase start & finish dates from the Azure classification-nodes API, keyed by iteration path
    (e.g. 'Family Trust Project\\Setup Phase' -> (start, finish)). Real dates, not derived."""
    proj = urllib.parse.quote(project_raw, safe="")
    out = {}
    try:
        d = az(f"{ORG}/{proj}/_apis/wit/classificationnodes/iterations?$depth=2&api-version=7.1")
    except Exception:
        return out

    def walk(node, path):
        p = path + "\\" + node.get("name", "") if path else node.get("name", "")
        attrs = node.get("attributes") or {}
        out[p] = (attrs.get("startDate"), attrs.get("finishDate"))
        for c in node.get("children") or []:
            walk(c, p)
    walk(d, "")
    return out


# ---- Project-health constants (mirror the authoritative n8n "Roll Up Hours" node) ----
PH_TASK_DONE = {"done", "closed"}                                  # task treated as complete
PH_BUG_INACTIVE = {"closed", "sa passed in uat", "sa passed", "done", "duplicate", "not a bug", "invalid", "removed"}
PH_BUG_CLOSED = {"closed", "sa passed in uat", "sa passed", "done"}
PH_GREEN_STATES = {"sa uat signed-off", "closed", "under customer uat"}
PH_BUG_KW = ("bug", "bug fix", "defect", "fix", "hotfix")
PH_BUG_DEPS = ["Delivery", "Testing", "Product", "SDG", "Customer", "US Team"]
PH_FIRST_ORDER = ["pre kick off", "technical pre-requisites"]
PH_LAST_ORDER = ["load testing", "regression", "uat regression", "security testing", "customer uat",
                 "prod setup and go live", "prod setup and go-live", "pre prod and production setup"]


def project_health(project):
    """Whole-project health, computed to match the authoritative n8n weekly-health workflow exactly.
    Scope = ALL epics of the project pooled (account-level view). Every figure is a real Azure DevOps
    value: schedule variance = task-completion% − schedule-elapsed% (schedule derived from feature
    Custom.SADate/Custom.CompletionDate), quality = bug closure rate, bugs split by Custom.BugDependency
    into Delivery/Testing/Product/SDG/Customer/US Team. RAG per feature from state + completion date."""
    proj = urllib.parse.quote(project, safe="")
    F = "Microsoft.VSTS.Scheduling."
    C = "Microsoft.VSTS.Common."
    fields = ("System.Id,System.WorkItemType,System.Title,System.State,System.AssignedTo,"
              "System.CreatedDate,System.Parent,"
              f"{C}ClosedDate,{C}Severity,{F}OriginalEstimate,{F}CompletedWork,{F}RemainingWork,"
              "Custom.SADate,Custom.CompletionDate,Custom.BugDependency")
    wiql = {"query": "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = @project "
                     "AND [System.WorkItemType] IN ('Epic','Feature','User Story','Product Backlog Item','Task','Bug') "
                     "AND [System.State] NOT IN ('Removed')"}
    try:
        ids = [w["id"] for w in az(f"{ORG}/{proj}/_apis/wit/wiql?api-version=7.1", "POST", wiql).get("workItems", [])]
    except Exception as e:
        return {"error": str(e)}
    items = []
    for i in range(0, len(ids), 200):
        csv = ",".join(map(str, ids[i:i + 200]))
        items += az(f"{ORG}/_apis/wit/workitems?ids={csv}&fields={fields}&api-version=7.1").get("value", [])
    if not items:
        return {"error": "no work items found"}

    def name_of(v):
        return v.get("displayName") if isinstance(v, dict) else None

    def dt10(s):
        return s[:10] if isinstance(s, str) else None

    def to_date(s):
        s = dt10(s)
        return dt.date.fromisoformat(s) if s else None

    today = dt.datetime.now(dt.timezone.utc).date()

    # ---- classify by type (User Story treated as PBI; Task/Bug exclude Removed already via WIQL) ----
    epics, features, pbis, tasks, bugs = {}, {}, {}, {}, {}
    for w in items:
        f = w["fields"]; t = f.get("System.WorkItemType")
        wi = {"id": w["id"], "title": f.get("System.Title") or "", "state": f.get("System.State") or "",
              "type": t, "assignee": name_of(f.get("System.AssignedTo")) or "Unassigned",
              "parent": f.get("System.Parent"),
              "est": f.get(f"{F}OriginalEstimate") or 0, "comp": f.get(f"{F}CompletedWork") or 0,
              "rem": f.get(f"{F}RemainingWork") or 0,
              "start": to_date(f.get("Custom.SADate")), "end": to_date(f.get("Custom.CompletionDate")),
              "created": to_date(f.get("System.CreatedDate")), "closed": to_date(f.get(f"{C}ClosedDate")),
              "dep": (f.get("Custom.BugDependency") or "").strip()}
        if t == "Epic": epics[wi["id"]] = wi
        elif t == "Feature": features[wi["id"]] = wi
        elif t in ("User Story", "Product Backlog Item"): pbis[wi["id"]] = wi
        elif t == "Task": tasks[wi["id"]] = wi
        elif t == "Bug": bugs[wi["id"]] = wi

    if not features:
        return {"error": "no Feature found"}

    # ---- hierarchy: PBIs under features, tasks under PBIs; derive feature dates from children when unset ----
    feat_pbis = {}
    for p in pbis.values():
        if p["parent"] in features:
            feat_pbis.setdefault(p["parent"], []).append(p)
    pbi_tasks = {}
    for t in tasks.values():
        if t["parent"] in pbis:
            pbi_tasks.setdefault(t["parent"], []).append(t)
    for fid, feat in features.items():
        kids = feat_pbis.get(fid, [])
        if not feat["start"]:
            st = [p["start"] for p in kids if p["start"]]
            if st: feat["start"] = min(st)
        if not feat["end"]:
            en = [p["end"] for p in kids if p["end"]]
            if en: feat["end"] = max(en)

    # ---- leaves for completion: each feature's PBIs -> their task-children, or the PBI itself if childless ----
    leaves = []  # (item, feature_id)
    for fid in features:
        for p in feat_pbis.get(fid, []):
            kids = pbi_tasks.get(p["id"], [])
            for leaf in (kids if kids else [p]):
                leaves.append((leaf, fid))
    is_bug_kw = lambda title: any(k in (title or "").lower() for k in PH_BUG_KW)
    non_bug = [(x, fid) for (x, fid) in leaves if not is_bug_kw(x["title"])]

    # ---- completion by time / tasks / schedule ----
    tot_est = sum(x["est"] for x, _ in non_bug)
    tot_comp = sum(x["comp"] for x, _ in non_bug)
    tot_rem = sum(x["rem"] for x, _ in non_bug)
    completion_by_time = round(tot_comp / tot_est * 100) if tot_est else 0
    closed_leaf = sum(1 for x, _ in non_bug if x["state"].lower() in PH_TASK_DONE)
    completion_by_tasks = round(closed_leaf / len(non_bug) * 100) if non_bug else 0

    feat_starts = [f["start"] for f in features.values() if f["start"]]
    feat_ends = [f["end"] for f in features.values() if f["end"]]
    proj_start = min(feat_starts) if feat_starts else None
    proj_end = max(feat_ends) if feat_ends else None
    completion_by_schedule = 0
    if proj_start and proj_end and proj_end > proj_start:
        completion_by_schedule = round(max(0, min(1, (today - proj_start).days / (proj_end - proj_start).days)) * 100)
    schedule_variance = completion_by_tasks - completion_by_schedule

    # ---- bug -> nearest ancestor feature (<=5 hops; bug parented under an Epic -> that Epic's first feature) ----
    _feat_by_parent = {}
    for f in features.values():
        _feat_by_parent.setdefault(f["parent"], []).append(f["id"])

    def resolve_bug_feature(bug):
        cursor, hops = bug["parent"], 0
        while cursor is not None and hops < 5:
            if cursor in features:
                return cursor
            if cursor in epics:
                fk = _feat_by_parent.get(cursor)
                return fk[0] if fk else None
            if cursor in pbis:
                cursor = pbis[cursor]["parent"]; hops += 1; continue
            if cursor in tasks:
                cursor = tasks[cursor]["parent"]; hops += 1; continue
            break
        return None
    for b in bugs.values():
        b["featureId"] = resolve_bug_feature(b)
        b["featureTitle"] = features[b["featureId"]]["title"] if b["featureId"] in features else "Unclassified"

    # ---- bug velocity + closure rate (whole project = all bugs) ----
    last7 = today - dt.timedelta(days=7)
    bugs_opened_7 = sum(1 for b in bugs.values() if b["created"] and b["created"] >= last7)
    bugs_closed_7 = sum(1 for b in bugs.values() if b["closed"] and b["closed"] >= last7)
    total_open_bugs = sum(1 for b in bugs.values() if b["state"].lower() not in PH_BUG_INACTIVE)
    total_closed_bugs = sum(1 for b in bugs.values() if b["state"].lower() in PH_BUG_CLOSED)
    total_bugs_ever = total_open_bugs + total_closed_bugs
    bug_closure_rate = round(total_closed_bugs / total_bugs_ever * 100) if total_bugs_ever else 100
    bug_trend = "growing" if bugs_opened_7 > bugs_closed_7 else "shrinking" if bugs_opened_7 < bugs_closed_7 else "stable"

    # ---- scope: features/PBIs created after project start ----
    scope_added = []
    if proj_start:
        for w in list(features.values()) + [p for p in pbis.values() if p["parent"] in features]:
            if w["created"] and w["created"] > proj_start:
                scope_added.append({"type": "Feature" if w["type"] == "Feature" else "PBI",
                                    "title": w["title"], "createdDate": w["created"].isoformat()})
    scope_total = len(features) + sum(1 for p in pbis.values() if p["parent"] in features)
    scope_pct = round(len(scope_added) / scope_total * 100) if scope_total else 0

    # ---- verdict (exact n8n bands) ----
    quality_concern = bug_closure_rate < 70
    quality_watch = 70 <= bug_closure_rate < 85
    off_track = schedule_variance <= -20 or (quality_concern and schedule_variance <= -10)
    at_risk = schedule_variance <= -10 or quality_concern or (quality_watch and schedule_variance < 0)
    if off_track:
        verdict = "Off Track"
        reason = (f"{abs(schedule_variance)}% behind schedule" if schedule_variance <= -20
                  else f"Behind schedule and bug closure rate at {bug_closure_rate}%")
    elif at_risk:
        verdict = "At Risk"
        reason = (f"{abs(schedule_variance)}% behind schedule" if schedule_variance <= -10
                  else f"Bug closure rate {bug_closure_rate}% — resolution not keeping pace" if quality_concern
                  else f"{abs(schedule_variance)}% behind with bug closure rate at {bug_closure_rate}%")
    else:
        verdict = "On Track"
        reason = (f"{schedule_variance}% ahead of schedule · Bug closure rate {bug_closure_rate}%" if schedule_variance >= 0
                  else f"Within tolerance ({abs(schedule_variance)}% variance) · Bug closure rate {bug_closure_rate}%")

    # ---- RAG per feature (state + completion date) ----
    def feature_rag(feat):
        if feat["state"].lower() in PH_GREEN_STATES:
            return "green"
        if not feat["end"]:
            return None  # grey / unassessable
        diff = (feat["end"] - today).days
        return "red" if diff < 0 else "amber" if diff <= 5 else "green"

    # ---- per-feature open bugs + remaining hours (open non-bug leaves) ----
    open_bugs_by_feat = {}
    for b in bugs.values():
        if b["featureId"] in features and b["state"].lower() not in PH_BUG_INACTIVE:
            open_bugs_by_feat[b["featureId"]] = open_bugs_by_feat.get(b["featureId"], 0) + 1
    rem_by_feat, open_by_feat, total_by_feat = {}, {}, {}
    for x, fid in leaves:
        total_by_feat[fid] = total_by_feat.get(fid, 0) + 1
        is_open = x["state"].lower() not in PH_TASK_DONE
        if is_open:
            open_by_feat[fid] = open_by_feat.get(fid, 0) + 1
            if not is_bug_kw(x["title"]):
                rem_by_feat[fid] = rem_by_feat.get(fid, 0) + x["rem"]

    feature_rows = []
    for feat in features.values():
        feature_rows.append({
            "id": feat["id"], "title": feat["title"], "state": feat["state"], "assignedTo": feat["assignee"],
            "openBugs": open_bugs_by_feat.get(feat["id"], 0),
            "openTasks": open_by_feat.get(feat["id"], 0), "totalTasks": total_by_feat.get(feat["id"], 0),
            "remainingHours": round(rem_by_feat.get(feat["id"], 0), 1),
            "startDate": feat["start"].isoformat() if feat["start"] else None,
            "targetDate": feat["end"].isoformat() if feat["end"] else None,
            "rag": feature_rag(feat),
        })
    # canonical ordering: setup features first, go-live/regression last, rest by created
    def order_key(r):
        n = r["title"].strip().lower()
        if n in PH_FIRST_ORDER: return (0, PH_FIRST_ORDER.index(n))
        if n in PH_LAST_ORDER: return (2, PH_LAST_ORDER.index(n))
        return (1, 0)
    feature_rows.sort(key=order_key)
    features_closed = sum(1 for r in feature_rows if r["state"] == "Closed")
    features_new = sum(1 for r in feature_rows if r["state"] == "New")
    features_in_progress = len(feature_rows) - features_closed - features_new

    # ---- tasks summary by assignee (over leaves) ----
    by_person = {}
    for x, _ in leaves:
        who = x["assignee"]
        p = by_person.setdefault(who, {"toDo": 0, "inProgress": 0, "remainingHours": 0.0, "overdue": 0})
        st = x["state"].lower()
        if st in ("to do", "new"):
            p["toDo"] += 1
        elif st in ("in progress", "active"):
            p["inProgress"] += 1
        if st in ("to do", "new", "in progress", "active"):
            p["remainingHours"] += x["rem"]
            if x["end"] and x["end"] < today:
                p["overdue"] += 1
    tasks_by_person = sorted(
        [dict(name=k, remainingHours=round(v["remainingHours"], 1), toDo=v["toDo"], inProgress=v["inProgress"], overdue=v["overdue"]) for k, v in by_person.items()],
        key=lambda a: -(a["toDo"] + a["inProgress"]))

    # ---- actionable bug summary by feature, split by Custom.BugDependency (6 teams) ----
    actionable = [b for b in bugs.values() if b["state"].lower() not in PH_BUG_INACTIVE]
    bug_by_feat = {}
    for b in actionable:
        key = b["featureId"] if b["featureId"] in features else "unclassified"
        title = features[key]["title"] if key in features else "Unclassified"
        g = bug_by_feat.setdefault(key, {"feature": title, "total": 0, **{d: 0 for d in PH_BUG_DEPS}})
        g["total"] += 1
        for d in PH_BUG_DEPS:
            if d.lower() == b["dep"].lower():
                g[d] += 1
    bug_rows = sorted(bug_by_feat.values(), key=lambda g: -g["total"])
    dep_totals = {d: sum(g[d] for g in bug_rows) for d in PH_BUG_DEPS}

    epic_count = len(epics)
    primary_epic = max(epics.values(), key=lambda e: sum(1 for f in features.values() if f["parent"] == e["id"]), default=None) if epics else None
    label = (primary_epic["title"] if epic_count == 1 and primary_epic else f"All Epics ({epic_count})" if epic_count else "No Epic")

    return {
        "project": project, "epicId": primary_epic["id"] if primary_epic else None, "epicTitle": label,
        "epicCount": epic_count,
        "iterStart": proj_start.isoformat() if proj_start else None,
        "iterFinish": proj_end.isoformat() if proj_end else None,
        "verdict": verdict, "verdictReason": reason,
        "scheduleVariance": schedule_variance, "scheduleElapsedPct": completion_by_schedule, "tasksDonePct": completion_by_tasks,
        "bugClosurePct": bug_closure_rate, "bugsOpened7d": bugs_opened_7, "bugsClosed7d": bugs_closed_7, "bugTrend": bug_trend,
        "totalBugs": len(bugs), "openBugs": total_open_bugs, "closedBugs": total_closed_bugs,
        "scopeAdded": scope_added, "scopeTotal": scope_total, "scopePct": scope_pct,
        "completionByTime": completion_by_time, "completionByTasks": completion_by_tasks, "completionBySchedule": completion_by_schedule,
        "totalHours": {"estimated": round(tot_est, 1), "completed": round(tot_comp, 1), "remaining": round(tot_rem, 1)},
        "featuresTotal": len(feature_rows), "featuresClosed": features_closed, "featuresInProgress": features_in_progress, "featuresNew": features_new,
        "features": feature_rows,
        "tasksByPerson": tasks_by_person,
        "bugsByFeature": bug_rows, "openBugsTotal": len(actionable), "bugDepTotals": dep_totals,
    }


# ---------- FI Navigator xlsx ----------
def fi_records():
    import openpyxl
    wb = openpyxl.load_workbook(FIN, data_only=True, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    hdr_i = next(i for i, r in enumerate(rows) if r and "Full Name" in [str(c).strip() if c is not None else "" for c in r])
    header = [str(c).strip() if c is not None else "" for c in rows[hdr_i]]
    recs = []
    for r in rows[hdr_i + 1:]:
        if not r or all(c is None for c in r):
            continue
        recs.append({header[j]: r[j] for j in range(len(header)) if header[j]})
    return header, recs


# ---------- helpers ----------
def money_int(v):
    if v is None:
        return None
    d = re.sub(r"[^0-9]", "", str(v))
    return int(d) if d else None


def clean(field, v):
    if v is None:
        return None
    s = str(v).strip()
    if s == "" or s.upper() == "NOT AVAILABLE":
        return None
    if field == "executivesponsor" and len(s) <= 1:  # audit: O BEE "J" is junk
        return None
    return s


RISK = {"no risk": ("Healthy", "none"), "moderate risk": ("Watch", "moderate"), "high risk": ("At risk", "high")}

# Combined risk logic: account risk (q664) + project risk (q663) drive the health tier.
SEV = {"high": 3, "medium": 2, "low": 1}
CS_BY_TIER = {"none": "Healthy", "moderate": "Watch", "high": "At risk"}


def sev_rank(s):
    return SEV.get((s or "").strip().lower(), 0)


def compute_risk(acct):
    ar = acct.get("accountRisks", []) or []
    pr = acct.get("projectRisks", []) or []
    open_ar = [r for r in ar if not r.get("actualclosuredate")]
    open_pr = [r for r in pr if (r.get("statuscode") or "").strip().lower() not in ("resolved", "closed", "cancelled")]
    acc_sev = max([sev_rank(r.get("riskseverity")) for r in open_ar], default=0)
    proj_sev = max([sev_rank(r.get("severity")) for r in open_pr], default=0)
    combined = max(acc_sev, proj_sev)
    _rt = THRESHOLDS["riskSeverityTier"]
    tier = "high" if combined >= _rt["high"] else "moderate" if combined >= _rt["moderate"] else "none"
    return {
        "tier": tier, "accountSeverity": acc_sev, "projectSeverity": proj_sev, "combined": combined,
        "openAccountRisks": len(open_ar), "totalAccountRisks": len(ar),
        "openProjectRisks": len(open_pr), "totalProjectRisks": len(pr),
        "highOpenAccountRisks": sum(1 for r in open_ar if sev_rank(r.get("riskseverity")) >= 3),
        "highOpenProjectRisks": sum(1 for r in open_pr if sev_rank(r.get("severity")) >= 3),
    }


# ---------- LLM (Bifrost gateway) — AI insights, grounded in the data ----------
# Key lives in scripts/llm_key.json (gitignored, never committed) or LLM_API_KEY env var.
_LLMKEY = {}
try:
    with open(os.path.join(os.path.dirname(__file__), "llm_key.json"), encoding="utf-8") as _f:
        _LLMKEY = json.load(_f)
except Exception:
    pass

LLM_URL = os.environ.get("LLM_URL", "https://example.invalid")
LLM_KEY = os.environ.get("LLM_API_KEY") or _LLMKEY.get("LLM_API_KEY", "")
LLM_MODEL = os.environ.get("LLM_MODEL", "gemma4-26b")  # ornith1-0 now 400s ("could not auto resolve a provider"); reverted 2026-07-10
# Deterministic by default: the same data must yield the same narrative, so insights don't
# drift run-to-run. Combined with the input-hash reuse below, the LLM is only called when the
# underlying data actually changed.
LLM_TEMPERATURE = float(os.environ.get("LLM_TEMPERATURE", "0"))
# Set SKIP_AI=1 for a fast, gateway-independent refresh: reuses whatever AI content already
# exists in the previous OUT file instead of calling the (often slow/unreachable) LLM gateway.
SKIP_AI = os.environ.get("SKIP_AI", "").strip().lower() in ("1", "true", "yes")


def llm_insight(prompt, max_tokens=3000):
    if not LLM_KEY:
        return {"error": "LLM_API_KEY not set"}
    body = json.dumps({"model": LLM_MODEL, "max_tokens": max_tokens, "temperature": LLM_TEMPERATURE,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", LLM_KEY)
    req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=330) as r:
            d = json.loads(r.read().decode())
        text = "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            j = json.loads(m.group(0))
            return {"headline": j.get("headline"), "insights": j.get("insights") or j.get("observations") or [],
                    "actions": j.get("actions") or j.get("recommendations") or []}
        except Exception:
            pass
    return {"raw": text.strip()}


def _pctv(v):
    try:
        return f"{float(v) * 100:.2f}%"
    except Exception:
        return "N/A"


def _delivery_line(d):
    """Delivery summary for the AI prompt — accounts with no linked Azure project have d=None."""
    if not d:
        return "Delivery (Azure Boards): no data — this account has no linked Azure project"
    f, p = d.get("features") or {}, d.get("pbis") or {}
    return (f"Delivery: {d.get('total')} work items, {d.get('completion_pct')}% complete, "
            f"{d.get('open_bugs')} open bugs, {d.get('open_impediments')} open impediments, "
            f"Features {f.get('done')}/{f.get('total')}, Backlog {p.get('done')}/{p.get('total')}")


def acct_summary(a):
    h, d = a["health"], a.get("delivery")
    fi = (a.get("financial") or {}).get("fields") or {}
    mods = "; ".join(f"{m['modulename']}={m['currentstatus']}" for m in a.get("modules", []) if m.get("modulename"))
    tech = "; ".join(f"{t['systemname']}({t['systemtype']})" for t in a.get("techStack", []) if t.get("systemname"))
    stake = "; ".join(f"{p['name']}({p.get('stakeholder') or p.get('role') or ''})" for p in a.get("relationships", []) if p.get("name"))
    levers = " | ".join((l.get("direction") or l.get("definition") or "") for l in a.get("businessLevers", []) if (l.get("direction") or l.get("definition")))
    objectives = " | ".join((o.get("objective") or "") + (": " + o["description"] if o.get("description") else "")
                            for o in a.get("businessObjectives", []) if o.get("objective"))
    return "\n".join([
        f"Account: {a['name']}",
        f"Renewal risk: {h.get('renewalRisk')}; CS status: {h.get('cs')}; ARR(USD): {h.get('arr')}; Segment: {h.get('segment')}; Core: {h.get('coreSystem')}; Go-live: {h.get('goLive')}; Renewal: {h.get('renewalDate')}; Customer status: {h.get('customerStatus')}",
        _delivery_line(d),
        f"Risk (account + project): tier '{a.get('risk', {}).get('tier')}', {a.get('risk', {}).get('openAccountRisks')} open account risks, {a.get('risk', {}).get('openProjectRisks')} open project risks (of {a.get('risk', {}).get('totalProjectRisks')} logged), {a.get('risk', {}).get('highOpenProjectRisks')} of them high severity; renewal risk (commercial): {h.get('renewalRisk')}",
        f"Financials (FI Navigator): Assets ${fi.get('Assets')}k, ROA {_pctv(fi.get('Return on Assets'))}, NIM {_pctv(fi.get('Net Interest Margin'))}, Operating Efficiency {_pctv(fi.get('Operating Efficiency Ratio'))}, Net Worth Leverage {fi.get('Net Worth Leverage')}",
        f"Modules & adoption: {mods}",
        f"Tech stack: {tech}",
        f"Key stakeholders: {stake}",
        f"Strategic direction: {levers}",
        f"Business objectives: {objectives}",
    ])


def account_prompt(a):
    return ("You are a Customer Success analyst for BusinessNext (CRMNEXT). Using ONLY the real data below, produce "
            "concise executive AI insights for this ONE account. Do NOT invent numbers, names, or facts not present in the data. "
            'Return ONLY a JSON object: {"headline": a one-line summary, "insights": [3-4 short data-grounded observations], '
            '"actions": [2-3 specific recommended next actions]}.\n\n' + acct_summary(a))


def portfolio_prompt(accts):
    rows = "\n".join(
        f"- {a['name']}: renewal risk {a['health'].get('renewalRisk')}, ARR {a['health'].get('arr')}, delivery {(a.get('delivery') or {}).get('completion_pct')}% complete, "
        f"{(a.get('delivery') or {}).get('open_bugs')} open bugs, status {a['health'].get('customerStatus')}, segment {a['health'].get('segment')}" for a in accts)
    return ("You are Head of Customer Success analytics for BusinessNext. Using ONLY the portfolio data below, produce "
            "concise portfolio-level AI insights across these accounts. Do NOT invent numbers or facts. "
            'Return ONLY a JSON object: {"headline": one-line summary, "insights": [3-4 cross-portfolio observations], '
            '"actions": [2-3 prioritized actions]}.\n\nPortfoli/opt/portfolio/project' + rows)


def cross_account_prompt(accts):
    rows = []
    for a in accts:
        mods = a.get("modules") or []
        live = sum(1 for m in mods if any(k in str(m.get("currentstatus", "")).lower() for k in ("live", "active")))
        tt = (a.get("ticketTrend") or {}).get("trend") or {}
        rows.append(f"- {a['name']}: risk tier {a.get('risk', {}).get('tier')}, renewal risk {a['health'].get('renewalRisk')}, "
                    f"delivery {(a.get('delivery') or {}).get('completion_pct')}% ({(a.get('delivery') or {}).get('open_bugs')} open bugs), "
                    f"{live} live modules of {len(mods)}, segment {a['health'].get('segment')}, "
                    f"latest-FY support tickets {tt.get('latest')}")
    return ("You are Head of Customer Success analytics for BusinessNext. Look ACROSS the accounts below and identify "
            "PATTERNS that repeat across TWO OR MORE accounts (e.g. shared module-adoption lag, correlated delivery "
            "slippage, common risk drivers, segment-level trends). Use ONLY the data shown; do NOT invent numbers or facts, "
            "and only report a pattern if it is supported by two or more accounts. "
            'Return ONLY a JSON object: {"headline": one-line, "patterns": [{"pattern": short statement, '
            '"accounts": [names it applies to], "soWhat": one-line implication}]}. 2-4 patterns.\n\nAccount/opt/portfolio/project' + "\n".join(rows))


def cross_account_patterns(accts):
    """Portfolio-wide pattern detection across accounts (advisory). Same model/temperature as the
    other narratives; returns {headline, patterns:[{pattern, accounts, soWhat}]} or {error}."""
    if not LLM_KEY:
        return {"error": "LLM_API_KEY not set"}
    body = json.dumps({"model": LLM_MODEL, "max_tokens": 2000, "temperature": LLM_TEMPERATURE,
                       "messages": [{"role": "user", "content": cross_account_prompt(accts)}]}).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", LLM_KEY)
    req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=330) as r:
            d = json.loads(r.read().decode())
        text = "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            j = json.loads(m.group(0))
            pats = [p for p in (j.get("patterns") or []) if isinstance(p, dict) and p.get("pattern")]
            return {"headline": j.get("headline"), "patterns": pats}
        except Exception:
            pass
    return {"error": "unparseable"}


def growth_next_action_prompt(a):
    g = a.get("growth")
    if not g:
        return None
    f4, f5 = g.get("fy2024", {}), g.get("fy2025", {})

    def line(fy):
        return (f"Total Assets {fy.get('totalAssets')}, Loans {fy.get('loans')}, Deposits {fy.get('deposits')}, "
                f"Net Worth {fy.get('netWorth')}, Net Worth Ratio {fy.get('netWorthRatioPct')}%, Members {fy.get('members')}, "
                f"Net Income {fy.get('netIncome')}, Employees {fy.get('employees')}")
    notes = "; ".join(g.get("notes") or [])
    return ("You are a Customer Success strategist for BusinessNext (CRMNEXT), advising on a credit union account's "
            "growth & financial trajectory. Using ONLY the real FY2024 vs FY2025 figures and context notes below, recommend "
            "1-2 concrete, specific next actions the CS/account team should take. Ground each in the actual figures given; "
            "do NOT invent numbers or facts not present below. "
            'Return ONLY a JSON array of 1-2 short strings, e.g. ["Action one.", "Action two."].\n\n'
            f"Account: {a.get('name')}\nFY2024: {line(f4)}\nFY2025: {line(f5)}\nContext notes: {notes or 'none'}")


def ai_action_plan_prompt(a):
    """Prioritized AI action plan (up to 5) grounded in the account's full 360 data — advances its
    business objectives, mitigates risks, lifts adoption/engagement and protects the renewal."""
    return ("You are a Customer Success strategist for BusinessNext (CRMNEXT). Using ONLY the real 360 data below, produce a "
            "prioritized ACTION PLAN of UP TO 5 concrete next actions for this ONE account — actions that advance its business "
            "objectives, reduce its open risks, lift module adoption and engagement, and protect the renewal. Ground every action "
            "in specific data points; do NOT invent numbers, names, or facts not present in the data. Order most important first. "
            'Return ONLY a JSON array of UP TO 5 objects: [{"action": imperative next step (<=16 words), '
            '"priority": "High"|"Medium"|"Low", "rationale": one line citing the data, "objective": the business objective or focus it serves}].\n\n'
            + acct_summary(a))


def parse_action_plan(text):
    """Parse the AI action-plan JSON array; keep at most 5 well-formed items."""
    if not text:
        return []
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        arr = json.loads(m.group(0))
    except Exception:
        return []
    out = []
    for x in arr:
        if not isinstance(x, dict):
            continue
        act = x.get("action") or x.get("step") or x.get("title")
        if not act:
            continue
        pri = (x.get("priority") or "").strip().capitalize()
        out.append({"action": act, "priority": pri if pri in ("High", "Medium", "Low") else None,
                    "rationale": x.get("rationale") or x.get("reason") or x.get("basis"),
                    "objective": x.get("objective") or x.get("focus") or x.get("driver")})
    return out[:5]


def parse_string_list(text):
    if not text:
        return []
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        arr = json.loads(m.group(0))
    except Exception:
        return []
    return [str(x) for x in arr if isinstance(x, str) and x.strip()][:3]


def llm_call(prompt, max_tokens=3000):
    if not LLM_KEY:
        return None
    body = json.dumps({"model": LLM_MODEL, "max_tokens": max_tokens, "temperature": LLM_TEMPERATURE,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", LLM_KEY)
    req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=330) as r:
            d = json.loads(r.read().decode())
        return "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception:
        return None


def parse_risk_list(text):
    if not text:
        return []
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        arr = json.loads(m.group(0))
    except Exception:
        return []
    out = []
    for x in arr:
        if not isinstance(x, dict):
            continue
        sev = (x.get("severity") or "").strip().capitalize()
        out.append({"statement": x.get("statement") or x.get("risk") or x.get("title"),
                    "severity": sev if sev in ("High", "Medium", "Low") else None,
                    "rationale": x.get("rationale") or x.get("reason") or x.get("basis"),
                    "type": x.get("type") or x.get("category")})
    return [r for r in out if r["statement"]]


def ai_account_risk_prompt(a):
    logged = "; ".join(f"{r.get('risktype')}={r.get('riskseverity')}" for r in (a.get("accountRisks") or []) if r.get("risktype"))
    return ("You are a Customer Success risk analyst for BusinessNext (CRMNEXT). Based ONLY on the account data below, identify up to 4 "
            "ADDITIONAL potential ACCOUNT-LEVEL risks (strategic, adoption/usage, relationship, commercial/renewal, financial, governance) that are "
            "plausibly implied by the data but are NOT already in the logged risks. Ground each in specific data points; do NOT invent numbers or names. "
            'Return ONLY a JSON array: [{"statement": short risk (<=14 words), "severity": "High"|"Medium"|"Low", "rationale": one line citing the data, "type": category}].\n\n'
            f"Already-logged account risks (do NOT repeat): {logged or 'none'}\n\n" + acct_summary(a))


def ai_project_risk_prompt(a):
    logged = "; ".join(f"{r.get('severity')}:{(r.get('riskstatement') or '')[:45]}" for r in (a.get("projectRisks") or [])[:12])
    return ("You are a delivery/project risk analyst for BusinessNext (CRMNEXT). Based ONLY on the delivery and project data below (open bugs, "
            "impediments, feature/backlog completion, UAT signals, tech stack, logged project risks), identify up to 4 ADDITIONAL potential "
            "PROJECT/DELIVERY risks that are plausibly implied by the data but NOT already logged. Ground each in specific data points; do NOT invent numbers. "
            'Return ONLY a JSON array: [{"statement": short risk (<=14 words), "severity": "High"|"Medium"|"Low", "rationale": one line citing the data, "type": category}].\n\n'
            f"Already-logged project risks sample (do NOT repeat): {logged or 'none'}\n\n" + acct_summary(a))


def capacity(qid, source_label):
    """Current-month resource allocation from an Azure DevOps 'Resources_Data - Current Month'
    query (SDG or SAG resource-allocation dashboard). Utilization = committed effort
    (completed+remaining) vs original estimate, per client project. Source stores raw hours, not a native %."""
    from collections import defaultdict
    proj = urllib.parse.quote("US portfolio- Common Board", safe="")
    F = "Microsoft.VSTS.Scheduling."
    try:
        ids = [w["id"] for w in az(f"{ORG}/{proj}/_apis/wit/wiql/{qid}?api-version=7.1").get("workItems", [])]
    except Exception as e:
        return {"error": str(e)}
    items = []
    for i in range(0, len(ids), 200):
        csv = ",".join(map(str, ids[i:i + 200]))
        items += az(f"{ORG}/_apis/wit/workitems?ids={csv}&fields=System.AssignedTo,System.AreaPath,{F}OriginalEstimate,{F}CompletedWork,{F}RemainingWork&api-version=7.1").get("value", [])

    def num(f, k):
        v = f.get(F + k)
        return float(v) if isinstance(v, (int, float)) else 0.0

    grp = defaultdict(lambda: [0.0, 0.0, 0.0]); perp = defaultdict(lambda: [0.0, 0.0, 0.0])
    tot = [0.0, 0.0, 0.0]; people = set()
    for w in items:
        f = w["fields"]; oe, cw, rw = num(f, "OriginalEstimate"), num(f, "CompletedWork"), num(f, "RemainingWork")
        area = (f.get("System.AreaPath") or "?").split("\\")[-1]
        grp[area][0] += oe; grp[area][1] += cw; grp[area][2] += rw
        tot[0] += oe; tot[1] += cw; tot[2] += rw
        a = f.get("System.AssignedTo"); nm = a.get("displayName") if isinstance(a, dict) else None
        if nm:
            people.add(nm); perp[nm][0] += oe; perp[nm][1] += cw; perp[nm][2] += rw

    def pct(c, r, o):
        return round((c + r) / o * 100) if o else None

    def rows(dd):
        rs = [{"name": n, "origEst": v[0], "completed": v[1], "remaining": v[2], "utilPct": pct(v[1], v[2], v[0])} for n, v in dd.items()]
        rs.sort(key=lambda x: -(x["origEst"] or 0))
        return rs

    cats = rows(grp)
    return {"month": "current", "source": source_label,
            "metric": "committed effort (completed + remaining) vs original estimate",
            "items": len(items), "resources": len(people),
            "totals": {"origEst": tot[0], "completed": tot[1], "remaining": tot[2]},
            "overallUtilPct": pct(tot[1], tot[2], tot[0]),
            "overAllocated": sum(1 for c in cats if (c["utilPct"] or 0) > 100),
            "categories": cats, "byResource": rows(perp)}


def aggregate_capacity(groups, source_label):
    """Overall utilization = the SDG + SAG + ESG delivery groups COMBINED. Sums the raw hours
    (committed = completed + remaining, vs original estimate) across the three groups rather than
    averaging their percentages, so larger groups weigh proportionally. Resources are unioned by
    name (a person in two groups counts once). Same output shape as capacity() so the UI renders
    it identically.

    Replaces the standalone "US Portolio-Onshore" overall query, which pulled a different, smaller
    dataset (e.g. 86 tasks / 4 resources / 38%) that did not reconcile with SDG+SAG+ESG."""
    valid = [g for g in groups if g and not g.get("error")]
    if not valid:
        return {"error": "no SDG/SAG/ESG capacity available to aggregate"}
    tot = [0.0, 0.0, 0.0]  # origEst, completed, remaining
    items = 0
    cats = []
    perp = {}
    for g in valid:
        t = g.get("totals") or {}
        tot[0] += t.get("origEst", 0) or 0
        tot[1] += t.get("completed", 0) or 0
        tot[2] += t.get("remaining", 0) or 0
        items += g.get("items", 0) or 0
        cats += g.get("categories") or []
        for r in g.get("byResource") or []:
            p = perp.setdefault(r.get("name"), [0.0, 0.0, 0.0])
            p[0] += r.get("origEst", 0) or 0
            p[1] += r.get("completed", 0) or 0
            p[2] += r.get("remaining", 0) or 0

    def pct(c, r, o):
        return round((c + r) / o * 100) if o else None

    cats_sorted = sorted(cats, key=lambda c: -(c.get("origEst") or 0))
    byres = [{"name": n, "origEst": v[0], "completed": v[1], "remaining": v[2], "utilPct": pct(v[1], v[2], v[0])}
             for n, v in perp.items()]
    byres.sort(key=lambda x: -(x["origEst"] or 0))
    return {"month": "current", "source": source_label,
            "metric": "committed effort (completed + remaining) vs original estimate — SDG + SAG + ESG combined",
            "items": items, "resources": len(perp),
            "totals": {"origEst": tot[0], "completed": tot[1], "remaining": tot[2]},
            "overallUtilPct": pct(tot[1], tot[2], tot[0]),
            "overAllocated": sum(1 for c in cats if (c.get("utilPct") or 0) > 100),
            "categories": cats_sorted, "byResource": byres}


SDG_QID = "REDACTED_OPAQUE_VALUE"  # dashboard: SDG (Imp)-Resource Allocation
SAG_QID = "REDACTED_OPAQUE_VALUE"  # dashboard: SAG-Resource Allocation Summary
ESG_QID = "REDACTED_OPAQUE_VALUE"  # dashboard: ESG-Resource Allocation Summary
# OVERALL_QID (dashboard: US Portolio-Onshore) is no longer queried — Overall is derived from SDG+SAG+ESG.


FI_PDFS = {"obee": "O BEE FI Navigator.pdf", "sesloc": "SESLOC FI Navigator.pdf", "CUSTOMER_REDACTED": "CUSTOMER_REDACTED FI Navigator.pdf"}
FIN_PROMPT = ("You are a credit-union financial analyst. The attached images are the FULL FI Navigator report for {name}. "
              "Read them carefully and assess the institution's FINANCIAL HEALTH. Output ONLY a JSON object: "
              '{{"rating": "Strong"|"Moderate"|"Watch"|"Weak", "score": integer 0-100, "headline": one concise line, '
              '"insights": [3-4 findings citing specific figures/ratios visible in the report], "strengths": [2-3], "concerns": [2-3], '
              '"nextActions": [1-2 concrete recommended next actions for the customer-success / account team]}}. '
              "Base everything ONLY on what is visible in the report; do NOT invent numbers.")


def render_pdf_pages(path, dpi=82, maxpages=6):
    import fitz
    doc = fitz.open(path)
    out = []
    for i, pg in enumerate(doc):
        if i >= maxpages:
            break
        out.append(base64.b64encode(pg.get_pixmap(dpi=dpi).tobytes("png")).decode())
    return out


def _pct_change(a, b):
    try:
        return round((b - a) / a * 100, 1) if a else None
    except (TypeError, ZeroDivisionError):
        return None


def financial_health_score(growth):
    """Deterministic, standards-based credit-union financial health from the FY2025 FI Navigator
    ratios — NO LLM, NO vision-reading (which could misread a figure). Bands follow NCUA/industry
    norms: capital (net worth ratio; well-capitalized ≥7%, strong ≥10%, very strong ≥12%), asset
    quality (delinquency, lower is better), earnings (ROA), liquidity (loan-to-share sweet spot
    70–90%), growth (assets YoY). Returns None if the account has no financials — never fabricated."""
    g = (growth or {}).get("fy2025") or {}
    f4 = (growth or {}).get("fy2024") or {}
    nwr, delq, lts = g.get("netWorthRatioPct"), g.get("delinquencyRatePct"), g.get("loanToShareRatioPct")
    ni, ta = g.get("netIncome"), g.get("totalAssets")
    roa = round(ni / ta * 100, 2) if isinstance(ni, (int, float)) and isinstance(ta, (int, float)) and ta else None
    asset_growth = _pct_change(f4.get("totalAssets"), g.get("totalAssets"))

    def band(v, thresholds, lower=False):
        if not isinstance(v, (int, float)):
            return None
        for thr, pts in thresholds:
            if (v <= thr) if lower else (v >= thr):
                return pts
        return 0

    liq = None
    if isinstance(lts, (int, float)):
        liq = 15 if 70 <= lts <= 90 else 10 if 60 <= lts <= 100 else 5
    dims = [
        ("Capital · net worth ratio", nwr, band(nwr, [(12, 30), (10, 25), (8, 19), (7, 13), (0, 4)]), 30, "%"),
        ("Asset quality · delinquency", delq, band(delq, [(0.5, 20), (1.0, 16), (2.0, 10), (3.0, 4), (999, 0)], lower=True), 20, "%"),
        ("Earnings · ROA", roa, band(roa, [(1.0, 20), (0.5, 14), (0.0, 8), (-999, 0)]), 20, "%"),
        ("Liquidity · loan-to-share", lts, liq, 15, "%"),
        ("Growth · assets YoY", asset_growth, band(asset_growth, [(8, 15), (3, 10), (0, 5), (-999, 0)]), 15, "%"),
    ]
    scored = [(lbl, v, p, m, u) for lbl, v, p, m, u in dims if p is not None]
    if not scored:
        return None
    earned = sum(p for _, _, p, _, _ in scored)
    maxp = sum(m for _, _, _, m, _ in scored)
    score = round(earned / maxp * 100)
    rating = "Strong" if score >= 85 else "Moderate" if score >= 65 else "Watch" if score >= 50 else "Weak"
    basis = [{"factor": lbl, "value": v, "unit": u, "points": p, "max": m} for lbl, v, p, m, u in scored]
    strengths = [f"{lbl}: {v}{u}" for lbl, v, p, m, u in scored if p >= m * 0.8]
    concerns = [f"{lbl}: {v}{u}" for lbl, v, p, m, u in scored if p < m * 0.5]
    headline = f"{rating} ({score}/100) — net worth ratio {nwr}%" + (f", delinquency {delq}%" if delq is not None else "") + (f", ROA {roa}%" if roa is not None else "") + "."
    return {"rating": rating, "score": score, "headline": headline, "basis": basis,
            "coverage": {"scored": len(scored), "of": len(dims)},  # honesty: a score from few factors is less robust
            "strengths": strengths[:3], "concerns": concerns[:3],
            "insights": [f"{b['factor']}: {b['value']}{b['unit']} → {b['points']}/{b['max']} pts" for b in basis],
            "source": "Computed from FY2025 FI Navigator ratios (deterministic)"}


def financial_health(slug, name):
    """Vision-read the account's FI Navigator PDF with the configured LLM -> structured financial health."""
    import os
    if not LLM_KEY:
        return {"error": "LLM_API_KEY not set"}
    pdf_name = FI_PDFS.get(slug)
    if not pdf_name:
        return {"error": "No FI Navigator PDF for this account"}
    path = os.path.join(FIN_DIR, pdf_name)
    if not os.path.isfile(path):
        return {"error": "PDF not found"}
    content = [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b}} for b in render_pdf_pages(path)]
    content.append({"type": "text", "text": FIN_PROMPT.format(name=name)})
    body = json.dumps({"model": LLM_MODEL, "max_tokens": 4000, "temperature": LLM_TEMPERATURE, "messages": [{"role": "user", "content": content}]}).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json"); req.add_header("x-api-key", LLM_KEY); req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=420) as r:
            d = json.loads(r.read().decode())
        text = "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return {"raw": text.strip()}
    try:
        j = json.loads(m.group(0))
    except Exception:
        return {"raw": text.strip()}
    rating = (j.get("rating") or "Moderate").strip().title()
    if rating not in ("Strong", "Moderate", "Watch", "Weak"):
        rating = "Moderate"
    return {"rating": rating, "score": j.get("score"), "headline": j.get("headline"),
            "insights": j.get("insights") or [], "strengths": j.get("strengths") or [], "concerns": j.get("concerns") or [],
            "nextActions": j.get("nextActions") or j.get("actions") or [],
            "source": f"FI Navigator PDF (vision-read by {LLM_MODEL})"}


def production_cases():
    """Open production support cases from Redash query 666 (oneview-productioncases)."""
    try:
        rows = redash_query("666", qkey("666"))
    except Exception as e:
        return {"error": str(e)}
    keep = ["caseid", "accountname", "accountid", "subject", "projectname", "casereportedon",
            "reportedby", "casepriority", "casestatus", "casecategory", "casesubcategory", "aging", "appliesto"]
    return [{k: r.get(k) for k in keep} for r in rows]


def case_sla():
    """Case SLA-by-priority matrix from Redash query 669 -> {CustomerName: row}. Sole basis for Support Health."""
    try:
        rows = redash_query("669", qkey("669"))
    except Exception:
        return {}
    keep = ["P1 Within SLA", "P1 Outside SLA", "P2 Within SLA", "P2 Outside SLA",
            "P3 Within SLA", "P3 Outside SLA", "P4 Status Case", "No Priority Cases"]
    return {r.get("CustomerName"): {k: r.get(k) for k in keep} for r in rows if r.get("CustomerName")}


def ticket_rows():
    """Support ticket volume by fiscal year, account and priority (Redash 607). A leading indicator:
    rising ticket volume signals friction ahead of renewal. Read-level; global key."""
    return redash_query("607", qkey("607"))


def account_ticket_trend(rows, subs):
    """Per-account ticket-volume trend: totals per fiscal year (all its name variants), latest-vs-prior
    delta. Returns None if this account has no ticket rows — never fabricated."""
    by_year = {}
    for r in rows:
        nm = str(r.get("account_name", "")).lower()
        if not any(s in nm for s in subs):
            continue
        fy = r.get("finyear")
        cnt = r.get("total_count") or 0
        e = by_year.setdefault(fy, {"total": 0, "byPriority": {}})
        e["total"] += cnt
        pr = r.get("priority") or "?"
        e["byPriority"][pr] = e["byPriority"].get(pr, 0) + cnt
    if not by_year:
        return None
    fys = sorted(by_year)
    trend = None
    if len(fys) >= 2:
        latest, prior = by_year[fys[-1]]["total"], by_year[fys[-2]]["total"]
        trend = {"latestFy": fys[-1], "priorFy": fys[-2], "latest": latest, "prior": prior,
                 "deltaPct": round((latest - prior) / prior * 100, 1) if prior else None,
                 "direction": "up" if latest > prior else "down" if latest < prior else "flat"}
    return {"byYear": by_year, "trend": trend, "source": "Redash 607 · support ticket volume"}


# ---------- AI grounding validator ----------
# The LLM is told to use ONLY the real data, but a prompt is a request, not a guarantee. This is the
# enforcement pass: after a narrative is generated we check every DATA number it states (money,
# percentages, ratios, counts) against that account's own structured inputs. Any figure the data does
# not support is recorded as ungrounded so the UI flags it and it is never presented as a verified
# fact. Deterministic, no LLM — a pure post-generation check.
#
# A source value can legitimately appear at a different magnitude, or as a percent vs a fraction:
#   source 1_200_000            vs  "$1.2M"
#   source 0.0868 (fraction)    vs  "8.68%" / "8.7%" / "~9%"
#   source 663_000 (thousands)  vs  "$663M"
# So we sweep these scales and accept a match if some source value, rescaled, rounds to the claimed
# number at the claim's OWN precision. Deliberately lenient: we only want to flag a figure we are
# confident the data never supports, so a coincidental match (which suppresses a flag) is acceptable.
_GROUND_SCALES = (1, 1e-2, 1e2, 1e-3, 1e3, 1e-6, 1e6, 1e-9, 1e9)
# A number token: optional $ prefix, thousands separators, decimals, and a %/k/m/b suffix.
_NUM_RE = re.compile(r"(?P<dollar>\$)?\s*(?P<num>\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?P<suf>%|[kKmMbB])?")

# AI-derived fields are NOT ground truth — a narrative must not be able to justify itself with another
# narrative. Everything else on the account (commercial, delivery, risk, financial, growth, and the
# DETERMINISTIC financialHealth) is real source data and counts as truth.
_TRUTH_EXCLUDE = {"ai", "aiAccountRisks", "aiProjectRisks", "growthNextAction", "aiActionPlan", "_aiInputHash"}

# Person-name shape (Title-Case bi/tri-grams). Advisory only — see ground_narrative.
_NAME_RE = re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})\b")
# Leading words that make a Title-Case run sentence prose, not a name.
_NAME_LEAD_STOP = {"the", "this", "that", "these", "those", "their", "its", "our", "we", "with",
                   "for", "and", "but", "however", "overall", "given", "based", "strong",
                   "moderate", "weak", "watch", "high", "low", "no", "all", "both", "each"}
_MONTHS = {"january", "february", "march", "april", "may", "june", "july", "august",
           "september", "october", "november", "december"}
# Analytical vocabulary that appears in narratives but not necessarily in raw data VALUES.
_NAME_STOP = {
    "customer success", "net interest margin", "return on assets", "operating efficiency",
    "net worth", "loan to share", "credit union", "community credit", "annual contract value",
    "go live", "renewal risk", "support health", "cross sell", "deposit growth", "digital member",
    "member engagement", "call report", "fi navigator", "azure boards", "production support",
    "account owner", "implementation manager", "executive sponsor", "customer success manager",
    "support ticket", "asset quality", "core system", "tech stack", "next action", "fiscal year",
    "per employee", "net income", "asset size", "total assets", "customer status", "renewal date",
    "recommended actions", "key stakeholders", "customer segment", "cloud cost",
}


def _collect_truth_numbers(obj, out):
    if isinstance(obj, bool):
        return  # bools are not quantities
    if isinstance(obj, (int, float)):
        out.append(float(obj))
    elif isinstance(obj, str):
        for m in _NUM_RE.finditer(obj):
            try:
                out.append(float(m.group("num").replace(",", "")))
            except ValueError:
                pass
    elif isinstance(obj, dict):
        for v in obj.values():
            _collect_truth_numbers(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_truth_numbers(v, out)


def _collect_truth_strings(obj, out):
    if isinstance(obj, str):
        out.append(obj.lower())
    elif isinstance(obj, dict):
        for v in obj.values():
            _collect_truth_strings(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_truth_strings(v, out)


def account_truth_numbers(acct):
    """Every numeric value that appears anywhere in an account's real (non-AI) inputs."""
    nums = []
    _collect_truth_numbers({k: v for k, v in acct.items() if k not in _TRUTH_EXCLUDE}, nums)
    return nums


def account_truth_blob(acct):
    """Lower-cased concatenation of every real (non-AI) string on an account, for name grounding."""
    strs = []
    _collect_truth_strings({k: v for k, v in acct.items() if k not in _TRUTH_EXCLUDE}, strs)
    return " | ".join(strs)


def _num_grounded(literal, truth):
    """True if some source value, at some scale, rounds to `literal` at the claim's own precision."""
    try:
        claim = float(literal.replace(",", ""))
    except ValueError:
        return True  # unparseable -> never flag
    dec = len(literal.split(".")[1]) if "." in literal else 0
    for t in truth:
        for s in _GROUND_SCALES:
            if round(t * s, dec) == claim:
                return True
    return False


def _checkable_number(dollar, literal, suf):
    """Only DATA numbers are checked. A bare small integer ('3-4 observations', 'top 2 actions') is
    prose, not a data claim, and is skipped to keep flags high-precision. A number counts as a data
    claim if it carries a $/%/k/m/b marker, has decimals, or is >= 100."""
    if dollar or suf or "." in literal:
        return True
    try:
        return abs(float(literal.replace(",", ""))) >= 100
    except ValueError:
        return False


def _name_grounded(cand, blob):
    # A Title-Case run can pick up a leading verb ("Engage Jane Rivera") or trailing role ("Jane
    # Rivera CSM"), so we ground it if the whole run OR any 2-word window of it appears in the real
    # data or the known analytical vocabulary. Only a run with no grounded window is advisory-flagged.
    words = cand.lower().split()
    windows = [cand.lower()] + [" ".join(words[i:i + 2]) for i in range(len(words) - 1)]
    for w in windows:
        if w in blob:
            return True
        if w in _NAME_STOP or any(w in sp or sp in w for sp in _NAME_STOP):
            return True
    return any(x in _MONTHS for x in words)


def _narrative_texts(ai):
    if not isinstance(ai, dict):
        return []
    out = []
    if ai.get("headline"):
        out.append(str(ai["headline"]))
    for key in ("insights", "actions"):
        out.extend(str(x) for x in (ai.get(key) or []))
    if ai.get("raw"):
        out.append(str(ai["raw"]))
    return out


def ground_narrative(ai, truth_numbers, truth_blob):
    """Verify an AI narrative against an account's real inputs. Returns a grounding record; the
    narrative TEXT is never altered — we flag, never silently rewrite. `ok` is False iff at least one
    checkable DATA number is unsupported by the source. Unknown person-names are advisory only
    (`ungroundedNames`) and do NOT set `ok` — name matching is heuristic and must not gate the data."""
    ungrounded, names, checked = [], [], 0
    for text in _narrative_texts(ai):
        for m in _NUM_RE.finditer(text):
            lit = m.group("num")
            if not _checkable_number(m.group("dollar"), lit, m.group("suf")):
                continue
            checked += 1
            if not _num_grounded(lit, truth_numbers):
                tok = (m.group(0) or "").strip()
                if tok not in ungrounded:
                    ungrounded.append(tok)
        for m in _NAME_RE.finditer(text):
            cand = m.group(1)
            if cand.split()[0].lower() in _NAME_LEAD_STOP:
                continue
            if not _name_grounded(cand, truth_blob) and cand not in names:
                names.append(cand)
    rec = {"ok": not ungrounded, "checkedNumbers": checked,
           "ungroundedNumbers": ungrounded, "checkedAt": _now_iso()}
    if names:
        rec["ungroundedNames"] = names  # advisory — review, does not fail the narrative
    return rec


def ground_all(out):
    """Run the grounding pass over every account narrative and the portfolio narrative. Mutates the
    narratives in place (adds `grounding` + `ungrounded`) and returns the list of flagged slugs."""
    flagged = []
    for a in out.get("accounts", []):
        ai = a.get("ai")
        if isinstance(ai, dict) and not ai.get("error"):
            g = ground_narrative(ai, account_truth_numbers(a), account_truth_blob(a))
            ai["grounding"] = g
            ai["ungrounded"] = not g["ok"]
            if not g["ok"]:
                flagged.append(a.get("slug"))
    # Portfolio narrative is grounded against the union of every account's inputs.
    pai = out.get("portfolioAI")
    if isinstance(pai, dict) and not pai.get("error"):
        nums, blobs = [], []
        for a in out.get("accounts", []):
            nums += account_truth_numbers(a)
            blobs.append(account_truth_blob(a))
        g = ground_narrative(pai, nums, " | ".join(blobs))
        pai["grounding"] = g
        pai["ungrounded"] = not g["ok"]
        if not g["ok"]:
            flagged.append("portfolio")
    return flagged


def build():
    prev = load_prev()  # last-known-good, for source fallback + AI-narrative reuse
    prev_by_slug = {a.get("slug"): a for a in (prev.get("accounts") or [])}
    # Provisional total; refined to the exact step count once the AI job list is known.
    prog_total(20 + (5 * len(ACCOUNTS) + 1))
    # The account list (657) is critical — if it fails we abort rather than overwrite good data.
    prog("Commercial health — Redash query 657")
    rrows = {r["accountname"]: r for r in source("redash657", redash_rows, critical=True)}
    # The portfolio is the roster in oneview_config.json, not whatever 657 returns, so a customer
    # added in the CRM is invisible here until someone adds it — which is exactly how Sound Credit
    # Union sat in 657 for weeks while the portal showed 16 of 17. Say so loudly instead of
    # silently dropping it; the fix is one line of config, but only if you know it is needed.
    _known = {c["redash"] for c in ACCOUNTS.values()}
    _unrostered = sorted(set(rrows) - _known)
    _missing = sorted(n for n in _known if n not in rrows)
    if _unrostered:
        print("WARNING: Redash 657 returns %d account(s) with no entry in oneview_config.json — "
              "they are NOT in the portal: %s" % (len(_unrostered), ", ".join(_unrostered)),
              file=sys.stderr)
    if _missing:
        print("WARNING: %d rostered account(s) are absent from Redash 657 (renamed or removed?): %s"
              % (len(_missing), ", ".join(_missing)), file=sys.stderr)
    prog("FI Navigator financials")
    fi_header, fi_recs = source("fiNavigator", fi_records, fallback=(prev.get("_fiHeader", []), []))
    prog("Account detail — Redash queries 659–668")
    extras = source("redashDetail", extra_index, fallback={k: {} for k in EXTRA})
    prog("Growth metrics")
    growth = source("growth", growth_metrics, fallback={})
    prog("Support SLA — Redash query 669")
    sla = source("supportSla", case_sla, fallback={})
    prog("Support ticket trend — Redash query 607")
    trows = source("ticketTrend", ticket_rows, fallback=[])

    def find_fi(subs):
        for rec in fi_recs:
            name = str(rec.get("Full Name", "")).lower()
            if any(sub in name for sub in subs):
                return rec
        return None

    out = {"generatedAt": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
           "sources": {"redash": 657, "azureOrg": "acidaes", "financial": "FI Navigator", "aiModel": LLM_MODEL},
           "accounts": []}

    # US Project Health (COE calc-RAG), matched to each account by Azure project name below.
    prog("US Project Health — COE calc-RAG (server-to-server)")
    coe_ph = source("coeProjectHealth", coe_project_index, fallback={}) or {}

    for slug, cfg in ACCOUNTS.items():
        r = rrows.get(cfg["redash"], {})
        risk_raw = clean("renewalrisk", r.get("renewalrisk")) or ""
        cs, tier = RISK.get(risk_raw.lower(), ("Watch", "moderate"))
        fi = find_fi(cfg["fi"]) or {}
        acct_name = r.get("accountname") or slug
        pa = prev_by_slug.get(slug) or {}
        prog("Delivery rollup — " + acct_name + " (Azure Boards)")
        acct_delivery = source("delivery:" + slug, lambda p=cfg["project"]: delivery(p), fallback=pa.get("delivery"))
        prog("Project health — " + acct_name + " (Azure Boards)")
        acct_project_health = source("projectHealth:"PORTFOLIO_REDACTED"project"]: project_health(p), fallback=pa.get("projectHealth"))
        acct = {
            "slug": slug,
            "name": r.get("accountname"),
            "health": {
                "renewalRisk": risk_raw or None, "cs": cs, "riskTier": tier,
                "arr": money_int(r.get("annualcontractvalue")),
                "cloudCost": money_int(r.get("annualcloudcost")),
                "assetSize": money_int(r.get("assetsize")),
                "users": money_int(r.get("totalusers")) or money_int(r.get("licenseduser")),
                "segment": clean("customersegment", r.get("customersegment")),
                "coreSystem": clean("coresystem", r.get("coresystem")),
                "state": clean("consigneestate", r.get("consigneestate")),
                "customerStatus": clean("customerstatus", r.get("customerstatus")),
                "goLive": clean("golivedatephase1", r.get("golivedatephase1")),
                "renewalDate": clean("renewaldate", r.get("renewaldate")),
                "msaDate": clean("msadate", r.get("msadate")),
                "csm": clean("customersucessmanager", r.get("customersucessmanager")),
                "accountOwner": clean("accountowner", r.get("accountowner")),
                "implementationManager": clean("implementationmanager", r.get("implementationmanager")),
                "executiveSponsor": clean("executivesponsor", r.get("executivesponsor")),
            },
            "delivery": acct_delivery,
            "financial": {"source": "FI Navigator", "assetsUnit": "USD thousands",
                          "fields": {k: fi.get(k) for k in fi_header if k}} if fi else None,
            "growth": growth.get(slug),
            "caseSla": sla.get(cfg["redash"]),
            "projectHealth": acct_project_health,
        }
        # COE calc-RAG for this account's Azure project (None if the account has no Azure project
        # — e.g. CUSTOMER_REDACTED/gather — or COE is unreachable; the frontend then uses its own score).
        proj_name = cfg.get("project")
        acct["coeProjectHealth"] = coe_ph.get(proj_name) if proj_name else None
        aid = str(r.get("accountid"))
        for ek in EXTRA:
            acct[ek] = extras[ek].get(aid, [])
        acct["ticketTrend"] = account_ticket_trend(trows, cfg["fi"])  # leading indicator (display)
        # Last-known-good heal: if a source failed this run, restore that field from the previous
        # output and leave it marked stale in provenance — never blank out or invent a value.
        if _PROV.get("fiNavigator", {}).get("status") != "ok" and pa.get("financial"):
            acct["financial"] = pa["financial"]
        if _PROV.get("growth", {}).get("status") != "ok" and pa.get("growth") is not None:
            acct["growth"] = pa["growth"]
        if _PROV.get("supportSla", {}).get("status") != "ok" and pa.get("caseSla") is not None:
            acct["caseSla"] = pa["caseSla"]
        if _PROV.get("redashDetail", {}).get("status") != "ok":
            for ek in EXTRA:
                if pa.get(ek) is not None:
                    acct[ek] = pa[ek]
        if _PROV.get("coeProjectHealth", {}).get("status") != "ok" and pa.get("coeProjectHealth") is not None:
            acct["coeProjectHealth"] = pa["coeProjectHealth"]
        # Combined risk (account + project) now drives the health tier; renewalRisk stays commercial.
        acct["risk"] = compute_risk(acct)
        acct["health"]["riskTier"] = acct["risk"]["tier"]
        acct["health"]["cs"] = CS_BY_TIER[acct["risk"]["tier"]]
        # Financial health is now DETERMINISTIC — computed from the real FY2025 ratios, not vision-read
        # from the PDF. Standards-based, explainable, and it can never misread a figure.
        acct["financialHealth"] = financial_health_score(acct.get("growth")) or {"error": "No financial data for this account"}
        acct["_aiInputHash"] = ai_input_hash(acct)  # drives narrative reuse — same data, same words
        out["accounts"].append(acct)

    # AI insights (Bifrost LLM gateway), grounded strictly in the data above.
    # Independent per-account/portfolio calls -> dispatched concurrently (each is a slow serial
    # network call to a local reasoning model; sequential execution does not scale to ~20 calls).
    # Concurrency is kept modest — this model runs on a single local inference backend, and higher
    # fan-out was observed to cause contention that made calls time out rather than complete.
    import concurrent.futures as cf

    def ai_result_ok(key, res):
        if res is None:
            return False
        if isinstance(res, dict):
            if res.get("error"):
                return False
            return bool(res.get("rating") if key == "financialHealth" else res.get("headline"))
        return True  # raw text from llm_call — a real response, even if it parses to an empty list

    def store_ai_result(target, key, res):
        if key in ("aiAccountRisks", "aiProjectRisks"):
            target[key] = parse_risk_list(res)
        elif key == "growthNextAction":
            target[key] = parse_string_list(res)
        elif key == "aiActionPlan":
            target[key] = parse_action_plan(res)
        else:
            target[key] = res if res is not None else {"error": "no response"}

    ai_label = {"ai": "AI insight", "aiAccountRisks": "PORTFOLIO_REDACTED", "aiProjectRisks": "PORTFOLIO_REDACTED",
                "growthNextAction": "AI growth actions", "aiActionPlan": "AI action plan", "financialHealth": "AI financial read", "portfolioAI": "AI portfolio insight"}

    def dispatch(job_specs, max_workers, wave_label, count_progress=False):
        jobs = {}
        with cf.ThreadPoolExecutor(max_workers=max_workers) as ex:
            for spec in job_specs:
                target, key, fn, args = spec
                jobs[ex.submit(fn, *args)] = spec
            done, retry = 0, []
            for fut in cf.as_completed(jobs):
                target, key, fn, args = jobs[fut]
                done += 1
                try:
                    res = fut.result()
                except Exception:
                    res = None
                ok = ai_result_ok(key, res)
                store_ai_result(target, key, res)
                if not ok:
                    retry.append((target, key, fn, args))
                if count_progress:  # only wave1 advances the bar; retries re-run the same jobs
                    prog(ai_label.get(key, key) + " — " + str(target.get("name") or target.get("slug") or "portfolio") + " (" + LLM_MODEL + ")")
                print(f"  [{wave_label} {done}/{len(jobs)}] {target.get('slug', 'portfolio'):12} {key} {'ok' if ok else 'retry'}", flush=True)
        return retry

    if SKIP_AI:
        prog_total(19 + 1)
        prog("Reusing existing AI insights (LLM gateway skipped)")
        print("SKIP_AI set — reusing existing AI-generated fields from the previous output, skipping LLM calls", flush=True)
        try:
            prev = json.load(open(OUT, encoding="utf-8"))
            prev_by_slug = {a["slug"]: a for a in prev.get("accounts", [])}
        except Exception:
            prev, prev_by_slug = {}, {}
        for a in out["accounts"]:
            p = prev_by_slug.get(a["slug"], {})
            a["ai"] = p.get("ai") or {"error": "skipped (SKIP_AI)"}
            a["aiAccountRisks"] = p.get("aiAccountRisks") or []
            a["aiProjectRisks"] = p.get("aiProjectRisks") or []
            a["growthNextAction"] = p.get("growthNextAction") or []
            a["aiActionPlan"] = p.get("aiActionPlan") or []
            a["aiGeneratedAt"] = p.get("aiGeneratedAt") or prev.get("generatedAt")  # reused -> keep its date
        out["portfolioAI"] = prev.get("portfolioAI") or {"error": "skipped (SKIP_AI)"}
        out["portfolioAIAt"] = prev.get("portfolioAIAt") or prev.get("generatedAt")
        out["crossAccountPatterns"] = prev.get("crossAccountPatterns") or {"error": "skipped (SKIP_AI)"}
        out["crossAccountPatternsAt"] = prev.get("crossAccountPatternsAt") or prev.get("generatedAt")
    else:
        job_specs = []
        reused, reused_slugs = 0, set()
        for a in out["accounts"]:
            p = prev_by_slug.get(a["slug"], {})
            # Reproducibility: if this account's inputs are byte-identical to last run, reuse the
            # existing narrative verbatim instead of re-rolling it — same data, same words, no LLM call.
            if p.get("_aiInputHash") and p["_aiInputHash"] == a["_aiInputHash"] and p.get("ai") and not p.get("ai", {}).get("error"):
                for k in ("ai", "aiAccountRisks", "aiProjectRisks", "growthNextAction", "aiActionPlan"):
                    a[k] = p.get(k)
                a.setdefault("growthNextAction", [])
                a.setdefault("aiActionPlan", [])
                a["aiGeneratedAt"] = p.get("aiGeneratedAt") or prev.get("generatedAt")  # reused -> keep its date
                reused += 1
                reused_slugs.add(a["slug"])
                continue
            job_specs.append((a, "ai", llm_insight, (account_prompt(a),)))
            job_specs.append((a, "aiAccountRisks", llm_call, (ai_account_risk_prompt(a),)))
            job_specs.append((a, "aiProjectRisks", llm_call, (ai_project_risk_prompt(a),)))
            job_specs.append((a, "aiActionPlan", llm_call, (ai_action_plan_prompt(a),)))
            gp = growth_next_action_prompt(a)
            if gp:
                job_specs.append((a, "growthNextAction", llm_call, (gp,)))
            else:
                a["growthNextAction"] = []
            # financialHealth is deterministic (computed in the account loop) — no LLM/vision job.
        # Portfolio narrative depends on all accounts; reuse only if none of them changed.
        port_hash = hashlib.sha256("".join(a["_aiInputHash"] for a in out["accounts"]).encode()).hexdigest()
        out["_portfolioHash"] = port_hash
        portfolio_reused = reused == len(out["accounts"]) and prev.get("_portfolioHash") == port_hash and prev.get("portfolioAI") and not prev.get("portfolioAI", {}).get("error")
        if portfolio_reused:
            out["portfolioAI"] = prev["portfolioAI"]
            out["portfolioAIAt"] = prev.get("portfolioAIAt") or prev.get("generatedAt")
        else:
            job_specs.append((out, "portfolioAI", llm_insight, (portfolio_prompt(out["accounts"]),)))
        # Cross-account patterns also depend on all accounts — same reuse gate as the portfolio narrative.
        patterns_reused = portfolio_reused and prev.get("crossAccountPatterns") and not prev.get("crossAccountPatterns", {}).get("error")
        if patterns_reused:
            out["crossAccountPatterns"] = prev["crossAccountPatterns"]
            out["crossAccountPatternsAt"] = prev.get("crossAccountPatternsAt") or prev.get("generatedAt")
        else:
            job_specs.append((out, "crossAccountPatterns", cross_account_patterns, (out["accounts"],)))
        if reused:
            print(f"reusing {reused}/{len(out['accounts'])} account narratives (inputs unchanged)", flush=True)

        # Now the AI job count is known: fix the exact total (data pull 6 + Azure 2·accounts + AI + capacity 4 + cases 1 + write 1).
        prog_total(6 + 2 * len(ACCOUNTS) + len(job_specs) + 4 + 1 + 1)
        print(f"generating AI insights + risks + next actions + financial health via LLM ({LLM_MODEL}) — serial ...", flush=True)
        retry1 = dispatch(job_specs, max_workers=1, wave_label="wave1", count_progress=True)
        if retry1:
            print(f"  retrying {len(retry1)} failed/timed-out call(s) ...", flush=True)
            dispatch(retry1, max_workers=1, wave_label="wave2")

        # Date each narrative by WHEN it was produced: reused ones kept their date above; ones
        # regenerated this run are stamped now, and carry the model that produced them.
        for a in out["accounts"]:
            if a["slug"] not in reused_slugs:
                a["aiGeneratedAt"] = out["generatedAt"]
                a["aiModel"] = LLM_MODEL
        if not portfolio_reused:
            out["portfolioAIAt"] = out["generatedAt"]
        if not patterns_reused:
            out["crossAccountPatternsAt"] = out["generatedAt"]

    for a in out["accounts"]:
        print(f"  {a['slug']:7} insight={'ok' if not a['ai'].get('error') else 'ERR'} "
              f"aiAcctRisks={len(a['aiAccountRisks'])} aiProjRisks={len(a['aiProjectRisks'])} "
              f"growthNextAction={len(a['growthNextAction'])} "
              f"finHealth={a['financialHealth'].get('rating') or a['financialHealth'].get('error')}")
    print(f"  portfolio ai={'ok' if not out['portfolioAI'].get('error') else out['portfolioAI']['error']}")

    # Grounding pass: verify every DATA number each narrative states actually appears in that
    # account's own inputs. Runs for every account each build (cheap, no LLM) so even reused
    # narratives carry a current grounding stamp. Flag only — the text is preserved and labelled,
    # never silently dropped; an ungrounded narrative also raises an alert below.
    ground_flagged = ground_all(out)
    out["grounding"] = {"checkedAt": _now_iso(), "ok": not ground_flagged, "flagged": ground_flagged}
    if ground_flagged:
        print(f"  GROUNDING: {len(ground_flagged)} narrative(s) state figures not in the source data: {ground_flagged}", flush=True)
    else:
        print("  grounding: all AI narratives verified against source data", flush=True)

    prev_cap = prev.get("capacity") or {}
    prog("Capacity — SDG (Azure)")
    cap_sdg = source("capacity:sdg", lambda: capacity(SDG_QID, "Azure DevOps · Resources_Data - Current Month - SDG (dashboard: SDG (Imp)-Resource Allocation)"), fallback=prev_cap.get("sdg"))
    prog("Capacity — SAG (Azure)")
    cap_sag = source("capacity:sag", lambda: capacity(SAG_QID, "Azure DevOps · Resources_Data - Current Month by Assigned To (dashboard: SAG-Resource Allocation Summary)"), fallback=prev_cap.get("sag"))
    prog("Capacity — ESG (Azure)")
    cap_esg = source("capacity:esg", lambda: capacity(ESG_QID, "Azure DevOps · Resources_Data - Current Month - ESG by Assigned To (dashboard: ESG-Resource Allocation Summary)"), fallback=prev_cap.get("esg"))
    # Overall is DERIVED from SDG+SAG+ESG (not a separate query), so the gauge always reconciles with
    # the three groups it summarises. Each group keeps its own source()/fallback provenance above.
    prog("Capacity — overall (derived from SDG + SAG + ESG)")
    cap_overall = aggregate_capacity([cap_sdg, cap_sag, cap_esg], "Derived — SDG + SAG + ESG combined (Azure DevOps · Resources_Data - Current Month)")
    out["capacity"] = {"overall": cap_overall, "sdg": cap_sdg, "sag": cap_sag, "esg": cap_esg}
    for src in ("overall", "sdg", "sag", "esg"):
        cc = out["capacity"][src] or {}
        print(f"  capacity[{src}] overall={cc.get('overallUtilPct')}% overAlloc={cc.get('overAllocated')} cats={len(cc.get('categories', []))}")
    prog("Production support cases — Redash query 666")
    out["productionCases"] = source("productionCases", production_cases, fallback=prev.get("productionCases"))

    # Provenance (which source produced each part, and whether it was fresh/stale), a change log
    # vs the previous run, and the fi header for future fallback — all additive, no value changes.
    out["provenance"] = _PROV
    out["config"] = THRESHOLDS  # health/risk thresholds, so the frontend scores with the same numbers
    out["_fiHeader"] = fi_header
    out["changeLog"] = change_log(prev, out)
    out["alerts"] = compute_alerts(prev, out)  # exceptions worth surfacing (tier worsening, bug spikes)
    # An AI narrative stating a figure the data doesn't support is itself an exception worth pushing.
    for slug in out.get("grounding", {}).get("flagged", []):
        nm = next((a.get("name") for a in out["accounts"] if a.get("slug") == slug), slug)
        out["alerts"].append({"slug": slug, "name": nm or slug, "severity": "high",
                              "message": "AI narrative states figures not found in the source data"})

    prog("Writing accounts.json")
    write_output(out, prev)  # validates, snapshots, writes atomically; keeps old data if invalid
    emit_webhook(out)        # push alerts to the configured webhook (e.g. n8n) if any; no-op if unset
    for a in out["accounts"]:
        d = a.get("delivery") or {}
        rk = a.get("risk") or {}
        print(f"{a['slug']:7} src={_PROV.get('delivery:' + a['slug'], {}).get('status', '?')}  delivery total={d.get('total')} bugs_open={d.get('open_bugs')}  "
              f"fi={'ok' if a.get('financial') else 'MISS'}  RISK tier={rk.get('tier')}")
    print("wrote", OUT, "| provenance:", {k: v.get("status") for k, v in _PROV.items()})
    prog_done("Refresh complete")


if __name__ == "__main__":
    build()
