import { useState } from 'react'

// Chart representation is a display preference, not data — remembered per
// chart (by a stable id like "leads.monthly_trend") in localStorage so it
// persists across reloads without needing any backend/customer scoping.
export function useChartType(chartId, defaultType) {
  const key = `chartType:${chartId}`
  const [type, setType] = useState(() => {
    try {
      return localStorage.getItem(key) || defaultType
    } catch {
      return defaultType
    }
  })

  const change = (next) => {
    setType(next)
    try {
      localStorage.setItem(key, next)
    } catch {
      // localStorage unavailable (private mode, etc.) — preference just
      // won't persist across reloads, chart still works this session.
    }
  }

  return [type, change]
}
