"""OpenAI integration — generates narrative insight text on top of
already-computed metrics. Never computes numbers itself."""

import json
import os

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")


class InsightUnavailable(RuntimeError):
    """The AI layer could not be reached. Raised instead of letting a raw SDK
    exception escape as a bare 500, so the UI can say WHY nothing generated.

    Every metric on every dashboard is computed in SQL, so this never affects
    the numbers — only the narrative text layered on top."""


def _client() -> OpenAI:
    """Build the OpenAI client, turning construction failures into a typed error.

    Constructing the client is not as safe as it looks: openai 1.51 passes
    `proxies=` to httpx, which httpx removed in 0.28, so an unpinned httpx makes
    OpenAI() itself raise TypeError before any request is sent. That produced a
    bare 500 on every AI endpoint while cached insights kept working, which made
    it look account-specific rather than total. requirements.txt now pins httpx;
    this keeps the failure readable if the SDK pairing ever breaks again."""
    try:
        return OpenAI()
    except Exception as exc:
        raise InsightUnavailable(f"Could not initialise the AI client: {exc}") from exc

SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You receive pre-computed metrics and return a concise, plain-language insight narrative (3-5 sentences).
Focus on: what's improving, what's concerning, what action is implied.
Never invent numbers not given to you. Never say 'I' or 'we'.
Output is clearly labelled as AI-generated in the UI."""

CHART_INSIGHT_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You will receive a JSON object called "charts" — one entry per chart already rendered on a dashboard, each
holding a small pre-aggregated summary (already computed by SQL, never raw records; long lists are capped and
marked with an "_omitted_rows" count for the rest).

For EVERY key in "charts", write exactly one crisp, plain-language insight (1-2 sentences) specific to the
numbers given for that chart only. Call out what's notable: a leader or laggard, a swing, a risk, or something
worth raising in a review meeting. Never invent a number that isn't present in the data. Never say 'I' or 'we'.

Respond with ONLY a single minified JSON object mapping each chart key to its insight string exactly as given —
no markdown, no code fences, no extra keys, no commentary before or after."""


def generate_insight(customer: str, module: str, metrics: dict) -> str:
    """Takes a pre-computed metrics dict, returns a 3-5 sentence narrative.
    Never passes raw row data — only aggregated numbers. PII must already be
    stripped by the caller before this function is invoked."""
    client = _client()

    prompt = f"""Customer: {customer}
Module: {module}
Metrics: {metrics}

Write a 3-5 sentence adoption insight for the review meeting. Be specific about the numbers."""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        # See generate_chart_insights for why this includes a reasoning-token
        # reserve on top of the actual output budget.
        max_completion_tokens=800 + 300,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content


PERIOD_COMPARISON_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You receive pre-computed lead funnel metrics for two comparison periods — "period_a" (the baseline/earlier
window) and "period_b" (the window being evaluated) — already grouped into growth, engagement/timing, and
funnel-conversion figures. Write a concise, plain-language insight (3-5 sentences) on what changed between the
two periods and why it matters for the business. Focus on the most meaningful swings, not every number. Never
invent a number not given to you. Never say 'I' or 'we'. Output is clearly labelled as AI-generated in the UI."""


def generate_period_comparison_insight(customer: str, label_a: str, label_b: str, comparison: dict) -> str:
    """Takes the {"a": {...}, "b": {...}} payload from
    metrics.leads_comparison.get_leads_comparison and narrates what changed.
    label_a/label_b are human-readable period descriptions (e.g. "Jan-Jun
    2025") for framing only — never a source of numbers."""
    client = _client()

    prompt = f"""Customer: {customer}
Period A ({label_a}): {json.dumps(comparison.get("a"), default=str)}
Period B ({label_b}): {json.dumps(comparison.get("b"), default=str)}

Write a 3-5 sentence insight on what changed from Period A to Period B and what it implies."""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        max_completion_tokens=800 + 300,
        messages=[
            {"role": "system", "content": PERIOD_COMPARISON_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content


CORRELATION_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You receive two pre-computed analyses of a leads dataset: "correlation" — Pearson correlation coefficients
between funnel stage durations (time-to-touch, time-to-qualify, time-to-close) plus the actual outcome rate at
each speed tier — and "drivers" — a ranking of which factor (product category, member type, lead source,
branch, speed-to-touch) most differentiates conversion or qualification outcomes, each with its best and
worst-performing group. Write a concise, plain-language insight (3-5 sentences) connecting the two: what's
driving outcomes, and where speed specifically matters. Never invent a number not given to you. Never say 'I'
or 'we'. Output is clearly labelled as AI-generated in the UI."""


def generate_correlation_insight(customer: str, correlation: dict, drivers: list) -> str:
    """Takes the outputs of metrics.leads_correlation.get_leads_time_correlation
    and get_leads_drivers and narrates the connection between them."""
    client = _client()

    prompt = f"""Customer: {customer}
Correlation: {json.dumps(correlation, default=str)}
Drivers: {json.dumps(drivers, default=str)}

Write a 3-5 sentence insight connecting the correlation and driver findings."""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        max_completion_tokens=800 + 300,
        messages=[
            {"role": "system", "content": CORRELATION_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content


OKR_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You receive "levers" — the customer's strategic business levers, each with a plain-language definition — and
"kpis" — a catalog of adoption KPIs already computed from the CRM data, each with a current value and its
year-over-year change. You also receive "objectives" — the customer's higher-level business objectives, for
context only.

For EACH lever, do three things using ONLY the KPI catalog provided:
  1. "kpis": pick the 1-3 KPI labels (verbatim from the catalog) whose movement best evidences progress on that
     lever. If none are relevant, use an empty list.
  2. "assessment": judge the lever as exactly one of "on_track", "at_risk", "behind", or "unknown" (use
     "unknown" only when no KPI is relevant), based only on the chosen KPIs' values and changes.
  3. "rationale": one crisp sentence citing the specific numbers behind the assessment.

Never invent a number or a KPI label not present in "kpis". Never say 'I' or 'we'.

Respond with ONLY a single minified JSON object mapping each lever name (verbatim) to
{"kpis": [...], "assessment": "...", "rationale": "..."} — no markdown, no code fences, no commentary."""


def generate_okr_assessment(customer: str, levers: list, kpis: list, objectives: list) -> dict:
    """Map each strategic lever to the adoption KPIs that evidence it and judge
    progress. The AI only selects relationships and writes the rationale — every
    displayed number still comes from the pre-computed KPI catalog. Returns
    {lever_name: {"kpis": [labels], "assessment": str, "rationale": str}}."""
    client = _client()

    prompt = f"""Customer: {customer}
objectives = {json.dumps(objectives, default=str)}
levers = {json.dumps(levers, default=str)}
kpis = {json.dumps(kpis, default=str)}

Return the JSON object described in the system prompt, one entry per lever name: {[l.get("lever") for l in levers]}"""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        max_completion_tokens=800 + min(1600, 160 * max(len(levers), 1) + 120),
        messages=[
            {"role": "system", "content": OKR_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        data = {}
    return data if isinstance(data, dict) else {}


ACCOUNT_NARRATIVE_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM,
writing the opening account narrative for a Quarterly Business Review. You receive a "context" object with the
already-computed signals available for this account: headline adoption KPIs (with YoY change), FI-Navigator
growth/profitability highlights, the customer's strategic business levers, roadmap horizon counts, and the
number of open discussion points/risks.

Write a brief executive narrative of 3-4 sentences that ties these together into a single coherent story: how
adoption is trending, what the institution's growth picture implies, and where attention is needed. Ground every
statement in the numbers provided — never invent a figure that isn't in the context. Do not restate every KPI;
synthesize. Never say 'I' or 'we'. Output is clearly labelled as AI-generated in the UI.

Respond with ONLY the narrative text — no headings, no markdown, no bullet points."""


def generate_account_narrative(customer: str, context: dict) -> str:
    """Synthesize the QBR opening narrative from already-computed signals.
    Numbers come only from `context`; the model writes the prose."""
    client = _client()
    prompt = f"""Customer: {customer}
context = {json.dumps(context, default=str)}

Write the 3-4 sentence executive account narrative described in the system prompt."""
    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        max_completion_tokens=800 + 400,
        messages=[
            {"role": "system", "content": ACCOUNT_NARRATIVE_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return (response.choices[0].message.content or "").strip()


def generate_chart_insights(customer: str, module: str, chart_metrics: dict) -> dict:
    """One OpenAI call per module view (never one call per chart, and never
    one per customer/month combination beyond what's actually requested) —
    sends only the already-computed, already-capped aggregates in
    chart_metrics. Returns {chart_key: insight_text | None}, one entry per
    key in chart_metrics, so the UI can degrade gracefully per chart if the
    model omits or mangles one."""
    client = _client()
    num_charts = max(len(chart_metrics), 1)

    prompt = f"""Customer: {customer}
Module: {module}
charts = {json.dumps(chart_metrics, default=str)}

Return the JSON object described in the system prompt, with one entry per key in charts: {list(chart_metrics.keys())}"""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        # Bounded by chart count, not a flat ceiling — keeps a 2-chart module
        # cheap while still giving a 9-chart module room for every entry.
        # OPENAI_MODEL is a reasoning model: its internal reasoning tokens are
        # deducted from this same budget before any visible output is
        # written, so a tight cap can burn 100% of it on reasoning and return
        # empty content (finish_reason="length") on data-heavy modules/
        # customers. The +800 reasoning reserve is on top of, not instead of,
        # the per-chart output budget.
        max_completion_tokens=800 + min(1400, 90 * num_charts + 80),
        messages=[
            {"role": "system", "content": CHART_INSIGHT_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    return _parse_chart_insights(text, chart_metrics.keys())


def _parse_chart_insights(text: str, expected_keys) -> dict:
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    return {key: data.get(key) for key in expected_keys}


SECTION_INSIGHT_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM.
You will receive a JSON object called "sections" — one entry per labeled dashboard section, each holding the
already-computed chart aggregates (never raw records; long lists are capped and marked with an "_omitted_rows"
count for the rest) for every chart grouped under that section. One section, "Book of Business (LCI)", reuses
some of the same underlying rows as "Source & Category Performance" — for that section specifically, narrate the
LCI/revenue-value angle (which categories or sources produce more value), not volume or conversion rate.

For EVERY key in "sections", write exactly one crisp, plain-language insight (2-4 sentences) that synthesizes the
charts in that section together into one coherent takeaway — call out the overall pattern, a leader or laggard, a
swing, or a risk worth raising in a review meeting. Never invent a number that isn't present in the data. Never
say 'I' or 'we'.

Respond with ONLY a single minified JSON object mapping each section key to its insight string exactly as given —
no markdown, no code fences, no extra keys, no commentary before or after."""


def generate_section_insights(customer: str, module: str, section_metrics: dict) -> dict:
    """One OpenAI call covering every section of a module view — never one
    call per section. Returns {section_name: insight_text | None}."""
    client = _client()
    num_sections = max(len(section_metrics), 1)

    prompt = f"""Customer: {customer}
Module: {module}
sections = {json.dumps(section_metrics, default=str)}

Return the JSON object described in the system prompt, with one entry per key in sections: {list(section_metrics.keys())}"""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        # See generate_chart_insights for why this includes a reasoning-token
        # reserve on top of the actual output budget.
        max_completion_tokens=800 + min(1400, 150 * num_sections + 100),
        messages=[
            {"role": "system", "content": SECTION_INSIGHT_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    return _parse_chart_insights(text, section_metrics.keys())


SENIOR_SUMMARY_SYSTEM_PROMPT = """You are an adoption analytics expert briefing senior/executive leadership at a
credit union on BUSINESSNEXT CRM adoption. You receive pre-computed, already-aggregated KPI numbers for the
Leads, Cases, Complaints, and Users modules — nothing else. Turn them into a short executive bullet briefing.

Write exactly four lists of bullet points: "leads", "cases", "complaints", and "users". Each list should have 3-5
bullets. Each bullet is one crisp sentence (no sub-clauses stacked with semicolons), written for a senior
executive skimming a summary — lead with the number, then the takeaway. Cover a mix of: strongest result,
biggest risk/concern, and one action-oriented recommendation, for each module. Never invent a number not present
in the data. Never say 'I' or 'we'.

Respond with ONLY a single minified JSON object: {"leads": ["...", ...], "cases": ["...", ...], "complaints":
["...", ...], "users": ["...", ...]} — no markdown, no code fences, no extra keys, no commentary before or after."""


def generate_senior_summary_bullets(
    customer: str, leads_kpis: dict, cases_kpis: dict, complaints_kpis: dict, users_kpis: dict
) -> dict:
    """One OpenAI call, sending only the four small already-computed KPI
    dicts (no chart breakdowns, no raw rows). Returns {"leads": [...],
    "cases": [...], "complaints": [...], "users": [...]} bullet lists for
    the executive Senior Summary view."""
    client = _client()

    prompt = f"""Customer: {customer}
Leads KPIs: {json.dumps(leads_kpis, default=str)}
Cases KPIs: {json.dumps(cases_kpis, default=str)}
Complaints KPIs: {json.dumps(complaints_kpis, default=str)}
Users KPIs: {json.dumps(users_kpis, default=str)}

Return the JSON object described in the system prompt."""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        # See generate_chart_insights for why this includes a reasoning-token
        # reserve on top of the actual output budget.
        max_completion_tokens=800 + 900,
        messages=[
            {"role": "system", "content": SENIOR_SUMMARY_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    return {
        key: data.get(key) if isinstance(data.get(key), list) else []
        for key in ("leads", "cases", "complaints", "users")
    }


CRM_LEVER_SYSTEM_PROMPT = """You are a CRM adoption strategist for credit unions using BUSINESSNEXT CRM.

You receive "signals" — real FI Navigator growth/risk metrics for one institution, each with its current
value — and "modules", the BUSINESSNEXT CRM modules that institution has actually implemented (with whether
each is live). For each signal, write ONE crisp lever: the specific CRM play that moves that metric.

Rules:
- Name only modules that appear in "modules". Never suggest a capability they have not implemented. If a
  signal has no plausible lever among the implemented modules, say what to do with what they DO have.
- Prefer modules marked implemented=true; if a relevant one is implemented=false, you may frame it as
  completing that rollout.
- Reference the signal's actual value when it sharpens the point. Never invent a number you were not given.
- Maximum 14 words per lever. No trailing period. Telegraphic and concrete, e.g.
  "Lead scoring + onboarding journeys to convert the 4.0% member growth".
- Never say 'I' or 'we'.

Return a JSON object mapping each signal name EXACTLY as given to its lever string. No other keys."""


def generate_crm_levers(customer: str, signals: list[dict], modules: list[dict]) -> dict:
    """Per-signal CRM lever text, grounded in the modules the customer actually runs.

    Replaces a hardcoded advisory template that read identically for every customer.
    Returns {signal_name: lever_text}; callers keep their static fallback for any
    signal missing from the response, so a partial answer degrades instead of blanking."""
    client = _client()

    prompt = f"""Customer: {customer}
Signals: {json.dumps(signals, default=str)}
Implemented CRM modules: {json.dumps(modules, default=str)}

Return the JSON object described in the system prompt."""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        max_completion_tokens=500 + 900,
        messages=[
            {"role": "system", "content": CRM_LEVER_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {k: v.strip() for k, v in data.items() if isinstance(v, str) and v.strip()}


COMPARISON_SYSTEM_PROMPT = """You are an adoption analytics expert for credit unions using BUSINESSNEXT CRM,
briefing a reviewer who is comparing 2-4 named customers head-to-head. You receive "kpis" — pre-computed,
already-aggregated KPI numbers grouped by module (leads/cases/complaints/users), one value per customer per KPI
— and "notes" — short free-text background per customer (region, size, financials, systems) that may be empty.

Use the notes ONLY for framing/context (e.g. "a larger credit union" or "primarily rural branches") — never as a
source of numbers, and never invent a number not present in "kpis". Write comparison bullets that call out who is
ahead, who is behind, and by how much, on each KPI that's actually present in the data.

Write a JSON object with an "overall" list (2-4 bullets, the highest-level takeaways across all modules) plus one
list per module key that's actually present in "kpis" (3-5 bullets each, comparing the given customers on that
module's KPIs only). Each bullet is one crisp sentence, lead with the number/customer, then the takeaway. Never
say 'I' or 'we'.

Respond with ONLY a single minified JSON object: {"overall": ["...", ...], "leads": ["...", ...], ...} — no
markdown, no code fences, no extra keys, no commentary before or after. Omit a module key entirely if it wasn't
in "kpis"."""


def generate_comparison_insights(customers: list[str], kpi_data: dict, notes_context: dict) -> dict:
    """One OpenAI call comparing 2-4 named customers on already-computed KPI
    numbers (kpi_data = {module: {customer: {kpi_id: value}}}), with each
    customer's saved background note (notes_context = {customer: text})
    passed in for framing only. Returns {"overall": [...], module: [...], ...}
    covering only the modules actually present in kpi_data."""
    client = _client()

    prompt = f"""Customers: {customers}
kpis = {json.dumps(kpi_data, default=str)}
notes = {json.dumps(notes_context, default=str)}

Return the JSON object described in the system prompt, covering "overall" plus these module keys: {list(kpi_data.keys())}"""

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        # See generate_chart_insights for why this includes a reasoning-token
        # reserve on top of the actual output budget. Scales with module count
        # like generate_chart_insights, plus a flat share for the "overall" list.
        max_completion_tokens=800 + min(1400, 150 * max(len(kpi_data), 1) + 200),
        messages=[
            {"role": "system", "content": COMPARISON_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    text = (response.choices[0].message.content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    expected_keys = ["overall", *kpi_data.keys()]
    return {key: data.get(key) if isinstance(data.get(key), list) else [] for key in expected_keys}
