"""Cross-dashboard summary + AI chat for the OneView landing page.

Aggregates a compact summary from BOTH dashboards, server-side:
  - OneView (Customer Success): site/data/accounts.json (portfolio health).
  - US Project Health (COE): fetched from the COE app's /api/refresh JSON.
And answers questions grounded strictly in that combined data via the LLM gateway
(Bifrost / gemma4-26b, the same gateway build_data.py uses for AI insights).

Access-scoped: the caller passes can_ov / can_coe (from the signed-in user's grants);
a user only ever sees / is answered from the dashboards they're allowed to open.
"""
import json
import os
import urllib.request

_DIR = os.path.dirname(__file__)
_ROOT = os.path.dirname(_DIR)
_ACCOUNTS = os.path.join(_ROOT, "site", "data", "accounts.json")

# COE app base URL for the server-to-server data fetch. Localhost: :8000. In prod the COE
# container is on the same Docker network — set COE_INTERNAL_URL (e.g. https://example.invalid).
COE_URL = os.environ.get("COE_INTERNAL_URL", "http://127.0.0.1:8000").rstrip("/")

# LLM gateway (shared with build_data.py) — Anthropic-style /v1/messages via Bifrost.
LLM_URL = os.environ.get("LLM_URL", "https://example.invalid").rstrip("/")
LLM_MODEL = os.environ.get("LLM_MODEL", "gemma4-26b")


def _llm_key():
    k = os.environ.get("LLM_API_KEY")
    if k:
        return k
    try:
        with open(os.path.join(_DIR, "llm_key.json"), encoding="utf-8") as f:
            return json.load(f).get("LLM_API_KEY", "")
    except Exception:
        return ""


# ---------------- OneView (accounts.json) ----------------

def _tier_label(combined):
    return {2: "At Risk", 1: "Watch", 0: "Healthy"}.get(combined, "Unknown")


def oneview_summary():
    try:
        with open(_ACCOUNTS, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as exc:
        return {"available": False, "error": f"OneView data unavailable: {exc}"}

    accts = d.get("accounts", [])
    counts = {"At Risk": 0, "Watch": 0, "Healthy": 0, "Unknown": 0}
    at_risk_revenue = open_risks = open_bugs = action_items = 0
    rows = []
    for a in accts:
        health = a.get("health") or {}
        risk = a.get("risk") or {}
        deliv = a.get("delivery") or {}
        combined = risk.get("combined")
        label = _tier_label(combined)
        counts[label] = counts.get(label, 0) + 1
        arr = health.get("arr") or 0
        oar = risk.get("openAccountRisks") or 0
        opr = risk.get("openProjectRisks") or 0
        bugs = deliv.get("open_bugs") or 0
        plan = len(a.get("actionPlan") or [])
        if label == "At Risk":
            at_risk_revenue += arr
        open_risks += oar + opr
        open_bugs += bugs
        action_items += plan
        rows.append({
            "name": a.get("name"), "tier": label, "arr": arr,
            "openRisks": oar + opr, "openBugs": bugs, "actionItems": plan,
            "status": health.get("customerStatus"), "csm": health.get("csm"),
            "completion": deliv.get("completion_pct"),
        })
    rows.sort(key=lambda r: ({"At Risk": 0, "Watch": 1, "Healthy": 2}.get(r["tier"], 3), -(r["arr"] or 0)))
    return {
        "available": True,
        "generatedAt": d.get("generatedAt"),
        "totalAccounts": len(accts),
        "atRisk": counts["At Risk"], "watch": counts["Watch"], "healthy": counts["Healthy"],
        "atRiskRevenue": at_risk_revenue,
        "openRisks": open_risks, "openBugs": open_bugs, "actionItems": action_items,
        "accounts": rows,
    }


# ---------------- US Project Health (COE) ----------------

def coe_summary():
    try:
        with urllib.request.urlopen(COE_URL + "/api/refresh?force=false", timeout=120) as r:
            data = json.loads(r.read().decode())
    except Exception as exc:
        return {"available": False, "error": f"US Project Health data unavailable: {exc}"}

    projects = data.get("projects") or []
    kpis = data.get("kpis") or {}
    pt = data.get("production_tickets") or {}
    rows = []
    for p in projects:
        td = p.get("task_delay") or {}
        risks = p.get("risks") or {}
        rows.append({
            "name": p.get("name") or p.get("short"),
            "pm": p.get("pm"),
            "rag": (p.get("calc_rag") or p.get("pm_rag") or "GREEN"),
            "phase": p.get("phase"),
            "overdueTasks": (td.get("overdue") or {}).get("count", 0),
            "staleTasks": (td.get("stale") or {}).get("count", 0),
            "openRisks": risks.get("count", 0) if risks.get("status") == "ok" else None,
        })
    order = {"RED": 0, "AMBER": 1, "GREEN": 2}
    rows.sort(key=lambda r: order.get(str(r["rag"]).upper(), 3))
    return {
        "available": True,
        "lastRefreshed": data.get("last_refreshed"),
        "totalProjects": len(projects),
        "onTrack": kpis.get("on_track", 0),
        "atRisk": kpis.get("at_risk", 0),
        "critical": kpis.get("critical", 0),
        "criticalBugs": kpis.get("total_critical_bugs", 0),
        "productionTickets": (pt.get("totals") or {}).get("total", 0),
        "ticketEscalations": pt.get("escalation_count", 0),
        "projects": rows,
    }


def combined_summary(can_ov=True, can_coe=True):
    return {
        "oneview": oneview_summary() if can_ov else {"available": False, "error": "No OneView access."},
        "coe": coe_summary() if can_coe else {"available": False, "error": "No US Project Health access."},
    }


# ---------------- AI chat (grounded in both) ----------------

def _ov_context(s):
    if not s.get("available"):
        return "OneView data is unavailable."
    lines = [
        f"OneView — Customer Success portfolio ({s['totalAccounts']} accounts, as of {s.get('generatedAt')}):",
        f"  Health: {s['atRisk']} At Risk, {s['watch']} Watch, {s['healthy']} Healthy.",
        f"  At-risk revenue (ARR): ${s['atRiskRevenue']:,}. Open risks: {s['openRisks']}. "
        f"Open bugs: {s['openBugs']}. Action-plan items: {s['actionItems']}.",
        "  Accounts:",
    ]
    for a in s["accounts"]:
        lines.append(
            f"    - {a['name']}: {a['tier']}, ARR ${ (a['arr'] or 0):,}, "
            f"{a['openRisks']} open risks, {a['openBugs']} open bugs, "
            f"{a['actionItems']} action items, status {a.get('status') or 'N/A'}, CSM {a.get('csm') or 'N/A'}.")
    return "\n".join(lines)


def _coe_context(s):
    if not s.get("available"):
        return "US Project Health data is unavailable (the COE service may still be warming up)."
    lines = [
        f"US Project Health — delivery ({s['totalProjects']} projects, as of {s.get('lastRefreshed')}):",
        f"  {s['onTrack']} On Track, {s['atRisk']} At Risk, {s['critical']} Critical. "
        f"Critical bugs: {s['criticalBugs']}. Production tickets: {s['productionTickets']} "
        f"({s['ticketEscalations']} escalated 30+ days).",
        "  Projects:",
    ]
    for p in s["projects"]:
        r = f"{p['openRisks']} open risks" if p.get("openRisks") is not None else "risks N/A"
        lines.append(
            f"    - {p['name']} (PM {p.get('pm') or 'N/A'}): RAG {p['rag']}, phase {p.get('phase') or 'N/A'}, "
            f"{p['overdueTasks']} overdue tasks, {p['staleTasks']} stale tasks, {r}.")
    return "\n".join(lines)


def chat(question, can_ov=True, can_coe=True):
    question = (question or "").strip()
    if not question:
        return {"error": "Ask a question."}
    key = _llm_key()
    if not key:
        return {"error": "The assistant is not configured (LLM key missing on the server)."}

    parts = []
    if can_ov:
        parts.append(_ov_context(oneview_summary()))
    if can_coe:
        parts.append(_coe_context(coe_summary()))
    if not parts:
        return {"error": "You don't have access to any dashboard data."}
    context = "\n\n".join(parts)

    prompt = (
        "You are the OneView assistant. Answer the user's question using ONLY the dashboard data "
        "below. Be concise and specific — cite account/project names and exact numbers. If the "
        "answer is not in the data, say you don't have that information. Never invent figures.\n\n"
        "=== DASHBOARD DATA ===\n" + context +
        "\n\n=== QUESTION ===\n" + question + "\n\n=== ANSWER ===\n"
    )
    body = json.dumps({
        "model": LLM_MODEL, "max_tokens": 900, "temperature": 0.2,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", key)
    req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            d = json.loads(r.read().decode())
        text = "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception as exc:
        return {"error": f"The assistant couldn't respond: {exc}"}
    return {"answer": text.strip() or "(no answer)"}


# ---------------- Account 360 — on-demand AI summary ----------------
def _account_360_context(a):
    """Compact, comprehensive text dump of ONE account's 360 data (accounts.json) for the LLM."""
    h = a.get("health", {}) or {}
    d = a.get("delivery") or {}
    L = []
    def add(s):
        if s:
            L.append(s)
    add("ACCOUNT: "PORTFOLIO_REDACTED"name")))
    add("Segment: %s · State: %s · Core system: %s · Lifecycle status: %s"
        % (h.get("segment"), h.get("state"), h.get("coreSystem"), h.get("customerStatus")))
    add("ARR(USD): %s · Cloud cost: %s · Licensed users: %s · Go-live: %s · Renewal: %s · MSA: %s"
        % (h.get("arr"), h.get("cloudCost"), h.get("users"), h.get("goLive"), h.get("renewalDate"), h.get("msaDate")))
    add("CS status: %s · Renewal risk (CRM): %s · Combined risk tier: %s"
        % (h.get("cs"), h.get("renewalRisk"), h.get("riskTier")))
    add("Owners — CSM: %s · Account owner: %s · Impl manager: %s · Exec sponsor: %s"
        % (h.get("csm"), h.get("accountOwner"), h.get("implementationManager"), h.get("executiveSponsor")))
    if d and not d.get("error"):
        add("Delivery: %s%% complete, %s work items, %s open bugs of %s total"
            % (d.get("completion_pct"), d.get("total"), d.get("open_bugs"), d.get("total_bugs")))
    cph = a.get("coeProjectHealth")
    if cph and cph.get("calcRag"):
        add("US Project Health (COE calc-RAG): %s (weighted %s)%s"
            % (cph.get("calcRag"), cph.get("weightedScore"), " · phase " + str(cph.get("phase")) if cph.get("phase") else ""))
    fh = a.get("financialHealth") or {}
    if fh.get("rating"):
        add("Financial health: %s (%s/100)" % (fh.get("rating"), fh.get("score")))
    g = a.get("growth") or {}
    f5 = g.get("fy2025") or {}
    if f5:
        add("FY2025 financials: assets $%sk, net worth ratio %s%%, members %s, net income $%sk, employees %s"
            % (f5.get("totalAssets"), f5.get("netWorthRatioPct"), f5.get("members"), f5.get("netIncome"), f5.get("employees")))
    mods = [m for m in (a.get("modules") or []) if m.get("modulename")]
    if mods:
        add("Modules & adoption: " + "; ".join("%s=%s" % (m.get("modulename"), m.get("adoptionstatus") or m.get("currentstatus")) for m in mods))
    sla = a.get("caseSla") or {}
    if sla:
        add("Support SLA (within/outside): P1 %s/%s, P2 %s/%s, P3 %s/%s"
            % (sla.get("P1 Within SLA"), sla.get("P1 Outside SLA"), sla.get("P2 Within SLA"), sla.get("P2 Outside SLA"), sla.get("P3 Within SLA"), sla.get("P3 Outside SLA")))
    eng = [e for e in (a.get("engagement") or []) if e.get("cadencetype")]
    if eng:
        add("Engagement cadences logged: " + "; ".join(e.get("cadencetype") for e in eng))
    ar = [r for r in (a.get("accountRisks") or []) if r.get("risktype") or r.get("riskdetail")]
    pr = a.get("projectRisks") or []
    add("Risks: %d logged account risks, %d project risks" % (len(a.get("accountRisks") or []), len(pr)))
    for r in ar[:5]:
        add("  Account risk: %s (%s) — %s" % (r.get("risktype"), r.get("riskseverity"), r.get("riskdetail")))
    bo = [o for o in (a.get("businessObjectives") or []) if o.get("objective")]
    if bo:
        add("Business objectives: " + "; ".join("%s: %s" % (o.get("objective"), o.get("description")) for o in bo))
    bl = [l for l in (a.get("businessLevers") or []) if l.get("businesslever")]
    if bl:
        add("Strategic levers: " + "; ".join("%s (%s)" % (l.get("businesslever"), l.get("direction") or l.get("definition")) for l in bl))
    rel = [p for p in (a.get("relationships") or []) if p.get("name")]
    if rel:
        add("Key stakeholders: " + "; ".join("%s [%s, sentiment %s]" % (p.get("name"), p.get("role") or p.get("stakeholder"), p.get("sentiment")) for p in rel[:8]))
    ap = [p for p in (a.get("actionPlan") or []) if p.get("detail")]
    if ap:
        add("Logged action items: " + "; ".join("%s (%s, due %s)" % (p.get("detail"), p.get("category"), p.get("dueDate")) for p in ap[:6]))
    ai = a.get("ai") or {}
    if ai.get("headline"):
        add("Prior AI headline: " + str(ai.get("headline")))
    return "\n".join(str(x) for x in L)


def account_summary(slug):
    """On-demand executive AI summary of ONE account, grounded in all its 360 data (accounts.json)."""
    key = _llm_key()
    if not key:
        return {"error": "The assistant is not configured (LLM key missing on the server)."}
    try:
        with open(_ACCOUNTS, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as exc:
        return {"error": f"Could not load account data: {exc}"}
    a = next((x for x in (data.get("accounts") or []) if x.get("slug") == slug), None)
    if not a:
        return {"error": "Account not found."}
    prompt = (
        "You are a Customer Success analyst for BusinessNext (CRMNEXT). Write a concise executive SUMMARY of this "
        "ONE account using ONLY the 360 data below. Cover, in this order: overall health & renewal outlook; delivery / "
        "project status; adoption & engagement; support quality; financial trajectory; the key risks; and the most "
        "important next actions. Cite specific numbers and names from the data — do NOT invent any figure or fact. "
        "Format as short markdown: a one-line **bold** takeaway first, then a few sections with '## ' headers and '- ' "
        "bullets. Keep it tight (about 200-300 words).\n\n"
        "=== ACCOUNT 360 DATA ===\n" + _account_360_context(a) + "\n\n=== SUMMARY ===\n"
    )
    body = json.dumps({
        "model": LLM_MODEL, "max_tokens": 1300, "temperature": 0.2,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(LLM_URL + "/v1/messages", data=body, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", key)
    req.add_header("anthropic-version", "2023-06-01")
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            d = json.loads(r.read().decode())
        text = "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    except Exception as exc:
        return {"error": f"The assistant couldn't respond: {exc}"}
    return {"summary": text.strip() or "(no summary)", "account": a.get("name"), "generatedAt": data.get("generatedAt")}
