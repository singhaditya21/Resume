const VARIANTS = new Set(['active', 'pending', 'progress', 'closed', 'draft'])

export default function Badge({ variant = 'draft', children }) {
  const safeVariant = VARIANTS.has(variant) ? variant : 'draft'
  return <span className={`badge badge-${safeVariant}`}>{children}</span>
}
