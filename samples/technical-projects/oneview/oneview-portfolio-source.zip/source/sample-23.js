import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// In production the app is served by the OneView portal under the /adoption/ path
// (nginx reverse-proxies /adoption/ -> the adoption container and strips the prefix).
// So the *build* must emit asset URLs under /adoption/. In dev we still serve at the
// root of the Vite server (base '/') and proxy /api to the local FastAPI on :8001, so
// the standalone `npm run dev` + start.sh workflow keeps working unchanged.
export default defineConfig(({ command }) => ({
  base: command === 'build' ? '/adoption/' : '/',
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8001',
        changeOrigin: true,
      }
    }
  }
}))
