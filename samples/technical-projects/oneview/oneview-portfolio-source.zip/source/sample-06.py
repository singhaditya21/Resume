"""FastAPI app — all routes. All KPI math happens in metrics/*; this file
only wires HTTP to those pure functions (plus sync + AI insight endpoints)."""

import json
from datetime import datetime
from typing import List, Optional

import os

from dotenv import find_dotenv, load_dotenv
from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import admin_config
import comparison as comparison_module
import notes as notes_module
import sync as sync_module
from chart_metrics import MODULE_CHART_METRICS, MODULE_SECTION_GROUPS, get_chart_insights, get_section_insights, get_senior_summary, period_label, resolve_period
from db import get_cached_chart_insights, get_connection, init_db, make_insight_cache_key, queue_summary_email, store_chart_insights
from exports import generate_qbr_ppt
from qbr_report import build_qbr_report
from insights import InsightUnavailable, generate_comparison_insights, generate_correlation_insight, generate_insight, generate_period_comparison_insight
from metrics import cases_metrics, complaints_metrics, leads_comparison, leads_correlation, leads_metrics, users_metrics

load_dotenv()

# load_dotenv() returns False SILENTLY when .env is absent — or when it is a DIRECTORY, which is
# what Docker leaves behind if the compose bind-mount source was never provisioned (seen in prod
# on 2026-08-11: container healthy, app keyless, module empty). Never crash for this — the module
# can still serve DB data — but say it loudly in the container log instead of failing invisibly.
# find_dotenv() mirrors load_dotenv's own parent-walking search, so a legitimately-found .env in a
# parent dir (local dev) never false-alarms; a directory at cwd/.env is invisible to find_dotenv,
# which is exactly the trap case.
_ENV_CWD = os.path.join(os.getcwd(), ".env")
if os.path.isdir(_ENV_CWD):
    print(f"[adoption] WARNING: {_ENV_CWD} is a DIRECTORY (unprovisioned bind mount). "
          "Remove it, provision the real .env, and force-recreate this container.", flush=True)
elif not find_dotenv(usecwd=True):
    print(f"[adoption] WARNING: no .env found from {os.getcwd()} — running without local env overrides.", flush=True)
if not os.environ.get("OPENAI_API_KEY"):
    print("[adoption] WARNING: OPENAI_API_KEY is not set — AI insights, summaries and QBR "
          "narratives will fail until it is provided (.env or environment).", flush=True)

app = FastAPI(title="Adoption Analytics")

# No CORS middleware: inside OneView the built frontend is served by THIS app under the
# same origin (nginx proxies /adoption/ here), and in standalone dev the Vite proxy makes
# /api same-origin too — so cross-origin access is never needed. (Static frontend mount is
# registered at the BOTTOM of this file, after every /api route, so it never shadows them.)


@app.exception_handler(InsightUnavailable)
def _insight_unavailable(request, exc: InsightUnavailable):
    """AI layer down -> 503 with the reason, not a bare 500.

    The dashboards' numbers are all computed in SQL and are unaffected; only the
    narrative text is missing. Saying so in the response is what turns "Internal
    Server Error" into something the user can act on."""
    return JSONResponse(status_code=503, content={"detail": str(exc)})


@app.on_event("startup")
def on_startup():
    init_db()


def get_db():
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


def default_year(year: Optional[int]) -> int:
    return year if year is not None else datetime.now().year


def _filters(**kwargs) -> Optional[dict]:
    """Drops unset filter query params; returns None if nothing was passed
    so downstream SQL builders can treat 'no filters' as a fast no-op."""
    active = {k: v for k, v in kwargs.items() if v}
    return active or None


# ---- Customers & sync ----

@app.get("/api/customers")
def list_customers(conn=Depends(get_db)):
    rows = conn.execute(
        """SELECT DISTINCT customer FROM (
               SELECT customer FROM leads
               UNION SELECT customer FROM cases
               UNION SELECT customer FROM complaints
               UNION SELECT customer FROM users
           )
           ORDER BY customer"""
    ).fetchall()
    return [row["customer"] for row in rows]


@app.get("/api/sync/status")
def sync_status(conn=Depends(get_db)):
    return sync_module.get_sync_status(conn)


def _sync_summary(results: list[dict]) -> dict:
    errors = [r for r in results if r.get("error")]
    synced = [r for r in results if not r["skipped"] and not r.get("error")]
    skipped = [r for r in results if r["skipped"]]
    return {
        "synced_files": len(synced),
        "skipped_files": len(skipped),
        "error_files": len(errors),
        "details": results,
    }


def _run_sync(fn, *args, **kwargs):
    """Run a sync call, turning source-folder problems into a clear 400 instead of a 500.
    sync_all() raises RuntimeError when no path is configured and FileNotFoundError when the
    folder isn't there — both are operator errors the admin panel should surface as text."""
    try:
        return fn(*args, **kwargs)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=f"Source folder not found in the container: {exc}")
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/sync/refresh")
def sync_refresh():
    return _sync_summary(_run_sync(sync_module.sync_all, onedrive_path=admin_config.get_source_path()))


@app.post("/api/sync/refresh/{customer}")
def sync_refresh_customer(customer: str):
    return _sync_summary(
        _run_sync(sync_module.sync_all, onedrive_path=admin_config.get_source_path(), customer=customer)
    )


# --- Admin: source folder + refresh controls -------------------------------------------
# Enforced admin-only by the OneView nginx gate (auth_request -> /api/auth/admin-check);
# this app has no session of its own — see nginx.conf's /adoption/api/admin/ block.


@app.get("/api/admin/config")
def admin_get_config():
    """Current source folder + what the scanner can see there, plus the customers
    already in the DB (drives the full-refresh picker)."""
    return {**admin_config.describe(), "known_customers": sync_module.list_known_customers()}


class SourcePathRequest(BaseModel):
    path: str


@app.post("/api/admin/config/validate")
def admin_validate_path(payload: SourcePathRequest):
    """Dry-run a folder before saving it, so a wrong level (0 files found) is visible
    up front rather than after a no-op refresh."""
    return admin_config.validate_source_path(payload.path)


@app.put("/api/admin/config")
def admin_set_path(payload: SourcePathRequest):
    result = admin_config.set_source_path(payload.path)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "Invalid path"))
    return {**result, **admin_config.describe()}


@app.post("/api/admin/refresh")
def admin_refresh_incremental():
    """Incremental: parse only files whose mtime changed since the last run. This is
    also what picks up brand-new customer folders — they flow straight into the
    customer selector and comparison once parsed."""
    path = admin_config.get_source_path()
    if not path:
        raise HTTPException(status_code=400, detail="No source folder configured — set one first.")
    return _sync_summary(_run_sync(sync_module.sync_all, onedrive_path=path))


@app.post("/api/admin/refresh/{customer}")
def admin_refresh_customer(customer: str):
    path = admin_config.get_source_path()
    if not path:
        raise HTTPException(status_code=400, detail="No source folder configured — set one first.")
    return _sync_summary(_run_sync(sync_module.sync_all, onedrive_path=path, customer=customer))


@app.post("/api/admin/refresh/{customer}/full")
def admin_full_refresh_customer(customer: str):
    """Wipe this customer's rows, then re-parse everything for them. Per-customer by
    design: other customers keep serving their data throughout."""
    path = admin_config.get_source_path()
    if not path:
        raise HTTPException(status_code=400, detail="No source folder configured — set one first.")
    outcome = _run_sync(sync_module.full_refresh_customer, customer, onedrive_path=path)
    return {"customer": customer, "deleted": outcome["deleted"], **_sync_summary(outcome["results"])}


# ---- Leads ----
# Filter query params map 1:1 to leads_metrics.FILTERABLE_COLUMNS keys.

def _leads_filters(product_category=None, lead_source=None, branch=None, existing_customer=None):
    return _filters(
        product_category=product_category, lead_source=lead_source, branch=branch, existing_customer=existing_customer
    )


@app.get("/api/{customer}/leads/kpis")
def leads_kpis(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_kpis(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/trends")
def leads_trends(
    customer: str, year: Optional[int] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_trends(conn, customer, default_year(year), filters)


@app.get("/api/{customer}/leads/by-product")
def leads_by_product(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_by_product(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/by-category")
def leads_by_category(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_by_category(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/by-source")
def leads_by_source(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_by_source(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/by-branch")
def leads_by_branch(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_by_branch(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/pipeline")
def leads_pipeline(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_pipeline(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/decline-reasons")
def leads_decline_reasons(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_decline_reasons(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/funnel")
def leads_funnel(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_funnel(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/by-member-type")
def leads_by_member_type(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_by_member_type(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/book-of-business-trend")
def leads_book_of_business_trend(
    customer: str, year: Optional[int] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_book_of_business_trend(conn, customer, default_year(year), filters)


@app.get("/api/{customer}/leads/member-type-trend")
def leads_member_type_trend(
    customer: str, year: Optional[int] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_member_type_trend(conn, customer, default_year(year), filters)


@app.get("/api/{customer}/leads/member-type-by-category")
def leads_member_type_by_category(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_member_type_by_category(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/member-type-decline-reasons")
def leads_member_type_decline_reasons(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_member_type_decline_reasons(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/member-type-by-source")
def leads_member_type_by_source(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_metrics.get_leads_member_type_by_source(conn, customer, default_year(year), month, filters)


# ---- Leads: period-over-period comparison & correlation/driver analysis ----
# Backend takes explicit (year, month_no) pairs for each comparison period —
# Year-over-year vs Rolling vs Custom period selection is entirely a
# frontend concern; these routes only ever answer "give me metrics for this
# exact set of months."

@app.get("/api/{customer}/leads/period-coverage")
def leads_period_coverage(customer: str, conn=Depends(get_db)):
    """Which (year, month) combinations actually have synced lead data for
    this customer — drives the comparison picker's available options and
    its "latest month" anchor for Rolling mode, since real sync coverage
    varies per customer instead of being a fixed window."""
    rows = conn.execute(
        """SELECT DISTINCT created_year AS year, created_month AS month, created_month_no AS month_no
           FROM leads
           WHERE customer = ? AND created_year IS NOT NULL AND created_month_no IS NOT NULL
           ORDER BY created_year, created_month_no""",
        (customer,),
    ).fetchall()

    months_by_year: dict = {}
    for row in rows:
        months_by_year.setdefault(row["year"], []).append({"month": row["month"], "month_no": row["month_no"]})
    latest = None
    if rows:
        last = rows[-1]
        latest = {"year": last["year"], "month": last["month"], "month_no": last["month_no"]}
    return {"years": sorted(months_by_year.keys()), "months_by_year": months_by_year, "latest": latest}


class PeriodPoint(BaseModel):
    year: int
    month_no: int


class LeadsComparisonRequest(BaseModel):
    period_a: List[PeriodPoint]
    period_b: List[PeriodPoint]
    label_a: Optional[str] = None
    label_b: Optional[str] = None
    filters: Optional[dict] = None


@app.post("/api/{customer}/leads/comparison")
def leads_comparison_route(customer: str, payload: LeadsComparisonRequest, conn=Depends(get_db)):
    period_a = [(p.year, p.month_no) for p in payload.period_a]
    period_b = [(p.year, p.month_no) for p in payload.period_b]
    filters = {k: v for k, v in (payload.filters or {}).items() if v} or None
    return leads_comparison.get_leads_comparison(conn, customer, period_a, period_b, filters)


@app.post("/api/{customer}/leads/comparison-insight")
def leads_comparison_insight(customer: str, payload: LeadsComparisonRequest, conn=Depends(get_db)):
    period_a = [(p.year, p.month_no) for p in payload.period_a]
    period_b = [(p.year, p.month_no) for p in payload.period_b]
    filters = {k: v for k, v in (payload.filters or {}).items() if v} or None
    comparison = leads_comparison.get_leads_comparison(conn, customer, period_a, period_b, filters)

    label_a = payload.label_a or f"{len(period_a)} month(s)"
    label_b = payload.label_b or f"{len(period_b)} month(s)"
    cache_year = period_b[0][0] if period_b else (period_a[0][0] if period_a else 0)
    cache_key = make_insight_cache_key(
        customer, "leads_comparison", cache_year, None,
        {"period_a": period_a, "period_b": period_b, "filters": filters, "comparison": comparison},
    )

    cached = get_cached_chart_insights(conn, cache_key)
    if cached and cached.get("insight"):
        return {"insight": cached["insight"], "cached": True}

    text = generate_period_comparison_insight(customer, label_a, label_b, comparison)
    if text:
        store_chart_insights(conn, cache_key, customer, "leads_comparison", cache_year, None, {"insight": text})
    return {"insight": text, "cached": False}


@app.get("/api/{customer}/leads/correlation")
def leads_correlation_route(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_correlation.get_leads_time_correlation(conn, customer, default_year(year), month, filters)


@app.get("/api/{customer}/leads/drivers")
def leads_drivers_route(
    customer: str, year: Optional[int] = None, month: Optional[str] = None, metric: str = "conversion",
    product_category: Optional[List[str]] = Query(None), lead_source: Optional[List[str]] = Query(None),
    branch: Optional[List[str]] = Query(None), existing_customer: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    filters = _leads_filters(product_category, lead_source, branch, existing_customer)
    return leads_correlation.get_leads_drivers(conn, customer, default_year(year), month, filters, metric)


class LeadsCorrelationInsightRequest(BaseModel):
    year: int
    month: Optional[str] = None
    filters: Optional[dict] = None


@app.post("/api/{customer}/leads/correlation-insight")
def leads_correlation_insight(customer: str, payload: LeadsCorrelationInsightRequest, conn=Depends(get_db)):
    filters = {k: v for k, v in (payload.filters or {}).items() if v} or None
    correlation = leads_correlation.get_leads_time_correlation(conn, customer, payload.year, payload.month, filters)
    drivers = leads_correlation.get_leads_drivers(conn, customer, payload.year, payload.month, filters)

    cache_key = make_insight_cache_key(
        customer, "leads_correlation", payload.year, payload.month,
        {"correlation": correlation, "drivers": drivers, "filters": filters},
    )
    cached = get_cached_chart_insights(conn, cache_key)
    if cached and cached.get("insight"):
        return {"insight": cached["insight"], "cached": True}

    text = generate_correlation_insight(customer, correlation, drivers)
    if text:
        store_chart_insights(conn, cache_key, customer, "leads_correlation", payload.year, payload.month, {"insight": text})
    return {"insight": text, "cached": False}


# ---- Cases ----

def _cases_filters(category=None, branch=None, source=None):
    return _filters(category=category, branch=branch, source=source)


@app.get("/api/{customer}/cases/kpis")
def cases_kpis(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_kpis(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/trends")
def cases_trends(
    customer: str, year: Optional[int] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_trends(conn, customer, default_year(year), _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/by-category")
def cases_by_category(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_by_category(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/by-branch")
def cases_by_branch(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_by_branch(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/by-source")
def cases_by_source(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_by_source(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/sla")
def cases_sla(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_sla(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/ftr")
def cases_ftr(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_ftr(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/rework")
def cases_rework(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_rework(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


@app.get("/api/{customer}/cases/status-distribution")
def cases_status_distribution(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), branch: Optional[List[str]] = Query(None),
    source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return cases_metrics.get_cases_status_distribution(conn, customer, default_year(year), month, _cases_filters(category, branch, source))


# ---- Complaints ----

def _complaints_filters(category=None, source=None):
    return _filters(category=category, source=source)


@app.get("/api/{customer}/complaints/kpis")
def complaints_kpis(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return complaints_metrics.get_complaints_kpis(conn, customer, default_year(year), month, _complaints_filters(category, source))


@app.get("/api/{customer}/complaints/by-category")
def complaints_by_category(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return complaints_metrics.get_complaints_by_category(conn, customer, default_year(year), month, _complaints_filters(category, source))


@app.get("/api/{customer}/complaints/trends")
def complaints_trends(
    customer: str, year: Optional[int] = None,
    category: Optional[List[str]] = Query(None), source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return complaints_metrics.get_complaints_trends(conn, customer, default_year(year), _complaints_filters(category, source))


@app.get("/api/{customer}/complaints/by-source")
def complaints_by_source(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return complaints_metrics.get_complaints_by_source(conn, customer, default_year(year), month, _complaints_filters(category, source))


@app.get("/api/{customer}/complaints/status-distribution")
def complaints_status_distribution(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    category: Optional[List[str]] = Query(None), source: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return complaints_metrics.get_complaints_status_distribution(conn, customer, default_year(year), month, _complaints_filters(category, source))


# ---- Users ----

def _users_filters(role=None, territory=None):
    return _filters(role=role, territory=territory)


@app.get("/api/{customer}/users/kpis")
def users_kpis(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_kpis(conn, customer, default_year(year), month, _users_filters(role, territory))


@app.get("/api/{customer}/users/trends")
def users_trends(
    customer: str, year: Optional[int] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_trends(conn, customer, default_year(year), _users_filters(role, territory))


@app.get("/api/{customer}/users/by-role")
def users_by_role(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_by_role(conn, customer, default_year(year), month, _users_filters(role, territory))


@app.get("/api/{customer}/users/inactive")
def users_inactive(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_inactive(conn, customer, default_year(year), month, _users_filters(role, territory))


@app.get("/api/{customer}/users/by-territory")
def users_by_territory(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_by_territory(conn, customer, default_year(year), month, _users_filters(role, territory))


@app.get("/api/{customer}/users/engagement-tiers")
def users_engagement_tiers(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    role: Optional[List[str]] = Query(None), territory: Optional[List[str]] = Query(None), conn=Depends(get_db),
):
    return users_metrics.get_users_engagement_tiers(conn, customer, default_year(year), month, _users_filters(role, territory))


# ---- Customer Info (notes) ----
# Free-form per-customer background (region, financials, members, systems)
# stored as a real .md file on disk — see notes.py. Upload only extracts
# text; it never writes to disk, so there's exactly one save path.

@app.get("/api/{customer}/notes")
def get_customer_note(customer: str, conn=Depends(get_db)):
    """Seeds the note from FI Navigator + Redash the first time it's opened, so the tab
    starts with real background instead of an empty box. Once the file exists it is
    returned untouched — a saved edit is permanent."""
    return notes_module.get_or_seed_note(conn, customer)


class NoteRequest(BaseModel):
    content: str


@app.put("/api/{customer}/notes")
def save_customer_note(customer: str, payload: NoteRequest):
    return notes_module.save_note(customer, payload.content)


@app.post("/api/{customer}/notes/upload")
async def upload_customer_note(customer: str, file: UploadFile = File(...)):
    raw = await file.read()
    try:
        text = notes_module.extract_text(file.filename, raw)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"content": text}


# ---- Customer comparison ----

@app.get("/api/comparison/catalog")
def comparison_catalog():
    return comparison_module.get_comparison_catalog()


class ComparisonRequest(BaseModel):
    customers: List[str]
    year: int
    month: Optional[str] = None
    selected_kpis: Optional[dict] = None
    trend_metric: Optional[dict] = None
    breakdown_dimension: Optional[dict] = None


def _validate_comparison_customers(customers: List[str]) -> List[str]:
    unique = list(dict.fromkeys(customers))
    if len(unique) < 2 or len(unique) > 4:
        raise HTTPException(status_code=400, detail="Select between 2 and 4 customers to compare")
    return unique


@app.post("/api/comparison")
def run_comparison(payload: ComparisonRequest, conn=Depends(get_db)):
    customers = _validate_comparison_customers(payload.customers)
    data, kpi_catalog = comparison_module.get_comparison_data(conn, customers, payload.year, payload.month, payload.selected_kpis)
    return {"data": data, "kpi_catalog": kpi_catalog}


@app.post("/api/comparison/charts")
def comparison_charts(payload: ComparisonRequest, conn=Depends(get_db)):
    customers = _validate_comparison_customers(payload.customers)
    trends = comparison_module.get_comparison_trends(conn, customers, payload.year, payload.selected_kpis, payload.trend_metric)
    breakdown = comparison_module.get_comparison_breakdown(
        conn, customers, payload.year, payload.month, payload.selected_kpis, payload.breakdown_dimension
    )
    return {"trends": trends, "breakdown": breakdown}


@app.post("/api/comparison/insights")
def comparison_insights(payload: ComparisonRequest, conn=Depends(get_db)):
    customers = _validate_comparison_customers(payload.customers)
    data, _ = comparison_module.get_comparison_data(conn, customers, payload.year, payload.month, payload.selected_kpis)
    notes_context = {c: notes_module.get_note(c)["content"][:2000] for c in customers}

    month_label = ",".join(payload.month) if isinstance(payload.month, list) else payload.month
    cache_key = make_insight_cache_key(
        ",".join(sorted(customers)), "comparison", payload.year, month_label, {"data": data, "notes": notes_context}
    )
    cached = get_cached_chart_insights(conn, cache_key)
    if cached is not None:
        return {"insights": cached, "cached": True}

    result = generate_comparison_insights(customers, data, notes_context)
    store_chart_insights(conn, cache_key, ",".join(sorted(customers)), "comparison", payload.year, month_label, result)
    return {"insights": result, "cached": False}


# ---- AI Insights ----

class InsightRequest(BaseModel):
    module: str
    year: int
    month: Optional[str] = None
    metrics_json: dict


@app.post("/api/{customer}/insights")
def create_insight(customer: str, payload: InsightRequest):
    text = generate_insight(customer, payload.module, payload.metrics_json)
    return {"insight": text, "ai_generated": True}


# ---- Per-chart AI insights (one OpenAI call per module view, cached) ----
# Assembly + caching lives in chart_metrics.py, shared with the QBR PPT export.


class ModuleInsightRequest(BaseModel):
    module: str
    year: int
    month: Optional[str] = None
    filters: Optional[dict] = None


@app.post("/api/{customer}/insights/module")
def create_module_insights(customer: str, payload: ModuleInsightRequest, conn=Depends(get_db)):
    if payload.module not in MODULE_CHART_METRICS:
        raise HTTPException(status_code=400, detail=f"Unknown module: {payload.module}")

    filters = {k: v for k, v in (payload.filters or {}).items() if v} or None
    _, insights, was_cached = get_chart_insights(conn, customer, payload.module, payload.year, payload.month, filters)
    return {"insights": insights, "cached": was_cached}


@app.post("/api/{customer}/insights/sections")
def create_section_insights(customer: str, payload: ModuleInsightRequest, conn=Depends(get_db)):
    if payload.module not in MODULE_SECTION_GROUPS:
        raise HTTPException(status_code=400, detail=f"No dashboard sections defined for module: {payload.module}")

    filters = {k: v for k, v in (payload.filters or {}).items() if v} or None
    _, insights, was_cached = get_section_insights(conn, customer, payload.module, payload.year, payload.month, filters)
    return {"insights": insights, "cached": was_cached}


# ---- QBR Report (in-app portal view: FI Navigator + live DB KPIs, with
# Redash-sourced sections returned as explicit "not available"). ----

@app.get("/api/{customer}/qbr/report")
def qbr_report(customer: str, year: Optional[int] = None, month: Optional[str] = None, conn=Depends(get_db)):
    return build_qbr_report(conn, customer, default_year(year), month)


@app.post("/api/{customer}/qbr/export-ppt")
def qbr_export_ppt(customer: str, payload: dict):
    from qbr_ppt import build_qbr_ppt
    content = build_qbr_ppt(payload)
    filename = f"QBR_{customer}.pptx"
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---- QBR export (PPT). PNG/HTML are rendered client-side from the same
# already-loaded dashboard data, so there's no server route for those. ----

@app.get("/api/{customer}/export/qbr")
def export_qbr(
    customer: str, year: Optional[int] = None, month: Optional[str] = None,
    selection: Optional[str] = None, conn=Depends(get_db),
):
    resolved_year = default_year(year)
    parsed_selection = None
    if selection:
        try:
            parsed_selection = json.loads(selection)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail=f"Invalid selection payload: {exc}") from exc
    content = generate_qbr_ppt(conn, customer, resolved_year, month, parsed_selection)
    filename = f"{customer}_QBR_{resolved_year}_{month or 'All'}.pptx"
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---- Senior Summary (Leads/Cases/Complaints/Users AI bullets, one call, cached) ----

class SeniorSummaryRequest(BaseModel):
    year: int
    period_type: str  # 'month' | 'quarter' | 'year'
    period_value: Optional[str] = None  # month name for 'month', 'Q1'..'Q4' for 'quarter', unused for 'year'
    # {"leads": [kpi_key, ...], "cases": [...], "complaints": [...], "users": [...]} —
    # set only by the QBR "Select KPIs" export mode, to narrow the executive
    # summary to the KPIs the user chose instead of the full KPI set.
    selected_kpis: Optional[dict] = None


@app.post("/api/{customer}/senior-summary")
def create_senior_summary(customer: str, payload: SeniorSummaryRequest, conn=Depends(get_db)):
    try:
        month = resolve_period(payload.period_type, payload.period_value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    bullets, was_cached = get_senior_summary(conn, customer, payload.year, month, payload.selected_kpis)
    return {
        "bullets": bullets,
        "cached": was_cached,
        "period_label": period_label(payload.period_type, payload.period_value),
    }


class SeniorSummaryEmailRequest(BaseModel):
    year: int
    period_type: str
    period_value: Optional[str] = None
    recipients: list[str]
    bullets: dict


@app.post("/api/{customer}/senior-summary/email")
def queue_senior_summary_email(customer: str, payload: SeniorSummaryEmailRequest, conn=Depends(get_db)):
    recipients = [r.strip() for r in payload.recipients if r.strip()]
    if not recipients:
        raise HTTPException(status_code=400, detail="At least one recipient email is required")
    invalid = [r for r in recipients if "@" not in r or "." not in r.split("@")[-1]]
    if invalid:
        raise HTTPException(status_code=400, detail=f"Invalid email address(es): {', '.join(invalid)}")

    label = period_label(payload.period_type, payload.period_value)
    queue_id = queue_summary_email(conn, customer, "senior_summary", payload.year, label, recipients, payload.bullets)
    return {
        "queued": True,
        "queue_id": queue_id,
        "recipients": recipients,
        "message": f"Saved for {len(recipients)} recipient(s) — will be sent once an email server is configured.",
    }


# --- Static frontend (production) --------------------------------------------------------
# Serve the built React SPA (Vite output) from this same app so the whole thing runs as ONE
# container behind OneView's nginx at /adoption/. This mount is registered LAST, so it only
# catches paths that no /api route above matched (index.html, /assets/*, favicon, etc.).
# In standalone dev this directory doesn't exist (Vite serves the frontend on :5173), so the
# mount is skipped and the backend is API-only — the dev workflow is unchanged.
_FRONTEND_DIST = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
if os.path.isdir(_FRONTEND_DIST):
    app.mount("/", StaticFiles(directory=_FRONTEND_DIST, html=True), name="frontend")
