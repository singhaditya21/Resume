import psycopg2

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='dbo' OR table_schema='public'")
    tables = [r[0] for r in cursor.fetchall()]
    
    # Looking for users, agents, priority, status
    print("--- POTENTIAL LOOKUP TABLES ---")
    for t in tables:
        t_low = t.lower()
        if 'user' in t_low or 'owner' in t_low or 'agent' in t_low or 'member' in t_low or 'employee' in t_low:
            print(t)
        if 'status' in t_low or 'priorit' in t_low or 'categor' in t_low:
            print(t)
            
    conn.close()
except Exception as e:
    print(e)
