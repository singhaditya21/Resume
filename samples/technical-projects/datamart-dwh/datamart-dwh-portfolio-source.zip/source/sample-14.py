import psycopg2

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT tc.constraint_name, kcu.column_name, ccu.table_name AS foreign_table_name, ccu.column_name AS foreign_column_name 
        FROM information_schema.table_constraints AS tc 
        JOIN information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema 
        JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema 
        WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name='cases';
    """)
    res = cursor.fetchall()
    for r in res:
        print(r)
    conn.close()
except Exception as e:
    print(e)
