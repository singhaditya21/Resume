import psycopg2

def get_pg_cols(host, user, password, dbname="my_2026_04_01"):
    try:
        print(f"Trying PostgreSQL at {host} as {user} with db {dbname}...")
        conn = psycopg2.connect(
            host=host,
            user=user,
            password=REDACTED_SECRET
            dbname=dbname,
            connect_timeout=3
        )
        print("Connected!")
        tables = ['cases', 'cas_ex1', 'cas_ex2', 'cas_ex3', 'cas_ex4', 'cas_ex5', 'cas_ex6']
        for table in tables:
            with conn.cursor() as cursor:
                cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table}';")
                cols = [row[0] for row in cursor.fetchall()]
                with open(f"pg_cols_{table}.txt", "w") as f:
                    for c in cols: f.write(c + "\n")
                print(f"Table {table}: {len(cols)} columns")
        conn.close()
        return True
    except Exception as e:
        print("Error:", str(e).strip())
        return False

# Local auth combos
if get_pg_cols('127.0.0.1', 'postgres', 'postgres'): pass
elif get_pg_cols('127.0.0.1', 'postgres', 'root'): pass
elif get_pg_cols('127.0.0.1', 'postgres', 'admin'): pass
elif get_pg_cols('127.0.0.1', 'postgres', ''): pass
# Remote auth combos
elif get_pg_cols('192.0.2.10', 'postgres', 'postgres'): pass
elif get_pg_cols('192.0.2.10', 'postgres', 'root'): pass
elif get_pg_cols('192.0.2.10', 'user', 'Noida@2406'): pass
elif get_pg_cols('192.0.2.10', 'postgres', 'Noida@2406'): pass
