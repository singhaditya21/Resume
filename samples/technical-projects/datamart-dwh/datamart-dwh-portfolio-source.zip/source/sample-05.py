import psycopg2
import time
import sys

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

def print_log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

def build_history_dwh():
    print_log("Starting DWH History Analytics refresh...")
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cursor = conn.cursor()

    tables_hs = ['casehistory', 'cas_ex1_hs', 'cas_ex2_hs', 'cas_ex3_hs', 'cas_ex4_hs', 'cas_ex5_hs', 'cas_ex6_hs']
    
    select_fields = ["c.*"]
    joins = []
    
    for i, t in enumerate(tables_hs[1:], 1):
        # Identify columns dynamically, skipping IDs to avoid collision
        cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{t}' AND column_name NOT LIKE '%_id'")
        ext_cols = [row[0] for row in cursor.fetchall()]
        for col in ext_cols:
            select_fields.append(f"e{i}.{col}")
        
        # History extensions join purely on historyid and ownerid
        # Wait, does cas_ex1_hs have historyid? Yes, we checked earlier: ['ownerid', 'cas_ex1_id', 'historyid', ...]
        joins.append(f"LEFT JOIN {t} e{i} ON c.historyid = e{i}.historyid AND c.ownerid = e{i}.ownerid")
        
    # Standard Semantic text joins mapping directly to casehistory integers
    joins.append("LEFT JOIN az_user u_ass ON c.assignedto = u_ass.userid AND c.ownerid = u_ass.appownerid")
    joins.append("LEFT JOIN az_user u_curr ON c.currentownerid = u_curr.userid AND c.ownerid = u_curr.appownerid")
    joins.append("LEFT JOIN statuscodemaster s ON c.statusid = s.statuscodeid AND s.itemtypeid = 9 AND c.ownerid = s.ownerid")
    joins.append("LEFT JOIN lookupmaster p ON c.priorityid = p.lookupid AND p.groupkey = 9 AND c.ownerid = p.ownerid")
    
    select_fields.append("u_ass.username AS assignedto_name")
    select_fields.append("u_curr.username AS currentowner_name")
    select_fields.append("s.statuscode AS status_name")
    select_fields.append("p.name AS priority_name")
    
    select_clause = ",\n        ".join(select_fields)
    join_clause = "\n        ".join(joins)

    dim_cases_hs_sql = f"""
    DROP TABLE IF EXISTS analytics.dim_case_history CASCADE;
    CREATE TABLE analytics.dim_case_history AS
    SELECT 
        {select_clause}
    FROM casehistory c
        {join_clause}
    WHERE c.lastmodifiedon >= current_date - interval '5 year';
    """
    
    print_log("Building wide analytics.dim_case_history table...")
    try:
        cursor.execute(dim_cases_hs_sql)
        cursor.execute("SELECT count(*) FROM analytics.dim_case_history;")
        cnt = cursor.fetchone()[0]
        print_log(f"Success! analytics.dim_case_history refreshed with {cnt} records.")
    except Exception as e:
        print_log(f"Error building dim_case_history: {e}")

    # Build Fact History
    print_log("Building analytics.fact_case_history...")
    fact_cases_hs_sql = """
    DROP TABLE IF EXISTS analytics.fact_case_history CASCADE;
    CREATE TABLE analytics.fact_case_history AS
    SELECT 
        historyid,
        caseid,
        ownerid AS owner_key,
        statusid AS status_key,
        categoryid AS category_key,
        productid AS product_key,
        CAST(lastmodifiedon AS DATE) AS date_key,
        lastmodifiedon AS snapshot_timestamp,
        EXTRACT(EPOCH FROM (resolvedon - reportedon))/3600 AS time_to_resolution_hours
    FROM casehistory
    WHERE lastmodifiedon >= current_date - interval '5 year';
    """
    try:
        cursor.execute(fact_cases_hs_sql)
        cursor.execute("SELECT count(*) FROM analytics.fact_case_history;")
        cnt = cursor.fetchone()[0]
        print_log(f"Success! analytics.fact_case_history refreshed with {cnt} records.")
    except Exception as e:
        print_log(f"Error building fact_case_history: {e}")

    cursor.close()
    conn.close()
    print_log("DWH History Refresh Complete.")

if __name__ == "__main__":
    build_history_dwh()
