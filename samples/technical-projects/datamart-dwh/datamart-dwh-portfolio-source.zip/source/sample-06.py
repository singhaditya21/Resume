import pandas as pd
excel_path = r"/opt/portfolio/project"

try:
    df = pd.read_excel(excel_path)
    columns = list(df.columns)
    with open("excel_cols.txt", "w") as f:
        for col in columns:
            f.write(str(col) + "\n")
    print(f"Success! Found {len(columns)} columns.")
except Exception as e:
    print("Error:", e)
