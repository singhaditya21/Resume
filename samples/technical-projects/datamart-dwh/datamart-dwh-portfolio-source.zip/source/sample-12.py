import psycopg2
import pandas as pd

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    
    print("--- az_user ---")
    try:
        print(pd.read_sql("SELECT * FROM dbo.az_user LIMIT 1", conn).columns.tolist())
    except Exception as e: print(e)

    print("--- statuscodemaster ---")
    try:
        print(pd.read_sql("SELECT * FROM dbo.statuscodemaster LIMIT 1", conn).columns.tolist())
    except Exception as e: print(e)
    
    print("--- lookupmaster ---")
    try:
        print(pd.read_sql("SELECT * FROM dbo.lookupmaster LIMIT 1", conn).columns.tolist())
    except Exception as e: print(e)
    
    conn.close()
except Exception as e:
    print(e)
