import psycopg2
from psycopg2 import sql

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

def setup_dwh():
    print("Connecting to PostgreSQL to build Analytical Data Warehouse...")
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cursor = conn.cursor()

    # 1. Initialize Analytics Schema
    print("Creating 'analytics' schema...")
    cursor.execute("CREATE SCHEMA IF NOT EXISTS analytics;")

    # 2. Extract column definitions for the flattened Dim_Cases
    print("Extracting column schemas to build flattened Dim_Cases...")
    tables = ['cases', 'cas_ex1', 'cas_ex2', 'cas_ex3', 'cas_ex4', 'cas_ex5', 'cas_ex6']
    
    select_fields = ["c.*"]
    joins = []
    
    for i, t in enumerate(tables[1:], 1):
        # We only want non-ID columns from extension tables to avoid collision
        cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{t}' AND column_name NOT LIKE '%_id'")
        ext_cols = [row[0] for row in cursor.fetchall()]
        
        # Build SELECT parts
        for col in ext_cols:
            select_fields.append(f"e{i}.{col}")
            
        # Build JOIN parts
        # cases.caseid seems to be the join key, but let's check what it joins to.
        # cas_ex1_id is likely the primary key for cas_ex1 matching caseid.
        joins.append(f"LEFT JOIN {t} e{i} ON c.caseid = e{i}.{t}_id")

    select_clause = ",\n        ".join(select_fields)
    join_clause = "\n        ".join(joins)

    dim_cases_sql = f"""
    DROP TABLE IF EXISTS analytics.dim_cases CASCADE;
    CREATE TABLE analytics.dim_cases AS
    SELECT 
        {select_clause}
    FROM cases c
        {join_clause};
    """
    
    print("Building wide analytics.dim_cases table (this might take a moment)...")
    try:
        cursor.execute(dim_cases_sql)
        cursor.execute("SELECT count(*) FROM analytics.dim_cases;")
        cnt = cursor.fetchone()[0]
        print(f"Success! analytics.dim_cases created with {cnt} records.")
    except Exception as e:
        print(f"Error building dim_cases: {e}")

    # 3. Build Fact_Cases
    print("Building analytics.fact_cases...")
    fact_cases_sql = """
    DROP TABLE IF EXISTS analytics.fact_cases CASCADE;
    CREATE TABLE analytics.fact_cases AS
    SELECT 
        caseid,
        ownerid AS owner_key,
        statusid AS status_key,
        categoryid AS category_key,
        productid AS product_key,
        CAST(createdon AS DATE) AS created_date_key,
        CAST(resolvedon AS DATE) AS resolved_date_key,
        CAST(reopencount AS INTEGER) as reopencount,
        CAST(escalatedcount AS INTEGER) as escalatedcount,
        CAST(targetsla AS NUMERIC) as targetsla,
        EXTRACT(EPOCH FROM (resolvedon - createdon))/3600 AS time_to_resolution_hours
    FROM cases;
    """
    try:
        cursor.execute(fact_cases_sql)
        cursor.execute("SELECT count(*) FROM analytics.fact_cases;")
        cnt = cursor.fetchone()[0]
        print(f"Success! analytics.fact_cases created with {cnt} records.")
    except Exception as e:
        print(f"Error building fact_cases: {e}")

    cursor.close()
    conn.close()
    print("DWH Setup Complete.")

if __name__ == "__main__":
    setup_dwh()
