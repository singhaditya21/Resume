import psycopg2
import pandas as pd

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    print(pd.read_sql("SELECT table_name FROM information_schema.tables WHERE table_name IN ('category', 'product', 'priority', 'statuscodemaster', 'caserequirementpriority', 'allocationpriority', 'productmaster')", conn))
    
    # Let's peek at category
    try:
        print(pd.read_sql("SELECT * FROM dbo.category LIMIT 1", conn).columns.tolist())
    except Exception as e: print(e)
    
    try:
        print(pd.read_sql("SELECT * FROM dbo.productmaster LIMIT 1", conn).columns.tolist())
    except Exception as e: print(e)
    
except Exception as e:
    print(e)
