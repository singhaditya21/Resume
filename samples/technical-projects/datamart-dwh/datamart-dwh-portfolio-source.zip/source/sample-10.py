import psycopg2

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cursor = conn.cursor()
    cursor.execute("""
        SELECT pid FROM pg_stat_activity 
        WHERE state = 'active'
        AND now() - query_start > interval '1 minutes'
        AND pid <> pg_backend_pid();
    """)
    pids = cursor.fetchall()
    for row in pids:
        pid = row[0]
        cursor.execute(f"SELECT pg_terminate_backend({pid});")
        print(f"Killed {pid}")
    cursor.close()
    conn.close()
except Exception as e:
    print(e)
