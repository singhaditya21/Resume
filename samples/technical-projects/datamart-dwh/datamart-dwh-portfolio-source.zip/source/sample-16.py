import psycopg2
import pandas as pd

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    
    # Check users table
    df_users = pd.read_sql("SELECT * FROM dbo.usermaster LIMIT 1", conn)
    print("Usermaster cols:", df_users.columns.tolist())
    
    df_users2 = pd.read_sql("SELECT * FROM dbo.userdetails LIMIT 1", conn)
    print("Userdetails cols:", df_users2.columns.tolist())
    
    # Check status
    try:
        df_status = pd.read_sql("SELECT * FROM dbo.statuscodes LIMIT 1", conn)
        print("Statuscodes cols:", df_status.columns.tolist())
    except:
        pass
        
    try:
        df_status2 = pd.read_sql("SELECT * FROM dbo.statuscodemaster LIMIT 1", conn)
        print("Statuscodemaster cols:", df_status2.columns.tolist())
    except:
        pass
        
    conn.close()
except Exception as e:
    print(e)
