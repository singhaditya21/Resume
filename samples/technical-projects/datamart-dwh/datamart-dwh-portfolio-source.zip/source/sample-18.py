import os

# Helper to read lines
def read_lines(filename):
    if not os.path.exists(filename): return []
    with open(filename, "r", encoding="utf-8") as f:
        return [line.strip().lower() for line in f if line.strip()]

# Read excel columns
excel_cols_raw = read_lines("excel_cols.txt")
excel_cols = set(excel_cols_raw)

# Read db columns
tables = ['cases', 'cas_ex1', 'cas_ex2', 'cas_ex3', 'cas_ex4', 'cas_ex5', 'cas_ex6']
db_cols_map = {}
all_db_cols = set()

for t in tables:
    cols = read_lines(f"pg_cols_{t}.txt")
    db_cols_map[t] = set(cols)
    all_db_cols.update(cols)

# Analysis
missing_cols = []
found_cols_mapping = {}

for col in excel_cols_raw:
    found_in = [t for t in tables if col in db_cols_map[t]]
    if found_in:
        found_cols_mapping[col] = found_in
    else:
        missing_cols.append(col)

with open("analysis_results.md", "w", encoding="utf-8") as f:
    f.write("# Excel vs PostgreSQL Schema Analysis\n\n")
    f.write("This document compares the columns found in `CaseRequiredColumnV2.xls` (109 columns) with the schemas of tables `cases` and `cas_ex1` through `cas_ex6` in the `my_2026_04_01` PostgreSQL database.\n\n")
    
    f.write("## High-Level Summary\n")
    f.write(f"- **Total columns in Excel:** {len(excel_cols_raw)}\n")
    f.write(f"- **Columns found in DB:** {len(found_cols_mapping)}\n")
    f.write(f"- **Columns completely missing from DB:** {len(missing_cols)}\n\n")
    
    f.write("## DB Table Representation\n")
    for t in tables:
        overlap = len(excel_cols.intersection(db_cols_map[t]))
        f.write(f"- **{t}**: Contains {len(db_cols_map[t])} columns total. Has {overlap} columns matching the Excel file.\n")
    f.write("\n")
    
    f.write("## Missing Columns\n")
    f.write("These columns are present in the Excel file but **DO NOT** exist in any of the specified tables (`cases`, `cas_ex1`..`cas_ex6`).\n")
    if missing_cols:
        f.write("```text\n")
        for c in missing_cols:
            f.write(f"- {c}\n")
        f.write("```\n\n")
    else:
        f.write("*None! All columns from the Excel file match existing columns.* \n\n")

    f.write("## Found Columns Mapping\n")
    f.write("Where each Excel column can be found in the databas/opt/portfolio/project")
    f.write("| Excel Column | Found In Tables |\n")
    f.write("| ------------ | --------------- |\n")
    for col, t_list in found_cols_mapping.items():
        f.write(f"| `{col}` | {', '.join(t_list)} |\n")
