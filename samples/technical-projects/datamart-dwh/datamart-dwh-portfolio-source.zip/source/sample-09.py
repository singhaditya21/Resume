import psycopg2
import pandas as pd

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    
    # 1. Check table names exists 
    tables = ['casehistory', 'cas_ex1_hs', 'cas_ex2_hs', 'cases', 'cas_ex1']
    
    for t in tables:
        try:
            df = pd.read_sql(f"SELECT * FROM dbo.{t} LIMIT 1", conn)
            print(f"--- {t} columns ---")
            print(df.columns.tolist())
        except Exception as e:
            print(f"Table {t} error:", e)
            
    conn.close()
except Exception as e:
    print(e)
