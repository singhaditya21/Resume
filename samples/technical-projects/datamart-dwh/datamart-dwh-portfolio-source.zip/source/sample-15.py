import psycopg2

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cursor = conn.cursor()
    
    # Kill the stuck ETL PIDs
    pids_to_kill = [3052364, 3052031, 3052023, 3052032]
    for p in pids_to_kill:
        cursor.execute(f"SELECT pg_terminate_backend({p})")
        print(f"Killed {p}")
        
    # Check for indexes
    tables = ['cases', 'cas_ex1', 'cas_ex2', 'cas_ex3', 'cas_ex4', 'cas_ex5', 'cas_ex6']
    for t in tables:
        cursor.execute(f"SELECT indexname, indexdef FROM pg_indexes WHERE tablename = '{t}'")
        idx = cursor.fetchall()
        print(f"--- Indexes on {t} ---")
        for i in idx:
            if '_id' in i[1].lower() or 'caseid' in i[1].lower():
                print("  ", i[1])
                
    conn.close()
except Exception as e:
    print(e)
