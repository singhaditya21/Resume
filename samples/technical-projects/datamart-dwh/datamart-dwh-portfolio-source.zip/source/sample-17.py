import paramiko
import time

def install_and_restart():
    print("Connecting to 192.168.0.81...")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('192.0.2.10', username='PORTFOLIO_REDACTED', password='REDACTED_SECRET')
    
    print("Installing google-generativeai...")
    stdin, stdout, stderr = ssh.exec_command("python3 -m pip install google-generativeai --user")
    
    out = stdout.read().decode()
    err = stderr.read().decode()
    # print("OUT:", out)
    # print("ERR:", err)
    
    print("Killing existing Streamlit processes on port 3001...")
    ssh.exec_command("fuser -k 3001/tcp")
    time.sleep(2)
    
    print("Restarting NLP Integrated Dashboard...")
    stdin, stdout, stderr = ssh.exec_command("nohup python3 -m streamlit run /biztech/Datamart-DWH/dashboard.py --server.port 3001 > /biztech/Datamart-DWH/streamlit.log 2>&1 &")
    time.sleep(3)
    
    ssh.close()
    print("Done")

if __name__ == "__main__":
    install_and_restart()
