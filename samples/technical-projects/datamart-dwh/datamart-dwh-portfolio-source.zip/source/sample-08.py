import psycopg2

DB_CONFIG = {
    'host': '192.0.2.10',
    'dbname': 'my_2026_04_01',
    'user': 'PORTFOLIO_REDACTED',
    'password': 'REDACTED_SECRET',
    'port': 5432
}

try:
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT pid, state, query, extract(epoch from (now() - query_start)) AS duration
        FROM pg_stat_activity 
        WHERE state = 'active' AND query NOT ILIKE '%pg_stat_activity%';
    """)
    rows = cursor.fetchall()
    for r in rows:
        print(f"PID: {r[0]}, STATE: {r[1]}, DURATION: {r[3]}, QUERY: {r[2][:200]}")
    conn.close()
except Exception as e:
    print(e)
