import pymysql

try:
    conn = pymysql.connect(host='192.0.2.10', user='PORTFOLIO_REDACTED', password='REDACTED_SECRET', database='my_2026_04_01', connect_timeout=5)
    print("MySQL Connected successfully to 192.0.2.10!")
    
    with conn.cursor() as cursor:
        for table in ['cases', 'cas_ex1', 'cas_ex2', 'cas_ex3', 'cas_ex4', 'cas_ex5', 'cas_ex6']:
            try:
                cursor.execute(f"SHOW COLUMNS FROM {table}")
                cols = [row[0] for row in cursor.fetchall()]
                with open(f"db_cols_{table}.txt", "w") as f:
                    for c in cols:
                        f.write(c + "\n")
                print(f"Table {table}: {len(cols)} columns")
            except Exception as e:
                print(f"Table {table} error: {e}")
    conn.close()
except Exception as e:
    print("MySQL Error 192.0.2.10:", e)

# Also try localhost if remote fails
try:
    conn = pymysql.connect(host='127.0.0.1', user='PORTFOLIO_REDACTED', password='', database='my_2026_04_01', connect_timeout=3)
    print("MySQL Connected successfully to localhost!")
    conn.close()
except Exception as e:
    print("MySQL Error localhost:", e)
