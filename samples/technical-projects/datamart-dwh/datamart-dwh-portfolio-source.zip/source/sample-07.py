import pandas as pd
import json

excel_path = r"/opt/portfolio/project"

try:
    df = pd.read_excel(excel_path)
    # Give summary of columns
    columns = list(df.columns)
    summary = {
        "columns": columns,
        "sample": df.head(3).to_dict()
    }
    with open("excel_analysis.json", "w") as f:
        json.dump(summary, f, indent=4)
    print("Excel file read successfully. Column count:", len(columns))
except Exception as e:
    print(f"Failed to read excel: {e}")
