import requests

from app.config.settings import get_settings
from utils.tracing import set_span_attrs, start_span


def call_llm(prompt: str) -> str:
    settings = get_settings()
    with start_span("rag.llm.chat_completion") as span:
        provider = "cerebras" if settings.cerebras_api_key else "llama.cpp"
        model = settings.cerebras_model if settings.cerebras_api_key else settings.llm_model
        set_span_attrs(
            span,
            {
                "openinference.span.kind": "LLM",
                "llm.provider": provider,
                "llm.model_name": model,
                "llm.prompt_chars": len(prompt),
                "llm.temperature": 0.1,
                "llm.max_tokens": 900,
                "input.value": prompt[:4000],
            },
        )

        if settings.cerebras_api_key:
            response = requests.post(
                f"{settings.cerebras_base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {settings.cerebras_api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": settings.cerebras_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_tokens": 900,
                },
                timeout=120,
            )
        else:
            response = requests.post(
                f"{settings.llama_cpp_base_url}/v1/chat/completions",
                json={
                    "model": settings.llm_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_tokens": 900,
                },
                timeout=180,
            )

        response.raise_for_status()
        answer = response.json()["choices"][0]["message"]["content"]
        set_span_attrs(span, {"llm.response_chars": len(answer), "output.value": answer[:4000]})
        return answer
