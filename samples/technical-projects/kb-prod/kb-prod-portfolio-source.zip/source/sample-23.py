import time
from typing import Any, Dict

from app.config.settings import get_settings
from vector_store.client import get_milvus_client

STARTED_AT = time.time()


def health_status(phoenix_status: Dict[str, Any]) -> Dict[str, Any]:
    settings = get_settings()
    milvus_error = None
    exists = False
    stats = {}
    try:
        client = get_milvus_client()
        exists = client.has_collection(settings.milvus_collection)
        stats = client.get_collection_stats(settings.milvus_collection) if exists else {}
    except Exception as exc:
        milvus_error = str(exc)
    return {
        "status": "ok" if milvus_error is None else "degraded",
        "service": "AIbot",
        "uptime_seconds": round(time.time() - STARTED_AT, 1),
        "milvus_uri": settings.milvus_uri,
        "collection": settings.milvus_collection,
        "collection_exists": exists,
        "row_count": stats.get("row_count", 0),
        "milvus_error": milvus_error,
        "llm": "cerebras" if settings.cerebras_api_key else "local",
        "phoenix": phoenix_status,
    }
