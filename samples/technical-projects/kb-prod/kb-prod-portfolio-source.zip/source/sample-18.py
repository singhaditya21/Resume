from fastapi import APIRouter

router = APIRouter(prefix="/ingest", tags=["ingest"])


@router.get("/status")
def ingest_status():
    return {"success": True, "status": "not_configured"}
