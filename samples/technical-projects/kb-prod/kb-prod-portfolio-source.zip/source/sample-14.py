"""CLI entry point for RAG evaluation."""
