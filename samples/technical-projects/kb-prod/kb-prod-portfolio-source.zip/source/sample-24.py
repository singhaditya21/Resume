from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config.settings import get_settings
from app.routes import api as production_api
from app.routes import health, ingest, query, test_ui, webhook
from app.config.constants import WEBHOOK_EVENT_LIMIT
from app.services.conversation import ConversationMemory
from utils.cache import EventCache


def create_app() -> FastAPI:
    settings = get_settings()
    api = FastAPI(title=settings.app_name, version=settings.app_version)
    api.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_origins != ["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    api.state.webhook_events = EventCache(WEBHOOK_EVENT_LIMIT)
    api.state.conversations = ConversationMemory(settings.chat_history_turns)
    api.state.phoenix_status = setup_phoenix_tracing(api)

    api.include_router(health.router)
    api.include_router(production_api.router)
    api.include_router(query.router)
    api.include_router(webhook.router)
    api.include_router(ingest.router)
    api.include_router(test_ui.router)
    if settings.enable_test_ui:
        from app.routes import ui

        api.include_router(ui.router)
    return api


def setup_phoenix_tracing(api: FastAPI) -> dict:
    settings = get_settings()
    status = {
        "enabled": settings.phoenix_enabled,
        "configured": False,
        "project_name": settings.phoenix_project_name,
        "endpoint": settings.phoenix_endpoint,
        "error": None,
    }
    if not settings.phoenix_enabled:
        return status
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        from phoenix.otel import register

        tracer_provider = register(project_name=settings.phoenix_project_name, endpoint=settings.phoenix_endpoint)
        FastAPIInstrumentor.instrument_app(api, tracer_provider=tracer_provider)
        status["configured"] = True
    except Exception as exc:
        status["error"] = str(exc)
    return status


app = create_app()
