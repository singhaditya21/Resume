from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class Source(BaseModel):
    document_id: Optional[str] = None
    file_name: Optional[str] = None
    file_path: Optional[str] = None
    score: float | int | None = None
    text_preview: Optional[str] = None


class AskResponse(BaseModel):
    success: bool
    answer: str
    sources: List[Source]


class HealthResponse(BaseModel):
    status: str
    service: str
    uptime_seconds: float
    milvus_uri: str
    collection: str
    collection_exists: bool
    row_count: int
    milvus_error: Optional[str]
    llm: str
    phoenix: Dict[str, Any]
