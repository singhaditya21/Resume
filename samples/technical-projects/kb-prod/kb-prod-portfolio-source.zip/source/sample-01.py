from typing import Any, Dict, List, Optional

from vector_store.queries import search_milvus


def retrieve(query: str, limit: int = 5, collection: Optional[str] = None, include_text: bool = False) -> List[Dict[str, Any]]:
    return search_milvus(query, limit, collection, include_text)
