from collections import defaultdict, deque
from typing import Deque, Dict, List, Literal, TypedDict


class ChatMessage(TypedDict):
    role: Literal["user", "assistant"]
    content: str


class ConversationMemory:
    def __init__(self, max_turns: int = 6) -> None:
        self._max_messages = max(2, max_turns * 2)
        self._sessions: Dict[str, Deque[ChatMessage]] = defaultdict(lambda: deque(maxlen=self._max_messages))

    def history(self, session_id: str | None) -> List[ChatMessage]:
        if not session_id:
            return []
        return list(self._sessions[session_id])

    def append_turn(self, session_id: str | None, user_message: str, assistant_message: str) -> None:
        if not session_id:
            return
        session = self._sessions[session_id]
        session.append({"role": "user", "content": user_message})
        session.append({"role": "assistant", "content": assistant_message})

    def clear(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
