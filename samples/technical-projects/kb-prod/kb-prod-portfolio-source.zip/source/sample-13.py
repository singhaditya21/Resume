"""CLI entry point for data ingestion."""
