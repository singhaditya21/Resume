"""AIbot RAG application package."""
