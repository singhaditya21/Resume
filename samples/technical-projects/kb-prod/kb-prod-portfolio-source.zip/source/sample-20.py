from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class SearchRequest(BaseModel):
    query: str
    limit: int = 5
    collection: Optional[str] = None
    include_text: bool = False


class AskRequest(BaseModel):
    question: str
    limit: int = 5
    collection: Optional[str] = None


class WebhookChatRequest(BaseModel):
    message: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    source: str = "company-ui"
    limit: int = 5
    collection: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WebhookEventRequest(BaseModel):
    event: str
    source: str = "company-ui"
    payload: Dict[str, Any] = Field(default_factory=dict)
