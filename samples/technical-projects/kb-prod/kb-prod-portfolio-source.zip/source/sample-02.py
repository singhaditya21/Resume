from typing import Any, Dict, List, Optional

from app.config.settings import get_settings
from app.services.generator import generate_answer
from app.services.reranker import rerank
from app.services.retriever import retrieve
from llm.chains.rag_chain import build_prompt
from utils.tracing import set_span_attrs, start_span


def ask_chatbot(
    question: str,
    limit: int = 5,
    collection: Optional[str] = None,
    history: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    settings = get_settings()
    with start_span("rag.ask_chatbot") as span:
        set_span_attrs(
            span,
            {
                "openinference.span.kind": "CHAIN",
                "input.value": question[:1000],
                "rag.limit": limit,
                "rag.collection": collection or settings.milvus_collection,
            },
        )
        chunks = rerank(retrieve(question, limit, collection, include_text=True))
        answer = generate_answer(build_prompt(question, chunks, history))
        set_span_attrs(span, {"rag.source_count": len(chunks), "output.value": answer[:4000]})
        return {
            "success": True,
            "answer": answer,
            "sources": [
                {
                    "document_id": chunk.get("document_id"),
                    "file_name": chunk.get("file_name"),
                    "file_path": chunk.get("file_path"),
                    "score": chunk.get("score"),
                    "text_preview": chunk.get("text_preview"),
                }
                for chunk in chunks
            ],
        }
