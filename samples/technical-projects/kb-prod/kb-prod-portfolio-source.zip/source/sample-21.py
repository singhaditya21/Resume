from fastapi import APIRouter, Request

from app.config.settings import get_settings
from app.services.health import health_status
from utils.helpers import get_server_ip

router = APIRouter()


@router.get("/health")
def health(request: Request):
    return health_status(request.app.state.phoenix_status)


@router.get("/server-info")
def server_info(request: Request):
    settings = get_settings()
    host = request.headers.get("host", "")
    scheme = request.headers.get("x-forwarded-proto", request.url.scheme)
    return {
        "success": True,
        "bind_host": settings.host,
        "configured_port": settings.port,
        "server_ip": get_server_ip(settings.public_host),
        "current_url": f"{scheme}://{host}",
        "ui_path": "/ui",
        "webhook_chat_path": "/webhook/chat",
        "phoenix": request.app.state.phoenix_status,
    }
