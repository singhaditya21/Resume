import asyncio
import logging

import httpx

from config import REDASH_BASE_URL

logger = logging.getLogger("coe_dashboard.redash_client")

JOB_SUCCESS = 3
JOB_FAILED = 4
POLL_ATTEMPTS = 12
POLL_INTERVAL_SECONDS = 1.5


class RedashAuthError(Exception):
    """Raised when a Redash API key is missing or rejected."""


class RedashError(Exception):
    """Raised for any other Redash failure (query error, timeout, bad response)."""


def _check_auth(resp: httpx.Response, query_id: str):
    if resp.status_code in (401, 403):
        raise RedashAuthError(f"Invalid Redash API key for query {query_id} — check .env")


async def fetch_query_rows(client: httpx.AsyncClient, query_id: str, api_key: str) -> list[dict]:
    """Fetch a Redash query's result rows.

    Tries the cached results endpoint first (fast, no re-execution). If no cached
    result exists yet, triggers a fresh run and polls the job until it completes.
    """
    if not api_key:
        raise RedashAuthError(f"Missing Redash API key for query {query_id} — check .env")

    results_url = f"{REDASH_BASE_URL}/api/queries/{query_id}/results.json"
    resp = await client.get(results_url, params={"api_key": api_key})
    _check_auth(resp, query_id)
    if resp.status_code == 200:
        rows = resp.json().get("query_result", {}).get("data", {}).get("rows")
        if rows is not None:
            return rows

    # No cached result yet — trigger a fresh run and poll for it.
    refresh_url = f"{REDASH_BASE_URL}/api/queries/{query_id}/refresh"
    refresh_resp = await client.post(refresh_url, params={"api_key": api_key})
    _check_auth(refresh_resp, query_id)
    refresh_resp.raise_for_status()
    job_id = refresh_resp.json().get("job", {}).get("id")
    if not job_id:
        raise RedashError(f"Redash did not return a job id for query {query_id}")

    job_url = f"{REDASH_BASE_URL}/api/jobs/{job_id}"
    for _ in range(POLL_ATTEMPTS):
        await asyncio.sleep(POLL_INTERVAL_SECONDS)
        job_resp = await client.get(job_url, params={"api_key": api_key})
        _check_auth(job_resp, query_id)
        job_resp.raise_for_status()
        job = job_resp.json().get("job", {})
        status = job.get("status")
        if status == JOB_SUCCESS:
            result_id = job.get("query_result_id")
            result_resp = await client.get(
                f"{REDASH_BASE_URL}/api/query_results/{result_id}.json",
                params={"api_key": api_key},
            )
            _check_auth(result_resp, query_id)
            result_resp.raise_for_status()
            return result_resp.json().get("query_result", {}).get("data", {}).get("rows", [])
        if status == JOB_FAILED:
            raise RedashError(f"Redash query {query_id} failed: {job.get('error')}")

    raise RedashError(f"Timed out waiting for Redash query {query_id} to finish")


async def fetch_all_portal_rows(queries: dict) -> dict:
    """Fetch multiple named Redash queries concurrently, independently.

    `queries` maps a label (e.g. "production_tickets") to (query_id, api_key).
    Returns {label: {"rows": [...], "error": None}} on success, or
    {label: {"rows": [], "error": "<message>"}} if that particular query failed —
    one bad/missing key degrades only its own column, not the whole portal.
    """
    async with httpx.AsyncClient(timeout=30.0) as client:
        labels = list(queries.keys())
        results = await asyncio.gather(
            *[fetch_query_rows(client, query_id, api_key) for query_id, api_key in queries.values()],
            return_exceptions=True,
        )
    out = {}
    for label, result in zip(labels, results):
        if isinstance(result, Exception):
            logger.error("Redash fetch failed for %s: %s", label, result)
            out[label] = {"rows": [], "error": str(result)}
        else:
            out[label] = {"rows": result, "error": None}
    return out
