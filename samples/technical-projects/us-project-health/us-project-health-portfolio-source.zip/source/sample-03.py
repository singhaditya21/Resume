import base64
import logging

import httpx

from config import AZURE_ORG, AZURE_PAT

logger = logging.getLogger("coe_dashboard.azure_client")

API_VERSION = "7.1"
BASE_URL = f"https://example.invalid}"
BATCH_SIZE = 190  # keep GET URLs well under server limits


class AzureAuthError(Exception):
    """Raised when the PAT is missing or rejected (401)."""


class ProjectNotFoundError(Exception):
    """Raised when Azure DevOps returns 404 for a project."""


def _auth_headers():
    token = REDACTED_SECRET
    return {"Authorization": f"Basic {token}", "Content-Type": "application/json"}


def _raise_for_status(resp: httpx.Response, project_name: str):
    if resp.status_code == 401 or resp.is_redirect:
        # Azure DevOps redirects to a sign-in page (302) instead of a clean 401
        # when the PAT is missing, malformed, or lacks org access.
        raise AzureAuthError("Invalid PAT token — check .env")
    if resp.status_code == 404:
        raise ProjectNotFoundError(project_name)
    resp.raise_for_status()


async def run_wiql(client: httpx.AsyncClient, project_name: str, wiql: str) -> list[int]:
    url = f"{BASE_URL}/{project_name}/_apis/wit/wiql?api-version={API_VERSION}"
    resp = await client.post(url, headers=_auth_headers(), json={"query": wiql})
    _raise_for_status(resp, project_name)
    data = resp.json()
    return [item["id"] for item in data.get("workItems", [])]


async def get_work_items(client: httpx.AsyncClient, project_name: str, ids: list[int], fields: str) -> list[dict]:
    if not ids:
        return []
    results = []
    for i in range(0, len(ids), BATCH_SIZE):
        chunk = ids[i : i + BATCH_SIZE]
        id_list = ",".join(str(i) for i in chunk)
        url = (
            f"{BASE_URL}/_apis/wit/workitems"
            f"?ids={id_list}&fields={fields}&api-version={API_VERSION}"
        )
        resp = await client.get(url, headers=_auth_headers())
        _raise_for_status(resp, project_name)
        data = resp.json()
        results.extend(data.get("value", []))
    return results


def _field(item: dict, name: str, default=None):
    return item.get("fields", {}).get(name, default)


EPIC_WIQL = """
SELECT [System.Id], [System.Title], [System.State],
       [Microsoft.VSTS.Scheduling.TargetDate],
       [Custom.SADate], [Custom.CompletionDate],
       [System.CreatedDate]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] = 'Epic'
AND [System.State] NOT IN ('Closed', 'Done', 'Removed')
ORDER BY [System.Id] ASC
"""
EPIC_FIELDS = (
    "System.Id,System.Title,System.State,Microsoft.VSTS.Scheduling.TargetDate,"
    "Custom.SADate,Custom.CompletionDate,System.CreatedDate"
)

# Excludes every resolved/terminal/paused Bug state — confirmed against the
# canonical state list for the "Bug" work item type (which varies slightly by
# project's process template customization; this covers the union of all
# variants seen: On Hold, Deferred, FRTT, SA Passed (+ in UAT/ACC/Co-dev),
# Invalid, Not a Bug, Removed, Closed, Duplicate, To Do, UAT – Cycle 2 Passed
# (note: en dash, not a hyphen — confirmed via the process template).
INTERNAL_QUALITY_WIQL = """
SELECT [System.Id], [System.Title], [System.State],
       [Microsoft.VSTS.Common.Severity],
       [Custom.Module], [System.AssignedTo], [System.ChangedDate]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] = 'Bug'
AND [Custom.Origin] = 'Internal'
AND [Microsoft.VSTS.Common.Severity] IN ('Critical', 'Showstopper')
AND [System.State] NOT IN (
    'Closed', 'Done', 'Removed', 'Not a Bug', 'Deferred', 'On Hold', 'FRTT',
    'SA Passed in UAT', 'SA Passed in ACC', 'Invalid', 'Duplicate', 'To Do',
    'SA Passed', 'SA Passed in Co-dev', 'UAT – Cycle 2 Passed'
)
ORDER BY [System.Id] DESC
"""
INTERNAL_QUALITY_FIELDS = (
    "System.Id,System.Title,System.State,Microsoft.VSTS.Common.Severity,"
    "Custom.Module,System.AssignedTo"
)

# All non-removed Tasks (not just stale ones): used to derive Stale (14+ days no
# activity) and Overdue (Custom.CompletionDate passed, not closed) counts, plus the
# Task-completion% and date-rollup inputs for the Schedule Variance calculation —
# see rag_engine.score_schedule_variance. Custom.SADate/CompletionDate are ~95-100%
# populated at Task level in this org, vs 0% on Epics, which is why the rollup
# starts here instead of at the Epic.
ALL_TASKS_WIQL = """
SELECT [System.Id], [System.Title], [System.State],
       [System.AssignedTo], [System.ChangedDate], [System.Parent],
       [Microsoft.VSTS.Scheduling.RemainingWork],
       [Microsoft.VSTS.Scheduling.OriginalEstimate],
       [Microsoft.VSTS.Scheduling.CompletedWork],
       [Custom.SADate], [Custom.CompletionDate]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] = 'Task'
AND [System.State] NOT IN ('Removed')
ORDER BY [System.ChangedDate] ASC
"""
ALL_TASKS_FIELDS = (
    "System.Id,System.Title,System.State,System.AssignedTo,System.ChangedDate,"
    "System.Parent,Microsoft.VSTS.Scheduling.RemainingWork,"
    "Microsoft.VSTS.Scheduling.OriginalEstimate,Microsoft.VSTS.Scheduling.CompletedWork,"
    "Custom.SADate,Custom.CompletionDate"
)

# Lightweight fetches used only to resolve a Task's Feature ancestor (Task -> PBI ->
# Feature — Tasks are never parented directly under a Feature in this org) so the
# Stale count can exclude tasks under the "Project Governance" feature.
FEATURES_WIQL = """
SELECT [System.Id], [System.Title]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] = 'Feature'
AND [System.State] NOT IN ('Removed')
"""
FEATURES_FIELDS = "System.Id,System.Title"

PBIS_WIQL = """
SELECT [System.Id], [System.Parent]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] IN ('Product Backlog Item', 'User Story')
AND [System.State] NOT IN ('Removed')
"""
PBIS_FIELDS = "System.Id,System.Parent"

ALL_OPEN_BUGS_WIQL = """
SELECT [System.Id], [System.Title], [System.State],
       [Microsoft.VSTS.Common.Severity],
       [Microsoft.VSTS.Common.Priority],
       [System.AssignedTo], [System.CreatedDate],
       [System.ChangedDate], [Custom.Origin]
FROM WorkItems
WHERE [System.TeamProject] = '{project}'
AND [System.WorkItemType] = 'Bug'
AND [System.State] NOT IN ('Closed', 'Done', 'Removed', 'Not a Bug')
ORDER BY [System.CreatedDate] ASC
"""
ALL_OPEN_BUGS_FIELDS = (
    "System.Id,System.Title,System.State,Microsoft.VSTS.Common.Severity,"
    "Microsoft.VSTS.Common.Priority,System.AssignedTo,System.CreatedDate,"
    "System.ChangedDate,Custom.Origin"
)


async def fetch_epics(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = EPIC_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, EPIC_FIELDS)


async def fetch_internal_quality_bugs(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = INTERNAL_QUALITY_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, INTERNAL_QUALITY_FIELDS)


async def fetch_all_tasks(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = ALL_TASKS_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, ALL_TASKS_FIELDS)


async def fetch_all_open_bugs(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = ALL_OPEN_BUGS_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, ALL_OPEN_BUGS_FIELDS)


async def fetch_features(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = FEATURES_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, FEATURES_FIELDS)


async def fetch_pbis(client: httpx.AsyncClient, project_name: str) -> list[dict]:
    wiql = PBIS_WIQL.format(project=project_name)
    ids = await run_wiql(client, project_name, wiql)
    return await get_work_items(client, project_name, ids, PBIS_FIELDS)


async def fetch_project_raw_data(project: dict) -> dict:
    """Fetch all raw Azure DevOps data for one project.

    Returns a dict with keys: epics, internal_quality_bugs, all_tasks,
    all_open_bugs, features, pbis, and error (None on success).
    On AzureAuthError this re-raises so the caller can surface a 401.
    On ProjectNotFoundError or any other failure, returns a partial
    result with an "error" key set and empty lists for the rest.
    """
    # "azure_project" overrides "name" for dynamically-discovered My Portal
    # accounts whose Azure DevOps Team Project is spelled differently — see
    # config.AZURE_PROJECT_ALIASES.
    project_name = project.get("azure_project") or project["name"]
    empty = {
        "epics": [],
        "internal_quality_bugs": [],
        "all_tasks": [],
        "all_open_bugs": [],
        "features": [],
        "pbis": [],
    }
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            epics = await fetch_epics(client, project_name)
            internal_quality_bugs = await fetch_internal_quality_bugs(client, project_name)
            all_tasks = await fetch_all_tasks(client, project_name)
            all_open_bugs = await fetch_all_open_bugs(client, project_name)
            features = await fetch_features(client, project_name)
            pbis = await fetch_pbis(client, project_name)
            return {
                "epics": epics,
                "internal_quality_bugs": internal_quality_bugs,
                "all_tasks": all_tasks,
                "all_open_bugs": all_open_bugs,
                "features": features,
                "pbis": pbis,
                "error": None,
            }
        except AzureAuthError:
            raise
        except ProjectNotFoundError:
            logger.error("Project not found in Azure DevOps: %s", project_name)
            return {**empty, "error": "project_not_found"}
        except Exception as exc:  # noqa: BLE001 — surface partial data, never 500
            logger.exception("Failed fetching Azure data for %s: %s", project_name, exc)
            return {**empty, "error": str(exc)}
