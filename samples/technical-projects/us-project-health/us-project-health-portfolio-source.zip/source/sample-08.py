import time


class TTLCache:
    def __init__(self):
        self._store = {}

    def get(self, key):
        if key in self._store:
            value, expires_at = self._store[key]
            if time.time() < expires_at:
                return value
            del self._store[key]
        return None

    def set(self, key, value, ttl_seconds=300):
        self._store[key] = (value, time.time() + ttl_seconds)

    def clear(self, key):
        self._store.pop(key, None)
