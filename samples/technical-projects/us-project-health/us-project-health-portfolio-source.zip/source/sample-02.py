"""RAG scoring logic. Weights are locked:
Schedule 10% + Task Delay 20% + Overdue 20% + Quality 30% + Risk 20%."""

SCHEDULE_WEIGHT = 0.10
TASK_DELAY_WEIGHT = 0.20
OVERDUE_WEIGHT = 0.20
QUALITY_WEIGHT = 0.30
RISK_WEIGHT = 0.20

RAG_LABELS = {1: "GREEN", 2: "AMBER", 3: "RED"}
RAG_CLASSES = {1: "green", 2: "amber", 3: "red"}


def score_schedule(epic_target_date, today):
    """Legacy Schedule signal: today vs a single Epic Target Date field.
    Returns (score, delay_days, label). Kept alongside score_schedule_variance
    per product decision — Target Date is rarely populated in this org (0/8
    tracked Epics have it set), so this mostly returns the neutral default;
    it's shown for whichever projects do set it, not used to drive the RAG score."""
    if epic_target_date is None:
        return (1, None, "Target Date not set")
    delay = (today - epic_target_date).days
    if delay <= 5:
        label = f"{-delay}d ahead of schedule" if delay < 0 else f"On time (+{delay}d)"
        return (1, delay, label)
    if delay <= 15:
        return (2, delay, f"{delay}d delayed")
    return (3, delay, f"{delay}d delayed — CRITICAL")


def score_schedule_variance(completion_by_tasks, completion_by_schedule):
    """Schedule Variance signal (adapted from the N8N project-health flow):
    variance = % of tasks closed − % of calendar time elapsed between the
    earliest Task Custom.SADate and latest Task Custom.CompletionDate.
    Negative means behind pace, positive means ahead. Returns (score, variance, label).
    Drives the Schedule pillar of the weighted RAG score when computable —
    Task-level dates are ~95-100% populated in this org, vs ~0% at Epic level."""
    variance = completion_by_tasks - completion_by_schedule
    if variance <= -20:
        return (3, variance, f"{abs(variance)}% behind schedule — CRITICAL")
    if variance <= -10:
        return (2, variance, f"{abs(variance)}% behind schedule")
    if variance >= 0:
        return (1, variance, f"{variance}% ahead of schedule")
    return (1, variance, f"Within tolerance ({abs(variance)}% behind)")


def score_task_delay(stale_count):
    """Returns (score, label). 0-5 stale tasks is healthy, 6-15 is a watch-list,
    16+ signals a real bottleneck."""
    if stale_count <= 5:
        return (1, f"{stale_count} stale (GREEN)")
    if stale_count <= 15:
        return (2, f"{stale_count} stale (AMBER)")
    return (3, f"{stale_count} stale (RED)")


def score_overdue(overdue_count):
    """Returns (score, label). Same bucket thresholds as score_task_delay —
    kept as a separate function since Overdue is a distinct weighted component."""
    if overdue_count <= 5:
        return (1, f"{overdue_count} overdue (GREEN)")
    if overdue_count <= 15:
        return (2, f"{overdue_count} overdue (AMBER)")
    return (3, f"{overdue_count} overdue (RED)")


def score_quality(critical_count, showstopper_count):
    """Returns (score, label)."""
    total = critical_count + showstopper_count
    if total < 3:
        return (1, f"{total} open (GREEN)")
    if total <= 10:
        return (2, f"{total} open (AMBER)")
    return (3, f"{total} open (RED)")


def score_risk(high_risk_count=0, medium_risk_count=0):
    """Placeholder until My Portal connected. Returns (score, label)."""
    if high_risk_count == 0:
        return (1, "0 high risks")
    if high_risk_count <= 2 and medium_risk_count <= 3:
        return (2, f"{high_risk_count} high, {medium_risk_count} medium risks")
    return (3, f"{high_risk_count} high risks — RED")


def calculate_rag(schedule_score, task_delay_score, overdue_score, quality_score, risk_score):
    """Returns (rag_label, weighted_score, css_class)."""
    weighted = (
        (schedule_score * SCHEDULE_WEIGHT)
        + (task_delay_score * TASK_DELAY_WEIGHT)
        + (overdue_score * OVERDUE_WEIGHT)
        + (quality_score * QUALITY_WEIGHT)
        + (risk_score * RISK_WEIGHT)
    )
    weighted = round(weighted, 2)
    if weighted <= 1.4:
        return ("GREEN", weighted, "green")
    if weighted <= 2.0:
        return ("AMBER", weighted, "amber")
    return ("RED", weighted, "red")
