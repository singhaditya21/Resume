"""DNS fallback for hosts whose system resolver is broken.

The deployment server (192.0.2.10) has systemd-resolved pointed at public
DNS servers (192.0.2.10 / 192.0.2.10) that its firewall blocks, so every hostname
lookup fails there — while the internal resolver at 192.0.2.10 answers
fine. Fixing that system-wide needs root; this module instead patches
socket.getaddrinfo to retry failed lookups against the internal resolver.
On machines whose normal DNS works (e.g. local dev), the patch never fires.
"""

import logging
import socket

logger = logging.getLogger("coe_dashboard.dns_fallback")

FALLBACK_NAMESERVERS = ["192.0.2.10"]

_orig_getaddrinfo = socket.getaddrinfo


def _fallback_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    try:
        return _orig_getaddrinfo(host, port, family, type, proto, flags)
    except socket.gaierror:
        try:
            import dns.resolver
        except ImportError:
            raise  # dnspython not installed — behave exactly as before
        resolver = dns.resolver.Resolver(configure=False)
        resolver.nameservers = FALLBACK_NAMESERVERS
        resolver.lifetime = 5
        name = host.decode() if isinstance(host, bytes) else str(host)
        try:
            ip = resolver.resolve(name, "A")[0].address
        except Exception as exc:
            logger.warning("Fallback DNS lookup failed for %s: %s", host, exc)
            raise socket.gaierror(socket.EAI_NONAME, f"fallback resolution failed for {host}") from exc
        return _orig_getaddrinfo(ip, port, family, type, proto, flags)


socket.getaddrinfo = _fallback_getaddrinfo
