import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone

import dns_fallback  # noqa: F401 — patches socket.getaddrinfo; must import before any HTTP client use

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates

import azure_client
import portal_data
import project_report
import redash_client
from azure_client import AzureAuthError, ProjectNotFoundError
from cache import TTLCache
from config import (
    ACCOUNT_PM_OVERRIDES,
    AZURE_PROJECT_ALIASES,
    CACHE_TTL_SECONDS,
    PROJECTS,
    REDASH_PRODUCT_BUGS_API_KEY,
    REDASH_PRODUCT_BUGS_QUERY_ID,
    REDASH_PRODUCTION_TICKETS_API_KEY,
    REDASH_PRODUCTION_TICKETS_QUERY_ID,
    REDASH_PROJECT_DATA_API_KEY,
    REDASH_PROJECT_DATA_QUERY_ID,
    REDASH_RISKS_API_KEY,
    REDASH_RISKS_QUERY_ID,
)
from rag_engine import (
    calculate_rag,
    score_overdue,
    score_quality,
    score_risk,
    score_schedule,
    score_schedule_variance,
    score_task_delay,
)

# Azure DevOps custom date fields (Custom.SADate, Custom.CompletionDate, Epic
# Target Date) are entered as calendar dates but stored as UTC timestamps at
# IST midnight (e.g. "2026-07-09T18:30:00Z" = 2026-07-10 00:00 IST) — the same
# convention the org's own Redash SQL uses (`+ INTERVAL '330 minutes'`). Naively
# truncating the raw UTC timestamp to a date is off by a day near midnight IST,
# which is exactly why a task due "today" could wrongly show as overdue.
IST_OFFSET = timedelta(minutes=330)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("coe_dashboard")

app = FastAPI(title="US Project Health Dashboard")

templates = Jinja2Templates(directory="templates")
templates.env.filters["tojson"] = lambda obj, indent=None: json.dumps(obj, default=str, indent=indent)

cache = TTLCache()
CACHE_KEY = "dashboard_data"

report_cache = TTLCache()
REPORT_CACHE_TTL_SECONDS = 300

REDASH_QUERIES = {
    "production_tickets": (REDASH_PRODUCTION_TICKETS_QUERY_ID, REDASH_PRODUCTION_TICKETS_API_KEY),
    "risks": (REDASH_RISKS_QUERY_ID, REDASH_RISKS_API_KEY),
    "product_bugs": (REDASH_PRODUCT_BUGS_QUERY_ID, REDASH_PRODUCT_BUGS_API_KEY),
    "project_data": (REDASH_PROJECT_DATA_QUERY_ID, REDASH_PROJECT_DATA_API_KEY),
}

_PHASE_CLASS_KEYWORDS = (
    ("uat", "phase-uat"),
    ("sit", "phase-uat"),
    ("dev", "phase-dev"),
    ("requirement", "phase-dev"),
    ("draft", "phase-dev"),
    ("pre-engagement", "phase-dev"),
    ("closed", "phase-prod"),
    ("warranty", "phase-prod"),
    ("live", "phase-prod"),
)


def _phase_class_for_status(status: str) -> str:
    s = (status or "").strip().lower()
    for keyword, css_class in _PHASE_CLASS_KEYWORDS:
        if keyword in s:
            return css_class
    return "phase-unknown"


def _best_effort_epic_match(project_name, epic_titles):
    """Azure Epic titles and My Portal project names are named independently
    (spot-checked across 4 accounts: e.g. SESLOC's 2 Azure epics share no real
    overlap with its 7 My Portal projects) — this is a low-confidence substring
    match shown for reference only, never used to scope Azure metrics to a
    project row, since a wrong silent match would be worse than no match."""
    pn = (project_name or "").strip().lower()
    if not pn:
        return None
    for title in epic_titles:
        t = (title or "").strip().lower()
        if t and (t in pn or pn in t):
            return title
    return None


EMPTY_PRODUCTION_TICKETS = {
    "note": "Pending My Portal integration",
    "buckets": portal_data.BUCKETS,
    "accounts": [],
    "totals": {},
    "escalation_count": 0,
}

EMPTY_DASHBOARD_DATA = {
    "last_refreshed": None,
    "cached": False,
    "projects": [],
    "kpis": {"on_track": 0, "at_risk": 0, "critical": 0, "total_critical_bugs": 0},
    "production_tickets": EMPTY_PRODUCTION_TICKETS,
}


def _field(item: dict, name: str, default=None):
    return item.get("fields", {}).get(name, default)


def _parse_date(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return (dt + IST_OFFSET).date()


def _today_ist():
    return (datetime.now(timezone.utc) + IST_OFFSET).date()


def _assignee_name(item: dict) -> str:
    assigned = _field(item, "System.AssignedTo")
    if isinstance(assigned, dict):
        return assigned.get("displayName", "Unassigned")
    return "Unassigned"


# Titles containing these are treated as bug-fix work, not feature delivery —
# excluded from the Task-completion% used in the Schedule Variance calc, matching
# the N8N flow's "nonBugTasks" filter (bug-fix throughput isn't a schedule signal).
_BUGFIX_TITLE_KEYWORDS = ("bug", "defect", "hotfix")


def _is_bugfix_titled(title: str) -> bool:
    t = (title or "").lower()
    return any(k in t for k in _BUGFIX_TITLE_KEYWORDS)


_STALE_EXCLUDED_FEATURES = ("project governance",)


def _build_feature_resolver(features: list, pbis: list):
    """Tasks are parented under a PBI, never directly under a Feature, in this
    org (confirmed: Feature -> PBI -> Task). Returns a function that walks a
    Task's System.Parent (a PBI id) up to its owning Feature's title."""
    feature_titles = {_field(f, "System.Id"): _field(f, "System.Title", "") for f in features}
    pbi_parent = {_field(p, "System.Id"): _field(p, "System.Parent") for p in pbis}

    def resolve(parent_id):
        if parent_id is None:
            return None
        if parent_id in feature_titles:
            return feature_titles[parent_id]
        return feature_titles.get(pbi_parent.get(parent_id))

    return resolve


def _build_task_metrics(all_tasks: list, features: list, pbis: list, today) -> dict:
    """Derives Stale / Overdue task lists and the Task-completion% + calendar-span
    inputs for Schedule Variance, all from one broad Task fetch (all_tasks —
    every non-removed Task, fields include Custom.SADate/CompletionDate which are
    ~95-100% populated at Task level vs ~0% at Epic level in this org).

    Stale = no activity 14+ days, not under Project Governance, AND not due in
    the future (a quiet task that isn't due yet isn't actually a problem).
    Overdue = Completion Date has passed and the task isn't closed."""
    resolve_feature = _build_feature_resolver(features, pbis)
    stale_items = []
    overdue_items = []
    non_bug_total = 0
    non_bug_closed = 0
    sa_dates = []
    completion_dates = []

    for t in all_tasks:
        title = _field(t, "System.Title", "")
        state = _field(t, "System.State", "")
        is_closed = state in ("Done", "Closed")
        changed = _parse_date(_field(t, "System.ChangedDate"))
        sa_date = _parse_date(_field(t, "Custom.SADate"))
        completion_date = _parse_date(_field(t, "Custom.CompletionDate"))
        feature_title = resolve_feature(_field(t, "System.Parent"))
        under_excluded_feature = (feature_title or "").strip().lower() in _STALE_EXCLUDED_FEATURES

        if sa_date:
            sa_dates.append(sa_date)
        if completion_date:
            completion_dates.append(completion_date)

        if not _is_bugfix_titled(title):
            non_bug_total += 1
            if is_closed:
                non_bug_closed += 1

        not_future_dated = completion_date is None or completion_date <= today
        if not is_closed:
            if changed and (today - changed).days >= 14 and not under_excluded_feature and not_future_dated:
                stale_items.append(
                    {
                        "id": _field(t, "System.Id"),
                        "title": title,
                        "owner": _assignee_name(t),
                        "days_stale": (today - changed).days,
                        "remaining_hrs": _field(t, "Microsoft.VSTS.Scheduling.RemainingWork"),
                    }
                )
            if completion_date and completion_date < today:
                overdue_items.append(
                    {
                        "id": _field(t, "System.Id"),
                        "title": title,
                        "owner": _assignee_name(t),
                        "days_overdue": (today - completion_date).days,
                        "due_date": completion_date.isoformat(),
                        "remaining_hrs": _field(t, "Microsoft.VSTS.Scheduling.RemainingWork"),
                    }
                )

    stale_items.sort(key=lambda x: -x["days_stale"])
    overdue_items.sort(key=lambda x: -x["days_overdue"])

    completion_by_tasks = round(non_bug_closed / non_bug_total * 100) if non_bug_total else None

    schedule_start = min(sa_dates) if sa_dates else None
    schedule_end = max(completion_dates) if completion_dates else None
    completion_by_schedule = None
    if schedule_start and schedule_end and schedule_end > schedule_start:
        span_days = (schedule_end - schedule_start).days
        elapsed_days = (today - schedule_start).days
        completion_by_schedule = round(min(max(elapsed_days / span_days, 0), 1) * 100)

    return {
        "stale_items": stale_items,
        "overdue_items": overdue_items,
        "completion_by_tasks": completion_by_tasks,
        "completion_by_schedule": completion_by_schedule,
        "schedule_start": schedule_start,
        "schedule_end": schedule_end,
    }


def _build_portal_summary(
    matched_accounts: list, groups: dict, risks_error, bugs_error, project_data_error
) -> dict:
    risk_rows = [r for acct in matched_accounts for r in groups["risks_by_account"].get(acct, [])]
    uat_rows = [r for acct in matched_accounts for r in groups["uat_by_account"].get(acct, [])]
    product_rows = [r for acct in matched_accounts for r in groups["product_by_account"].get(acct, [])]
    project_data_rows = [r for acct in matched_accounts for r in groups["project_data_by_account"].get(acct, [])]

    if risks_error:
        risks_out = {"status": "error", "message": risks_error, "source": "My Portal"}
    else:
        risks_out = {"status": "ok", "source": "My Portal", **portal_data.summarize_risks(risk_rows)}

    if bugs_error:
        uat_out = {"status": "error", "message": bugs_error, "source": "My Portal"}
        product_out = {"status": "error", "message": bugs_error, "source": "My Portal"}
    else:
        uat_out = {"status": "ok", "source": "My Portal", **portal_data.summarize_bugs(uat_rows)}
        product_out = {"status": "ok", "source": "My Portal", **portal_data.summarize_bugs(product_rows)}

    if project_data_error or not project_data_rows:
        project_summary = {
            "projects": [],
            "pm_rag": None,
            "phase": None,
            "ind_pm": None,
            "us_pm": None,
            "core_system": None,
            "showing_inactive_fallback": False,
        }
    else:
        project_summary = portal_data.summarize_account_projects(project_data_rows)

    # Attach per-project UAT bugs / Risks / Product bugs to each visible drawer
    # row, matched by normalized project name (the only key these 3 queries
    # share with the project-data query — none carry a shared project id).
    for vp in project_summary["projects"]:
        key = portal_data.normalize(vp["project_name"])
        p_risk_rows = groups["risks_by_project"].get(key, [])
        p_uat_rows = groups["uat_by_project"].get(key, [])
        p_product_rows = groups["product_by_project"].get(key, [])
        vp["risks"] = (
            {"status": "error", "message": risks_error, "source": "My Portal"}
            if risks_error
            else {"status": "ok", "source": "My Portal", **portal_data.summarize_risks(p_risk_rows)}
        )
        vp["uat_bugs"] = (
            {"status": "error", "message": bugs_error, "source": "My Portal"}
            if bugs_error
            else {"status": "ok", "source": "My Portal", **portal_data.summarize_bugs(p_uat_rows)}
        )
        vp["product_bugs"] = (
            {"status": "error", "message": bugs_error, "source": "My Portal"}
            if bugs_error
            else {"status": "ok", "source": "My Portal", **portal_data.summarize_bugs(p_product_rows)}
        )

    return {
        "uat_bugs": uat_out,
        "risks": risks_out,
        "product_bugs": product_out,
        "connected": (risks_error is None) or (bugs_error is None),
        "risk_high": risks_out.get("high", 0),
        "risk_medium": risks_out.get("medium", 0),
        "project_data_error": project_data_error,
        "my_portal_projects": project_summary["projects"],
        "pm_rag_override": project_summary["pm_rag"] if project_data_rows and not project_data_error else None,
        "phase_override": project_summary["phase"],
        "core_system": project_summary["core_system"],
        "ind_pm": project_summary["ind_pm"],
        "us_pm": project_summary["us_pm"],
        "REDACTED_OPAQUE_VALUE": project_summary["showing_inactive_fallback"],
    }


def _build_project_result(project: dict, raw: dict, today, portal: dict) -> dict:
    epics = raw["epics"]
    target_dates = [
        d
        for d in (
            _parse_date(_field(e, "Microsoft.VSTS.Scheduling.TargetDate")) for e in epics
        )
        if d is not None
    ]
    epic_target_date = min(target_dates) if target_dates else None
    target_date_score, target_date_delay, target_date_label = score_schedule(epic_target_date, today)

    task_metrics = _build_task_metrics(raw["all_tasks"], raw["features"], raw["pbis"], today)
    variance_has_data = (
        task_metrics["completion_by_tasks"] is not None and task_metrics["completion_by_schedule"] is not None
    )
    if variance_has_data:
        variance_score, variance_pct, variance_label = score_schedule_variance(
            task_metrics["completion_by_tasks"], task_metrics["completion_by_schedule"]
        )
    else:
        variance_score, variance_pct, variance_label = (1, None, "Not enough task date data")

    # Schedule Variance drives the weighted RAG when computable (Task-level dates
    # are ~95-100% populated here); Target Date is shown alongside for reference
    # but falls back to driving the score only when variance can't be computed.
    schedule_score = variance_score if variance_has_data else target_date_score
    schedule_label = variance_label if variance_has_data else target_date_label

    task_delay_score, task_delay_label = score_task_delay(len(task_metrics["stale_items"]))
    overdue_score, overdue_label = score_overdue(len(task_metrics["overdue_items"]))

    quality_bugs = raw["internal_quality_bugs"]
    critical_count = sum(
        1 for b in quality_bugs if _field(b, "Microsoft.VSTS.Common.Severity") == "Critical"
    )
    showstopper_count = sum(
        1 for b in quality_bugs if _field(b, "Microsoft.VSTS.Common.Severity") == "Showstopper"
    )
    quality_score, quality_label = score_quality(critical_count, showstopper_count)

    risk_score, risk_label = score_risk(portal["risk_high"], portal["risk_medium"])

    rag_label, weighted_score, rag_class = calculate_rag(
        schedule_score, task_delay_score, overdue_score, quality_score, risk_score
    )

    by_module = {}
    for b in quality_bugs:
        module = _field(b, "Custom.Module") or "Unspecified"
        sev = _field(b, "Microsoft.VSTS.Common.Severity")
        entry = by_module.setdefault(
            module, {"module": module, "showstopper": 0, "critical": 0, "total": 0}
        )
        if sev == "Showstopper":
            entry["showstopper"] += 1
        elif sev == "Critical":
            entry["critical"] += 1
        entry["total"] += 1
    by_module_list = sorted(by_module.values(), key=lambda x: -x["total"])

    quality_items = [
        {
            "id": _field(b, "System.Id"),
            "title": _field(b, "System.Title", ""),
            "module": _field(b, "Custom.Module") or "Unspecified",
            "severity": _field(b, "Microsoft.VSTS.Common.Severity"),
            "owner": _assignee_name(b),
        }
        for b in quality_bugs
    ]
    quality_items.sort(key=lambda x: 0 if x["severity"] == "Showstopper" else 1)

    all_open_bugs = raw["all_open_bugs"]
    severity_populated = (
        all(_field(b, "Microsoft.VSTS.Common.Severity") for b in all_open_bugs)
        if all_open_bugs
        else True
    )

    # Phase / PM / PM RAG now come from the My Portal project-level query when
    # available (item 6/7/4) — config.PROJECTS values are only a fallback for
    # accounts with no rows there at all.
    if portal["phase_override"]:
        phase = portal["phase_override"]
        phase_class = _phase_class_for_status(phase)
    else:
        phase = project["phase"]
        phase_class = project["phase_class"]

    pm_name = portal["ind_pm"] or project["pm"]

    epic_titles = [_field(e, "System.Title", "") for e in epics]
    my_portal_projects = [
        {**p, "matched_epic": _best_effort_epic_match(p["project_name"], epic_titles)}
        for p in portal["my_portal_projects"]
    ]
    # us_project_type isn't in the Redash query yet (My Portal field pending) —
    # this stays an empty list until it starts showing up in the data, at which
    # point the "US Project Type" filter activates with no further code change.
    us_project_types = sorted({p["us_project_type"] for p in my_portal_projects if p.get("us_project_type")})

    if portal["pm_rag_override"]:
        pm_rag_label = portal["pm_rag_override"]
        pm_rag_class = pm_rag_label.lower()
    else:
        pm_rag_label = rag_label
        pm_rag_class = rag_class

    tooltip = (
        f"Schedule (10%): {schedule_label} → {schedule_score}\n"
        f"Task Delay (20%): {task_delay_label} → {task_delay_score}\n"
        f"Overdue (20%): {overdue_label} → {overdue_score}\n"
        f"Quality (30%): {quality_label} → {quality_score}\n"
        f"Risk (20%): {risk_label} → {risk_score}\n"
        f"───────────────\n"
        f"({schedule_score}×0.10)+({task_delay_score}×0.20)+({overdue_score}×0.20)"
        f"+({quality_score}×0.30)+({risk_score}×0.20) = {weighted_score}"
    )

    return {
        "name": project["name"],
        "short": project["short"],
        "azure_project_name": project.get("azure_project") or project["name"],
        "pm": pm_name,
        "ind_pm": portal["ind_pm"],
        "us_pm": portal["us_pm"],
        "phase": phase,
        "phase_class": phase_class,
        "calc_rag": rag_label,
        "calc_rag_class": rag_class,
        "weighted_score": weighted_score,
        "rag_tooltip": tooltip,
        "pm_rag": pm_rag_label,
        "pm_rag_class": pm_rag_class,
        "my_portal_projects": my_portal_projects,
        "REDACTED_OPAQUE_VALUE": portal["REDACTED_OPAQUE_VALUE"],
        "us_project_types": us_project_types,
        "core_system": portal["core_system"],
        "schedule": {
            "score": schedule_score,
            "label": schedule_label,
            "target_date_check": {
                "score": target_date_score,
                "delay_days": target_date_delay,
                "label": target_date_label,
                "target_date": epic_target_date.isoformat() if epic_target_date else None,
                "has_target_date": epic_target_date is not None,
            },
            "variance_check": {
                "score": variance_score,
                "variance_pct": variance_pct,
                "label": variance_label,
                "completion_by_tasks": task_metrics["completion_by_tasks"],
                "completion_by_schedule": task_metrics["completion_by_schedule"],
                "schedule_start": task_metrics["schedule_start"].isoformat() if task_metrics["schedule_start"] else None,
                "schedule_end": task_metrics["schedule_end"].isoformat() if task_metrics["schedule_end"] else None,
                "has_data": variance_has_data,
            },
        },
        "task_delay": {
            "stale": {"count": len(task_metrics["stale_items"]), "items": task_metrics["stale_items"]},
            "overdue": {"count": len(task_metrics["overdue_items"]), "items": task_metrics["overdue_items"]},
        },
        "internal_quality": {
            "score": quality_score,
            "critical_count": critical_count,
            "showstopper_count": showstopper_count,
            "total": critical_count + showstopper_count,
            "label": quality_label,
            "completion_pct": None,
            "by_module": by_module_list,
            "items": quality_items,
        },
        "uat_bugs": portal["uat_bugs"],
        "risks": portal["risks"],
        "product_bugs": portal["product_bugs"],
        "data_quality": {
            "severity_populated": severity_populated,
            "target_date_set": epic_target_date is not None,
            "my_portal_connected": portal["connected"],
        },
        "is_dynamic": bool(project.get("is_dynamic")),
        "error": raw.get("error"),
    }


async def _fetch_all_projects() -> dict:
    # Azure (the 4 tracked projects) and My Portal / Redash (all 3 queries) are
    # independent systems — fetch both concurrently.
    azure_task = asyncio.gather(*[azure_client.fetch_project_raw_data(p) for p in PROJECTS])
    portal_task = redash_client.fetch_all_portal_rows(REDASH_QUERIES)
    azure_raw_results, portal_rows = await asyncio.gather(azure_task, portal_task)

    tickets_rows = portal_rows["production_tickets"]["rows"]
    tickets_error = portal_rows["production_tickets"]["error"]
    risks_rows = portal_rows["risks"]["rows"]
    risks_error = portal_rows["risks"]["error"]
    bugs_rows = portal_rows["product_bugs"]["rows"]
    bugs_error = portal_rows["product_bugs"]["error"]
    project_data_rows = portal_rows["project_data"]["rows"]
    project_data_error = portal_rows["project_data"]["error"]

    alias_index = portal_data.build_alias_index(PROJECTS)
    uat_rows_all = [r for r in bugs_rows if portal_data.is_uat_bug(r)]
    product_rows_all = [r for r in bugs_rows if not portal_data.is_uat_bug(r)]
    groups = {
        "risks_by_account": portal_data.group_by_account(risks_rows),
        "uat_by_account": portal_data.group_by_account(uat_rows_all),
        "product_by_account": portal_data.group_by_account(product_rows_all),
        "project_data_by_account": portal_data.group_by_account(project_data_rows),
        # Keyed by projectname instead of accountname — scopes UAT/Risks/Product
        # bugs down to an individual My Portal project for the drawer (item 4).
        "risks_by_project": portal_data.group_by_projectname(risks_rows),
        "uat_by_project": portal_data.group_by_projectname(uat_rows_all),
        "product_by_project": portal_data.group_by_projectname(product_rows_all),
    }
    tickets_by_account = portal_data.group_by_account(tickets_rows)

    # Discover every My Portal account across all 4 queries. Any account that
    # doesn't match one of our 4 tracked projects still gets shown — as a new,
    # dynamically-created project row with its own best-effort Azure DevOps fetch.
    all_accounts = portal_data.discover_all_accounts(
        groups["risks_by_account"],
        groups["uat_by_account"],
        groups["product_by_account"],
        groups["project_data_by_account"],
        tickets_by_account,
    )
    unmatched_accounts = sorted(
        a for a in all_accounts if alias_index.get(portal_data.normalize(a)) is None
    )
    dynamic_projects = [
        portal_data.make_dynamic_project(
            a,
            AZURE_PROJECT_ALIASES.get(portal_data.normalize(a)),
            ACCOUNT_PM_OVERRIDES.get(portal_data.normalize(a)),
        )
        for a in unmatched_accounts
    ]

    dynamic_raw_results = []
    if dynamic_projects:
        dynamic_raw_results = await asyncio.gather(
            *[azure_client.fetch_project_raw_data(p) for p in dynamic_projects]
        )

    combined_projects = list(PROJECTS) + dynamic_projects
    combined_raw = list(azure_raw_results) + list(dynamic_raw_results)

    today = _today_ist()
    projects = []
    for project, raw in zip(combined_projects, combined_raw):
        matched_accounts = portal_data.accounts_for_project(project, all_accounts)
        portal_summary = _build_portal_summary(
            matched_accounts, groups, risks_error, bugs_error, project_data_error
        )
        projects.append(_build_project_result(project, raw, today, portal_summary))

    kpis = {
        "on_track": sum(1 for p in projects if p["calc_rag"] == "GREEN"),
        "at_risk": sum(1 for p in projects if p["calc_rag"] == "AMBER"),
        "critical": sum(1 for p in projects if p["calc_rag"] == "RED"),
        "total_critical_bugs": sum(p["internal_quality"]["total"] for p in projects),
    }

    if tickets_error:
        production_tickets = {**EMPTY_PRODUCTION_TICKETS, "note": f"My Portal error: {tickets_error}"}
    else:
        production_tickets = {"note": None, **portal_data.build_production_tickets_matrix(tickets_rows, alias_index)}

    return {
        "last_refreshed": datetime.now(timezone.utc).isoformat(),
        "cached": False,
        "projects": projects,
        "kpis": kpis,
        "production_tickets": production_tickets,
    }


async def get_dashboard_data(force: bool = False) -> dict:
    if not force:
        cached = cache.get(CACHE_KEY)
        if cached is not None:
            return {**cached, "cached": True}
    data = await _fetch_all_projects()
    cache.set(CACHE_KEY, data, ttl_seconds=CACHE_TTL_SECONDS)
    return data


@app.get("/")
async def index(request: Request):
    try:
        data = await get_dashboard_data()
    except AzureAuthError as exc:
        data = {**EMPTY_DASHBOARD_DATA, "error": str(exc)}
    return templates.TemplateResponse(request, "dashboard.html", {"data": data})


@app.get("/api/refresh")
async def api_refresh(force: bool = False):
    try:
        return await get_dashboard_data(force=force)
    except AzureAuthError as exc:
        return JSONResponse(status_code=401, content={"error": str(exc)})


@app.get("/api/project/{name}")
async def api_project(name: str):
    try:
        data = await get_dashboard_data()
    except AzureAuthError as exc:
        return JSONResponse(status_code=401, content={"error": str(exc)})
    for project in data["projects"]:
        if project["name"] == name or project["short"] == name:
            return project
    return JSONResponse(status_code=404, content={"error": f"Project not found: {name}"})


def _report_error_page(request: Request, status_code: int, display_name: str, icon: str, title: str, message: str, detail: str = None):
    return templates.TemplateResponse(
        request,
        "report_error.html",
        {"display_name": display_name, "icon": icon, "title": title, "message": message, "detail": detail},
        status_code=status_code,
    )


@app.get("/project-report")
async def project_report_page(request: Request, project: str, force: bool = False):
    try:
        data = await get_dashboard_data()
    except AzureAuthError as exc:
        return _report_error_page(
            request, 401, project, "lock",
            "Azure DevOps authentication failed",
            "The dashboard's Azure DevOps token was rejected. Check the PAT in .env.",
            str(exc),
        )

    match = next((p for p in data["projects"] if p["name"] == project or p["short"] == project), None)
    if not match:
        return _report_error_page(
            request, 404, project, "search-x",
            "Project not found",
            f'"{project}" isn\'t in the current dashboard data. It may have been renamed or removed on refresh.',
        )

    azure_project_name = match["azure_project_name"]
    cache_key = f"report:{azure_project_name}"
    report = None if force else report_cache.get(cache_key)
    if report is None:
        try:
            report = await project_report.build_report_data(azure_project_name, match["name"])
        except AzureAuthError as exc:
            return _report_error_page(
                request, 401, match["name"], "lock",
                "Azure DevOps authentication failed",
                "The dashboard's Azure DevOps token was rejected. Check the PAT in .env.",
                str(exc),
            )
        except ProjectNotFoundError:
            return _report_error_page(
                request, 404, match["name"], "folder-x",
                "No Azure DevOps project found for this account",
                f'"{match["name"]}" exists in My Portal but has no matching Team Project in Azure DevOps '
                "under this organization, so there's no work-item data to build a report from. "
                "If this account has a project under a different name, add it to AZURE_PROJECT_ALIASES in config.py.",
                f"My Portal account: {match['name']}  ·  Attempted Azure DevOps project: {azure_project_name}",
            )
        report_cache.set(cache_key, report, ttl_seconds=REPORT_CACHE_TTL_SECONDS)

    return templates.TemplateResponse(request, "project_report.html", {"report": report, "display_name": match["name"]})


@app.get("/health")
async def health():
    cached = cache.get(CACHE_KEY)
    return {
        "status": "ok",
        "cached": cached is not None,
        "last_refresh": cached.get("last_refreshed") if cached else None,
    }
