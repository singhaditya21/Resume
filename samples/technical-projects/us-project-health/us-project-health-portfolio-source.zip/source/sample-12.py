"""Aggregation helpers for My Portal (Redash) data.

Redash returns flat case/risk rows keyed by an "accountname" string. Azure DevOps
project names don't always match that spelling (e.g. Azure "SESLOC CU" vs the
My Portal account "SESLOC"), so matching to a known project is done via the
explicit `redash_accounts` alias list in config.PROJECTS rather than fuzzy string
comparison. Any account name that shows up in the Redash data but matches no known
project's aliases is still surfaced (per spec: "show for all the accounts coming
in the API response") — the caller turns it into a dynamic project entry.
"""

import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

BUCKETS = ["1-5", "5-10", "10-15", "15-30", "30+"]

_AGING_RE = re.compile(r"(-?\d+)\s*D")

# Mirrors main.IST_OFFSET — kept local so this module has no dependency on main.
# The project-data query's date columns follow the same convention as Azure's
# custom date fields: UTC timestamps representing IST midnight.
_IST_OFFSET = timedelta(minutes=330)


def parse_portal_date(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    return (dt + _IST_OFFSET).date()


def normalize(value) -> str:
    return (value or "").strip().lower()


def build_alias_index(projects: list) -> dict:
    """Maps normalized account-name alias -> project dict."""
    index = {}
    for project in projects:
        for alias in project.get("redash_accounts", []):
            index[normalize(alias)] = project
    return index


def group_by_account(rows: list) -> dict:
    grouped = defaultdict(list)
    for row in rows:
        grouped[row.get("accountname") or "Unknown"].append(row)
    return grouped


def group_by_projectname(rows: list) -> dict:
    """Keyed by normalized project name — used to scope UAT bugs/Risks/Product
    bugs (which only carry a projectname string, no id) to a specific My Portal
    project row in the drawer. Rows with no projectname are dropped (can't be
    scoped to a project, but they still count at the account level)."""
    grouped = defaultdict(list)
    for row in rows:
        key = normalize(row.get("projectname"))
        if key:
            grouped[key].append(row)
    return grouped


_CLOSED_RISK_STATUSES = ("resolved", "deferred")


def is_open_risk(row: dict) -> bool:
    return normalize(row.get("statuscode")) not in _CLOSED_RISK_STATUSES


def is_uat_bug(row: dict) -> bool:
    return normalize(row.get("appliesto")) == "customer uat"


def parse_aging_days(aging: str):
    if not aging:
        return None
    match = _AGING_RE.search(aging)
    return int(match.group(1)) if match else None


def bucket_for_days(days) -> str:
    if days is None or days <= 5:
        return "1-5"
    if days <= 10:
        return "5-10"
    if days <= 15:
        return "10-15"
    if days <= 30:
        return "15-30"
    return "30+"


def summarize_risks(rows: list) -> dict:
    open_rows = [r for r in rows if is_open_risk(r)]
    severities = Counter(normalize(r.get("severity")) for r in open_rows)
    return {
        "count": len(open_rows),
        "high": severities.get("high", 0),
        "medium": severities.get("medium", 0),
        "low": severities.get("low", 0),
        "items": [
            {
                "statement": r.get("riskstatement"),
                "assigned_to": r.get("assignedtoname"),
                "status": r.get("statuscode"),
                "severity": r.get("severity"),
                "pending_on": r.get("riskpendingon"),
                "origination_date": r.get("originationdate"),
            }
            for r in open_rows
        ],
    }


def summarize_bugs(rows: list) -> dict:
    by_priority = Counter(r.get("casepriority") or "—" for r in rows)
    return {
        "count": len(rows),
        "by_priority": dict(by_priority),
        "items": [
            {
                "caseid": r.get("caseid"),
                "subject": r.get("subject"),
                "priority": r.get("casepriority"),
                "status": r.get("casestatus"),
                "aging": r.get("aging"),
                "reported_by": r.get("reportedby"),
                "reported_on": r.get("casereportedon"),
            }
            for r in rows
        ],
    }


def build_production_tickets_matrix(rows: list, alias_index: dict) -> dict:
    by_account = group_by_account(rows)
    accounts_out = []
    totals = {bucket: 0 for bucket in BUCKETS}
    total_count = 0
    escalation_count = 0

    for accountname, acc_rows in sorted(by_account.items()):
        project = alias_index.get(normalize(accountname))
        bucket_counts = {bucket: 0 for bucket in BUCKETS}
        bucket_priority = {bucket: {} for bucket in BUCKETS}
        bucket_items = {bucket: [] for bucket in BUCKETS}
        oldest = None
        for row in acc_rows:
            days = parse_aging_days(row.get("aging"))
            bucket = bucket_for_days(days)
            bucket_counts[bucket] += 1
            totals[bucket] += 1
            priority = row.get("casepriority") or "—"
            bucket_priority[bucket][priority] = bucket_priority[bucket].get(priority, 0) + 1
            bucket_items[bucket].append(
                {
                    "caseid": row.get("caseid"),
                    "subject": row.get("subject"),
                    "priority": priority,
                    "status": row.get("casestatus"),
                    "aging": row.get("aging"),
                    "reported_by": row.get("reportedby"),
                    "reported_on": row.get("casereportedon"),
                }
            )
            if oldest is None or (days or 0) > oldest["days"]:
                oldest = {"days": days or 0, "subject": row.get("subject"), "caseid": row.get("caseid")}
            if bucket == "30+":
                escalation_count += 1
        total_count += len(acc_rows)
        accounts_out.append(
            {
                "account": accountname,
                "matched_project": project["short"] if project else None,
                "buckets": bucket_counts,
                "bucket_priority": bucket_priority,
                "bucket_items": bucket_items,
                "total": len(acc_rows),
                "oldest": oldest,
            }
        )

    accounts_out.sort(key=lambda a: -a["total"])
    totals["total"] = total_count
    return {
        "buckets": BUCKETS,
        "accounts": accounts_out,
        "totals": totals,
        "escalation_count": escalation_count,
    }


def discover_all_accounts(*grouped_dicts: dict) -> set:
    accounts = set()
    for grouped in grouped_dicts:
        accounts.update(grouped.keys())
    return accounts


def accounts_for_project(project: dict, all_accounts) -> list:
    aliases = {normalize(a) for a in project.get("redash_accounts", [])}
    return [a for a in all_accounts if normalize(a) in aliases]


def rollup_rag(rag_values) -> str:
    """Any RED -> RED; elif any AMBER -> AMBER; else GREEN. Blank/None values
    (common — ~20% of delivery_rag rows are unset) are ignored, not counted
    as a color, matching the "if any is RED... if any is Amber... else green"
    rule as given — an account with no RAG set anywhere defaults to GREEN."""
    normed = {normalize(v) for v in rag_values if v}
    if "red" in normed:
        return "RED"
    if "amber" in normed:
        return "AMBER"
    return "GREEN"


_DRAWER_HIDDEN_STATUSES = ("closed", "draft")


def summarize_account_projects(rows: list) -> dict:
    """Builds the per-account 'My Portal projects' list (for the drawer) plus
    account-level rollups. Every rollup (PM RAG, Phase, PM, US PM, Core System)
    considers ONLY active engagements (status not in Closed/Draft) — a
    long-finished or not-yet-started project shouldn't drive what the account
    row shows. Phase/PM/US PM come from a "primary" active project: whichever
    is in Development wins, else the most recently created (highest projectid).
    Core System is the first non-blank value found among active projects (not
    tied to the primary project specifically)."""
    projects = []
    for r in rows:
        go_live = parse_portal_date(r.get("golivedate"))
        start = parse_portal_date(r.get("startdate"))
        projects.append(
            {
                "project_id": r.get("projectid"),
                "project_name": r.get("projectname"),
                "status": r.get("statuscode"),
                "pm_rag": r.get("delivery_rag"),
                "start_date": start.isoformat() if start else None,
                "go_live_date": go_live.isoformat() if go_live else None,
                "core_system": r.get("coresystem"),
                "us_pm": r.get("usprojectmanager"),
                "ind_pm": r.get("indprojectmanager"),
                "us_project_type": r.get("usprojecttype"),
            }
        )

    active_projects = [p for p in projects if normalize(p["status"]) not in _DRAWER_HIDDEN_STATUSES]

    dev_projects = [p for p in active_projects if normalize(p["status"]) == "development"]
    candidates = dev_projects or active_projects
    primary = max(candidates, key=lambda p: p["project_id"] or 0) if candidates else None

    pm_rag = rollup_rag(p["pm_rag"] for p in active_projects)
    core_system = next((p["core_system"] for p in active_projects if p["core_system"]), None)

    # If every project this account has is Closed/Draft, fall back to showing
    # them anyway — an account with 100% closed/draft history should still get
    # a drawer to expand, not silently look like it has no My Portal data at all.
    drawer_source = active_projects or projects

    # core_system is shown at the account level, not repeated per drawer row.
    visible_projects = sorted(
        ({k: v for k, v in p.items() if k != "core_system"} for p in drawer_source),
        key=lambda p: p["project_id"] or 0,
        reverse=True,
    )

    return {
        "projects": visible_projects,
        "pm_rag": pm_rag,
        "phase": primary["status"] if primary else None,
        "ind_pm": primary["ind_pm"] if primary else None,
        "us_pm": primary["us_pm"] if primary else None,
        "core_system": core_system,
        "showing_inactive_fallback": not active_projects and bool(projects),
    }


def make_dynamic_project(account_name: str, azure_project_name: str = None, pm: str = None) -> dict:
    """A project entry synthesized for a My Portal account that has no matching
    entry in config.PROJECTS. `azure_project_name` — resolved from
    config.AZURE_PROJECT_ALIASES — points its Azure DevOps fetch at the correct
    Team Project name when the two systems spell the account differently. If no
    alias is known, the account name itself is tried as a last resort (and will
    404 gracefully via ProjectNotFoundError if there's truly no matching project).
    `pm` — resolved from config.ACCOUNT_PM_OVERRIDES — since no system tracks PM
    ownership for these accounts; defaults to "—" when not yet provided."""
    return {
        "id": f"portal:{account_name}",
        "name": account_name,
        "short": account_name,
        "pm": pm or "—",
        "phase": "Unmapped",
        "phase_class": "phase-unknown",
        "redash_accounts": [account_name],
        "azure_project": azure_project_name,
        "azure_matched": azure_project_name is not None,
        "is_dynamic": True,
    }
