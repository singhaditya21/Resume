"""Per-project detailed health report — ported from the standalone
project_health_analyzer.py N8N script into this app, reusing azure_client's
async WIQL/batch-fetch primitives and Team Project resolution instead of a
separate `requests`-based client.

One deliberate deviation from the reference script: "reopened items" detection
(a work item that closed and later reopened) requires one Azure DevOps History
API call per work item. For a project with 1000+ items that's too slow to run
synchronously on a dashboard click, so it's skipped here — the section stays
in the report (as requested), just empty with a note explaining why, rather
than silently dropping the whole feature.
"""

import logging
from collections import defaultdict
from datetime import datetime, timezone
from urllib.parse import quote

import httpx

from azure_client import API_VERSION, BASE_URL, ProjectNotFoundError, _auth_headers, _raise_for_status, get_work_items, run_wiql
from config import AZURE_ORG

logger = logging.getLogger("coe_dashboard.project_report")

DONE_STATES = {"Done", "Closed", "Resolved", "Completed", "Removed"}
MODULE_TYPES = {"Epic", "Feature"}
TRACKING_TYPES = {"Product Backlog Item", "User Story", "PBI", "Task", "Bug", "Feedback", "Issue", "Impediment"}

REPORT_FIELDS = [
    "System.Id", "System.Title", "System.WorkItemType", "System.State", "System.AssignedTo",
    "System.CreatedDate", "System.ChangedDate", "System.AreaPath", "System.IterationPath",
    "System.Tags", "System.Parent",
    "Microsoft.VSTS.Common.Priority", "Microsoft.VSTS.Common.Severity", "Microsoft.VSTS.Common.Activity",
    "Microsoft.VSTS.Scheduling.OriginalEstimate", "Microsoft.VSTS.Scheduling.CompletedWork",
    "Microsoft.VSTS.Scheduling.RemainingWork", "Microsoft.VSTS.Scheduling.Effort",
    "Microsoft.VSTS.Scheduling.StoryPoints", "Microsoft.VSTS.Scheduling.Size",
    "Microsoft.VSTS.Scheduling.DueDate", "Microsoft.VSTS.Scheduling.TargetDate",
    "Microsoft.VSTS.Common.TargetDate",
]
ALL_ITEMS_WIQL = """
SELECT [System.Id] FROM WorkItems
WHERE [System.TeamProject] = '{project}'
ORDER BY [System.ChangedDate] DESC
"""

MAX_ITEMS = 4000


def _field(item: dict, name: str, default=None):
    return item.get("fields", {}).get(name, default)


def _parse_dt(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _age_days(value, today):
    dt = _parse_dt(value)
    if not dt:
        return None
    return (today - dt).days


def _owner_name(value):
    if isinstance(value, dict):
        return value.get("displayName") or value.get("uniqueName") or "Unassigned"
    return str(value).strip() if value and str(value).strip() else "Unassigned"


def _num(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _split_tags(tags):
    if not tags:
        return []
    return [t.strip() for t in str(tags).split(";") if t.strip()]


def _effort_values(fields: dict):
    planned = (
        _num(fields.get("Microsoft.VSTS.Scheduling.OriginalEstimate"))
        or _num(fields.get("Microsoft.VSTS.Scheduling.Effort"))
        or _num(fields.get("Microsoft.VSTS.Scheduling.StoryPoints"))
        or _num(fields.get("Microsoft.VSTS.Scheduling.Size"))
    )
    completed = _num(fields.get("Microsoft.VSTS.Scheduling.CompletedWork"))
    remaining = _num(fields.get("Microsoft.VSTS.Scheduling.RemainingWork"))
    return planned, completed, remaining


def _due_value(fields: dict):
    for ref in (
        "Microsoft.VSTS.Scheduling.DueDate",
        "Microsoft.VSTS.Scheduling.TargetDate",
        "Microsoft.VSTS.Common.TargetDate",
    ):
        if fields.get(ref):
            return fields.get(ref)
    return None


def _is_closed(state: str) -> bool:
    return state in DONE_STATES


def _activity_category(fields: dict) -> str:
    ado_activity = (fields.get("Microsoft.VSTS.Common.Activity") or "").strip()
    if ado_activity:
        return ado_activity
    wi_type = str(fields.get("System.WorkItemType", "") or "").lower()
    title = str(fields.get("System.Title", "") or "").lower()
    tags = " ".join(_split_tags(fields.get("System.Tags", ""))).lower()
    area = str(fields.get("System.AreaPath", "") or "").lower()
    text = f"{wi_type} {title} {tags} {area}"
    if wi_type == "bug" or any(x in text for x in ["bug", "defect", "fix", "hotfix", "issue fix"]):
        return "Bug Fixing"
    if any(x in text for x in ["test", "testing", "qa", "uat", "sanity", "regression", "verification", "validate", "validation"]):
        return "Testing"
    if any(x in text for x in ["dev", "development", "config", "configuration", "api", "integration", "job", "sp", "eds", "coding", "build", "layout"]):
        return "Development"
    if any(x in text for x in ["analysis", "design", "approach", "solution", "mapping", "requirement", "brd", "fsd", "tsd"]):
        return "Analysis / Design"
    if any(x in text for x in ["deployment", "release", "migration", "go live", "golive", "environment"]):
        return "Deployment / Release"
    return "Other"


def _parent_id(item: dict):
    pid = _field(item, "System.Parent")
    return int(pid) if pid else None


async def _safe_get_work_items(client: httpx.AsyncClient, project_name: str, ids: list, fields_csv: str) -> list:
    """get_work_items, but tolerant of stale System.Parent references (a parent
    that was since deleted). Azure DevOps 404s the whole GET when every id in
    the batch is invalid — that's a fetch-time gap for this one hop, not a
    reason to fail the whole report, so it's logged and skipped instead."""
    try:
        return await get_work_items(client, project_name, ids, fields_csv)
    except ProjectNotFoundError:
        logger.warning("Skipping %d hierarchy id(s) not found in Azure DevOps: %s", len(ids), ids)
        return []


async def _fetch_hierarchy_lookup(client: httpx.AsyncClient, project_name: str, items: list, fields_csv: str) -> dict:
    """2-hop parent/grandparent lookup (Task -> PBI -> Feature -> Epic) for
    items whose parent isn't already in the fetched batch."""
    lookup = {}
    for item in items:
        item_id = _field(item, "System.Id", item.get("id"))
        if item_id is not None:
            lookup[int(item_id)] = item

    parent_ids = {_parent_id(item) for item in items if _parent_id(item) and _parent_id(item) not in lookup}
    if parent_ids:
        parents = await _safe_get_work_items(client, project_name, list(parent_ids), fields_csv)
        for item in parents:
            item_id = _field(item, "System.Id", item.get("id"))
            if item_id is not None:
                lookup[int(item_id)] = item

        grand_ids = {_parent_id(item) for item in parents if _parent_id(item) and _parent_id(item) not in lookup}
        if grand_ids:
            grandparents = await _safe_get_work_items(client, project_name, list(grand_ids), fields_csv)
            for item in grandparents:
                item_id = _field(item, "System.Id", item.get("id"))
                if item_id is not None:
                    lookup[int(item_id)] = item

    return lookup


def _attach_hierarchy(items: list, lookup: dict) -> list:
    for item in items:
        fields = item.setdefault("fields", {})
        pid = _parent_id(item)
        parent = lookup.get(pid) if pid else None
        if not parent:
            continue
        pf = parent.get("fields", {})
        fields["Health.ParentId"] = pf.get("System.Id", pid)
        fields["Health.ParentType"] = pf.get("System.WorkItemType", "")
        fields["Health.ParentTitle"] = pf.get("System.Title", "")

        gpid = _parent_id(parent)
        gp = lookup.get(gpid) if gpid else None
        if gp:
            gf = gp.get("fields", {})
            fields["Health.GrandParentId"] = gf.get("System.Id", gpid)
            fields["Health.GrandParentType"] = gf.get("System.WorkItemType", "")
            fields["Health.GrandParentTitle"] = gf.get("System.Title", "")
    return items


def _module_for_item(item: dict):
    fields = item.get("fields", {})
    item_id = fields.get("System.Id", item.get("id"))
    wi_type = fields.get("System.WorkItemType", "")
    title = fields.get("System.Title", "")

    if wi_type == "Epic":
        return str(item_id), title or f"Epic {item_id}", "Epic"
    if wi_type == "Feature":
        return str(item_id), title or f"Feature {item_id}", "Feature"

    pt = fields.get("Health.ParentType", "")
    pi = fields.get("Health.ParentId", "")
    pn = fields.get("Health.ParentTitle", "")
    gt = fields.get("Health.GrandParentType", "")
    gi = fields.get("Health.GrandParentId", "")
    gn = fields.get("Health.GrandParentTitle", "")

    if pt in ("Feature", "Epic"):
        return str(pi), pn or f"{pt} {pi}", pt
    if gt in ("Feature", "Epic"):
        return str(gi), gn or f"{gt} {gi}", gt
    return "Unmapped", "Unmapped / Standalone", "Unmapped"


def _row_for_item(item: dict, project_name: str, today) -> dict:
    fields = item.get("fields", {})
    item_id = fields.get("System.Id", item.get("id", ""))
    planned, completed, remaining = _effort_values(fields)
    due = _due_value(fields)
    module_id, module_name, module_type = _module_for_item(item)
    changed = fields.get("System.ChangedDate", "")
    return {
        "id": item_id,
        "title": fields.get("System.Title", ""),
        "type": fields.get("System.WorkItemType", ""),
        "state": fields.get("System.State", ""),
        "owner": _owner_name(fields.get("System.AssignedTo")),
        "module_id": module_id,
        "module": module_name,
        "module_type": module_type,
        "activity": _activity_category(fields),
        "planned": planned,
        "completed": completed,
        "remaining": remaining,
        "due_date": due,
        "age": _age_days(changed, today),
        "parent": _parent_id(item) or "",
        "tags": "; ".join(_split_tags(fields.get("System.Tags", ""))),
        "url": f"https://example.invalid)}/{quote(project_name)}/_workitems/edit/{item_id}",
    }


def _analyze(rows: list, project_label: str) -> dict:
    type_summary = defaultdict(lambda: {"items": 0, "open": 0, "closed": 0, "planned": 0.0, "completed": 0.0, "remaining": 0.0})
    owner_summary = defaultdict(lambda: {"items": 0, "open": 0, "closed": 0, "planned": 0.0, "completed": 0.0, "remaining": 0.0})
    activity_summary = defaultdict(lambda: {"items": 0, "open": 0, "closed": 0, "planned": 0.0, "completed": 0.0, "remaining": 0.0})
    module_summary = defaultdict(lambda: {
        "module_id": "", "module": "", "module_type": "", "module_state": "",
        "pbi": 0, "tasks": 0, "bugs": 0, "feedback": 0, "other": 0,
        "items": 0, "open": 0, "closed": 0, "open_child_work": 0,
        "planned": 0.0, "completed": 0.0, "remaining": 0.0,
    })

    closed = 0
    planned_total = completed_total = remaining_total = 0.0
    overdue, aged_open, blocked, unassigned, missing_effort = [], [], [], [], []
    now = datetime.now(timezone.utc)

    for row in rows:
        wi_type = row["type"]
        state = row["state"]
        done = _is_closed(state)
        module_type_flag = wi_type in MODULE_TYPES
        tracking = wi_type in TRACKING_TYPES

        if done:
            closed += 1
        planned_total += row["planned"]
        completed_total += row["completed"]
        remaining_total += row["remaining"]

        for summary, key in ((type_summary, wi_type), (owner_summary, row["owner"]), (activity_summary, row["activity"])):
            bucket = summary[key]
            bucket["items"] += 1
            bucket["planned"] += row["planned"]
            bucket["completed"] += row["completed"]
            bucket["remaining"] += row["remaining"]
            bucket["closed" if done else "open"] += 1

        mod = module_summary[row["module_id"]]
        mod["module_id"] = row["module_id"]
        mod["module"] = row["module"]
        mod["module_type"] = row["module_type"]
        mod["items"] += 1
        mod["planned"] += row["planned"]
        mod["completed"] += row["completed"]
        mod["remaining"] += row["remaining"]

        if wi_type in ("Product Backlog Item", "User Story", "PBI"):
            mod["pbi"] += 1
        elif wi_type == "Task":
            mod["tasks"] += 1
        elif wi_type == "Bug":
            mod["bugs"] += 1
        elif wi_type in ("Feedback", "Issue"):
            mod["feedback"] += 1
        elif not module_type_flag:
            mod["other"] += 1

        if module_type_flag and str(row["id"]) == str(row["module_id"]):
            mod["module_state"] = state

        if done:
            mod["closed"] += 1
        else:
            mod["open"] += 1
            if not module_type_flag:
                mod["open_child_work"] += 1

        if not done and row["age"] is not None and row["age"] >= 14:
            aged_open.append(row)
        if not done and row["owner"] == "Unassigned":
            unassigned.append(row)
        if tracking and not done and row["due_date"]:
            due_dt = _parse_dt(row["due_date"])
            if due_dt and due_dt < now:
                overdue.append(row)
        if wi_type in ("Task", "Bug", "Feedback", "Issue") and row["planned"] == 0:
            missing_effort.append(row)

        tag_text = row["tags"].lower()
        if any(x in tag_text for x in ["blocked", "blocker", "dependency", "on hold", "hold"]):
            blocked.append(row)

    def finish(summary):
        # NOTE: the output key is "total_items", not "items" — Jinja's dot
        # notation on a dict tries getattr() before getitem(), and dict has a
        # real .items() method, so `t.items` in a template would silently
        # resolve to that bound method instead of the count.
        out = []
        for name, v in summary.items():
            count = v["items"]
            out.append({
                "name": name,
                "total_items": count,
                "open": v["open"],
                "closed": v["closed"],
                "completion_pct": round(v["closed"] / count * 100, 1) if count else 0,
                "planned": round(v["planned"], 2),
                "completed": round(v["completed"], 2),
                "remaining": round(v["remaining"], 2),
            })
        return sorted(out, key=lambda x: (x["remaining"], x["open"], x["total_items"]), reverse=True)

    modules, exceptions = [], []
    for v in module_summary.values():
        count = v["items"]
        module_state = v["module_state"] or "Not Captured"
        exception = ""
        if v["module_id"] != "Unmapped":
            if module_state not in DONE_STATES and v["open_child_work"] == 0:
                exception = "Feature/Epic not closed but no open child work"
            elif module_state in ("New", "To Do", "Proposed") and v["open_child_work"] > 0:
                exception = "Child work started but Feature/Epic is still New"
            elif module_state in DONE_STATES and v["open_child_work"] > 0:
                exception = "Feature/Epic closed but child work is still open"
        module_row = {
            "module_id": v["module_id"], "module": v["module"], "module_type": v["module_type"],
            "module_state": module_state, "pbi": v["pbi"], "tasks": v["tasks"], "bugs": v["bugs"],
            "feedback": v["feedback"], "other": v["other"], "total_items": count, "open": v["open"], "closed": v["closed"],
            "open_child_work": v["open_child_work"],
            "completion_pct": round(v["closed"] / count * 100, 1) if count else 0,
            "planned": round(v["planned"], 2), "completed": round(v["completed"], 2), "remaining": round(v["remaining"], 2),
            "exception": exception,
        }
        modules.append(module_row)
        if exception:
            exceptions.append(module_row)

    total = len(rows)
    return {
        "project_name": project_label,
        "generated_on": datetime.now().strftime("%d %b %Y, %I:%M %p"),
        "total": total,
        "closed": closed,
        "open": total - closed,
        "completion_rate": round(closed / total * 100, 1) if total else 0,
        "planned": round(planned_total, 2),
        "completed_effort": round(completed_total, 2),
        "remaining_effort": round(remaining_total, 2),
        "type_summary": finish(type_summary),
        "owner_summary": finish(owner_summary),
        "activity_effort": finish(activity_summary),
        "module_summary": sorted(
            modules, key=lambda x: (x["module_id"] == "Unmapped", x["exception"] == "", -x["open_child_work"], -x["total_items"])
        ),
        "feature_state_exceptions": sorted(exceptions, key=lambda x: (-x["open_child_work"], x["module"])),
        "overdue_items": sorted(overdue, key=lambda x: str(x["due_date"] or ""))[:200],
        "reopened_items": [],
        "reopened_check_skipped": True,
        "aged_open": sorted(aged_open, key=lambda x: -(x["age"] or 0))[:200],
        "blocked": blocked[:200],
        "unassigned": unassigned[:200],
        "missing_effort": missing_effort[:200],
    }


async def _existing_field_refs(client: httpx.AsyncClient, project_name: str) -> set:
    """Not every field in REPORT_FIELDS is customized into every project's process
    template (e.g. this org has no StoryPoints/Size/DueDate on some projects) —
    Azure DevOps returns a hard 400 for the whole batch if even one requested field
    reference name doesn't exist, so the field list must be validated first, same
    as the reference script's `--dump-fields` safety check."""
    url = f"{BASE_URL}/{project_name}/_apis/wit/fields?api-version={API_VERSION}"
    resp = await client.get(url, headers=_auth_headers())
    _raise_for_status(resp, project_name)
    return {f["referenceName"] for f in resp.json().get("value", [])}


async def build_report_data(azure_project_name: str, display_label: str) -> dict:
    """Fetches every work item in the Azure DevOps team project and runs the
    full analysis. Raises azure_client.AzureAuthError / ProjectNotFoundError
    on failure — callers should catch these same as elsewhere in the app."""
    async with httpx.AsyncClient(timeout=60.0) as client:
        existing = await _existing_field_refs(client, azure_project_name)
        fields = [f for f in REPORT_FIELDS if f in existing]
        fields_csv = ",".join(fields)

        wiql = ALL_ITEMS_WIQL.format(project=azure_project_name)
        ids = await run_wiql(client, azure_project_name, wiql)
        ids = ids[:MAX_ITEMS]
        items = await get_work_items(client, azure_project_name, ids, fields_csv)
        lookup = await _fetch_hierarchy_lookup(client, azure_project_name, items, fields_csv)
        items = _attach_hierarchy(items, lookup)
        today = datetime.now(timezone.utc)
        rows = [_row_for_item(item, azure_project_name, today) for item in items]
        summary = _analyze(rows, display_label)
        return {"summary": summary, "items": rows}
