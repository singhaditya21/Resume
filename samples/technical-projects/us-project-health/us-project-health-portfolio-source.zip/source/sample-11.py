import os

from dotenv import load_dotenv

load_dotenv()

AZURE_ORG = os.getenv("AZURE_ORG", "acidaes")
AZURE_PAT = os.getenv("AZURE_PAT", "")
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "300"))
PORT = int(os.getenv("PORT", "8000"))

REDASH_BASE_URL = os.getenv("REDASH_BASE_URL", "https://example.invalid")
REDASH_API_KEY = os.getenv("REDASH_API_KEY", "")
REDASH_PRODUCTION_TICKETS_QUERY_ID = os.getenv("REDACTED_OPAQUE_VALUE", "666")
REDASH_PRODUCTION_TICKETS_API_KEY = os.getenv("REDACTED_OPAQUE_VALUE", "")
REDASH_RISKS_QUERY_ID = os.getenv("REDASH_RISKS_QUERY_ID", "663")
REDASH_RISKS_API_KEY = os.getenv("REDASH_RISKS_API_KEY", "")
REDASH_PRODUCT_BUGS_QUERY_ID = os.getenv("REDASH_PRODUCT_BUGS_QUERY_ID", "672")
REDASH_PRODUCT_BUGS_API_KEY = os.getenv("REDASH_PRODUCT_BUGS_API_KEY", "")
REDASH_PROJECT_DATA_QUERY_ID = os.getenv("REDASH_PROJECT_DATA_QUERY_ID", "673")
REDASH_PROJECT_DATA_API_KEY = os.getenv("REDASH_PROJECT_DATA_API_KEY", "")

# "redash_accounts" lists the My Portal account-name spellings (as returned by the
# Redash queries) that should be matched to this project. Names vary between systems
# (e.g. Azure DevOps project "SESLOC CU" vs My Portal account "SESLOC"), so matching
# is done by explicit alias rather than fuzzy string comparison.
PROJECTS = [
    {
        "id": "REDACTED_OPAQUE_VALUE",
        "name": "Foothill Federal Credit Union",
        "short": "Foothill FCU",
        "pm": "Lalit Raj",
        "phase": "Dev",
        "phase_class": "phase-dev",
        "redash_accounts": ["Foothill Federal Credit Union"],
    },
    {
        "id": "First Source Credit Union",
        "name": "First Source Credit Union",
        "short": "First Source CU",
        "pm": "Stephen Manuel",
        "phase": "UAT",
        "phase_class": "phase-uat",
        "redash_accounts": ["FIRST SOURCE", "First Source Credit Union"],
    },
    {
        "id": "REDACTED_OPAQUE_VALUE",
        "name": "Family Trust Project",
        "short": "Family Trust",
        "pm": "Jinali Kamdar",
        "phase": "UAT",
        "phase_class": "phase-uat",
        "redash_accounts": ["FAMILY TRUST", "Family Trust Project"],
    },
    {
        "id": "REDACTED_OPAQUE_VALUE",
        "name": "SESLOC CU",
        "short": "SESLOC CU",
        "pm": "Gaurav Singh",
        "phase": "SA/UAT",
        "phase_class": "phase-uat",
        "redash_accounts": ["SESLOC", "SESLOC CU"],
    },
]

CLOSED_BUG_STATES = ("Closed", "Done", "Removed", "Not a Bug")

# For My Portal accounts that aren't one of the 4 tracked projects above, this maps
# the (normalized, lowercased) account name to its real Azure DevOps Team Project
# name — looked up from `GET /_apis/projects` since the two systems don't spell
# accounts the same way (e.g. My Portal "WESTMARK" vs Azure "West Mark Credit Union").
# Accounts with no entry here (e.g. "CUSTOMER_REDACTED Financial Credit Union") have no
# matching Azure DevOps project and will show partial (My Portal only) data.
AZURE_PROJECT_ALIASES = {
    "clearview federal credit union": "US-CFCU-Clearview Federal Credit Union (Gold 8 Upgrade)",
    "community choice credit union": "CCCU- Agile Engagement",
    "CUSTOMER_REDACTED community credit union": "US-DCCU-CUSTOMER_REDACTED Community Credit Union",
    "extraco banks national association": "Extraco Banks",
    "o bee credit union": "O BEE CU Implementation",
    "sound credit union": "Sound G8 Upgrade",
    "CUSTOMER_REDACTED credit union": "CUSTOMER_REDACTED CU",
    "westmark": "West Mark Credit Union",
    "state department": "State Department Federal Credit Union",
}

# Fallback PM only — real PM ownership now comes from the My Portal project-level
# query (REDASH_PROJECT_DATA_QUERY_ID, indprojectmanager/usprojectmanager). This
# is used only when an account has no rows in that query at all.
ACCOUNT_PM_OVERRIDES = {
    "clearview federal credit union": "Devesh",
    "community choice credit union": "Nishant Kajekar",
    "CUSTOMER_REDACTED community credit union": "Lalit Raj",
    "extraco banks national association": "Jinali Kamdar",
    "o bee credit union": "Lalit Raj",
    "sound credit union": "Lalit Raj",
    "CUSTOMER_REDACTED credit union": "Gaurav Singh",
    "westmark": "Lalit Raj",
}
