# US Project Health Dashboard

- **Evidence status:** Deterministic / AI-enabling
- **Source evidence:** Sanitized source samples
- **Verification:** Static review only · code not executed
- **Delivery maturity:** Deterministic implementation archive
- **Intelligence type:** Deterministic / AI-enabling
- **Category:** Data & decision intelligence
- **Project family:** BizTech decision systems
- **Source package:** `USProjecthealth.zip`

Portfolio-health analytics that reconcile delivery and CRM evidence into weighted red/amber/green outcomes.

The technical claims below are grounded in the supplied source archive.

## AI or automation role

No LLM or retrieval model is present; RAG means deterministic Red/Amber/Green scoring with transparent thresholds and weights.

## Technical stack

Python · FastAPI · Azure DevOps · Redash · Jinja2 · httpx

## Skills demonstrated

- Async integration
- Source reconciliation
- Data quality
- Weighted health scoring
- TTL caching
- Graceful degradation

## Primary system flow

Delivery and CRM sources → Parallel fetch → Alias reconciliation → Metric engine → Weighted RAG score → Portfolio dashboard

## Architecture image pack

- `architecture/01-executive-architecture.svg`
- `architecture/02-runtime-data-flow.svg`
- `architecture/03-system-context-deployment.svg`
- `architecture/04-authenticated-lifecycle.svg`
- `architecture/05-data-architecture.svg`
- `architecture/06-workflow-orchestration.svg`
- `architecture/07-ai-control-plane.svg`
- `architecture/08-trust-boundaries.svg`
- `architecture/09-target-architecture-roadmap.svg`

IdeaStorm additionally includes the nine supplied PNG reference diagrams under `architecture/reference-pack/`.

## Source evidence reviewed

See [`PUBLIC_EVIDENCE_MAP.md`](PUBLIC_EVIDENCE_MAP.md) for a claim-to-sample map and the complete anonymized sample inventory. Original archive-member paths are intentionally not published.

## Attribution, outcomes and decisions

- **Personal ownership:** Not established from the supplied archive.
- **Measured outcomes:** Not established from the supplied archive.

- **Technical decision rationale:** Not established from the supplied archive.

## Public-package boundary

This is a curated, non-runnable portfolio snapshot rather than the original production archive. Credentials, environment files, customer datasets, contract documents, employee records, database backups, vector indexes, model weights, generated dependencies, media and live deployment state are excluded. Selected source text is anonymized, scanned and redacted for credential-like values, known customer names, identity literals, email addresses, phone numbers, identifiers, service URLs, network addresses and local filesystem paths.

- Meaningful anonymized source samples: **14**
- Retained empty source placeholders: **0**
- Total included source files: **14**
- Included sanitized source bytes: **192,755**
