import { system } from "styled-system";

// DS shorthand aliases not covered by the standard styled-system parsers.
export const dsAliases = system({
  brd: { property: "borderRadius", scale: "radii" },
  fw: { property: "fontWeight", scale: "fontWeights" },
  ff: { property: "fontFamily", scale: "fonts" },
  wt: { property: "width", scale: "sizes" },
  ht: { property: "height", scale: "sizes" },
});
