"""Single sign-on via Microsoft Entra ID (Azure AD) — OIDC authorization-code flow.

SSO is OPTIONAL and self-disabling: if the Entra app-registration values are
not present in the environment, `sso_enabled()` is False, the /api/auth/login
route returns 503, and the app falls back to the existing demo sign-in. Fill in
the four ENTRA_* values (see backend/.env.example) to turn it on — no code
change required.

Flow:
  GET  /api/auth/login     → redirect to Entra /authorize (state+nonce in session)
  GET  /api/auth/callback  → exchange code, validate ID token, map to app_users,
                             store the user in the signed session cookie, bounce
                             back to the SPA
  GET  /api/auth/me        → the signed-in user (or {authenticated:false})
  POST /api/auth/logout    → clear the session
  GET  /api/auth/config    → {enabled} so the login page can show/hide the button
"""
from __future__ import annotations

import os

from authlib.integrations.starlette_client import OAuth

# ---- configuration (from environment / backend/.env) ----

ENTRA_TENANT_ID = os.getenv("ENTRA_TENANT_ID", "").strip()
ENTRA_CLIENT_ID = os.getenv("ENTRA_CLIENT_ID", "").strip()
ENTRA_CLIENT_SECRET = os.getenv("ENTRA_CLIENT_SECRET", "").strip()
# Where Entra sends the browser back — must match a Redirect URI on the app
# registration exactly (default assumes the API is proxied under the SPA origin).
ENTRA_REDIRECT_URI = os.getenv("ENTRA_REDIRECT_URI", "http://localhost:4000/api/auth/callback").strip()

# After a successful sign-in, where to send the browser (the SPA).
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173").strip()

# Signs the session cookie that carries the authenticated user, so it is what
# stands between a forged cookie and someone else's session.
_DEV_SECRET = REDACTED_SECRET
SESSION_SECRET = os.getenv("SESSION_SECRET", _DEV_SECRET)

# APP_ENV=production makes the deployment-critical settings mandatory rather than
# defaulted: a shipped build that silently kept the development secret would sign
# every session with a value published in this repository.
APP_ENV = os.getenv("APP_ENV", "development").strip().lower()
IS_PRODUCTION = APP_ENV == "production"

if IS_PRODUCTION and SESSION_SECRET == _DEV_SECRET:
    raise RuntimeError(
        "SESSION_SECRET is still the development default. Set it to a long random "
        "value before starting with APP_ENV=production — session cookies signed "
        "with the published default can be forged."
    )

# Secure cookies require HTTPS, so this follows the environment rather than being
# hardcoded: forcing it on in local development would break sign-in over http.
SESSION_HTTPS_ONLY = os.getenv("SESSION_HTTPS_ONLY", "1" if IS_PRODUCTION else "0") not in ("0", "false", "")

# Idle lifetime of a signed-in session, in seconds. Default 8 hours — a working
# day, rather than Starlette's fortnight.
SESSION_MAX_AGE = int(os.getenv("SESSION_MAX_AGE", "28800"))

# Role assigned to a first-time SSO user with no app_users row. They can sign in
# but hold no rights until an admin assigns a role in the Admin console.
SSO_DEFAULT_ROLE = os.getenv("SSO_DEFAULT_ROLE", "Viewer").strip() or "Viewer"

# Comma-separated email domains allowed to sign in via SSO (e.g.
# "businessnext.com"). Empty = any account the Entra tenant issues.
SSO_ALLOWED_DOMAINS = [
    d.strip().lower().lstrip("@")
    for d in os.getenv("SSO_ALLOWED_DOMAINS", "businessnext.com").split(",")
    if d.strip()
]


def domain_allowed(email: str) -> bool:
    if not SSO_ALLOWED_DOMAINS:
        return True
    return email.lower().rsplit("@", 1)[-1] in SSO_ALLOWED_DOMAINS

_ENTRA_METADATA = (
    f"https://example.invalid}/v2.0/.well-known/openid-configuration"
)


def sso_enabled() -> bool:
    return bool(ENTRA_TENANT_ID and ENTRA_CLIENT_ID and ENTRA_CLIENT_SECRET)


oauth = OAuth()

if sso_enabled():
    oauth.register(
        name="entra",
        server_metadata_url=_ENTRA_METADATA,
        client_id=ENTRA_CLIENT_ID,
        client_secret=REDACTED_SECRET
        client_kwargs={"scope": "openid email profile"},
    )
