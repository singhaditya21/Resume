/** Org units selectable on a roster line's Team field — alphabetical. */
export const TEAMS = [
  'Delivery Services Group (DSG)',
  'Digital Delivery',
  'ESG',
  'Managed Solutions - CUSTOMER_REDACTED',
  'SAG',
  'SDG',
  'US Delivery',
] as const;

/** Roster line locations — seed/offline fallback; the LOV master is the live source. */
export const LOCATIONS = ['On Site', 'Offshore', 'Nearshore'] as const;
