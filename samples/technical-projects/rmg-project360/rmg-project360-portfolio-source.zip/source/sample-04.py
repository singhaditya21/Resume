"""
Resource Allocation & Project Budgeting API — FastAPI + PostgreSQL.
Endpoints per BRD §14.3; approvals are server-authoritative (§14.4):
the chain is derived from recomputed margin and every sign-off is bound
to the budget signature, so a re-priced budget cannot inherit approvals.
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from psycopg.rows import dict_row
from pydantic import BaseModel
from starlette.middleware.sessions import SessionMiddleware

from . import db, directory, sso
from .security_headers import SecurityHeadersMiddleware
from .passwords import DEFAULT_PASSWORD, pw_hash
from .rbac import (
    ADMIN_PERMISSIONS,
    APP_ROLES,
    DEFAULT_APPROVAL_RULES,
    DEFAULT_ROLE_PERMISSIONS,
    LOV_FIELDS,
    PERMISSIONS,
)
from .engine import (
    APPROVER_ORDER,
    approval_signature,
    compute_budget,
    computed_payload,
    required_approvers,
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    db.init_db()
    directory.startup_sync_if_empty()
    yield
    if db.pool:
        db.pool.close()


app = FastAPI(title="RMG Budgeting API", version="1.0.0", lifespan=lifespan)

# Registered last, so it runs outermost: the headers land on every response,
# including ones short-circuited before the routes (CORS preflight, session
# errors). See security_headers.py for what these cover and what they do not.
app.add_middleware(SecurityHeadersMiddleware, production=sso.IS_PRODUCTION)

# Signed session cookie carries the SSO-authenticated user and the OAuth
# state/nonce during the redirect dance. same_site=lax so the cookie survives
# the top-level redirect back from Entra.
app.add_middleware(
    SessionMiddleware,
    secret_key=REDACTED_SECRET
    same_site="lax",
    # Secure in production so the cookie never travels over plain HTTP, and an
    # 8-hour idle life rather than Starlette's default fortnight.
    https_only=sso.SESSION_HTTPS_ONLY,
    max_age=sso.SESSION_MAX_AGE,
)

# Auth now rides on a session cookie, and a wildcard origin cannot carry
# credentials — browsers reject it. The SPA is served same-origin through the
# Vite proxy in dev; FRONTEND_URL covers a separately-hosted build.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[sso.FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def require_db() -> None:
    # ensure_db retries a lost connection (throttled), so a Postgres that comes
    # back is picked up without restarting the API.
    if not db.ensure_db() or db.pool is None:
        raise HTTPException(status_code=503, detail="database unavailable")


def q(sql: str, params: tuple = ()) -> list[dict]:
    assert db.pool is not None
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        cur = conn.execute(sql, params)
        return cur.fetchall() if cur.description else []


class ProjectIn(BaseModel):
    project_ref: str
    name: str = ""
    currency: str = "INR"
    start_date: str | None = None
    go_live: str | None = None
    created_by: str = "system"
    # Cost drivers of the working copy. Optional so an older client that sends
    # only identity + dates still upserts; None leaves the stored value alone
    # rather than blanking it.
    revenue: float | None = None
    uplift_pct: float | None = None
    effort_cont_pct: float | None = None
    expense_cont_pct: float | None = None
    travel_per_mm: float | None = None
    months: int | None = None


class VersionIn(BaseModel):
    label: str = ""
    state: dict[str, Any]
    actor: str = "web"


class ApprovalIn(BaseModel):
    role: str
    user: str = ""


@app.get("/api/health")
def health():
    return {"ok": True, "db": db.ensure_db()}


# ---------- auth & permissions ----------

class LoginIn(BaseModel):
    username: str
    password: str = ""


def _employee_by_email(email: str) -> dict | None:
    rows = q("SELECT * FROM employees WHERE lower(email) = lower(%s)", (email,))
    return rows[0] if rows else None


def _employee_name(employee_id: int | None) -> str:
    if employee_id is None:
        return "your reporting manager"
    rows = q("SELECT name FROM employees WHERE employee_id = %s", (employee_id,))
    return rows[0]["name"] if rows else "your reporting manager"


@app.post("/api/login")
def login(body: LoginIn, request: Request):
    """Resolve a username/email to its app account, verifying the password, and
    open a signed session cookie on success — that session, not any client
    header, is what authorises later calls.

    Known app users sign in with their assigned role, provided their access
    request is approved. Emails found in the employee directory get an account
    created automatically, pending approval by their reporting manager
    (RM1 → RM2 → RM3 → HOD fallback). Unknown usernames return found=false,
    which the frontend reports as a failed sign-in — there is no fallback."""
    require_db()
    uname = body.username.strip()
    rows = q("SELECT * FROM app_users WHERE lower(username) = lower(%s)", (uname,))
    if rows:
        u = rows[0]
        if not u["active"]:
            raise HTTPException(status_code=403, detail="account is deactivated — contact an administrator")
        stored = u.get("password_hash")
        if stored is None:  # pre-password account — adopt the default lazily
            stored = pw_hash(u["username"], DEFAULT_PASSWORD)
            q("UPDATE app_users SET password_hash = %s WHERE id = %s", (stored, u["id"]))
        if pw_hash(u["username"], body.password) != stored:
            raise HTTPException(status_code=401, detail="incorrect username or password")
        status = u.get("approval_status") or "approved"
        if status == "pending":
            raise HTTPException(
                status_code=403,
                detail=f"access request awaiting approval from {_employee_name(u.get('approver_employee_id'))}",
            )
        if status == "rejected":
            raise HTTPException(
                status_code=403,
                detail="access request was declined — contact your reporting manager or an administrator",
            )
        request.session["user"] = {
            "username": u["username"],
            "displayName": u["display_name"],
            "role": u["app_role"],
        }
        return {
            "found": True,
            "username": u["username"],
            "displayName": u["display_name"],
            "role": u["app_role"],
            "roles": u.get("app_roles") or [u["app_role"]],
        }

    # First sign-in: create the account from the employee directory
    emp = _employee_by_email(uname)
    if not emp:
        return {"found": False}
    if body.password != DEFAULT_PASSWORD:  # first sign-in uses the org default password
        raise HTTPException(status_code=401, detail="incorrect username or password")
    approver_id = (
        emp.get("rm1_employee_id") or emp.get("rm2_employee_id")
        or emp.get("rm3_employee_id") or emp.get("hod_employee_id")
    )
    status = "pending" if approver_id else "approved"  # no RM on record → no one to route to
    q(
        """INSERT INTO app_users (username, display_name, app_role, app_roles, employee_id, approval_status,
                                  approver_employee_id, requested_at, password_hash)
           VALUES (%s,%s,'Viewer',%s,%s,%s,%s,now(),%s)""",
        (emp["email"], emp["name"], ["Viewer"], emp["employee_id"], status, approver_id,
         pw_hash(emp["email"], DEFAULT_PASSWORD)),
    )
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'access.request',%s)",
        (emp["email"], json.dumps({"employee_id": emp["employee_id"], "approver": approver_id, "status": status})),
    )
    if status == "pending":
        raise HTTPException(
            status_code=403,
            detail=f"access request sent to {_employee_name(approver_id)} for approval",
        )
    request.session["user"] = {"username": emp["email"], "displayName": emp["name"], "role": "Viewer"}
    return {"found": True, "username": emp["email"], "displayName": emp["name"], "role": "Viewer", "roles": ["Viewer"]}


# ---------- passwords ----------

class ChangePasswordIn(BaseModel):
    username: str
    current_password: str
    new_password: str


@app.post("/api/users/change-password")
def change_password(body: ChangePasswordIn, request: Request):
    """Self-service password change (Summary → My Account) — own account only.

    body.username used to select the row, so with a known current password any
    account could be targeted. The row now comes from the session; a username
    that disagrees is refused rather than silently redirected."""
    require_db()
    if len(body.new_password) < 8:
        raise HTTPException(status_code=400, detail="new password must be at least 8 characters")
    me = current_user(request)  # validates session, active flag and approval status
    if body.username.strip() and body.username.strip().lower() != me["username"].lower():
        raise HTTPException(status_code=403, detail="you can only change your own password")
    # Re-read for id + password_hash; current_user deliberately does not carry
    # the hash around, since every guarded endpoint calls it.
    rows = q("SELECT id, username, password_hash FROM app_users WHERE lower(username) = lower(%s)", (me["username"],))
    if not rows:
        raise HTTPException(status_code=404, detail="account not found — password management applies to directory accounts")
    u = rows[0]
    stored = u.get("password_hash") or pw_hash(u["username"], DEFAULT_PASSWORD)
    if pw_hash(u["username"], body.current_password) != stored:
        raise HTTPException(status_code=401, detail="current password is incorrect")
    q("UPDATE app_users SET password_hash = %s WHERE id = %s", (pw_hash(u["username"], body.new_password), u["id"]))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'user.password.change',%s)",
        (u["username"], json.dumps({"id": u["id"]})),
    )
    return {"ok": True}


@app.post("/api/admin/users/{user_id}/reset-password")
def admin_reset_password(user_id: int, request: Request):
    """Reset an account back to the org default password."""
    require_db()
    actor = require_perm(request, "admin.users")
    rows = q("SELECT username FROM app_users WHERE id = %s", (user_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="user not found")
    uname = rows[0]["username"]
    q("UPDATE app_users SET password_hash = %s WHERE id = %s", (pw_hash(uname, DEFAULT_PASSWORD), user_id))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.user.password.reset',%s)",
        (actor, json.dumps({"id": user_id, "username": uname})),
    )
    return {"ok": True, "username": uname}


# ---------- access requests (RM approval) ----------

class DecideIn(BaseModel):
    decision: str
    actor: str = ""


@app.get("/api/access-requests")
def list_access_requests(request: Request, approver: str = ""):
    """Pending access requests routed to the signed-in user as reporting manager.

    The approver used to come from a query parameter, so anyone could enumerate
    another manager's pending requests — names, designations, teams and grades
    included. It is now taken from the session; `approver` is accepted and
    ignored so existing clients keep working."""
    require_db()
    me = _employee_by_email(current_user(request)["username"])
    if not me:
        return []
    return q(
        """SELECT u.id, u.username, u.display_name, u.requested_at,
                  e.designation, e.team, e.grade
           FROM app_users u LEFT JOIN employees e ON e.employee_id = u.employee_id
           WHERE u.approval_status = 'pending' AND u.approver_employee_id = %s
           ORDER BY u.requested_at""",
        (me["employee_id"],),
    )


@app.post("/api/access-requests/{user_id}/decide")
def decide_access_request(user_id: int, body: DecideIn, request: Request):
    """Approve or reject a pending request. Allowed for the routed approver, or
    any role holding admin.users.

    The approver is matched against the *signed-in* account. It used to be
    matched against body.actor, which the caller supplied — so anyone could
    approve their own request by naming the approver. body.actor is now ignored
    and kept only so older clients still post successfully."""
    require_db()
    if body.decision not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="decision must be approved or rejected")
    rows = q("SELECT * FROM app_users WHERE id = %s", (user_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="request not found")
    u = rows[0]
    if (u.get("approval_status") or "approved") != "pending":
        raise HTTPException(status_code=409, detail="request is not pending")

    me = current_user(request)  # 401 unless signed in
    actor = me["username"]
    actor_emp = _employee_by_email(actor)
    is_approver = actor_emp is not None and actor_emp["employee_id"] == u.get("approver_employee_id")
    if not is_approver:
        require_perm(request, "admin.users")  # 403 unless an admin role decides

    q("UPDATE app_users SET approval_status = %s WHERE id = %s", (body.decision, user_id))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'access.decide',%s)",
        (actor, json.dumps({"user": u["username"], "decision": body.decision})),
    )
    return {"ok": True, "username": u["username"], "decision": body.decision}


# ---------- employee directory (admin) ----------

# Columns the employee grid may sort on: UI key -> SQL expression. This is a
# whitelist rather than interpolation of whatever the client sends, because a
# sort key cannot be a bound parameter — it reaches ORDER BY as SQL text, so an
# unknown key has to be rejected here instead of passed through.
#
# NULLIF folds '' into NULL so blank cells land with the NULLs, and lower()
# keeps the order case-insensitive ('ashok' next to 'Ashok', not in a separate
# block after the capitals).
EMPLOYEE_SORTS: dict[str, str] = {
    "code": "lower(NULLIF(e.code, ''))",
    "name": "lower(NULLIF(e.name, ''))",
    "email": "lower(NULLIF(e.email, ''))",
    "status": "lower(COALESCE(NULLIF(e.status, ''), 'Active'))",
    "designation": "lower(NULLIF(e.designation, ''))",
    "band": "lower(NULLIF(e.band, ''))",
    "grade": "lower(NULLIF(e.grade, ''))",
    "group_name": "lower(NULLIF(e.group_name, ''))",
    "sub_group": "lower(NULLIF(e.sub_group, ''))",
    "geography": "lower(NULLIF(e.geography, ''))",
    "country": "lower(NULLIF(e.country, ''))",
    "work_location": "lower(NULLIF(e.work_location, ''))",
    "employee_type": "lower(NULLIF(e.employee_type, ''))",
    "gender": "lower(NULLIF(e.gender, ''))",
    "date_of_joining": "e.date_of_joining",
    "total_experience": "lower(NULLIF(e.total_experience, ''))",
    "mobile": "lower(NULLIF(e.mobile, ''))",
    "rm1_name": "lower(NULLIF(e.rm1_name, ''))",
    "rm2_name": "lower(NULLIF(e.rm2_name, ''))",
    "rm3_name": "lower(NULLIF(e.rm3_name, ''))",
    "hod_name": "lower(NULLIF(e.hod_name, ''))",
    "account": "lower(NULLIF(u.approval_status, ''))",
}


@app.get("/api/admin/employees")
def admin_list_employees(
    request: Request,
    search: str = "",
    status: str = "Active",
    page: int = 1,
    page_size: int = 50,
    sort: str = "name",
    order: str = "asc",
):
    """Paged employee list with the linked app account (if any). status=all
    disables the filter; search matches name / email / EC code.

    sort/order drive ORDER BY. Sorting has to happen here rather than in the
    grid: the client only ever holds one page, so sorting there would reorder
    50 rows out of some thousands and quietly claim to be a sort of the whole
    directory."""
    require_db()
    require_perm(request, "admin.users")
    page = max(1, page)
    page_size = min(max(1, page_size), 200)
    where, params = [], []
    if status and status.lower() != "all":
        where.append("COALESCE(e.status, 'Active') = %s")
        params.append(status)
    if search.strip():
        where.append("(e.name ILIKE %s OR e.email ILIKE %s OR e.code ILIKE %s)")
        params.extend([f"%{search.strip()}%"] * 3)
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    sort = sort if sort in EMPLOYEE_SORTS else "name"
    descending = order.lower() == "desc"
    # NULLS LAST both ways: a page of em-dashes is never what someone clicking a
    # header is asking for. employee_id breaks ties so paging stays stable —
    # rows with equal values keep a fixed order instead of being free to
    # reshuffle between two LIMIT/OFFSET queries, which is how a row ends up
    # shown on both page 1 and page 2, or on neither.
    order_sql = (
        f"ORDER BY {EMPLOYEE_SORTS[sort]} {'DESC' if descending else 'ASC'} NULLS LAST, e.employee_id"
    )

    # The COUNT does not join app_users, so it must not reference u.*.
    count_sql = f"SELECT COUNT(*)::int AS n FROM employees e {where_sql}"
    total = q(count_sql, tuple(params))[0]["n"]
    rows = q(
        f"""SELECT e.*, u.id AS account_id, u.app_role AS account_role, u.app_roles AS account_roles,
                   u.approval_status AS account_status, u.active AS account_active
            FROM employees e
            LEFT JOIN app_users u ON lower(u.username) = lower(e.email)
            {where_sql}
            {order_sql}
            LIMIT %s OFFSET %s""",
        (*params, page_size, (page - 1) * page_size),
    )
    return {
        "total": total,
        "page": page,
        "pageSize": page_size,
        "sort": sort,
        "order": "desc" if descending else "asc",
        "rows": rows,
    }


class EmployeeIn(BaseModel):
    name: str
    email: str
    code: str | None = None
    status: str | None = "Active"
    gender: str | None = None
    band: str | None = None
    grade: str | None = None
    designation: str | None = None
    group_name: str | None = None
    sub_group: str | None = None
    geography: str | None = None
    country: str | None = None
    work_location: str | None = None
    employee_type: str | None = None
    date_of_joining: str | None = None
    total_experience: str | None = None
    mobile: str | None = None
    rm1_name: str | None = None
    hod_name: str | None = None


@app.post("/api/admin/employees")
def admin_create_employee(body: EmployeeIn, request: Request):
    """Manual add; unseen dropdown values are auto-registered in the LOVs."""
    require_db()
    actor = require_perm(request, "admin.users")
    try:
        emp = directory.create_employee(body.model_dump())
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.employee.create',%s)",
        (actor, json.dumps({"employee_id": emp["employee_id"], "email": emp["email"]})),
    )
    return emp


@app.patch("/api/admin/employees/{employee_id}")
def admin_update_employee(employee_id: int, body: EmployeeIn, request: Request):
    """Edit profile fields; the row switches to source='manual' so Redash sync
    no longer overwrites its profile."""
    require_db()
    actor = require_perm(request, "admin.users")
    fields = {c: v for c, v in body.model_dump().items() if c in directory.PROFILE_COLS or c == "email"}
    assert db.pool is not None
    with db.pool.connection() as conn:
        directory._auto_lov(conn, fields)  # noqa: SLF001 — same package
    sets = ", ".join(f"{c} = %s" for c in fields)
    rows = q(
        f"UPDATE employees SET {sets}, source = 'manual', synced_at = now() "
        "WHERE employee_id = %s RETURNING *",
        (*fields.values(), employee_id),
    )
    if not rows:
        raise HTTPException(status_code=404, detail="employee not found")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.employee.update',%s)",
        (actor, json.dumps({"employee_id": employee_id})),
    )
    return rows[0]


@app.post("/api/admin/employees/import")
async def admin_import_employees(request: Request, file: UploadFile = File(...)):
    """Upload the HR Excel (.xls/.xlsx) — upserts by email; profile fields from
    the sheet win over future Redash syncs; new dropdown values auto-register."""
    require_db()
    actor = require_perm(request, "admin.users")
    content = await file.read()
    try:
        result = directory.import_excel(content, file.filename or "upload.xlsx")
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))
    except Exception as err:  # noqa: BLE001 — parse errors surface cleanly
        raise HTTPException(status_code=400, detail=f"could not read the file: {err}")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.employees.import',%s)",
        (actor, json.dumps({"file": file.filename, **result})),
    )
    return result


@app.post("/api/admin/employees/{employee_id}/ensure-account")
def admin_ensure_account(employee_id: int, request: Request):
    """Reset PW from the employee grid: resets an existing account to the
    default password, or creates a pre-approved Viewer account at the default
    (admin action skips RM approval)."""
    require_db()
    actor = require_perm(request, "admin.users")
    rows = q("SELECT * FROM employees WHERE employee_id = %s", (employee_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="employee not found")
    emp = rows[0]
    if not emp.get("email"):
        raise HTTPException(status_code=400, detail="employee has no email address")
    acct = q("SELECT id, username FROM app_users WHERE lower(username) = lower(%s)", (emp["email"],))
    if acct:
        uname = acct[0]["username"]
        q("UPDATE app_users SET password_hash = %s WHERE id = %s", (pw_hash(uname, DEFAULT_PASSWORD), acct[0]["id"]))
        action = "reset"
    else:
        q(
            """INSERT INTO app_users (username, display_name, app_role, app_roles, employee_id,
                                      approval_status, password_hash)
               VALUES (%s,%s,'Viewer',%s,%s,'approved',%s)""",
            (emp["email"], emp["name"], ["Viewer"], employee_id, pw_hash(emp["email"], DEFAULT_PASSWORD)),
        )
        action = "created"
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.account.ensure',%s)",
        (actor, json.dumps({"employee_id": employee_id, "email": emp["email"], "result": action})),
    )
    return {"ok": True, "result": action, "username": emp["email"]}


@app.post("/api/admin/employees/sync")
def admin_sync_employees(request: Request):
    """Pull the HR master from Redash and upsert the employees table."""
    require_db()
    actor = require_perm(request, "admin.users")
    try:
        n = directory.sync_employees()
    except Exception as err:  # noqa: BLE001 — surface a clean message
        raise HTTPException(status_code=502, detail=f"sync failed: {err}")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.employees.sync',%s)",
        (actor, json.dumps({"rows": n})),
    )
    return {"ok": True, "rows": n}


@app.get("/api/admin/employees/stats")
def admin_employee_stats(request: Request):
    require_db()
    require_perm(request, "admin.users")
    rows = q("SELECT COUNT(*)::int AS n, MAX(synced_at) AS last_sync FROM employees")
    return {"count": rows[0]["n"], "lastSync": str(rows[0]["last_sync"]) if rows[0]["last_sync"] else None,
            "configured": bool(directory.source_url())}


# ---------- SSO (Microsoft Entra ID / OIDC) ----------

@app.get("/api/auth/config")
def auth_config():
    """Lets the login page show the 'Sign in with Microsoft' button only when SSO is wired up."""
    return {"enabled": sso.sso_enabled(), "provider": "Microsoft Entra ID"}


@app.get("/api/auth/login")
async def auth_login(request: Request):
    """Kick off the OIDC authorization-code flow — full-page redirect to Entra."""
    if not sso.sso_enabled():
        raise HTTPException(status_code=503, detail="SSO is not configured")
    return await sso.oauth.entra.authorize_redirect(request, sso.ENTRA_REDIRECT_URI)


def _sso_provision(email: str, name: str) -> dict:
    """Map an Entra identity to an app_users row. First-time users are created
    with SSO_DEFAULT_ROLE (no rights until an admin assigns one)."""
    rows = q("SELECT username, display_name, app_role, active FROM app_users WHERE lower(username) = lower(%s)", (email,))
    if rows:
        u = rows[0]
        if not u["active"]:
            raise HTTPException(status_code=403, detail="account is deactivated — contact an administrator")
        return {"username": u["username"], "displayName": u["display_name"] or name, "role": u["app_role"]}
    q(
        "INSERT INTO app_users (username, display_name, app_role) VALUES (%s,%s,%s)",
        (email, name, sso.SSO_DEFAULT_ROLE),
    )
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'sso.user.provision',%s)",
        (email, json.dumps({"email": email, "role": sso.SSO_DEFAULT_ROLE})),
    )
    return {"username": email, "displayName": name, "role": sso.SSO_DEFAULT_ROLE}


@app.get("/api/auth/callback")
async def auth_callback(request: Request):
    """Entra redirects here with the code. Validate, map to a role, store in session, bounce to the SPA."""
    if not sso.sso_enabled():
        raise HTTPException(status_code=503, detail="SSO is not configured")
    try:
        token = await sso.oauth.entra.authorize_access_token(request)
    except Exception as err:  # noqa: BLE001 — surface as a clean redirect, not a 500
        return RedirectResponse(f"{sso.FRONTEND_URL}/?sso_error=1")
    claims = token.get("userinfo") or {}
    email = (claims.get("email") or claims.get("preferred_username") or "").strip()
    name = (claims.get("name") or email).strip()
    if not email:
        return RedirectResponse(f"{sso.FRONTEND_URL}/?sso_error=1")
    if not sso.domain_allowed(email):
        return RedirectResponse(f"{sso.FRONTEND_URL}/?sso_error=domain")
    if not db.db_available():
        # No directory to resolve roles against — sign in with the default role.
        user = {"username": email, "displayName": name, "role": sso.SSO_DEFAULT_ROLE}
    else:
        user = _sso_provision(email, name)
    request.session["user"] = user
    return RedirectResponse(sso.FRONTEND_URL)


@app.get("/api/auth/me")
def auth_me(request: Request):
    """The SSO-authenticated user restored from the session cookie, if any."""
    user = request.session.get("user")
    if not user:
        return {"authenticated": False}
    return {"authenticated": True, **user}


@app.post("/api/auth/logout")
def auth_logout(request: Request):
    request.session.pop("user", None)
    return {"ok": True}


def _approval_rules() -> dict:
    """The live margin-tier rules from app_config; BRD defaults when unset."""
    rows = q("SELECT value FROM app_config WHERE key = 'approval_rules'")
    return rows[0]["value"] if rows else DEFAULT_APPROVAL_RULES


@app.get("/api/approval-rules")
def get_approval_rules(request: Request):
    """The live margin-tier approval rules — business configuration, so it needs
    a session. The frontend falls back to the BRD defaults when this 401s."""
    require_db()
    current_user(request)
    return _approval_rules()


class ApprovalRulesIn(BaseModel):
    tiers: list[dict]
    fallback: list[str]


@app.put("/api/admin/approval-rules")
def admin_put_approval_rules(body: ApprovalRulesIn, request: Request):
    """Replace the margin-tier table. Approver chains are normalised to the
    canonical PO → HOD → COO order; thresholds must decrease top-down."""
    require_db()
    actor = require_perm(request, "admin.rules")
    if not body.tiers:
        raise HTTPException(status_code=400, detail="at least one tier is required")

    def norm_chain(approvers: list) -> list[str]:
        for a in approvers:
            if a not in APPROVER_ORDER:
                raise HTTPException(status_code=400, detail=f"unknown approver {a}")
        return [r for r in APPROVER_ORDER if r in approvers]

    tiers = []
    prev = None
    for i, t in enumerate(body.tiers):
        try:
            threshold = float(t.get("threshold"))
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail=f"tier {i + 1}: threshold must be a number")
        if not (0 <= threshold <= 100):
            raise HTTPException(status_code=400, detail=f"tier {i + 1}: threshold must be 0–100")
        if prev is not None and threshold >= prev:
            raise HTTPException(status_code=400, detail="thresholds must decrease from top to bottom")
        prev = threshold
        op = t.get("op", "gte")
        if op not in ("gte", "gt"):
            raise HTTPException(status_code=400, detail=f"tier {i + 1}: op must be gte or gt")
        tiers.append({"threshold": threshold, "op": op, "approvers": norm_chain(t.get("approvers", []))})

    rules = {"tiers": tiers, "fallback": norm_chain(body.fallback)}
    q(
        "INSERT INTO app_config (key, value) VALUES ('approval_rules', %s) "
        "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
        (json.dumps(rules),),
    )
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.rules.update',%s)",
        (actor, json.dumps(rules)),
    )
    return rules


def _permission_matrix() -> dict[str, list[str]]:
    rows = q("SELECT app_role, permission FROM role_permissions ORDER BY app_role, permission")
    matrix: dict[str, list[str]] = {r: [] for r in APP_ROLES}
    for row in rows:
        matrix.setdefault(row["app_role"], []).append(row["permission"])
    return matrix


@app.get("/api/permissions")
def get_permissions(request: Request):
    """The live role → permission matrix (frontend falls back to defaults when
    this 401s, which is what the login page now gets)."""
    require_db()
    current_user(request)
    return _permission_matrix()


def current_user(request: Request) -> dict:
    """The signed-in account, taken from the signed session cookie and re-read
    from app_users on every request — so deactivating an account or revoking a
    role takes effect immediately instead of at next login."""
    sess = request.session.get("user") or {}
    username = sess.get("username")
    if not username:
        raise HTTPException(status_code=401, detail="not signed in")
    require_db()
    rows = q(
        "SELECT username, display_name, app_role, app_roles, active, approval_status "
        "FROM app_users WHERE lower(username) = lower(%s)",
        (username,),
    )
    if not rows:
        raise HTTPException(status_code=401, detail="account no longer exists")
    u = rows[0]
    if not u["active"]:
        raise HTTPException(status_code=403, detail="account is deactivated — contact an administrator")
    if (u.get("approval_status") or "approved") != "approved":
        raise HTTPException(status_code=403, detail="access request is not approved")
    return u


def acting_role(request: Request, user: dict) -> str:
    """The role the client asked to act as. X-App-Role is now only a *request*:
    it is honoured when the account actually holds that role, and ignored
    otherwise. It can no longer grant anything on its own."""
    allowed = user.get("app_roles") or [user["app_role"]]
    asked = (request.headers.get("X-App-Role") or "").strip()
    return asked if asked and asked in allowed else user["app_role"]


def require_perm(request: Request, perm: str) -> str:
    """Authorise against the session, never against a client-claimed role.
    Returns the authenticated username, which is also the audit-log actor —
    previously the actor was whatever the caller put in the header."""
    user = current_user(request)
    role = acting_role(request, user)
    granted = _permission_matrix().get(role) or DEFAULT_ROLE_PERMISSIONS.get(role, [])
    if perm not in granted:
        raise HTTPException(status_code=403, detail=f"role {role} lacks {perm}")
    return user["username"]


# ---------- admin: users ----------

class UserIn(BaseModel):
    username: str
    display_name: str = ""
    app_role: str = "Viewer"
    active: bool = True


class UserPatch(BaseModel):
    display_name: str | None = None
    app_role: str | None = None
    active: bool | None = None
    app_roles: list[str] | None = None


def _check_role(app_role: str) -> None:
    if app_role not in APP_ROLES:
        raise HTTPException(status_code=400, detail=f"app_role must be one of {', '.join(APP_ROLES)}")


USER_COLS = (
    "id, username, display_name, app_role, app_roles, active, created_at, "
    "employee_id, approval_status, approver_employee_id, requested_at"
)


@app.get("/api/admin/users")
def admin_list_users(
    request: Request,
    search: str = "",
    role: str = "",
    status: str = "",
    page: int = 1,
    page_size: int = 20,
):
    """Paged account list. Search matches the username (an email) or the display
    name. Previously this returned every row unpaged, which was fine at five
    accounts and is not at several thousand.

    Explicit column list, never SELECT * — password_hash has no client use and
    was once returned to every caller of this endpoint."""
    require_db()
    require_perm(request, "admin.users")
    page = max(1, page)
    page_size = min(max(1, page_size), 200)  # same cap as the employee grid

    where, params = [], []
    if search.strip():
        where.append("(username ILIKE %s OR display_name ILIKE %s)")
        params.extend([f"%{search.strip()}%"] * 2)
    if role.strip():
        where.append("%s = ANY(COALESCE(app_roles, ARRAY[app_role]))")
        params.append(role.strip())
    if status.strip():
        where.append("COALESCE(approval_status, 'approved') = %s")
        params.append(status.strip())
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    total = q(f"SELECT COUNT(*)::int AS n FROM app_users {where_sql}", tuple(params))[0]["n"]
    rows = q(
        f"SELECT {USER_COLS} FROM app_users {where_sql} ORDER BY username LIMIT %s OFFSET %s",
        (*params, page_size, (page - 1) * page_size),
    )
    return {"total": total, "page": page, "pageSize": page_size, "rows": rows}


@app.post("/api/admin/users")
def admin_create_user(body: UserIn, request: Request):
    require_db()
    actor = require_perm(request, "admin.users")
    username = body.username.strip()
    if not username:
        raise HTTPException(status_code=400, detail="username is required")
    _check_role(body.app_role)
    if q("SELECT 1 FROM app_users WHERE lower(username) = lower(%s)", (username,)):
        raise HTTPException(status_code=409, detail="username already exists")
    rows = q(
        "INSERT INTO app_users (username, display_name, app_role, app_roles, active, password_hash) "
        "VALUES (%s,%s,%s,%s,%s,%s) RETURNING *",
        (username, body.display_name.strip(), body.app_role, [body.app_role], body.active,
         pw_hash(username, DEFAULT_PASSWORD)),
    )
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.user.create',%s)",
        (actor, json.dumps({"username": username, "app_role": body.app_role})),
    )
    return rows[0]


@app.patch("/api/admin/users/{user_id}")
def admin_update_user(user_id: int, body: UserPatch, request: Request):
    require_db()
    actor = require_perm(request, "admin.users")
    if body.app_role is not None:
        _check_role(body.app_role)
    if body.app_roles is not None:
        if not body.app_roles:
            raise HTTPException(status_code=400, detail="a user needs at least one role")
        for r in body.app_roles:
            _check_role(r)
    sets, params = [], []
    for col, val in (("display_name", body.display_name), ("app_role", body.app_role), ("active", body.active)):
        if val is not None:
            sets.append(f"{col} = %s")
            params.append(val.strip() if isinstance(val, str) else val)
    if body.app_roles is not None:
        roles = [r for r in APP_ROLES if r in body.app_roles]  # canonical order, de-duplicated
        sets.append("app_roles = %s")
        params.append(roles)
        # keep the default acting role inside the assigned set
        sets.append("app_role = CASE WHEN app_role = ANY(%s) THEN app_role ELSE %s END")
        params.extend([roles, roles[0]])
    if not sets:
        raise HTTPException(status_code=400, detail="nothing to update")
    rows = q(f"UPDATE app_users SET {', '.join(sets)} WHERE id = %s RETURNING *", (*params, user_id))
    if not rows:
        raise HTTPException(status_code=404, detail="user not found")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.user.update',%s)",
        (actor, json.dumps({"id": user_id, **body.model_dump(exclude_none=True)})),
    )
    return rows[0]


@app.delete("/api/admin/users/{user_id}")
def admin_delete_user(user_id: int, request: Request):
    require_db()
    actor = require_perm(request, "admin.users")
    rows = q("DELETE FROM app_users WHERE id = %s RETURNING username", (user_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="user not found")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.user.delete',%s)",
        (actor, json.dumps({"id": user_id, "username": rows[0]["username"]})),
    )
    return {"ok": True}


# ---------- admin: role permissions ----------

class PermissionsIn(BaseModel):
    matrix: dict[str, list[str]]


@app.put("/api/admin/permissions")
def admin_put_permissions(body: PermissionsIn, request: Request):
    """Replace the role → permission matrix. Admin's admin.* grants are forced
    back on (lockout guard)."""
    require_db()
    actor = require_perm(request, "admin.permissions")
    for role, perms in body.matrix.items():
        _check_role(role)
        for p in perms:
            if p not in PERMISSIONS:
                raise HTTPException(status_code=400, detail=f"unknown permission {p}")
    matrix = {r: sorted(set(body.matrix.get(r, []))) for r in APP_ROLES}
    matrix["Admin"] = sorted(set(matrix["Admin"]) | set(ADMIN_PERMISSIONS))

    assert db.pool is not None
    with db.pool.connection() as conn:  # single transaction
        conn.execute("DELETE FROM role_permissions")
        conn.cursor().executemany(
            "INSERT INTO role_permissions (app_role, permission) VALUES (%s,%s)",
            [(r, p) for r, perms in matrix.items() for p in perms],
        )
        conn.execute(
            "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.permissions.update',%s)",
            (actor, json.dumps(matrix)),
        )
    return matrix


# ---------- admin: field LOVs ----------

class LovIn(BaseModel):
    id: str | None = None
    name: str


class LovPatch(BaseModel):
    name: str | None = None
    active: bool | None = None


def _check_field(field: str) -> None:
    if field not in LOV_FIELDS:
        raise HTTPException(status_code=400, detail=f"field must be one of {', '.join(LOV_FIELDS)}")


@app.get("/api/lov/{field}")
def list_lov(field: str):
    """Active values for a dropdown field (public — feeds the pickers)."""
    require_db()
    _check_field(field)
    order = "name" if field == "role" else "sort, name"
    return q(f"SELECT id, name FROM lov_values WHERE field = %s AND active ORDER BY {order}", (field,))


@app.get("/api/admin/lov")
def admin_list_lov(request: Request):
    """All LOV values, active and inactive, for the Admin console."""
    require_db()
    require_perm(request, "admin.lov")
    return q("SELECT field, id, name, active, sort FROM lov_values ORDER BY field, sort, name")


@app.post("/api/admin/lov/{field}")
def admin_add_lov(field: str, body: LovIn, request: Request):
    require_db()
    actor = require_perm(request, "admin.lov")
    _check_field(field)
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    rows = q("SELECT id, name FROM lov_values WHERE field = %s", (field,))
    if any(r["name"].lower() == name.lower() for r in rows):
        raise HTTPException(status_code=409, detail="a value with this name already exists")
    value_id = (body.id or "").strip()
    if not value_id:
        if field == "role":
            # Designations use numeric portal-style lookup codes; generate the next one ≥ 200000
            numeric = [int(r["id"]) for r in rows if r["id"].isdigit()]
            value_id = str(max([199999, *numeric]) + 1)
        else:
            value_id = name
    if any(r["id"] == value_id for r in rows):
        raise HTTPException(status_code=409, detail="a value with this id already exists")
    sort = len(rows)
    out = q(
        "INSERT INTO lov_values (field, id, name, sort) VALUES (%s,%s,%s,%s) RETURNING field, id, name, active, sort",
        (field, value_id, name, sort),
    )
    if field == "role":
        # keep the roles master in step — it anchors the roster_lines.role_id FK
        q("INSERT INTO roles (id, name) VALUES (%s,%s) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name", (value_id, name))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.lov.add',%s)",
        (actor, json.dumps({"field": field, "id": value_id, "name": name})),
    )
    return out[0]


@app.delete("/api/admin/lov/{field}/{value_id}")
def admin_delete_lov(field: str, value_id: str, request: Request):
    """Remove a value from the list (hard delete). Historic budgets keep their
    denormalised labels; for designations the roles master row is kept so
    roster_lines.role_id references stay valid."""
    require_db()
    actor = require_perm(request, "admin.lov")
    _check_field(field)
    rows = q("DELETE FROM lov_values WHERE field = %s AND id = %s RETURNING name", (field, value_id))
    if not rows:
        raise HTTPException(status_code=404, detail="value not found")
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.lov.delete',%s)",
        (actor, json.dumps({"field": field, "id": value_id, "name": rows[0]["name"]})),
    )
    return {"ok": True}


@app.patch("/api/admin/lov/{field}/{value_id}")
def admin_update_lov(field: str, value_id: str, body: LovPatch, request: Request):
    """Rename a value (and optionally toggle active — kept for API compatibility)."""
    require_db()
    actor = require_perm(request, "admin.lov")
    _check_field(field)
    sets, params = [], []
    if body.name is not None:
        name = body.name.strip()
        if not name:
            raise HTTPException(status_code=400, detail="name cannot be blank")
        sets.append("name = %s")
        params.append(name)
    if body.active is not None:
        sets.append("active = %s")
        params.append(body.active)
    if not sets:
        raise HTTPException(status_code=400, detail="nothing to update")
    rows = q(
        f"UPDATE lov_values SET {', '.join(sets)} WHERE field = %s AND id = %s RETURNING field, id, name, active, sort",
        (*params, field, value_id),
    )
    if not rows:
        raise HTTPException(status_code=404, detail="value not found")
    if field == "role" and body.name is not None:
        q("UPDATE roles SET name = %s WHERE id = %s", (rows[0]["name"], value_id))
    q(
        "INSERT INTO audit_log (actor, action, detail_json) VALUES (%s,'admin.lov.update',%s)",
        (actor, json.dumps({"field": field, "id": value_id, **body.model_dump(exclude_none=True)})),
    )
    return rows[0]


# ---------- roles (designation lookup) ----------

@app.get("/api/roles")
def list_roles():
    """Role master for the Role dropdown — active designations, alphabetical."""
    require_db()
    return q("SELECT id, name FROM lov_values WHERE field = 'role' AND active ORDER BY name")


# ---------- projects ----------

@app.post("/api/projects")
def upsert_project(body: ProjectIn, request: Request):
    require_db()
    require_perm(request, "budget.edit")
    # COALESCE(EXCLUDED.x, projects.x) so a partial payload updates what it sent
    # and preserves the rest — an older client cannot blank the cost drivers.
    rows = q(
        """INSERT INTO projects (project_ref, name, currency, start_date, go_live, created_by,
                                 revenue, uplift_pct, effort_cont_pct, expense_cont_pct,
                                 travel_per_mm, months, updated_at)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
           ON CONFLICT (project_ref) DO UPDATE
             SET name             = EXCLUDED.name,
                 start_date       = EXCLUDED.start_date,
                 go_live          = EXCLUDED.go_live,
                 revenue          = COALESCE(EXCLUDED.revenue,          projects.revenue),
                 uplift_pct       = COALESCE(EXCLUDED.uplift_pct,       projects.uplift_pct),
                 effort_cont_pct  = COALESCE(EXCLUDED.effort_cont_pct,  projects.effort_cont_pct),
                 expense_cont_pct = COALESCE(EXCLUDED.expense_cont_pct, projects.expense_cont_pct),
                 travel_per_mm    = COALESCE(EXCLUDED.travel_per_mm,    projects.travel_per_mm),
                 months           = COALESCE(EXCLUDED.months,           projects.months),
                 updated_at       = now()
           RETURNING *""",
        (body.project_ref, body.name, body.currency, body.start_date or None, body.go_live or None,
         body.created_by, body.revenue, body.uplift_pct, body.effort_cont_pct,
         body.expense_cont_pct, body.travel_per_mm, body.months),
    )
    q(
        "INSERT INTO audit_log (project_id, actor, action, detail_json) VALUES (%s,%s,'project.upsert',%s)",
        (rows[0]["id"], body.created_by, json.dumps({"project_ref": body.project_ref, "name": body.name})),
    )
    return rows[0]


@app.get("/api/projects")
def list_projects(request: Request):
    require_db()
    current_user(request)  # budget data is commercial — signed-in users only
    return q(
        """SELECT p.*, COUNT(v.id)::int AS version_count, MAX(v.created_at) AS last_saved
           FROM projects p LEFT JOIN budget_versions v ON v.project_id = p.id
           GROUP BY p.id ORDER BY p.id"""
    )


def _find_project(ref: str) -> dict:
    rows = q("SELECT * FROM projects WHERE project_ref = %s OR id::text = %s", (ref, ref))
    if not rows:
        raise HTTPException(status_code=404, detail="project not found")
    return rows[0]


@app.get("/api/projects/{ref}")
def get_project(ref: str, request: Request):
    require_db()
    current_user(request)
    return _find_project(ref)


# ---------- versions ----------

@app.post("/api/projects/{ref}/versions")
def save_version(ref: str, body: VersionIn, request: Request):
    """Save a new immutable budget version. The server recomputes totals — never trusts the client."""
    require_db()
    require_perm(request, "version.manage")
    state = body.state
    if "assumptions" not in state or not isinstance(state.get("roster"), list):
        raise HTTPException(status_code=400, detail="body must include a full BudgetState in `state`")
    project = _find_project(ref)

    c = compute_budget(state)
    signature = approval_signature(c)

    assert db.pool is not None
    with db.pool.connection() as conn:  # single transaction
        conn.row_factory = dict_row
        ver_no = conn.execute(
            "SELECT COALESCE(MAX(version_no),0)+1 AS n FROM budget_versions WHERE project_id=%s",
            (project["id"],),
        ).fetchone()["n"]
        version = conn.execute(
            """INSERT INTO budget_versions (project_id, version_no, label, state_jsonb, total_cost, margin_pct, signature)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
            (project["id"], ver_no, body.label or f"Revision {ver_no}", json.dumps(state), c["totalCost"], c["mpct"], signature),
        ).fetchone()

        for p in state.get("phases", []):
            conn.execute(
                "INSERT INTO phases (version_id, name, start_month, end_month) VALUES (%s,%s,%s,%s)",
                (version["id"], p.get("n", ""), p.get("s", 1), p.get("e", 1)),
            )
        for r in state.get("roster", []):
            line = conn.execute(
                """INSERT INTO roster_lines (version_id, team, role, role_id, location, cost_per_mm, start_month, duration)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
                (version["id"], r.get("team", ""), r.get("role", ""), r.get("roleId"), r.get("loc", "Offshore"),
                 r.get("cpm", 0), r.get("start", 1), r.get("dur", 0)),
            ).fetchone()
            for m, mm in enumerate(r.get("alloc", []), start=1):
                if mm:
                    conn.execute(
                        "INSERT INTO allocations (roster_line_id, month_no, mm) VALUES (%s,%s,%s)",
                        (line["id"], m, mm),
                    )
        conn.execute(
            "INSERT INTO audit_log (project_id, version_id, actor, action, detail_json) VALUES (%s,%s,%s,'version.save',%s)",
            (project["id"], version["id"], body.actor, json.dumps({"label": body.label, "totalCost": c["totalCost"], "marginPct": c["mpct"]})),
        )

    version["computed"] = computed_payload(state, _approval_rules())
    return version


@app.get("/api/projects/{ref}/versions")
def list_versions(ref: str, request: Request):
    """List versions; baseline = first, latest = last (BRD §9)."""
    require_db()
    current_user(request)  # snapshots carry revenue, cost and per-role rates
    project = _find_project(ref)
    rows = q(
        """SELECT id, version_no, label, created_at, state_jsonb, total_cost, margin_pct, signature
           FROM budget_versions WHERE project_id = %s ORDER BY version_no""",
        (project["id"],),
    )
    rules = _approval_rules()
    for row in rows:
        row["computed"] = computed_payload(row["state_jsonb"], rules)
    return rows


@app.get("/api/versions/{version_id}/computed")
def version_computed(version_id: int):
    """Server-computed totals, P&L, phase & monthly roll-ups."""
    require_db()
    rows = q("SELECT * FROM budget_versions WHERE id = %s", (version_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="version not found")
    return computed_payload(rows[0]["state_jsonb"], _approval_rules())


@app.delete("/api/versions/{version_id}")
def delete_version(version_id: int):
    require_db()
    rows = q("DELETE FROM budget_versions WHERE id = %s RETURNING project_id, version_no", (version_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="version not found")
    q(
        "INSERT INTO audit_log (project_id, version_id, action, detail_json) VALUES (%s,%s,'version.delete',%s)",
        (rows[0]["project_id"], version_id, json.dumps({"version_no": rows[0]["version_no"]})),
    )
    return {"ok": True}


# ---------- approvals (server-authoritative, BRD §8 + §14.4) ----------

def _approval_state(version_id: int) -> dict:
    rows = q("SELECT * FROM budget_versions WHERE id = %s", (version_id,))
    if not rows:
        raise HTTPException(status_code=404, detail="version not found")
    version = rows[0]
    state = version["state_jsonb"]
    c = compute_budget(state)
    signature = approval_signature(c)
    required = required_approvers(c["mpct"], _approval_rules())
    # Only decisions bound to the *current* signature count
    decisions = q(
        """SELECT DISTINCT ON (approver_role) approver_role, decision, approver_user, decided_at
           FROM approvals WHERE version_id = %s AND signature = %s
           ORDER BY approver_role, decided_at DESC""",
        (version_id, signature),
    )
    approved = {
        d["approver_role"]: {"user": d["approver_user"], "at": str(d["decided_at"])}
        for d in decisions
        if d["decision"] == "approved"
    }
    return {"version": version, "c": c, "signature": signature, "required": required, "approved": approved}


@app.get("/api/versions/{version_id}/approvals")
def get_approvals(version_id: int, request: Request):
    require_db()
    current_user(request)  # margin and signature are commercial data
    s = _approval_state(version_id)
    outstanding = [r for r in s["required"] if r not in s["approved"]]
    status = "auto-approved" if not s["required"] else ("approved" if not outstanding else "pending")
    return {
        "marginPct": s["c"]["mpct"],
        "signature": s["signature"],
        "required": s["required"],
        "approved": s["approved"],
        "status": status,
        "outstanding": outstanding,
    }


@app.post("/api/versions/{version_id}/approve")
def approve(version_id: int, body: ApprovalIn, request: Request):
    """Sequential, signature-bound sign-off. The server derives the chain — the client cannot supply it.

    These routes were reachable without a session: anyone able to reach the API
    could sign off a budget, and body.user was written to the audit log verbatim,
    so the record named whoever the caller claimed to be."""
    require_db()
    actor = require_perm(request, f"approve.{body.role}") if body.role in APPROVER_ORDER else current_user(request)["username"]
    if body.role not in APPROVER_ORDER:
        raise HTTPException(status_code=400, detail=f"role must be one of {', '.join(APPROVER_ORDER)}")
    s = _approval_state(version_id)
    if body.role not in s["required"]:
        raise HTTPException(status_code=409, detail=f"margin {s['c']['mpct'] * 100:.1f}% does not require {body.role}")
    idx = s["required"].index(body.role)
    prior_unsigned = [r for r in s["required"][:idx] if r not in s["approved"]]
    if prior_unsigned:
        raise HTTPException(status_code=409, detail=f"awaiting prior approver(s): {', '.join(prior_unsigned)}")

    q(
        "INSERT INTO approvals (version_id, signature, approver_role, approver_user, decision) VALUES (%s,%s,%s,%s,'approved')",
        (version_id, s["signature"], body.role, actor),
    )
    q(
        "INSERT INTO audit_log (project_id, version_id, actor, action, detail_json) VALUES (%s,%s,%s,'approval.sign',%s)",
        (s["version"]["project_id"], version_id, actor, json.dumps({"role": body.role, "signature": s["signature"]})),
    )
    return {"ok": True}


@app.post("/api/versions/{version_id}/revoke")
def revoke(version_id: int, body: ApprovalIn, request: Request):
    """Undo cascades: revoking a role also revokes every later role in [PO, HOD, COO]."""
    require_db()
    actor = require_perm(request, f"approve.{body.role}") if body.role in APPROVER_ORDER else current_user(request)["username"]
    if body.role not in APPROVER_ORDER:
        raise HTTPException(status_code=400, detail=f"role must be one of {', '.join(APPROVER_ORDER)}")
    s = _approval_state(version_id)
    cascade = APPROVER_ORDER[APPROVER_ORDER.index(body.role):]
    for r in cascade:
        if r in s["approved"]:
            q(
                "INSERT INTO approvals (version_id, signature, approver_role, approver_user, decision) VALUES (%s,%s,%s,%s,'revoked')",
                (version_id, s["signature"], r, body.user or r),
            )
    q(
        "INSERT INTO audit_log (project_id, version_id, actor, action, detail_json) VALUES (%s,%s,%s,'approval.revoke',%s)",
        (s["version"]["project_id"], version_id, body.user or body.role, json.dumps({"role": body.role, "cascade": cascade})),
    )
    return {"ok": True}
