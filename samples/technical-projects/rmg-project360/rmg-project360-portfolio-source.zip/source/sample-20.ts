import "@emotion/react";
import type { DsTheme } from "./theme";

// Makes `props.theme` inside Emotion resolve to our theme rather than `{}`.
declare module "@emotion/react" {
  export interface Theme extends DsTheme {}
}
