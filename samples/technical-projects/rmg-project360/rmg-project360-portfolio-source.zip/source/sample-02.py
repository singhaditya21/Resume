"""
Pure costing engine — BRD §4/§8. Python port of shared/src/engine.ts.
The server is the source of truth: it recomputes totals, margin and the
required approval chain from the stored snapshot and never trusts the client.
The math must stay identical to the TypeScript engine used by the React app
(both are covered by the §13 acceptance figures).
"""
from __future__ import annotations

from typing import Any

APPROVER_ORDER = ["PO", "HOD", "COO"]


def num(v: Any) -> float:
    """Coerce any input to a finite number; NaN never propagates (BRD §11)."""
    try:
        n = float(v)
    except (TypeError, ValueError):
        return 0.0
    return n if n == n and n not in (float("inf"), float("-inf")) else 0.0


def compute_budget(state: dict) -> dict:
    """BRD §4.1–§4.3: per-month roll-ups, totals and P&L."""
    a = state.get("assumptions", {})
    n = max(1, round(num(a.get("months", 12))))
    uplift = num(a.get("uplift")) / 100.0
    eff = num(a.get("eff")) / 100.0
    exp = num(a.get("exp")) / 100.0
    travel_rate = num(a.get("travel"))

    base_m = [0.0] * n
    on_m = [0.0] * n
    off_m = [0.0] * n

    for r in state.get("roster", []):
        cpm = num(r.get("cpm"))
        for j, cell in enumerate(r.get("alloc", [])):
            if j >= n:
                break
            mm = num(cell)
            base_m[j] += mm * cpm
            if r.get("loc") == "On Site":
                on_m[j] += mm
            else:
                off_m[j] += mm

    burd_m = [b * (1 + uplift) * (1 + eff) for b in base_m]
    trav_m = [o * travel_rate * (1 + exp) for o in on_m]

    base_tot = sum(base_m)
    burd_tot = sum(burd_m)
    trav_tot = sum(trav_m)
    total_cost = burd_tot + trav_tot
    on_mm = sum(on_m)
    off_mm = sum(off_m)
    mm = on_mm + off_mm
    rev = num(a.get("rev"))
    gm = rev - total_cost
    mpct = 0.0 if rev == 0 else gm / rev

    return {
        "baseM": base_m, "burdM": burd_m, "travM": trav_m, "onM": on_m, "offM": off_m,
        "baseTot": base_tot, "burdTot": burd_tot, "travTot": trav_tot, "totalCost": total_cost,
        "onMM": on_mm, "offMM": off_mm, "mm": mm, "rev": rev, "gm": gm, "mpct": mpct,
        "rate": 0.0 if mm == 0 else total_cost / mm,
    }


def compute_phase_rollups(state: dict, c: dict | None = None) -> list[dict]:
    """BRD §4.4: phase roll-up over fixed month bands."""
    C = c or compute_budget(state)
    n = len(C["baseM"])
    total = C["totalCost"] or 1.0
    out = []
    for p in state.get("phases", []):
        effort = base = burdened = travel = 0.0
        for m in range(int(num(p.get("s", 1))), int(num(p.get("e", 0))) + 1):
            j = m - 1
            if j < 0 or j >= n:
                continue
            base += C["baseM"][j]
            burdened += C["burdM"][j]
            travel += C["travM"][j]
            effort += C["onM"][j] + C["offM"][j]
        cost = burdened + travel
        out.append({
            "name": p.get("n", ""), "s": p.get("s"), "e": p.get("e"),
            "effortMM": effort, "base": base, "burdened": burdened,
            "travel": travel, "cost": cost, "share": cost / total,
        })
    return out


def required_approvers(margin_pct: float, rules: dict | None = None) -> list[str]:
    """BRD §8.1 tier table (margin as fraction, e.g. 0.28). Configurable:
    `rules` = {"tiers": [{"threshold": %, "op": "gte"|"gt", "approvers": [...]}, ...],
    "fallback": [...]} evaluated top-down; defaults mirror the BRD."""
    if rules is None:
        from .rbac import DEFAULT_APPROVAL_RULES
        rules = DEFAULT_APPROVAL_RULES
    m = margin_pct * 100.0
    for tier in rules.get("tiers", []):
        t = num(tier.get("threshold"))
        if (m >= t) if tier.get("op", "gte") == "gte" else (m > t):
            return list(tier.get("approvers", []))
    return list(rules.get("fallback", []))


def approval_signature(c: dict) -> str:
    """
    BRD §8.2: signature from (round(totalCost), round(marginPct*1000), round(revenue)).
    Any edit that moves cost or margin changes the signature → approvals reset.
    Rounding matches JS Math.round (half away from zero for positives).
    """
    def js_round(x: float) -> int:
        import math
        return math.floor(x + 0.5)

    return f"{js_round(c['totalCost'])}|{js_round(c['mpct'] * 1000)}|{js_round(c['rev'])}"


def computed_payload(state: dict, rules: dict | None = None) -> dict:
    """Full server-computed view: totals + phase roll-ups + approval requirement."""
    c = compute_budget(state)
    return {
        **c,
        "phases": compute_phase_rollups(state, c),
        "requiredApprovers": required_approvers(c["mpct"], rules),
        "signature": approval_signature(c),
    }
