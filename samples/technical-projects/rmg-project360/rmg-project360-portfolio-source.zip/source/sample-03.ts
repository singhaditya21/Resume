/**
 * Pure costing engine — BRD §4. Deterministic, no side effects.
 * This module is the single source of truth for all money/effort math,
 * reused verbatim by the React client and the API server.
 */
import type {
  Assumptions,
  BudgetState,
  Computed,
  Phase,
  PhaseRollup,
  RosterLine,
} from './types.js';

/** Coerce any input to a finite number; NaN never propagates (BRD §11). */
export function num(v: unknown): number {
  const n = typeof v === 'number' ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : 0;
}

export function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/** BRD §4.1–§4.3: per-month roll-ups, totals and P&L. */
export function computeBudget(state: BudgetState): Computed {
  const a = state.assumptions;
  const N = Math.max(1, Math.round(num(a.months)));
  const uplift = num(a.uplift) / 100;
  const eff = num(a.eff) / 100;
  const exp = num(a.exp) / 100;
  const travelRate = num(a.travel);

  const baseM = Array(N).fill(0);
  const onM = Array(N).fill(0);
  const offM = Array(N).fill(0);

  for (const r of state.roster) {
    (r.alloc || []).forEach((cell, j) => {
      if (j >= N) return;
      const mm = num(cell);
      baseM[j] += mm * num(r.cpm);
      if (r.loc === 'On Site') onM[j] += mm;
      else offM[j] += mm;
    });
  }

  const burdM = baseM.map((b) => b * (1 + uplift) * (1 + eff));
  const travM = onM.map((o) => o * travelRate * (1 + exp));

  const sum = (xs: number[]) => xs.reduce((s, x) => s + x, 0);
  const baseTot = sum(baseM);
  const burdTot = sum(burdM);
  const travTot = sum(travM);
  const totalCost = burdTot + travTot;
  const onMM = sum(onM);
  const offMM = sum(offM);
  const mm = onMM + offMM;
  const rev = num(a.rev);
  const gm = rev - totalCost;
  const mpct = rev === 0 ? 0 : gm / rev;

  return {
    baseM, burdM, travM, onM, offM,
    baseTot, burdTot, travTot, totalCost,
    onMM, offMM, mm, rev, gm, mpct,
    rate: mm === 0 ? 0 : totalCost / mm,
  };
}

/** BRD §4.3: per-role totals. */
export function roleTotals(r: RosterLine): { mm: number; cost: number } {
  const mm = (r.alloc || []).reduce((s, x) => s + num(x), 0);
  return { mm, cost: mm * num(r.cpm) };
}

/** BRD §4.4: phase roll-up over fixed month bands. */
export function computePhaseRollups(state: BudgetState, c?: Computed): PhaseRollup[] {
  const C = c ?? computeBudget(state);
  const N = C.baseM.length;
  const total = C.totalCost || 1;
  return state.phases.map((p) => {
    let effortMM = 0, base = 0, burdened = 0, travel = 0;
    for (let m = p.s; m <= p.e; m++) {
      const j = m - 1;
      if (j < 0 || j >= N) continue;
      base += C.baseM[j];
      burdened += C.burdM[j];
      travel += C.travM[j];
      effortMM += C.onM[j] + C.offM[j];
    }
    const cost = burdened + travel;
    return { name: p.n, s: p.s, e: p.e, effortMM, base, burdened, travel, cost, share: cost / total };
  });
}

/** BRD §5: phase index that month m falls in, else -1. */
export function phaseOf(phases: Phase[], m: number): number {
  for (let i = 0; i < phases.length; i++) {
    if (m >= phases[i].s && m <= phases[i].e) return i;
  }
  return -1;
}

/** BRD §5: header band cells — consecutive months sharing a phase collapse into one span. */
export function bandCells(phases: Phase[], months: number): { phase: number; span: number }[] {
  const cells: { phase: number; span: number }[] = [];
  let m = 1;
  while (m <= months) {
    const p = phaseOf(phases, m);
    let span = 1;
    while (m + span <= months && phaseOf(phases, m + span) === p) span++;
    cells.push({ phase: p, span });
    m += span;
  }
  return cells;
}

/**
 * BRD §7: derive a role's active window when absent —
 * first..last month with allocation > 0, else the full span.
 */
export function ensureWindows(roster: RosterLine[], months: number): void {
  for (const r of roster) {
    if (r.start != null && r.dur != null) continue;
    let first = -1, last = -1;
    (r.alloc || []).forEach((a, j) => {
      if (num(a) > 0) {
        if (first < 0) first = j;
        last = j;
      }
    });
    if (first < 0) {
      r.start = 1;
      r.dur = months;
    } else {
      r.start = first + 1;
      r.dur = last - first + 1;
    }
  }
}

/** BRD §7/§11: clamp windows and resize alloc arrays after a month-count change. */
export function resizeToMonths(state: BudgetState, months: number): void {
  const n = clamp(Math.round(num(months)) || 1, 1, 36);
  state.assumptions.months = n;
  for (const r of state.roster) {
    const alloc = r.alloc || [];
    while (alloc.length < n) alloc.push(0);
    alloc.length = n;
    r.alloc = alloc;
    r.start = clamp(Math.round(num(r.start)) || 1, 1, n);
    r.dur = clamp(Math.round(num(r.dur)), 0, n);
  }
  for (const p of state.phases) {
    p.s = clamp(Math.round(num(p.s)) || 1, 1, n);
    p.e = clamp(Math.round(num(p.e)) || 1, 1, n);
  }
}

/** P&L health thresholds — BRD §12. */
export type Health = 'HEALTHY' | 'THIN' | 'AT RISK';
export function marginHealth(mpct: number): Health {
  if (mpct >= 0.30) return 'HEALTHY';
  if (mpct >= 0.18) return 'THIN';
  return 'AT RISK';
}

/* ===================== §6: duration-derived months & as-of-date ===================== */

export const AVG_MONTH_DAYS = 30.4375;

export interface PhaseSchedule {
  start: number;
  end: number;
  duration: number;
}

/** BRD §6.1: lay phases end-to-end from their durations. */
export function scheduleFromDurations(durations: number[]): PhaseSchedule[] {
  const out: PhaseSchedule[] = [];
  let cursor = 0;
  for (const d of durations) {
    out.push({ start: cursor, end: cursor + d, duration: d });
    cursor += d;
  }
  return out;
}

/** BRD §6.2: overlap-weighted spread of a phase value into month m (1-indexed). */
export function overlapWeight(p: PhaseSchedule, m: number): number {
  if (p.duration <= 0) return 0;
  const overlap = Math.max(0, Math.min(p.end, m) - Math.max(p.start, m - 1));
  return overlap / p.duration;
}

export interface AsOfResult {
  asOfMonths: number;
  totalDuration: number;
  scheduleElapsedPct: number;
  phaseCompletion: number[];
  plannedValue: number;
  plannedEffortMM: number;
  remainingBudget: number;
  phasesComplete: number;
}

/** BRD §6.3: planned value (BCWS) by phase-completion weighting. */
export function asOfDate(
  startDate: string,
  asOf: string,
  durations: number[],
  phaseCost: number[],
  phaseEffortMM: number[],
): AsOfResult {
  const sched = scheduleFromDurations(durations);
  const totalDuration = durations.reduce((s, d) => s + d, 0);
  const elapsedDays = (new Date(asOf).getTime() - new Date(startDate).getTime()) / 86400000;
  const asOfMonths = clamp(elapsedDays / AVG_MONTH_DAYS, 0, totalDuration);
  const phaseCompletion = sched.map((p) =>
    p.duration > 0 ? clamp((asOfMonths - p.start) / p.duration, 0, 1) : 0,
  );
  const plannedValue = phaseCompletion.reduce((s, c, i) => s + c * (phaseCost[i] ?? 0), 0);
  const plannedEffortMM = phaseCompletion.reduce((s, c, i) => s + c * (phaseEffortMM[i] ?? 0), 0);
  const totalBudget = phaseCost.reduce((s, x) => s + x, 0);
  return {
    asOfMonths,
    totalDuration,
    scheduleElapsedPct: totalDuration ? asOfMonths / totalDuration : 0,
    phaseCompletion,
    plannedValue,
    plannedEffortMM,
    remainingBudget: totalBudget - plannedValue,
    phasesComplete: phaseCompletion.filter((c) => c >= 0.999).length,
  };
}

/* ===================== validation (§11) ===================== */

export interface ValidationIssue {
  level: 'warn' | 'error';
  message: string;
}

export function validateState(state: BudgetState): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const n = state.assumptions.months;
  if (n < 1 || n > 36) issues.push({ level: 'error', message: `months must be 1..36 (got ${n})` });

  if (state.project.goLive && state.project.start && state.project.goLive < state.project.start) {
    issues.push({ level: 'warn', message: 'Go-Live date is before the project start date' });
  }

  // phases should partition the timeline — warn, don't block
  const covered = Array(n).fill(0);
  for (const p of state.phases) {
    for (let m = p.s; m <= p.e && m <= n; m++) covered[m - 1]++;
  }
  if (covered.some((c) => c === 0)) issues.push({ level: 'warn', message: 'Phase gap: some months belong to no phase' });
  if (covered.some((c) => c > 1)) issues.push({ level: 'warn', message: 'Phase overlap: some months belong to multiple phases' });

  state.roster.forEach((r, i) => {
    if (num(r.cpm) < 0) issues.push({ level: 'error', message: `Row ${i + 1} (${r.role}): negative cost/MM` });
    const end = r.start + r.dur - 1;
    (r.alloc || []).forEach((a, j) => {
      if (num(a) < 0) issues.push({ level: 'error', message: `Row ${i + 1} (${r.role}): negative allocation in M${j + 1}` });
      if (num(a) > 0 && (j + 1 < r.start || j + 1 > end)) {
        issues.push({ level: 'warn', message: `Row ${i + 1} (${r.role}): allocation outside active window in M${j + 1}` });
      }
    });
  });
  return issues;
}
