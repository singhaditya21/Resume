// Drives the spacing scale. The upstream portal lets a tenant switch density; if you
// do not need that, this can safely stay at the 16 default forever.
export function getDensity(): number {
  if (typeof window !== "undefined") {
    const ls = window.localStorage?.getItem("acid_resolution_view");
    if (ls) return Number(ls);
    const g = (window as unknown as { GlobalSwiftUISetting?: { UIDensityView?: string } })
      .GlobalSwiftUISetting?.UIDensityView;
    if (g) return Number(g);
  }
  return 16;
}
