-- Resource Allocation & Project Budgeting — schema per BRD §14.2
-- Versions are immutable JSONB snapshots (source of truth for recompute);
-- roster/allocations/phases are normalised copies for reporting.

CREATE TABLE IF NOT EXISTS projects (
  id           SERIAL PRIMARY KEY,
  project_ref  TEXT NOT NULL UNIQUE,
  name         TEXT NOT NULL DEFAULT '',
  currency     TEXT NOT NULL DEFAULT 'INR',
  start_date   DATE,
  go_live      DATE,
  created_by   TEXT NOT NULL DEFAULT 'system',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Upgrade path for databases created before go_live existed
ALTER TABLE projects ADD COLUMN IF NOT EXISTS go_live DATE;

-- The working copy's cost drivers. Until these existed the projects row held
-- only identity and dates, so revenue and margin reached PostgreSQL solely
-- inside a version snapshot — between snapshots the database had no record of
-- a budget's economics.
ALTER TABLE projects ADD COLUMN IF NOT EXISTS revenue          NUMERIC(18,2);
ALTER TABLE projects ADD COLUMN IF NOT EXISTS uplift_pct       NUMERIC(9,4);
ALTER TABLE projects ADD COLUMN IF NOT EXISTS effort_cont_pct  NUMERIC(9,4);
ALTER TABLE projects ADD COLUMN IF NOT EXISTS expense_cont_pct NUMERIC(9,4);
ALTER TABLE projects ADD COLUMN IF NOT EXISTS travel_per_mm    NUMERIC(18,2);
ALTER TABLE projects ADD COLUMN IF NOT EXISTS months           INTEGER;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS updated_at       TIMESTAMPTZ NOT NULL DEFAULT now();

CREATE TABLE IF NOT EXISTS budget_versions (
  id           SERIAL PRIMARY KEY,
  project_id   INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  version_no   INTEGER NOT NULL,
  label        TEXT NOT NULL DEFAULT '',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  state_jsonb  JSONB NOT NULL,
  total_cost   NUMERIC NOT NULL,
  margin_pct   NUMERIC NOT NULL,
  signature    TEXT NOT NULL,
  UNIQUE (project_id, version_no)
);

CREATE TABLE IF NOT EXISTS phases (
  id           SERIAL PRIMARY KEY,
  version_id   INTEGER NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  start_month  INTEGER NOT NULL,
  end_month    INTEGER NOT NULL
);

-- Role master (designations). Source of truth for the Role dropdown; each
-- roster line stores role_id, not the label.
CREATE TABLE IF NOT EXISTS roles (
  id    TEXT PRIMARY KEY,
  name  TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS roster_lines (
  id           SERIAL PRIMARY KEY,
  version_id   INTEGER NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
  team         TEXT NOT NULL DEFAULT '',
  role         TEXT NOT NULL DEFAULT '',
  role_id      TEXT REFERENCES roles(id),
  location     TEXT NOT NULL DEFAULT 'Offshore',
  cost_per_mm  NUMERIC NOT NULL DEFAULT 0,
  start_month  INTEGER NOT NULL DEFAULT 1,
  duration     INTEGER NOT NULL DEFAULT 0
);

-- Upgrade path for databases created before role_id existed
ALTER TABLE roster_lines ADD COLUMN IF NOT EXISTS role_id TEXT;

CREATE TABLE IF NOT EXISTS allocations (
  id             SERIAL PRIMARY KEY,
  roster_line_id INTEGER NOT NULL REFERENCES roster_lines(id) ON DELETE CASCADE,
  month_no       INTEGER NOT NULL,
  mm             NUMERIC NOT NULL DEFAULT 0
);

-- Approval sign-offs are bound to a budget signature: a re-priced budget
-- cannot inherit stale approvals (BRD §14.4).
CREATE TABLE IF NOT EXISTS approvals (
  id             SERIAL PRIMARY KEY,
  version_id     INTEGER NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
  signature      TEXT NOT NULL,
  approver_role  TEXT NOT NULL CHECK (approver_role IN ('PO','HOD','COO')),
  approver_user  TEXT NOT NULL DEFAULT '',
  decision       TEXT NOT NULL CHECK (decision IN ('approved','revoked')),
  decided_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_approvals_version_sig ON approvals (version_id, signature);

-- Application users (demo auth): username → app role. Managed from the Admin
-- console; login resolves the username here and assumes the assigned role.
CREATE TABLE IF NOT EXISTS app_users (
  id           SERIAL PRIMARY KEY,
  username     TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL DEFAULT '',
  app_role     TEXT NOT NULL DEFAULT 'Viewer',
  active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Access-request workflow: employees signing in for the first time are created
-- pending, routed to their reporting manager for approval.
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS employee_id INTEGER;
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS password_hash TEXT;
-- Multi-role support: the set of roles a user may act as; app_role stays the default.
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS app_roles TEXT[];
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS approval_status TEXT NOT NULL DEFAULT 'approved';
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS approver_employee_id INTEGER;
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS requested_at TIMESTAMPTZ;

-- Employee directory — HR master synced from Redash (query 686). All source
-- columns are kept; login-by-email and RM routing resolve against this table.
CREATE TABLE IF NOT EXISTS employees (
  employee_id      INTEGER PRIMARY KEY,
  user_id          INTEGER,
  name             TEXT NOT NULL DEFAULT '',
  code             TEXT,
  email            TEXT,
  band             TEXT,
  grade            TEXT,
  status           TEXT,
  employee_type    TEXT,
  designation      TEXT,
  work_location    TEXT,
  group_name       TEXT,
  sub_group        TEXT,
  team             TEXT,
  rm1_name         TEXT,
  rm1_user_id      INTEGER,
  rm1_employee_id  INTEGER,
  rm2_name         TEXT,
  rm2_user_id      INTEGER,
  rm2_employee_id  INTEGER,
  rm3_name         TEXT,
  rm3_user_id      INTEGER,
  rm3_employee_id  INTEGER,
  po_name          TEXT,
  po_user_id       INTEGER,
  po_employee_id   INTEGER,
  hod_name         TEXT,
  hod_user_id      INTEGER,
  hod_employee_id  INTEGER,
  date_of_joining  DATE,
  total_experience TEXT,
  synced_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_employees_email ON employees (lower(email));

CREATE INDEX IF NOT EXISTS idx_app_users_username_lower ON app_users (lower(username));
CREATE INDEX IF NOT EXISTS idx_app_users_employee_id    ON app_users (employee_id);


-- Profile fields from the HR Excel master + provenance tracking.
-- source: 'redash' rows accept profile overwrites from the API sync;
-- 'excel'/'manual' rows keep their profile fields (structure still syncs).
ALTER TABLE employees ADD COLUMN IF NOT EXISTS gender TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS geography TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS country TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS mobile TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'redash';

-- Role → permission grants, editable from the Admin console. Seeded from
-- rbac.DEFAULT_ROLE_PERMISSIONS when empty; the frontend falls back to the
-- same defaults when the API is offline.
CREATE TABLE IF NOT EXISTS role_permissions (
  app_role   TEXT NOT NULL,
  permission TEXT NOT NULL,
  PRIMARY KEY (app_role, permission)
);

-- Generic list-of-values master for dropdown fields (role/team/location).
-- Removal deletes the row; historic budgets keep their denormalised labels.
CREATE TABLE IF NOT EXISTS lov_values (
  field  TEXT NOT NULL,
  id     TEXT NOT NULL,
  name   TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (field, id)
);

-- Small JSON config store (e.g. key 'approval_rules' → margin-tier table
-- edited from the Admin console).
CREATE TABLE IF NOT EXISTS app_config (
  key   TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id           SERIAL PRIMARY KEY,
  project_id   INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  version_id   INTEGER,
  actor        TEXT NOT NULL DEFAULT 'system',
  action       TEXT NOT NULL,
  detail_json  JSONB,
  at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
