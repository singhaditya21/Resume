import React, { useEffect } from 'react';

export default function SlideOver({ isOpen, onClose, title, children }) {
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'auto';
        }
    }, [isOpen]);

    if (!isOpen) return null;

    return (
        <div className="slideover-backdrop" onClick={onClose}>
            <div
                className="slideover-panel"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="slideover-header">
                    <h2 className="slideover-title">{title}</h2>
                    <button className="slideover-close" onClick={onClose}>✕</button>
                </div>
                <div className="slideover-body">
                    {children}
                </div>
            </div>
        </div>
    );
}
