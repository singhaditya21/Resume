#!/bin/bash
echo "=== Fixing Git Authentication for Background Sync (Once and For All) ==="
echo "Configuring generic file-based 'store' helper globally instead of macOS osxkeychain,"
echo "which will permanently resolve the 'Device not configured' headless failures."

# Set global store (you are running this in your terminal, so it has permissions)
git config --global credential.helper 'store --file ~/.git-credentials'

echo "Pulling from origin right now to trigger the final authentication..."
git pull origin main

echo ""
echo "✅ Finished! Your credentials are now stored in ~/.git-credentials."
echo "Your LaunchAgents and background jobs for all 15 repositories will now work flawlessly without keychain permission drops."
