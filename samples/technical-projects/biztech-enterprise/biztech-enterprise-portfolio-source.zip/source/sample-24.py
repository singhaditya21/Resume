import json

try:
    with open('data/workitems.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    found_tasks = []
    for item in data:
        fields = item.get("fields", {})
        if fields.get("System.WorkItemType") == "Task":
            relations = item.get("relations") or []
            if any(r.get("rel") == "AttachedFile" for r in relations):
                assigned_to = fields.get("System.AssignedTo")
                assignee_name = assigned_to.get("displayName") if isinstance(assigned_to, dict) else str(assigned_to)
                
                title = fields.get("System.Title", "No Title")
                found_tasks.append(f"Task ID: {item.get('id')} | Assignee: {assignee_name} | Title: {title}")
                
    if not found_tasks:
        print("No tasks with attachments found in the cached dataset.")
    else:
        print(f"Found {len(found_tasks)} Tasks with attachments. Here are the first 5:")
        for t in found_tasks[:5]:
            print("- " + t)
except Exception as e:
    print(f"Error: {e}")
