import urllib.request
import json
import base64

pat = "REDACTED_OPAQUE_VALUE"
b64_pat = base64.b64encode(b":" + pat.encode("utf-8")).decode("utf-8")
headers = {"Authorization": "REDACTED_SECRET" + b64_pat}

url = "https://example.invalid"
req = urllib.request.Request(url, headers=headers)
try:
    with urllib.request.urlopen(req) as response:
        data = json.loads(response.read().decode())
        print(f"Found {data['count']} iterations")
        for itr in data['value'][:5]:
            attrs = itr.get('attributes', {})
            print(f"- {itr['path']} | Start: {attrs.get('startDate')} | Finish: {attrs.get('finishDate')}")
        
        # Save to file to inspect all
        with open("/opt/portfolio/project", "w") as f:
            json.dump(data, f, indent=2)
except Exception as e:
    print(e.read().decode('utf-8') if hasattr(e, 'read') else str(e))
