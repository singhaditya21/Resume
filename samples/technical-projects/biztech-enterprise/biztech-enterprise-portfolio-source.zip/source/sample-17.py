import json

md_content = "# Created Tasks for NPS Repository\n\n"
md_content += "| Task ID | Title | Link |\n|---|---|---|\n"

count = 0
with open("/opt/portfolio/project", "r") as f:
    for line in f:
        if line.startswith("| `") and "[NPS]" in line:
            md_content += line
            count += 1

md_content = md_content.replace("# Created Tasks for NPS Repository\n\n", f"# Created Tasks for NPS Repository\n\nFound **{count}** tasks for the NPS repository.\n\n")

with open("/opt/portfolio/project", "w") as f:
    f.write(md_content)
