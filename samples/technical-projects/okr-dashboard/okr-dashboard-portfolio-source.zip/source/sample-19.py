import psycopg2
import json

try:
    conn = psycopg2.connect(
        host="192.0.2.10",
        database="DataMart_Bizops",
        user="PORTFOLIO_REDACTED",
        password=REDACTED_SECRET
        port=5432
    )
    cur = conn.cursor()
    cur.execute("SELECT * FROM dbo.npsdata LIMIT 10")
    colnames = [desc[0] for desc in cur.description]
    rows = cur.fetchall()
    
    output = []
    for row in rows:
        output.append(dict(zip(colnames, row)))
        
    print(json.dumps(output, indent=2, default=str))
except Exception as e:
    print(f"Error: {e}")
