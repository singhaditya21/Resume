import psycopg2
try:
    conn = psycopg2.connect(host="192.0.2.10", database="DataMart_Bizops", user="PORTFOLIO_REDACTED", password="REDACTED_SECRET")
    cur = conn.cursor()
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='dbo' AND table_name='ndr'")
    print("NDR VIEW Columns:", [r[0] for r in cur.fetchall()])
except Exception as e:
    print("Failed:", e)
