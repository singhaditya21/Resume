import paramiko

HOST = "192.0.2.10"
USER = "PORTFOLIO_REDACTED"
PASS = "Noida@2406"

try:
    transport = paramiko.Transport((HOST, 22))
    transport.connect(username=USER, password=PASS)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, port=22, username=USER, password=PASS)
    
    print("Checking for server.py process...")
    stdin, stdout, stderr = client.exec_command("ps -ef | grep server.py")
    print(stdout.read().decode())
    
    print("Finding python process and killing it...")
    stdin, stdout, stderr = client.exec_command("pkill -f server.py")
    print(stdout.read().decode())
    
    print("Restarting server.py...")
    # we run it nicely using nohup
    stdin, stdout, stderr = client.exec_command("cd /biztech/OKRDashboard && nohup python3 server.py > server.log 2>&1 &")
    
    print("Done")
    client.close()
    
except Exception as e:
    print("Error:", e)
