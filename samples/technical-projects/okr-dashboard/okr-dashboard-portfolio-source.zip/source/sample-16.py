import psycopg2
import sys

try:
    conn = psycopg2.connect(dbname='okr_db', user='PORTFOLIO_REDACTED', password='REDACTED_SECRET', host='192.0.2.10', port='5432')
    cur = conn.cursor()
    cur.execute('SELECT * FROM datamart_bizops.dbo.openpipeline LIMIT 5')
    print([desc[0] for desc in cur.description])
    print(cur.fetchall())
    conn.close()
except Exception as e:
    print(e)
