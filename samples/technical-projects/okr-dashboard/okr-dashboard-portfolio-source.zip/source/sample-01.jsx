import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, ScatterChart, Scatter, ZAxis, LineChart, Line, AreaChart, Area, Legend } from 'recharts';
import { AlertTriangle, ChevronDown, ChevronUp, X } from 'lucide-react';
const C = { primary: '#e62054', success: '#00c283', warning: '#fca311', danger: '#e63946', info: '#4361ee', purple: '#8b5cf6', cyan: '#06b6d4', orange: '#f97316' };
const TS = { borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: '0.75rem' };
const CR_DIV = 10000000;
const MONTHS = ['apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'jan', 'feb', 'mar'];
const MONTH_LABELS = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
const PIE_COLORS = ['#e62054', '#4361ee', '#00c283', '#fca311', '#8b5cf6', '#06b6d4', '#ef4444', '#22c55e', '#f97316', '#6366f1', '#14b8a6', '#f59e0b'];
const GRADIENTS = { territory: '#06b6d4', subOwner: 'PORTFOLIO_REDACTED', scatter: '#f97316', mom: '#ef4444', pareto: '#6366f1', heatmap: '#22c55e', projects: 'PORTFOLIO_REDACTED', poAge: '#0ea5e9', quarterly: '#ec4899', yoy: '#14b8a6' };

// ─── HELPERS ───
const parseNum = (v) => { try { const s = String(v || '').replace(/[^0-9.\-]/g, ''); const n = parseFloat(s); return isNaN(n) ? 0 : n; } catch { return 0; } };
const parsePct = (v) => { try { const s = String(v || '').replace(/[^0-9.\-]/g, ''); const n = parseFloat(s); return isNaN(n) ? 0 : n; } catch { return 0; } };
const toCr = (v) => parseFloat(v || 0) / CR_DIV;

const SidebarItem = ({ title, weight, pct, color, onClick }) => (
  <div onClick={onClick} style={{ marginBottom: 16, cursor: onClick ? 'pointer' : 'default' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
      <div><div style={{ color: '#eaedf2', fontWeight: 700, fontSize: '0.8rem' }}>{title}</div>
        <div style={{ color: '#6c757d', fontSize: '0.65rem', marginTop: 4 }}>Wt: {weight}%</div></div>
      <span style={{ color, fontWeight: 800, fontSize: '0.8rem' }}>{pct}</span></div>
    <div style={{ height: 4, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 2 }}>
      <div style={{ width: Math.min(100, parseFloat(pct) || 0) + '%', backgroundColor: color, height: '100%', borderRadius: 2 }} /></div></div>);

const SideSection = ({ icon, title, weightStr, count, isOpen, onToggle, children }) => (<>
  <div onClick={onToggle} style={{ backgroundColor: '#2b2132', borderRadius: 8, padding: '10px 12px', color: '#e62054', fontWeight: 800, fontSize: '0.75rem', marginBottom: isOpen ? 12 : 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#fff', fontSize: '0.9rem', fontWeight: 700 }}><span>{icon}</span> {title}</div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, color: '#e62054', fontSize: '0.75rem' }}>
      <span style={{ color: '#888' }}>{weightStr}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>{count} <ChevronDown size={12} style={{ transform: isOpen ? 'rotate(0)' : 'rotate(180deg)', transition: 'transform 0.2s' }} /></div></div></div>
  {isOpen && <div style={{ marginBottom: 24, padding: '0 4px' }}>{children}</div>}</>);

const SectionHeader = ({ title, icon, isOpen, onToggle, rightContent }) => (
  <div onClick={onToggle} style={{ backgroundColor: isOpen ? '#26293d' : '#f8f9fa', borderRadius: isOpen ? '8px 8px 0 0' : '8px', padding: '8px 16px', color: isOpen ? 'white' : '#495057', border: isOpen ? 'none' : '1px solid #eaedf2', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none', marginTop: 16 }}>
    <div style={{ fontWeight: 700, fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: 8 }}>{icon} <span>{title}</span></div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: '0.75rem', color: isOpen ? '#e62054' : '#e63946' }}>{rightContent}{isOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}</div></div>);

const DrillModal = ({ open, onClose, title, tabs, activeTab, setActiveTab, children }) => {
  if (!open) return null;
  return (
    <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(3px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }} onClick={onClose}>
      <div style={{ backgroundColor: '#fff', borderRadius: 16, width: '960px', maxWidth: '95vw', padding: '24px', boxShadow: '0 24px 48px rgba(0,0,0,0.2)', position: 'relative', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }} onClick={e => e.stopPropagation()}>
        <button style={{ position: 'absolute', top: 16, right: 16, background: 'transparent', border: 'none', cursor: 'pointer', color: '#6c757d' }} onClick={onClose}><X size={20} /></button>
        <h2 style={{ margin: '0 0 16px', fontSize: '1.3rem', fontWeight: 800, color: '#2b2b2b' }}>{title}</h2>
        {tabs && <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {tabs.map(t => <button key={t.key} onClick={() => setActiveTab(t.key)} style={{ padding: '6px 16px', borderRadius: 16, backgroundColor: activeTab === t.key ? '#e62054' : '#f0f2f5', color: activeTab === t.key ? 'white' : '#6c757d', fontWeight: 800, fontSize: '0.85rem', border: 'none', cursor: 'pointer' }}>{t.label}</button>)}
        </div>}
        <div style={{ flex: 1, overflowY: 'auto' }}>{children}</div>
      </div>
    </div>);
};

export default function DeliveryDashboard({ selectedFy = 'FY26' }) {
  // Financial data
  const [rawData, setRawData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sF, setSF] = useState(true); const [sE, setSE] = useState(true); const [sS, setSS] = useState(true); const [sP, setSP] = useState(true);
  const [cF, setCF] = useState(true); const [cE, setCE] = useState(true); const [cS, setCS] = useState(true); const [cP, setCP] = useState(true);
  const [modal, setModal] = useState(null); const [modalTab, setModalTab] = useState('overview');

  // Execution / project data
  const [projectData, setProjectData] = useState([]);
  const [projLoading, setProjLoading] = useState(true);

  useEffect(() => {
    setLoading(true); setProjLoading(true);
    Promise.all([
      fetch('https://example.invalid').then(r => r.json()).catch(() => []),
      fetch('https://example.invalid').then(r => r.json()).catch(() => [])
    ]).then(([fin, proj]) => {
      setRawData(Array.isArray(fin) ? fin : []);
      setProjectData(Array.isArray(proj) ? proj : []);
      setLoading(false); setProjLoading(false);
    }).catch(() => {
      setRawData([]); setProjectData([]);
      setLoading(false); setProjLoading(false);
    });
  }, [selectedFy]);

  // ─── FINANCIAL DATA PROCESSING ───
  const fyRows = rawData.filter(r => r.financialyear === selectedFy);
  const monthly = MONTHS.map((m, i) => ({ month: MONTH_LABELS[i], value: parseFloat(fyRows.reduce((s, r) => s + toCr(r[m]), 0).toFixed(2)) }));
  const fyTotal = fyRows.reduce((s, r) => s + toCr(r.fy_total), 0);
  const achieved = parseFloat(fyTotal.toFixed(1));
  const ownerMap = {}; fyRows.forEach(r => { const k = r.portfolioowner || 'Unknown'; ownerMap[k] = (ownerMap[k] || 0) + toCr(r.fy_total); });
  const byOwner = Object.entries(ownerMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const acctMap = {}; fyRows.forEach(r => { const k = r.accountname || 'Unknown'; acctMap[k] = (acctMap[k] || 0) + toCr(r.fy_total); });
  const byAccount = Object.entries(acctMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const top5Accounts = byAccount.slice(0, 5);
  const poTypeMap = {}; fyRows.forEach(r => { const k = r.potypename || 'Unknown'; poTypeMap[k] = (poTypeMap[k] || 0) + toCr(r.fy_total); });
  const byPOType = Object.entries(poTypeMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const mgrMap = {}; fyRows.forEach(r => { const k = r.manager || 'Unknown'; mgrMap[k] = (mgrMap[k] || 0) + toCr(r.fy_total); });
  const byManager = Object.entries(mgrMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const terrMap = {}; fyRows.forEach(r => { const k = r.territory || 'Unknown'; terrMap[k] = (terrMap[k] || 0) + toCr(r.fy_total); });
  const byTerritory = Object.entries(terrMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const subMap = {}; fyRows.forEach(r => { const k = r.subportfolioowner || 'Unknown'; subMap[k] = (subMap[k] || 0) + toCr(r.fy_total); });
  const bySubOwner = Object.entries(subMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const ownerPO = {}; fyRows.forEach(r => { const k = r.portfolioowner || 'Unknown'; if (!ownerPO[k]) ownerPO[k] = { count: 0, revenue: 0 }; ownerPO[k].count++; ownerPO[k].revenue += toCr(r.fy_total); });
  const poCorrelation = Object.entries(ownerPO).map(([name, d]) => ({ name, count: d.count, revenue: parseFloat(d.revenue.toFixed(2)), avg: parseFloat((d.revenue / d.count).toFixed(2)) }));
  const momGrowth = monthly.slice(1).map((m, i) => ({ month: m.month, growth: monthly[i].value > 0 ? parseFloat((((m.value - monthly[i].value) / monthly[i].value) * 100).toFixed(1)) : 0 }));
  const paretoData = byAccount.map((a, i) => ({ ...a, cumulative: parseFloat((byAccount.slice(0, i + 1).reduce((s, x) => s + x.value, 0) / (fyTotal || 1) * 100).toFixed(1)) }));
  const top20Pareto = paretoData.slice(0, 20);
  const hmOwners = byOwner.slice(0, 10).map(o => o.name);
  const hmData = hmOwners.map(owner => { const d = { owner }; byPOType.forEach(pt => { d[pt.name] = parseFloat(fyRows.filter(r => r.portfolioowner === owner && r.potypename === pt.name).reduce((s, r) => s + toCr(r.fy_total), 0).toFixed(2)); }); return d; });
  const hmMaxVal = Math.max(...hmData.flatMap(d => byPOType.map(pt => d[pt.name] || 0)), 1);
  const projMap = {}; fyRows.forEach(r => { const k = r.projectname || 'Unknown'; projMap[k] = (projMap[k] || 0) + toCr(r.fy_total); });
  const byProject = Object.entries(projMap).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) })).sort((a, b) => b.value - a.value);
  const top10Projects = byProject.slice(0, 10);
  const ageMap = {}; fyRows.forEach(r => { const d = r.podate ? new Date(r.podate) : null; const y = d ? d.getFullYear() : 0; const b = !y ? 'Unknown' : y < 2018 ? 'Pre-2018' : y < 2022 ? '2018-21' : '2022+'; ageMap[b] = (ageMap[b] || 0) + toCr(r.fy_total); });
  const byPOAge = ['Pre-2018', '2018-21', '2022+', 'Unknown'].map(b => ({ name: b, value: parseFloat((ageMap[b] || 0).toFixed(2)) })).filter(x => x.value > 0);
  const Q = [{ label: 'Q1', m: ['apr', 'may', 'jun'] }, { label: 'Q2', m: ['jul', 'aug', 'sep'] }, { label: 'Q3', m: ['oct', 'nov', 'dec'] }, { label: 'Q4', m: ['jan', 'feb', 'mar'] }];
  const quarterly = Q.map(q => { const d = { quarter: q.label }; byOwner.slice(0, 5).forEach(o => { d[o.name] = parseFloat(fyRows.filter(r => r.portfolioowner === o.name).reduce((s, r) => s + q.m.reduce((sm, m) => sm + toCr(r[m]), 0), 0).toFixed(2)); }); d.total = byOwner.slice(0, 5).reduce((s, o) => s + (d[o.name] || 0), 0); return d; });
  const fy25Rows = rawData.filter(r => r.financialyear === 'FY25');
  const fy26Rows = rawData.filter(r => r.financialyear === 'FY26');
  const yoyData = MONTHS.map((m, i) => ({ month: MONTH_LABELS[i], FY25: parseFloat(fy25Rows.reduce((s, r) => s + toCr(r[m]), 0).toFixed(2)), FY26: parseFloat(fy26Rows.reduce((s, r) => s + toCr(r[m]), 0).toFixed(2)) }));
  const target = 55;
  const pct = target > 0 ? Math.round((achieved / target) * 100) : 0;
  const wSR = (pct / 100) * 20; const sv = Math.min(100, Math.round(wSR + 10));
  const sc = sv >= 90 ? C.success : sv >= 70 ? C.warning : C.danger;

  // ─── EXECUTION / PROJECT DATA PROCESSING ───
  const pd = projectData || [];
  const totalProjects = pd.length;

  // 1. Status
  const statusMap = {};
  pd.forEach(r => { const k = r.statuscode || 'Unknown'; statusMap[k] = (statusMap[k] || 0) + 1; });
  const byStatus = Object.entries(statusMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 2. Portfolio Owner (project count + PO amount)
  const execOwnerMap = {};
  pd.forEach(r => { const k = r['Portfolio Owner'] || r.portfolioowner || 'Unknown'; if (!execOwnerMap[k]) execOwnerMap[k] = { count: 0, poAmount: 0 }; execOwnerMap[k].count++; execOwnerMap[k].poAmount += parseNum(r['PO Amount INR on Project']); });
  const byExecOwner = Object.entries(execOwnerMap).map(([name, d]) => ({ name, count: d.count, poAmount: parseFloat((d.poAmount / 10000000).toFixed(2)) })).sort((a, b) => b.count - a.count);

  // 3. Assignee
  const assignMap = {};
  pd.forEach(r => { const k = r.assigntoname || 'Unknown'; assignMap[k] = (assignMap[k] || 0) + 1; });
  const byAssignee = Object.entries(assignMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 4. Category
  const catMap = {};
  pd.forEach(r => { const k = r['Project Category'] || 'Unknown'; catMap[k] = (catMap[k] || 0) + 1; });
  const byCategory = Object.entries(catMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 5. Billable
  const billMap = {};
  pd.forEach(r => { const k = r.billable === true ? 'Billable' : r.billable === false ? 'Non-Billable' : 'Unknown'; billMap[k] = (billMap[k] || 0) + 1; });
  const byBillable = Object.entries(billMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 6. Completion bins
  const compBins = { '0-25%': 0, '25-50%': 0, '50-75%': 0, '75-100%': 0, 'Unknown': 0 };
  pd.forEach(r => { const p = parsePct(r['% Completion']); if (p === 0 && (!r['% Completion'] || String(r['% Completion']).trim() === '')) compBins['Unknown']++; else if (p <= 25) compBins['0-25%']++; else if (p <= 50) compBins['25-50%']++; else if (p <= 75) compBins['50-75%']++; else compBins['75-100%']++; });
  const byCompletion = Object.entries(compBins).map(([name, value]) => ({ name, value })).filter(x => x.value > 0);

  // 7. Top accounts by project count
  const execAcctMap = {};
  pd.forEach(r => { const k = r.companyname || 'Unknown'; execAcctMap[k] = (execAcctMap[k] || 0) + 1; });
  const byExecAccount = Object.entries(execAcctMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  const top5ExecAccounts = byExecAccount.slice(0, 5);

  // 8. Revenue Area
  const revAreaMap = {};
  pd.forEach(r => { const k = r['Revenue Area'] || 'Unknown'; revAreaMap[k] = (revAreaMap[k] || 0) + 1; });
  const byRevArea = Object.entries(revAreaMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 9. IDR SignOff
  const idrMap = {};
  pd.forEach(r => { const k = r['IDR SignOff'] || 'Unknown'; idrMap[k] = (idrMap[k] || 0) + 1; });
  const byIDR = Object.entries(idrMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // 10. Active
  const activeMap = {};
  pd.forEach(r => { const k = r['Active'] || 'Unknown'; activeMap[k] = (activeMap[k] || 0) + 1; });
  const byActive = Object.entries(activeMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  const activeCount = byActive.find(x => String(x.name).toLowerCase() === 'yes')?.value || 0;
  const activePct = totalProjects > 0 ? Math.round((activeCount / totalProjects) * 100) : 0;

  // 11. Duration by Portfolio Owner
  const durMap = {};
  pd.forEach(r => { const k = r['Portfolio Owner'] || 'Unknown'; if (!durMap[k]) durMap[k] = { total: 0, count: 0 }; durMap[k].total += parseInt(r.duration || 0); durMap[k].count++; });
  const byDuration = Object.entries(durMap).map(([name, d]) => ({ name, avg: Math.round((d.total / d.count) / 1440) })).sort((a, b) => b.avg - a.avg);

  // 12. Go-Live tracker (projects with Go-Live Date History)
  const goLiveProjects = pd.filter(r => r['Go-Live Date History'] && String(r['Go-Live Date History']).trim() !== '');
  const goLiveCount = goLiveProjects.length;

  // ─── REUSABLE COMPONENTS ───
  const SummaryRow = ({ items }) => (
    <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
      {items.map((it, i) => <div key={i} style={{ flex: 1, backgroundColor: '#f8f9fa', borderRadius: 12, padding: '20px 16px', textAlign: 'center' }}>
        <div style={{ fontSize: '0.8rem', color: '#888', fontWeight: 600, marginBottom: 6 }}>{it.label}</div>
        <div style={{ fontSize: '1.8rem', fontWeight: 800, color: it.color || '#2b2b2b' }}>{it.value}</div>
      </div>)}
    </div>);

  const DataTable = ({ rows, columns }) => (
    <div style={{ border: '1px solid #eaedf2', borderRadius: 8, overflow: 'hidden' }}>
      <div style={{ display: 'flex', backgroundColor: '#f8f9fe', borderBottom: '2px solid #eaedf2', padding: '10px 16px', fontSize: '0.8rem', fontWeight: 800, color: '#6c757d' }}>
        {columns.map((c, i) => <div key={i} style={{ flex: c.flex || 1, textAlign: c.align || 'left' }}>{c.header}</div>)}
      </div>
      {rows.slice(0, 50).map((r, idx) => <div key={idx} style={{ display: 'flex', padding: '10px 16px', borderBottom: '1px solid #f1f5f9', fontSize: '0.85rem', backgroundColor: idx % 2 === 0 ? '#fff' : '#fcfcfd' }}>
        {columns.map((c, i) => <div key={i} style={{ flex: c.flex || 1, textAlign: c.align || 'left', fontWeight: c.bold ? 700 : 400 }}>{c.fmt ? c.fmt(r[c.key], r, idx) : r[c.key]}</div>)}
      </div>)}
    </div>);

  const Card = ({ title, topColor, onClick, badge, badgeColor, children }) => (
    <div onClick={onClick} style={{ borderRadius: 12, border: '1px solid #eaedf2', borderTop: `3px solid ${topColor}`, padding: '12px 16px', position: 'relative', backgroundColor: 'white', cursor: 'pointer', transition: 'box-shadow 0.2s' }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = '0 8px 24px rgba(0,0,0,0.08)'} onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}>
      {badge && <div style={{ position: 'absolute', top: 12, right: 12, backgroundColor: badgeColor || '#fde8ea', color: topColor, padding: '2px 8px', borderRadius: 12, fontSize: '0.65rem', fontWeight: 800 }}>{badge}</div>}
      <div style={{ color: '#6c757d', fontSize: '0.7rem', fontWeight: 800, letterSpacing: 0.5 }}>{title}</div>
      {children}
    </div>);

  const drill = (m) => { setModal(m); setModalTab('overview'); };

  // ─── MODAL CONTENT ───
  const renderModalContent = () => {
    if (!modal) return null;
    const m = modal;

    // FINANCIAL MODALS (existing)
    if (m === 'monthly') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: `${selectedFy} Total`, value: `₹${achieved} Cr` }, { label: 'Monthly Avg', value: `₹${(achieved / 12).toFixed(1)} Cr` }, { label: 'Peak Month', value: monthly.reduce((a, b) => a.value > b.value ? a : b).month }]} />
        <div style={{ height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={monthly} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Bar dataKey="value" name="Revenue (Cr)" radius={[4, 4, 0, 0]} maxBarSize={40}>{monthly.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'byOwner') return (<>
        <SummaryRow items={[{ label: 'Total Owners', value: byOwner.length }]} />
        <div style={{ height: Math.max(300, byOwner.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byOwner} layout="vertical" margin={{ top: 0, right: 40, left: 100, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={20}>{byOwner.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
      </>);
    }
    if (m === 'owner') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={byOwner.slice(0, 3).map(o => ({ label: o.name, value: `₹${o.value} Cr`, color: C.info }))} />
        <div style={{ height: Math.max(300, byOwner.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byOwner} layout="vertical" margin={{ top: 0, right: 40, left: 100, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={24} fill="#4361ee" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'monthly') {
        const cd = MONTH_LABELS.map((ml, i) => { const d = { month: ml }; byOwner.slice(0, 5).forEach(o => { d[o.name] = parseFloat(fyRows.filter(r => r.portfolioowner === o.name).reduce((s, r) => s + toCr(r[MONTHS[i]]), 0).toFixed(2)); }); return d; });
        return <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={cd} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><Tooltip contentStyle={TS} />{byOwner.slice(0, 5).map((o, i) => <Bar key={i} dataKey={o.name} stackId="a" fill={PIE_COLORS[i]} maxBarSize={40} />)}</BarChart></ResponsiveContainer></div>;
      }
    }
    if (m === 'account') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Accounts', value: byAccount.length }, { label: 'Top 5 Share', value: `${(top5Accounts.reduce((s, a) => s + a.value, 0) / (fyTotal || 1) * 100).toFixed(0)}%` }, { label: 'Top Account', value: top5Accounts[0]?.name || '--' }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={top5Accounts} layout="vertical" margin={{ top: 0, right: 40, left: 100, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={24} fill="#e62054" /></BarChart></ResponsiveContainer></div>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={top5Accounts} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{top5Accounts.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
        </div></>);
      if (modalTab === 'all') return <DataTable rows={byAccount.map((a, i) => ({ ...a, rank: i + 1 }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Account Name', key: 'name' }, { header: 'Revenue (₹ Cr)', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'potype') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={byPOType.map(t => ({ label: t.name, value: `₹${t.value} Cr`, color: C.info }))} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byPOType} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byPOType.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byPOType} columns={[{ header: 'PO Type', key: 'name' }, { header: 'Revenue (₹ Cr)', key: 'value', align: 'right', bold: true }]} /></div>
        </div></>);
      if (modalTab === 'byOwner') {
        const cd = byOwner.slice(0, 8).map(o => { const d = { name: o.name }; byPOType.forEach(pt => { d[pt.name] = parseFloat(fyRows.filter(r => r.potypename === pt.name && r.portfolioowner === o.name).reduce((s, r) => s + toCr(r.fy_total), 0).toFixed(2)); }); return d; });
        return <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={cd} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><Tooltip contentStyle={TS} />{byPOType.map((pt, i) => <Bar key={i} dataKey={pt.name} stackId="a" fill={PIE_COLORS[i % PIE_COLORS.length]} maxBarSize={40} />)}</BarChart></ResponsiveContainer></div>;
      }
    }
    if (m === 'manager') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Managers', value: byManager.length }, { label: 'Top Manager', value: byManager[0]?.name || '--' }]} />
        <div style={{ height: Math.max(300, byManager.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byManager} layout="vertical" margin={{ top: 0, right: 40, left: 100, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={24} fill="#00c283" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'byAccount') {
        const mgrAcct = {}; byManager.slice(0, 6).forEach(m => { const rows = fyRows.filter(r => r.manager === m.name); const am = {}; rows.forEach(r => { const k = r.accountname || 'Unknown'; am[k] = (am[k] || 0) + toCr(r.fy_total); }); mgrAcct[m.name] = Object.entries(am).map(([n, v]) => ({ name: n, value: parseFloat(v.toFixed(2)) })).sort((a, b) => b.value - a.value).slice(0, 5); });
        return <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 16 }}>{Object.entries(mgrAcct).map(([mgr, accts]) => <div key={mgr} style={{ border: '1px solid #eaedf2', borderRadius: 8, padding: 12 }}><div style={{ fontWeight: 800, fontSize: '0.85rem', color: '#2b2b2b', marginBottom: 8 }}>{mgr}</div>{accts.map((a, i) => <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '0.8rem', borderBottom: '1px solid #f1f5f9' }}><span>{a.name}</span><span style={{ fontWeight: 700 }}>₹{a.value} Cr</span></div>)}</div>)}</div>;
      }
    }
    if (m === 'territory') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Territories', value: byTerritory.length }, { label: 'Top Territory', value: byTerritory[0]?.name || '--' }, { label: 'Top Value', value: `₹${byTerritory[0]?.value || 0} Cr`, color: C.cyan }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byTerritory} layout="vertical" margin={{ top: 0, right: 40, left: 80, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#888' }} axisLine={false} tickLine={false} width={80} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={24}>{byTerritory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byTerritory} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byTerritory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
        </div></>);
      if (modalTab === 'byOwner') {
        const td = byTerritory.map(t => { const d = { name: t.name }; byOwner.slice(0, 6).forEach(o => { d[o.name] = parseFloat(fyRows.filter(r => r.territory === t.name && r.portfolioowner === o.name).reduce((s, r) => s + toCr(r.fy_total), 0).toFixed(2)); }); return d; });
        return <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={td} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><Tooltip contentStyle={TS} />{byOwner.slice(0, 6).map((o, i) => <Bar key={i} dataKey={o.name} stackId="a" fill={PIE_COLORS[i]} maxBarSize={40} />)}</BarChart></ResponsiveContainer></div>;
      }
    }
    if (m === 'subowner') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Sub-Owners', value: bySubOwner.length }, { label: 'Top', value: bySubOwner[0]?.name || '--' }, { label: 'Revenue', value: `₹${bySubOwner[0]?.value || 0} Cr`, color: C.purple }]} />
        <div style={{ height: Math.max(300, Math.min(bySubOwner.length, 15) * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={bySubOwner.slice(0, 15)} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#8b5cf6" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={bySubOwner.map((s, i) => ({ ...s, rank: i + 1 }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Sub-Portfolio Owner', key: 'name' }, { header: 'Revenue (₹ Cr)', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'pocorr') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Owners', value: poCorrelation.length }, { label: 'Total POs', value: fyRows.length }, { label: 'Avg PO Value', value: `₹${(fyTotal / (fyRows.length || 1)).toFixed(2)} Cr` }]} />
        <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><ScatterChart margin={{ top: 20, right: 40, left: 20, bottom: 20 }}><CartesianGrid strokeDasharray="3 3" stroke="#f0f2f5" /><XAxis type="number" dataKey="count" name="PO Count" tick={{ fontSize: 11, fill: '#888' }} axisLine={false} tickLine={false} label={{ value: 'PO Count', position: 'bottom', fontSize: 11, fill: '#888' }} /><YAxis type="number" dataKey="revenue" name="Revenue (Cr)" tick={{ fontSize: 11, fill: '#888' }} axisLine={false} tickLine={false} label={{ value: 'Revenue (₹ Cr)', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#888' }} /><ZAxis type="number" dataKey="avg" range={[100, 800]} name="Avg PO Value" /><Tooltip contentStyle={TS} cursor={{ strokeDasharray: '3 3' }} /><Scatter data={poCorrelation} fill="#f97316">{poCorrelation.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Scatter></ScatterChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={poCorrelation} columns={[{ header: 'Owner', key: 'name' }, { header: 'PO Count', key: 'count', align: 'right' }, { header: 'Revenue (₹ Cr)', key: 'revenue', align: 'right', bold: true }, { header: 'Avg PO (₹ Cr)', key: 'avg', align: 'right' }]} />;
    }
    if (m === 'mom') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Avg Growth', value: `${(momGrowth.reduce((s, m) => s + m.growth, 0) / (momGrowth.length || 1)).toFixed(1)}%` }, { label: 'Best Month', value: momGrowth.reduce((a, b) => a.growth > b.growth ? a : b).month }, { label: 'Worst Month', value: momGrowth.reduce((a, b) => a.growth < b.growth ? a : b).month, color: C.danger }]} />
        <div style={{ height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={momGrowth} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} unit="%" /><Tooltip contentStyle={TS} /><Bar dataKey="growth" name="Growth %" radius={[4, 4, 0, 0]} maxBarSize={40}>{momGrowth.map((d, i) => <Cell key={i} fill={d.growth >= 0 ? '#00c283' : '#e63946'} />)}</Bar></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'trend') return <div style={{ height: 300 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={momGrowth} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} unit="%" /><Tooltip contentStyle={TS} /><Line type="monotone" dataKey="growth" stroke="#e63946" strokeWidth={2.5} dot={{ r: 5, fill: '#e63946', strokeWidth: 2, stroke: '#fff' }} /></LineChart></ResponsiveContainer></div>;
    }
    if (m === 'pareto') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Accounts', value: byAccount.length }, { label: 'Top 10 Share', value: `${(paretoData.slice(0, 10).reduce((s, a) => s + a.value, 0) / (fyTotal || 1) * 100).toFixed(0)}%` }, { label: 'Top 20 Share', value: `${(paretoData.slice(0, 20).reduce((s, a) => s + a.value, 0) / (fyTotal || 1) * 100).toFixed(0)}%` }]} />
        <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={top20Pareto} margin={{ top: 20, right: 40, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888', angle: -30 }} interval={0} /><YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} unit="%" domain={[0, 100]} /><Tooltip contentStyle={TS} /><Bar yAxisId="left" dataKey="value" name="Revenue (Cr)" fill="#6366f1" radius={[3, 3, 0, 0]} maxBarSize={30} /><Line yAxisId="right" type="monotone" dataKey="cumulative" name="Cumulative %" stroke="#e62054" strokeWidth={2.5} dot={{ r: 3, fill: '#e62054' }} /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={paretoData.map((a, i) => ({ ...a, rank: i + 1 }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Account', key: 'name' }, { header: 'Revenue (₹ Cr)', key: 'value', align: 'right', bold: true }, { header: 'Cumulative %', key: 'cumulative', align: 'right', fmt: v => `${v}%` }]} />;
    }
    if (m === 'heatmap') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Owners', value: hmOwners.length }, { label: 'PO Types', value: byPOType.length }, { label: 'Max Value', value: `₹${hmMaxVal.toFixed(1)} Cr` }]} />
        <div style={{ overflowX: 'auto' }}><table style={{ borderCollapse: 'collapse', width: '100%' }}><thead><tr><th style={{ padding: '10px 12px', fontSize: '0.8rem', fontWeight: 800, color: '#6c757d', textAlign: 'left', borderBottom: '2px solid #eaedf2' }}>Owner</th>{byPOType.map(pt => <th key={pt.name} style={{ padding: '10px 8px', fontSize: '0.75rem', fontWeight: 800, color: '#6c757d', textAlign: 'center', borderBottom: '2px solid #eaedf2' }}>{pt.name}</th>)}</tr></thead><tbody>{hmData.map((row, i) => <tr key={i} style={{ backgroundColor: i % 2 === 0 ? '#fff' : '#fcfcfd' }}><td style={{ padding: '8px 12px', fontSize: '0.8rem', fontWeight: 700, color: '#2b2b2b', whiteSpace: 'nowrap' }}>{row.owner}</td>{byPOType.map(pt => { const v = row[pt.name] || 0; const intensity = v / hmMaxVal; return <td key={pt.name} style={{ padding: '8px', textAlign: 'center', backgroundColor: `rgba(230, 32, 84, ${intensity * 0.7})`, color: intensity > 0.35 ? '#fff' : '#2b2b2b', fontSize: '0.75rem', fontWeight: 700, borderRadius: 4 }}>{v > 0 ? v.toFixed(1) : '-'}</td>; })}</tr>)}</tbody></table></div>
      </>);
      if (modalTab === 'chart') {
        const cd = hmOwners.map(o => { const d = { name: o }; byPOType.forEach(pt => { d[pt.name] = parseFloat(fyRows.filter(r => r.portfolioowner === o && r.potypename === pt.name).reduce((s, r) => s + toCr(r.fy_total), 0).toFixed(2)); }); return d; });
        return <div style={{ height: Math.max(300, hmOwners.length * 50) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={cd} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} />{byPOType.map((pt, i) => <Bar key={i} dataKey={pt.name} stackId="a" fill={PIE_COLORS[i % PIE_COLORS.length]} maxBarSize={30} />)}</BarChart></ResponsiveContainer></div>;
      }
    }
    if (m === 'projects') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Projects', value: byProject.length }, { label: 'Top Project', value: top10Projects[0]?.name || '--' }, { label: 'Top Value', value: `₹${top10Projects[0]?.value || 0} Cr`, color: C.warning }]} />
        <div style={{ height: Math.max(300, top10Projects.length * 35) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={top10Projects} layout="vertical" margin={{ top: 0, right: 40, left: 140, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 9, fill: '#888' }} axisLine={false} tickLine={false} width={140} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={20}>{top10Projects.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={top10Projects.map((p, i) => ({ ...p, rank: i + 1 }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Project', key: 'name' }, { header: 'Revenue (₹ Cr)', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'poage') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={byPOAge.map(a => ({ label: a.name, value: `₹${a.value} Cr`, color: C.cyan }))} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byPOAge} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byPOAge.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byPOAge} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={50}>{byPOAge.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
        </div></>);
      if (modalTab === 'detail') {
        const ageOwnerMap = {}; fyRows.forEach(r => { const d = r.podate ? new Date(r.podate) : null; const y = d ? d.getFullYear() : 0; const b = !y ? 'Unknown' : y < 2018 ? 'Pre-2018' : y < 2022 ? '2018-21' : '2022+'; byOwner.slice(0, 6).forEach(o => { if (r.portfolioowner === o.name) { if (!ageOwnerMap[b]) ageOwnerMap[b] = {}; ageOwnerMap[b][o.name] = (ageOwnerMap[b][o.name] || 0) + toCr(r.fy_total); } }); });
        const ad = byOwner.slice(0, 6).map(o => { const d = { name: o.name }; byPOAge.forEach(a => { d[a.name] = parseFloat((ageOwnerMap[a.name]?.[o.name] || 0).toFixed(2)); }); return d; });
        return <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={ad} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} /><Tooltip contentStyle={TS} />{byPOAge.map((a, i) => <Bar key={i} dataKey={a.name} stackId="a" fill={PIE_COLORS[i % PIE_COLORS.length]} maxBarSize={40} />)}</BarChart></ResponsiveContainer></div>;
      }
    }
    if (m === 'quarterly') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={quarterly.map(q => ({ label: q.quarter, value: `₹${q.total.toFixed(1)} Cr` }))} />
        <div style={{ height: 350 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={quarterly} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="quarter" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} />{byOwner.slice(0, 5).map((o, i) => <Bar key={i} dataKey={o.name} stackId="a" fill={PIE_COLORS[i]} maxBarSize={60} />)}</BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'trend') return <div style={{ height: 350 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={quarterly} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="quarter" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Line type="monotone" dataKey="total" stroke="#ec4899" strokeWidth={3} dot={{ r: 6, fill: '#ec4899', strokeWidth: 2, stroke: '#fff' }} name="Total Revenue" /></LineChart></ResponsiveContainer></div>;
    }
    if (m === 'yoy') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'FY25 Total', value: `₹${yoyData.reduce((s, d) => s + d.FY25, 0).toFixed(1)} Cr` }, { label: 'FY26 Total', value: `₹${yoyData.reduce((s, d) => s + d.FY26, 0).toFixed(1)} Cr`, color: C.success }, { label: 'YoY Growth', value: (() => { const f25 = yoyData.reduce((s, d) => s + d.FY25, 0); const f26 = yoyData.reduce((s, d) => s + d.FY26, 0); return f25 > 0 ? `${((f26 - f25) / f25 * 100).toFixed(1)}%` : 'N/A'; })() }]} />
        <div style={{ height: 400 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={yoyData} margin={{ top: 20, right: 40, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Legend /><Line type="monotone" dataKey="FY25" stroke="#c1c8fa" strokeWidth={2.5} dot={{ r: 4, fill: '#c1c8fa' }} strokeDasharray="5 5" /><Line type="monotone" dataKey="FY26" stroke="#14b8a6" strokeWidth={2.5} dot={{ r: 4, fill: '#14b8a6', strokeWidth: 2, stroke: '#fff' }} /></LineChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'delta') {
        const deltaData = yoyData.map(d => ({ month: d.month, delta: parseFloat((d.FY26 - d.FY25).toFixed(2)) }));
        return <div style={{ height: 350 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={deltaData} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Bar dataKey="delta" name="FY26 - FY25 (Cr)" radius={[4, 4, 0, 0]} maxBarSize={40}>{deltaData.map((d, i) => <Cell key={i} fill={d.delta >= 0 ? '#14b8a6' : '#e63946'} />)}</Bar></BarChart></ResponsiveContainer></div>;
      }
    }

    // EXECUTION MODALS (new)
    if (m === 'projectStatus') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Projects', value: totalProjects }, { label: 'Statuses', value: byStatus.length }, { label: 'Most Common', value: byStatus[0]?.name || '--' }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 350 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byStatus} cx="50%" cy="50%" innerRadius={60} outerRadius={110} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byStatus.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byStatus} columns={[{ header: 'Status', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }, { header: 'Share', key: 'pct', align: 'right', fmt: (_v, r) => `${(r.value / (totalProjects || 1) * 100).toFixed(1)}%` }]} /></div>
        </div></>);
      if (modalTab === 'table') return <DataTable rows={byStatus} columns={[{ header: 'Status', key: 'name' }, { header: 'Count', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execOwner') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Owners', value: byExecOwner.length }, { label: 'Top Owner', value: byExecOwner[0]?.name || '--' }, { label: 'Projects', value: byExecOwner[0]?.count || 0 }]} />
        <div style={{ height: Math.max(300, byExecOwner.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byExecOwner} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="count" name="Projects" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#4361ee" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'poamount') return (<>
        <SummaryRow items={[{ label: 'Top Owner PO', value: `₹${byExecOwner[0]?.poAmount || 0} Cr` }]} />
        <div style={{ height: Math.max(300, byExecOwner.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byExecOwner} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="poAmount" name="PO Amount (Cr)" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#fca311" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byExecOwner} columns={[{ header: 'Owner', key: 'name' }, { header: 'Projects', key: 'count', align: 'right' }, { header: 'PO Amount (₹ Cr)', key: 'poAmount', align: 'right', bold: true }]} />;
    }
    if (m === 'execAssignee') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Assignees', value: byAssignee.length }, { label: 'Top Assignee', value: byAssignee[0]?.name || '--' }, { label: 'Projects', value: byAssignee[0]?.value || 0 }]} />
        <div style={{ height: Math.max(300, byAssignee.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byAssignee} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" name="Projects" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#00c283" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byAssignee} columns={[{ header: 'Assignee', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execCategory') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Categories', value: byCategory.length }, { label: 'Top Category', value: byCategory[0]?.name || '--' }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byCategory} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byCategory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byCategory} columns={[{ header: 'Category', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} /></div>
        </div></>);
      if (modalTab === 'table') return <DataTable rows={byCategory} columns={[{ header: 'Category', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execBillable') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Projects', value: totalProjects }, { label: 'Billable', value: byBillable.find(x => x.name === 'Billable')?.value || 0 }, { label: 'Non-Billable', value: byBillable.find(x => x.name === 'Non-Billable')?.value || 0 }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byBillable} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byBillable.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byBillable} columns={[{ header: 'Type', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} /></div>
        </div></>);
      if (modalTab === 'table') return <DataTable rows={byBillable} columns={[{ header: 'Type', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execCompletion') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={byCompletion.map(c => ({ label: c.name, value: c.value, color: C.info }))} />
        <div style={{ height: 300 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byCompletion} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#888' }} /><Tooltip contentStyle={TS} /><Bar dataKey="value" name="Projects" radius={[4, 4, 0, 0]} maxBarSize={50}>{byCompletion.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byCompletion} columns={[{ header: 'Completion Range', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execAccount') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Accounts', value: byExecAccount.length }, { label: 'Top Account', value: byExecAccount[0]?.name || '--' }, { label: 'Projects', value: byExecAccount[0]?.value || 0 }]} />
        <div style={{ height: Math.max(300, top5ExecAccounts.length * 50) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={top5ExecAccounts} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" name="Projects" radius={[0, 4, 4, 0]} maxBarSize={24} fill="#e62054" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byExecAccount.map((a, i) => ({ ...a, rank: i + 1 }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Account', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execRevArea') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Revenue Areas', value: byRevArea.length }, { label: 'Top Area', value: byRevArea[0]?.name || '--' }]} />
        <div style={{ height: Math.max(300, byRevArea.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byRevArea} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="value" name="Projects" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#06b6d4" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byRevArea} columns={[{ header: 'Revenue Area', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execIDR') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'IDR Statuses', value: byIDR.length }, { label: 'Top Status', value: byIDR[0]?.name || '--' }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byIDR} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byIDR.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byIDR} columns={[{ header: 'IDR SignOff', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} /></div>
        </div></>);
      if (modalTab === 'table') return <DataTable rows={byIDR} columns={[{ header: 'IDR SignOff', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execActive') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Projects', value: totalProjects }, { label: 'Active', value: activeCount }, { label: 'Active %', value: `${activePct}%`, color: activePct >= 70 ? C.success : C.warning }]} />
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1, height: 300 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byActive} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>{byActive.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          <div style={{ flex: 1 }}><DataTable rows={byActive} columns={[{ header: 'Active Status', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} /></div>
        </div></>);
      if (modalTab === 'table') return <DataTable rows={byActive} columns={[{ header: 'Active Status', key: 'name' }, { header: 'Projects', key: 'value', align: 'right', bold: true }]} />;
    }
    if (m === 'execDuration') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Owners', value: byDuration.length }, { label: 'Longest Avg', value: `${byDuration[0]?.avg || 0} days` }, { label: 'Shortest Avg', value: `${byDuration[byDuration.length - 1]?.avg || 0} days` }]} />
        <div style={{ height: Math.max(300, byDuration.length * 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byDuration} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f2f5" /><XAxis type="number" hide /><YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#888' }} axisLine={false} tickLine={false} width={120} /><Tooltip contentStyle={TS} /><Bar dataKey="avg" name="Avg Days" radius={[0, 4, 4, 0]} maxBarSize={20} fill="#8b5cf6" /></BarChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={byDuration} columns={[{ header: 'Owner', key: 'name' }, { header: 'Avg Duration (days)', key: 'avg', align: 'right', bold: true }]} />;
    }
    if (m === 'execGoLive') {
      if (modalTab === 'overview') return (<>
        <SummaryRow items={[{ label: 'Total Projects', value: totalProjects }, { label: 'With Go-Live Date', value: goLiveCount }, { label: 'Without', value: totalProjects - goLiveCount, color: C.danger }]} />
        <div style={{ height: 350 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={[{ name: 'Has Go-Live', value: goLiveCount }, { name: 'No Go-Live', value: totalProjects - goLiveCount }]} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}><Cell fill="#00c283" /><Cell fill="#e63946" /></Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
      </>);
      if (modalTab === 'table') return <DataTable rows={goLiveProjects.slice(0, 50).map((r, i) => ({ rank: i + 1, name: r.projectname || 'Unknown', company: r.companyname || 'Unknown', date: r['Go-Live Date History'] || '--' }))} columns={[{ header: '#', key: 'rank', flex: 0.4 }, { header: 'Project', key: 'name' }, { header: 'Account', key: 'company' }, { header: 'Go-Live Date', key: 'date', align: 'right' }]} />;
    }
    return null;
  };

  // ─── MODAL TITLES & TABS ───
  const modalCfg = {
    monthly: { title: 'Service Revenue — Monthly Trend', tabs: [{ key: 'overview', label: 'Monthly Trend' }, { key: 'byOwner', label: 'By Owner' }] },
    owner: { title: 'Revenue by Portfolio Owner', tabs: [{ key: 'overview', label: 'Overview' }, { key: 'monthly', label: 'Monthly Split' }] },
    account: { title: 'Revenue by Account (Top 5)', tabs: [{ key: 'overview', label: 'Top 5 Overview' }, { key: 'all', label: 'All Accounts' }] },
    potype: { title: 'Revenue by PO Type', tabs: [{ key: 'overview', label: 'PO Type Split' }, { key: 'byOwner', label: 'By Owner' }] },
    manager: { title: 'Revenue by Manager', tabs: [{ key: 'overview', label: 'Overview' }, { key: 'byAccount', label: 'By Account' }] },
    territory: { title: 'Revenue by Territory', tabs: [{ key: 'overview', label: 'Territory Split' }, { key: 'byOwner', label: 'By Owner' }] },
    subowner: { title: 'Revenue by Sub-Portfolio Owner', tabs: [{ key: 'overview', label: 'Top 15' }, { key: 'table', label: 'Full Table' }] },
    pocorr: { title: 'PO Count vs Revenue Correlation', tabs: [{ key: 'overview', label: 'Scatter Plot' }, { key: 'table', label: 'Data Table' }] },
    mom: { title: 'Month-over-Month Growth Rate', tabs: [{ key: 'overview', label: 'Bar Chart' }, { key: 'trend', label: 'Trend Line' }] },
    pareto: { title: 'Account Concentration (Pareto)', tabs: [{ key: 'overview', label: 'Pareto Chart' }, { key: 'table', label: 'Full Table' }] },
    heatmap: { title: 'Owner × PO Type Heatmap', tabs: [{ key: 'overview', label: 'Heatmap' }, { key: 'chart', label: 'Stacked Bar' }] },
    projects: { title: 'Top Projects by Revenue', tabs: [{ key: 'overview', label: 'Top 10' }, { key: 'table', label: 'Full Table' }] },
    poage: { title: 'PO Age / Vintage Analysis', tabs: [{ key: 'overview', label: 'Distribution' }, { key: 'detail', label: 'By Owner' }] },
    quarterly: { title: 'Quarterly Revenue Comparison', tabs: [{ key: 'overview', label: 'Stacked Bar' }, { key: 'trend', label: 'Trend' }] },
    yoy: { title: 'Year-over-Year Comparison', tabs: [{ key: 'overview', label: 'FY25 vs FY26' }, { key: 'delta', label: 'Delta' }] },
    projectStatus: { title: 'Project Status Distribution', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execOwner: { title: 'Projects by Portfolio Owner', tabs: [{ key: 'overview', label: 'Project Count' }, { key: 'poamount', label: 'PO Amount' }, { key: 'table', label: 'Full Table' }] },
    execAssignee: { title: 'Projects by Assignee', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execCategory: { title: 'Projects by Category', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execBillable: { title: 'Billable vs Non-Billable', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execCompletion: { title: 'Project Completion %', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execAccount: { title: 'Top Accounts by Project Count', tabs: [{ key: 'overview', label: 'Top 5' }, { key: 'table', label: 'All Accounts' }] },
    execRevArea: { title: 'Projects by Revenue Area', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execIDR: { title: 'IDR SignOff Status', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execActive: { title: 'Active Projects', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execDuration: { title: 'Avg Project Duration by Owner', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Table' }] },
    execGoLive: { title: 'Go-Live Date Tracker', tabs: [{ key: 'overview', label: 'Chart' }, { key: 'table', label: 'Project List' }] },
  };
  const cfg = modalCfg[modal] || {};

  return (
    <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
      {/* Sidebar */}
      <div className="sidebar" style={{ backgroundColor: '#1a1d2d', width: 280, padding: 16, overflowY: 'auto' }}>
        <div style={{ backgroundColor: '#26293d', borderRadius: 12, padding: '20px 16px', marginBottom: 16, textAlign: 'center', boxShadow: 'inset 0 0 20px rgba(0,0,0,0.2)' }}>
          <div style={{ position: 'relative', width: 120, height: 120, margin: '0 auto' }}>
            <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={[{ value: sv }, { value: 100 - sv }]} cx="50%" cy="50%" startAngle={210} endAngle={-30} innerRadius={45} outerRadius={55} dataKey="value" stroke="none" cornerRadius={4}><Cell fill={sc} /><Cell fill="#3a3d54" /></Pie></PieChart></ResponsiveContainer>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: '2rem', fontWeight: 800, color: sc }}>{sv}</span><span style={{ fontSize: '0.7rem', color: '#888' }}>/ 100</span></div></div>
          <div style={{ color: sc, fontWeight: 700, fontSize: '0.75rem', marginTop: 12, letterSpacing: 1 }}>{sv >= 90 ? 'ON TRACK' : sv >= 70 ? 'NEEDS ATTENTION' : 'AT RISK'}</div>
          <div style={{ color: '#e62054', fontWeight: 800, fontSize: '0.8rem', marginTop: 4 }}>CUMULATIVE OKR SCORE</div></div>
        <div style={{ padding: 0, background: 'transparent' }}>
          <SideSection icon="💰" title="Financial" weightStr={wSR.toFixed(1) + ' / 30%'} count={15} isOpen={sF} onToggle={() => setSF(!sF)}>
            <SidebarItem title="Service Revenue (Monthly)" weight={20} pct={pct + '%'} color={pct >= 80 ? C.success : C.warning} onClick={() => drill('monthly')} />
            <SidebarItem title="By Portfolio Owner" weight={5} pct={`${byOwner.length}`} color={C.info} onClick={() => drill('owner')} />
            <SidebarItem title="Top 5 Accounts" weight={5} pct={`${top5Accounts.length}`} color={C.primary} onClick={() => drill('account')} />
            <SidebarItem title="By PO Type" weight={5} pct={`${byPOType.length}`} color={C.warning} onClick={() => drill('potype')} />
            <SidebarItem title="By Manager" weight={5} pct={`${byManager.length}`} color={C.success} onClick={() => drill('manager')} />
            <SidebarItem title="By Territory" weight={3} pct={`${byTerritory.length}`} color={C.cyan} onClick={() => drill('territory')} />
            <SidebarItem title="Sub-Portfolio Owner" weight={3} pct={`${bySubOwner.length}`} color={C.purple} onClick={() => drill('subowner')} />
            <SidebarItem title="PO Count vs Revenue" weight={3} pct={`${poCorrelation.length}`} color={C.orange} onClick={() => drill('pocorr')} />
            <SidebarItem title="MoM Growth" weight={3} pct={`${momGrowth.length}mo`} color={C.danger} onClick={() => drill('mom')} />
            <SidebarItem title="Account Pareto" weight={3} pct={`${byAccount.length}`} color={GRADIENTS.pareto} onClick={() => drill('pareto')} />
            <SidebarItem title="Owner×PO Heatmap" weight={3} pct={`${hmOwners.length}×${byPOType.length}`} color={GRADIENTS.heatmap} onClick={() => drill('heatmap')} />
            <SidebarItem title="Top Projects" weight={3} pct={`${byProject.length}`} color={C.warning} onClick={() => drill('projects')} />
            <SidebarItem title="PO Age Analysis" weight={3} pct={`${byPOAge.length}`} color={GRADIENTS.poAge} onClick={() => drill('poage')} />
            <SidebarItem title="Quarterly Comparison" weight={3} pct="4Q" color={GRADIENTS.quarterly} onClick={() => drill('quarterly')} />
            <SidebarItem title="YoY Comparison" weight={3} pct="FY25-26" color={GRADIENTS.yoy} onClick={() => drill('yoy')} />
          </SideSection>
          <SideSection icon="⚙️" title="Execution" weightStr={`${totalProjects} projects`} count={12} isOpen={sE} onToggle={() => setSE(!sE)}>
            <SidebarItem title="Project Status" weight={5} pct={`${byStatus.length}`} color={C.primary} onClick={() => drill('projectStatus')} />
            <SidebarItem title="By Portfolio Owner" weight={5} pct={`${byExecOwner.length}`} color={C.info} onClick={() => drill('execOwner')} />
            <SidebarItem title="By Assignee" weight={5} pct={`${byAssignee.length}`} color={C.success} onClick={() => drill('execAssignee')} />
            <SidebarItem title="Project Category" weight={5} pct={`${byCategory.length}`} color={C.warning} onClick={() => drill('execCategory')} />
            <SidebarItem title="Billable Split" weight={5} pct={`${byBillable.length}`} color={C.purple} onClick={() => drill('execBillable')} />
            <SidebarItem title="Completion %" weight={5} pct={`${byCompletion.length}`} color={C.cyan} onClick={() => drill('execCompletion')} />
            <SidebarItem title="Top Accounts" weight={5} pct={`${byExecAccount.length}`} color={C.danger} onClick={() => drill('execAccount')} />
            <SidebarItem title="Revenue Area" weight={5} pct={`${byRevArea.length}`} color={C.orange} onClick={() => drill('execRevArea')} />
            <SidebarItem title="IDR SignOff" weight={5} pct={`${byIDR.length}`} color={C.info} onClick={() => drill('execIDR')} />
            <SidebarItem title="Active Projects" weight={5} pct={`${activePct}%`} color={activePct >= 70 ? C.success : C.warning} onClick={() => drill('execActive')} />
            <SidebarItem title="Avg Duration" weight={5} pct={`${byDuration.length}`} color={C.purple} onClick={() => drill('execDuration')} />
            <SidebarItem title="Go-Live Tracker" weight={5} pct={`${goLiveCount}`} color={C.success} onClick={() => drill('execGoLive')} />
          </SideSection>
          <SideSection icon="🎧" title="Support" weightStr="5 / 15%" count={1} isOpen={sS} onToggle={() => setSS(!sS)}>
            <SidebarItem title="SLA Adherence" weight={10} pct="92%" color={C.success} /></SideSection>
          <SideSection icon="👥" title="People" weightStr="7 / 10%" count={1} isOpen={sP} onToggle={() => setSP(!sP)}>
            <SidebarItem title="Billable Utilization" weight={10} pct="74%" color={C.warning} /></SideSection>
        </div></div>

      {/* Main Content */}
      <div className="main-content" style={{ padding: 16, backgroundColor: '#fef1f2', flex: 1, overflow: 'auto' }}>
        <div style={{ backgroundColor: '#fffdf5', border: '1px solid #ffe8a1', borderRadius: 8, padding: '8px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.8rem', color: '#b8860b', fontWeight: 600 }}>
          <AlertTriangle size={14} /> {loading || projLoading ? 'Loading live data...' : `Delivery · ${selectedFy} · ${fyRows.length} POs · ₹${achieved} Cr · ${totalProjects} Projects`}
        </div>

        <SectionHeader title="Financial" icon={<span style={{ color: '#fca311' }}>💰</span>} isOpen={cF} onToggle={() => setCF(!cF)} rightContent={<span style={{ color: '#888' }}>{wSR.toFixed(1)} / 30%</span>} />
        {cF && <div style={{ backgroundColor: 'white', padding: 16, borderRadius: '0 0 8px 8px', border: '1px solid #eaedf2', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 16 }}>
          <Card title="SERVICE REVENUE (MONTHLY)" topColor={C.danger} badge={`${pct}%`} badgeColor="#fde8ea" onClick={() => drill('monthly')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>₹{achieved} Cr <span style={{ fontSize: '0.75rem', color: '#adb5bd' }}>/ ₹{target} Cr</span></div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={monthly} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888' }} /><YAxis hide /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#c1c8fa" radius={[2, 2, 0, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="REVENUE BY PORTFOLIO OWNER" topColor={C.info} badge={`${byOwner.length}`} badgeColor="#e8f0fe" onClick={() => drill('owner')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byOwner.length} Owners</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byOwner.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#4361ee" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="TOP 5 ACCOUNTS" topColor={C.primary} badge={`Top ${top5Accounts.length}`} badgeColor="#fde8ea" onClick={() => drill('account')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>₹{top5Accounts.reduce((s, a) => s + a.value, 0).toFixed(1)} Cr</div>
            <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
              {top5Accounts.slice(0, 5).map((a, i) => <div key={i} style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: '0.6rem', color: '#888', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
                <div style={{ height: 60, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                  <div style={{ width: '100%', backgroundColor: PIE_COLORS[i], borderRadius: '4px 4px 0 0', height: `${(a.value / (top5Accounts[0]?.value || 1)) * 100}%`, minHeight: 4 }} /></div>
                <div style={{ fontSize: '0.6rem', fontWeight: 700, color: '#2b2b2b' }}>₹{a.value}</div>
              </div>)}
            </div>
          </Card>
          <Card title="REVENUE BY PO TYPE" topColor={C.warning} badge={`${byPOType.length}`} badgeColor="#fffdf5" onClick={() => drill('potype')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byPOType.length} Types</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byPOType} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byPOType.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="REVENUE BY MANAGER" topColor={C.success} badge={`${byManager.length}`} badgeColor="#e6fcf5" onClick={() => drill('manager')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byManager.length} Managers</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byManager.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#00c283" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="REVENUE BY TERRITORY" topColor={GRADIENTS.territory} badge={`${byTerritory.length}`} badgeColor="#e0f7fa" onClick={() => drill('territory')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byTerritory.length} Regions</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byTerritory} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byTerritory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="SUB-PORTFOLIO OWNER" topColor={GRADIENTS.subOwner} badge={`${bySubOwner.length}`} badgeColor="#f0e6ff" onClick={() => drill('subowner')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{bySubOwner.length} Sub-Owners</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={bySubOwner.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#8b5cf6" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="PO COUNT vs REVENUE" topColor={GRADIENTS.scatter} badge={`${poCorrelation.length}`} badgeColor="#fff3e0" onClick={() => drill('pocorr')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{fyRows.length} POs</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><ScatterChart margin={{ top: 10, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" stroke="#f0f2f5" /><XAxis type="number" dataKey="count" hide /><YAxis type="number" dataKey="revenue" hide /><ZAxis type="number" dataKey="avg" range={[40, 400]} /><Tooltip contentStyle={TS} /><Scatter data={poCorrelation} fill="#f97316">{poCorrelation.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Scatter></ScatterChart></ResponsiveContainer></div>
          </Card>
          <Card title="MONTH-OVER-MONTH GROWTH" topColor={GRADIENTS.mom} badge={`${(momGrowth.reduce((s, m) => s + m.growth, 0) / (momGrowth.length || 1)).toFixed(0)}%`} badgeColor="#fde8ea" onClick={() => drill('mom')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{momGrowth.length} Months</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={momGrowth} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888' }} /><YAxis hide /><Tooltip contentStyle={TS} /><Bar dataKey="growth" radius={[2, 2, 0, 0]} maxBarSize={16}>{momGrowth.map((d, i) => <Cell key={i} fill={d.growth >= 0 ? '#00c283' : '#e63946'} />)}</Bar></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="ACCOUNT CONCENTRATION (PARETO)" topColor={GRADIENTS.pareto} badge={`${byAccount.length}`} badgeColor="#ede8fe" onClick={() => drill('pareto')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byAccount.length} Accounts</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><AreaChart data={top20Pareto} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 0 }} /><YAxis hide /><Tooltip contentStyle={TS} /><Area type="monotone" dataKey="cumulative" stroke="#6366f1" fill="rgba(99,102,241,0.15)" strokeWidth={2} dot={false} /></AreaChart></ResponsiveContainer></div>
          </Card>
          <Card title="OWNER × PO TYPE HEATMAP" topColor={GRADIENTS.heatmap} badge={`${hmOwners.length}×${byPOType.length}`} badgeColor="#e6fcf0" onClick={() => drill('heatmap')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>Matrix View</div>
            <div style={{ marginTop: 8, display: 'grid', gridTemplateColumns: `60px repeat(${byPOType.length}, 1fr)`, gap: 2, fontSize: '0.55rem' }}>
              <div /><div />{byPOType.map(pt => <div key={pt.name} style={{ textAlign: 'center', color: '#888', fontWeight: 700, fontSize: '0.5rem' }}>{pt.name.slice(0, 6)}</div>)}
              {hmData.slice(0, 5).map((row, i) => <React.Fragment key={i}>
                <div style={{ color: '#888', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{row.owner.split(' ')[0]}</div>
                {byPOType.map(pt => { const v = row[pt.name] || 0; return <div key={pt.name} style={{ backgroundColor: `rgba(230, 32, 84, ${v / hmMaxVal * 0.6})`, borderRadius: 2, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', color: v / hmMaxVal > 0.3 ? '#fff' : '#888', fontWeight: 700 }}>{v > 0 ? v.toFixed(0) : ''}</div>; })}
              </React.Fragment>)}
            </div>
          </Card>
          <Card title="TOP PROJECTS BY REVENUE" topColor={GRADIENTS.projects} badge={`${top10Projects.length}`} badgeColor="#fef3cd" onClick={() => drill('projects')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byProject.length} Projects</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={top10Projects.slice(0, 5)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#f59e0b" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="PO AGE / VINTAGE ANALYSIS" topColor={GRADIENTS.poAge} badge={`${byPOAge.length}`} badgeColor="#e0f2fe" onClick={() => drill('poage')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byPOAge.length} Buckets</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byPOAge} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byPOAge.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="QUARTERLY REVENUE" topColor={GRADIENTS.quarterly} badge="4Q" badgeColor="#fce4ec" onClick={() => drill('quarterly')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>₹{quarterly.reduce((s, q) => s + q.total, 0).toFixed(1)} Cr</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={quarterly} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="quarter" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} /><YAxis hide /><Tooltip contentStyle={TS} />{byOwner.slice(0, 5).map((o, i) => <Bar key={i} dataKey={o.name} stackId="a" fill={PIE_COLORS[i]} maxBarSize={30} />)}</BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="YEAR-OVER-YEAR (FY25 vs FY26)" topColor={GRADIENTS.yoy} badge="YoY" badgeColor="#e0f7f0" onClick={() => drill('yoy')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>FY25 vs FY26</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={yoyData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888' }} /><YAxis hide /><Tooltip contentStyle={TS} /><Line type="monotone" dataKey="FY25" stroke="#c1c8fa" strokeWidth={1.5} dot={false} strokeDasharray="4 4" /><Line type="monotone" dataKey="FY26" stroke="#14b8a6" strokeWidth={2} dot={{ r: 2 }} /></LineChart></ResponsiveContainer></div>
          </Card>
        </div>}

        {/* Execution */}
        <SectionHeader title="Execution" icon={<span style={{ color: '#4361ee' }}>⚙️</span>} isOpen={cE} onToggle={() => setCE(!cE)} rightContent={<span style={{ color: '#888' }}>{totalProjects} projects</span>} />
        {cE && <div style={{ backgroundColor: 'white', padding: 16, borderRadius: '0 0 8px 8px', border: '1px solid #eaedf2', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 16 }}>
          <Card title="PROJECT STATUS" topColor={C.primary} badge={`${byStatus.length}`} badgeColor="#fde8ea" onClick={() => drill('projectStatus')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{totalProjects} Projects</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byStatus.slice(0, 6)} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byStatus.slice(0, 6).map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="BY PORTFOLIO OWNER" topColor={C.info} badge={`${byExecOwner.length}`} badgeColor="#e8f0fe" onClick={() => drill('execOwner')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byExecOwner.length} Owners</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byExecOwner.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="count" fill="#4361ee" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="BY ASSIGNEE" topColor={C.success} badge={`${byAssignee.length}`} badgeColor="#e6fcf5" onClick={() => drill('execAssignee')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byAssignee.length} Assignees</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byAssignee.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#00c283" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="PROJECT CATEGORY" topColor={C.warning} badge={`${byCategory.length}`} badgeColor="#fffdf5" onClick={() => drill('execCategory')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byCategory.length} Categories</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byCategory.slice(0, 6)} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byCategory.slice(0, 6).map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="BILLABLE SPLIT" topColor={C.purple} badge={`${byBillable.length}`} badgeColor="#f0e6ff" onClick={() => drill('execBillable')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byBillable.find(x => x.name === 'Billable')?.value || 0} Billable</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byBillable} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byBillable.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="COMPLETION %" topColor={C.cyan} badge={`${byCompletion.length}`} badgeColor="#e0f7fa" onClick={() => drill('execCompletion')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>Distribution</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byCompletion} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f2f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#888' }} /><YAxis hide /><Tooltip contentStyle={TS} /><Bar dataKey="value" radius={[2, 2, 0, 0]} maxBarSize={24}>{byCompletion.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Bar></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="TOP ACCOUNTS" topColor={C.danger} badge={`${top5ExecAccounts.length}`} badgeColor="#fde8ea" onClick={() => drill('execAccount')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{top5ExecAccounts.reduce((s, a) => s + a.value, 0)} Projects</div>
            <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
              {top5ExecAccounts.map((a, i) => <div key={i} style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: '0.6rem', color: '#888', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
                <div style={{ height: 60, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                  <div style={{ width: '100%', backgroundColor: PIE_COLORS[i], borderRadius: '4px 4px 0 0', height: `${(a.value / (top5ExecAccounts[0]?.value || 1)) * 100}%`, minHeight: 4 }} /></div>
                <div style={{ fontSize: '0.6rem', fontWeight: 700, color: '#2b2b2b' }}>{a.value}</div>
              </div>)}
            </div>
          </Card>
          <Card title="REVENUE AREA" topColor={GRADIENTS.territory} badge={`${byRevArea.length}`} badgeColor="#e0f7fa" onClick={() => drill('execRevArea')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byRevArea.length} Areas</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byRevArea.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="value" fill="#06b6d4" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="IDR SIGNOFF" topColor={C.info} badge={`${byIDR.length}`} badgeColor="#e8f0fe" onClick={() => drill('execIDR')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byIDR.length} Statuses</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byIDR.slice(0, 6)} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byIDR.slice(0, 6).map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="ACTIVE PROJECTS" topColor={activePct >= 70 ? C.success : C.warning} badge={`${activePct}%`} badgeColor={activePct >= 70 ? '#e6fcf5' : '#fffdf5'} onClick={() => drill('execActive')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{activeCount} Active</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byActive} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value">{byActive.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
          <Card title="AVG DURATION" topColor={C.purple} badge={`${byDuration.length}`} badgeColor="#f0e6ff" onClick={() => drill('execDuration')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{byDuration[0]?.avg || 0} days max</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={byDuration.slice(0, 6)} layout="vertical" margin={{ top: 5, right: 0, left: -10, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" /><XAxis type="number" axisLine={false} tickLine={false} /><YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#888' }} width={90} /><Tooltip contentStyle={TS} /><Bar dataKey="avg" fill="#8b5cf6" radius={[0, 4, 4, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div>
          </Card>
          <Card title="GO-LIVE TRACKER" topColor={C.success} badge={`${goLiveCount}`} badgeColor="#e6fcf5" onClick={() => drill('execGoLive')}>
            <div style={{ fontSize: '1.2rem', color: '#2b2b2b', fontWeight: 800, margin: '4px 0' }}>{goLiveCount} / {totalProjects}</div>
            <div style={{ height: 120, marginTop: 8 }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={[{ name: 'Has Go-Live', value: goLiveCount }, { name: 'No Go-Live', value: totalProjects - goLiveCount }]} cx="50%" cy="50%" outerRadius={50} innerRadius={25} dataKey="value"><Cell fill="#00c283" /><Cell fill="#e63946" /></Pie><Tooltip contentStyle={TS} /></PieChart></ResponsiveContainer></div>
          </Card>
        </div>}

        <SectionHeader title="Support" icon={<span style={{ color: '#e62054' }}>🎧</span>} isOpen={cS} onToggle={() => setCS(!cS)} rightContent={<span style={{ color: '#888' }}>5 / 15%</span>} />
        {cS && <div style={{ backgroundColor: 'white', padding: 40, borderRadius: '0 0 8px 8px', border: '1px solid #eaedf2', fontSize: '0.85rem', color: '#888', textAlign: 'center' }}>Support metrics coming soon</div>}

        <SectionHeader title="People & Capacity" icon={<span style={{ color: '#00c283' }}>👥</span>} isOpen={cP} onToggle={() => setCP(!cP)} rightContent={<span style={{ color: '#888' }}>7 / 10%</span>} />
        {cP && <div style={{ backgroundColor: 'white', padding: 40, borderRadius: '0 0 8px 8px', border: '1px solid #eaedf2', fontSize: '0.85rem', color: '#888', textAlign: 'center' }}>People metrics coming soon</div>}
      </div>

      <DrillModal open={!!modal} onClose={() => setModal(null)} title={cfg.title || ''} tabs={cfg.tabs || []} activeTab={modalTab} setActiveTab={setModalTab}>
        {renderModalContent()}
      </DrillModal>
    </div>);
}
