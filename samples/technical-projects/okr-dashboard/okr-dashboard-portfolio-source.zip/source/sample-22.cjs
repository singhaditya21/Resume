const puppeteer = require('puppeteer');

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    page.on('console', msg => { if(msg.type() === 'error') console.log('PAGE ERROR LOG:', msg.text()) });
    page.on('pageerror', error => console.log('PAGE CRASH:', error.message));
    
    await page.goto('https://example.invalid');
    // Find the select dropdown and select Sales
    await page.waitForSelector('select');
    const selects = await page.$$('select');
    // Assuming the role one has options KAM and Sales. Let's just find the first one that has "Sales".
    for(let s of selects) {
        const text = await page.evaluate(el => el.textContent, s);
        if(text.includes('Sales')) {
            await s.select('Sales');
        }
    }
    await new Promise(r => setTimeout(r, 2000));
    await browser.close();
})();
