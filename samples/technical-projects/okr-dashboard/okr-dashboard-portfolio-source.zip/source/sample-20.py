import psycopg2
import os

try:
    print("Checking schema...")
    conn = psycopg2.connect(
        host="192.0.2.10",
        dbname="DataMart_Bizops",
        user="PORTFOLIO_REDACTED",
        password=os.environ.get("DB_PASSWORD", "BizTech@123")
    )
    cur = conn.cursor()
    cur.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema='dbo' AND table_name='service_arr'")
    rows = cur.fetchall()
    for row in rows:
        print(row)
        
    print("Sample data:")
    cur.execute("SELECT * FROM dbo.service_arr LIMIT 5")
    samples = cur.fetchall()
    for s in samples:
        print(s)
except Exception as e:
    print("Error:", e)
