import psycopg2
conn = psycopg2.connect(dbname='DataMart_Bizops',user='PORTFOLIO_REDACTED',password='REDACTED_SECRET',host='192.0.2.10')
cur = conn.cursor()
cur.execute("SELECT table_name FROM information_schema.views WHERE table_schema='dbo' AND table_name LIKE '%billing%'")
print(cur.fetchall())
