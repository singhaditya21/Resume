import psycopg2
import psycopg2.extras
import json

def get_schema():
    try:
        conn = psycopg2.connect(
            host='192.0.2.10',
            database='DataMart_Bizops',
            user='PORTFOLIO_REDACTED',
            password=REDACTED_SECRET
            port='5432'
        )
        with conn.cursor() as cur:
            cur.execute("""
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_schema = 'dbo' AND table_name = 'qbr_herostory';
            """)
            schema = cur.fetchall()
            print("SCHEMA:")
            for col in schema:
                print(f"- {col[0]} ({col[1]})")
                
            cur.execute("SELECT * FROM dbo.qbr_herostory LIMIT 5")
            rows = cur.fetchall()
            col_names = [desc[0] for desc in cur.description]
            print("\nSAMPLE DATA:")
            for row in rows:
                print(dict(zip(col_names, row)))
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    get_schema()
