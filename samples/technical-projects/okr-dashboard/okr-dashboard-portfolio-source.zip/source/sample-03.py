# server.py
import json
import decimal
import datetime
import sys
import time
from flask import Flask, jsonify, send_from_directory, request, Response
from flask_cors import CORS
from psycopg2 import pool
import psycopg2.extras
import os

app = Flask(__name__, static_folder='dashboard/dist')
CORS(app)

# Database connection pool
try:
    db_pool = psycopg2.pool.ThreadedConnectionPool(
        1, 10,
        host='192.0.2.10',
        database='DataMart_Bizops',
        user='PORTFOLIO_REDACTED',
        password=REDACTED_SECRET
        port='5432'
    )
    if db_pool:
        print("Connection pool created successfully")
    
    import threading
    import time
    
    GLOBAL_LIVE_STORE = {}
    VIEWS_TO_SYNC = [
        'arr_achievement',
        'billingamountbymonth', 
        'collectionamountbymonth',
        'kam_arr_billing_collection', 
        'npsdata', 
        'openpipeline', 
        'sales_arr_billing_collection',
        'ndr',
        'qbr_herostory',
        'service_arr',
        # FY27 views
        'arr_achievement_fy27',
        'billingamountbymonth_27',
        'collectionamountbymonth_27',
        'kam_arr_billing_collection_fy27',
        'ndr_27',
        'service_arr_fy27',
        # Sales FY26 & FY27 Views
        'arr_achievement_Sales_fy26',
        'sales_billingamountbymonth_fy26',
        'REDACTED_OPAQUE_VALUE',
        'arr_achievement_Sales_fy27',
        'REDACTED_OPAQUE_VALUE',
        'REDACTED_OPAQUE_VALUE',
        'sales_billingamountbymonth_fy27',
        'REDACTED_OPAQUE_VALUE',
        'salescapacity',
        'weightages',
        # Delivery views
        'delivery_servicerev',
        'projectdata_delivery'
    ]

    def background_live_sync():
        print("Daemon: Booting continuous live datamart cache synchronized background worker...")
        while True:
            try:
                conn = db_pool.getconn()
                for view in VIEWS_TO_SYNC:
                    try:
                        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                            cur.execute('SET statement_timeout = 300000')
                            if view == 'projectdata_delivery':
                                cur.execute(f'SELECT * FROM dbo.{view} LIMIT 100000')
                            else:
                                cur.execute(f'SELECT * FROM dbo.{view}')
                            GLOBAL_LIVE_STORE[view] = cur.fetchall()
                    except Exception as loop_e:
                        print(f"Daemon View sync failed on {view}: {loop_e}")
                        conn.rollback()
                db_pool.putconn(conn)
            except Exception as e:
                print(f"Daemon connection failed: {e}")
            
            # Recalculate full datamart view arrays faithfully every 15 seconds natively 
            time.sleep(15) 

    threading.Thread(target=background_live_sync, daemon=True).start()

except psycopg2.Error as e:
    print(f"Error connecting to database: {e}")
    sys.exit(1)

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        if isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.isoformat()
        return super().default(obj)

app.json_encoder = CustomJSONEncoder

def query_db(query, args=(), fetchall=True):
    try:
        conn = db_pool.getconn()
    except Exception as e:
        print(f"Error getting connection from pool: {e}")
        return []
        
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute('SET statement_timeout = 300000')
            cur.execute(query, args)
            if fetchall:
                res = cur.fetchall()
            else:
                res = cur.fetchone()
        return res
    except Exception as e:
        print(f"Database query error: {e}")
        import traceback
        traceback.print_exc()
        conn.rollback()
        return []
    finally:
        db_pool.putconn(conn)

# Views available:
# billingamountbymonth
# collectionamountbymonth
# kam_arr_billing_collection
# npsdata
# openpipeline
# sales_arr_billing_collection

CACHE_STORE = {}
CACHE_TTL_SECONDS = 0 # 0 seconds to ensure 100% strictly LIVE basis as requested

# ─── SMART CONTEXT ENGINE FOR LLM ─────────────────────────────
import re as _re


# Intent classification — maps keyword patterns to data sections
INTENT_PATTERNS = {
    'arr':        [r'\b(arr|annual\s+recurring|revenue\s+achievement|quarterly\s+arr)\b'],
    'billing':    [r'\b(bill|invoice|billing\s*amount)\b'],
    'collection': [r'\b(collect|payment|cash|collection|receivable)\b'],
    'pipeline':   [r'\b(pipeline|deal|opportunity|open\s*pipe|funnel)\b'],
    'ndr':        [r'\b(ndr|gdr|retention|net\s+dollar|gross\s+dollar|churn|expansion)\b'],
    'nps':        [r'\b(nps|satisfaction|promoter|detractor|survey|customer\s+score)\b'],
    'service':    [r'\b(service\s*rev|service\s+revenue|service\s*arr)\b'],
    'qbr':        [r'\b(qbr|quarterly\s+business|hero\s*story)\b'],
    'delivery':   [r'\b(deliver|project|po\s*type|portfolio|territory|account|manager)\b'],
    'capacity':   [r'\b(capacity|headcount|team\s+size|sales\s+capacity)\b'],
    'weightage':  [r'\b(weight|okr\s+weight|scorecard)\b'],
    'summary':    [r'\b(summary|overview|executive|dashboard|all|everything|how\s+are|status|health|track|risk)\b'],
}

def classify_intent(messages):
    """Classify user intent from recent messages using keyword matching."""
    recent = ' '.join(m.get('content', '').lower() for m in messages[-3:])
    intents = set()
    for intent, patterns in INTENT_PATTERNS.items():
        for pat in patterns:
            if _re.search(pat, recent):
                intents.add(intent)
    if not intents:
        intents.add('summary')
    return intents

def _safe_float(val, default=0):
    try: return float(val)
    except: return default

def _to_cr(val):
    try: return round(float(val) / 10000000, 2)
    except: return 0.0

def _pct_str(actual, target):
    try:
        t = float(target)
        a = float(actual)
        return f"{round((a/t)*100, 1)}%" if t > 0 else "N/A"
    except: return "N/A"

@app.route('/api/views/<view_name>', methods=['GET'])
def get_view_data(view_name):
    allowed_views = {
        'arr_achievement',
        'billingamountbymonth', 
        'collectionamountbymonth',
        'kam_arr_billing_collection', 
        'npsdata', 
        'openpipeline', 
        'sales_arr_billing_collection',
        'ndr',
        'qbr_herostory',
        'service_arr',
        # FY27 views
        'arr_achievement_fy27',
        'billingamountbymonth_27',
        'collectionamountbymonth_27',
        'kam_arr_billing_collection_fy27',
        'ndr_27',
        'service_arr_fy27',
        # Sales FY26 & FY27 Views
        'arr_achievement_Sales_fy26',
        'sales_billingamountbymonth_fy26',
        'REDACTED_OPAQUE_VALUE',
        'arr_achievement_Sales_fy27',
        'REDACTED_OPAQUE_VALUE',
        'REDACTED_OPAQUE_VALUE',
        'sales_billingamountbymonth_fy27',
        'REDACTED_OPAQUE_VALUE',
        'salescapacity',
        'weightages',
        # Delivery views
        'delivery_servicerev',
        'projectdata_delivery'
    }
    
    if view_name not in allowed_views:
        return jsonify({"error": "Unauthorized view"}), 403
        
    # Instantly resolve from the background 15-second Sync-Thread to absolutely prevent 25s timeouts!
    data = GLOBAL_LIVE_STORE.get(view_name)
    if data is not None and len(data) > 0:
        return app.response_class(
            response=json.dumps(data, cls=CustomJSONEncoder),
            status=200,
            mimetype='application/json'
        )
            
    # Cache miss (thread hasn't executed first dump yet?), query the database
    if view_name == 'projectdata_delivery':
        data = query_db(f'SELECT * FROM dbo.{view_name} LIMIT 100000')
    else:
        data = query_db(f'SELECT * FROM dbo.{view_name}')
    
    # Custom encoder for decimals
    json_data = json.dumps(data, cls=CustomJSONEncoder)
    
    return app.response_class(
        response=json_data,
        status=200,
        mimetype='application/json'
    )

@app.route('/api/chat', methods=['POST'])
def chat_stream():
    data = request.json or {}
    messages = data.get('messages', [])
    use_thinking = data.get('thinking', False)
    if not messages:
        return jsonify({"error": "No messages array provided"}), 400

    try:
        import threading

        # Singleton OpenAI client (thread-safe init)
        if not hasattr(chat_stream, '_client_lock'):
            import threading as _th
            chat_stream._client_lock = _th.Lock()
        with chat_stream._client_lock:
            if not hasattr(chat_stream, '_client'):
                from openai import OpenAI
                chat_stream._client = OpenAI(
                    base_url="https://example.invalid",
                    api_key=REDACTED_SECRET
                )
        client = chat_stream._client

        extra = {}
        if use_thinking:
            extra["chat_template_kwargs"] = {"thinking": True}

        role = data.get('role', 'KAM')
        fy = data.get('fy', 'FY26')

        # Classify user intent for smart context selection
        intents = classify_intent(messages)

        # ─── SMART CONTEXT BUILDER ────────────────────────────
        # Builds compact, intent-relevant context instead of full dump
        def build_smart_context(role='KAM', fy='FY26', intents=None):
            if intents is None:
                intents = {'summary'}
            
            # Aliases for module-level helpers
            safe_float = _safe_float
            to_cr = _to_cr
            pct_str = _pct_str

            is_summary = 'summary' in intents or len(intents) > 4

            lines = [
                f"You are an AI assistant for a B2B SaaS OKR Dashboard (Acidaes/BizTech). The user is viewing the {role} dashboard for {fy}.",
                f"Respond ONLY about {role} metrics and data. Do NOT mention other roles' data.",
                "Respond to C-suite leadership in English. Be concise, data-driven. Always cite exact numbers from the data below.",
                "ALL monetary values below are in ₹ Crores (Cr) unless stated otherwise.",
                ""
            ]

            ndr_view = 'ndr' if fy == 'FY26' else 'ndr_27'
            ndr_data = GLOBAL_LIVE_STORE.get(ndr_view, [])
            other_fy = 'FY25' if fy == 'FY26' else ('FY27' if fy == 'FY25' else 'FY26')

            # ============================================================
            # ROLE-SPECIFIC SECTIONS
            # ============================================================
            if role == 'KAM':
                lines.append("=" * 50)
                lines.append(f"## KAM FINANCIAL METRICS ({fy})")
                lines.append("=" * 50)

                kam_key = 'kam_arr_billing_collection' if fy == 'FY26' else 'kam_arr_billing_collection_fy27'
                kam = GLOBAL_LIVE_STORE.get(kam_key, [])
                if not kam:
                    kam = GLOBAL_LIVE_STORE.get('kam_arr_billing_collection', [])
                kam_fy = [r for r in kam if r.get('fy') == fy]
                r_kam = kam_fy[0] if kam_fy else (kam[0] if kam else {})
                if r_kam:
                    lines.append(f"### KAM Summary ({fy})")
                    # Curated metrics with human-readable labels (not raw DB dump)
                    label_map = {
                        'arr_target': 'ARR Target (Cr)', 'arr_achievement': 'ARR Achievement (Cr)',
                        'billing_target': 'Billing Target (Cr)', 'billing_achievement': 'Billing Achievement (Cr)',
                        'collection_target': 'Collection Target (Cr)', 'collection_achievement': 'Collection Achievement (Cr)',
                        'arr_pct': 'ARR %', 'billing_pct': 'Billing %', 'collection_pct': 'Collection %',
                        'fy': 'Financial Year', 'gtm': 'GTM Segment',
                    }
                    for k, v in r_kam.items():
                        if v is not None and k.lower() not in ('id', 'created_at', 'updated_at'):
                            label = label_map.get(k, k.replace('_', ' ').title())
                            lines.append(f"  {label}: {v}")

                arr_view = 'arr_achievement' if fy == 'FY26' else 'arr_achievement_fy27'
                arr_rows = GLOBAL_LIVE_STORE.get(arr_view, [])
                arr_filtered = [r for r in arr_rows if r.get('gtm') == 'KAM' and str(r.get('quarter_fy', '')).endswith(fy.replace('FY', ''))]
                if arr_filtered:
                    lines.append(f"### KAM ARR Achievement by Quarter ({fy})")
                    for r in arr_filtered:
                        tgt = safe_float(r.get('arr_target', 0))
                        ach = safe_float(r.get('arr_achievement', 0))
                        lines.append(f"  {r.get('quarter_fy','?')}: Target={tgt:.1f} Cr, Actual={ach:.1f} Cr ({pct_str(ach, tgt)})")

                bill_view = 'billingamountbymonth' if fy == 'FY26' else 'billingamountbymonth_27'
                bill_rows = GLOBAL_LIVE_STORE.get(bill_view, [])
                bill_kam = [r for r in bill_rows if r.get('fy') == fy and r.get('gtm') == 'KAM']
                if bill_kam:
                    lines.append(f"### KAM Billing by Month ({fy})")
                    for r in bill_kam:
                        lines.append(f"  {r.get('month','?')}: {r.get('billingamountcr',0)} Cr")

                coll_view = 'collectionamountbymonth' if fy == 'FY26' else 'collectionamountbymonth_27'
                coll_rows = GLOBAL_LIVE_STORE.get(coll_view, [])
                coll_kam = [r for r in coll_rows if r.get('fy') == fy and r.get('gtm') == 'KAM']
                if coll_kam:
                    lines.append(f"### KAM Collection by Month ({fy})")
                    for r in coll_kam:
                        lines.append(f"  {r.get('month','?')}: {r.get('collectionamountcr',0)} Cr")

                ndr_kam = [r for r in ndr_data if r.get('fy') == fy and r.get('gtm') == 'KAM']
                if ndr_kam:
                    sum_start = sum(safe_float(r.get('starting_arr', 0)) for r in ndr_kam)
                    sum_exp = sum(safe_float(r.get('expansion_arr', 0)) for r in ndr_kam)
                    sum_churn = sum(safe_float(r.get('churn_contraction_arr', 0)) for r in ndr_kam)
                    if sum_start > 0:
                        ndr_pct = round(((sum_start + sum_exp + sum_churn) / sum_start) * 100, 1)
                        gdr_pct = round(((sum_start + sum_churn) / sum_start) * 100, 1)
                        lines.append(f"### KAM NDR/GDR ({fy})")
                        lines.append(f"  NDR: {ndr_pct}% (Target: 120%), GDR: {gdr_pct}% (Target: 95%)")

                svc_view = 'service_arr' if fy == 'FY26' else 'service_arr_fy27'
                svc = GLOBAL_LIVE_STORE.get(svc_view, [])
                svc_fy = [r for r in svc if r.get('quarter', '').endswith(fy.replace('FY', ''))]
                if svc_fy:
                    lines.append(f"### KAM Service Revenue by Quarter ({fy})")
                    for r in svc_fy:
                        tgt = safe_float(r.get('target', 0))
                        ach = safe_float(r.get('service_rev_achievement', 0))
                        lines.append(f"  {r.get('quarter','?')}: {ach:.2f} / {tgt:.2f} Cr ({pct_str(ach, tgt)})")

                qbr = GLOBAL_LIVE_STORE.get('qbr_herostory', [])
                qbr_kam = [r for r in qbr if r.get('gtm') == 'KAM' and fy.replace('FY', '') in str(r.get('quarter', ''))]
                if qbr_kam:
                    lines.append(f"### KAM QBR & Hero Stories ({fy})")
                    for r in qbr_kam:
                        lines.append(f"  {r.get('quarter','?')}: QBR={r.get('qbr_achievement',0)}/{r.get('qbr_target',0)}, Hero={r.get('herostory_achievement',0)}/{r.get('herostory_target',0)}")

                pipe = GLOBAL_LIVE_STORE.get('openpipeline', [])
                pipe_kam = [r for r in pipe if r.get('financial_year') == fy and r.get('gtm') == 'KAM']
                if pipe_kam:
                    pipe_val = sum(safe_float(r.get('openpipeline', 0)) for r in pipe_kam) / 10000000
                    lines.append(f"### KAM Open Pipeline ({fy}): {pipe_val:.2f} Cr across {len(pipe_kam)} deals")

                nps = GLOBAL_LIVE_STORE.get('npsdata', [])
                nps_kam = [r for r in nps if r.get('fy') == fy and r.get('acc_ex3_63') == 'ROW CSM']
                if nps_kam:
                    lines.append(f"### KAM NPS ({fy})")
                    for r in nps_kam:
                        lines.append(f"  NPS={r.get('nps',0)}, Target={r.get('target',0)}, Promoters={r.get('promoter_count',0)}, Neutrals={r.get('neutral_count',0)}, Detractors={r.get('detractor_count',0)}")

                wt = GLOBAL_LIVE_STORE.get('weightages', [])
                wt_kam = [r for r in wt if r.get('fy') == fy and r.get('gtm') == 'KAM']
                if wt_kam:
                    lines.append(f"### KAM OKR Weightages ({fy})")
                    for r in wt_kam:
                        lines.append(f"  {r.get('metric_label','?')} ({r.get('metric_key','?')}): {r.get('weight_percent',0)}%")

                # Few-shot examples for KAM — realistic with actual chart JSON
                lines.append("")
                lines.append("### EXAMPLE RESPONSES (follow this EXACT style):")
                lines.append("Q: 'Show me ARR trend' → A: 'Here is the ARR quarterly trend for KAM FY26:")
                lines.append("| Quarter | Target (Cr) | Actual (Cr) | Achievement |")
                lines.append("| Q1FY26 | 25.0 | 23.5 | 94.0% |")
                lines.append("| Q2FY26 | 28.0 | 27.1 | 96.8% |")
                lines.append("Overall ARR achievement: 94.2%. Q2 shows improvement over Q1. %%CHART:arr_quarterly%%'")
                lines.append("Q: 'How is billing?' → A: 'Monthly billing for KAM FY26:")
                lines.append("| Month | Billing (Cr) |")
                lines.append("| Apr | 8.2 |")
                lines.append("| May | 7.5 |")
                lines.append("Total YTD billing: 47.3 Cr. May saw a 8.5% dip — investigate if delayed invoices. %%CHART:billing_monthly%%'")
                lines.append("Q: 'What is our hiring plan?' → A: 'I don\\'t have hiring or headcount data on this dashboard. I can help with ARR, billing, collection, NDR, NPS, pipeline, and service revenue metrics.'")

            elif role == 'Sales':
                lines.append("=" * 50)
                lines.append(f"## SALES FINANCIAL METRICS ({fy})")
                lines.append("=" * 50)

                sales_key = 'REDACTED_OPAQUE_VALUE' if fy == 'FY26' else 'REDACTED_OPAQUE_VALUE'
                sales = GLOBAL_LIVE_STORE.get(sales_key, [])
                sales_fy = [r for r in sales if r.get('fy') == fy]
                r_sales = sales_fy[0] if sales_fy else (sales[0] if sales else {})
                if r_sales:
                    lines.append(f"### Sales Summary ({fy})")
                    # Curated metrics with human-readable labels
                    label_map = {
                        'arr_target': 'ARR Target (Cr)', 'arr_achievement': 'ARR Achievement (Cr)',
                        'billing_target': 'Billing Target (Cr)', 'billing_achievement': 'Billing Achievement (Cr)',
                        'collection_target': 'Collection Target (Cr)', 'collection_achievement': 'Collection Achievement (Cr)',
                        'arr_pct': 'ARR %', 'billing_pct': 'Billing %', 'collection_pct': 'Collection %',
                        'fy': 'Financial Year', 'gtm': 'GTM Segment',
                    }
                    for k, v in r_sales.items():
                        if v is not None and k.lower() not in ('id', 'created_at', 'updated_at'):
                            label = label_map.get(k, k.replace('_', ' ').title())
                            lines.append(f"  {label}: {v}")

                sarr_view = 'arr_achievement_Sales_fy26' if fy == 'FY26' else 'arr_achievement_Sales_fy27'
                sarr_rows = GLOBAL_LIVE_STORE.get(sarr_view, [])
                if sarr_rows:
                    lines.append(f"### Sales ARR Achievement by Quarter ({fy})")
                    for r in sarr_rows:
                        tgt = safe_float(r.get('arr_target', 0))
                        ach = safe_float(r.get('arr_achievement', 0))
                        lines.append(f"  {r.get('quarter_fy','?')}: Target={tgt:.1f} Cr, Actual={ach:.1f} Cr ({pct_str(ach, tgt)})")

                sbill_view = 'sales_billingamountbymonth_fy26' if fy == 'FY26' else 'sales_billingamountbymonth_fy27'
                sbill_rows = GLOBAL_LIVE_STORE.get(sbill_view, [])
                if sbill_rows:
                    lines.append(f"### Sales Billing by Month ({fy})")
                    for r in sbill_rows:
                        if r.get('fy') == fy:
                            lines.append(f"  {r.get('month','?')}: {r.get('billingamountcr',0)} Cr")

                scoll_view = 'REDACTED_OPAQUE_VALUE' if fy == 'FY26' else 'REDACTED_OPAQUE_VALUE'
                scoll_rows = GLOBAL_LIVE_STORE.get(scoll_view, [])
                if scoll_rows:
                    lines.append(f"### Sales Collection by Month ({fy})")
                    for r in scoll_rows:
                        if r.get('fy') == fy:
                            lines.append(f"  {r.get('month','?')}: {r.get('collectionamountcr',0)} Cr")

                ndr_sales = [r for r in ndr_data if r.get('fy') == fy and r.get('gtm') == 'Sales']
                if ndr_sales:
                    sum_start = sum(safe_float(r.get('starting_arr', 0)) for r in ndr_sales)
                    sum_exp = sum(safe_float(r.get('expansion_arr', 0)) for r in ndr_sales)
                    sum_churn = sum(safe_float(r.get('churn_contraction_arr', 0)) for r in ndr_sales)
                    if sum_start > 0:
                        ndr_pct = round(((sum_start + sum_exp + sum_churn) / sum_start) * 100, 1)
                        lines.append(f"### Sales NDR ({fy}): {ndr_pct}%")

                cap = GLOBAL_LIVE_STORE.get('salescapacity', [])
                cap_fy = [r for r in cap if str(r.get('FY', '')) == fy]
                if cap_fy:
                    lines.append(f"### Sales Capacity ({fy})")
                    for r in cap_fy:
                        lines.append(f"  Target: {r.get('Target',0)}, Achievement: {r.get('Achievement',0)}")

                qbr = GLOBAL_LIVE_STORE.get('qbr_herostory', [])
                qbr_sales = [r for r in qbr if r.get('gtm') == 'Sales' and fy.replace('FY', '') in str(r.get('quarter', ''))]
                if qbr_sales:
                    lines.append(f"### Sales QBR & Hero Stories ({fy})")
                    for r in qbr_sales:
                        lines.append(f"  {r.get('quarter','?')}: QBR={r.get('qbr_achievement',0)}/{r.get('qbr_target',0)}, Hero={r.get('herostory_achievement',0)}/{r.get('herostory_target',0)}")

                pipe = GLOBAL_LIVE_STORE.get('openpipeline', [])
                pipe_sales = [r for r in pipe if r.get('financial_year') == fy and r.get('gtm') == 'Sales']
                if pipe_sales:
                    pipe_val = sum(safe_float(r.get('openpipeline', 0)) for r in pipe_sales) / 10000000
                    lines.append(f"### Sales Open Pipeline ({fy}): {pipe_val:.2f} Cr across {len(pipe_sales)} deals")

                nps = GLOBAL_LIVE_STORE.get('npsdata', [])
                nps_sales = [r for r in nps if r.get('fy') == fy and r.get('acc_ex3_63') == 'ROW Sales']
                if nps_sales:
                    lines.append(f"### Sales NPS ({fy})")
                    for r in nps_sales:
                        lines.append(f"  NPS={r.get('nps',0)}, Target={r.get('target',0)}, Promoters={r.get('promoter_count',0)}, Neutrals={r.get('neutral_count',0)}, Detractors={r.get('detractor_count',0)}")

                wt = GLOBAL_LIVE_STORE.get('weightages', [])
                wt_sales = [r for r in wt if r.get('fy') == fy and r.get('gtm') == 'Sales']
                if wt_sales:
                    lines.append(f"### Sales OKR Weightages ({fy})")
                    for r in wt_sales:
                        lines.append(f"  {r.get('metric_label','?')} ({r.get('metric_key','?')}): {r.get('weight_percent',0)}%")

                lines.append("")
                lines.append("### EXAMPLE RESPONSES (follow this EXACT style):")
                lines.append("Q: 'Show me ARR trend' → A: 'Here is the Sales ARR quarterly trend for FY26:")
                lines.append("| Quarter | Target (Cr) | Actual (Cr) | Achievement |")
                lines.append("| Q1FY26 | 15.0 | 14.2 | 94.7% |")
                lines.append("Sales ARR is tracking at 94.7% of target. %%CHART:arr_quarterly%%'")
                lines.append("Q: 'How is billing?' → A: 'Monthly billing for Sales FY26:")
                lines.append("| Month | Billing (Cr) |")
                lines.append("| Apr | 5.2 |")
                lines.append("Total YTD billing: 32.1 Cr. %%CHART:billing_monthly%%'")
                lines.append("Q: 'What is our hiring plan?' → A: 'I don\\'t have hiring data on this dashboard. I can help with Sales ARR, billing, collection, NDR, pipeline, and capacity metrics.'")

            elif role == 'Delivery':
                lines.append("=" * 50)
                lines.append(f"## DELIVERY METRICS - SERVICE REVENUE ({fy})")
                lines.append("=" * 50)

                delv = GLOBAL_LIVE_STORE.get('delivery_servicerev', [])
                delv_fy = [r for r in delv if r.get('financialyear') == fy]
                # Also get other FY for comparison
                delv_other = [r for r in delv if r.get('financialyear') == other_fy]

                month_cols = ['apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'jan', 'feb', 'mar']
                month_labels = ['APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', 'JAN', 'FEB', 'MAR']

                if delv_fy:
                    # Monthly totals in Cr
                    month_totals = {}
                    for m in month_cols:
                        month_totals[m] = to_cr(sum(safe_float(r.get(m, 0)) for r in delv_fy))
                    fy_total = to_cr(sum(safe_float(r.get('fy_total', 0)) for r in delv_fy))

                    lines.append(f"### Monthly Service Revenue ({fy}) - ALL Projects (₹ Cr)")
                    for i, m in enumerate(month_cols):
                        val = month_totals[m]
                        lines.append(f"  {month_labels[i]}: {val:.2f} Cr")
                    lines.append(f"  ─────────────")
                    lines.append(f"  FY TOTAL: {fy_total:.2f} Cr")
                    lines.append(f"  Total projects: {len(delv_fy)}")

                    # Quarterly aggregation
                    q_map = {'Q1': ['apr','may','jun'], 'Q2': ['jul','aug','sep'], 'Q3': ['oct','nov','dec'], 'Q4': ['jan','feb','mar']}
                    lines.append(f"### Quarterly Service Revenue ({fy}) (₹ Cr)")
                    for q, months in q_map.items():
                        q_total = sum(month_totals[m] for m in months)
                        lines.append(f"  {q}: {q_total:.2f} Cr")

                    # YoY Comparison
                    if delv_other:
                        other_total = to_cr(sum(safe_float(r.get('fy_total', 0)) for r in delv_other))
                        yoy_delta = fy_total - other_total
                        yoy_pct = round((yoy_delta / other_total) * 100, 1) if other_total > 0 else 0
                        arrow = "↑" if yoy_delta > 0 else "↓"
                        lines.append(f"### Year-over-Year Comparison")
                        lines.append(f"  {other_fy}: {other_total:.2f} Cr")
                        lines.append(f"  {fy}: {fy_total:.2f} Cr")
                        lines.append(f"  Change: {arrow} {abs(yoy_delta):.2f} Cr ({arrow} {abs(yoy_pct)}%)")

                    # Top accounts by revenue (in Cr)
                    acct_totals = {}
                    for r in delv_fy:
                        acct = r.get('accountname', 'Unknown')
                        acct_totals[acct] = acct_totals.get(acct, 0) + to_cr(r.get('fy_total', 0))
                    top_accts = sorted(acct_totals.items(), key=lambda x: -x[1])[:10]
                    lines.append(f"### Top 10 Accounts by Service Revenue ({fy}) (₹ Cr)")
                    for acct, val in top_accts:
                        if val > 0:
                            pct_of_total = round((val / fy_total) * 100, 1) if fy_total > 0 else 0
                            lines.append(f"  {acct}: {val:.2f} Cr ({pct_of_total}% of total)")

                    # By PO Type
                    potype_totals = {}
                    for r in delv_fy:
                        pt = r.get('potypename', 'Unknown')
                        potype_totals[pt] = potype_totals.get(pt, 0) + to_cr(r.get('fy_total', 0))
                    lines.append(f"### Service Revenue by PO Type ({fy}) (₹ Cr)")
                    for pt, val in sorted(potype_totals.items(), key=lambda x: -x[1]):
                        if val > 0:
                            lines.append(f"  {pt}: {val:.2f} Cr")

                    # By Territory
                    terr_totals = {}
                    for r in delv_fy:
                        t = r.get('territory', 'Unknown')
                        terr_totals[t] = terr_totals.get(t, 0) + to_cr(r.get('fy_total', 0))
                    lines.append(f"### Service Revenue by Territory ({fy}) (₹ Cr)")
                    for t, val in sorted(terr_totals.items(), key=lambda x: -x[1]):
                        if val > 0:
                            lines.append(f"  {t}: {val:.2f} Cr")

                    # By Portfolio Owner (top 10)
                    owner_totals = {}
                    for r in delv_fy:
                        o = r.get('portfolioowner', 'Unknown')
                        owner_totals[o] = owner_totals.get(o, 0) + to_cr(r.get('fy_total', 0))
                    top_owners = sorted(owner_totals.items(), key=lambda x: -x[1])[:10]
                    lines.append(f"### Top 10 Portfolio Owners by Revenue ({fy}) (₹ Cr)")
                    for o, val in top_owners:
                        if val > 0:
                            lines.append(f"  {o}: {val:.2f} Cr")

                    # Per-project monthly detail for top 5 projects (in Cr)
                    top_projects = sorted(delv_fy, key=lambda r: -safe_float(r.get('fy_total', 0)))[:5]
                    lines.append(f"### Top 5 Projects - Monthly Breakdown ({fy}) (₹ Cr)")
                    for r in top_projects:
                        lines.append(f"  {r.get('projectname','?')} ({r.get('accountname','?')}):")
                        for m in month_cols:
                            val = to_cr(r.get(m, 0))
                            if val > 0:
                                lines.append(f"    {m.upper()}: {val:.2f}")
                        lines.append(f"    FY Total: {to_cr(r.get('fy_total', 0)):.2f} Cr")

                    # Auto-detected insights
                    lines.append(f"### Auto-Detected Insights ({fy})")
                    # Detect monthly drops
                    for i in range(1, len(month_cols)):
                        prev_val = month_totals[month_cols[i-1]]
                        curr_val = month_totals[month_cols[i]]
                        if prev_val > 0 and curr_val > 0:
                            drop_pct = round(((prev_val - curr_val) / prev_val) * 100, 1)
                            if drop_pct > 20:
                                lines.append(f"  ⚠️ {month_labels[i]} dropped {drop_pct}% vs {month_labels[i-1]} ({curr_val:.2f} Cr vs {prev_val:.2f} Cr)")
                    # Detect top concentration
                    if top_accts:
                        top1_pct = round((top_accts[0][1] / fy_total) * 100, 1) if fy_total > 0 else 0
                        if top1_pct > 15:
                            lines.append(f"  📊 {top_accts[0][0]} accounts for {top1_pct}% of total revenue — high concentration risk")
                    # H1 vs H2
                    h1 = sum(month_totals[m] for m in ['apr','may','jun','jul','aug','sep'])
                    h2 = sum(month_totals[m] for m in ['oct','nov','dec','jan','feb','mar'])
                    if h1 > 0 and h2 > 0:
                        h2_growth = round(((h2 - h1) / h1) * 100, 1)
                        arrow = "↑" if h2_growth > 0 else "↓"
                        lines.append(f"  📈 H1 avg: {h1/6:.2f} Cr/month → H2 avg: {h2/6:.2f} Cr/month ({arrow} {abs(h2_growth)}%)")
                else:
                    lines.append(f"  No delivery data for {fy}")

                # Delivery Weightages
                wt = GLOBAL_LIVE_STORE.get('weightages', [])
                wt_delv = [r for r in wt if r.get('fy') == fy and r.get('gtm') == 'Delivery']
                if wt_delv:
                    lines.append(f"### Delivery OKR Weightages ({fy})")
                    for r in wt_delv:
                        lines.append(f"  {r.get('metric_label','?')} ({r.get('metric_key','?')}): {r.get('weight_percent',0)}%")

                # Few-shot examples for Delivery
                lines.append("")
                lines.append("### EXAMPLE RESPONSES (follow this style):")
                lines.append("Q: 'Tell me about monthly service revenue' → A: Here's the FY26 monthly service revenue (₹ Cr):\\n| Month | Revenue (Cr) |\\n| APR | 15.44 |\\n| MAY | 14.92 |\\n...\\nFY Total: 193.14 Cr\\n%%CHART:{\"type\":\"bar\",\"title\":\"Monthly Service Revenue (FY26)\",\"data\":[{\"name\":\"APR\",\"value\":15.44},{\"name\":\"MAY\",\"value\":14.92},...],\"dataKey\":\"value\"}%%\\n[Key insight about trend]'")
                lines.append("Q: 'Show top accounts' → Table + %%CHART:{\"type\":\"bar\",\"title\":\"Top Accounts\",\"data\":[...],\"dataKey\":\"value\"}%%")
                lines.append("Q: 'Revenue by territory' → Table + %%CHART:{\"type\":\"pie\",\"title\":\"Revenue by Territory\",\"data\":[...]}%%")

            lines.append("")
            lines.append("INSTRUCTIONS:")
            lines.append("- When user asks for a chart, generate a DYNAMIC chart spec as: %%CHART:{\"type\":\"bar|pie|line\",\"title\":\"...\",\"data\":[{\"name\":\"...\",\"value\":...},...],\"dataKey\":\"value\"}%%")
            lines.append("- Use EXACT numbers from the data above. All values in ₹ Cr. Do NOT guess or estimate.")
            lines.append("- IMPORTANT: If the user asks about data NOT provided above (e.g., hiring, competitors, product roadmap), say 'I don\\'t have that data on this dashboard. I can help with [list available metrics].' NEVER fabricate data.")
            lines.append("- Flag any metric below 80% achievement as ⚠️ AT RISK.")
            lines.append("- Include insights and anomalies when you spot them (drops > 20%, concentration risks, trends).")
            lines.append(f"- You are on the {role} dashboard. Only answer about {role} metrics. Do NOT mention other roles.")
            lines.append("- Provide actionable C-suite recommendations.")
            lines.append("- Use markdown tables for data presentation when appropriate.")
            lines.append("- Keep responses concise (under 200 words unless showing tables).")
            return "\n".join(lines)

        system_msg = {"role": "system", "content": build_smart_context(role, fy, intents)}
        
        # Keep conversation history manageable — last 10 messages for context window
        recent_messages = messages[-10:] if len(messages) > 10 else messages
        full_messages = [system_msg] + recent_messages

        import queue
        chunk_queue = queue.Queue()

        def nvidia_worker():
            try:
                completion = client.chat.completions.create(
                    model="minimaxai/minimax-m2.5",
                    messages=full_messages,
                    temperature=0.3,
                    top_p=0.9,
                    max_tokens=REDACTED_SECRET
                    extra_body=extra if extra else None,
                    stream=True
                )
                for chunk in completion:
                    chunk_queue.put(chunk)
                chunk_queue.put("DONE")
            except Exception as e:
                chunk_queue.put(f"ERROR:{str(e)}")

        t = threading.Thread(target=nvidia_worker, daemon=True)
        t.start()

        def generate():
            import time as _time
            # Immediately yield a status event so HTTP response starts
            yield f"data: {json.dumps({'type': 'status', 'content': 'Analyzing dashboard data...'})}\n\n"
            
            start_time = _time.time()
            MAX_STREAM_SECONDS = 90  # Wall-clock timeout
            
            while True:
                if _time.time() - start_time > MAX_STREAM_SECONDS:
                    _timeout_msg = '\n\n⏱️ Response timed out after 90 seconds. Please try again.'
                    yield f"data: {json.dumps({'type': 'content', 'content': _timeout_msg})}\n\n"
                    break
                try:
                    item = chunk_queue.get(timeout=2)
                except queue.Empty:
                    # Send heartbeat to keep connection alive
                    yield ": heartbeat\n\n"
                    continue
                
                if item == "DONE":
                    break
                if isinstance(item, str) and item.startswith("ERROR:"):
                    yield f"data: {json.dumps({'type': 'content', 'content': 'AI service error: ' + item[6:]})}\n\n"
                    break
                
                if not getattr(item, "choices", None):
                    continue
                reasoning = getattr(item.choices[0].delta, "reasoning_content", None)
                if reasoning:
                    yield f"data: {json.dumps({'type': 'reasoning', 'content': reasoning})}\n\n"
                
                if item.choices and item.choices[0].delta.content is not None:
                    yield f"data: {json.dumps({'type': 'content', 'content': item.choices[0].delta.content})}\n\n"
            
            yield "data: [DONE]\n\n"

        return Response(
            generate(),
            mimetype="text/event-stream",
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'X-Accel-Buffering': 'no'
            }
        )

    except Exception as e:
        print("AI Stream Error:", str(e))
        return jsonify({"error": str(e)}), 500


@app.route('/api/chart-data/<chart_type>', methods=['GET'])
def get_chart_data(chart_type):
    """Return real structured chart data from GLOBAL_LIVE_STORE for AI-driven charts"""
    role = request.args.get('role', 'KAM')
    fy = request.args.get('fy', 'FY26')
    is_fy27 = fy == 'FY27'

    def safe_float(val, default=0):
        try: return float(val)
        except: return default

    try:
        if chart_type == 'arr_quarterly':
            if role == 'Sales':
                view = 'arr_achievement_Sales_fy27' if is_fy27 else 'arr_achievement_Sales_fy26'
            else:
                view = 'arr_achievement_fy27' if is_fy27 else 'arr_achievement'
            rows = GLOBAL_LIVE_STORE.get(view, [])
            filtered = [r for r in rows if r.get('gtm') == role and r.get('quarter_fy') and fy.replace('FY', '') in str(r.get('quarter_fy', ''))]
            if not filtered:
                filtered = [r for r in rows if r.get('quarter_fy') and fy.replace('FY', '') in str(r.get('quarter_fy', ''))]
            
            quarters = {'Q1': {'target': 0, 'actual': 0}, 'Q2': {'target': 0, 'actual': 0}, 'Q3': {'target': 0, 'actual': 0}, 'Q4': {'target': 0, 'actual': 0}}
            for r in filtered:
                q_match = str(r.get('quarter_fy', '')).match(r'Q[1-4]') if hasattr(str(r.get('quarter_fy', '')), 'match') else None
                import re
                m = re.search(r'Q[1-4]', str(r.get('quarter_fy', '')))
                if m:
                    q = m.group(0)
                    quarters[q]['target'] += safe_float(r.get('arr_target', 0))
                    quarters[q]['actual'] += safe_float(r.get('arr_achievement', 0))
            
            data = [{'name': q, 'target': round(v['target'], 1), 'actual': round(v['actual'], 1)} for q, v in quarters.items()]
            return jsonify({'chartType': 'bar', 'dataKey': 'actual', 'data': data})

        elif chart_type == 'billing_monthly':
            if role == 'Sales':
                view = 'sales_billingamountbymonth_fy27' if is_fy27 else 'sales_billingamountbymonth_fy26'
            else:
                view = 'billingamountbymonth_27' if is_fy27 else 'billingamountbymonth'
            rows = GLOBAL_LIVE_STORE.get(view, [])
            gtm_filter = 'Sales' if role == 'Sales' else 'KAM'
            filtered = [r for r in rows if r.get('fy') == fy and r.get('gtm') == gtm_filter]
            if not filtered:
                filtered = [r for r in rows if r.get('fy') == fy]
            
            data = []
            for r in filtered[:12]:
                ach = safe_float(r.get('billingamountcr', 0))
                data.append({'name': r.get('month', 'N/A'), 'value': round(ach, 1)})
            return jsonify({'chartType': 'bar', 'dataKey': 'value', 'data': data})

        elif chart_type == 'collection_monthly':
            if role == 'Sales':
                view = 'REDACTED_OPAQUE_VALUE' if is_fy27 else 'REDACTED_OPAQUE_VALUE'
            else:
                view = 'collectionamountbymonth_27' if is_fy27 else 'collectionamountbymonth'
            rows = GLOBAL_LIVE_STORE.get(view, [])
            gtm_filter = 'Sales' if role == 'Sales' else 'KAM'
            filtered = [r for r in rows if r.get('fy') == fy and r.get('gtm') == gtm_filter]
            if not filtered:
                filtered = [r for r in rows if r.get('fy') == fy]
            
            data = []
            for r in filtered[:12]:
                ach = safe_float(r.get('collectionamountcr', 0))
                data.append({'name': r.get('month', 'N/A'), 'value': round(ach, 1)})
            return jsonify({'chartType': 'bar', 'dataKey': 'value', 'data': data})

        elif chart_type == 'pipeline':
            rows = GLOBAL_LIVE_STORE.get('openpipeline', [])
            filtered = [r for r in rows if r.get('financial_year') == fy and r.get('gtm') == role]
            if not filtered:
                filtered = rows
            # Group by stage or owner
            stage_agg = {}
            for r in filtered:
                stage = r.get('stage', r.get('deal_stage', 'Unknown'))
                val = safe_float(r.get('openpipeline', 0)) / 10000000
                stage_agg[stage] = stage_agg.get(stage, 0) + val
            data = [{'name': k, 'value': round(v, 2)} for k, v in sorted(stage_agg.items(), key=lambda x: -x[1])]
            return jsonify({'chartType': 'pie', 'data': data})

        elif chart_type == 'ndr_gdr':
            ndr_view = 'ndr_27' if is_fy27 else 'ndr'
            rows = GLOBAL_LIVE_STORE.get(ndr_view, [])
            filtered = [r for r in rows if r.get('fy') == fy]
            if role != 'All':
                filtered = [r for r in filtered if r.get('gtm') == role]
            
            sum_start = sum(safe_float(r.get('starting_arr', 0)) for r in filtered)
            sum_exp = sum(safe_float(r.get('expansion_arr', 0)) for r in filtered)
            sum_churn = sum(safe_float(r.get('churn_contraction_arr', 0)) for r in filtered)
            
            ndr = round(((sum_start + sum_exp + sum_churn) / sum_start) * 100, 1) if sum_start > 0 else 0
            gdr = round(((sum_start + sum_churn) / sum_start) * 100, 1) if sum_start > 0 else 0
            
            data = [
                {'name': 'NDR', 'value': ndr, 'target': 120},
                {'name': 'GDR', 'value': gdr, 'target': 95}
            ]
            return jsonify({'chartType': 'gauge', 'data': data})

        elif chart_type == 'service_rev':
            svc_view = 'service_arr_fy27' if is_fy27 else 'service_arr'
            rows = GLOBAL_LIVE_STORE.get(svc_view, [])
            data = []
            for q in ['Q1', 'Q2', 'Q3', 'Q4']:
                q_str = f"{q} {fy.replace('FY', '')}"
                r = next((x for x in rows if x.get('quarter') == q_str), None)
                tgt = safe_float(r.get('target', 0)) if r else 27.2
                ach = safe_float(r.get('service_rev_achievement', 0)) if r else 0
                data.append({'name': q, 'target': round(tgt, 1), 'actual': round(ach, 1)})
            return jsonify({'chartType': 'bar', 'dataKey': 'actual', 'data': data})

        elif chart_type == 'nps_trend':
            rows = GLOBAL_LIVE_STORE.get('npsdata', [])
            mapped_acc = 'ROW Sales' if role == 'Sales' else 'ROW CSM'
            data = []
            for f in ['FY25', 'FY26', 'FY27']:
                fy_rows = [r for r in rows if r.get('fy') == f and r.get('acc_ex3_63') == mapped_acc]
                if not fy_rows:
                    fy_rows = [r for r in rows if r.get('fy') == f]
                total_p = sum(int(float(r.get('promoter_count', 0) or 0)) for r in fy_rows)
                total_d = sum(int(float(r.get('detractor_count', 0) or 0)) for r in fy_rows)
                total_t = sum(int(float(r.get('promoter_count', 0) or 0)) + float(r.get('neutral_count', 0) or 0) + float(r.get('detractor_count', 0) or 0) for r in fy_rows)
                score = round(((total_p / total_t) - (total_d / total_t)) * 100) if total_t > 0 else 0
                data.append({'name': f, 'score': score})
            return jsonify({'chartType': 'line', 'dataKey': 'score', 'data': data})

        else:
            return jsonify({'error': f'Unknown chart type: {chart_type}'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Serve the React App frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(app.static_folder + '/' + path):
        # Allow static files (js/css/png) to cache naturally, Vite handles hashes
        return send_from_directory(app.static_folder, path)
    else:
        # Heavily restrict index.html caching so the browser ALWAYS asks for the newest build hash
        response = send_from_directory(app.static_folder, 'index.html')
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, threaded=True)
