import paramiko
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('192.0.2.10', username='PORTFOLIO_REDACTED', password='REDACTED_SECRET')
sftp = client.open_sftp()
sftp.put('server.py', '/biztech/OKRDashboard/server.py')
print("Uploaded server.py!")
sftp.close()
client.close()
