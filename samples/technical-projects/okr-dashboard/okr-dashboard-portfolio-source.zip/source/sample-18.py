import paramiko

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('192.0.2.10', username='PORTFOLIO_REDACTED', password='REDACTED_SECRET')

print("Starting server...")
stdin, stdout, stderr = client.exec_command('cd /biztech/OKRDashboard && nohup python3 server.py > /tmp/okr_server.log 2>&1 < /dev/null &')
print("STDOUT:", stdout.read().decode())
print("STDERR:", stderr.read().decode())

client.close()
