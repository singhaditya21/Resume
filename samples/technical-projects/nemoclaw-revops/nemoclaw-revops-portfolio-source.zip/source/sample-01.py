import os
import json
import sqlite3
import pandas as pd
from typing import Dict, Any, List

DB_PATH = r"/opt/portfolio/project"
ORIGINALS_DIR = r"/opt/portfolio/project"

def init_sqlite_db():
    """
    Reads all fetched JSON payloads from Redash (in Originals/) 
    and constructs a local Relational SQLite database.
    This enables the NEMOCLAW agents to execute fully analytical SQL 
    on the real operational datasets, advancing to Level 5 Autonomy.
    """
    print("Initializing Relational SQLite Engine with Live Redash Data...")
    
    if not os.path.exists(ORIGINALS_DIR):
        print(f"Directory {ORIGINALS_DIR} not found. Cannot init DB.")
        return

    json_files = [f for f in os.listdir(ORIGINALS_DIR) if f.endswith('.json')]
    
    conn = sqlite3.connect(DB_PATH)
    
    for file in json_files:
        table_name = file.replace(".json", "")
        file_path = os.path.join(ORIGINALS_DIR, file)
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
            rows = []
            if "query_result" in data and "data" in data["query_result"]:
                rows = data["query_result"]["data"].get("rows", [])
            elif isinstance(data, list):
                rows = data
            elif isinstance(data, dict) and "rows" in data:
                rows = data["rows"]
                
            if not rows:
                continue
                
            df = pd.DataFrame(rows)
            # Clean dataframe: drop completely empty columns
            df = df.dropna(CUSTOMER_REDACTED=1, how='all')
            
            # Write to SQLite, replacing if it exists to keep fresh TTL
            df.to_sql(table_name, conn, if_exists='replace', index=False)
            print(f"  -> Hydrated table `{table_name}` ({len(df)} rows)")
            
        except Exception as e:
            print(f"  -> Failed to load {table_name} into SQLite: {e}")
            
    conn.close()
    print("SQLite Relational Engine is fully synced with Redash.")

def get_full_schema_context() -> str:
    """
    Introspects every table in the SQLite database and returns a compact
    schema map string suitable for injection into LLM agent prompts.
    Keeps output compact (~8000 chars max) to stay within Cerebras TPM limits.
    """
    if not os.path.exists(DB_PATH):
        return "No database found. Schema unavailable."
    
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Get all table names
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [r[0] for r in cursor.fetchall()]
        
        schema_parts = []
        for tbl in tables:
            # Get column info
            cursor.execute(f"PRAGMA table_info({tbl});")
            columns = cursor.fetchall()
            col_names = [c[1] for c in columns]
            
            # Get row count
            cursor.execute(f"SELECT COUNT(*) FROM {tbl};")
            row_count = cursor.fetchone()[0]
            
            # Get one sample row to identify non-null columns (more useful ones)
            cursor.execute(f"SELECT * FROM {tbl} LIMIT 1;")
            sample_row = cursor.fetchone()
            
            # Prioritize non-null columns in the sample for display
            if sample_row:
                non_null_cols = [name for name, val in zip(col_names, sample_row) if val is not None]
                null_cols = [name for name, val in zip(col_names, sample_row) if val is None]
                # Show up to 25 most useful columns (non-null first)
                display_cols = (non_null_cols + null_cols)[:25]
                remaining = len(col_names) - len(display_cols)
                
                # Build compact sample with non-null values only
                sample_pairs = []
                for name, val in zip(col_names, sample_row):
                    if val is not None and name in display_cols[:10]:
                        sample_pairs.append(f"{name}={str(val)[:50]}")
                sample_str = f"  Sample: {{{', '.join(sample_pairs)}}}"
            else:
                display_cols = col_names[:25]
                remaining = len(col_names) - len(display_cols)
                sample_str = ""
            
            cols_str = ", ".join(display_cols)
            if remaining > 0:
                cols_str += f" ... (+{remaining} more columns)"
            
            schema_parts.append(
                f"TABLE: {tbl} ({row_count} rows)\n"
                f"  Columns: {cols_str}\n"
                f"{sample_str}"
            )
        
        conn.close()
        result = "\n\n".join(schema_parts)
        # Hard cap at 8000 chars to stay within token limits
        if len(result) > 8000:
            result = result[:8000] + "\n... [SCHEMA TRUNCATED]"
        return result
    except Exception as e:
        return f"Schema introspection failed: {e}"

# Global cached schema context (computed once at import time)
_cached_schema_context = None

def get_schema_context() -> str:
    """Returns the cached schema context string, computing it once."""
    global _cached_schema_context
    if _cached_schema_context is None:
        _cached_schema_context = get_full_schema_context()
    return _cached_schema_context

def execute_query(sql_query: str) -> str:
    """
    Executes a read-only SQL query against the local SQLite replica of Redash data.
    Returns a JSON string of the results.
    """
    try:
        conn = sqlite3.connect(DB_PATH)
        # Prevent destructive operations
        if any(keyword in sql_query.upper() for keyword in ["DROP", "DELETE", "INSERT", "UPDATE", "ALTER", "CREATE"]):
            return json.dumps({"error": "Only SELECT read-only operations are permitted by Agent policy."})
            
        df = pd.read_sql_query(sql_query, conn)
        conn.close()
        
        # Convert to records JSON string
        result_json = df.to_json(orient="records", date_format="iso")
        return result_json
        
    except Exception as e:
        return json.dumps({"error": str(e)})

if __name__ == "__main__":
    init_sqlite_db()
