import requests, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("=" * 60)
print("NEMOCLAW FULL SYSTEM VALIDATION")
print("=" * 60)

tests = []

# Test 1: Topology API
try:
    r = requests.get('http://localhost:8000/api/agents/topology', timeout=5)
    d = r.json()['data']
    tests.append(("Topology API", r.status_code == 200, f"{d['total_agents']} agents, {d['total_edges']} edges"))
except Exception as e:
    tests.append(("Topology API", False, str(e)[:60]))

# Test 2: Agent Registry
try:
    r = requests.get('http://localhost:8000/api/agents/registry', timeout=5)
    agents = r.json()['data']['agents']
    tests.append(("Agent Registry", r.status_code == 200, f"{len(agents)} agents registered"))
except Exception as e:
    tests.append(("Agent Registry", False, str(e)[:60]))

# Test 3: Frontend
try:
    r = requests.get('http://localhost:5173', timeout=5)
    tests.append(("Frontend (Vite)", r.status_code == 200, f"{len(r.text)} bytes HTML"))
except Exception as e:
    tests.append(("Frontend (Vite)", False, str(e)[:60]))

# Test 4: Single query (fast, cached)
try:
    r = requests.post('http://localhost:8000/api/intelligence/query',
                      json={"query": "What is the total ARR?", "generate_ppt": False}, timeout=60)
    d = r.json().get('data', {})
    report_len = len(d.get('report', ''))
    sql = d.get('sql_query', 'N/A')[:60]
    tests.append(("LLM Query Pipeline", r.status_code == 200 and report_len > 50, f"{report_len} chars | SQL: {sql}"))
except Exception as e:
    tests.append(("LLM Query Pipeline", False, str(e)[:60]))

# Test 5: Single agent run
try:
    r = requests.post('http://localhost:8000/api/agents/pipeline_health/run', timeout=30)
    d = r.json()
    status = d.get('data', {}).get('status', 'unknown')
    tests.append(("Agent Run (pipeline_health)", status == 'success', f"status={status}"))
except Exception as e:
    tests.append(("Agent Run (pipeline_health)", False, str(e)[:60]))

# Print results
print()
passed = 0
for name, ok, msg in tests:
    tag = "PASS" if ok else "FAIL"
    if ok:
        passed += 1
    print(f"  [{tag}] {name:30s} | {msg}")

print(f"\nResult: {passed}/{len(tests)} passed")
