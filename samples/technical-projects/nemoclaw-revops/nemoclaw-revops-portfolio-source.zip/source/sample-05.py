import os
import json
from typing import Dict, Any, List, Optional, TypedDict
from langgraph.graph import StateGraph, END
from backend.llm_client import ask_llm
from backend.sqlite_engine import get_schema_context
from backend.business_glossary import BUSINESS_GLOSSARY, TABLE_CONTEXT

# Initialize ChromaDB if available
try:
    from langchain_chroma import Chroma
    from langchain_huggingface import HuggingFaceEmbeddings
    embeddings = HuggingFaceEmbeddings(
        model_name="REDACTED_OPAQUE_VALUE",
        model_kwargs={"token": os.getenv("HF_TOKEN", None)} if os.getenv("HF_TOKEN") else {}
    )
    INDEXED_DIR = r"/opt/portfolio/project"
    if os.path.exists(INDEXED_DIR):
        vectorstore = Chroma(
            collection_name="nemoclaw_redash",
            embedding_function=embeddings,
            persist_directory=INDEXED_DIR
        )
    else:
        vectorstore = None
except ImportError:
    vectorstore = None

class PipelineState(TypedDict):
    query: str
    generate_ppt: bool
    schema_metadata: Optional[str]
    sql_query: Optional[str]
    raw_data: Optional[str]
    semantic_memory: Optional[str]
    data_quality_report: Optional[str]
    snapshot_insights: Optional[str]
    opportunity_insights: Optional[str]
    research_notes: Optional[str]
    final_report: Optional[str]
    ppt_path: Optional[str]
    qa_passed: bool
    errors: List[str]
    retry_count: int

async def schema_intelligence_node(state: PipelineState):
    print("Agent 1: Schema Intelligence running...")
    
    # Inject the FULL live schema + business glossary so the agent knows every table, column, and business meaning
    db_schema = get_schema_context()
    
    system_prompt = f"""You are a database metadata expert. You have direct access to the FULL schema of the live SQLite database AND a business glossary that maps obfuscated field codes to their real business meanings.

When the user asks about "ARR", "TCV", "opportunities", "pipeline", etc., use the glossary to identify the correct tables and columns.

Return ONLY a JSON object specifying the tables and their relevant columns. Use the EXACT column names from the schema — never invent or guess column names.

{BUSINESS_GLOSSARY}

{TABLE_CONTEXT}

--- LIVE DATABASE SCHEMA ---
{db_schema}
--- END SCHEMA ---"""
    
    # If we have Semantic Memory, retrieve context for the query
    context_str = ""
    if vectorstore is not None:
        try:
            docs = vectorstore.similarity_search(state.get("query", ""), k=3)
            context_str = "\nRelevant Memory Contex/opt/portfolio/project" + "\n".join([doc.page_content[:200] for doc in docs])
        except Exception as e:
            print(f"Warning: Semantic retrieval failed: {e}")
            
    prompt = f"User Query: {state.get('query', '')}. What schema entities are needed for this query?{context_str}"
    
    # If we are retrying after error, inject the error
    errors = state.get("errors", [])
    retry_count = state.get("retry_count", 0)
    if errors and retry_count > 0:
        prompt += f"\nNote: Previous attempt failed with error: {errors[-1][:200]}. Fix your output. Retry Attempt: {retry_count}"
        
    schema_metadata = await ask_llm(system_prompt, prompt)
    return {"schema_metadata": schema_metadata}

async def query_construction_node(state: PipelineState):
    print("Agent 2: Query Construction running...")
    
    db_schema = get_schema_context()
    
    system_prompt = f"""You are an expert SQLite developer. You have direct access to the FULL schema of the live SQLite database AND a business glossary that maps business terms to exact column names.

RULES:
1. Return ONLY the raw SQL query string — no markdown, no explanation.
2. Use SQLite functions ONLY (e.g., date('now'), julianday(), etc.). NEVER use MySQL functions like CURDATE() or DATEDIFF().
3. Use ONLY column names that exist in the schema below. If a column doesn't exist, DO NOT use it.
4. For date comparisons use julianday() arithmetic.
5. When the user asks about ARR, use opp_ex3.opp_ex3_39. When they ask about TCV, use opp_ex3.opp_ex3_49.
6. Extension tables (opp_ex1-5, lea_ex2-5, acc_ex1-5, pay_ex1-4, ctr_ex1-2) link via ownerid.

{BUSINESS_GLOSSARY}

{TABLE_CONTEXT}

--- LIVE DATABASE SCHEMA ---
{db_schema}
--- END SCHEMA ---"""
    prompt = f"Schema needed: {state.get('schema_metadata', '')}. Goal: {state.get('query', '')}."
    
    errors = state.get("errors", [])
    retry_count = state.get("retry_count", 0)
    if errors and retry_count > 0:
        prompt += f"\nNote: Previous execution failed. Reason: {errors[-1][:200]}. Adjust your SQL. Retry Attempt: {retry_count}"
        
    sql_query = await ask_llm(system_prompt, prompt)
    return {"sql_query": sql_query}

async def data_fetch_node(state: PipelineState):
    print("Agent 3: Data Fetch (Native SQLite Integration) running...")
    sql_query = state.get("sql_query", "")
    errors = state.get("errors", [])
    
    from backend.sqlite_engine import execute_query
    
    try:
        # Prevent "markdown" SQL strings
        clean_sql = sql_query.replace("```sql", "").replace("```", "").strip()
        print(f"  -> SQL GENERATED: {clean_sql}")
        raw_data = execute_query(clean_sql)
        print(f"  -> FETCH RESULT: {raw_data[:200]}")
        
        # Check if it returned an error JSON
        raw_data_json = json.loads(raw_data)
        if isinstance(raw_data_json, dict) and "error" in raw_data_json:
            errors.append(f"SQL Execution Error: {raw_data_json['error']}")
            return {"raw_data": f"SQL Execution Error: {raw_data_json['error']}", "errors": errors}
            
        print(f"  -> Successfully fetched real rows from SQLite execution.")
        return {"raw_data": raw_data, "semantic_memory": "Executed via Native SQLite"}
    except Exception as e:
        errors.append(f"Data Fetch Error: {str(e)}")
        return {"raw_data": f"SQL Execution Error: {str(e)}", "errors": errors}

async def data_quality_node(state: PipelineState):
    print("Agent 4: Data Quality Check running...")
    errors = state.get("errors", [])
    retry_count = state.get("retry_count", 0)
    raw_data = state.get("raw_data", "")
    
    # CASE 1: SQL execution error — must retry with corrected SQL
    if not raw_data or "SQL Execution Error" in raw_data:
        errors.append(f"Data Quality Issue: SQL execution failed — {raw_data[:200]}")
        return {"errors": errors, "retry_count": retry_count + 1}
    
    # CASE 2: Valid query returned empty results — proceed (not an error, just no matching data)
    if raw_data == "[]":
        print("  -> Query returned 0 rows. Proceeding to analytical agents to explain.")
        return {"data_quality_report": "Query executed successfully but returned no matching rows. Analytical agents should report this finding."}
        
    system_prompt = "You are a Data Quality engineer inspecting a *truncated preview* of a raw JSON data payload. Check for missing fields. Do NOT fail or warn about missing closing brackets/braces or incomplete JSON structure, as this is an intentional 1000-character slice. Reply 'PASS' if the properties look generally correct, or list the semantic errors."
    prompt = f"Raw Data (First 1000 chars): {raw_data[:1000]}"
    quality_check = await ask_llm(system_prompt, prompt)
    
    if "PASS" in quality_check.upper():
        return {"data_quality_report": "Data conforms to expected schema."}
    else:
        errors.append(f"Data Quality Issue: {quality_check}")
        return {"errors": errors, "retry_count": retry_count + 1}

# LangGraph Routing logic
def route_after_quality_check(state: PipelineState):
    """
    Decides whether to continue analytics or loop back up for error correction.
    """
    errors = state.get("errors", [])
    retry_count = state.get("retry_count", 0)
    
    if errors and retry_count < 2:
        print(f"--- DAG LOOP TRIGGERED --- Data Quality failed. Looping back to Agent 1. Retry count: {retry_count + 1}")
        return "schema_node"
    elif errors and retry_count >= 2:
        print("--- DAG HALT --- Max retries reached. Exiting pipeline.")
        return "output_node"
    return "snapshot_node"

async def snapshot_intelligence_node(state: PipelineState):
    print("Agent 5: Snapshot Intelligence running...")
    system_prompt = """You are a data summary agent. Your ONLY job is to summarize the ACTUAL data that was fetched from the database.

CRITICAL RULES:
- ONLY cite numbers, values, and facts that appear in the raw data below.
- NEVER fabricate comparisons, trends, or historical data.
- If no historical snapshot exists, say: 'No historical comparison available — this is the current state.'
- Do NOT invent percentage changes, deltas, or temporal comparisons.
- List the key data points found in the raw data as bullet points."""
    raw_data = state.get('raw_data', '')
    prompt = f"User query: {state.get('query', '')}\n\nACTUAL DATA FROM DATABASE (this is the ONLY source of truth):\n{raw_data[:3000]}\n\nSummarize ONLY what the data shows. Do NOT add anything not present in the data."
    snapshot_insights = await ask_llm(system_prompt, prompt)
    return {"snapshot_insights": snapshot_insights}

async def opportunity_intelligence_node(state: PipelineState):
    print("Agent 6: Opportunity Intelligence running...")
    system_prompt = f"""You are a Senior RevOps Analyst. Translate raw database output into business insights.

BUSINESS FIELD GLOSSARY (use these to translate column codes):
{BUSINESS_GLOSSARY}

CRITICAL ANTI-HALLUCINATION RULES:
1. ONLY use numbers, values, and facts that appear in the RAW DATA below.
2. NEVER invent, fabricate, or assume data that is not present in the raw data.
3. NEVER make up percentages, growth rates, or comparisons unless the data contains multiple data points to compare.
4. If a field is NULL or missing, say it is 'not available' — do NOT guess.
5. Translate obfuscated field codes (opp_ex3_39 → ARR, opp_ex3_49 → TCV, etc.) but KEEP the actual values from the data.
6. Every number you cite MUST come from the raw data. If you cannot find it in the data, do not mention it.

Provide a clear, structured analysis using ONLY the real data."""
    raw_data = state.get('raw_data', '')
    prompt = f"User Query: {state.get('query', '')}\n\nACTUAL DATABASE OUTPUT (source of truth):\n{raw_data[:4000]}\n\nAnalyze this data. Every fact must come from the data above."
    opportunity_insights = await ask_llm(system_prompt, prompt, estimated_output_tokens=1500)
    return {"opportunity_insights": opportunity_insights}

async def research_node(state: PipelineState):
    print("Agent 7: Research running...")
    system_prompt = f"""You are a RevOps context analyst. Your job is to add BUSINESS CONTEXT to data-grounded findings.

{BUSINESS_GLOSSARY}

CRITICAL RULES:
1. Do NOT fabricate historical data, benchmarks, or comparisons not in the data.
2. You may explain what business terms mean (e.g., 'Stage 3 = Negotiation phase').
3. You may explain what the data IMPLIES for business operations.
4. NEVER cite specific numbers unless they come from the findings below.
5. NEVER reference 'historical precedents', 'industry benchmarks', or specific company examples (Cisco, Microsoft, etc.) unless explicitly present in the data."""
    
    opportunity_insights = state.get("opportunity_insights", "")
    raw_data = state.get('raw_data', '')
    prompt = f"User Query: {state.get('query', '')}\n\nData-Based Finding/opt/portfolio/project"
    research_notes = await ask_llm(system_prompt, prompt, estimated_output_tokens=1500)
    return {"research_notes": research_notes}

async def report_generation_node(state: PipelineState):
    print("Agent 8: Report Generation running...")
    raw_data = state.get('raw_data', '')
    system_prompt = f"""You are a data-grounded Executive Report Creator.

CRITICAL GROUNDING RULES:
1. The RAW DATA section below is the ONLY source of truth. Every number you cite MUST come from this data.
2. NEVER fabricate, estimate, or assume values not present in the raw data.
3. If the raw data shows a single number (e.g., ARR = $346M), report that number. Do NOT invent breakdowns, trends, or comparisons unless the data contains them.
4. If data is missing, say 'Data not available' — NEVER fill gaps with guesses.
5. Do NOT reference external companies, industry benchmarks, or historical precedents.

BUSINESS GLOSSARY:
{BUSINESS_GLOSSARY}

FORMAT:
1. **Answer** — Direct, concise answer to the user's question with the exact numbers from the data
2. **Data Breakdown** — Table or bullet points of ALL data returned by the query
3. **Business Implications** — What this data means for revenue operations (no made-up numbers)
4. **Recommended Actions** — 3-5 specific next steps based ONLY on what the data reveals

Keep it focused and data-driven. Quality over quantity."""
    prompt = f"""User Question: {state.get('query', '')}

RAW DATA FROM DATABASE (SOURCE OF TRUTH — cite ONLY these numbers):
{raw_data[:5000]}

Agent Analysis (secondary — verify against raw data):
{state.get('opportunity_insights', '')[:2000]}

Generate the report. Every number must match the raw data."""
    final_report = await ask_llm(system_prompt, prompt, estimated_output_tokens=2500)
    return {"final_report": final_report}

async def ppt_generation_node(state: PipelineState):
    print("Agent 9: PPT Generation running...")
    if state.get("generate_ppt", False):
        system_prompt = """You are a slide generator. Output ONLY a raw JSON object with this exact schema:
{
  "title": "Presentation Title",
  "slides": [
    {"title": "Slide 1 Title", "content": ["Bullet 1", "Bullet 2"]},
    {"title": "Slide 2 Title", "content": ["Bullet 1", "Bullet 2"]}
  ]
}
Do not output markdown code blocks. Just valid JSON."""
        final_report = state.get("final_report", "")
        prompt = f"Convert this report into the requested JSON slide format. Report: {final_report}"
        ppt_json = await ask_llm(system_prompt, prompt)
        
        # Physicalize the file
        from backend.utils.ppt_generator import generate_ppt_file
        output_file = r"/opt/portfolio/project"
        try:
            real_path = generate_ppt_file(ppt_json, output_file)
            return {"ppt_path": real_path}
        except Exception as e:
            errors = state.get("errors", [])
            errors.append(f"PPTX Gen Error: {e}")
            return {"errors": errors}
    return {}

async def qa_node(state: PipelineState):
    print("Agent 10: QA Validation running...")
    system_prompt = "You are a strict QA Agent. Check if the 'Final Report' answers the original 'Query' accurately based on the 'Raw Data'. Reply 'PASS' or 'FAIL: [Reason]'."
    prompt = f"Query: {state.get('query', '')}\nReport: {state.get('final_report', '')[:200]}\nRaw Data: {state.get('raw_data', '')[:200]}"
    qa_result = await ask_llm(system_prompt, prompt)
    
    errors = state.get("errors", [])

    # Materialize final report physical markdown file regardless of QA
    try:
        import os
        os.makedirs(r"/opt/portfolio/project", exist_ok=True)
        report_path = r"/opt/portfolio/project"
        prefix = ""
        if "PASS" not in qa_result.upper():
            prefix = f"> [!WARNING]\n> **QA Failed Validation:** {qa_result}\n\n"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(prefix + state.get("final_report", ""))
        print(f"  -> Materialized report to {report_path}")
    except Exception as e:
        print(f"Warning: Could not save report file: {e}")

    if "PASS" in qa_result.upper():
        return {"qa_passed": True}
    else:
        errors.append(f"QA Failed: {qa_result}")
        return {"qa_passed": False, "errors": errors}

async def output_node(state: PipelineState):
    print("Agent 11: Output Formatting running...")
    # Does nothing to state, just serves as the end terminal
    return {}

# --- Build the LangGraph ---
def build_graph():
    workflow = StateGraph(PipelineState)

    # Add Nodes
    workflow.add_node("schema_node", schema_intelligence_node)
    workflow.add_node("query_node", query_construction_node)
    workflow.add_node("fetch_node", data_fetch_node)
    workflow.add_node("quality_node", data_quality_node)
    workflow.add_node("snapshot_node", snapshot_intelligence_node)
    workflow.add_node("opportunity_node", opportunity_intelligence_node)
    workflow.add_node("research_node", research_node)
    workflow.add_node("report_node", report_generation_node)
    workflow.add_node("ppt_node", ppt_generation_node)
    workflow.add_node("qa_node", qa_node)
    workflow.add_node("output_node", output_node)

    # Set Entry Point
    workflow.set_entry_point("schema_node")

    # Sequential edges
    workflow.add_edge("schema_node", "query_node")
    workflow.add_edge("query_node", "fetch_node")
    workflow.add_edge("fetch_node", "quality_node")

    # Conditional logic (The DAG Loop)
    workflow.add_conditional_edges(
        "quality_node",
        route_after_quality_check,
        {
            "schema_node": "schema_node",      # Loop back to start
            "snapshot_node": "snapshot_node",  # Continue normal path
            "output_node": "output_node"       # Hard halt
        }
    )

    # Continue sequential edges
    workflow.add_edge("snapshot_node", "opportunity_node")
    workflow.add_edge("opportunity_node", "research_node")
    workflow.add_edge("research_node", "report_node")
    workflow.add_edge("report_node", "ppt_node")
    workflow.add_edge("ppt_node", "qa_node")
    workflow.add_edge("qa_node", "output_node")
    workflow.add_edge("output_node", END)

    return workflow.compile()

# Compile the DAG
agent_graph = build_graph()

async def run_pipeline(query: str, generate_ppt: bool = False) -> Dict[str, Any]:
    print(f"--- Starting NEMOCLAW LangGraph DAG Pipeline for query: '{query}' ---")
    
    initial_state = {
        "query": query,
        "generate_ppt": generate_ppt,
        "schema_metadata": None,
        "sql_query": None,
        "raw_data": None,
        "semantic_memory": None,
        "data_quality_report": None,
        "snapshot_insights": None,
        "opportunity_insights": None,
        "research_notes": None,
        "final_report": None,
        "ppt_path": None,
        "qa_passed": False,
        "errors": [],
        "retry_count": 0
    }
    
    final_output = await agent_graph.ainvoke(initial_state)
    
    return {
        "success": final_output.get("qa_passed", False),
        "query": final_output.get("query", query),
        "sql_query": final_output.get("sql_query", ""),
        "report": final_output.get("final_report", ""),
        "ppt_url": final_output.get("ppt_path", ""),
        "errors": final_output.get("errors", [])
    }
