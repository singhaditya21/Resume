import sqlite3
import json
conn = sqlite3.connect('nemo_claw.db')
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = [r[0] for r in cursor.fetchall()]
output = {}
for tbl in tables:
    cursor.execute(f"PRAGMA table_info({tbl});")
    output[tbl] = [r[1] for r in cursor.fetchall()]
print(json.dumps(output, indent=2))
