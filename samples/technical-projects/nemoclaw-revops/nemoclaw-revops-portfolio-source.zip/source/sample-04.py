from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sys
import os
import json

# Add parent directory to path to allow absolute imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.orchestrator import run_pipeline
from backend.scheduler import start_scheduler, stop_scheduler

# --- Agent Registry: Maps agent names to their classes ---
from backend.agents.pipeline_health import PipelineHealthAgent
from backend.agents.forecast_drift import ForecastDriftAgent
from backend.agents.sla_tracker import SLATrackerAgent, ExpiringContractsAgent, AgingLeadsAgent
from backend.agents.win_loss_predictor import WinLossPredictor
from backend.agents.revenue_predictor import RevenuePredictorAgent
from backend.agents.churn_scorer import ChurnScorerAgent
from backend.agents.next_best_action import NextBestActionAgent
from backend.agents.arr_growth import ARRGrowthAgent
from backend.agents.renewal_pipeline import RenewalPipelineAgent
from backend.agents.impl_revenue import ImplRevenueAgent
from backend.agents.deal_velocity import DealVelocityAgent
from backend.agents.advanced_agents import (
    TerritoryRebalancerAgent, PricingIntelAgent, MarketingAttributionAgent,
    CustomerHealthAgent, QueryOptimizerAgent, AnomalyDetectorAgent,
    CompetitiveIntelAgent
)
from backend.agents.capacity_forecaster import CapacityForecasterAgent
from backend.agents.extended_agents import (
    RepPerformanceAgent, QuarterlyBookingAgent, PaymentCollectionAgent,
    ContractLifecycleAgent, ExecutiveSummaryAgent
)
from backend.api.crm_mock import router as crm_router
from backend.api.deal_desk import router as deal_desk_router
from backend.api.marketing_mock import router as marketing_router
from backend.api.chat_api import router as chat_router
from backend.api.teams_mock import router as teams_router
from backend.api.voice_api import router as voice_router
from backend.api.document_api import router as document_router

AGENT_REGISTRY = {
    # Tier 1: Proactive Monitoring (7 agents)
    "pipeline_health": PipelineHealthAgent,
    "forecast_drift": ForecastDriftAgent,
    "sla_tracker": SLATrackerAgent,
    "expiring_contracts": ExpiringContractsAgent,
    "aging_leads": AgingLeadsAgent,
    "arr_growth": ARRGrowthAgent,
    "renewal_pipeline": RenewalPipelineAgent,
    # Tier 2: Monitoring + Revenue (3 agents)
    "impl_revenue": ImplRevenueAgent,
    "payment_collection": PaymentCollectionAgent,
    "deal_velocity": DealVelocityAgent,
    # Tier 3: Predictive (4 agents)
    "win_loss_predictor": WinLossPredictor,
    "revenue_predictor": RevenuePredictorAgent,
    "churn_scorer": ChurnScorerAgent,
    "quarterly_booking": QuarterlyBookingAgent,
    # Tier 4: Prescriptive (4 agents)
    "next_best_action": NextBestActionAgent,
    "territory_rebalancer": TerritoryRebalancerAgent,
    "pricing_intel": PricingIntelAgent,
    "rep_performance": RepPerformanceAgent,
    # Tier 5: Cross-Functional (4 agents)
    "marketing_attribution": MarketingAttributionAgent,
    "customer_health": CustomerHealthAgent,
    "competitive_intel": CompetitiveIntelAgent,
    "contract_lifecycle": ContractLifecycleAgent,
    "capacity_forecaster": CapacityForecasterAgent,
    # Tier 6: Meta (3 agents)
    "query_optimizer": QueryOptimizerAgent,
    "anomaly_detector": AnomalyDetectorAgent,
    "executive_summary": ExecutiveSummaryAgent,
}

ALERTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output", "alerts")

app = FastAPI(title="NEMOCLAW RevOps Intelligence Platform", version="2.0.0")

app.include_router(crm_router)
app.include_router(deal_desk_router)
app.include_router(marketing_router)
app.include_router(chat_router)
app.include_router(teams_router)
app.include_router(voice_router)
app.include_router(document_router)

# Allow CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Startup/Shutdown Events ---
@app.on_event("startup")
async def startup_event():
    """Start the background agent scheduler on server boot."""
    try:
        start_scheduler(interval_hours=6)
        print("[NEMOCLAW] Background agent scheduler started (6-hour interval)")
    except Exception as e:
        print(f"[NEMOCLAW] Warning: Scheduler failed to start: {e}")


@app.on_event("shutdown")
async def shutdown_event():
    """Stop the scheduler on shutdown."""
    stop_scheduler()


# --- Models ---
class QueryRequest(BaseModel):
    query: str
    generate_ppt: bool = False


# --- Core Pipeline Endpoint (existing) ---
@app.get("/api/health")
async def health_check():
    return {"status": "ok", "message": "NEMOCLAW RevOps Platform running.", "agents": len(AGENT_REGISTRY)}


@app.post("/api/intelligence/query")
async def process_query(request: QueryRequest):
    """Kicks off the full 11-agent sequential async pipeline based on user natural language query."""
    try:
        result = await run_pipeline(request.query, request.generate_ppt)
        return {"status": "success", "data": result}
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# --- Agent Dashboard Endpoints ---
@app.get("/api/agents/registry")
async def get_agent_registry():
    """List all available agents with their metadata."""
    agents = []
    for name, cls in AGENT_REGISTRY.items():
        agent = cls()
        agents.append({
            "name": agent.name,
            "description": agent.description,
            "category": agent.category
        })
    return {"agents": agents, "total": len(agents)}


@app.post("/api/agents/{agent_name}/run")
async def run_agent(agent_name: str):
    """Run a specific agent on demand and return its results."""
    if agent_name not in AGENT_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found. Available: {list(AGENT_REGISTRY.keys())}")

    agent_cls = AGENT_REGISTRY[agent_name]
    agent = agent_cls()
    result = await agent.run()
    return {"status": "success", "data": result}


@app.get("/api/agents/{agent_name}/latest")
async def get_agent_latest(agent_name: str):
    """Get the most recent cached result for an agent (no re-run)."""
    if agent_name not in AGENT_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found.")

    path = os.path.join(ALERTS_DIR, f"{agent_name}.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return {"status": "success", "data": json.load(f)}
    return {"status": "no_data", "data": None, "message": "Agent has not been run yet."}


@app.get("/api/agents/dashboard")
async def get_dashboard():
    """Get latest results from all agents in a single dashboard payload."""
    dashboard = {"monitoring": [], "predictive": [], "prescriptive": [], "cross_functional": [], "meta": []}

    for name, cls in AGENT_REGISTRY.items():
        agent = cls()
        path = os.path.join(ALERTS_DIR, f"{name}.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                data["has_data"] = True
        else:
            data = {
                "agent": agent.name,
                "description": agent.description,
                "category": agent.category,
                "has_data": False,
                "status": "not_run"
            }
        category = agent.category if agent.category in dashboard else "meta"
        dashboard[category].append(data)

    return {"status": "success", "data": dashboard}


@app.post("/api/agents/run-all")
async def run_all_agents():
    """Run ALL agents sequentially and return combined results."""
    results = []
    for name, cls in AGENT_REGISTRY.items():
        agent = cls()
        try:
            result = await agent.run()
            results.append(result)
        except Exception as e:
            results.append({
                "agent": name,
                "status": "error",
                "analysis": str(e)
            })
    return {"status": "success", "data": results, "total": len(results)}


@app.post("/api/agents/run-category/{category}")
async def run_agents_by_category(category: str):
    """Run all agents in a specific category."""
    valid_categories = {"monitoring", "predictive", "prescriptive", "cross_functional", "meta"}
    if category not in valid_categories:
        raise HTTPException(status_code=400, detail=f"Invalid category. Valid: {valid_categories}")

    results = []
    for name, cls in AGENT_REGISTRY.items():
        agent = cls()
        if agent.category == category:
            try:
                result = await agent.run()
                results.append(result)
            except Exception as e:
                results.append({"agent": name, "status": "error", "analysis": str(e)})

    return {"status": "success", "data": results, "category": category, "total": len(results)}


@app.get("/api/agents/alerts")
async def get_alerts():
    """Get all proactive monitoring alerts (most recent results from Tier 1 agents)."""
    monitoring_agents = ["pipeline_health", "forecast_drift", "sla_tracker", "expiring_contracts",
                         "aging_leads", "arr_growth", "renewal_pipeline", "impl_revenue",
                         "payment_collection", "anomaly_detector"]
    alerts = []
    for name in monitoring_agents:
        path = os.path.join(ALERTS_DIR, f"{name}.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                alerts.append(json.load(f))
    return {"status": "success", "data": alerts, "total": len(alerts)}


# --- NETWORK TOPOLOGY DATA ---
AGENT_EDGES = [
    # Data flow: who feeds whom
    # Monitoring → Predictive
    {"source": "pipeline_health", "target": "win_loss_predictor", "label": "stalling deals"},
    {"source": "pipeline_health", "target": "next_best_action", "label": "at-risk deals"},
    {"source": "forecast_drift", "target": "revenue_predictor", "label": "pipeline snapshot"},
    {"source": "forecast_drift", "target": "quarterly_booking", "label": "pipeline delta"},
    {"source": "arr_growth", "target": "revenue_predictor", "label": "ARR composition"},
    {"source": "arr_growth", "target": "quarterly_booking", "label": "ARR trends"},
    {"source": "renewal_pipeline", "target": "churn_scorer", "label": "renewal status"},
    {"source": "renewal_pipeline", "target": "contract_lifecycle", "label": "renewal pipeline"},
    {"source": "sla_tracker", "target": "churn_scorer", "label": "SLA breaches"},
    {"source": "sla_tracker", "target": "payment_collection", "label": "overdue payments"},
    {"source": "expiring_contracts", "target": "contract_lifecycle", "label": "expiring contracts"},
    {"source": "expiring_contracts", "target": "churn_scorer", "label": "contract risk"},
    {"source": "aging_leads", "target": "marketing_attribution", "label": "lead aging"},
    {"source": "impl_revenue", "target": "revenue_predictor", "label": "impl revenue"},
    {"source": "impl_revenue", "target": "pricing_intel", "label": "impl patterns"},
    {"source": "payment_collection", "target": "customer_health", "label": "payment health"},
    {"source": "deal_velocity", "target": "win_loss_predictor", "label": "velocity signals"},
    {"source": "deal_velocity", "target": "rep_performance", "label": "stage velocity"},
    # Predictive → Prescriptive
    {"source": "win_loss_predictor", "target": "next_best_action", "label": "win scores"},
    {"source": "win_loss_predictor", "target": "rep_performance", "label": "deal scores"},
    {"source": "churn_scorer", "target": "next_best_action", "label": "churn risk"},
    {"source": "churn_scorer", "target": "customer_health", "label": "churn signals"},
    {"source": "revenue_predictor", "target": "quarterly_booking", "label": "landing forecast"},
    {"source": "quarterly_booking", "target": "rep_performance", "label": "quota data"},
    # Prescriptive → Cross-functional
    {"source": "next_best_action", "target": "rep_performance", "label": "action items"},
    {"source": "territory_rebalancer", "target": "rep_performance", "label": "territory load"},
    {"source": "pricing_intel", "target": "competitive_intel", "label": "pricing patterns"},
    {"source": "customer_health", "target": "contract_lifecycle", "label": "health scores"},
    # Meta
    {"source": "anomaly_detector", "target": "query_optimizer", "label": "data quality"},
    {"source": "pipeline_health", "target": "executive_summary", "label": "pipeline risks"},
    {"source": "forecast_drift", "target": "executive_summary", "label": "forecast drift"},
    {"source": "win_loss_predictor", "target": "executive_summary", "label": "deal scores"},
    {"source": "churn_scorer", "target": "executive_summary", "label": "churn alerts"},
    {"source": "arr_growth", "target": "executive_summary", "label": "ARR growth"},
]

@app.get("/api/agents/topology")
async def get_topology():
    """Return network topology graph data for D3.js visualization."""
    nodes = []
    for name, cls in AGENT_REGISTRY.items():
        agent = cls()
        path = os.path.join(ALERTS_DIR, f"{name}.json")
        status = "idle"
        last_run = None
        elapsed = None
        row_count = 0
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                status = data.get("status", "idle")
                last_run = data.get("timestamp")
                elapsed = data.get("elapsed_seconds")
                row_count = data.get("row_count", 0)
        nodes.append({
            "id": agent.name,
            "label": agent.description,
            "category": agent.category,
            "status": status,
            "last_run": last_run,
            "elapsed_seconds": elapsed,
            "row_count": row_count,
        })
    return {
        "status": "success",
        "data": {
            "nodes": nodes,
            "edges": AGENT_EDGES,
            "total_agents": len(nodes),
            "total_edges": len(AGENT_EDGES),
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
