import os
import json
import requests
import hashlib
import time
from typing import Dict, Any, List
from dotenv import load_dotenv

# Ensure requirements are met
try:
    from langchain_community.document_loaders import JSONLoader
    from langchain_huggingface import HuggingFaceEmbeddings
    from langchain_chroma import Chroma
    from langchain_core.documents import Document
except ImportError:
    print("WARNING: Required packages not installed. Run: pip install langchain-community langchain-huggingface langchain-chroma sentence-transformers jq")

# Load environment variables
load_dotenv()

REDASH_API_KEY = os.getenv("REDASH_USER_API_KEY", "REDACTED_OPAQUE_VALUE")
REDASH_BASE_URL = os.getenv("REDASH_BASE_URL", "https://example.invalid").rstrip("/")

ORIGINALS_DIR = r"/opt/portfolio/project"
INDEXED_DIR = r"/opt/portfolio/project"

# Ensure directories exist
os.makedirs(ORIGINALS_DIR, exist_ok=True)
os.makedirs(INDEXED_DIR, exist_ok=True)

# Map of Query Names to Query IDs from user attachments
REDASH_QUERIES = {
    "Leads": 394, "Opportunities": 396, "Accounts": 400, "lea_ex1": 403,
    "lea_ex2": 405, "lea_ex3": 409, "lea_ex4": 410, "lea_ex5": 411,
    "acc_ex1": 413, "acc_ex2": 414, "acc_ex3": 415, "acc_ex4": 416,
    "acc_ex5": 417, "opp_ex1": 418, "opp_ex2": 419, "opp_ex3": 420,
    "opp_ex4": 422, "opp_ex5": 421, "pay_ex1": 423, "pay_ex2": 424,
    "pay_ex3": 425, "pay_ex4": 426, "ctr_ex1": 427, "ctr_ex2": 428,
    "payments": 429, "Contracts": 462, "Stauscodemaster": 406,
    "Uilayoutmaster": 408, "az_user": 412
}

def fetch_redash_data() -> List[str]:
    """
    Fetches JSON data from Redash for all configured queries and saves to Originals directory.
    Returns a list of saved file paths.
    """
    saved_files = []
    headers = {
        "Authorization": f"Key {REDASH_API_KEY}"
    }
    
    TTL_SECONDS = 4 * 3600  # 4 hours TTL cache for Redash payloads
    
    for name, query_id in REDASH_QUERIES.items():
        file_path = os.path.join(ORIGINALS_DIR, f"{name}.json")
        
        # TTL Cache Check
        if os.path.exists(file_path):
            file_age = time.time() - os.path.getmtime(file_path)
            if file_age < TTL_SECONDS:
                print(f"[{name}] Valid TTL Cache hit (Age: {file_age/3600:.1f} hrs). Bypassing Redash API.")
                saved_files.append(file_path)
                continue

        print(f"Fetching {name} (Query ID: {query_id}) from Redash API...")
        url = f"{REDASH_BASE_URL}/api/queries/{query_id}/results.json"
        
        try:
            # We use params=api_key as well just to be safe if Authorization header is blocked
            response = requests.get(url, headers=headers, params={"api_key": REDASH_API_KEY}, timeout=30)
            if response.status_code == 200:
                data = response.json()
                file_path = os.path.join(ORIGINALS_DIR, f"{name}.json")
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)
                saved_files.append(file_path)
                print(f"  -> Saved to {file_path}")
            else:
                print(f"  -> Failed: HTTP {response.status_code} - {response.text[:100]}")
        except Exception as e:
            print(f"  -> Exception occurred: {e}")
            
    return saved_files

def index_data_into_vectorstore(json_files: List[str]):
    """
    Reads the downloaded JSON files, embeds them using HuggingFace model, 
    and stores them persistently in ChromaDB.
    """
    print(f"\nStarting vector indexing into {INDEXED_DIR}...")
    
    # Initialize the local embedding model (no Cerebras tokens used for embeddings)
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    
    # Initialize Persistent Chroma DB
    vectorstore = Chroma(
        collection_name="nemoclaw_redash",
        embedding_function=embeddings,
        persist_directory=INDEXED_DIR
    )
    
    all_docs = []
    
    for file_path in json_files:
        name = os.path.basename(file_path).split('.')[0]
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
            # Usually redash json returns {"query_result": {"data": {"rows": [...]}}}
            # Let's safely extract rows
            rows = []
            if "query_result" in data and "data" in data["query_result"]:
                rows = data["query_result"]["data"].get("rows", [])
            elif isinstance(data, list):
                rows = data
            if not rows:
                print(f"  -> No data found for {name}.")
                continue

            # Hierarchical Document Summarization via Pandas
            import pandas as pd
            df = pd.DataFrame(rows)
            # Clean dataframe: drop completely empty columns
            df = df.dropna(CUSTOMER_REDACTED=1, how='all')
            
            # Synthesize into chunks of 10 records to avoid flooding the vector DB 
            # with fragmented semantic space (solving "Needle in a Haystack")
            chunk_size = 10
            chunks = [df[i:i + chunk_size] for i in range(0, df.shape[0], chunk_size)]
            
            print(f"Hierarchically summarising {name} into {len(chunks)} document chunks...")
            
            for chunk_idx, chunk in enumerate(chunks):
                # Convert chunk to stringified records
                content = chunk.to_json(orient="records", lines=True)
                doc = Document(
                    page_content=content,
                    metadata={"source_table": name, "query_id": REDASH_QUERIES[name], "chunk": chunk_idx}
                )
                all_docs.append(doc)
                
        except Exception as e:
            print(f"  -> Failed to index {file_path}: {e}")
            
    if all_docs:
        print(f"Batch embedding {len(all_docs)} total documents... This may take a moment.")
        # Chroma handles batching, but we can do it safely
        batch_size = 500
        for i in range(0, len(all_docs), batch_size):
            batch = all_docs[i:i+batch_size]
            vectorstore.add_documents(batch)
            print(f"  -> Indexed batch {i} to {i+len(batch)}")
            
        print("Indexing Complete! Redash Data is now fully vectorized.")
    else:
        print("No documents were found to index.")

if __name__ == "__main__":
    print(f"--- NEMOCLAW Phase 1 & 3: Data Materialization ---")
    files = fetch_redash_data()
    if files:
        index_data_into_vectorstore(files)
        # Build local relational engine 
        from sqlite_engine import init_sqlite_db
        init_sqlite_db()
    else:
        print("No files fetched. Check Redash connection or skip indexing.")
