from fastapi import APIRouter
from pydantic import BaseModel
import httpx

router = APIRouter(prefix="/api/teams", tags=["MS Teams Mock"])

class TeamsWebhook(BaseModel):
    user_id: str
    channel_id: str
    message: str

@router.post("/webhook")
async def process_teams_webhook(data: TeamsWebhook):
    """
    MOCK ENDPOINT: Simulates receiving a webhook from MS Teams and responding with a Card.
    Sends the message to the central chat_api to preserve history.
    """
    print(f"\n[MS TEAMS] Received message from {data.user_id}: '{data.message}'")
    
    # Forward to the conversational agent
    async with httpx.AsyncClient() as client:
        chat_payload = {
            "session_id": f"teams_{data.channel_id}",
            "message": data.message
        }
        res = await client.post("http://127.0.0.1:8000/api/chat/message", json=chat_payload, timeout=60.0)
        bot_reply = res.json().get("response", "Error generating Teams response")
        
    print(f"  -> Replying to Teams: {bot_reply[:50]}...")
    
    # Return mock adaptive card
    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "body": [
                        {
                            "type": "TextBlock",
                            "text": "NEMOCLAW Insights \U0001f916", # Robot emoji
                            "weight": "Bolder",
                            "size": "Medium"
                        },
                        {
                            "type": "TextBlock",
                            "text": bot_reply,
                            "wrap": True
                        }
                    ]
                }
            }
        ]
    }
