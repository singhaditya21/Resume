from fastapi import APIRouter
from pydantic import BaseModel
import time

router = APIRouter(prefix="/api/marketing", tags=["Marketing Mock"])

class CampaignTrigger(BaseModel):
    account_id: str
    account_name: str
    campaign_type: str
    reason: str

@router.post("/trigger_campaign")
async def trigger_campaign(data: CampaignTrigger):
    """
    MOCK ENDPOINT: Simulates a REST API call to Marketo/HubSpot/Outreach
    to queue an Account-Based Marketing (ABM) campaign.
    """
    print(f"\n[MARKETING ABM] Triggering {data.campaign_type} campaign for '{data.account_name}' (ID: {data.account_id})")
    print(f"  -> Trigger Reason: {data.reason}")
    print(f"  -> SUCCESS: Campaign queued in Marketo/Outreach")
    
    return {"status": "success", "message": f"ABM campaign launched for {data.account_name}"}
