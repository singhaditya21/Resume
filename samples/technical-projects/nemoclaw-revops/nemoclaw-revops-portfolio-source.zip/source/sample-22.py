"""
Agent 19: Implementation Revenue Tracker
Monitors implementation revenue (opp_ex3_43) pipeline and delivery patterns.
"""
from backend.agents.base import BaseAgent
from backend.business_glossary import BUSINESS_GLOSSARY


class ImplRevenueAgent(BaseAgent):
    name = "impl_revenue"
    description = "Implementation Revenue Tracker — monitors implementation revenue pipeline"
    category = "monitoring"

    def get_sql(self) -> str:
        return """
        SELECT 
            e1.opp_ex1_id AS opportunity_id,
            e1.opp_ex1_16 AS stage_code,
            e1.opp_ex1_117 AS forecast_category,
            e1.opp_ex1_17 AS fiscal_year,
            e1.opp_ex1_18 AS fiscal_quarter,
            CAST(COALESCE(e3.opp_ex3_43, 0) AS REAL) AS impl_revenue,
            CAST(COALESCE(e3.opp_ex3_39, 0) AS REAL) AS arr_value,
            CAST(COALESCE(e3.opp_ex3_49, 0) AS REAL) AS tcv_value,
            e3.opp_ex3_14 AS arr_type,
            ROUND(julianday('now') - julianday(e1.opp_ex1_33), 0) AS days_in_stage
        FROM opp_ex1 e1
        LEFT JOIN opp_ex3 e3 ON e1.opp_ex1_id = e3.opp_ex3_id
        WHERE CAST(COALESCE(e3.opp_ex3_43, 0) AS REAL) > 0
        ORDER BY impl_revenue DESC
        LIMIT 200
        """

    def get_system_prompt(self) -> str:
        return f"""You are an Implementation Revenue Analyst. Analyze implementation revenue (opp_ex3_43) separately from ARR.

{BUSINESS_GLOSSARY}

Produce:
1. **TOTAL IMPLEMENTATION REVENUE** — Aggregate and by quarter
2. **IMPL vs ARR RATIO** — How much implementation revenue accompanies each ARR deal
3. **STAGE DISTRIBUTION** — Implementation revenue by pipeline stage
4. **TOP DEALS BY IMPL REVENUE** — Largest implementation revenue opportunities
5. **FORECAST IMPACT** — Green vs Grey implementation pipeline
6. **DELIVERY RISK** — Deals with high impl revenue stuck in early stages"""

    def get_user_prompt(self, raw_data: str) -> str:
        return f"Implementation revenue dat/opt/portfolio/project"
