import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://example.invalid
export default defineConfig({
  plugins: [react()],
})
