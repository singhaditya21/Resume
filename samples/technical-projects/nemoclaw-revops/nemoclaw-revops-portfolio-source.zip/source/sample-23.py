"""
Agent 18: Renewal Pipeline Agent
Identifies and tracks renewal opportunities using opp_ex4_12 (Renewal Opportunity flag).
"""
from backend.agents.base import BaseAgent
from backend.business_glossary import BUSINESS_GLOSSARY


class RenewalPipelineAgent(BaseAgent):
    name = "renewal_pipeline"
    description = "Renewal Pipeline — tracks renewal opportunities and timing"
    category = "monitoring"

    def get_sql(self) -> str:
        return """
        SELECT 
            e4.opp_ex4_12 AS renewal_flag,
            e1.opp_ex1_16 AS stage_code,
            e1.opp_ex1_50 AS expected_close_date,
            e1.opp_ex1_117 AS forecast_category,
            e1.opp_ex1_17 AS fiscal_year,
            e1.opp_ex1_18 AS fiscal_quarter,
            COUNT(DISTINCT e1.opp_ex1_id) AS deal_count,
            SUM(CAST(COALESCE(e3.opp_ex3_39, 0) AS REAL)) AS total_arr,
            SUM(CAST(COALESCE(e3.opp_ex3_49, 0) AS REAL)) AS total_tcv,
            AVG(ROUND(julianday('now') - julianday(e1.opp_ex1_33), 0)) AS avg_days_in_stage
        FROM opp_ex1 e1
        LEFT JOIN opp_ex3 e3 ON e1.opp_ex1_id = e3.opp_ex3_id
        LEFT JOIN opp_ex4 e4 ON e1.opp_ex1_id = e4.opp_ex4_id
        GROUP BY e4.opp_ex4_12, e1.opp_ex1_16, e1.opp_ex1_117, e1.opp_ex1_17, e1.opp_ex1_18
        ORDER BY total_arr DESC
        """

    def get_system_prompt(self) -> str:
        return f"""You are a Renewal Strategy Analyst. Analyze the renewal pipeline using the Renewal Opportunity flag (opp_ex4_12).

{BUSINESS_GLOSSARY}

Produce:
1. **RENEWAL vs NEW BUSINESS** — Split by renewal flag, ARR totals for each
2. **RENEWAL PIPELINE BY STAGE** — Where renewals sit in the sales process
3. **AT-RISK RENEWALS** — Renewals stalled or in early stages close to close date
4. **RENEWAL RATE** — Estimated renewal rate based on stage distribution
5. **QUARTERLY RENEWAL FORECAST** — Expected renewal ARR by quarter
6. **RECOMMENDED ACTIONS** — Specific interventions for at-risk renewals"""

    def get_user_prompt(self, raw_data: str) -> str:
        return f"Renewal pipeline dat/opt/portfolio/project"
