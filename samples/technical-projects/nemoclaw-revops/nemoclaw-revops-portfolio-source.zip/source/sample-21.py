from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import sqlite3
import datetime
import os

router = APIRouter(prefix="/api/crm", tags=["CRM Mock"])

# We'll use the existing DB just to record that the mock action happened
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "nemo_claw.db")

class ForecastUpdate(BaseModel):
    deal_id: int
    new_category: str
    reason: str

class TaskCreate(BaseModel):
    deal_id: int
    assigned_to: str
    message: str
    action_type: str

@router.post("/update_forecast")
async def update_forecast(data: ForecastUpdate):
    """
    MOCK ENDPOINT: Simulates a REST API call to Salesforce/HubSpot to update an Opportunity.
    In a real scenario, this would be an outbound HTTP request from the agent.
    Here, we receive the request and simulate a successful CRM write-back.
    """
    print(f"\n[CRM WRITE-BACK] Updating Deal {data.deal_id} forecast to '{data.new_category}'")
    print(f"  -> Reason: {data.reason}")
    
    # We will actually write to the DB just to prove the simulation works end-to-end
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE opp_ex1 SET opp_ex1_117 = ? WHERE opp_ex1_id = ?",
            (data.new_category, data.deal_id)
        )
        conn.commit()
        conn.close()
        print(f"  -> SUCCESS: Database updated.")
    except Exception as e:
        print(f"  -> ERROR: {e}")
        
    return {"status": "success", "message": "Forecast updated in mock CRM"}

@router.post("/create_task")
async def create_task(data: TaskCreate):
    """
    MOCK ENDPOINT: Simulates a REST API call to Slack/Teams or a CRM Task creation.
    """
    print(f"\n[CRM ACTION] Task created for {data.assigned_to} on Deal {data.deal_id}")
    print(f"  -> Message: {data.message}")
    print(f"  -> Action: {data.action_type}")
    
    return {"status": "success", "message": "Task queued in mock API"}
