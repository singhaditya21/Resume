import os
import time
import asyncio
from typing import Optional, Dict, Any
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from dotenv import load_dotenv
import hashlib
import chromadb
from langchain_huggingface import HuggingFaceEmbeddings

# Load env variables if .env exists
load_dotenv()

# --- HF Pro: Upgraded Embedding Model ---
# all-mpnet-base-v2 (109M params, 768-dim) replaces all-MiniLM-L6-v2 (22M, 384-dim)
# ~40% better semantic accuracy for cache hits and memory retrieval
# Runs 100% locally — zero API calls, zero limits
HF_TOKEN = os.getenv("HF_TOKEN", None)
EMBEDDING_MODEL = "REDACTED_OPAQUE_VALUE"

def _build_embeddings():
    """Build the local embedding model with HF Pro token for faster downloads."""
    kwargs = {}
    if HF_TOKEN:
        kwargs["token"] = HF_TOKEN
        print(f"[HF Pro] Authenticated downloads enabled. Using {EMBEDDING_MODEL}")
    else:
        print(f"[HF] Using {EMBEDDING_MODEL} (set HF_TOKEN in .env for faster downloads)")
    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs=kwargs
    )

def _embed_via_hf_api(text: str) -> list:
    """
    Fallback: Use HuggingFace Inference API for embeddings when local model fails.
    Free with HF Pro (~1000 RPM). Zero extra cost.
    """
    import requests as req
    headers = {}
    if HF_TOKEN:
        headers["Authorization"] = f"Bearer {HF_TOKEN}"
    api_url = f"https://example.invalid}"
    resp = req.post(api_url, headers=headers, json={"inputs": text, "options": {"wait_for_model": True}}, timeout=30)
    resp.raise_for_status()
    return resp.json()

# Semantic Cache Implementation
class SemanticCache:
    def __init__(self, persist_directory: str = "/opt/portfolio/project"):
        self.persist_directory = persist_directory
        try:
            self.client = chromadb.PersistentClient(path=self.persist_directory)
            self.embeddings = _build_embeddings()
            self.collection = self.client.get_or_create_collection(
                name="semantic_prompt_cache_v2",  # v2: new embedding dims (768 vs 384)
                metadata={"hnsw:space": "cosine"}
            )
            self.enabled = True
        except Exception as e:
            print(f"Warning: Failed to initialize SemanticCache: {e}")
            self.enabled = False

    def _safe_embed(self, text: str) -> list:
        """Embed text locally, falling back to HF Inference API if local fails."""
        try:
            return self.embeddings.embed_query(text)
        except Exception as e:
            print(f"[HF Failover] Local embedding failed ({e}). Routing to HF Inference API...")
            try:
                return _embed_via_hf_api(text)
            except Exception as api_err:
                print(f"[HF Failover] HF API also failed: {api_err}")
                raise

    def get_cached_response(self, system_prompt: str, user_prompt: str, threshold: float = 0.05) -> Optional[str]:
        if not self.enabled: return None
        if "Retry Attempt:" in user_prompt: return None
        try:
            system_hash = hashlib.sha256(system_prompt.encode('utf-8')).hexdigest()
            vector = self._safe_embed(user_prompt)
            results = self.collection.query(
                query_embeddings=[vector],
                n_results=1,
                where={"system_hash": system_hash}
            )
            
            if results['distances'] and results['distances'][0]:
                distance = results['distances'][0][0]
                if distance <= threshold:
                    print(f"[CACHE HIT] Found semantically similar prompt with distance {distance:.4f} (Threshold: {threshold}). Bypassing LLM.")
                    docs = results['documents'][0]
                    if docs:
                        return docs[0]
        except Exception as e:
            print(f"Warning: Cache retrieval failed: {e}")
        return None

    def set_cached_response(self, system_prompt: str, user_prompt: str, response: str):
        if not self.enabled: return
        try:
            system_hash = hashlib.sha256(system_prompt.encode('utf-8')).hexdigest()
            doc_id = hashlib.sha256(f"{system_hash}_{user_prompt}".encode('utf-8')).hexdigest()
            vector = self._safe_embed(user_prompt)
            
            self.collection.add(
                ids=[doc_id],
                embeddings=[vector],
                documents=[response],
                metadatas=[{"system_hash": system_hash}]
            )
        except Exception as e:
            print(f"Warning: Cache insertion failed: {e}")

semantic_cache = SemanticCache()

# Rate Limiter for Cerebras (Qwen model: 30 RPM, 30,000 TPM)
class RateLimiter:
    def __init__(self, rpm_limit: int = 30, tpm_limit: int = 30000):
        self.rpm_limit = rpm_limit
        self.tpm_limit = tpm_limit
        self.requests = []  # List of timestamps
        self.tokens = []    # List of (timestamp, token_count)
    
    def _cleanup(self):
        now = time.time()
        one_min_ago = now - 60.0
        self.requests = [ts for ts in self.requests if ts > one_min_ago]
        self.tokens = [(ts, count) for ts, count in self.tokens if ts > one_min_ago]

    def _current_tokens(self) -> int:
        return sum(count for _, count in self.tokens)

    async def wait_if_needed(self, estimated_tokens: int = 1000):
        self._cleanup()
        
        while len(self.requests) >= self.rpm_limit or (self._current_tokens() + estimated_tokens) > self.tpm_limit:
            # Sleep briefly and re-check
            await asyncio.sleep(1.0)
            self._cleanup()
            
        # Register the request
        now = time.time()
        self.requests.append(now)
        self.tokens.append((now, estimated_tokens))

# Global rate limiter instance
_cerebras_limiter = RateLimiter(rpm_limit=30, tpm_limit=30000)

class LLMClient:
    def __init__(self, backend_type: str = "cerebras"):
        """
        backend_type: 'cerebras' — uses Cerebras API with auto-fallback to local Qwen-7B GGUF
        """
        self.backend_type = backend_type
        self.cerebras_llm = None
        self.local_llm = None
        
        # --- Primary: Cerebras Cloud API ---
        if self.backend_type in ("cerebras", "auto"):
            try:
                self.api_key = os.getenv("CEREBRAS_API_KEY", "")
                self.model_name = "qwen-3-235b-a22b-instruct-2507"
                self.cerebras_llm = ChatOpenAI(
                    api_key=REDACTED_SECRET
                    base_url="https://example.invalid",
                    model=self.model_name
                )
                print(f"[LLM] Primary backend: Cerebras ({self.model_name})")
            except Exception as e:
                print(f"Warning: Cerebras init failed: {e}")
        
        # --- Backup: Local Qwen-7B GGUF via llama.cpp ---
        self._init_local_backup()
    
    def _init_local_backup(self):
        """Initialize local Qwen-7B GGUF model as fallback (lazy — only loads if needed)."""
        self.local_model_path = os.getenv(
            "LLAMA_CPP_MODEL_PATH", 
            "./models/qwen-7b-instruct.Q4_K_M.gguf"
        )
        if os.path.exists(self.local_model_path):
            print(f"[LLM] Backup available: Local Qwen-7B GGUF at {self.local_model_path}")
        else:
            print(f"[LLM] Backup model not found at {self.local_model_path}. Download it for offline fallback.")
    
    def _get_local_llm(self):
        """Lazy-load the local llama.cpp model only when needed."""
        if self.local_llm is None:
            try:
                from langchain_community.llms import LlamaCpp
                self.local_llm = LlamaCpp(
                    model_path=self.local_model_path,
                    temperature=0.7,
                    max_tokens=REDACTED_SECRET
                    n_ctx=4096,
                    verbose=False
                )
                print("[LLM] Local Qwen-7B GGUF loaded successfully via llama.cpp")
            except Exception as e:
                print(f"[LLM] Failed to load local model: {e}")
                raise
        return self.local_llm

    async def generate_response(self, system_prompt: str, user_prompt: str, estimated_output_tokens: int = 500) -> str:
        """
        Generates a response. Strategy:
        1. Check Semantic Cache first
        2. Try Cerebras API (primary)
        3. If Cerebras fails → auto-fallback to local Qwen-7B GGUF
        """
        # 1. Semantic Cache Lookup
        cached_response = semantic_cache.get_cached_response(system_prompt, user_prompt)
        if cached_response:
            return cached_response

        # 2. Try Cerebras (primary)
        response_content = ""
        if self.cerebras_llm:
            try:
                input_length = len(system_prompt.split()) + len(user_prompt.split())
                estimated_total = int(input_length * 1.3) + estimated_output_tokens
                
                await _cerebras_limiter.wait_if_needed(estimated_total)
                
                messages = [
                    SystemMessage(content=system_prompt),
                    HumanMessage(content=user_prompt)
                ]
                response = self.cerebras_llm.invoke(messages)
                response_content = response.content
                
            except Exception as e:
                print(f"[LLM] Cerebras failed: {e}. Falling back to local Qwen-7B...")
                response_content = ""  # Will trigger fallback below
        
        # 3. Fallback to local Qwen-7B GGUF if Cerebras failed or unavailable
        if not response_content:
            try:
                local = self._get_local_llm()
                prompt = f"<|im_start|>system\n{system_prompt}<|im_end|>\n<|im_start|>user\n{user_prompt}<|im_end|>\n<|im_start|>assistant\n"
                response = local.invoke(prompt)
                response_content = response
                print("[LLM] Response generated via local Qwen-7B GGUF")
            except Exception as e:
                print(f"[LLM] Both Cerebras and local fallback failed: {e}")
                response_content = f"Error: All LLM backends failed. Cerebras may be rate-limited and local model is unavailable."

        # 4. Store in Cache
        if response_content and not response_content.startswith("Error:"):
            semantic_cache.set_cached_response(system_prompt, user_prompt, response_content)

        return response_content

# Default instance
default_backend = os.getenv("BACKEND_TYPE", "cerebras")
llm_client = LLMClient(backend_type=default_backend)

async def ask_llm(system_prompt: str, user_prompt: str, estimated_output_tokens: int = 500) -> str:
    return await llm_client.generate_response(system_prompt, user_prompt, estimated_output_tokens)
