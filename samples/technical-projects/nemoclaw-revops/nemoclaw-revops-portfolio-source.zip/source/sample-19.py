import os
import json
from typing import List, Dict

BUS_FILE = r"/opt/portfolio/project"

class CrossAgentBus:
    def __init__(self):
        self.bus_file = BUS_FILE
        if not os.path.exists(self.bus_file):
            with open(self.bus_file, "w", encoding="utf-8") as f:
                json.dump({"learnings": []}, f)

    def _load(self) -> Dict:
        try:
            with open(self.bus_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {"learnings": []}

    def _save(self, data: Dict):
        with open(self.bus_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def write_learning(self, agent_name: str, topic: str, content: str):
        """
        Record a permanent structural learning from an agent (e.g., 'table X has no data').
        """
        data = self._load()
        # Avoid exact duplicates
        for l in data["learnings"]:
            if l["agent"] == agent_name and l["topic"] == topic and l["content"] == content:
                return
                
        data["learnings"].append({
            "agent": agent_name,
            "topic": topic,
            "content": content
        })
        self._save(data)

    def get_all_learnings(self) -> str:
        """
        Retrieve all shared learnings to inject into agent system prompts.
        """
        data = self._load()
        if not data["learnings"]:
            return ""
            
        compiled = "\n[SHARED AGENT MEMORY BUS]:\n"
        for l in data["learnings"]:
            compiled += f"- Learned by {l['agent']} regarding '{l['topic']}': {l['content']}\n"
        return compiled

shared_bus = CrossAgentBus()
