import React from 'react';
import { AlertTriangle, BarChart3, ListChecks } from 'lucide-react';
import type { Metric, Issue, ModuleSummary } from '../types';
import { KPICard } from './KPICard';
import { DonutChart, CompletenessBar, WinRateGauge } from './Charts';
import { IssuesPanel } from './IssuesPanel';

interface AuditDashboardProps {
  module: ModuleSummary;
  metrics: Metric[];
  issues: Issue[];
  onDrilldown: (key: string) => void;
}

// Chart segment colours keyed by the tone a module declares on its metrics, so
// a new module gets sensible colours without touching this file.
const toneHex: Record<string, string> = {
  blue: '#3b82f6',
  sky: '#22d3ee',
  green: '#10b981',
  red: '#ef4444',
  orange: '#f59e0b',
  grey: '#64748b',
};

const SectionHeading: React.FC<{ icon: React.ReactNode; title: string; count?: number }> = ({
  icon,
  title,
  count,
}) => (
  <div className="flex items-center gap-3 mb-5">
    {icon}
    <h2 className="text-lg font-bold text-slate-100">{title}</h2>
    {count !== undefined && (
      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-800/80 text-slate-400 border border-slate-700/50">
        {count}
      </span>
    )}
    <div className="flex-1 h-px bg-gradient-to-r from-slate-700 to-transparent" />
  </div>
);

export const AuditDashboard: React.FC<AuditDashboardProps> = ({
  module,
  metrics,
  issues,
  onDrilldown,
}) => {
  const valueOf = (key: string) => metrics.find((m) => m.key === key)?.value ?? 0;

  // A metric's share of whatever it declares as its denominator.
  const percentFor = (metric: Metric): number | undefined => {
    if (!metric.pctOf || metric.value === undefined) return undefined;
    const base = valueOf(metric.pctOf);
    return base > 0 ? (metric.value / base) * 100 : undefined;
  };

  const failed = metrics.filter((m) => m.error);
  const shown = metrics.filter((m) => !m.error);

  // Donut segments: the volume metrics that describe a share of a whole. If a
  // module declares none, the donut is skipped rather than rendered empty.
  const donutSegments = shown
    .filter((m) => m.group === 'volume' && m.pctOf && (m.value ?? 0) > 0)
    .map((m) => ({
      label: m.label,
      value: m.value ?? 0,
      color: toneHex[m.tone] ?? toneHex.grey,
    }));

  const completenessBars = shown.filter((m) => m.pctOf && m.value !== undefined);

  // Only modules that declare both outcomes get the win-rate gauge.
  const won = shown.find((m) => m.key === 'won');
  const lost = shown.find((m) => m.key === 'lost');
  const showWinRate = won !== undefined && lost !== undefined;

  return (
    <div className="max-w-[1600px] mx-auto px-6 py-8 space-y-10">
      <header>
        <h1 className="text-3xl font-black text-slate-50 mb-2">{module.title}</h1>
        <p className="text-sm text-slate-400 max-w-3xl">{module.description}</p>
      </header>

      {failed.length > 0 && (
        <div className="glass rounded-xl border border-amber-700/40 p-4 flex gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold text-amber-200 mb-1">
              {failed.length} metric{failed.length > 1 ? 's' : ''} could not be computed
            </p>
            <ul className="text-amber-200/70 text-xs space-y-1">
              {failed.map((m) => (
                <li key={m.key}>
                  <span className="font-medium">{m.label}:</span> {m.error}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <section>
        <SectionHeading
          icon={<BarChart3 className="w-5 h-5 text-blue-400" />}
          title="Key Metrics"
          count={shown.length}
        />
        <div className="grid gap-5 grid-cols-1 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((metric) => (
            <KPICard
              key={metric.key}
              metric={metric}
              percentage={percentFor(metric)}
              onDrilldown={metric.drilldown ? () => onDrilldown(metric.drilldown as string) : undefined}
            />
          ))}
        </div>
      </section>

      {(donutSegments.length > 0 || completenessBars.length > 0 || showWinRate) && (
        <section className="grid gap-6 lg:grid-cols-2">
          {donutSegments.length > 0 && (
            <DonutChart label={`${module.shortTitle} breakdown`} values={donutSegments} />
          )}
          {showWinRate && <WinRateGauge won={won.value ?? 0} lost={lost.value ?? 0} />}
          {completenessBars.length > 0 && (
            <div className="glass rounded-2xl p-6 space-y-4">
              <p className="text-xs uppercase tracking-widest font-bold text-slate-400">
                Share of population
              </p>
              {completenessBars.map((m) => (
                <CompletenessBar
                  key={m.key}
                  label={m.label}
                  complete={m.value ?? 0}
                  total={valueOf(m.pctOf as string)}
                />
              ))}
            </div>
          )}
        </section>
      )}

      <section>
        <SectionHeading
          icon={<ListChecks className="w-5 h-5 text-amber-400" />}
          title="Issues & Actions"
          count={issues.length}
        />
        <IssuesPanel issues={issues} onDrilldown={onDrilldown} />
      </section>

      <footer className="pt-4 text-center text-xs uppercase tracking-widest text-slate-600">
        CRM Data Audit Framework · Analyze · Review · Approve · Execute
      </footer>
    </div>
  );
};
