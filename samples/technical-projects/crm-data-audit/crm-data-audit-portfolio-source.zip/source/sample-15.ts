export interface Metric {
  key: string;
  label: string;
  value?: number;
  tone: string;
  pctOf?: string;
  group: string;
  description: string;
  issue: boolean;
  severity: string;
  action: string;
  category: string;
  issueLabel: string;
  remediation: string;
  drilldown: string | null;
  error?: string;
}

export interface ModuleSummary {
  id: string;
  title: string;
  shortTitle: string;
  icon: string;
  status: string;
  description: string;
  entityLabel: string;
  plannedChecks: PlannedCheck[];
  metricCount: number;
}

export interface PlannedCheck {
  category: string;
  check: string;
}

export interface DrilldownColumn {
  key: string;
  label: string;
  type: string;
}

export interface DrilldownRow {
  [key: string]: string | null;
}

export interface DrilldownData {
  title: string;
  columns: DrilldownColumn[];
  total: number;
  rows: DrilldownRow[];
  limit: number;
  offset: number;
}

export interface Issue {
  key: string;
  label: string;
  count: number;
  severity: string;
  action: string;
  category: string;
  remediation: string;
  drilldown: string;
}

export interface AuditSummary {
  moduleId: string;
  metrics: Metric[];
}

export interface HealthStatus {
  mode: string;
  ready?: boolean;
  error?: string;
  apiVersion?: string;
}
