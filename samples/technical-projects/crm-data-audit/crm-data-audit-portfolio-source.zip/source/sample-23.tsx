import { useState, useEffect } from 'react';
import { Loader, AlertCircle, ShieldCheck } from 'lucide-react';
import { api } from './api';
import type { HealthStatus, ModuleSummary } from './types';
import { StatusBanner } from './components/StatusBanner';
import { ModuleTab } from './components/ModuleTab';

// The dashboard shows this module and nothing else. The other modules stay
// registered on the server; widen this list (or drop the filter) to bring the
// tab bar back — with two or more entries the tabs render automatically.
const VISIBLE_MODULES = ['users'];

function App() {
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [modules, setModules] = useState<ModuleSummary[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [healthData, moduleList] = await Promise.all([api.health(), api.modules()]);
        const visible = moduleList.filter((m) => VISIBLE_MODULES.includes(m.id));
        setHealth(healthData);
        setModules(visible);
        setActiveId(visible.find((m) => m.status === 'active')?.id ?? visible[0]?.id ?? null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to reach the audit API');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Loader className="w-10 h-10 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-slate-400 font-medium">Loading CRM Data Audit Framework…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen px-6">
        <div className="glass rounded-2xl border border-red-800/40 p-6 flex gap-4 max-w-lg">
          <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-200 mb-1">Cannot reach the audit API</h3>
            <p className="text-sm text-red-300/80">{error}</p>
            <p className="text-xs text-slate-500 mt-3">
              Start it with <code className="text-slate-400">node dev.js</code> from the{' '}
              <code className="text-slate-400">crm-audit/</code> directory.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const active = modules.find((m) => m.id === activeId) ?? null;

  return (
    <div className="min-h-screen">
      {health && <StatusBanner {...health} />}

      <div className="border-b border-slate-800/80 bg-slate-950/40 backdrop-blur sticky top-0 z-30">
        <div className="max-w-[1600px] mx-auto px-6">
          <div className="flex items-center gap-3 py-5">
            <ShieldCheck className="w-6 h-6 text-blue-400" />
            <span className="text-sm font-bold uppercase tracking-widest text-slate-300">
              CRM Data Audit Framework
            </span>
          </div>

          {/* One visible module needs no tab bar — it would just be a label. */}
          {modules.length > 1 && (
            <nav className="flex gap-1 overflow-x-auto pb-0" role="tablist">
              {modules.map((m) => {
                const isActive = m.id === activeId;
                return (
                  <button
                    key={m.id}
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setActiveId(m.id)}
                    title={m.description}
                    className={`px-4 py-3 text-sm font-semibold whitespace-nowrap border-b-2 transition-colors ${
                      isActive
                        ? 'border-blue-400 text-blue-300'
                        : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {m.shortTitle}
                    {m.status !== 'active' && (
                      <span className="ml-2 text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-800 text-slate-500 border border-slate-700">
                        planned
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          )}
        </div>
      </div>

      {active ? (
        <ModuleTab key={active.id} module={active} />
      ) : (
        <p className="text-center text-slate-500 text-sm mt-20">No module is enabled.</p>
      )}
    </div>
  );
}

export default App;
