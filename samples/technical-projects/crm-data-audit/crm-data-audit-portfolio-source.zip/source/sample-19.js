// Deterministic sample dataset used when USE_MOCK_DATA=true (or while DB
// credentials are not yet configured). Lets the dashboard be developed and
// demonstrated before the real database connection is available. The UI
// displays a prominent "sample data" banner whenever this executor is active.

const MOCK_METRICS = {
  opportunity: {
    total: 12847,
    open: 3412,
    closed: 9435,
    won: 4120,
    lost: 4890,
    no_owner: 214,
    no_account: 168,
    open_stale_2y: 447,
  },
};

// Deterministic pseudo-random helper so pagination stays stable between calls.
function seeded(n) {
  const x = Math.sin(n * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

function isoDate(daysAgo) {
  const base = new Date('2026-08-07T00:00:00Z');
  base.setUTCDate(base.getUTCDate() - daysAgo);
  return base.toISOString().slice(0, 10);
}

const STAGES = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Contract Review'];

function mockDrilldownRows(moduleId, key, total) {
  const rows = [];
  for (let i = 0; i < total; i++) {
    const r1 = seeded(i + 1);
    const r2 = seeded(i + 101);
    const stage = STAGES[Math.floor(r1 * STAGES.length)];
    if (key === 'open_stale_2y') {
      rows.push({
        name: `OPP-${String(4200 + i).padStart(5, '0')} · ${stage}`,
        stageenddate: isoDate(-Math.floor(30 + r1 * 900)), // future stage end = open
        lastmodifiedon: isoDate(Math.floor(731 + r2 * 1200)), // >2y since modification
        status: 'Open - No activity for 2 years',
      });
    } else if (key === 'no_owner') {
      rows.push({
        name: `OPP-${String(1500 + i).padStart(5, '0')} · ${stage}`,
        stageenddate: isoDate(Math.floor(r1 * 700) - 350),
        lastmodifiedon: isoDate(Math.floor(90 + r2 * 700)),
        status: 'Owner not assigned',
      });
    } else {
      rows.push({
        name: `OPP-${String(7800 + i).padStart(5, '0')} · ${stage}`,
        stageenddate: isoDate(Math.floor(r1 * 700) - 350),
        lastmodifiedon: isoDate(Math.floor(60 + r2 * 600)),
        status: 'No account linked',
      });
    }
  }
  // Oldest activity first, mirroring the real drilldown ORDER BY.
  rows.sort((a, b) => a.lastmodifiedon.localeCompare(b.lastmodifiedon));
  return rows;
}

const drilldownCache = new Map();

export const mockExecutor = {
  mode: 'mock',

  async metricValue(moduleId, metric) {
    const v = MOCK_METRICS[moduleId]?.[metric.key];
    if (v === undefined) throw new Error(`No sample value for metric ${moduleId}.${metric.key}`);
    return v;
  },

  async drilldown(moduleId, def, limit, offset) {
    const total = MOCK_METRICS[moduleId]?.[def.metricKey] ?? 0;
    const cacheKey = `${moduleId}.${def.key}`;
    if (!drilldownCache.has(cacheKey)) {
      drilldownCache.set(cacheKey, mockDrilldownRows(moduleId, def.key, total));
    }
    const rows = drilldownCache.get(cacheKey);
    return { total, rows: rows.slice(offset, offset + limit) };
  },

  async health() {
    return { mode: 'mock' };
  },
};
