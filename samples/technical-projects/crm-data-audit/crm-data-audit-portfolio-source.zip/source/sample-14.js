// Planned module stub. To activate: set status to 'active', add `metrics`
// (with validated SQL) and optional `drilldowns` following the shape in
// opportunity.js. Nothing else in the app needs to change.
export default {
  id: 'lead',
  title: 'Lead Data Audit',
  shortTitle: 'Leads',
  icon: 'user-plus',
  status: 'planned',
  description:
    'Lead funnel hygiene: capture quality, duplicates, staleness, conversion linkage, and ownership.',
  entityLabel: 'leads',
  plannedChecks: [
    { category: 'Data Quality', check: 'Invalid / missing email and phone formats' },
    { category: 'Completeness', check: 'Leads missing source, campaign, or territory' },
    { category: 'Duplicates', check: 'Same email or phone across multiple leads (Merge candidates)' },
    { category: 'Inactivity', check: 'Leads untouched beyond SLA thresholds' },
    { category: 'Relationship', check: 'Converted leads without linked account/opportunity' },
    { category: 'Ownership', check: 'Unassigned or orphan-owner leads' },
    { category: 'Cleanup', check: 'Dead leads eligible for archive / delete approval' },
  ],
};
