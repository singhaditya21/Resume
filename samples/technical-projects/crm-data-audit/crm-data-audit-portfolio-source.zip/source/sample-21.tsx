import React, { useState, useEffect } from 'react';
import { Loader, AlertCircle } from 'lucide-react';
import { api } from '../api';
import type { ModuleSummary, Metric, Issue } from '../types';
import { AuditDashboard } from './AuditDashboard';
import { DrilldownModal } from './DrilldownModal';

interface ModuleTabProps {
  module: ModuleSummary;
}

export const ModuleTab: React.FC<ModuleTabProps> = ({ module }) => {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [drilldownKey, setDrilldownKey] = useState<string | null>(null);

  useEffect(() => {
    // Hooks run before the planned-module early return below, so guard here:
    // the API answers 400 for a module with no metrics, and fetching anyway
    // filled the console with failed requests on every planned tab.
    if (module.status !== 'active') {
      setMetrics([]);
      setIssues([]);
      setError(null);
      setLoading(false);
      return;
    }
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const summary = await api.auditSummary(module.id);
        setMetrics(summary.metrics);
        const issuesList = await api.issues(module.id);
        setIssues(issuesList);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load metrics');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [module.id, module.status]);

  if (module.status === 'planned') {
    return (
      <div className="max-w-[1600px] mx-auto px-6 py-8">
        <div className="max-w-3xl">
          <h1 className="text-3xl font-black text-slate-50 mb-2">{module.title}</h1>
          <p className="text-slate-400 text-sm mb-8">{module.description}</p>
          <div className="glass rounded-2xl p-6 mb-6">
            <p className="text-xs uppercase tracking-widest text-slate-400 font-bold mb-4">
              Planned Checks
            </p>
            <ul className="space-y-3">
              {module.plannedChecks.map((check, idx) => (
                <li key={idx} className="text-sm text-slate-300 flex gap-3">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-800/80 text-slate-400 border border-slate-700/50 whitespace-nowrap">
                    {check.category}
                  </span>
                  <span className="pt-0.5">{check.check}</span>
                </li>
              ))}
            </ul>
          </div>
          <p className="text-xs text-slate-500">
            This module activates once its SQL is written and validated — see{' '}
            <code className="text-slate-400">server/modules/users.js</code> for the shape.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader className="w-8 h-8 animate-spin text-blue-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-3xl mx-auto mt-12 glass rounded-2xl border border-red-800/40 p-6 flex gap-4">
        <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-red-200 mb-1">Error loading module</h3>
          <p className="text-sm text-red-300/80">{error}</p>
          <p className="text-xs text-slate-500 mt-3">
            Check that the API is running on http://127.0.0.1:4180.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <AuditDashboard
        module={module}
        metrics={metrics}
        issues={issues}
        onDrilldown={(key) => setDrilldownKey(key)}
      />

      {drilldownKey && (
        <DrilldownModal
          isOpen={!!drilldownKey}
          moduleId={module.id}
          drilldownKey={drilldownKey}
          onClose={() => setDrilldownKey(null)}
        />
      )}
    </>
  );
};
