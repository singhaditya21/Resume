import React from 'react';
import { AlertTriangle, CheckCircle, Database, AlertCircle } from 'lucide-react';

interface StatusBannerProps {
  mode: string;
  ready?: boolean;
  error?: string;
}

export const StatusBanner: React.FC<StatusBannerProps> = ({ mode, ready, error }) => {
  if (mode === 'mock') {
    return (
      <div className="px-6 py-2.5 bg-blue-950/60 border-b border-blue-800/40 flex items-center gap-3">
        <AlertCircle className="w-4 h-4 text-blue-400 flex-shrink-0" />
        <span className="text-xs text-blue-200">
          <strong className="font-semibold">Sample Data Mode</strong> — PostgreSQL connection not
          configured. Set the DB_* variables in <code>.env</code> to audit your live database.
        </span>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="px-6 py-2.5 bg-red-950/60 border-b border-red-800/40 flex items-center gap-3">
        <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
        <span className="text-xs text-red-200">
          <strong className="font-semibold">Database Error</strong> —{' '}
          {error || 'Unable to connect to PostgreSQL.'}
        </span>
      </div>
    );
  }

  return (
    <div className="px-6 py-2.5 bg-emerald-950/50 border-b border-emerald-800/40 flex items-center gap-3">
      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
      <span className="text-xs text-emerald-200 flex items-center gap-2">
        <Database className="w-3.5 h-3.5" />
        Connected to PostgreSQL — metrics below are live
      </span>
    </div>
  );
};
