// Planned module stub — see opportunity.js for the active-module shape.
export default {
  id: 'account',
  title: 'Account Data Audit',
  shortTitle: 'Accounts',
  icon: 'building',
  status: 'planned',
  description:
    'Master-data health for accounts: identity completeness, duplicate hierarchy, and orphaned records.',
  entityLabel: 'accounts',
  plannedChecks: [
    { category: 'Data Quality', check: 'Malformed GST/PAN/registration identifiers' },
    { category: 'Completeness', check: 'Accounts missing industry, segment, or address' },
    { category: 'Duplicates', check: 'Fuzzy-matched duplicate account names (Merge candidates)' },
    { category: 'Relationship', check: 'Accounts with no contacts, leads, or opportunities' },
    { category: 'Ownership', check: 'Accounts owned by inactive users' },
    { category: 'Usage', check: 'Accounts with zero activity in trailing 12 months' },
    { category: 'Cleanup', check: 'Shell accounts eligible for archive' },
  ],
};
