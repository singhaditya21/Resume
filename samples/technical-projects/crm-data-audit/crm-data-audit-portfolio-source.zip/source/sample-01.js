// Central registry of audit modules. Adding a module = import + one array
// entry; the API and frontend pick it up automatically.
import opportunity from './modules/opportunity.js';
import lead from './modules/lead.js';
import account from './modules/account.js';
import users from './modules/users.js';
import activity from './modules/activity.js';
import crossobject from './modules/crossobject.js';

export const modules = [opportunity, lead, account, users, activity, crossobject];

export function getModule(id) {
  return modules.find((m) => m.id === id) || null;
}

// Public metadata only — SQL never leaves the server.
export function moduleSummaryList() {
  return modules.map((m) => ({
    id: m.id,
    title: m.title,
    shortTitle: m.shortTitle,
    icon: m.icon,
    status: m.status,
    description: m.description,
    entityLabel: m.entityLabel,
    plannedChecks: m.plannedChecks || [],
    metricCount: (m.metrics || []).length,
  }));
}
