import React from 'react';
import { TrendingUp } from 'lucide-react';
import type { Metric } from '../types';

const toneStyles = {
  blue: {
    bg: 'glass glow-blue border-blue-500/20 from-blue-500/10 to-cyan-500/5',
    accent: 'text-blue-300',
    icon: 'text-blue-400',
    bar: 'bg-gradient-to-r from-blue-500 to-cyan-500',
  },
  sky: {
    bg: 'glass glow-cyan border-cyan-500/20 from-cyan-500/10 to-emerald-500/5',
    accent: 'text-cyan-300',
    icon: 'text-cyan-400',
    bar: 'bg-gradient-to-r from-cyan-500 to-emerald-500',
  },
  green: {
    bg: 'glass glow-green border-emerald-500/20 from-emerald-500/10 to-teal-500/5',
    accent: 'text-emerald-300',
    icon: 'text-emerald-400',
    bar: 'bg-gradient-to-r from-emerald-500 to-teal-500',
  },
  red: {
    bg: 'glass border-red-500/20 from-red-500/10 to-pink-500/5',
    accent: 'text-red-300',
    icon: 'text-red-400',
    bar: 'bg-gradient-to-r from-red-500 to-pink-500',
  },
  orange: {
    bg: 'glass border-amber-500/20 from-amber-500/10 to-orange-500/5',
    accent: 'text-amber-300',
    icon: 'text-amber-400',
    bar: 'bg-gradient-to-r from-amber-500 to-orange-500',
  },
  grey: {
    bg: 'glass border-slate-500/20 from-slate-500/10 to-slate-600/5',
    accent: 'text-slate-300',
    icon: 'text-slate-400',
    bar: 'bg-gradient-to-r from-slate-500 to-slate-600',
  },
};

const severityColors = {
  critical: 'bg-red-600/90 text-white shadow-lg shadow-red-500/50',
  warning: 'bg-amber-600/90 text-white shadow-lg shadow-amber-500/50',
  info: 'bg-blue-600/90 text-white shadow-lg shadow-blue-500/50',
};

interface KPICardProps {
  metric: Metric;
  percentage?: number;
  onDrilldown?: () => void;
}

export const KPICard: React.FC<KPICardProps> = ({ metric, percentage, onDrilldown }) => {
  const style = toneStyles[metric.tone as keyof typeof toneStyles] || toneStyles.blue;
  const severityBadge = metric.severity ? severityColors[metric.severity as keyof typeof severityColors] : '';

  return (
    <div
      className={`
        border rounded-2xl p-6 transition-all duration-300 cursor-pointer
        ${style.bg} hover-lift
        ${onDrilldown ? 'hover:border-blue-400/50' : ''}
      `}
      onClick={onDrilldown}
      style={{
        background: `linear-gradient(135deg, rgba(${metric.tone === 'blue' ? '59, 130, 246' : metric.tone === 'sky' ? '34, 211, 238' : metric.tone === 'green' ? '16, 185, 129' : metric.tone === 'red' ? '239, 68, 68' : metric.tone === 'orange' ? '245, 158, 11' : '100, 116, 139'}, 0.05) 0%, rgba(15, 23, 42, 0.5) 100%)`,
        backdropFilter: 'blur(12px)',
        border: `1px solid rgba(${metric.tone === 'blue' ? '59, 130, 246' : metric.tone === 'sky' ? '34, 211, 238' : metric.tone === 'green' ? '16, 185, 129' : metric.tone === 'red' ? '239, 68, 68' : metric.tone === 'orange' ? '245, 158, 11' : '100, 116, 139'}, 0.2)`,
      }}
      title={metric.description}
    >
      <div className="flex items-start justify-between gap-3 mb-6">
        <div className="flex-1 min-w-0">
          <p className="text-xs uppercase tracking-widest font-bold text-slate-400 mb-1">
            {metric.label}
          </p>
        </div>
        {metric.issue && metric.severity && (
          <span className={`text-xs font-bold px-3 py-1.5 rounded-full whitespace-nowrap ${severityBadge}`}>
            {metric.severity}
          </span>
        )}
      </div>

      <div className="flex items-end justify-between gap-4">
        <div className="flex-1">
          <div className={`text-5xl font-black tabular-nums ${style.accent} leading-none mb-3`}>
            {metric.value ?? '—'}
          </div>
          {percentage !== undefined && (
            <div className="flex items-center gap-2">
              <TrendingUp className={`w-4 h-4 ${style.icon}`} />
              <span className="text-sm font-semibold text-slate-300">
                {percentage.toFixed(1)}%
              </span>
              <span className="text-xs text-slate-500">of total</span>
            </div>
          )}
        </div>
      </div>

      {metric.issue && metric.action && (
        <div className="mt-6 pt-4 border-t border-slate-700/50 flex items-center gap-2">
          <div className={`px-3 py-1.5 rounded-lg text-xs font-bold ${style.bar} text-white`}>
            {metric.action}
          </div>
          <span className="text-xs text-slate-500">{metric.category}</span>
        </div>
      )}
    </div>
  );
};
