import type {
  HealthStatus,
  ModuleSummary,
  AuditSummary,
  DrilldownData,
  Issue,
} from './types';

const API_BASE = 'http://127.0.0.1:4180';

async function fetchApi<T>(path: string): Promise<T> {
  const resp = await fetch(`${API_BASE}${path}`);
  if (!resp.ok) throw new Error(`API ${resp.status}: ${resp.statusText}`);
  return resp.json();
}

export const api = {
  health: (): Promise<HealthStatus> => fetchApi('/health'),
  modules: (): Promise<ModuleSummary[]> => fetchApi('/modules'),
  auditSummary: (moduleId: string): Promise<AuditSummary> =>
    fetchApi(`/audit/${moduleId}/summary`),
  drilldown: (moduleId: string, key: string, limit = 50, offset = 0): Promise<DrilldownData> =>
    fetchApi(`/audit/${moduleId}/drilldown/${key}?limit=${limit}&offset=${offset}`),
  issues: (moduleId: string): Promise<Issue[]> =>
    fetchApi(`/audit/${moduleId}/issues`),
};
