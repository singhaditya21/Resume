// Loads crm-audit/.env into process.env (existing process.env wins),
// then exposes a typed config object. No dotenv dependency available
// on this machine, so parsing is done here.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const envPath = join(here, '..', '.env');

function parseEnvFile(path) {
  let text;
  try {
    text = readFileSync(path, 'utf8');
  } catch {
    return {};
  }
  const out = {};
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

const fileVars = parseEnvFile(envPath);
for (const [k, v] of Object.entries(fileVars)) {
  if (process.env[k] === undefined) process.env[k] = v;
}

const bool = (v) => /^(1|true|yes|on)$/i.test(String(v ?? ''));

export const config = {
  db: {
    host: process.env.DB_HOST || '',
    port: Number(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || '',
    user: process.env.DB_USER || '',
    password: process.env.DB_PASSWORD || '',
    poolSize: Math.min(Math.max(Number(process.env.DB_POOL_SIZE) || 4, 1), 10),
    statementTimeoutMs: Number(process.env.DB_STATEMENT_TIMEOUT_MS) || 15000,
  },
  useMockData: bool(process.env.USE_MOCK_DATA),
  apiPort: Number(process.env.API_PORT) || 4180,
  envPath,
};

export function dbConfigured() {
  const { host, database, user } = config.db;
  return Boolean(host && database && user);
}
