import React from 'react';
import { AlertTriangle, AlertCircle, CheckCircle2, ChevronRight } from 'lucide-react';
import type { Issue } from '../types';

interface IssuesPanelProps {
  issues: Issue[];
  onDrilldown: (drilldownKey: string) => void;
}

const severityIcon: Record<string, React.ReactNode> = {
  critical: <AlertTriangle className="w-5 h-5 text-red-400" />,
  warning: <AlertCircle className="w-5 h-5 text-amber-400" />,
  info: <CheckCircle2 className="w-5 h-5 text-cyan-400" />,
};

const severityBorder: Record<string, string> = {
  critical: 'border-l-red-500 bg-red-900/10 border border-red-800/30 hover:bg-red-900/20',
  warning: 'border-l-amber-500 bg-amber-900/10 border border-amber-800/30 hover:bg-amber-900/20',
  info: 'border-l-cyan-500 bg-cyan-900/10 border border-cyan-800/30 hover:bg-cyan-900/20',
};

const actionBadges: Record<string, string> = {
  Correct: 'bg-yellow-900/60 text-yellow-300 border border-yellow-700/50',
  Review: 'bg-purple-900/60 text-purple-300 border border-purple-700/50',
  Merge: 'bg-indigo-900/60 text-indigo-300 border border-indigo-700/50',
  Archive: 'bg-slate-700/60 text-slate-300 border border-slate-600/50',
  Delete: 'bg-red-900/60 text-red-300 border border-red-700/50',
  Approval: 'bg-orange-900/60 text-orange-300 border border-orange-700/50',
};

export const IssuesPanel: React.FC<IssuesPanelProps> = ({ issues, onDrilldown }) => {
  if (issues.length === 0) {
    return (
      <div className="p-12 text-center">
        <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-emerald-400 opacity-50" />
        <p className="text-slate-400 font-medium">No issues found</p>
        <p className="text-slate-500 text-sm mt-1">Data quality is excellent</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {issues.map((issue) => (
        <div
          key={issue.key}
          className={`p-4 border-l-4 rounded-lg cursor-pointer transition-all duration-200 ${severityBorder[issue.severity] || severityBorder.info}`}
          onClick={() => issue.drilldown && onDrilldown(issue.drilldown)}
        >
          <div className="flex items-start gap-4">
            <div className="mt-0.5 flex-shrink-0">{severityIcon[issue.severity] || severityIcon.info}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-3 mb-2">
                <p className="font-semibold text-slate-200">{issue.label}</p>
                <ChevronRight className="w-4 h-4 text-slate-500 flex-shrink-0 mt-1" />
              </div>
              <p className="text-xs text-slate-400 mb-3 leading-relaxed">{issue.remediation}</p>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-block text-xs font-bold px-3 py-1.5 rounded-full bg-slate-900/60 text-slate-300 border border-slate-700/50">
                  {issue.count.toLocaleString()} records
                </span>
                <span className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-full ${actionBadges[issue.action] || actionBadges.Review}`}>
                  {issue.action}
                </span>
                <span className="text-xs text-slate-500 font-medium">{issue.category}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
