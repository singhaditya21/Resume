import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Loader } from 'lucide-react';
import { api } from '../api';
import type { DrilldownData } from '../types';

interface DrilldownModalProps {
  isOpen: boolean;
  moduleId: string;
  drilldownKey: string;
  onClose: () => void;
}

const PAGE_SIZE = 50;

// Modules return whatever Postgres hands back — some cast to ::date, others
// leave a full timestamp. Trim to the calendar day so every module's date
// column reads the same.
const formatDate = (raw: string) => {
  const match = /^(\d{4}-\d{2}-\d{2})/.exec(raw);
  return match ? match[1] : raw;
};

export const DrilldownModal: React.FC<DrilldownModalProps> = ({
  isOpen,
  moduleId,
  drilldownKey,
  onClose,
}) => {
  const [data, setData] = useState<DrilldownData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);

  // A different metric opened the modal — restart at the first page rather
  // than requesting an offset that may be past the new result set.
  useEffect(() => {
    setOffset(0);
    setData(null);
  }, [drilldownKey, moduleId]);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    setLoading(true);
    const load = async () => {
      try {
        const result = await api.drilldown(moduleId, drilldownKey, PAGE_SIZE, offset);
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load drilldown');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [isOpen, moduleId, drilldownKey, offset]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="glass rounded-2xl shadow-2xl max-w-6xl w-full max-h-[88vh] flex flex-col border border-slate-700/60"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 p-5 border-b border-slate-700/60">
          <div className="min-w-0">
            <h2 className="text-base font-bold text-slate-100 truncate">
              {data?.title || 'Details'}
            </h2>
            {data && (
              <p className="text-xs text-slate-500 mt-0.5">
                {data.total.toLocaleString()} matching records
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="text-slate-500 hover:text-slate-200 transition-colors flex-shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="px-5 py-3 bg-red-950/50 border-b border-red-800/40 text-red-200 text-sm">
            {error}
          </div>
        )}

        <div className="flex-1 overflow-auto">
          {loading && !data ? (
            <div className="flex items-center justify-center h-40">
              <Loader className="w-6 h-6 animate-spin text-slate-500" />
            </div>
          ) : data && data.rows.length === 0 ? (
            <div className="flex items-center justify-center h-40">
              <p className="text-sm text-slate-500">No records on this page.</p>
            </div>
          ) : data ? (
            <table className="w-full text-sm">
              <thead className="bg-slate-900/90 backdrop-blur sticky top-0">
                <tr>
                  {data.columns.map((col) => (
                    <th
                      key={col.key}
                      className="px-4 py-3 text-left text-xs uppercase tracking-wider font-bold text-slate-400 whitespace-nowrap border-b border-slate-700/60"
                    >
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {data.rows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    {data.columns.map((col) => (
                      <td key={col.key} className="px-4 py-2.5 text-slate-300 whitespace-nowrap">
                        {row[col.key] ? (
                          col.type === 'date' ? (
                            <span className="text-xs font-mono bg-slate-800/70 text-slate-300 px-2 py-1 rounded">
                              {formatDate(row[col.key] as string)}
                            </span>
                          ) : (
                            row[col.key]
                          )
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
        </div>

        {data && (
          <div className="px-5 py-3 border-t border-slate-700/60 flex items-center justify-between">
            <span className="text-xs text-slate-500 tabular-nums">
              {data.total === 0
                ? 'No records'
                : `Showing ${(offset + 1).toLocaleString()}–${Math.min(
                    offset + PAGE_SIZE,
                    data.total,
                  ).toLocaleString()} of ${data.total.toLocaleString()}`}
            </span>
            <div className="flex gap-2">
              <button
                disabled={offset === 0 || loading}
                onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
                aria-label="Previous page"
                className="p-2 rounded-lg text-slate-300 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={offset + PAGE_SIZE >= data.total || loading}
                onClick={() => setOffset(offset + PAGE_SIZE)}
                aria-label="Next page"
                className="p-2 rounded-lg text-slate-300 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
