// Planned module stub — see opportunity.js for the active-module shape.
export default {
  id: 'crossobject',
  title: 'Cross-Object Data Governance',
  shortTitle: 'Cross-Object',
  icon: 'network',
  status: 'planned',
  description:
    'Referential integrity across the CRM graph: broken links, orphan chains, and governance scorecards.',
  entityLabel: 'records',
  plannedChecks: [
    { category: 'Relationship', check: 'Foreign keys pointing at missing parents (orphan chains)' },
    { category: 'Data Quality', check: 'Conflicting values for the same entity across objects' },
    { category: 'Ownership', check: 'Owner mismatches between parent and child records' },
    { category: 'Usage', check: 'Object-level growth and touch-rate trends' },
    { category: 'Cleanup', check: 'Coordinated archive / delete-approval workflows across objects' },
  ],
};
