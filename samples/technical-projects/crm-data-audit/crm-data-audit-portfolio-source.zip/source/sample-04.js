// CRM Data Audit API. Exposes:
// - GET /health → connection status
// - GET /modules → module registry
// - GET /audit/MODULEID/summary → KPI snapshot
// - GET /audit/MODULEID/drilldown/KEY → paginated issue details
// - GET /audit/MODULEID/issues → filtered view for Issues & Actions panel

import { createServer } from 'node:http';
import { URL } from 'node:url';
import { config, dbConfigured } from './env.js';
import { Pool, friendlyDbError } from './pgclient.js';
import { mockExecutor } from './mock.js';
import { modules, moduleSummaryList, getModule } from './registry.js';

let executor = null;

async function initExecutor() {
  if (executor) return executor;
  if (config.useMockData) {
    executor = mockExecutor;
    return executor;
  }
  if (!dbConfigured()) {
    executor = mockExecutor;
    return executor;
  }
  const pool = new Pool({
    host: config.db.host,
    port: config.db.port,
    user: config.db.user,
    password: config.db.password,
    database: config.db.database,
    poolSize: config.db.poolSize,
    statementTimeoutMs: config.db.statementTimeoutMs,
  });
  executor = {
    pool,
    mode: 'postgres',
    async metricValue(moduleId, metric) {
      const result = await pool.query(metric.sql);
      if (result.rows.length === 0) return 0;
      const row = result.rows[0];
      const value = Object.values(row)[0];
      return Number(value) || 0;
    },
    async drilldown(moduleId, def, limit, offset) {
      const sql = def.listSql
        .replace(/\{\{limit\}\}/g, String(limit))
        .replace(/\{\{offset\}\}/g, String(offset));
      const countResult = await pool.query(def.countSql);
      const total = Number(countResult.rows[0][Object.keys(countResult.rows[0])[0]]) || 0;
      const dataResult = await pool.query(sql);
      return { total, rows: dataResult.rows };
    },
    async health() {
      try {
        await pool.query('SELECT 1');
        return { mode: 'postgres', ready: true };
      } catch (err) {
        return { mode: 'postgres', ready: false, error: friendlyDbError(err) };
      }
    },
  };
  return executor;
}

const server = createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  try {
    const url = new URL(req.url, `https://example.invalid}`);
    const path = url.pathname;

    // GET /health
    if (path === '/health') {
      const exec = await initExecutor();
      const health = await exec.health();
      res.writeHead(200);
      res.end(JSON.stringify({ ...health, apiVersion: '1.0' }));
      return;
    }

    // GET /modules
    if (path === '/modules') {
      res.writeHead(200);
      res.end(JSON.stringify(moduleSummaryList()));
      return;
    }

    // GET /audit/:moduleId/summary
    const summaryMatch = path.match(/^\/audit\/([a-z]+)\/summary$/);
    if (summaryMatch) {
      const moduleId = summaryMatch[1];
      const mod = getModule(moduleId);
      if (!mod) {
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Module not found' }));
        return;
      }
      if (!mod.metrics) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Module is not active' }));
        return;
      }
      const exec = await initExecutor();
      const metrics = [];
      for (const metric of mod.metrics) {
        try {
          const value = await exec.metricValue(moduleId, metric);
          metrics.push({
            key: metric.key,
            label: metric.label,
            value,
            tone: metric.tone,
            pctOf: metric.pctOf,
            group: metric.group,
            description: metric.description,
            issue: metric.issue || false,
            severity: metric.severity || '',
            action: metric.action || '',
            category: metric.category || '',
            issueLabel: metric.issueLabel || '',
            remediation: metric.remediation || '',
            drilldown: metric.drilldown || null,
          });
        } catch (err) {
          metrics.push({ key: metric.key, label: metric.label, error: err.message });
        }
      }
      res.writeHead(200);
      res.end(JSON.stringify({ moduleId, metrics }));
      return;
    }

    // GET /audit/:moduleId/drilldown/:key
    // Keys carry digits (no_login_3m, open_stale_2y), so the class must too.
    const drilldownMatch = path.match(/^\/audit\/([a-z]+)\/drilldown\/([a-z0-9_]+)$/);
    if (drilldownMatch) {
      const [, moduleId, drilldownKey] = drilldownMatch;
      const mod = getModule(moduleId);
      if (!mod || !mod.drilldowns?.[drilldownKey]) {
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Drilldown not found' }));
        return;
      }
      const limit = Math.min(Math.max(Number(url.searchParams.get('limit')) || 50, 1), 1000);
      const offset = Math.max(Number(url.searchParams.get('offset')) || 0, 0);
      const def = mod.drilldowns[drilldownKey];
      try {
        const exec = await initExecutor();
        const { total, rows } = await exec.drilldown(moduleId, def, limit, offset);
        res.writeHead(200);
        res.end(JSON.stringify({ title: def.title, columns: def.columns, total, rows, limit, offset }));
      } catch (err) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: err.message }));
      }
      return;
    }

    // GET /audit/:moduleId/issues
    const issuesMatch = path.match(/^\/audit\/([a-z]+)\/issues$/);
    if (issuesMatch) {
      const moduleId = issuesMatch[1];
      const mod = getModule(moduleId);
      if (!mod || !mod.metrics) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Module is not active' }));
        return;
      }
      const exec = await initExecutor();
      const issues = [];
      for (const metric of mod.metrics.filter((m) => m.issue)) {
        try {
          const value = await exec.metricValue(moduleId, metric);
          if (value > 0) {
            issues.push({
              key: metric.key,
              label: metric.issueLabel,
              count: value,
              severity: metric.severity,
              action: metric.action,
              category: metric.category,
              remediation: metric.remediation,
              drilldown: metric.drilldown,
            });
          }
        } catch {
          // skip metrics with errors
        }
      }
      res.writeHead(200);
      res.end(JSON.stringify(issues));
      return;
    }

    // 404
    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Not found' }));
  } catch (err) {
    res.writeHead(500);
    res.end(JSON.stringify({ error: err.message }));
  }
});

const port = config.apiPort;
server.listen(port, '127.0.0.1', () => {
  console.log(`CRM Audit API listening on http://127.0.0.1:${port}`);
  console.log(`Using database: ${config.useMockData || !dbConfigured() ? 'mock (sample data)' : 'PostgreSQL'}`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${port} is already in use.`);
  } else {
    console.error('Server error:', err);
  }
  process.exit(1);
});
