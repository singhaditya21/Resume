// Opportunity Data Audit module.
//
// This file is the template for every future audit module: a module is pure
// metadata + SQL. The engine (registry.js + index.js) and the frontend render
// whatever is declared here, so adding Lead/Account/... modules later means
// writing one file like this and registering it — no app redesign.
//
// KPI SQL below is the user-validated query set, unchanged.

const OPEN_STALE_WHERE = `stageenddate >= CURRENT_DATE
  AND lastmodifiedon < CURRENT_DATE - INTERVAL '2 years'`;

export default {
  id: 'opportunity',
  title: 'Opportunity Data Audit',
  shortTitle: 'Opportunities',
  icon: 'target',
  status: 'active',
  description:
    'Pipeline hygiene for the opportunities object: volumes, outcomes, ownership, account linkage, and inactivity.',
  entityLabel: 'opportunities',

  // KPI metrics. `issue: true` rows also appear in the Issues & Actions panel
  // with a severity + recommended remediation classification.
  metrics: [
    {
      key: 'total',
      label: 'Total Opportunities',
      tone: 'blue',
      group: 'volume',
      description: 'All records in dbo.opportunities',
      sql: `SELECT COUNT(*) FROM dbo.opportunities;`,
    },
    {
      key: 'open',
      label: 'Open Opportunities',
      tone: 'sky',
      group: 'volume',
      pctOf: 'total',
      description: 'Stage end date is today or later',
      sql: `SELECT COUNT(*) AS open_count
FROM dbo.opportunities
WHERE stageenddate >= CURRENT_DATE;`,
    },
    {
      key: 'closed',
      label: 'Closed Opportunities',
      tone: 'grey',
      group: 'volume',
      pctOf: 'total',
      description: 'Stage end date is in the past',
      sql: `SELECT COUNT(*) AS closed_count
FROM dbo.opportunities
WHERE stageenddate < CURRENT_DATE;`,
    },
    {
      key: 'won',
      label: 'Won Opportunities',
      tone: 'green',
      group: 'outcome',
      pctOf: 'total',
      description: 'Status code 100077 / 100777',
      sql: `SELECT COUNT(*)
FROM dbo.opportunities
WHERE oppstatuscodeid IN (100077, 100777);`,
    },
    {
      key: 'lost',
      label: 'Lost Opportunities',
      tone: 'red',
      group: 'outcome',
      pctOf: 'total',
      description: 'Status code 100078',
      sql: `SELECT COUNT(*)
FROM dbo.opportunities
WHERE oppstatuscodeid = 100078;`,
    },
    {
      key: 'no_owner',
      label: 'No Owner',
      tone: 'red',
      group: 'issue',
      pctOf: 'total',
      issue: true,
      severity: 'critical',
      action: 'Correct',
      category: 'Ownership',
      issueLabel: 'Opportunities without an owner',
      remediation: 'Assign an owner (oppownerid = 0) so pipeline accountability is restored.',
      description: 'oppownerid = 0',
      drilldown: 'no_owner',
      sql: `SELECT COUNT(*)
FROM dbo.opportunities
WHERE oppownerid = 0;`,
    },
    {
      key: 'no_account',
      label: 'No Account',
      tone: 'orange',
      group: 'issue',
      pctOf: 'total',
      issue: true,
      severity: 'warning',
      action: 'Correct',
      category: 'Relationship',
      issueLabel: 'Opportunities not linked to an account',
      remediation: 'Link each opportunity to its account (accountid = 0) to repair the relationship graph.',
      description: 'accountid = 0',
      drilldown: 'no_account',
      sql: `SELECT COUNT(*)
FROM dbo.opportunities
WHERE accountid = 0;`,
    },
    {
      key: 'open_stale_2y',
      label: 'Open · No Activity 2 Years',
      tone: 'orange',
      group: 'issue',
      pctOf: 'open',
      issue: true,
      severity: 'warning',
      action: 'Archive',
      category: 'Inactivity',
      issueLabel: 'Open but untouched for 2+ years',
      remediation: 'Review with owners, then archive or close stale pipeline to keep forecasts honest.',
      description: 'Open, last modified > 2 years ago',
      drilldown: 'open_stale_2y',
      sql: `SELECT COUNT(*) AS open_no_activity_2_years_count
FROM dbo.opportunities
WHERE stageenddate >= CURRENT_DATE
  AND lastmodifiedon < CURRENT_DATE - INTERVAL '2 years';`,
    },
  ],

  // Record-level drilldowns behind issue KPIs. {{limit}}/{{offset}} are
  // replaced by server-clamped integers — never raw request input.
  drilldowns: {
    open_stale_2y: {
      key: 'open_stale_2y',
      metricKey: 'open_stale_2y',
      title: 'Open Opportunities with No Activity for 2 Years',
      columns: [
        { key: 'name', label: 'Opportunity', type: 'text' },
        { key: 'stageenddate', label: 'Stage End Date', type: 'date' },
        { key: 'lastmodifiedon', label: 'Last Modified', type: 'date' },
        { key: 'status', label: 'Status', type: 'text' },
      ],
      countSql: `SELECT COUNT(*) FROM dbo.opportunities WHERE ${OPEN_STALE_WHERE};`,
      listSql: `SELECT
    name,
    stageenddate,
    lastmodifiedon,
    CASE
        WHEN ${OPEN_STALE_WHERE}
        THEN 'Open - No activity for 2 years'
        ELSE 'Active/Open'
    END AS status
FROM dbo.opportunities
WHERE ${OPEN_STALE_WHERE}
ORDER BY lastmodifiedon ASC
LIMIT {{limit}} OFFSET {{offset}};`,
    },
    no_owner: {
      key: 'no_owner',
      metricKey: 'no_owner',
      title: 'Opportunities Without an Owner',
      columns: [
        { key: 'name', label: 'Opportunity', type: 'text' },
        { key: 'stageenddate', label: 'Stage End Date', type: 'date' },
        { key: 'lastmodifiedon', label: 'Last Modified', type: 'date' },
        { key: 'status', label: 'Status', type: 'text' },
      ],
      countSql: `SELECT COUNT(*) FROM dbo.opportunities WHERE oppownerid = 0;`,
      listSql: `SELECT
    name,
    stageenddate,
    lastmodifiedon,
    CASE WHEN stageenddate >= CURRENT_DATE THEN 'Open' ELSE 'Closed' END AS status
FROM dbo.opportunities
WHERE oppownerid = 0
ORDER BY lastmodifiedon ASC
LIMIT {{limit}} OFFSET {{offset}};`,
    },
    no_account: {
      key: 'no_account',
      metricKey: 'no_account',
      title: 'Opportunities Without an Account',
      columns: [
        { key: 'name', label: 'Opportunity', type: 'text' },
        { key: 'stageenddate', label: 'Stage End Date', type: 'date' },
        { key: 'lastmodifiedon', label: 'Last Modified', type: 'date' },
        { key: 'status', label: 'Status', type: 'text' },
      ],
      countSql: `SELECT COUNT(*) FROM dbo.opportunities WHERE accountid = 0;`,
      listSql: `SELECT
    name,
    stageenddate,
    lastmodifiedon,
    CASE WHEN stageenddate >= CURRENT_DATE THEN 'Open' ELSE 'Closed' END AS status
FROM dbo.opportunities
WHERE accountid = 0
ORDER BY lastmodifiedon ASC
LIMIT {{limit}} OFFSET {{offset}};`,
    },
  },
};
