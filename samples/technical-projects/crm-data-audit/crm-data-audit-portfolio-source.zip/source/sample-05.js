// User Data Audit module.
//
// The metric and drilldown SQL below is the user-validated query set and is
// authoritative — keep it in step with the source queries. Deviations, all of
// them forced:
//
//   * Tables are schema-qualified (`dbo.usercontact`, `dbo.loggedinuser`).
//     The app connects without `dbo` on its search_path, so the unqualified
//     names fail with `relation does not exist`.
//   * The customer drilldown reads `loginid` / `appownerid` off `az_user`, not
//     `usercontact` — those columns only exist on `az_user`, so the original
//     `uc.loginid` form could not run.
//   * That same drilldown joins on `uc.companyid = 2`. `usercontact.userid` is
//     not unique (64 userids repeat across companies), so an unrestricted join
//     fanned 1,009 portal accounts out to 1,015 rows.
//
// Scope note: the volume metrics filter companyid = 2, the login-recency
// metrics deliberately do not — they count active users across every company
// (763 vs 711 for 3 months, 640 vs 588 for 6 months; the delta is companyid 3).
// Because the two populations differ, the recency metrics carry no `pctOf`.
const COMPANY = 2;

// --- Shared SQL fragments -------------------------------------------------
// `p` is the table alias prefix ('uc.' or '') so one definition serves every
// query and the band/group mappings can never drift between drilldowns.

const BAND = (p = 'uc.') => `CASE
        WHEN ${p}bandid::text = '1' THEN 'B1'
        WHEN ${p}bandid::text = '2' THEN 'B2'
        WHEN ${p}bandid::text = '3' THEN 'B3'
        WHEN ${p}bandid::text = '4' THEN 'B4'
        WHEN ${p}bandid::text = '5' THEN 'B5'
        ELSE NULL
    END AS "Band"`;

const GROUPS = (p = 'uc.') => `CASE
        WHEN ${p}groupid = 100008 THEN 'Global Operations'
        WHEN ${p}groupid = 100009 THEN 'Support'
        WHEN ${p}groupid = 100010 THEN 'Product'
        WHEN ${p}groupid = 100011 THEN 'CustomerNext'
        WHEN ${p}groupid = 100012 THEN 'Customer Success Management (CSM)'
        WHEN ${p}groupid = 100013 THEN 'Delivery Services Group (DSG)'
        WHEN ${p}groupid = 100014 THEN 'Delivery Services Group (DSG) - US'
        WHEN ${p}groupid = 100015 THEN 'Sales and Marketing'
        WHEN ${p}groupid = 100016 THEN 'Product Incubation Center (PIC)'
        WHEN ${p}groupid = 100017 THEN 'People Enablement'
        WHEN ${p}groupid = 100018 THEN 'Central Business Group'
        WHEN ${p}groupid = 100019 THEN 'CSG'
        WHEN ${p}groupid = 100020 THEN 'Delivery Services Group (DSG) - CUSTOMER_REDACTED'
        WHEN ${p}groupid = 100021 THEN 'Key Account Management (KAM)'
        WHEN ${p}groupid = 100022 THEN 'Finance'
        WHEN ${p}groupid = 0 THEN 'Owner'
        WHEN ${p}groupid = 100023 THEN 'Managed Solutions'
        ELSE NULL
    END AS "Groups"`;

// Every drilldown returns the same five columns.
const DRILL_COLUMNS = [
  { key: 'Name', label: 'Name', type: 'text' },
  { key: 'Loginid', label: 'Login ID', type: 'text' },
  { key: 'Designation', label: 'Designation', type: 'text' },
  { key: 'Band', label: 'Band', type: 'text' },
  { key: 'Groups', label: 'Group', type: 'text' },
];

const noLoginSince = (interval) => `uc.isactive = 1
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.loggedinuser logg
      WHERE logg.userid = uc.userid
        AND logg.logindate >= CURRENT_DATE - INTERVAL '${interval}'
  )`;

// Drilldowns over dbo.usercontact differ only in their WHERE clause. Deriving
// countSql from the same body guarantees the modal's total can never disagree
// with the rows it lists.
const userDrilldown = (key, title, where) => ({
  key,
  metricKey: key,
  title,
  columns: DRILL_COLUMNS,
  countSql: `SELECT COUNT(*) FROM dbo.usercontact uc WHERE ${where};`,
  listSql: `SELECT
    uc.username AS "Name",
    uc.email AS "Loginid",
    uc.title AS "Designation",
    ${BAND()},
    ${GROUPS()}
FROM dbo.usercontact uc
WHERE ${where}
ORDER BY uc.username, uc.userid
LIMIT {{limit}} OFFSET {{offset}};`,
});

// External portal accounts: a real email address that is not one of ours.
const CUSTOMER_WHERE = `loginid IS NOT NULL
  AND loginid NOT ILIKE '%crmnext.com%'
  AND loginid NOT ILIKE '%businessnext.com%'
  AND loginid NOT ILIKE '%crmnext.in%'
  AND loginid NOT ILIKE '%gmail.com%'
  AND loginid ILIKE '%@%'
  AND loginid ILIKE '%.com%'
  AND appownerid = ${COMPANY}`;

const CUSTOMER_JOIN_WHERE = CUSTOMER_WHERE.replace(/\b(loginid|appownerid)\b/g, 'az.$1');

export default {
  id: 'users',
  title: 'User Data Audit',
  shortTitle: 'Users',
  icon: 'users',
  status: 'active',
  description:
    'User access audit: total users, active/inactive status, login recency, and customer portal usage.',
  entityLabel: 'users',

  metrics: [
    {
      key: 'total_users',
      label: 'Total Users',
      tone: 'blue',
      group: 'volume',
      description: 'All users in the system (companyid = 2)',
      drilldown: 'total_users',
      sql: `SELECT COUNT(*) FROM dbo.usercontact WHERE companyid = ${COMPANY};`,
    },
    {
      key: 'active_users',
      label: 'Active Users',
      tone: 'green',
      group: 'volume',
      pctOf: 'total_users',
      description: 'Users marked as active (companyid = 2)',
      drilldown: 'active_users',
      sql: `SELECT COUNT(*) FROM dbo.usercontact WHERE isactive = 1 AND companyid = ${COMPANY};`,
    },
    {
      key: 'inactive_users',
      label: 'Inactive Users',
      tone: 'red',
      group: 'volume',
      pctOf: 'total_users',
      description: 'Users marked as inactive (companyid = 2)',
      drilldown: 'inactive_users',
      sql: `SELECT (SELECT COUNT(*) FROM dbo.usercontact WHERE companyid = ${COMPANY})
     - (SELECT COUNT(*) FROM dbo.usercontact WHERE isactive = 1 AND companyid = ${COMPANY})
     AS "inactive user";`,
    },
    {
      key: 'no_login_3m',
      label: 'No Login 3 Months',
      tone: 'orange',
      group: 'issue',
      description: 'Active users with no login in 3 months (all companies)',
      issue: true,
      severity: 'warning',
      action: 'Review',
      category: 'Inactivity',
      issueLabel: 'Active users not accessing system for 3+ months',
      remediation: 'Contact users to confirm continued access needs or deactivate if unused.',
      drilldown: 'no_login_3m',
      sql: `SELECT COUNT(*) FROM dbo.usercontact uc WHERE ${noLoginSince('3 months')};`,
    },
    {
      key: 'no_login_6m',
      label: 'No Login 6 Months',
      tone: 'red',
      group: 'issue',
      description: 'Active users with no login in 6 months (all companies)',
      issue: true,
      severity: 'critical',
      action: 'Deactivate',
      category: 'Dormancy',
      issueLabel: 'Long-dormant user accounts',
      remediation: 'Deactivate inactive accounts and reclaim licenses after management approval.',
      drilldown: 'no_login_6m',
      sql: `SELECT COUNT(*) FROM dbo.usercontact uc WHERE ${noLoginSince('6 months')};`,
    },
    {
      key: 'customer_portal_users',
      label: 'Customer Users',
      tone: 'sky',
      group: 'volume',
      description: 'Total external customers accessing the portal',
      drilldown: 'customer_portal_users',
      sql: `SELECT COUNT(loginid) AS total_count FROM dbo.az_user WHERE ${CUSTOMER_WHERE};`,
    },
  ],

  // Record-level drilldowns. {{limit}}/{{offset}} are replaced by
  // server-clamped integers — never raw request input.
  drilldowns: {
    total_users: userDrilldown('total_users', 'All Users', `uc.companyid = ${COMPANY}`),

    active_users: userDrilldown(
      'active_users',
      'Active Users',
      `uc.isactive = 1 AND uc.companyid = ${COMPANY}`,
    ),

    inactive_users: userDrilldown(
      'inactive_users',
      'Inactive Users',
      `uc.isactive = 0 AND uc.companyid = ${COMPANY}`,
    ),

    no_login_3m: userDrilldown(
      'no_login_3m',
      'Active Users With No Login in 3 Months',
      noLoginSince('3 months'),
    ),

    no_login_6m: userDrilldown(
      'no_login_6m',
      'Active Users With No Login in 6 Months',
      noLoginSince('6 months'),
    ),

    customer_portal_users: {
      key: 'customer_portal_users',
      metricKey: 'customer_portal_users',
      title: 'External Customer Portal Accounts',
      columns: DRILL_COLUMNS,
      countSql: `SELECT COUNT(*)
FROM dbo.az_user az
INNER JOIN dbo.usercontact uc
    ON uc.userid = az.userid
   AND uc.companyid = ${COMPANY}
WHERE ${CUSTOMER_JOIN_WHERE};`,
      listSql: `SELECT
    uc.username AS "Name",
    az.loginid AS "Loginid",
    uc.title AS "Designation",
    ${BAND()},
    ${GROUPS()}
FROM dbo.az_user az
INNER JOIN dbo.usercontact uc
    ON uc.userid = az.userid
   AND uc.companyid = ${COMPANY}
WHERE ${CUSTOMER_JOIN_WHERE}
ORDER BY az.loginid, az.userid
LIMIT {{limit}} OFFSET {{offset}};`,
    },
  },
};
