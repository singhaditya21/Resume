// Planned module stub — see opportunity.js for the active-module shape.
export default {
  id: 'activity',
  title: 'Activity Data Audit',
  shortTitle: 'Activities',
  icon: 'calendar-clock',
  status: 'planned',
  description:
    'Task, call, and meeting hygiene: overdue backlog, orphaned activities, and logging discipline.',
  entityLabel: 'activities',
  plannedChecks: [
    { category: 'Inactivity', check: 'Open activities overdue beyond 30 / 90 days' },
    { category: 'Relationship', check: 'Activities not linked to any lead, account, or opportunity' },
    { category: 'Completeness', check: 'Activities missing type, outcome, or notes' },
    { category: 'Usage', check: 'Activity logging rate per team / per user' },
    { category: 'Cleanup', check: 'Ancient completed activities eligible for archive' },
  ],
};
