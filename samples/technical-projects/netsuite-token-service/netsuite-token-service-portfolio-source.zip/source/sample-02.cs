using Acidaes.Netsuite.Api.Services;

namespace Acidaes.Netsuite.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Log the current environment for debugging
            Console.WriteLine($"Environment: {builder.Environment.EnvironmentName}");

            SetupLogging(builder);

            builder.WebHost.UseKestrel(options => options.AddServerHeader = false);

            var applicationPathBase = AddPathBaseFilter(builder);

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Register the TokenService and IHttpClientFactory for dependency injection
            builder.Services.AddHttpClient(); // Registers IHttpClientFactory
            builder.Services.AddScoped<ITokenService, TokenService>();

            var app = builder.Build();

            if (!string.IsNullOrWhiteSpace(applicationPathBase))
                app.UsePathBase(applicationPathBase);

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }

        private static void SetupLogging(WebApplicationBuilder builder)
        {
            var enableConsoleLogging = builder.Configuration.GetValue<bool>("AppSettings:EnableConsoleLogging");

            builder.Logging.ClearProviders();

            if (enableConsoleLogging)
                builder.Logging.AddConsole();

            builder.Logging.AddDebug();
        }

        static string AddPathBaseFilter(WebApplicationBuilder builder)
        {
            // Fetch the PathBaseSettings section from configuration
            var config = builder.Configuration.GetSection("PathBaseSettings");

            // Bind the config section to PathBaseSettings using IOptions
            builder.Services.Configure<PathBaseSettings>(config);

            // Register the startup filter
            builder.Services.AddTransient<IStartupFilter, PathBaseStartupFilter>();

            return config.GetValue<string>("ApplicationPathBase") ?? string.Empty;
        }
    }
}
