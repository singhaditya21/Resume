namespace Acidaes.Netsuite.Api.Services;

public interface ITokenService
{
    Task<string> GenerateTokenAsync();
}