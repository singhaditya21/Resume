using System.Text;

namespace Acidaes.Netsuite.Api.Services;

public static class NetSuiteConfigurationHelper
{
    private static readonly HashSet<string> NonEncodedKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "TokenUrl"
    };

    public static string GetValue(IConfiguration configuration, string key)
    {
        var fullKey = $"NetSuite:{key}";
        var value = configuration[fullKey]
            ?? throw new InvalidOperationException($"{fullKey} not configured");

        return NonEncodedKeys.Contains(key) ? value : DecodeBase64(value);
    }

    private static string DecodeBase64(string base64Value)
    {
        try
        {
            var bytes = Convert.FromBase64String(base64Value);
            return Encoding.UTF8.GetString(bytes);
        }
        catch (FormatException ex)
        {
            throw new InvalidOperationException("Invalid Base64 configuration value", ex);
        }
    }
}