﻿using Microsoft.Extensions.Options;

namespace Acidaes.Netsuite.Api
{
    public class PathBaseStartupFilter(IOptions<PathBaseSettings> options) : IStartupFilter
    {
        private readonly string _pathBase = options.Value.ApplicationPathBase ?? string.Empty;

        public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next)
        {
            return app =>
            {
                app.UsePathBase(_pathBase);
                next(app);
            };
        }
    }
    public class PathBaseSettings
    {
        public string? ApplicationPathBase { get; set; }
    }
}
