using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text.Json;

namespace Acidaes.Netsuite.Api.Services
{
    public class TokenService(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<TokenService> logger) : ITokenService
    {
        private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
        private readonly IConfiguration _configuration = configuration;
        private readonly ILogger<TokenService> _logger = logger;
        private static readonly string[] Scopes = ["restlets", "rest_webservices"];

        public async Task<string> GenerateTokenAsync()
        {
            _logger.LogInformation("Starting token generation");

            var kid = NetSuiteConfigurationHelper.GetValue(_configuration, "KID");
            var consumerKey = NetSuiteConfigurationHelper.GetValue(_configuration, "ConsumerKey");
            var tokenUrl = NetSuiteConfigurationHelper.GetValue(_configuration, "TokenUrl"); // Not decoded

            _logger.LogDebug("Configuration loaded - KID: {Kid}, TokenUrl: {TokenUrl}", kid, tokenUrl);

            var jwtHeader = new JwtHeader(
                new SigningCredentials(
                    new RsaSecurityKey(GetPrivateKey()),
                    SecurityAlgorithms.RsaSsaPssSha256))
            {
                ["kid"] = kid
            };

            var jwtPayload = new JwtPayload
            {
                { "iss", consumerKey },
                { "scope", Scopes },
                { "iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
                { "exp", DateTimeOffset.UtcNow.AddHours(1).ToUnixTimeSeconds() },
                { "aud", tokenUrl }
            };

            var jwtToken = new JwtSecurityToken(jwtHeader, jwtPayload);
            var signedJWT = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            _logger.LogDebug("JWT token created and signed");

            try
            {
                var result = await GetTokenAsync(signedJWT, tokenUrl);
                _logger.LogInformation("Token generation completed successfully");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve token from NetSuite");
                throw;
            }
        }

        private RSA GetPrivateKey()
        {
            _logger.LogDebug("Loading private key from configuration");

            var privateKeyPEM = NetSuiteConfigurationHelper.GetValue(_configuration, "PrivateKeyPEM");

            _logger.LogDebug("Private key PEM length: {Length} characters", privateKeyPEM.Length);

            var rsa = RSA.Create();
            rsa.ImportFromPem(privateKeyPEM.ToCharArray());

            _logger.LogDebug("Private key loaded successfully");

            return rsa;
        }

        private async Task<string> GetTokenAsync(string clientAssertion, string tokenUrl)
        {
            _logger.LogDebug("Sending token request to {TokenUrl}", tokenUrl);

            var client = _httpClientFactory.CreateClient();
            using var request = new HttpRequestMessage(HttpMethod.Post, tokenUrl);

            var collection = new List<KeyValuePair<string, string>>
            {
                new("grant_type", "client_credentials"),
                new("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"),
                new("client_assertion", clientAssertion)
            };

            request.Content = new FormUrlEncodedContent(collection);

            var response = await client.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogWarning("Token request failed with status {StatusCode}: {Error}",
                    response.StatusCode, errorContent);
            }

            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();
            using var tokenObject = JsonDocument.Parse(responseBody);

            var result = new
            {
                access_token = REDACTED_SECRET
                expires_in = tokenObject.RootElement.GetProperty("expires_in").GetString(),
                token_type = REDACTED_SECRET
            };

            _logger.LogDebug("Token received - Type: {TokenType}, ExpiresIn: {ExpiresIn}",
                result.token_type, result.expires_in);

            return JsonSerializer.Serialize(result);
        }
    }
}