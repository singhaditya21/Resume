﻿using Acidaes.Netsuite.Api.Models;
using Acidaes.Netsuite.Api.Services;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Acidaes.Netsuite.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HomeController(
    ITokenService tokenService,
    IHttpClientFactory httpClientFactory,
    ILogger<HomeController> logger) : ControllerBase
{
    private readonly ITokenService _tokenService = tokenService;
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly ILogger<HomeController> _logger = logger;

    [HttpGet("health-check")]
    public IActionResult HealthCheck()
    {
        var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        _logger.LogDebug("Health check requested - Environment: {Environment}", environment);
        return Ok($"Netsuite Api is live and running in {environment} mode.");
    }

    [HttpPost("get-token")]
    [HttpGet("get-token")]
    public async Task<IActionResult> GetJWTToken()
    {
        _logger.LogInformation("Token generation requested");

        try
        {
            var signedJWT = await _tokenService.GenerateTokenAsync();
            _logger.LogInformation("Token generated successfully");
            return Content(signedJWT, "application/json");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to generate JWT token");
            return StatusCode(500, new { message = ex.Message });
        }
    }

    [HttpPost("NetSuite-ApiWrapper")]
    public async Task<IActionResult> Post([FromBody] ApiRequestModel requestModel)
    {
        _logger.LogInformation("NetSuite API request - Method: {Method}, URL: {Url}",
            requestModel.APIMethod ?? "POST", requestModel.APIURL);

        var bearerToken = Request.Headers.Authorization.ToString().Replace("Bearer ", "");
        var client = _httpClientFactory.CreateClient("NetSuiteClient");

        try
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
            client.DefaultRequestHeaders.Add("Prefer", "Transient");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var jsonBody = JsonSerializer.Serialize(requestModel.JSONAPIBODY);
            using var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

            _logger.LogDebug("Sending request to NetSuite API");

            var response = requestModel.APIMethod?.ToUpperInvariant() switch
            {
                "PUT" => await client.PutAsync(requestModel.APIURL, content),
                _ => await client.PostAsync(requestModel.APIURL, content)
            };

            var responseContent = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("NetSuite API request succeeded - StatusCode: {StatusCode}",
                    (int)response.StatusCode);

                if (response.Headers.Location != null)
                {
                    var location = response.Headers.Location.ToString()
                        .Replace(requestModel.APIURL + "/", string.Empty);
                    _logger.LogDebug("Response location: {Location}", location);
                    return Ok(new { Location = location });
                }
                return Ok(responseContent);
            }

            _logger.LogWarning("NetSuite API request failed - StatusCode: {StatusCode}, Reason: {Reason}",
                (int)response.StatusCode, response.ReasonPhrase);

            return StatusCode((int)response.StatusCode,
                $"Error: {(int)response.StatusCode} - {response.ReasonPhrase}. Response: {responseContent}");
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP request to NetSuite API failed");
            return StatusCode(500, $"Request error: {ex.Message}");
        }
    }
}