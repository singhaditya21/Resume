import { z } from "zod";
import { createBlock, DEFAULT_GLOBAL_STYLES } from "./defaults";
import { sanitizeHtml, stripHtml } from "./sanitize";

const alignmentSchema = z.enum(["left", "center", "right"]);
const hexOrCssColor = z.string().min(1).max(80);
const cssSize = z.string().min(1).max(80);

const headerBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("header"),
  content: z.object({
    logoUrl: z.string().default(""),
    logoAlt: z.string().default(""),
    companyName: z.string().default(""),
    logoLink: z.string().default(""),
  }),
  styles: z.object({
    backgroundColor: hexOrCssColor,
    padding: cssSize,
    alignment: alignmentSchema,
    logoAlignment: alignmentSchema.optional(),
    companyNameAlignment: alignmentSchema.optional(),
    logoHeight: z.number().min(1).max(240),
    logoWidth: z.number().min(1).max(240).optional(),
    companyNameSize: z.number().min(1).max(80),
    companyNameColor: hexOrCssColor,
    companyNameWeight: z.string().min(1).max(20),
  }),
  behavior: z.object({ linkEnabled: z.boolean().default(true) }).default({ linkEnabled: true }),
});

const heroBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("hero"),
  content: z.object({
    imageUrl: z.string().default(""),
    imageAlt: z.string().default(""),
    headline: z.string().default(""),
    subheadline: z.string().default(""),
    overlayText: z.boolean().optional().default(false),
  }),
  styles: z.object({
    backgroundColor: hexOrCssColor,
    padding: cssSize,
    headlineSize: z.number().min(1).max(96),
    headlineColor: hexOrCssColor,
    headlineWeight: z.string().min(1).max(20),
    subheadlineSize: z.number().min(1).max(64),
    subheadlineColor: hexOrCssColor,
    subheadlineWeight: z.string().min(1).max(20),
    imageHeight: z.number().min(1).max(900),
    imageBorderRadius: z.number().min(0).max(80),
    textAlignment: alignmentSchema,
  }),
  behavior: z.record(z.never()).optional().default({}),
});

const textBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("text"),
  content: z.object({
    html: z.string().default(""),
    plainText: z.string().default(""),
  }),
  styles: z.object({
    fontSize: z.number().min(1).max(80),
    lineHeight: z.number().min(0.8).max(4),
    textColor: hexOrCssColor,
    linkColor: hexOrCssColor,
    alignment: alignmentSchema,
    padding: cssSize,
  }),
  behavior: z.record(z.never()).optional().default({}),
});

const buttonBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("button"),
  content: z.object({
    label: z.string().default(""),
    linkUrl: z.string().default(""),
    openInNewTab: z.boolean().default(true),
    preButtonText: z.string().default(""),
    postButtonText: z.string().default(""),
  }),
  styles: z.object({
    backgroundColor: hexOrCssColor,
    textColor: hexOrCssColor,
    fontSize: z.number().min(1).max(80),
    fontWeight: z.string().min(1).max(20),
    borderRadius: z.number().min(0).max(80),
    paddingVertical: z.number().min(0).max(80),
    paddingHorizontal: z.number().min(0).max(160),
    fullWidth: z.boolean(),
    alignment: alignmentSchema,
    hoverBackgroundColor: hexOrCssColor,
  }),
  behavior: z.object({
    injectSurveyLink: z.boolean().default(true),
    trackClicks: z.boolean().default(true),
  }).default({ injectSurveyLink: true, trackClicks: true }),
});

const dividerBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("divider"),
  content: z.object({
    lineStyle: z.enum(["solid", "dashed", "dotted", "none"]),
    label: z.string().default(""),
  }),
  styles: z.object({
    lineColor: hexOrCssColor,
    lineThickness: z.number().min(0).max(20),
    lineStyle: z.enum(["solid", "dashed", "dotted", "none"]),
    spacingAbove: z.number().min(0).max(160),
    spacingBelow: z.number().min(0).max(160),
    labelColor: hexOrCssColor,
    labelSize: z.number().min(1).max(80),
  }),
  behavior: z.record(z.never()).optional().default({}),
});

const socialLinkSchema = z.object({
  platform: z.enum(["website", "linkedin", "twitter", "facebook", "instagram", "youtube", "tiktok", "whatsapp", "telegram", "github"]),
  url: z.string().default(""),
});

const footerBlockSchema = z.object({
  id: z.string().min(1),
  type: z.literal("footer"),
  content: z.object({
    companyName: z.string().default(""),
    address: z.string().default(""),
    unsubscribeText: z.string().default(""),
    unsubscribeUrl: z.string().default(""),
    socialLinks: z.array(socialLinkSchema).default([]),
    legalText: z.string().default(""),
  }),
  styles: z.object({
    backgroundColor: hexOrCssColor,
    padding: cssSize,
    textColor: hexOrCssColor,
    fontSize: z.number().min(1).max(80),
    linkColor: hexOrCssColor,
    alignment: alignmentSchema,
    dividerAbove: z.boolean(),
    socialIconSize: z.number().min(1).max(80),
    socialIconColor: hexOrCssColor,
  }),
  behavior: z.record(z.never()).optional().default({}),
});

export const emailBlockSchema = z.discriminatedUnion("type", [
  headerBlockSchema,
  heroBlockSchema,
  textBlockSchema,
  buttonBlockSchema,
  dividerBlockSchema,
  footerBlockSchema,
]);

export const emailGlobalStylesSchema = z.object({
  backgroundColor: hexOrCssColor.default(DEFAULT_GLOBAL_STYLES.backgroundColor),
  contentBackgroundColor: hexOrCssColor.default(DEFAULT_GLOBAL_STYLES.contentBackgroundColor),
  fontFamily: z.string().min(1).max(200).default(DEFAULT_GLOBAL_STYLES.fontFamily),
  textColor: hexOrCssColor.default(DEFAULT_GLOBAL_STYLES.textColor),
  linkColor: hexOrCssColor.default(DEFAULT_GLOBAL_STYLES.linkColor),
  contentWidth: z.number().min(320).max(900).default(DEFAULT_GLOBAL_STYLES.contentWidth),
  borderRadius: z.number().min(0).max(60).default(DEFAULT_GLOBAL_STYLES.borderRadius),
  outerPadding: z.number().min(0).max(120).default(DEFAULT_GLOBAL_STYLES.outerPadding),
  innerPadding: z.number().min(0).max(120).default(DEFAULT_GLOBAL_STYLES.innerPadding),
});

export const trackingSettingsSchema = z.object({
  tracking: z.object({
    openTracking: z.boolean().default(false),
    clickTracking: z.boolean().default(true),
  }).default({ openTracking: false, clickTracking: true }),
});

export const emailTemplateDocumentSchema = z.object({
  id: z.number().optional(),
  name: z.string().trim().min(1, "Template name is required."),
  subject: z.string().trim().min(1, "Subject line is required."),
  preheader: z.string().default(""),
  blocks: z.array(emailBlockSchema).min(1, "At least one email block is required."),
  globalStyles: emailGlobalStylesSchema,
  settings: trackingSettingsSchema,
  isDefault: z.boolean().default(false),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
});

export const emailTemplateSaveSchema = z.object({
  // Persistence schema — it must NEVER block a save on advisory conditions.
  // Content completeness (name / subject / at least one block / CTA etc.) is
  // surfaced as non-blocking warnings in the UI, not enforced here. `name` is
  // coalesced to a fallback in normalizeEmailTemplateSavePayload so the NOT NULL
  // column is always satisfied.
  name: z.string().default("Untitled Template"),
  subject: z.string().default(""),
  preheader: z.string().optional().default(""),
  bodyHtml: z.string().nullable().optional(),
  bodyText: z.string().nullable().optional(),
  blocksJson: z.array(emailBlockSchema).default([]),
  globalStyles: emailGlobalStylesSchema,
  settings: trackingSettingsSchema,
  headerImageUrl: z.string().nullable().optional(),
  primaryColor: z.string().optional(),
  fontFamily: z.string().optional(),
  isDefault: z.boolean().optional().default(false),
});

export type EmailTemplateSavePayload = z.infer<typeof emailTemplateSaveSchema>;

const emailTemplateSaveInputSchema = z.object({
  name: z.string().trim().optional().default(""),
  subject: z.string().optional().default(""),
  preheader: z.string().optional().default(""),
  bodyHtml: z.string().nullable().optional(),
  bodyText: z.string().nullable().optional(),
  blocksJson: z.array(emailBlockSchema).optional().default([]),
  globalStyles: emailGlobalStylesSchema.partial().optional(),
  settings: trackingSettingsSchema.optional(),
  headerImageUrl: z.string().nullable().optional(),
  primaryColor: z.string().optional(),
  fontFamily: z.string().optional(),
  isDefault: z.boolean().optional().default(false),
});

function normalizeBlocksFromLegacyHtml(bodyHtml?: string | null, bodyText?: string | null) {
  if (!bodyHtml) return [];

  const textBlock = createBlock("text");
  const safeHtml = sanitizeHtml(bodyHtml);
  return [
    {
      ...textBlock,
      content: {
        ...textBlock.content,
        html: safeHtml,
        plainText: bodyText || stripHtml(safeHtml),
      },
    },
  ];
}

export function normalizeEmailTemplateSavePayload(input: unknown): EmailTemplateSavePayload {
  const raw = emailTemplateSaveInputSchema.parse(input);
  const blocksJson =
    raw.blocksJson.length > 0
      ? raw.blocksJson
      : normalizeBlocksFromLegacyHtml(raw.bodyHtml, raw.bodyText);

  return emailTemplateSaveSchema.parse({
    ...raw,
    name: raw.name && raw.name.trim() ? raw.name.trim() : "Untitled Template",
    subject: raw.subject,
    blocksJson,
    globalStyles: {
      ...DEFAULT_GLOBAL_STYLES,
      ...(raw.globalStyles || {}),
    },
    settings: raw.settings || { tracking: { openTracking: false, clickTracking: true } },
  });
}
