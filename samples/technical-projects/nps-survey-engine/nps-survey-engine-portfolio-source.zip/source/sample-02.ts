import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  jsonb,
  integer,
  uniqueIndex,
  varchar,
  primaryKey,
} from "drizzle-orm/pg-core";

// ── RBAC: Roles ──────────────────────────────────────────────────────────────
// DB-backed configurable roles (RBAC Solution doc §4.1). `isImmutable` guards
// Owner; `isSignupDefault` marks the single role auto-assigned to self-service
// registrations (partial unique index enforced in the migration). `updatedAt`
// doubles as a cache-bust stamp for the permission cache in lib/authz.ts.
export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  isSystem: boolean("is_system").notNull().default(false),
  isImmutable: boolean("is_immutable").notNull().default(false),
  isSignupDefault: boolean("is_signup_default").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ── RBAC: Users ──────────────────────────────────────────────────────────────
// Per-user accounts (doc §4.1/§6.2). Email stored lowercase. `status` is the
// account lifecycle (unverified | pending | active | invited | suspended |
// rejected); only `active` accounts can obtain a session. `tokenVersion`
// bumps to revoke all outstanding sessions. `passwordHash` is null for the
// bootstrap break-glass Owner (which authenticates via the env admin key).
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"),
  name: text("name"),
  roleId: integer("role_id").references(() => roles.id),
  status: text("status").notNull().default("pending"),
  isActive: boolean("is_active").notNull().default(false),
  mustResetPassword: boolean("must_reset_password").notNull().default(false),
  tokenVersion: integer("token_version").notNull().default(0),
  failedLoginCount: integer("failed_login_count").notNull().default(0),
  lockedUntil: timestamp("locked_until"),
  activatedBy: integer("activated_by"),
  activatedAt: timestamp("activated_at"),
  createdAt: timestamp("created_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
});

// ── RBAC: Permission catalog ─────────────────────────────────────────────────
// Seeded from src/lib/permissions.ts by the run-migration route; additive.
export const permissions = pgTable("permissions", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g. "survey:delete"
  description: text("description"),
  category: text("category"),
});

// ── RBAC: Role ↔ Permission grants ───────────────────────────────────────────
// One UI checkbox toggle = one insert/delete here.
export const rolePermissions = pgTable(
  "role_permissions",
  {
    roleId: integer("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "cascade" }),
    permissionId: integer("permission_id")
      .notNull()
      .references(() => permissions.id, { onDelete: "cascade" }),
  },
  (table) => {
    return {
      pk: primaryKey({ columns: [table.roleId, table.permissionId] }),
    };
  },
);

// ── RBAC: Survey sharing ─────────────────────────────────────────────────────
// Explicit per-survey collaboration (doc §4.1); composes with the caller's
// role. `access` is "viewer" | "editor".
export const surveyCollaborators = pgTable(
  "survey_collaborators",
  {
    surveyId: integer("survey_id")
      .notNull()
      .references(() => surveys.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    access: text("access").notNull().default("viewer"),
    grantedBy: integer("granted_by"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => {
    return {
      pk: primaryKey({ columns: [table.surveyId, table.userId] }),
    };
  },
);

// ── RBAC: Audit log ──────────────────────────────────────────────────────────
// Covers user.self_register / user.email_verified / user.activate /
// user.reject / role changes etc. (doc §4.1). Also backs the register
// rate-limiter's per-IP window counts.
export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  actorUserId: integer("actor_user_id"),
  action: text("action").notNull(),
  resourceType: text("resource_type"),
  resourceId: text("resource_id"),
  metadata: jsonb("metadata"),
  ip: text("ip"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ── Email Templates ──────────────────────────────────────────────────────────
// Reusable rich-text email templates for survey distribution.
export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subject: text("subject"),
  preheader: text("preheader"), // Inbox preview text shown before opening
  bodyHtml: text("body_html"), // Legacy rich text HTML (used by old editor)
  bodyText: text("body_text"), // Legacy plain text fallback
  blocksJson: jsonb("blocks_json"), // Block-based builder: array of EmailBlock objects
  globalStyles: jsonb("global_styles"), // Block-based builder: EmailGlobalStyles object
  settings: jsonb("settings"), // Block-based builder: { tracking: { openTracking, clickTracking } }
  headerImageUrl: text("header_image_url"),
  primaryColor: text("primary_color").default("#E81F76"),
  fontFamily: text("font_family").default("Inter, Arial, sans-serif"),
  isDefault: boolean("is_default").default(false),
  /**
   * Audience this template is designed for. "respondent" (the default) is the
   * survey email sent to people filling the survey. "alert" templates are
   * authored for admin-facing alert messages and use a different token
   * namespace (nps.score, trigger.*, insight.*). Old rows default to
   * "respondent" so nothing existing breaks.
   */
  kind: text("kind").default("respondent"),
  // RBAC ownership (doc §4.2): SET NULL so deleting a user never destroys
  // their templates — an admin reassigns instead. Backfilled to the bootstrap
  // Owner by the migration.
  createdBy: integer("created_by").references(() => users.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  // RBAC ownership (doc §4.2)
  createdBy: integer("created_by").references(() => users.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const surveys = pgTable("surveys", {
  id: serial("id").primaryKey(),
  // Opaque, unguessable public identifier used in every survey URL (/s/<token>
  // and admin ?id=<token>). The numeric `id` stays internal-only. Backfilled for
  // existing rows via the run-migration route, generated on create.
  publicToken: text("public_token").notNull().unique(),
  // RBAC ownership (doc §4.2): "surveys I can see" = created_by = me OR a
  // survey_collaborators row OR my role holds survey:read:all. SET NULL so
  // deleting a user never destroys their surveys. Backfilled to the
  // bootstrap Owner by the migration.
  createdBy: integer("created_by").references(() => users.id, {
    onDelete: "set null",
  }),
  folderId: integer("folder_id").references(() => folders.id),
  isActive: boolean("is_active").default(true),
  isTemplate: boolean("is_template").default(false),
  isWorkflow: boolean("is_workflow").default(true), // Phase 2: Enables Node map
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").default("draft"), // 'draft', 'published'
  activationDate: timestamp("activation_date"),
  expiresAt: timestamp("expires_at"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  theme: jsonb("theme"),
  workflow: jsonb("workflow"), // Stores { nodes: [], edges: [], startNodeId: '' }
  views: integer("views").default(0), // True view tracking
  /**
   * Submission rule — when true, the same tracked respondent may submit the
   * survey multiple times and each submission counts as a separate response.
   * Default false matches the legacy behaviour (the public response page's
   * "Already Completed" check fires on the second submission). Configurable
   * via the builder Settings tab.
   */
  allowMultipleResponses: boolean("allow_multiple_responses").default(false),
  /**
   * Submission rule — when true, the public Thank-You page renders a
   * "Download response as PDF" button after a successful submission. The
   * server-side PDF endpoint (/api/responses/[id]/pdf) gates on this flag too
   * so respondents on long-lived sessions can't bypass it. Default false
   * keeps the legacy Thank-You behaviour.
   */
  allowResponsePdf: boolean("allow_response_pdf").default(false),
  /**
   * Submission rule — when true, respondents may navigate back to
   * previously-answered questions and edit their answers, including across
   * resumed sessions. Default false keeps the legacy forward-only behaviour.
   */
  allowBacktracking: boolean("allow_backtracking").default(false),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id").references(() => surveys.id, {
    onDelete: "cascade",
  }),
  type: text("type").notNull(), // 'text', 'multiple_choice', 'opinion_scale'
  title: text("title").notNull(),
  config: jsonb("config"), // JSON configuration for options, min/max, layout
  order: integer("order").default(0),
});

export const responses = pgTable(
  "responses",
  {
    id: serial("id").primaryKey(),
    surveyId: integer("survey_id").references(() => surveys.id, {
      onDelete: "cascade",
    }),
    respondentId: text("respondent_id"), // Optional tracking
    startedAt: timestamp("started_at").defaultNow(),
    submittedAt: timestamp("submitted_at").defaultNow(),
    completedAt: timestamp("completed_at"),
    answers: jsonb("answers"), // Array of { questionId, answer }
    isCompleted: boolean("is_completed").default(false),
  },
  (table) => {
    return {
      surveyRespondentIdx: uniqueIndex("survey_respondent_idx").on(
        table.surveyId,
        table.respondentId,
      ),
    };
  },
);

export const emailDistributions = pgTable("email_distributions", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id").references(() => surveys.id, {
    onDelete: "cascade",
  }),
  emailAddress: text("email_address").notNull(),
  trackingToken: text("tracking_token").notNull().unique(), // UUID string
  status: text("status").default("SENT"), // 'QUEUED', 'SENT', 'OPENED', 'NUDGED', 'BOUNCED', 'FAILED'
  sentAt: timestamp("sent_at").defaultNow(),
  openedAt: timestamp("opened_at"),
  filledAt: timestamp("filled_at"),
  /**
   * When set in the future, the distribute API enqueues the send rather than
   * dispatching synchronously. A background worker (instrumentation.ts boot
   * hook) picks up due rows on each tick and posts them through the regular
   * SMTP path. Null means "send immediately" (the historical behaviour).
   */
  scheduledFor: timestamp("scheduled_for"),
  /** Optional admin-supplied subject for scheduled sends. */
  scheduledSubject: text("scheduled_subject"),
  /** Optional admin-supplied recipient name for personalisation. */
  recipientName: text("recipient_name"),
  /** Email template chosen at distribution time, if any. */
  emailTemplateId: integer("email_template_id"),
  /** Last delivery error when status='FAILED'. */
  lastError: text("last_error"),
});

// ── Save & Resume ────────────────────────────────────────────────────────────
// Allows respondents to save partial progress and resume later via a unique token.
// The token is generated client-side (crypto.randomUUID) and persisted in localStorage.
// Partial answers are stored as JSONB so the survey page can restore state exactly.
export const savedSessions = pgTable("saved_sessions", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id")
    .notNull()
    .references(() => surveys.id, { onDelete: "cascade" }),
  resumeToken: varchar("resume_token", { length: 64 }).notNull().unique(),
  currentNodeId: text("current_node_id"), // which node the respondent was on
  answers: jsonb("answers"), // partial answers map: { [nodeId]: value }
  visitHistory: jsonb("visit_history"), // array of visited node IDs for back-nav
  respondentEmail: text("respondent_email"), // optional email to send resume link
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  expiresAt: timestamp("expires_at"), // when this saved session expires
});

// ── Dashboards (Phase 5C) ────────────────────────────────────────────────────
// Per-survey reusable digest layouts. A dashboard is a named bundle of
// "widget" identifiers (e.g. ["nps", "responses", "completion"]) that a
// survey-digest alert can reference via its `dashboardId` parameter — so
// multiple digest schedules (Monday/Wednesday/Friday, Slack/email/exec
// digest…) share one definition of "what content goes in the body."
//
// Widget identifiers are stored as plain strings; the digest renderer keeps
// the whitelist (see lib/alerts/library.ts). Additive: digests without a
// dashboardId keep using the legacy includeNps/includeResponses/
// includeCompletion toggles unchanged.
export const dashboards = pgTable("dashboards", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id")
    .notNull()
    .references(() => surveys.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  widgetsJson: jsonb("widgets_json"), // string[] of widget identifiers
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ── Survey Alerts ────────────────────────────────────────────────────────────
// Per-survey alert configuration. Each row is one rule attached to one
// survey. `libraryKey` is set when the alert was added from the predefined
// library; null means a custom rule. `conditionJson` carries either the
// library entry's parameter overrides or, for custom rules, the full rule
// definition consumed by the evaluator.
//
// Channel is "email" in phase 1; later additions (slack, webhook, sms) live
// on the same row so a single rule can fan out to multiple destinations as
// the library grows.
export const surveyAlerts = pgTable("survey_alerts", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id")
    .notNull()
    .references(() => surveys.id, { onDelete: "cascade" }),
  libraryKey: text("library_key"),
  name: text("name"),
  event: text("event").notNull(), // e.g. "response.submitted"
  conditionJson: jsonb("condition_json"),
  channel: text("channel").notNull().default("email"),
  emailTemplateId: integer("email_template_id").references(
    () => emailTemplates.id,
    { onDelete: "set null" },
  ),
  recipientsJson: jsonb("recipients_json"), // JSON array of channel-specific recipients
  deliveryJson: jsonb("delivery_json"), // throttle / quiet hours / dedup settings
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ── Alert Dispatches (audit log) ─────────────────────────────────────────────
// One row per attempted alert delivery — the system of record for "did the
// alert actually go out, and where." Surfaces in the Recent Fires panel on
// each survey's Alerts tab and in the org-wide /admin/alerts overview.
export const alertDispatches = pgTable("alert_dispatches", {
  id: serial("id").primaryKey(),
  alertId: integer("alert_id")
    .notNull()
    .references(() => surveyAlerts.id, { onDelete: "cascade" }),
  surveyId: integer("survey_id")
    .notNull()
    .references(() => surveys.id, { onDelete: "cascade" }),
  responseId: integer("response_id").references(() => responses.id, {
    onDelete: "set null",
  }),
  triggerEvent: text("trigger_event").notNull(),
  channel: text("channel").notNull(),
  status: text("status").notNull().default("queued"), // queued | sent | failed
  errorMessage: text("error_message"),
  payloadSnapshot: jsonb("payload_snapshot"),
  dispatchedAt: timestamp("dispatched_at").defaultNow(),
});

// ── File Uploads ─────────────────────────────────────────────────────────────
// Tracks every file uploaded through a survey. Files are stored on the local
// filesystem under `uploads/` (relative to project root) and referenced by a
// unique storage key. This table provides metadata, access control, and audit.
export const uploads = pgTable("uploads", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id")
    .notNull()
    .references(() => surveys.id, { onDelete: "cascade" }),
  responseId: integer("response_id").references(() => responses.id, {
    onDelete: "set null",
  }),
  storageKey: text("storage_key").notNull().unique(), // e.g. "survey_5/a1b2c3-file.pdf"
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  uploadedBy: text("uploaded_by"), // respondentId or trackingToken
  createdAt: timestamp("created_at").defaultNow(),
});
