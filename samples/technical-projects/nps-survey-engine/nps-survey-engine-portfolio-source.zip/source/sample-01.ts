// ─────────────────────────────────────────────────────────────────────────────
// NPS Engine — Pure computation layer for Net Promoter Score analytics.
//
// This module is fully self-contained: it imports only from the database layer
// (`@/db` and `@/db/schema`) and has zero React / Next.js dependencies.
// ─────────────────────────────────────────────────────────────────────────────

import { db } from "@/db";
import { responses, questions } from "@/db/schema";
import { eq, and, gte, desc } from "drizzle-orm";

// ── Types ────────────────────────────────────────────────────────────────────

/** The three standard NPS respondent categories. */
export type NpsCategory = "promoter" | "passive" | "detractor";

/** Computed NPS metrics for a single question within a survey. */
export interface NpsMetrics {
  surveyId: number;
  questionId: number;
  totalResponses: number;
  promoters: number;
  passives: number;
  detractors: number;
  /** -100 to +100 (rounded to nearest integer), or `null` when no responses. */
  npsScore: number | null;
  /** Percentage of promoters (0–100, one decimal place). */
  promoterPercent: number;
  /** Percentage of passives (0–100, one decimal place). */
  passivePercent: number;
  /** Percentage of detractors (0–100, one decimal place). */
  detractorPercent: number;
  updatedAt: Date;
}

/** A single data point in an NPS-over-time trend series. */
export interface NpsTrendPoint {
  /** Human-readable date label, e.g. "Apr 10". */
  date: string;
  /** NPS score for this day, or `null` when no valid responses. */
  npsScore: number | null;
  totalResponses: number;
}

// ── Internal Helpers ─────────────────────────────────────────────────────────

/**
 * Extract a numeric score from a raw answer value.
 *
 * Handles plain numbers, numeric strings, and group-rating-style objects
 * (where the value is a map of item-id → score and we return the average).
 *
 * Exported so the alerts subsystem coerces answers exactly the way the NPS
 * engine does — otherwise group_rating object answers (and numeric strings)
 * yield NaN under a naive Number() and the alert silently never fires.
 */
export function extractScore(raw: unknown): number | null {
  // Direct number
  if (typeof raw === "number" && Number.isFinite(raw)) {
    return raw;
  }

  // Numeric string
  if (typeof raw === "string") {
    const parsed = Number(raw);
    if (Number.isFinite(parsed)) return parsed;
  }

  // Object (group_rating): average all numeric values
  if (raw !== null && typeof raw === "object" && !Array.isArray(raw)) {
    const values = Object.values(raw as Record<string, unknown>);
    const nums = values
      .map((v) =>
        typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN,
      )
      .filter(Number.isFinite);
    if (nums.length > 0) {
      return nums.reduce((sum, n) => sum + n, 0) / nums.length;
    }
  }

  return null;
}

/** Return `true` when the score falls within the valid NPS range (0–10). */
function isValidNpsScore(score: number): boolean {
  return Number.isFinite(score) && score >= 0 && score <= 10;
}

/** Format a `Date` as a short label like "Apr 10". */
function formatDateShort(date: Date): string {
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ];
  return `${months[date.getMonth()]} ${date.getDate()}`;
}

/** Return an ISO date key (`YYYY-MM-DD`) for grouping responses by day. */
function toIsoDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// ── Exported Functions ───────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// 1. NPS Classification
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Classify a numeric score into an NPS category.
 *
 * The thresholds are the same regardless of whether the scale starts at 0 or 1:
 * - 9–10 → promoter
 * - 7–8  → passive
 * - 0–6  → detractor
 */
export function classifyNps(
  score: number,
  _startAtOne?: boolean,
): NpsCategory {
  if (score >= 9) return "promoter";
  if (score >= 7) return "passive";
  return "detractor";
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. Scale Validation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Validate whether a question's `config` represents an NPS-compatible scale.
 *
 * Recognised configurations:
 * - **opinion_scale**: uses `steps` + `startAtOne`
 *   - 0–10 (steps = 11, startAtOne = false) — standard ✅
 *   - 1–10 (steps = 10, startAtOne = true)  — accepted, with a warning
 * - **group_rating**: uses `maxRating` (10 or 11 accepted)
 */
export function isNpsCompatibleScale(
  config: unknown,
): { valid: boolean; warning?: string } {
  if (!config || typeof config !== "object") {
    return { valid: false, warning: "Question has no configuration." };
  }

  const cfg = config as Record<string, unknown>;
  const steps = cfg.steps as number | undefined;
  const startAtOne = cfg.startAtOne as boolean | undefined;
  const maxRating = cfg.maxRating as number | undefined;

  // ── opinion_scale style ────────────────────────────────────────────────
  if (steps !== undefined) {
    if (startAtOne) {
      if (steps === 10) {
        return {
          valid: true,
          warning:
            "Scale is 1–10. Standard NPS uses a 0–10 scale. Scores will " +
            "still be classified using standard NPS thresholds (0–6 detractor, " +
            "7–8 passive, 9–10 promoter).",
        };
      }
      return {
        valid: false,
        warning: `Scale is 1 to ${steps}. NPS requires a 0–10 or 1–10 scale.`,
      };
    }

    // startAtOne is false / undefined → scale starts at 0
    if (steps === 11) return { valid: true };
    if (steps === 10) {
      return {
        valid: true,
        warning:
          "Scale is 0–9. Standard NPS uses a 0–10 scale. A score of 10 " +
          "will never appear.",
      };
    }
    return {
      valid: false,
      warning: `Scale is 0 to ${steps}. NPS requires a 0–10 or 1–10 scale.`,
    };
  }

  // ── group_rating style ─────────────────────────────────────────────────
  if (maxRating !== undefined) {
    if (maxRating === 10 || maxRating === 11) return { valid: true };
    return {
      valid: false,
      warning: `Group rating max is ${maxRating}. NPS requires a 0–10 or 1–10 scale.`,
    };
  }

  return {
    valid: false,
    warning: "Unable to determine scale from question configuration.",
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. Compute NPS for a specific question (full recomputation)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Fully recompute NPS metrics for a single question within a survey.
 *
 * The function:
 * 1. Fetches every completed response for the survey.
 * 2. Extracts the answer stored under key `node_${questionDbId}`.
 * 3. Classifies each valid numeric score.
 * 4. Computes NPS = % promoters − % detractors (rounded to nearest integer).
 *
 * Returns `null` when there are no valid responses for the given question.
 */
export async function computeNpsForQuestion(
  surveyId: number,
  questionDbId: number,
): Promise<NpsMetrics | null> {
  // Fetch every completed response for this survey
  const surveyResponses = await db
    .select()
    .from(responses)
    .where(
      and(
        eq(responses.surveyId, surveyId),
        eq(responses.isCompleted, true),
      ),
    )
    .orderBy(desc(responses.submittedAt));

  // Extract valid numeric scores for this question
  const nodeKey = `node_${questionDbId}`;
  const validScores: number[] = [];

  for (const resp of surveyResponses) {
    const raw = resp.answers;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) continue;

    const answersMap = raw as Record<string, unknown>;
    const answer = answersMap[nodeKey];
    if (answer === undefined || answer === null) continue;

    const score = extractScore(answer);
    if (score === null || !isValidNpsScore(score)) continue;

    validScores.push(score);
  }

  if (validScores.length === 0) return null;

  // Classify scores
  let promoters = 0;
  let passives = 0;
  let detractors = 0;

  for (const score of validScores) {
    const cat = classifyNps(score);
    if (cat === "promoter") promoters++;
    else if (cat === "passive") passives++;
    else detractors++;
  }

  const total = validScores.length;

  return {
    surveyId,
    questionId: questionDbId,
    totalResponses: total,
    promoters,
    passives,
    detractors,
    npsScore: Math.round(
      (promoters / total) * 100 - (detractors / total) * 100,
    ),
    promoterPercent: Math.round((promoters / total) * 1000) / 10,
    passivePercent: Math.round((passives / total) * 1000) / 10,
    detractorPercent: Math.round((detractors / total) * 1000) / 10,
    updatedAt: new Date(),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. Compute NPS for all NPS-enabled questions in a survey
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute NPS metrics for every question in a survey that has
 * `config.isNpsDriver === true`.
 *
 * Scale compatibility is validated for each question and any warnings are
 * logged to the console (computation proceeds regardless).
 */
export async function computeNpsForSurvey(
  surveyId: number,
): Promise<NpsMetrics[]> {
  // Fetch all questions for this survey
  const surveyQuestions = await db
    .select()
    .from(questions)
    .where(eq(questions.surveyId, surveyId));

  // Keep only NPS-driver questions
  const npsQuestions = surveyQuestions.filter(
    (q) =>
      (q.config as Record<string, unknown> | null)?.isNpsDriver === true,
  );

  if (npsQuestions.length === 0) return [];

  const metrics: NpsMetrics[] = [];

  for (const q of npsQuestions) {
    // Validate scale — warn but don't skip
    const validation = isNpsCompatibleScale(q.config);
    if (!validation.valid) {
      console.warn(
        `[NPS Engine] Question ${q.id} ("${q.title}") has a non-standard ` +
          `scale: ${validation.warning}`,
      );
    }

    const result = await computeNpsForQuestion(surveyId, q.id);
    if (result) metrics.push(result);
  }

  return metrics;
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. Get the "global" NPS question for a survey
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Return the first question (by `order`) in the survey that has
 * `config.isNpsDriver === true`, or `null` when none exists.
 */
export async function getGlobalNpsQuestion(
  surveyId: number,
): Promise<{ questionId: number; questionTitle: string } | null> {
  const surveyQuestions = await db
    .select()
    .from(questions)
    .where(eq(questions.surveyId, surveyId));

  // Sort by `order` ascending so "first" is well-defined
  const sorted = surveyQuestions
    .slice()
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const npsQuestion = sorted.find(
    (q) =>
      (q.config as Record<string, unknown> | null)?.isNpsDriver === true,
  );

  if (!npsQuestion) return null;

  return {
    questionId: npsQuestion.id,
    questionTitle: npsQuestion.title,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. Trend data computation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute daily NPS trend for a specific question over a lookback window.
 *
 * Completed responses are grouped by their submission date (`submittedAt`,
 * falling back to `completedAt`) and NPS is calculated per day.
 * Days with no valid responses are omitted from the result.
 *
 * @param surveyId      The survey to analyse.
 * @param questionDbId  The database ID of the NPS question.
 * @param days          Lookback window in days (default 30).
 * @returns An array of trend points sorted chronologically (oldest first).
 */
export async function computeNpsTrend(
  surveyId: number,
  questionDbId: number,
  days: number = 30,
): Promise<NpsTrendPoint[]> {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  startDate.setHours(0, 0, 0, 0);

  // Fetch completed responses within the lookback window
  const surveyResponses = await db
    .select()
    .from(responses)
    .where(
      and(
        eq(responses.surveyId, surveyId),
        eq(responses.isCompleted, true),
        gte(responses.submittedAt, startDate),
      ),
    );

  // Group valid scores by calendar day
  const nodeKey = `node_${questionDbId}`;
  const dayBuckets = new Map<
    string,
    { date: Date; scores: number[] }
  >();

  for (const resp of surveyResponses) {
    const timestamp = resp.completedAt ?? resp.submittedAt;
    if (!timestamp) continue;

    const respDate = new Date(timestamp);

    const raw = resp.answers;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) continue;

    const answersMap = raw as Record<string, unknown>;
    const answer = answersMap[nodeKey];
    if (answer === undefined || answer === null) continue;

    const score = extractScore(answer);
    if (score === null || !isValidNpsScore(score)) continue;

    const isoKey = toIsoDateKey(respDate);
    if (!dayBuckets.has(isoKey)) {
      dayBuckets.set(isoKey, { date: respDate, scores: [] });
    }
    dayBuckets.get(isoKey)!.scores.push(score);
  }

  // Build trend points, sorted chronologically
  const sortedDays = [...dayBuckets.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  );

  const trend: NpsTrendPoint[] = [];

  for (const [, bucket] of sortedDays) {
    const { scores, date } = bucket;
    const total = scores.length;

    let promoters = 0;
    let detractors = 0;

    for (const s of scores) {
      const cat = classifyNps(s);
      if (cat === "promoter") promoters++;
      else if (cat === "detractor") detractors++;
    }

    trend.push({
      date: formatDateShort(date),
      npsScore:
        total > 0
          ? Math.round(
              (promoters / total) * 100 - (detractors / total) * 100,
            )
          : null,
      totalResponses: total,
    });
  }

  return trend;
}
