import React from 'react';
import { SideNavBar } from '@/components/layout/SideNavBar';
import { TopNavBar } from '@/components/layout/TopNavBar';
import { InsightsDashboardClient } from '@/components/dashboard/InsightsDashboardClient';
export default function InsightsPage() {
  return (
    <div className="bg-surface text-on-surface antialiased min-h-screen">
      <SideNavBar />
      <TopNavBar />

      <main className="ml-20 pt-24 px-12 pb-12 min-h-screen bg-surface" style={{ marginLeft: 80 }}>

        <InsightsDashboardClient />
      </main>
    </div>
  );
}
