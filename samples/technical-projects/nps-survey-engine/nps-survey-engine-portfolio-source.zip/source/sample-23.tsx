"use client";

import React, { Suspense } from "react";
import { SideNavBar } from "@/components/layout/SideNavBar";
import { TopNavBar } from "@/components/layout/TopNavBar";
import { EmailStudioShell } from "@/components/email-studio/EmailStudioShell";

function EmailStudioLoading() {
  return (
    <div className="flex h-full items-center justify-center bg-surface text-sm font-semibold text-on-surface-variant">
      Loading Email Studio...
    </div>
  );
}

export default function EmailStudioPage() {
  return (
    <div className="flex h-screen bg-surface" style={{ paddingLeft: 80 }}>
      <SideNavBar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopNavBar />
        <main className="mt-14 min-h-0 flex-1 overflow-hidden">
          <Suspense fallback={<EmailStudioLoading />}>
            <EmailStudioShell />
          </Suspense>
        </main>
      </div>
    </div>
  );
}
