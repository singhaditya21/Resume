import { NextResponse } from "next/server";
import { ADMIN_SESSION_COOKIE, shouldUseSecureAdminCookie } from "@/lib/adminAuth";
import { USER_SESSION_COOKIE } from "@/lib/session";

/**
 * Clears both session cookies (per-user sn_session + legacy admin_session).
 * On the proxy's public allowlist so a STALE cookie can still log out, and
 * uses shouldUseSecureAdminCookie() instead of the old hardcoded
 * secure:false (doc §8) so the clearing Set-Cookie matches the login one.
 */
export async function POST() {
  const response = NextResponse.json({ success: true });
  const flags = {
    httpOnly: true,
    secure: shouldUseSecureAdminCookie(),
    sameSite: "lax" as const,
    maxAge: 0,
    path: "/",
  };
  response.cookies.set(USER_SESSION_COOKIE, "", flags);
  response.cookies.set(ADMIN_SESSION_COOKIE, "", flags);
  return response;
}
