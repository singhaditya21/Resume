import { NextRequest, NextResponse } from "next/server";
import { listLibraryEntriesForApi } from "@/lib/alerts/library";
import { requirePermission } from "@/lib/authz";

// GET /api/alerts/library — Public-shape metadata for every predefined entry
// the admin UI can offer when adding an alert to a survey. evaluate()
// functions stay server-side.
export async function GET(req: NextRequest) {
  const guard = await requirePermission(req, "alert:read");
  if (!guard.ok) return guard.response;

  return NextResponse.json({ entries: listLibraryEntriesForApi() });
}
