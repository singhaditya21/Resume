"use client";
import React from 'react';
import { useBuilderStore } from '@/store/builderStore';

export function GlobalToast() {
    const globalToast = useBuilderStore((state) => state.globalToast);

    if (!globalToast) return null;

    return (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-5 fade-in duration-300">
            <div className="bg-[#111] text-white px-5 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-white/[0.08]">
                <span className="material-symbols-outlined text-emerald-400 text-[20px]">check_circle</span>
                <span className="font-semibold text-sm tracking-tight text-white/80">{globalToast}</span>
            </div>
        </div>
    );
}