"use client";

export { EmailPreviewPanel as PreviewPanel } from "./EmailPreviewPanel";
