import { NextResponse } from 'next/server';

// 1x1 transparent GIF base64 encoded
const TRANSPARENT_GIF = Buffer.from('REDACTED_OPAQUE_VALUE', 'base64');

export async function GET() {
    // Always respond with the transparent 1x1 image so the email client satisfies the image request
    return new NextResponse(TRANSPARENT_GIF, {
        headers: {
            'Content-Type': 'image/gif',
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0',
        },
    });
}
