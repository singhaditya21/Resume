import { redirect } from "next/navigation";

type EmailBuilderRedirectPageProps = {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
};

export default async function EmailBuilderRedirectPage({ searchParams }: EmailBuilderRedirectPageProps) {
  const params = await searchParams;
  const rawId = params?.id;
  const id = Array.isArray(rawId) ? rawId[0] : rawId;
  const target = id ? `/admin/email-studio?id=${encodeURIComponent(id)}` : "/admin/email-studio";

  redirect(target);
}
