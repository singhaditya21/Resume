/**
 * Whitelist of widget identifiers a Report Template (dashboards row) can
 * contain. Lives outside any Route Handler file so it can be imported from
 * the API routes *and* the renderer without violating Next.js's restriction
 * that Route Handler files only export handler functions + recognized
 * config keys.
 *
 * Each identifier maps to a renderable section in the digest body
 * (see lib/alerts/library.ts → SURVEY_DIGEST.evaluate). Adding a new widget
 * means: append it here, add a `render…Section` helper in library.ts, and
 * teach the digest evaluate() to branch on it.
 */

export const KNOWN_WIDGETS = ["nps", "responses", "completion"] as const;
export type DashboardWidget = (typeof KNOWN_WIDGETS)[number];
