/**
 * SurveyWorkflowEngine
 *
 * Enhanced runtime engine for executing workflow graphs.
 * Supports memoized lookups, priority-based edge resolution,
 * condition evaluation, cycle protection, and execution tracing.
 */

import { evaluateCondition, type EvaluationTrace } from "./conditionEvaluator";
import { executeAction, type ActionResult } from "./actionExecutor";

// ── Types ─────────────────────────────────────────────────────────────────────

export type WorkflowNodeType =
  | "start"
  | "end"
  | "question"
  | "logic_if"
  | "logic_switch"
  | "action_end_survey"
  | "action_redirect"
  | "action_tag"
  | "action_score"
  | "action_webhook"
  | "action_set_variable"
  | "merge"
  | "loop"
  | "random_split"
  // Legacy compat
  | "logic"
  | "action"
  | "message";

export interface WorkflowNode {
  id: string;
  type: WorkflowNodeType;
  position: { x: number; y: number };
  data: {
    label?: string;
    questionId?: string;
    questionType?: string;
    condition?: string;
    operator?: string;
    operand?: string;
    value?: string;
    branches?: { id: string; label: string; condition: string; value?: string }[];
    actionType?: string;
    actionValue?: string;
    config?: any;
    outputPorts?: string[];
    logicType?: string;
    scoreVariable?: string;
    scoreExpression?: string;
    // Compound conditions support
    conditions?: Array<{
      questionId: string;
      operator: string;
      value: string;
    }>;
    conditionLogic?: "AND" | "OR";
    // Loop support
    maxIterations?: number;
    // Random split support
    splitWeights?: number[];
    // Variable support
    variableName?: string;
    variableValue?: string;
  };
}

export interface WorkflowEdge {
  id: string;
  sourceId: string;
  targetId: string;
  sourcePort: string;
  label?: string;
  condition?: string;
  priority: number;
  // Legacy compat fields
  source?: string;
  target?: string;
  sourceHandle?: string;
  data?: {
    condition?: string;
    priority?: number;
  };
}

export interface WorkflowGraph {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  startNodeId: string | null;
}

export interface WorkflowState {
  answers: Record<string, any>;
  score: number;
  variables: Record<string, any>;
  currentQuestionNodeId?: string;
  /** Per-node loop iteration counter */
  loopIterations: Record<string, number>;
  /** Tags applied by action nodes during traversal */
  tags: string[];
  /** Actions executed during this walk (for debug) */
  actionLog: string[];
}

export interface StepTrace {
  nodeId: string;
  nodeType: string;
  answer?: any;
  edgesEvaluated: number;
  edgeTraces: EvaluationTrace[];
  selectedEdgeId: string | null;
  selectedTargetId: string | null;
  reason: string;
}

// ── Template Resolution (Phase 5c) ──────────────────────────────────────────

/** Resolve {{variable}} templates in a string using context values */
export function resolveTemplate(str: string, state: WorkflowState): string {
  return str.replace(/\{\{(\w+)\}\}/g, (_match, key: string) => {
    if (key in state.variables) return String(state.variables[key]);
    if (key in state.answers) return String(state.answers[key]);
    return _match;
  });
}

// ── Engine ─────────────────────────────────────────────────────────────────────

const MAX_WALK_DEPTH = 200;

export class SurveyWorkflowEngine {
  private graph: WorkflowGraph;
  private nodeMap: Map<string, WorkflowNode>;
  private outgoingEdgeMap: Map<string, WorkflowEdge[]>;
  private lastTrace: StepTrace | null = null;
  /**
   * Maps every known question identifier (builderQuestionId, DB id, workflow node id)
   * to the set of answer keys that may appear in WorkflowState.answers.
   * Built once at construction for O(1) deterministic lookups.
   */
  private questionLookupMap: Map<string, string[]>;

  constructor(graph: WorkflowGraph) {
    // Normalize edges to use sourceId/targetId consistently
    const normalizedEdges = (graph.edges || []).map((e) => ({
      ...e,
      sourceId: e.sourceId || e.source || "",
      targetId: e.targetId || e.target || "",
      sourcePort: e.sourcePort || e.sourceHandle || "default",
      condition: e.condition || e.data?.condition || "",
      priority: e.priority ?? e.data?.priority ?? 999,
    }));

    this.graph = { ...graph, edges: normalizedEdges };

    // Build memoized lookups
    this.nodeMap = new Map();
    for (const n of this.graph.nodes) {
      this.nodeMap.set(n.id, n);
    }

    this.outgoingEdgeMap = new Map();
    for (const e of this.graph.edges) {
      const list = this.outgoingEdgeMap.get(e.sourceId) || [];
      list.push(e);
      this.outgoingEdgeMap.set(e.sourceId, list);
    }

    // Build deterministic question lookup map
    // For each question node, map all its known identifiers to answer keys
    this.questionLookupMap = new Map();
    for (const n of this.graph.nodes) {
      if (n.type === "question") {
        const qId = n.data?.questionId;
        const keys: string[] = [];
        // The workflow node id itself
        keys.push(n.id);
        // The builderQuestionId / questionId
        if (qId) {
          keys.push(qId);
          keys.push(`node_${qId}`);
        }
        // Register all keys as lookup aliases
        const allAliases = [n.id, qId, qId ? `node_${qId}` : null].filter(Boolean) as string[];
        for (const alias of allAliases) {
          const existing = this.questionLookupMap.get(alias);
          if (existing) {
            // Merge without duplicates
            for (const k of keys) {
              if (!existing.includes(k)) existing.push(k);
            }
          } else {
            this.questionLookupMap.set(alias, [...keys]);
          }
        }
      }
    }
  }

  // ── Public API ───────────────────────────────────────────────────────────

  public getStartNode(): WorkflowNode | null {
    if (this.graph.startNodeId) {
      const node = this.nodeMap.get(this.graph.startNodeId);
      if (node) return node;
    }
    // Fallback: find node with type 'start'
    for (const n of this.graph.nodes) {
      if (n.type === "start") return n;
    }
    return null;
  }

  public getNode(nodeId: string): WorkflowNode | null {
    return this.nodeMap.get(nodeId) || null;
  }

  public findQuestionNode(questionId: string): WorkflowNode | null {
    for (const n of this.graph.nodes) {
      if (n.type === "question" && n.data?.questionId === questionId) return n;
    }
    return null;
  }

  public getAllQuestionNodes(): WorkflowNode[] {
    return this.graph.nodes.filter((n) => n.type === "question");
  }

  public getOutgoingEdges(nodeId: string): WorkflowEdge[] {
    return this.outgoingEdgeMap.get(nodeId) || [];
  }

  public getLastTrace(): StepTrace | null {
    return this.lastTrace;
  }

  /**
   * Get the next node ID from the current node using priority-based
   * condition evaluation. Deterministic and traceable.
   */
  public getNextNodeId(
    currentNodeId: string,
    state: WorkflowState,
  ): string | null {
    const currentNode = this.nodeMap.get(currentNodeId);
    if (!currentNode) return null;

    const edges = (this.outgoingEdgeMap.get(currentNodeId) || [])
      .slice()
      .sort((a, b) => (a.priority ?? 999) - (b.priority ?? 999));

    if (edges.length === 0) return null;

    // Logic nodes have their own evaluation
    if (currentNode.type === "logic_if") {
      return this.evaluateIfElse(currentNode, edges, state);
    }
    if (currentNode.type === "logic_switch") {
      return this.evaluateSwitch(currentNode, edges, state);
    }
    // Loop node: check iteration count
    if (currentNode.type === "loop") {
      return this.evaluateLoop(currentNode, edges, state);
    }
    // Random split: deterministic assignment
    if (currentNode.type === "random_split") {
      return this.evaluateRandomSplit(currentNode, edges, state);
    }

    // For question/start/merge/message nodes: evaluate edge conditions
    // against the current answer for this node
    const answer = state.answers[currentNodeId]
      ?? state.answers[currentNode.data?.questionId || ""]
      ?? undefined;

    return this.resolveEdgesByPriority(currentNodeId, currentNode.type, edges, answer, state);
  }

  /**
   * Walk from a given node through non-question nodes until reaching
   * a question or end-type node.
   */
  public walkToNextQuestion(
    startWfNodeId: string,
    state: WorkflowState,
  ): WorkflowNode | null {
    let currentId: string | null = startWfNodeId;
    let depth = 0;

    while (currentId && depth < MAX_WALK_DEPTH) {
      depth++;
      const node = this.nodeMap.get(currentId);
      if (!node) return null;

      if (node.type === "end" || node.type === "action_end_survey") return null;
      if (node.type === "question") return node;

      // Non-question → step through
      currentId = this.getNextNodeId(currentId, state);
    }
    return null;
  }

  // ── Priority-based edge resolution ──────────────────────────────────────

  private resolveEdgesByPriority(
    nodeId: string,
    nodeType: string,
    edges: WorkflowEdge[],
    answer: any,
    state: WorkflowState,
  ): string | null {
    const traces: EvaluationTrace[] = [];
    let fallbackEdge: WorkflowEdge | null = null;

    for (const edge of edges) {
      // Edge with no condition and no sourcePort label = fallback
      const hasCondition = !!(edge.condition && edge.condition.trim());
      const hasPort = !!(edge.sourcePort && edge.sourcePort !== "default");

      if (!hasCondition && !hasPort) {
        // Only keep the first fallback
        if (!fallbackEdge) fallbackEdge = edge;
        continue;
      }

      // Evaluate condition if present
      if (hasCondition) {
        const trace: EvaluationTrace = { operator: "", expected: null, actual: answer, result: false };
        const cond = { operator: edge.condition!, value: edge.label || undefined };
        const met = evaluateCondition(cond, answer, state.answers, trace);
        traces.push(trace);

        if (met) {
          this.lastTrace = {
            nodeId, nodeType, answer,
            edgesEvaluated: edges.length,
            edgeTraces: traces,
            selectedEdgeId: edge.id,
            selectedTargetId: edge.targetId,
            reason: `Condition "${edge.condition}" matched`,
          };
          return edge.targetId;
        }
      }

      // Unconditional but has a port (e.g., "default") — treat as fallback
      if (!hasCondition && hasPort && !fallbackEdge) {
        fallbackEdge = edge;
      }
    }

    // Use fallback edge
    if (fallbackEdge) {
      this.lastTrace = {
        nodeId, nodeType, answer,
        edgesEvaluated: edges.length,
        edgeTraces: traces,
        selectedEdgeId: fallbackEdge.id,
        selectedTargetId: fallbackEdge.targetId,
        reason: "Fallback edge selected",
      };
      return fallbackEdge.targetId;
    }

    // No match, no fallback → terminal
    this.lastTrace = {
      nodeId, nodeType, answer,
      edgesEvaluated: edges.length,
      edgeTraces: traces,
      selectedEdgeId: null,
      selectedTargetId: null,
      reason: "No matching edge and no fallback",
    };
    return null;
  }

  // ── Logic node evaluators ───────────────────────────────────────────────

  private evaluateIfElse(
    node: WorkflowNode,
    edges: WorkflowEdge[],
    state: WorkflowState,
  ): string | null {
    const questionId = node.data?.questionId || node.data?.operand;
    const operator = node.data?.operator || node.data?.condition || "==";
    const compareValue = node.data?.value || "";

    // ── Deterministic answer lookup via questionLookupMap ──
    const answer = questionId ? this.lookupAnswer(questionId, state) : undefined;

    // ── Evaluate compound conditions if present ──
    let conditionMet: boolean;

    if (node.data?.conditions && node.data.conditions.length > 0) {
      // Compound conditions with AND/OR logic
      const logic = node.data.conditionLogic || "AND";
      const results = node.data.conditions.map((cond) => {
        const condAnswer = this.resolveAnswer(cond.questionId, state);
        return this.evaluateOperator(condAnswer, cond.operator, cond.value);
      });
      conditionMet = logic === "OR"
        ? results.some(Boolean)
        : results.every(Boolean);

      if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
        console.log("[WorkflowEngine:evaluateIfElse:compound]", {
          nodeId: node.id,
          conditions: node.data.conditions,
          logic,
          results,
          conditionMet,
          availableKeys: Object.keys(state.answers),
        });
      }
    } else {
      // Simple single condition (legacy path)
      conditionMet = this.evaluateOperator(answer, operator, compareValue);

      if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
        console.log("[WorkflowEngine:evaluateIfElse:simple]", {
          nodeId: node.id,
          questionId,
          operator,
          compareValue,
          answer,
          conditionMet,
          availableKeys: Object.keys(state.answers),
          edgesCount: edges.length,
        });
      }
    }

    // Find true/false edges by port name or label
    const trueEdge = edges.find((e) =>
      e.sourcePort === "true" || e.sourcePort === "yes" ||
      e.label === "true" || e.label === "Yes" || e.label === "yes"
    );
    const falseEdge = edges.find((e) =>
      e.sourcePort === "false" || e.sourcePort === "no" ||
      e.label === "false" || e.label === "No" || e.label === "no"
    );
    const defaultEdge = edges.find((e) => e.sourcePort === "default");

    this.lastTrace = {
      nodeId: node.id, nodeType: node.type, answer,
      edgesEvaluated: edges.length,
      edgeTraces: [],
      selectedEdgeId: (conditionMet ? trueEdge : falseEdge || defaultEdge)?.id || null,
      selectedTargetId: (conditionMet ? trueEdge : falseEdge || defaultEdge)?.targetId || null,
      reason: `if/else: qId=${questionId} op=${operator} val=${compareValue} answer=${JSON.stringify(answer)} → ${conditionMet ? "TRUE" : "FALSE"} | edges: yes=${!!trueEdge} no=${!!falseEdge} default=${!!defaultEdge}`,
    };

    if (conditionMet && trueEdge) return trueEdge.targetId;
    if (!conditionMet && falseEdge) return falseEdge.targetId;
    // Fallback chain: default → first edge → null
    if (defaultEdge) return defaultEdge.targetId;
    return edges[0]?.targetId || null;
  }

  private evaluateSwitch(
    node: WorkflowNode,
    edges: WorkflowEdge[],
    state: WorkflowState,
  ): string | null {
    const branches = node.data?.branches || [];
    const questionId = node.data?.questionId || node.data?.operand;

    const answer = questionId ? this.lookupAnswer(questionId, state) : undefined;

    for (const branch of branches) {
      const branchEdge = edges.find((e) => e.sourcePort === branch.id);
      if (!branchEdge) continue;
      if (this.evaluateOperator(answer, branch.condition || "==", branch.label)) {
        this.lastTrace = {
          nodeId: node.id, nodeType: node.type, answer,
          edgesEvaluated: edges.length, edgeTraces: [],
          selectedEdgeId: branchEdge.id,
          selectedTargetId: branchEdge.targetId,
          reason: `switch: branch "${branch.label}" matched`,
        };
        return branchEdge.targetId;
      }
    }

    const defaultEdge = edges.find((e) => e.sourcePort === "default");
    if (defaultEdge) return defaultEdge.targetId;
    return edges[0]?.targetId || null;
  }

  /**
   * Deterministic answer lookup using the pre-built questionLookupMap.
   * Tries all registered answer keys for the given questionId in order,
   * with a single exact-match fallback.
   */
  private lookupAnswer(questionId: string, state: WorkflowState): any {
    // 1) Try all pre-mapped keys for this questionId
    const mappedKeys = this.questionLookupMap.get(questionId);
    if (mappedKeys) {
      for (const key of mappedKeys) {
        const val = state.answers[key];
        if (val !== undefined && val !== null) return val;
      }
    }
    // 2) Direct key (for questions not in the workflow graph)
    const direct = state.answers[questionId];
    if (direct !== undefined && direct !== null) return direct;
    // 3) Prefixed key
    const prefixed = state.answers[`node_${questionId}`];
    if (prefixed !== undefined && prefixed !== null) return prefixed;
    return undefined;
  }

  /**
   * Resolve an answer value by questionId — delegates to lookupAnswer.
   */
  private resolveAnswer(questionId: string, state: WorkflowState): any {
    return this.lookupAnswer(questionId, state);
  }

  // ── Loop evaluation ─────────────────────────────────────────────────────

  private evaluateLoop(
    node: WorkflowNode,
    edges: WorkflowEdge[],
    state: WorkflowState,
  ): string | null {
    const maxIter = node.data?.maxIterations || 3;
    const currentIter = state.loopIterations[node.id] || 0;

    const loopEdge = edges.find((e) =>
      e.sourcePort === "loop_back" || e.sourcePort === "loop" ||
      e.label === "Loop"
    );
    const exitEdge = edges.find((e) =>
      e.sourcePort === "exit" || e.sourcePort === "default" ||
      e.label === "Exit"
    );

    this.lastTrace = {
      nodeId: node.id, nodeType: node.type,
      edgesEvaluated: edges.length, edgeTraces: [],
      selectedEdgeId: null, selectedTargetId: null,
      reason: `loop: iter=${currentIter}/${maxIter}`,
    };

    if (currentIter < maxIter && loopEdge) {
      state.loopIterations[node.id] = currentIter + 1;
      this.lastTrace.selectedEdgeId = loopEdge.id;
      this.lastTrace.selectedTargetId = loopEdge.targetId;
      this.lastTrace.reason = `loop: iterating ${currentIter + 1}/${maxIter}`;
      return loopEdge.targetId;
    }

    // Max reached or no loop edge → exit
    const target = exitEdge || edges[0];
    if (target) {
      this.lastTrace.selectedEdgeId = target.id;
      this.lastTrace.selectedTargetId = target.targetId;
      this.lastTrace.reason = `loop: exiting at iter ${currentIter}/${maxIter}`;
      return target.targetId;
    }
    return null;
  }

  // ── Random split evaluation ────────────────────────────────────────────

  private evaluateRandomSplit(
    node: WorkflowNode,
    edges: WorkflowEdge[],
    state: WorkflowState,
  ): string | null {
    // Deterministic: hash answers to pick a path
    const hash = this.deterministicHash(state.answers);
    const splitEdges = edges.filter((e) =>
      e.sourcePort?.startsWith("split_") || e.sourcePort !== "default"
    );

    if (splitEdges.length === 0) {
      const fallback = edges[0];
      return fallback?.targetId || null;
    }

    const idx = hash % splitEdges.length;
    const chosen = splitEdges[idx];

    this.lastTrace = {
      nodeId: node.id, nodeType: node.type,
      edgesEvaluated: edges.length, edgeTraces: [],
      selectedEdgeId: chosen.id,
      selectedTargetId: chosen.targetId,
      reason: `random_split: hash=${hash} → path ${idx + 1}/${splitEdges.length}`,
    };
    return chosen.targetId;
  }

  private deterministicHash(answers: Record<string, any>): number {
    let h = 0;
    for (const key of Object.keys(answers).sort()) {
      const val = String(answers[key]);
      for (let i = 0; i < val.length; i++) {
        h = ((h << 5) - h + val.charCodeAt(i)) | 0;
      }
    }
    return Math.abs(h);
  }

  private evaluateOperator(answer: any, operator: string, value: string): boolean {
    if (answer === undefined || answer === null) return false;
    const cond = { operator, value };
    return evaluateCondition(cond, answer);
  }
}
