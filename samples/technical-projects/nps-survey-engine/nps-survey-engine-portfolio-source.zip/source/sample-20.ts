import { NextRequest, NextResponse } from "next/server";
import { getAuthContext } from "@/lib/authz";

export const dynamic = "force-dynamic";

/**
 * Client auth context (RBAC Solution doc §7): the identity + permission set
 * behind the current session. Consumed by the Zustand authStore (useCan)
 * for UX-only gating — the server DAL remains the security boundary.
 */
export async function GET(req: NextRequest) {
  const ctx = await getAuthContext(req);
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({
    user: {
      id: ctx.user.id,
      email: ctx.user.email,
      name: ctx.user.name,
    },
    role: ctx.user.roleName,
    permissions: [...ctx.permissions],
    isBreakGlass: ctx.isBreakGlass,
  });
}
