/**
 * Shared user-management guardrails (RBAC Solution doc §7): the org must
 * never lose its last active Owner — not by role change, not by suspension.
 */
import { eq, and, ne, count } from "drizzle-orm";
import { db } from "@/db";
import { users, roles } from "@/db/schema";

export async function isLastActiveOwnerUser(userId: number): Promise<boolean> {
  const [owner] = await db.select({ id: roles.id }).from(roles).where(eq(roles.name, "Owner"));
  if (!owner) return false;
  const [target] = await db
    .select({ roleId: users.roleId, isActive: users.isActive })
    .from(users)
    .where(eq(users.id, userId));
  if (!target || target.roleId !== owner.id || !target.isActive) return false;
  const [{ others }] = await db
    .select({ others: count() })
    .from(users)
    .where(and(eq(users.roleId, owner.id), eq(users.isActive, true), ne(users.id, userId)));
  return Number(others) === 0;
}
