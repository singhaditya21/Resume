"use client";

export { EmailPropertiesPanel as PropertyPanel } from "./EmailPropertiesPanel";
