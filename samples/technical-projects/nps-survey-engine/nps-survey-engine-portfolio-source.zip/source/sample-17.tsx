"use client";

import React from "react";
import Link from "next/link";
import { SideNavBar } from "@/components/layout/SideNavBar";
import { TopNavBar } from "@/components/layout/TopNavBar";
import { EmailTemplateList } from "@/components/email-builder/EmailTemplateList";

export default function EmailTemplatesPage() {
  return (
    <div className="flex h-screen bg-surface">
      <SideNavBar />

      <div className="ml-20 flex flex-1 flex-col overflow-hidden" style={{ marginLeft: 80 }}>
        <TopNavBar />

        <main className="mt-14 flex-1 overflow-y-auto p-10">
          <EmailTemplateList />
        </main>
      </div>
    </div>
  );
}