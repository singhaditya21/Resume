/**
 * Audit-log writer (RBAC Solution doc §4.1). Best-effort: an audit failure
 * must never break the action it records — errors are logged and swallowed.
 * The register rate-limiter also counts rows here (action + ip + window).
 */
import { db } from "@/db";
import { auditLog } from "@/db/schema";

export interface AuditEntry {
  actorUserId?: number | null;
  action: string; // e.g. "user.self_register", "user.activate", "role.update"
  resourceType?: string;
  resourceId?: string | number;
  metadata?: Record<string, unknown>;
  ip?: string;
}

export async function writeAudit(entry: AuditEntry): Promise<void> {
  try {
    await db.insert(auditLog).values({
      actorUserId: entry.actorUserId ?? null,
      action: entry.action,
      resourceType: entry.resourceType ?? null,
      resourceId: entry.resourceId != null ? String(entry.resourceId) : null,
      metadata: entry.metadata ?? null,
      ip: entry.ip ?? null,
    });
  } catch (err) {
    console.error("[audit] failed to write audit row:", err);
  }
}
