import { Option2Panel } from './command-centre/Option2Panel';
import '../styles/command-centre.css';

/**
 * Project Command Centre — the rich "Portfolio Command Centre" dashboard.
 * Renders the org-level view; the dashboard's own header carries the
 * All/Billable/At-Risk/This-Quarter + customer filters and Save-as-PDF.
 */
export function CommandCentrePanel() {
  return (
    <div id="pcc-root">
      <Option2Panel level="org" />
    </div>
  );
}
