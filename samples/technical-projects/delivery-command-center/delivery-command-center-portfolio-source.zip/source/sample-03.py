from __future__ import annotations

"""
Project lifecycle classification — single source of truth.

Rule (cutoff boundary = 1 April 2026):
  Active    — project has STARTED and go-live date is AFTER 31 Mar 2026
              (i.e. go_live_date >= 1 Apr 2026)
  Inactive  — project has STARTED and go-live date is ON OR BEFORE 31 Mar 2026
              (i.e. go_live_date < 1 Apr 2026)
  Prospect  — project has NOT started yet (pre-sales / pre-initiation status),
              OR it has started but has no go-live date (edge case — bucketed as
              Prospect per product decision: an undated project is still a
              pipeline/needs-planning item, not a live delivery).

"Started" = the project has moved beyond a pre-sales / pre-initiation status.
"Not started" = an explicit pre-initiation status (draft, concept,
pre-engagement, initiated, …). Everything else is treated as started.

Both the Command Centre data aggregators and the dashboard filters/cards import
from here so the backend classification and the UI stay in lockstep.
"""

from datetime import date, datetime
from typing import Any

# Cutoff boundary. Active requires go-live on/after this date.
LIFECYCLE_CUTOFF = date(2026, 4, 1)

# Pre-sales / pre-initiation statuses → the project has NOT started yet.
# Compared case-insensitively against project.statuscode (trimmed). Keep this the
# one place to tune what counts as "not started".
NOT_STARTED_STATUSES: set[str] = {
    "draft",
    "concept",
    "pre-engagement",
    "pre engagement",
    "pre-initiation",
    "pre initiation",
    "pre-sales",
    "pre sales",
    "presales",
    "initiated",
    "prospect",
}

# Stable type keys + human labels, shared with the UI.
PROJECT_TYPE_ACTIVE = "PORTFOLIO_REDACTED"
PROJECT_TYPE_INACTIVE = "PORTFOLIO_REDACTED"
PROJECT_TYPE_PROSPECT = "PORTFOLIO_REDACTED"

PROJECT_TYPE_LABELS: dict[str, str] = {
    PROJECT_TYPE_ACTIVE: "PORTFOLIO_REDACTED",
    PROJECT_TYPE_INACTIVE: "PORTFOLIO_REDACTED",
    PROJECT_TYPE_PROSPECT: "PORTFOLIO_REDACTED",
}


def _to_date(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return datetime.fromisoformat(str(v).split("T")[0]).date()
    except Exception:
        return None


def is_started(statuscode: Any) -> bool:
    """True when the project has moved beyond a pre-sales / pre-initiation status."""
    s = str(statuscode or "").lower().strip()
    if not s:
        # Unknown/blank status: assume it has started (let the go-live date decide).
        return True
    return s not in NOT_STARTED_STATUSES


def classify_project_type(statuscode: Any, golive_date: Any) -> str:
    """
    Classify a project into one of: "active" | "inactive" | "prospect".

    golive_date may be a date/datetime/ISO-string/None.
    """
    if not is_started(statuscode):
        return PROJECT_TYPE_PROSPECT

    gl = _to_date(golive_date)
    if gl is None:
        # Started but no go-live date → Prospect (product decision).
        return PROJECT_TYPE_PROSPECT

    return PROJECT_TYPE_ACTIVE if gl >= LIFECYCLE_CUTOFF else PROJECT_TYPE_INACTIVE
