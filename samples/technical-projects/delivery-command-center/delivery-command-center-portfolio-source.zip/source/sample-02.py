from __future__ import annotations

"""
Command Centre — Option 2 data aggregator.

Builds the exact data shape the rich "Portfolio Command Centre" (Option 2)
front-end expects, combining:

  REAL CRM data
    projects      → dbo.project
    milestones    → dbo.projectmodule (plan cols + trail/actual cols)
    financials    → dbo.project_revenue  (service value, recognised, invoice, unbilled)
    defects       → dbo.cases  (relatedtotypeid = 113)
    risks/actions → dbo.risk + dbo.activity
    modules       → dbo.projectmodule

  SUPPLEMENTARY data (seeded into dbo.cc_* by command_centre_v2_seed.py)
    track/category, governance, integrations, milestone billing, pipeline, ARR

Every field's origin is documented in docs/DATA_LINEAGE.md. Each section is
independently guarded so a missing table degrades gracefully.

Filters (same as Option 1): level = org | portfolio | project, with optional
project_id / portfolio_id. The curated demo set = projects present in
dbo.cc_project_meta; level scoping further narrows that set.
"""

import logging
from datetime import datetime, date
from typing import Any

from sqlalchemy import text
from db import SessionLocal

from project_intel.services.project_lifecycle import (
    LIFECYCLE_CUTOFF,
    NOT_STARTED_STATUSES,
    classify_project_type,
    is_started,
)

logger = logging.getLogger(__name__)

# 11-stage milestone model used by Option 2
MILESTONES = ["SAD", "SAD Sign-off", "Development", "QA", "SIT Delivery",
              "SIT Sign-off", "UAT Delivery", "UAT Sign-off", "Pre-Prod",
              "Pre-Prod Sign-off", "Go-Live"]

# Map each Option-2 milestone to (plan_col, trail_col) on dbo.projectmodule.
# Columns that have no DB source are left as (None, None) and derived.
_MS_COLS = [
    ("fsddelivery",  "trailfsdsignoff"),   # SAD
    ("fsdsignoff",   "trailfsdsignoff"),   # SAD Sign-off
    ("devdelivery",  "traildevdelivery"),  # Development
    ("preuatdemo",   "trailpreuatdemo"),   # QA
    ("sitstartdate", "trailsitstartdate"), # SIT Delivery
    (None,           None),                # SIT Sign-off (derived)
    ("uatstartdate", "trailuatstartdate"), # UAT Delivery
    ("uatsignoff",   "trailuatsignoff"),   # UAT Sign-off
    (None,           None),                # Pre-Prod (derived)
    (None,           None),                # Pre-Prod Sign-off (derived)
    ("golive",       "trailgolive"),       # Go-Live
]

_COMPLETE = {"closed", "completed", "warranty", "live", "live cutover", "done"}
_AT_RISK_STATUS = {"dropped", "not done", "on hold"}

# Revenue Type LOV for prj_ex4_67 ("Revenue Type_P"), verified from the field's
# lookup. Drives the Revenue section's type filter.
_REV_TYPE_LABELS = {
    1: "Work@Risk", 2: "Recognizable Revenue", 3: "Reversal", 4: "Pipeline",
    5: "Offbook", 6: "Renewal", 7: "Pipeline ARR",
}

# SQL literal list of pre-initiation statuses, generated from the shared
# source-of-truth set so the rollup query never drifts from classify_project_type.
_NOT_STARTED_SQL = ",".join("'" + s.replace("'", "''") + "'" for s in sorted(NOT_STARTED_STATUSES))

# Correlated go-live subquery (earliest planned go-live per project), joined as
# `glx` so the lifecycle filter can run server-side on the project population.
_GOLIVE_JOIN = (
    "LEFT JOIN (SELECT relatedtoid AS pid, MIN(golive) AS gol "
    "FROM dbo.projectmodule WHERE relatedtotypeid = 113 GROUP BY relatedtoid) glx "
    "ON glx.pid = p.projectid"
)


def _norm_ptype(ptype: str | None) -> str | None:
    """Normalise the lifecycle filter to active|inactive|prospect, else None (=all)."""
    p = (ptype or "").strip().lower()
    return p if p in ("active", "inactive", "prospect") else None


def _ptype_where(ptype: str | None, gl_expr: str) -> str:
    """WHERE fragment selecting one lifecycle type, mirroring
    project_lifecycle.classify_project_type. `gl_expr` is the SQL go-live
    expression for the surrounding query (e.g. "COALESCE(glx.gol, p.enddate)").
    Binds :lc_cutoff. Empty string when ptype is None/all."""
    pt = _norm_ptype(ptype)
    if not pt:
        return ""
    started = f"lower(coalesce(p.statuscode,'')) NOT IN ({_NOT_STARTED_SQL})"
    if pt == "prospect":
        return f" AND (NOT ({started}) OR {gl_expr} IS NULL)"
    if pt == "active":
        return f" AND {started} AND {gl_expr} IS NOT NULL AND {gl_expr} >= :lc_cutoff"
    return f" AND {started} AND {gl_expr} IS NOT NULL AND {gl_expr} < :lc_cutoff"  # inactive


# ── helpers ────────────────────────────────────────────────────────────────

def _fetch(db, sql: str, params: dict | None = None) -> list[dict]:
    try:
        res = db.execute(text(sql), params or {})
        cols = list(res.keys())
        return [dict(zip(cols, row)) for row in res.fetchall()]
    except Exception:
        # In PostgreSQL a failed statement aborts the whole transaction, so every
        # later query errors with "current transaction is aborted". That would let
        # one missing table (e.g. the cc_* supplementary layer when the dashboard
        # runs live-data-only) cascade into the live sections and the anchor
        # fallback. Roll back so each section's try/except can degrade on its own
        # and the next query runs on a clean transaction.
        db.rollback()
        raise


def _d(v: Any) -> str:
    """Short date label 'DD Mon' or em-dash."""
    if v is None:
        return "—"
    if isinstance(v, (datetime, date)):
        return v.strftime("%d %b")
    try:
        return datetime.fromisoformat(str(v).split("T")[0]).strftime("%d %b")
    except Exception:
        s = str(v).strip()
        return s[:10] if s else "—"


def _to_date(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return datetime.fromisoformat(str(v).split("T")[0]).date()
    except Exception:
        return None


def _safe_float(v: Any) -> float:
    try:
        return float(v or 0)
    except Exception:
        return 0.0


def _lakhs(v: Any) -> float:
    # ₹ Lakhs to 2 decimals (₹1,000 resolution). Exact rupee figures are carried
    # separately (raw fields) so the UI can show the precise amount on demand.
    return round(_safe_float(v) / 100000.0, 2)


def _rupees(v: Any) -> int:
    """Exact rupee amount (rounded to the nearest rupee) for precise display."""
    return int(round(_safe_float(v)))


def _is_complete(statuscode: str) -> bool:
    return (statuscode or "").lower().strip() in _COMPLETE


def _project_golive(mod_rows: list[dict], enddate: Any) -> date | None:
    """Best-available go-live date for a project, used by lifecycle classification.

    Earliest planned Go-Live across the project's modules, falling back to
    project.enddate. (The projectmodule trail* columns are free-text notes in
    this CRM, not dates, so they are not used.) Returns None when nothing is
    dated (→ classified as Prospect). Mirrors the rollup SQL in _compute_rollup."""
    ds = [d for r in mod_rows if (d := _to_date(r.get("golive"))) is not None]
    return (min(ds) if ds else None) or _to_date(enddate)


def _fallback_track(statuscode: str) -> tuple[str, str | None]:
    """Classify a non-anchor project (no cc_project_meta row) into a track.
    Run/maintain phases → BAU; everything in-flight → Transformational (no theme)."""
    s = (statuscode or "").lower().strip()
    if s in ("warranty", "live cutover", "closed", "completed"):
        return "bau", None
    return "transformational", None


def _health(statuscode: str, escalated: Any, states: list[str] | None = None,
            has_plan: bool = True) -> str:
    """
    Derive health from real status + real milestone dates.
      - escalated / dropped / on hold              → atRisk
      - completed / run-state (warranty/live)      → onTime
      - UAT phase                                  → delayed
      - in-flight with >=3 overdue milestones      → atRisk
      - in-flight with any overdue/slipped         → delayed
      - in-flight WITH planned milestones, none due → onTime
      - in-flight with NO milestone dates at all   → unknown (no evidence)

    `has_plan` is False when the project has no planned milestone dates — those
    projects are NOT counted as on-time (they were silently inflating On Time).
    """
    s = (statuscode or "").lower().strip()
    if str(escalated or "").lower() in ("1", "true", "t", "yes") or s in _AT_RISK_STATUS:
        return "atRisk"
    if _is_complete(s):
        return "onTime"
    late = states.count("late") if states else 0
    slip = bool(states and "slip" in states)
    if s == "uat":
        return "delayed"
    if late >= 3:          # several overdue milestones on an in-flight project
        return "atRisk"
    if late or slip:
        return "delayed"
    if not has_plan:       # no milestone dates → we can't claim it's on time
        return "unknown"
    return "onTime"


# ── milestone timeline per project (from projectmodule, aggregated) ──────────

def _build_milestones(mod_rows: list[dict], project_done: bool = False) -> tuple[list[str], list[str], list[str]]:
    """
    Aggregate module-level milestone dates into a single project timeline.
    Returns (states[11], plan[11], actual[11]).
    Plan = earliest planned date across modules; Actual = earliest trail date.
    State derived from plan vs actual vs today. When the project is in a
    completed/run state, planned-but-undated milestones read as delivered
    (the work shipped even if the trail/actual date wasn't back-filled).
    """
    today = date.today()
    plan_out, act_out, state_out = [], [], []

    def _earliest(rows, col):
        ds = [_to_date(r.get(col)) for r in rows if col and r.get(col) is not None]
        ds = [d for d in ds if d]
        return min(ds) if ds else None

    # derive helper anchors first
    sit_start = _earliest(mod_rows, "sitstartdate")
    uat_sign  = _earliest(mod_rows, "uatsignoff")
    golive    = _earliest(mod_rows, "golive")

    for i, (pcol, tcol) in enumerate(_MS_COLS):
        pdate = _earliest(mod_rows, pcol) if pcol else None
        adate = _earliest(mod_rows, tcol) if tcol else None

        # derive the three milestones with no direct column
        if i == 5 and not pdate:   # SIT Sign-off ≈ sit_start + 14d
            pdate = (sit_start.replace() if sit_start else None)
        if i == 8 and not pdate and uat_sign and golive:  # Pre-Prod ≈ between UAT signoff & go-live
            pdate = uat_sign
        if i == 9 and not pdate and golive:  # Pre-Prod Sign-off ≈ go-live - few days
            pdate = golive

        plan_out.append(_d(pdate))
        act_out.append(_d(adate))

        # state machine
        if adate and pdate and adate > pdate:
            st = "slip"            # delivered but late → amber
        elif adate:
            st = "done"            # delivered on/early → green
        elif project_done and pdate:
            st = "done"            # run-state project — milestone shipped
        elif pdate and pdate < today:
            st = "late"            # overdue, no actual → red
        elif pdate and pdate <= today:
            st = "active"
        elif pdate:
            st = "future"
        else:
            st = "future"
        state_out.append(st)

    # ensure at least the first is done so the bar reads naturally
    if all(s == "future" for s in state_out):
        state_out[0] = "active"
    return state_out, plan_out, act_out


# ── portfolio rollup (aggregates over ALL matched projects, before the cap) ──

def _compute_rollup(db, proj_where: str, filt_sql: str, params: dict,
                    ptype: str | None = None) -> dict:
    """KPI totals over the ENTIRE matched live set (not just the top-N detail
    cap), so the headline cards reflect the whole selected portfolio. When a
    lifecycle `ptype` (active|inactive|prospect) is given, every total is scoped
    to that type so the cards match the filtered detail. Health mirrors _health
    (status + escalation + overdue milestones) via one aggregate query. Revenue
    from project_revenue. Each piece is guarded so one failure doesn't void the
    rest. (The Active/Inactive/Prospect breakdown is computed whole-scope by
    _type_breakdown, not here.)"""
    out = {"total": 0, "onTime": 0, "delayed": 0, "atRisk": 0, "unknown": 0,
           "billableCount": 0, "billed": 0, "pending": 0, "overdue": 0, "unbilled": 0,
           "billedRs": 0, "unbilledRs": 0,
           "invoiceCount": 0, "openInvoiceCount": 0, "unbilledCount": 0}
    pt = _norm_ptype(ptype)
    # Lifecycle scoping for the health query uses the mil CTE's planned go-live;
    # for the financial query it uses the glx join (added only when filtering).
    pw_health = _ptype_where(pt, "COALESCE(m.golive, p.enddate)")
    pw_fin = _ptype_where(pt, "COALESCE(glx.gol, p.enddate)")
    fin_join = _GOLIVE_JOIN if pt else ""
    p_extra = {"lc_cutoff": LIFECYCLE_CUTOFF} if pt else {}
    try:
        rows = _fetch(db, f"""
            WITH mraw AS (
              -- One row per project: earliest planned milestone date + earliest
              -- go-live (mirrors _build_milestones, which aggregates a project's
              -- modules). NOTE: the projectmodule trail* columns are free-text
              -- commentary in this CRM (e.g. "Not Specified", status notes), NOT
              -- actual dates — so they are deliberately ignored here. "Late" =
              -- a planned milestone now in the past (no parseable actual exists),
              -- which matches how the per-project _build_milestones resolves it.
              SELECT relatedtoid AS pid,
                MIN(fsddelivery)  AS sad_p,
                MIN(fsdsignoff)   AS sso_p,
                MIN(devdelivery)  AS dev_p,
                MIN(preuatdemo)   AS qa_p,
                MIN(sitstartdate) AS sit_p,
                MIN(uatstartdate) AS uad_p,
                MIN(uatsignoff)   AS uas_p,
                MIN(golive)       AS gol_p
              FROM dbo.projectmodule WHERE relatedtotypeid = 113 GROUP BY relatedtoid
            ),
            mil AS (
              -- late = a planned milestone in the past. (slip is unavailable —
              -- no actual dates in this dataset.) Matches _health: late>=3 →
              -- atRisk; late>0 → delayed.
              SELECT pid,
                ( (CASE WHEN sad_p IS NOT NULL AND sad_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN sso_p IS NOT NULL AND sso_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN dev_p IS NOT NULL AND dev_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN qa_p  IS NOT NULL AND qa_p  < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN sit_p IS NOT NULL AND sit_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN uad_p IS NOT NULL AND uad_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN uas_p IS NOT NULL AND uas_p < CURRENT_DATE THEN 1 ELSE 0 END)
                + (CASE WHEN gol_p IS NOT NULL AND gol_p < CURRENT_DATE THEN 1 ELSE 0 END) ) AS late_cnt,
                (CASE WHEN sad_p IS NOT NULL OR sso_p IS NOT NULL OR dev_p IS NOT NULL
                        OR qa_p IS NOT NULL OR sit_p IS NOT NULL OR uad_p IS NOT NULL
                        OR uas_p IS NOT NULL OR gol_p IS NOT NULL THEN 1 ELSE 0 END) AS has_plan,
                gol_p AS golive   -- go-live (planned); enddate used as fallback below
              FROM mraw
            ),
            base AS (
              SELECT p.projectid,
                CASE
                  WHEN lower(coalesce(p.isescalated::text,'')) IN ('1','true','t','yes')
                       OR lower(coalesce(p.statuscode,'')) IN ('dropped','not done','on hold') THEN 'atRisk'
                  WHEN lower(coalesce(p.statuscode,'')) IN ('closed','completed','warranty','live cutover','live','done') THEN 'onTime'
                  WHEN lower(coalesce(p.statuscode,'')) = 'uat' THEN 'delayed'
                  WHEN coalesce(m.late_cnt,0) >= 3 THEN 'atRisk'
                  WHEN coalesce(m.late_cnt,0) > 0 THEN 'delayed'
                  WHEN coalesce(m.has_plan,0) = 1 THEN 'onTime'
                  ELSE 'unknown' END AS health,
                (replace(coalesce(p.billable::text,''),'.0','') IN ('1','true')) AS billable_flag
              FROM dbo.project p
              LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
              LEFT JOIN mil m ON m.pid = p.projectid
              WHERE {proj_where} AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1{filt_sql}{pw_health}
            )
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN health='onTime' THEN 1 ELSE 0 END) AS ontime,
                   SUM(CASE WHEN health='delayed' THEN 1 ELSE 0 END) AS delayed,
                   SUM(CASE WHEN health='atRisk' THEN 1 ELSE 0 END) AS atrisk,
                   SUM(CASE WHEN health='unknown' THEN 1 ELSE 0 END) AS unknown,
                   SUM(CASE WHEN billable_flag THEN 1 ELSE 0 END) AS billable_cnt
            FROM base
        """, {**params, **p_extra})
        if rows:
            r = rows[0]
            out["total"] = int(r.get("total") or 0)
            out["onTime"] = int(r.get("ontime") or 0)
            out["delayed"] = int(r.get("delayed") or 0)
            out["atRisk"] = int(r.get("atrisk") or 0)
            out["unknown"] = int(r.get("unknown") or 0)
            out["billableCount"] = int(r.get("billable_cnt") or 0)
    except Exception as exc:
        out["health_error"] = str(exc)
    try:
        rows = _fetch(db, f"""
            SELECT COALESCE(SUM(pr.invoice),0)              AS billed,
                   COALESCE(SUM(GREATEST(pr.unbilled,0)),0) AS unbilled,
                   COUNT(*) FILTER (WHERE pr.invoice > 0)   AS invoice_cnt,
                   COUNT(*) FILTER (WHERE pr.unbilled > 0)  AS open_cnt
            FROM (
                SELECT project_id,
                       MAX(cumulative_invoice) AS invoice,
                       MAX(unbilled)           AS unbilled
                FROM dbo.project_revenue
                GROUP BY project_id
            ) pr
            JOIN dbo.project p ON p.projectid = pr.project_id
            LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
            {fin_join}
            WHERE {proj_where} AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1
              AND replace(coalesce(p.billable::text,''),'.0','') IN ('1','true'){filt_sql}{pw_fin}
        """, {**params, **p_extra})
        billed = float(rows[0].get("billed") or 0) if rows else 0.0
        unbilled = float(rows[0].get("unbilled") or 0) if rows else 0.0
        out["billed"] = _lakhs(billed)
        out["unbilled"] = _lakhs(unbilled)
        # Exact rupee totals so the tiles can show the precise amount on hover.
        out["billedRs"] = _rupees(billed)
        out["unbilledRs"] = _rupees(unbilled)
        # Count of billable projects with invoice value (for the "N invoices"
        # label on Total Billed) and with unbilled WIP > 0 (for the Unbilled
        # tile). Pending/overdue counts stay 0 — there is no milestone-billing
        # (cc_*) data in live mode, so those amounts are ₹0.
        out["invoiceCount"] = int(rows[0].get("invoice_cnt") or 0) if rows else 0
        out["unbilledCount"] = int(rows[0].get("open_cnt") or 0) if rows else 0
    except Exception as exc:
        out["financial_rollup_error"] = str(exc)
    return out


def _type_breakdown(db, proj_where: str, filt_sql: str, params: dict) -> dict:
    """Whole-scope Active/Inactive/Prospect counts (ignores the ptype filter), so
    the dashboard can always show the full lifecycle split regardless of which
    type is currently selected. Mirrors classify_project_type."""
    out = {"active": 0, "inactive": 0, "prospect": 0}
    try:
        rows = _fetch(db, f"""
            SELECT SUM(CASE WHEN ptype='active'   THEN 1 ELSE 0 END) AS active_cnt,
                   SUM(CASE WHEN ptype='inactive' THEN 1 ELSE 0 END) AS inactive_cnt,
                   SUM(CASE WHEN ptype='prospect' THEN 1 ELSE 0 END) AS prospect_cnt
            FROM (
              SELECT CASE
                  WHEN lower(coalesce(p.statuscode,'')) IN ({_NOT_STARTED_SQL}) THEN 'prospect'
                  WHEN COALESCE(glx.gol, p.enddate) IS NULL THEN 'prospect'
                  WHEN COALESCE(glx.gol, p.enddate) >= :lc_cutoff THEN 'active'
                  ELSE 'inactive' END AS ptype
              FROM dbo.project p
              LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
              {_GOLIVE_JOIN}
              WHERE {proj_where} AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1{filt_sql}
            ) t
        """, {**params, "lc_cutoff": LIFECYCLE_CUTOFF})
        if rows:
            r = rows[0]
            out = {"active": int(r.get("active_cnt") or 0),
                   "inactive": int(r.get("inactive_cnt") or 0),
                   "prospect": int(r.get("prospect_cnt") or 0)}
    except Exception:
        pass
    return out


# ── facets (full filter option lists) ───────────────────────────────────────

def build_command_centre_v2_facets(
    level: str = "org",
    project_id: int | None = None,
    portfolio_id: int | None = None,
    account_id: int | None = None,
    avp_ids: list[str] | None = None,
    accounts: list[str] | None = None,
) -> dict:
    """Option lists for the dashboard's Portfolio-AVP and Account filters.

    The lists respect the current scope (org/portfolio/account/project). Account
    options additionally narrow to the selected AVP ids so the second filter is
    dependent on the first.
    """
    db = SessionLocal()
    out: dict = {"ok": True, "avps": [], "accounts": [], "projects": []}
    try:
        params: dict[str, Any] = {}
        scope_where = "1=1"
        if project_id:
            scope_where = "p.projectid = :pid"
            params["pid"] = project_id
        elif account_id:
            scope_where = "p.accountid = :acc"
            params["acc"] = account_id
            if portfolio_id and int(portfolio_id) != 0:
                scope_where += " AND p.portfolioid = :pf"
                params["pf"] = portfolio_id
        elif portfolio_id and int(portfolio_id) != 0:
            scope_where = "p.portfolioid = :pf"
            params["pf"] = portfolio_id

        avp_ids = [str(a).strip() for a in (avp_ids or []) if str(a).strip()]
        accounts = [str(a).strip() for a in (accounts or []) if str(a).strip()]
        avp_filter_sql = ""
        scoped_filter_sql = ""
        scoped_filter_params = dict(params)
        if avp_ids:
            keys = []
            for idx, value in enumerate(avp_ids):
                key = f"avp{idx}"
                scoped_filter_params[key] = value
                keys.append(f":{key}")
            avp_filter_sql = f" AND x.prj_ex4_16 IN ({','.join(keys)})"
            scoped_filter_sql += avp_filter_sql
        if accounts:
            keys = []
            for idx, value in enumerate(accounts):
                key = f"accf{idx}"
                scoped_filter_params[key] = value
                keys.append(f":{key}")
            scoped_filter_sql += f" AND p.companyname IN ({','.join(keys)})"

        # Portfolio AVP people: distinct prj_ex4_16 (userid as text) → names.
        try:
            raw = _fetch(db, """
                SELECT DISTINCT x.prj_ex4_16 AS avp
                FROM dbo.project p
                LEFT JOIN dbo.prj_ex4 x ON x.prj_ex4_id = p.projectid AND x.ownerid = p.ownerid
                WHERE """ + scope_where + """
                  AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1
                  AND x.prj_ex4_16 IS NOT NULL AND x.prj_ex4_16 <> ''
            """, params)
            int_ids = sorted({int(s) for r in raw
                              if (s := str(r.get("avp") or "").strip()).lstrip("-").isdigit()})
            names: dict[str, str] = {}
            if int_ids:
                csv = ",".join(str(i) for i in int_ids)
                for r in _fetch(db, f"""
                    SELECT userid, TRIM(COALESCE(firstname,'') || ' ' || COALESCE(lastname,'')) AS nm
                    FROM dbo.assignmentuserview WHERE userid IN ({csv})
                """):
                    names[str(r["userid"])] = (r["nm"] or "").strip()
            out["avps"] = sorted(
                [{"id": str(i), "name": names.get(str(i)) or f"User {i}"} for i in int_ids],
                key=lambda d: d["name"].lower(),
            )
        except Exception as exc:
            out["avps_error"] = str(exc)

        # Accounts: distinct company names across the live project population.
        try:
            out["accounts"] = [r["c"] for r in _fetch(db, """
                SELECT DISTINCT p.companyname AS c
                FROM dbo.project p
                LEFT JOIN dbo.prj_ex4 x ON x.prj_ex4_id = p.projectid AND x.ownerid = p.ownerid
                WHERE """ + scope_where + """
                  AND p.companyname IS NOT NULL AND LENGTH(p.companyname) > 0
                  AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1""" + avp_filter_sql + """
                ORDER BY p.companyname
            """, scoped_filter_params)]
        except Exception as exc:
            out["accounts_error"] = str(exc)

        try:
            out["projects"] = _fetch(db, """
                SELECT p.projectid AS id,
                       p.projectname AS name,
                       p.companyname AS customer
                FROM dbo.project p
                LEFT JOIN dbo.prj_ex4 x ON x.prj_ex4_id = p.projectid AND x.ownerid = p.ownerid
                WHERE """ + scope_where + """
                  AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1""" + scoped_filter_sql + """
                ORDER BY p.projectname
            """, scoped_filter_params)
        except Exception as exc:
            out["projects_error"] = str(exc)
        return out
    finally:
        db.close()


# ── main ────────────────────────────────────────────────────────────────────

def build_command_centre_v2(
    level: str = "org",
    project_id: int | None = None,
    portfolio_id: int | None = None,
    account_id: int | None = None,
    avp_ids: list[str] | None = None,
    accounts: list[str] | None = None,
    ptype: str | None = None,
) -> dict:
    errors: dict = {}
    db = SessionLocal()
    try:
        # ── Lifecycle (Project Type) filter — applied server-side so the loaded
        # detail, matched total and rollup all reflect Active/Inactive/Prospect.
        # `glx` go-live join + predicate reuse the same logic as the per-project
        # classifier. The whole-scope split is computed separately (byType).
        pt = _norm_ptype(ptype)
        pw_anchor = _ptype_where(pt, "COALESCE(glx.gol, p.enddate)")
        anchor_join = _GOLIVE_JOIN if pt else ""
        pt_extra = {"lc_cutoff": LIFECYCLE_CUTOFF} if pt else {}
        # ── Optional multi-select filters (Portfolio AVP person + Account/company).
        # prj_ex4_16 (Portfolio AVP) is a text column holding a userid; compare as
        # text. companyname is the account. Built once, appended to both anchor
        # queries (which both alias project as `p` and join prj_ex4 as `x4`).
        avp_ids = [str(a).strip() for a in (avp_ids or []) if str(a).strip()]
        accounts = [str(a).strip() for a in (accounts or []) if str(a).strip()]
        filt_sql = ""
        filt_params: dict = {}
        if avp_ids:
            ks = []
            for i, v in enumerate(avp_ids):
                filt_params[f"avp{i}"] = v
                ks.append(f":avp{i}")
            filt_sql += f" AND x4.prj_ex4_16 IN ({','.join(ks)})"
        if accounts:
            ks = []
            for i, v in enumerate(accounts):
                filt_params[f"acc{i}"] = v
                ks.append(f":acc{i}")
            filt_sql += f" AND p.companyname IN ({','.join(ks)})"
        # ── 1. Resolve the curated project set (cc_project_meta ∩ filter) ──
        # Precedence: project > account > portfolio > org. account_id narrows the
        # anchor set by the real project.accountid (Portfolio→Account→Project drill).
        meta_where = "1=1"
        params: dict = {}
        if project_id:
            meta_where = "m.projectid = :pid"
            params = {"pid": project_id}
        elif account_id:
            meta_where = "p.accountid = :acc"
            params = {"acc": account_id}
            if portfolio_id:
                meta_where = "p.accountid = :acc AND p.portfolioid = :pf"
                params["pf"] = portfolio_id
        elif portfolio_id:
            meta_where = "p.portfolioid = :pf"
            params = {"pf": portfolio_id}

        matched_total = 0
        rollup = None
        anchor_source = "curated"
        try:
            anchor = _fetch(db, f"""
                SELECT m.projectid, m.track, m.category, m.display_order,
                       p.projectname, p.companyname, p.statuscode, p.billable,
                       p.isescalated, p.portfolioid, p.startdate, p.enddate,
                       p.ownerid, p.accountid, x4.prj_ex4_16 AS avp_id,
                       x4.prj_ex4_98 AS monitored, x4.prj_ex4_67 AS rev_type_code
                FROM dbo.cc_project_meta m
                JOIN dbo.project p ON p.projectid = m.projectid
                LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
                {anchor_join}
                WHERE {meta_where}{filt_sql}{pw_anchor}
                ORDER BY m.display_order
            """, {**params, **filt_params, **pt_extra})
        except Exception as exc:
            errors["anchor"] = str(exc)
            anchor = []

        # ── Fallback: scope has no curated anchor → build from REAL project rows
        # so the live sections (milestones, defects, revenue, risks, modules)
        # populate for any portfolio/account/project in the full population. The
        # seeded sections (governance/integrations/billing/pipeline/ARR) stay empty.
        if not anchor:
            proj_where = "1=1"
            pparams: dict = {}
            if project_id:
                proj_where = "p.projectid = :pid"; pparams = {"pid": project_id}
            elif account_id:
                proj_where = "p.accountid = :acc"; pparams = {"acc": account_id}
                if portfolio_id and int(portfolio_id) != 0:
                    proj_where += " AND p.portfolioid = :pf"; pparams["pf"] = portfolio_id
            elif portfolio_id and int(portfolio_id) != 0:
                proj_where = "p.portfolioid = :pf"; pparams = {"pf": portfolio_id}
            try:
                anchor = _fetch(db, f"""
                    SELECT p.projectid, NULL AS track, NULL AS category, 0 AS display_order,
                           p.projectname, p.companyname, p.statuscode, p.billable,
                           p.isescalated, p.portfolioid, p.startdate, p.enddate,
                           p.ownerid, p.accountid, x4.prj_ex4_16 AS avp_id,
                           x4.prj_ex4_98 AS monitored, x4.prj_ex4_67 AS rev_type_code
                    FROM dbo.project p
                    LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
                    LEFT JOIN (
                        SELECT project_id, MAX(revenue_recognized) AS recog
                        FROM dbo.project_revenue GROUP BY project_id
                    ) r ON r.project_id = p.projectid
                    {anchor_join}
                    WHERE {proj_where} AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1{filt_sql}{pw_anchor}
                    ORDER BY r.recog DESC NULLS LAST, p.lastmodifiedon DESC NULLS LAST
                """, {**pparams, **filt_params, **pt_extra})
                for a in anchor:
                    a["track"], a["category"] = _fallback_track(a.get("statuscode"))
                anchor_source = "live"
                # True count of projects matching the scope+filters (incl. the
                # lifecycle type). The detail is no longer capped, so this equals
                # len(anchor); kept for the "Showing X of N" label.
                try:
                    cnt = _fetch(db, f"""
                        SELECT COUNT(*) AS n FROM dbo.project p
                        LEFT JOIN dbo.prj_ex4 x4 ON x4.prj_ex4_id = p.projectid AND x4.ownerid = p.ownerid
                        {anchor_join}
                        WHERE {proj_where} AND p.projectname IS NOT NULL AND LENGTH(p.projectname) > 1{filt_sql}{pw_anchor}
                    """, {**pparams, **filt_params, **pt_extra})
                    matched_total = int(cnt[0]["n"]) if cnt else len(anchor)
                except Exception:
                    matched_total = len(anchor)
                # Portfolio rollup: KPI totals over ALL matched projects of the
                # selected type (matches the now-uncapped detail below).
                rollup = _compute_rollup(db, proj_where, filt_sql, {**pparams, **filt_params}, pt)
                # Whole-scope Active/Inactive/Prospect split (ignores the type
                # filter) so the dashboard always shows the full lifecycle counts.
                rollup["byType"] = _type_breakdown(db, proj_where, filt_sql, {**pparams, **filt_params})
            except Exception as exc:
                errors["anchor_fallback"] = str(exc)
                anchor = []

        if not anchor:
            # Both the curated and the LIVE anchor came back empty → the current
            # scope + lifecycle type genuinely has no matching projects. This is
            # an empty scope, NOT a "cc_* needs seeding" situation (the live
            # fallback always runs), so report seeded=True so the UI shows the
            # "no projects match" state with the option to widen the type filter.
            return {"ok": True, "level": level, "seeded": True,
                    "scope_empty": True,
                    "selectedPtype": pt or "all",
                    "errors": errors or None,
                    "projects": [], "financials": [], "billing": [], "modules": [],
                    "integrations": [], "governance": [], "pipeline": [], "arr": {},
                    "pdef": {}, "prisk": {}, "transformCats": {},
                    "defectItems": [], "riskItems": [], "actionItems": []}

        # Curated path has no LIMIT, so the loaded set IS the matched total.
        matched_total = matched_total or len(anchor)

        pids = [a["projectid"] for a in anchor]
        pid_csv = ",".join(str(p) for p in pids)

        # Resolve Portfolio AVP (prj_ex4_16 holds a userid) → display name.
        avp_name_by_id: dict[str, str] = {}
        avp_int_ids = sorted({int(s) for a in anchor
                              if (s := str(a.get("avp_id") or "").strip()).lstrip("-").isdigit()})
        if avp_int_ids:
            try:
                csv = ",".join(str(i) for i in avp_int_ids)
                for r in _fetch(db, f"""
                    SELECT userid, TRIM(COALESCE(firstname,'') || ' ' || COALESCE(lastname,'')) AS nm
                    FROM dbo.assignmentuserview WHERE userid IN ({csv})
                """):
                    avp_name_by_id[str(r["userid"])] = (r["nm"] or "").strip()
            except Exception as exc:
                errors["avp_names"] = str(exc)

        # ── 2. Milestones from projectmodule (plan + trail) ──
        mod_by_pid: dict[int, list[dict]] = {p: [] for p in pids}
        try:
            mod_rows = _fetch(db, f"""
                SELECT relatedtoid AS pid, subject, statuscodeid, statusid,
                       fsddelivery, fsdsignoff, devdelivery, preuatdemo,
                       sitstartdate, uatstartdate, uatsignoff, golive,
                       trailfsdsignoff, traildevdelivery, trailpreuatdemo,
                       trailsitstartdate, trailuatstartdate, trailuatsignoff, trailgolive
                FROM dbo.projectmodule
                WHERE relatedtotypeid = 113 AND relatedtoid IN ({pid_csv})
            """)
            for r in mod_rows:
                mod_by_pid.setdefault(r["pid"], []).append(r)
        except Exception as exc:
            errors["modules"] = str(exc)
            mod_rows = []

        # ── 3. Build project objects ──
        projects = []
        this_q_start = date(date.today().year if date.today().month >= 4 else date.today().year - 1, 4, 1)
        for a in anchor:
            done = _is_complete(a.get("statuscode"))
            proj_mods = mod_by_pid.get(a["projectid"], [])
            states, plan, act = _build_milestones(proj_mods, done)
            # go-live drives both the "this quarter" flag and lifecycle type.
            golive = _project_golive(proj_mods, a.get("enddate"))
            this_q = bool(golive and golive >= this_q_start)
            ptype = classify_project_type(a.get("statuscode"), golive)
            # has_plan: does this project actually have any planned milestone date?
            has_plan = any(x != "—" for x in plan)
            _rtc_raw = str(a.get("rev_type_code") or "").strip()
            rev_type_code = int(_rtc_raw) if _rtc_raw.lstrip("-").isdigit() else None
            avp_id = str(a.get("avp_id") or "").strip()
            projects.append({
                "name": str(a["projectname"] or f"Project {a['projectid']}")[:42],
                "pid": a["projectid"],
                "customer": str(a["companyname"] or "—"),
                "account": str(a["companyname"] or "—"),
                "avp": avp_name_by_id.get(avp_id) or None,
                "avpId": avp_id or None,
                "track": a["track"],
                "cat": a["category"],
                "billable": str(a.get("billable") or "").replace(".0", "") in ("1", "true"),
                # "Monitor Project" custom field (prj_ex4_98): 'Yes' | 'No' | '' (unset)
                "monitored": str(a.get("monitored") or "").strip(),
                # Revenue Type (prj_ex4_67) — code + label for the Revenue filter
                "revTypeCode": rev_type_code,
                "revType": _REV_TYPE_LABELS.get(rev_type_code or 0, ""),
                "health": _health(a.get("statuscode"), a.get("isescalated"), states, has_plan),
                "thisQ": this_q,
                # Lifecycle classification (source of truth: project_lifecycle.py)
                "ptype": ptype,
                "started": is_started(a.get("statuscode")),
                "goLive": _d(golive),
                "states": states, "proj": plan, "act": act,
            })

        # ── 4. Financials from project_revenue ──
        financials = []
        try:
            fin_rows = _fetch(db, f"""
                SELECT project_id AS pid,
                       MAX(project_service_value) AS svc,
                       MAX(revenue_recognized)    AS recog,
                       MAX(cumulative_invoice)    AS invoice,
                       MAX(unbilled)              AS unbilled
                FROM dbo.project_revenue
                WHERE project_id IN ({pid_csv})
                GROUP BY project_id
            """)
            fmap = {r["pid"]: r for r in fin_rows}
            for a in anchor:
                f = fmap.get(a["projectid"], {})
                contract = _lakhs(f.get("svc"))
                rev_td = _lakhs(f.get("recog"))
                # cost till date ≈ recognised - margin estimate, fall back to invoice
                inv = _lakhs(f.get("invoice"))
                cost_td = round(rev_td * 0.62, 1) if rev_td else round(inv * 0.6, 1)
                financials.append({
                    "p": str(a["projectname"] or "")[:42],
                    "contract": contract or round(rev_td * 1.4, 1),
                    "revTD": rev_td,
                    "costTD": cost_td,
                    "invoice": inv,
                    # WIP floored at 0 — over-billed projects (negative raw
                    # unbilled) must not subtract from the Unbilled (WIP) KPI or
                    # its drill-down; over-billing is a separate signal.
                    "unbilled": max(_lakhs(f.get("unbilled")), 0.0),
                    # Exact rupee figures (for precise display / tooltips).
                    "invoiceRs": _rupees(f.get("invoice")),
                    "revRs": _rupees(f.get("recog")),
                    "unbilledRs": max(_rupees(f.get("unbilled")), 0),
                    "contractRs": _rupees(f.get("svc")),
                })
        except Exception as exc:
            errors["financials"] = str(exc)

        # ── 5. Defects (pdef) from cases ──
        # We aggregate into pdef (counts, unchanged) AND emit the underlying real
        # rows as defect_items so the front-end can list exactly the records behind
        # every defect number (phase is a priority proxy; open/sev/age are real).
        pdef: dict[str, dict] = {}
        defect_items: list[dict] = []
        nm = {a["projectid"]: str(a["projectname"] or "")[:42] for a in anchor}
        # Decode the real CRM severity lookup (dbo.mdvseverityview) → labels.
        sev_map: dict[int, str] = {}
        try:
            for r in _fetch(db, "SELECT valueid, name FROM dbo.mdvseverityview"):
                sev_map[int(r["valueid"])] = str(r["name"])
        except Exception:
            sev_map = {1: "Trivial", 2: "Minor", 3: "Normal", 4: "Critical", 5: "Major",
                       6: "Feature", 7: "Solution Discussion", 8: "Discussion Needed",
                       9: "Blocker", 10: "Enhancement"}
        sev_map.setdefault(0, "Not Specified")
        sev_map.setdefault(10000, "Not Specified")

        def _sev_label(v: Any) -> str:
            if v is None:
                return "—"
            try:
                return sev_map.get(int(v), str(v))
            except Exception:
                return str(v)
        try:
            case_rows = _fetch(db, f"""
                SELECT caseid, relatedtoid AS pid, statusid, priorityid, severity,
                       subject, createdon, currentowner
                FROM dbo.cases
                WHERE relatedtotypeid = 113 AND relatedtoid IN ({pid_csv})
            """)
            agg: dict[int, dict] = {}
            for c in case_rows:
                pid = c["pid"]
                d = agg.setdefault(pid, {"dev": [0, 0], "sit": [0, 0], "uat": [0, 0]})
                # no phase field on cases → distribute by priority as a proxy
                pr = int(c.get("priorityid") or 0)
                bucket = "uat" if pr >= 4 else "sit" if pr >= 2 else "dev"
                openf = 1 if int(c.get("statusid") or 0) != 5 else 0
                d[bucket][0] += 1
                d[bucket][1] += openf
                cdate = _to_date(c.get("createdon"))
                defect_items.append({
                    "id": "CASE-" + str(c.get("caseid") or ""),
                    "p": nm.get(pid, str(pid)),
                    "subj": str(c.get("subject") or "")[:70],
                    "phase": bucket,
                    "sev": _sev_label(c.get("severity")),
                    "open": bool(openf),
                    "age": (date.today() - cdate).days if cdate else None,
                    "owner": str(c.get("currentowner") or "—"),
                })
            # Real-only: defect counts come straight from dbo.cases (the same rows
            # the drill-down lists), so headline == drill list exactly. Projects
            # with no real cases show 0 (no seeded cc_defect_agg fallback).
            for a in anchor:
                pid = a["projectid"]
                d = agg.get(pid) or {"dev": [0, 0], "sit": [0, 0], "uat": [0, 0]}
                pdef[str(a["projectname"] or "")[:42]] = {
                    **d, "pShare": 0.45, "cShare": 0.55,
                }
        except Exception as exc:
            errors["defects"] = str(exc)

        # ── 6. Risks & actions — real rows from dbo.risk / dbo.activity, with the
        # counts (prisk) derived from those very rows so headline == drill list.
        # No seeded cc_risk_agg fallback; projects with no real rows show 0.
        prisk: dict[str, dict] = {}
        risk_items: list[dict] = []
        action_items: list[dict] = []
        try:
            for r in _fetch(db, f"""
                SELECT customobjectid, subject, statusid, projectid, createdon
                FROM dbo.risk
                WHERE projectid IN ({pid_csv})
                ORDER BY createdon DESC NULLS LAST
                LIMIT 2000
            """):
                cdate = _to_date(r.get("createdon"))
                risk_items.append({
                    "id": "RISK-" + str(r.get("customobjectid") or ""),
                    "p": nm.get(r["projectid"], str(r["projectid"])),
                    "subj": str(r.get("subject") or "")[:70],
                    "open": int(r.get("statusid") or 0) == 1,
                    "age": (date.today() - cdate).days if cdate else None,
                })
        except Exception as exc:
            errors["risk_items"] = str(exc)
        try:
            for r in _fetch(db, f"""
                SELECT activityid, subject, duedate, relatedtoid AS pid
                FROM dbo.activity
                WHERE relatedtotype = 113 AND relatedtoid IN ({pid_csv})
                ORDER BY duedate NULLS LAST
                LIMIT 2000
            """):
                dd = _to_date(r.get("duedate"))
                action_items.append({
                    "id": "ACT-" + str(r.get("activityid") or ""),
                    "p": nm.get(r["pid"], str(r["pid"])),
                    "subj": str(r.get("subject") or "")[:70],
                    "open": (dd is None or dd >= date.today()),
                    "due": _d(r.get("duedate")),
                })
        except Exception as exc:
            errors["action_items"] = str(exc)
        # counts derived from the exact rows above (guaranteed to match the drill list)
        for a in anchor:
            pn = str(a["projectname"] or "")[:42]
            prisk[pn] = {
                "ro": sum(1 for x in risk_items if x["p"] == pn and x["open"]),
                "rc": sum(1 for x in risk_items if x["p"] == pn and not x["open"]),
                "ao": sum(1 for x in action_items if x["p"] == pn and x["open"]),
                "ac": sum(1 for x in action_items if x["p"] == pn and not x["open"]),
            }

        # ── 7. Modules list ──
        modules = []
        try:
            name_by_pid = {a["projectid"]: str(a["projectname"] or "")[:42] for a in anchor}
            scode_map = {5400: "active", 5401: "done", 5402: "delayed"}
            for r in (mod_rows or []):
                pid = r["pid"]
                sc = int(r.get("statuscodeid") or 0)
                gl = _to_date(r.get("golive"))
                status = ("done" if gl and gl < date.today() else
                          "active" if (r.get("devdelivery") or r.get("sitstartdate")) else "future")
                modules.append({
                    "p": name_by_pid.get(pid, str(pid)),
                    "drop": "Drop " + str((len(modules) % 4) + 1),
                    "name": str(r.get("subject") or "Module")[:34],
                    "status": status,
                    "defT": 0, "defO": 0,  # filled below from cases share
                })
            # rough defect attribution to modules (even split of project's defects)
            for a in anchor:
                pn = name_by_pid[a["projectid"]]
                pmods = [m for m in modules if m["p"] == pn]
                pd = pdef.get(pn, {})
                tot = sum(pd.get(k, [0, 0])[0] for k in ("dev", "sit", "uat"))
                opn = sum(pd.get(k, [0, 0])[1] for k in ("dev", "sit", "uat"))
                if pmods:
                    per_t, per_o = tot // len(pmods), opn // len(pmods)
                    for m in pmods:
                        m["defT"], m["defO"] = per_t, per_o
        except Exception as exc:
            errors["modules_list"] = str(exc)

        # ── 8. Supplementary cc_* tables ──
        integrations, governance, billing = [], [], []
        pipeline, arr = [], {}
        name_by_pid = {a["projectid"]: str(a["projectname"] or "")[:42] for a in anchor}
        try:
            for r in _fetch(db, f"""
                SELECT projectid, name, itype, status, defect_total, defect_open
                FROM dbo.cc_integration WHERE projectid IN ({pid_csv})
            """):
                integrations.append({
                    "p": name_by_pid.get(r["projectid"], ""), "name": r["name"],
                    "type": r["itype"], "status": r["status"],
                    "defT": int(r["defect_total"] or 0), "defO": int(r["defect_open"] or 0),
                })
        except Exception as exc:
            errors["integrations"] = str(exc)

        try:
            for r in _fetch(db, f"""
                SELECT projectid, sc_plan, sc_actual, vd_plan, vd_actual
                FROM dbo.cc_governance WHERE projectid IN ({pid_csv})
            """):
                sc_ok = r["sc_actual"] is not None
                vd_ok = r["vd_actual"] is not None
                sc_late = sc_ok and _to_date(r["sc_actual"]) and _to_date(r["sc_plan"]) and _to_date(r["sc_actual"]) > _to_date(r["sc_plan"])
                governance.append({
                    "p": name_by_pid.get(r["projectid"], ""),
                    "scPlan": _d(r["sc_plan"]), "scAct": _d(r["sc_actual"]),
                    "vdPlan": _d(r["vd_plan"]), "vdAct": _d(r["vd_actual"]),
                    "scStatus": "missed" if not sc_ok else ("late" if sc_late else "ok"),
                    "vdStatus": "missed" if not vd_ok and sc_ok else ("pending" if not vd_ok else "ok"),
                })
        except Exception as exc:
            errors["governance"] = str(exc)

        try:
            for r in _fetch(db, f"""
                SELECT projectid, milestone, status, invoice_amt, received_amt,
                       due_date, revised_date, ageing_days
                FROM dbo.cc_billing_milestone WHERE projectid IN ({pid_csv})
            """):
                billing.append({
                    "p": name_by_pid.get(r["projectid"], ""), "ms": r["milestone"],
                    "status": "closed" if r["status"] == "closed" else "open",
                    "inv": round(_safe_float(r["invoice_amt"])),
                    "recv": round(_safe_float(r["received_amt"])),
                    "due": _d(r["due_date"]),
                    "revised": _d(r["revised_date"]) if r["revised_date"] else None,
                    "ageing": int(r["ageing_days"] or 0),
                })
        except Exception as exc:
            errors["billing"] = str(exc)

        # pipeline & ARR are portfolio-level — always full set
        try:
            for r in _fetch(db, "SELECT stage_key, revenue, cost, accent FROM dbo.cc_pipeline ORDER BY display_order"):
                pipeline.append({"k": r["stage_key"], "rev": round(_safe_float(r["revenue"])),
                                 "cost": round(_safe_float(r["cost"])), "ac": r["accent"]})
            ar = _fetch(db, "SELECT ytd, confirmed, pipeline, deals FROM dbo.cc_arr WHERE id = 1")
            if ar:
                arr = {"ytd": round(_safe_float(ar[0]["ytd"])),
                       "confirmed": round(_safe_float(ar[0]["confirmed"])),
                       "pipeline": round(_safe_float(ar[0]["pipeline"])),
                       "deals": int(ar[0]["deals"] or 0)}
        except Exception as exc:
            errors["pipeline_arr"] = str(exc)

        transform_cats = {
            "Digital": "Digital channel & experience transformation — re-platforming customer journeys, portals and omnichannel experiences.",
            "LOS": "Loan Origination System — end-to-end digital lending origination platforms.",
            "OCP": "Originations & Collections Platform — core lending lifecycle, origination through collections.",
            "AI": "AI / GenAI programmes — automation, decisioning and intelligence-led capabilities.",
            "Mobile": "Mobile-first platforms — native apps and mobile experiences.",
            "New Logo": "Net-new strategic clients — complex, high-value engagements only.",
        }

        return {
            "ok": True, "level": level, "seeded": True,
            "anchor_source": anchor_source,
            "matchedTotal": matched_total,
            "selectedPtype": pt or "all",
            "rollup": rollup,
            "errors": errors or None,
            "projects": projects,
            "financials": financials,
            "billing": billing,
            "modules": modules,
            "integrations": integrations,
            "governance": governance,
            "pipeline": pipeline,
            "arr": arr,
            "pdef": pdef,
            "prisk": prisk,
            "defectItems": defect_items,
            "riskItems": risk_items,
            "actionItems": action_items,
            "transformCats": transform_cats,
        }
    finally:
        db.close()
