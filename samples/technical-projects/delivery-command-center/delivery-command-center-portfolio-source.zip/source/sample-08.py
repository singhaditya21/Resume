"""API layer (FastAPI routers)."""

