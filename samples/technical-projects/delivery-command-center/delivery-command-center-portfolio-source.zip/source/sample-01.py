"""Delivery Command Center — minimal FastAPI host for the source slice.

README_SLICE.md says the slice ships no entrypoint on purpose (it mirrors the
upstream monorepo). This host provides the namespace the verbatim slice expects
(`router`, `logger`, `asyncio`, `JSONResponse`) and mounts the 4 endpoints,
without modifying any slice file so they keep diffing cleanly upstream.

It also serves the dashboard UI at `/`: a vanilla-JS port of
frontend/src/components/command-centre/Option2Panel.tsx driving the compiled
option2Template (static/option2Template.js, built with esbuild from the verbatim
.ts — zero imports, so it compiles standalone).
"""
from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("delivery-command-center")

app = FastAPI(title="Delivery Command Center", version="0.2.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

router = APIRouter(prefix="/api")

# Execute the verbatim slice into a namespace that provides what it references.
_slice = BASE_DIR / "project_intel" / "api" / "routes_command_centre.py"
_ns = {
    "__builtins__": __builtins__,
    "__name__": "routes_command_centre",
    "__file__": str(_slice),
    "router": router,
    "logger": logger,
    "asyncio": asyncio,
    "JSONResponse": JSONResponse,
}
exec(compile(_slice.read_text(encoding="utf-8"), str(_slice), "exec"), _ns)

app.include_router(router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


@app.get("/healthz")
async def healthz():
    return {"status": "ok", "app": "delivery-command-center"}


# ── Dashboard UI ─────────────────────────────────────────────────────────────
# Vanilla-JS port of Option2Panel.tsx: same fetch contract, same iframe srcdoc
# rendering, same postMessage wiring (ptype dropdown up, AI signals down), same
# auto-grow behaviour. Filter toolbar = AVP + Account multi-selects (facets).
UI_HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Delivery Command Center</title>
<style>
:root{color-scheme:light}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#FBF8F3;color:#0f172a}
.wrap{max-width:1280px;margin:0 auto;padding:14px 16px 40px}
.toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:10px 14px;box-shadow:0 1px 2px rgba(15,23,42,.05);margin-bottom:12px}
.brand{font-weight:600;font-size:.95rem;margin-right:6px}
.ms{position:relative}
.ms>button{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;background:#fff;border-radius:10px;padding:6px 10px;font-size:.82rem;cursor:pointer}
.ms>button b{font-weight:600;color:#0d9488}
.ms .menu{position:absolute;z-index:30;top:calc(100% + 6px);left:0;min-width:240px;max-height:280px;overflow:auto;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 10px 30px rgba(15,23,42,.12);padding:6px;display:none}
.ms.open .menu{display:block}
.ms label{display:flex;gap:8px;align-items:center;padding:6px 8px;border-radius:8px;font-size:.82rem;cursor:pointer}
.ms label:hover{background:#f1f5f9}
.clear{border:none;background:none;color:#64748b;font-size:.78rem;cursor:pointer;padding:6px 8px;border-radius:8px}
.clear:hover{background:#f1f5f9;color:#0f172a}
.state{display:flex;flex-direction:column;gap:12px;align-items:center;justify-content:center;min-height:340px;border:1px solid #e2e8f0;border-radius:16px;background:#fff;text-align:center;padding:28px}
.state .big{font-size:2rem}
.state p{max-width:460px;color:#475569;font-size:.9rem;margin:0}
.state button{border:1px solid #cbd5e1;background:#fff;border-radius:10px;padding:8px 16px;font-size:.85rem;font-weight:600;cursor:pointer}
.state button.primary{background:#0d9488;border-color:#0d9488;color:#fff}
.state.warn{border-color:#fcd34d;background:#fffbeb}
.state.err{border-color:#fecaca;background:#fef2f2}
iframe{width:100%;min-height:640px;border:none;display:block;border-radius:16px;background:#FBF8F3}
</style></head><body><div class="wrap">
<div class="toolbar">
  <span class="brand">Delivery Command Center</span>
  <div class="ms" id="ms-avp"><button type="button">Portfolio: <b>All</b></button><div class="menu"></div></div>
  <div class="ms" id="ms-acc"><button type="button">Account: <b>All</b></button><div class="menu"></div></div>
  <button class="clear" id="btn-clear" style="display:none">✕ Clear</button>
</div>
<div id="stage"><div class="state"><div class="big">⏳</div><p>Loading Portfolio Command Centre…</p></div></div>
</div>
<script src="/static/option2Template.js"></script>
<script>
const API = "/api";
const state = { ptype:"active", avps:[], accounts:[], avpOptions:[], accOptions:[], signalSeq:0 };
const stage = document.getElementById("stage");

function qs(extra){
  const q = new URLSearchParams({ level:"org" });
  if (state.avps.length) q.set("avp_ids", state.avps.join(","));
  if (state.accounts.length) q.set("accounts", state.accounts.join(","));
  if (state.ptype && state.ptype!=="all") q.set("ptype", state.ptype);
  for (const [k,v] of Object.entries(extra||{})) q.set(k,v);
  return q.toString();
}
async function api(path, opts){ const r = await fetch(API+path, opts); return r.json(); }

function renderState(cls, bigIcon, text, btnLabel, btnFn, primary){
  const div = document.createElement("div");
  div.className = "state "+(cls||"");
  div.innerHTML = '<div class="big">'+bigIcon+'</div><p></p>';
  div.querySelector("p").textContent = text;
  if (btnLabel){ const b=document.createElement("button"); if(primary) b.className="primary";
    b.textContent=btnLabel; b.onclick=btnFn; div.appendChild(b); }
  stage.replaceChildren(div);
}

// ── multi-select dropdowns (facets) ──
function buildMs(id, roleLabel, getOpts, getSel, setSel){
  const root = document.getElementById(id), btn = root.querySelector("button"), menu = root.querySelector(".menu");
  btn.onclick = (e)=>{ e.stopPropagation(); document.querySelectorAll(".ms.open").forEach(m=>m!==root&&m.classList.remove("open")); root.classList.toggle("open"); };
  document.addEventListener("click", ()=>root.classList.remove("open"));
  menu.onclick = (e)=>e.stopPropagation();
  root.refresh = ()=>{
    const sel = getSel();
    btn.innerHTML = roleLabel+": <b>"+(sel.length? sel.length+" selected" : "All")+"</b>";
    menu.replaceChildren(...getOpts().map(o=>{
      const l = document.createElement("label");
      const c = document.createElement("input"); c.type="checkbox"; c.checked = sel.includes(o.value);
      c.onchange = ()=>{ const s=getSel(); c.checked? s.push(o.value) : s.splice(s.indexOf(o.value),1); setSel(s); };
      l.appendChild(c); l.appendChild(document.createTextNode(o.label));
      return l;
    }));
    if (!getOpts().length){ const p=document.createElement("label"); p.textContent="(no options)"; menu.replaceChildren(p); }
  };
}
const msAvp = buildMs("ms-avp","Portfolio",()=>state.avpOptions,()=>state.avps,(s)=>{state.avps=s; onFilterChange();});
const msAcc = buildMs("ms-acc","Account",()=>state.accOptions,()=>state.accounts,(s)=>{state.accounts=s; onFilterChange();});
function refreshToolbar(){
  document.getElementById("ms-avp").refresh(); document.getElementById("ms-acc").refresh();
  document.getElementById("btn-clear").style.display = (state.avps.length||state.accounts.length)? "" : "none";
}
document.getElementById("btn-clear").onclick = ()=>{ state.avps=[]; state.accounts=[]; onFilterChange(); };
function onFilterChange(){ refreshToolbar(); load(); loadFacets(); }

async function loadFacets(){
  try{
    const d = await api("/command-centre/v2/facets?"+qs());
    if (!d || !d.ok) return;
    state.avpOptions = (d.avps||[]).map(a=>({value:a.id,label:a.name}));
    state.accOptions = (d.accounts||[]).map(c=>({value:c,label:c}));
    const allowed = new Set(state.accOptions.map(o=>o.value));
    state.accounts = state.accounts.filter(v=>allowed.has(v));
    refreshToolbar();
  }catch(e){ /* facets are non-fatal */ }
}

// ── signals (AI alerts/nudges/insights) → posted into the iframe ──
async function loadSignals(iframe){
  const win = iframe.contentWindow; if (!win) return;
  const seq = ++state.signalSeq;
  win.postMessage({ __cc:"signals", pending:true }, "*");
  try{
    const d = await api("/command-centre/v2/signals?"+qs());
    if (seq !== state.signalSeq) return;
    const w = iframe.contentWindow; if (!w) return;
    w.postMessage({ __cc:"signals", value: d && d.ok ? {alerts:d.alerts, nudges:d.nudges, insights:d.insights} : null }, "*");
  }catch(e){ /* iframe keeps rule-based signals */ }
}

// ── main load: fetch v2 → buildOption2Html → iframe srcdoc (auto-grow) ──
async function load(){
  renderState("", "⏳", "Loading Portfolio Command Centre…");
  let d;
  try{ d = await api("/command-centre/v2?"+qs()); }
  catch(e){ return renderState("err","⚠️","Failed to reach the API: "+e, "Retry", load); }
  if (!d || !d.ok) return renderState("err","⚠️", (d && d.error) || "Failed to load data.", "Retry", load);
  if (!d.seeded) return renderState("warn","🌱",
    "The dashboard combines live CRM data with delivery metadata held in the cc_* tables. Seed them once to get started.",
    "🌱 Seed data", async ()=>{ renderState("","⏳","Seeding…");
      const r = await api("/command-centre/v2/seed", {method:"POST"});
      r && r.ok ? load() : renderState("err","⚠️", (r&&r.error)||"Seed failed.", "Retry", load); }, true);
  if (!d.projects || !d.projects.length){
    const lbl = state.ptype==="all" ? "" : " "+state.ptype;
    return renderState("", "📭", "No"+lbl+" projects match the selected filters.",
      state.ptype!=="all" ? "Show all project types" : null,
      ()=>{ state.ptype="all"; load(); });
  }
  const iframe = document.createElement("iframe");
  iframe.title = "Portfolio Command Centre";
  iframe.setAttribute("scrolling","no");
  iframe.setAttribute("sandbox","allow-scripts allow-same-origin allow-modals allow-popups allow-downloads");
  iframe.srcdoc = CCTemplate.buildOption2Html(d);
  iframe.onload = ()=>{
    const win = iframe.contentWindow, doc = win && win.document;
    if (!doc) return;
    const measure = ()=>{ const h = doc.body ? doc.body.scrollHeight : 0; if (h>0) iframe.style.height = h+"px"; };
    measure();
    try{ if (win.ResizeObserver && doc.body) new win.ResizeObserver(measure).observe(doc.body); }catch(e){}
    [200,600,1200,2200,3500].forEach(t=>setTimeout(measure,t));
    loadSignals(iframe);
  };
  stage.replaceChildren(iframe);
}

// ptype dropdown lives INSIDE the dashboard iframe; it posts selection up.
window.addEventListener("message",(e)=>{
  const d = e.data;
  if (d && d.__cc==="ptype" && typeof d.value==="string"){
    state.ptype = (d.value==="all"||d.value==="inactive"||d.value==="prospect") ? d.value : "active";
    load();
  }
});

refreshToolbar(); load(); loadFacets();
</script></body></html>"""


@app.get("/", response_class=HTMLResponse)
async def index():
    return UI_HTML
