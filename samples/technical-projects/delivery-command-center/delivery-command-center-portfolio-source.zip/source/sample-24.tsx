import { Check, ChevronDown, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export interface MultiSelectOption {
  value: string;
  label: string;
}

interface MultiSelectProps {
  label: string;
  options: MultiSelectOption[];
  selected: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
  className?: string;
  /**
   * When set, the trigger renders as a "labeled field": a tiny baked-in role
   * label (e.g. "Portfolio") stacked above the current value, with a caret —
   * instead of the compact pill. Pairs with `allLabel` for the empty state.
   */
  roleLabel?: string;
  /** Value text shown when nothing is selected (e.g. "All accounts"). */
  allLabel?: string;
}

/**
 * Searchable checkbox dropdown for multi-selection. Built on the existing
 * Popover + Command + Badge primitives. The trigger shows the label and a count
 * badge; the panel is a searchable list of checkable options with a Clear action.
 *
 * Two trigger styles: a compact pill (default) and a "labeled field" (when
 * `roleLabel` is provided) that bakes the filter's role into the control.
 */
export function MultiSelect({
  label,
  options,
  selected,
  onChange,
  placeholder = "Search…",
  className,
  roleLabel,
  allLabel,
}: MultiSelectProps) {
  const toggle = (value: string) => {
    onChange(
      selected.includes(value)
        ? selected.filter((v) => v !== value)
        : [...selected, value],
    );
  };

  // Value summary for the labeled-field trigger: the single selection's label,
  // a count when many, else the "all" fallback.
  const valueText =
    selected.length === 0
      ? allLabel ?? `All ${label.toLowerCase()}s`
      : selected.length === 1
        ? options.find((o) => o.value === selected[0])?.label ?? "1 selected"
        : `${selected.length} selected`;

  const trigger = roleLabel ? (
    <Button
      variant="outline"
      role="combobox"
      className={cn(
        "h-auto min-w-[150px] justify-between gap-3 rounded-xl border-slate-300 bg-white px-3.5 py-1.5 text-left hover:border-teal-400 hover:bg-teal-50",
        className,
      )}
    >
      <span className="flex min-w-0 flex-col">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          {roleLabel}
        </span>
        <span className="flex items-center gap-1.5 text-sm font-bold text-slate-800">
          <span className="max-w-[160px] truncate">{valueText}</span>
          {selected.length > 1 && (
            <Badge variant="secondary" className="rounded-full px-1.5 py-0 text-[10px]">
              {selected.length}
            </Badge>
          )}
        </span>
      </span>
      <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
    </Button>
  ) : (
    <Button
      variant="outline"
      role="combobox"
      className={cn(
        "h-9 justify-between gap-2 rounded-full border-slate-300 bg-white/80 px-3 text-sm font-semibold text-slate-700 hover:border-teal-400 hover:bg-teal-50",
        className,
      )}
    >
      <span className="truncate">{label}</span>
      {selected.length > 0 && (
        <Badge variant="secondary" className="ml-1 rounded-full px-1.5 py-0 text-[10px]">
          {selected.length}
        </Badge>
      )}
      <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 opacity-50" />
    </Button>
  );

  return (
    <Popover>
      <PopoverTrigger asChild>{trigger}</PopoverTrigger>
      <PopoverContent className="w-[280px] p-0" align="start">
        <Command>
          <CommandInput placeholder={placeholder} />
          <CommandList>
            <CommandEmpty>No matches.</CommandEmpty>
            {selected.length > 0 && (
              <div className="flex items-center justify-between border-b px-3 py-1.5">
                <span className="text-xs text-muted-foreground">{selected.length} selected</span>
                <button
                  type="button"
                  onClick={() => onChange([])}
                  className="text-xs font-medium text-teal-700 hover:underline"
                >
                  Clear
                </button>
              </div>
            )}
            <CommandGroup>
              {options.map((opt) => {
                const isSel = selected.includes(opt.value);
                return (
                  <CommandItem
                    key={opt.value}
                    value={opt.label}
                    onSelect={() => toggle(opt.value)}
                    className="cursor-pointer"
                  >
                    <span
                      className={cn(
                        "mr-2 flex h-4 w-4 items-center justify-center rounded border",
                        isSel ? "border-teal-600 bg-teal-600 text-white" : "border-slate-300",
                      )}
                    >
                      {isSel && <Check className="h-3 w-3" />}
                    </span>
                    <span className="truncate">{opt.label}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
