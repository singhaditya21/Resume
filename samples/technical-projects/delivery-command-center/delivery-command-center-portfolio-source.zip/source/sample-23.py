"""Command Centre endpoints — extracted from project_intel/api/routes.py (lines 1420-1532).

Mount on a FastAPI router that provides `router`, `get_db`/SessionLocal and the
shared imports from the host app. Kept verbatim so it diffs cleanly upstream.
"""

# (Option 1 endpoints /command-centre/data and /command-centre/seed-sample-data
#  were removed in the dead-code cleanup — superseded by the v2 endpoints below.)
# ---------------------------------------------------------------------------

@router.get("/command-centre/v2")
async def command_centre_v2(
    level: str = "org",
    project_id: int | None = None,
    portfolio_id: int | None = None,
    account_id: int | None = None,
    avp_ids: str | None = None,
    accounts: str | None = None,
    ptype: str | None = None,
):
    """
    Aggregated data for the Option 2 dashboard. Same filter contract as Option 1,
    plus an `account_id` scope for the Portfolio→Account→Project drill-down.
    `avp_ids` and `accounts` are optional comma-separated multi-select filters
    (Portfolio AVP userids and account/company names) — see /command-centre/v2/facets
    for the full option lists. `ptype` is the lifecycle filter
    (active|inactive|prospect; anything else = all). Combines live CRM data
    (projects, modules, revenue, defects, risks) with the supplementary
    dbo.cc_* tables. See docs/DATA_LINEAGE.md.
    """
    try:
        from project_intel.services.command_centre_v2_service import build_command_centre_v2
        avp_list = [s.strip() for s in (avp_ids or "").split(",") if s.strip()]
        acc_list = [s.strip() for s in (accounts or "").split(",") if s.strip()]
        result = await asyncio.to_thread(
            build_command_centre_v2, level, project_id, portfolio_id, account_id,
            avp_list, acc_list, ptype,
        )
        return result
    except Exception as exc:
        logger.exception("command_centre_v2 failed")
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@router.get("/command-centre/v2/facets")
async def command_centre_v2_facets(
    level: str = "org",
    project_id: int | None = None,
    portfolio_id: int | None = None,
    account_id: int | None = None,
    avp_ids: str | None = None,
    accounts: str | None = None,
):
    """Scoped option lists for the Option 2 multi-select filters.

    Accounts are narrowed to the current scope and, when provided, to the
    selected Portfolio AVP ids so the second filter depends on the first.
    """
    try:
        from project_intel.services.command_centre_v2_service import build_command_centre_v2_facets
        avp_list = [s.strip() for s in (avp_ids or "").split(",") if s.strip()]
        acc_list = [s.strip() for s in (accounts or "").split(",") if s.strip()]
        return await asyncio.to_thread(
            build_command_centre_v2_facets,
            level, project_id, portfolio_id, account_id, avp_list, acc_list,
        )
    except Exception as exc:
        logger.exception("command_centre_v2_facets failed")
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@router.get("/command-centre/v2/signals")
async def command_centre_v2_signals(
    level: str = "org",
    project_id: int | None = None,
    portfolio_id: int | None = None,
    account_id: int | None = None,
    avp_ids: str | None = None,
    accounts: str | None = None,
    ptype: str | None = None,
):
    """AI-generated Alerts / Nudges / Insights for the current scope. Grounded in
    a factual digest of the live v2 data. Returns ok=False on any failure so the
    dashboard falls back to its rule-based signals.
    """
    try:
        from project_intel.services.command_centre_signals import build_command_centre_signals
        avp_list = [s.strip() for s in (avp_ids or "").split(",") if s.strip()]
        acc_list = [s.strip() for s in (accounts or "").split(",") if s.strip()]
        return await asyncio.to_thread(
            build_command_centre_signals,
            level, project_id, portfolio_id, account_id, avp_list, acc_list, ptype,
        )
    except Exception as exc:
        logger.exception("command_centre_v2_signals failed")
        return JSONResponse({"ok": False, "source": "fallback", "error": str(exc)}, status_code=200)


# /command-centre/hierarchy and /command-centre/v2/email were removed in the
# dead-code cleanup — the hierarchy navigator (HierarchyNav) and the dashboard
# Email button were both removed from the frontend, so these had no callers.


@router.post("/command-centre/v2/seed")
async def command_centre_v2_seed():
    """
    Creates the dbo.cc_* supplementary tables and seeds Option-2-only dimensions
    (track/category, governance, integrations, milestone billing, pipeline, ARR)
    against a curated set of real anchor projects. Idempotent.
    """
    try:
        from project_intel.services.command_centre_v2_seed import seed_v2
        result = await asyncio.to_thread(seed_v2)
        return result
    except Exception as exc:
        logger.exception("command_centre_v2_seed failed")
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


