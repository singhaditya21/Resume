"""
The run engine: one execution of the inject pipeline for a single source.

``RunEngine.execute_run`` is the spine of the whole injector. It:

1. Acquires the per-source Postgres advisory lock (cross-process) plus an in-proc
   ``asyncio.Lock`` (same-process), so two runs of the *same* source never overlap
   while different sources stay concurrent. A manual trigger that finds a run in
   progress raises :class:`RunInProgress` (the ops API maps it to HTTP 409).
2. Streams ``source.discover`` — ``since=last_success`` for incremental runs,
   ``None`` for full runs (a full enumeration is what makes set-difference delete
   detection safe).
3. Classifies the discover against the ledger via :mod:`.diff` into new / changed /
   unchanged / deletion-candidates, and handles inline source-signalled deletes
   (e.g. Document360 ``status != 3``).
4. Processes ``new + changed`` docs with bounded parallelism: a doc-level semaphore
   (``MAX_DOC_CONCURRENCY``), a tighter embed semaphore (``EMBED_CONCURRENCY``) to
   protect the shared GPU, and CPU-bound parse/chunk pushed to a thread pool.
5. Per doc, in strict order: fetch → (re-hash & re-check) → parse → chunk → embed →
   **upsert (delete-then-insert) into Milvus** → **only then** mark the ledger
   ``INDEXED``. The vector store is the source of truth; the ledger is committed
   *after* the write so a crash between them re-does the doc (idempotent) instead of
   marking a doc done that was never written.
6. Applies guarded deletions (full runs above the seen-ratio guard only).
7. Finishes the run row and releases the lock in ``finally``.

A single doc's failure is isolated: it is marked ``ERROR`` in the ledger and the run
continues. The run only fails wholesale on an infrastructure error (discover blew up,
lock lost, etc.).
"""
from __future__ import annotations

import asyncio
from typing import Any, Mapping, Optional, Protocol, Sequence, runtime_checkable

import structlog

from zeno_injector.config import Settings
from zeno_injector.contracts import (
    Chunk,
    Chunker,
    DocRef,
    DocState,
    DocStatus,
    Embedder,
    EmbeddedChunk,
    FetchedDoc,
    Ledger,
    RunStats,
    RunTrigger,
    Section,
    Source,
    VectorSink,
    content_sha256,
)
from zeno_injector.orchestrator.diff import (
    Plan,
    classify,
    compute_seen_ratio,
    guard_ok,
    source_signalled_deletes,
)

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
class RunInProgress(RuntimeError):
    """Raised when a run is requested but one is already active for the source.

    The ops API maps this to HTTP 409 Conflict. It carries ``source_id`` so the
    handler can build a precise message without leaking internals.
    """

    def __init__(self, source_id: str) -> None:
        super().__init__(f"a run is already in progress for source '{source_id}'")
        self.source_id = source_id


class DocProcessingError(RuntimeError):
    """Wraps any per-doc failure with its doc_id for isolated error handling.

    The engine catches these (and any other exception) per doc, marks the ledger
    ``ERROR``, increments the failure counter and keeps going — one bad document
    never fails the whole run.
    """

    def __init__(self, doc_id: str, cause: BaseException) -> None:
        super().__init__(f"failed processing doc {doc_id}: {cause!r}")
        self.doc_id = doc_id
        self.cause = cause


# ---------------------------------------------------------------------------
# Sibling-group plug points (injected; defined as Protocols to avoid import cycles)
# ---------------------------------------------------------------------------
@runtime_checkable
class ParserRouter(Protocol):
    """Routes a :class:`FetchedDoc` to the right parser and returns clean Sections.

    Implemented by the parsing group. Sync because parsing is CPU-bound — the engine
    runs it via :func:`asyncio.to_thread` so it never blocks the event loop. It must
    never place base64 image data into Section text (OCR captions only).
    """

    def parse(self, doc: FetchedDoc) -> Sequence[Section]: ...


@runtime_checkable
class SourceRegistry(Protocol):
    """Lookup of configured sources by id, built from sources.yaml at startup."""

    def get(self, source_id: str) -> Source: ...

    def __contains__(self, source_id: str) -> bool: ...


# ---------------------------------------------------------------------------
# RunEngine
# ---------------------------------------------------------------------------
class RunEngine:
    """Executes inject runs for the configured sources.

    All collaborators are injected so the engine is trivially testable and never
    reaches for globals. One engine instance is shared by the scheduler and the ops
    API; per-source in-process locks live here so both entry points coordinate.
    """

    def __init__(
        self,
        settings: Settings,
        ledger: Ledger,
        sink: VectorSink,
        embedder: Embedder,
        parser_router: ParserRouter,
        chunker: Chunker,
        sources: SourceRegistry,
        artifact_store: Optional[Any] = None,
    ) -> None:
        self._settings = settings
        self._ledger = ledger
        self._sink = sink
        self._embedder = embedder
        self._parser_router = parser_router
        self._chunker = chunker
        self._sources = sources
        # Optional MinIO artifact store. When set, every doc's AI-ready markdown +
        # raw source are persisted and their URLs ride on each chunk's metadata.
        self._artifact_store = artifact_store

        # Per-source in-process mutexes: a manual trigger and a scheduled tick in the
        # SAME process can race; these serialize them. Cross-process overlap is
        # handled by the ledger's pg advisory lock. Created lazily, one per source.
        self._inproc_locks: dict[str, asyncio.Lock] = {}
        # Outbound-embed throttle shared across ALL docs in a run: the GPU is the
        # scarce resource, so even with 8 docs in flight we never have more than
        # EMBED_CONCURRENCY embed calls outstanding.
        self._embed_sem = asyncio.Semaphore(max(1, settings.EMBED_CONCURRENCY))

    # ----- lock helpers ----------------------------------------------------
    def _inproc_lock(self, source_id: str) -> asyncio.Lock:
        lock = self._inproc_locks.get(source_id)
        if lock is None:
            lock = asyncio.Lock()
            self._inproc_locks[source_id] = lock
        return lock

    def is_running(self, source_id: str) -> bool:
        """Best-effort same-process check used by the scheduler/ops status."""
        lock = self._inproc_locks.get(source_id)
        return bool(lock and lock.locked())

    # ----- public entry point ---------------------------------------------
    async def execute_run(
        self,
        source_id: str,
        trigger: RunTrigger,
        full: bool,
        limit: Optional[int] = None,
    ) -> RunStats:
        """Run the pipeline once for ``source_id``.

        Acquires both locks, classifies, processes, reconciles deletions, and always
        finishes the run row + releases the lock. Raises :class:`RunInProgress` if a
        run is already active for this source (409 on a manual trigger).
        """
        source = self._sources.get(source_id)

        inproc = self._inproc_lock(source_id)
        if inproc.locked():
            # Don't block — a manual trigger must fail fast as 409. Scheduled ticks
            # are already coalesced by APScheduler, so reaching here means a genuine
            # overlap we should reject rather than queue.
            raise RunInProgress(source_id)

        async with inproc:
            got_pg_lock = await self._ledger.try_acquire_source_lock(source_id)
            if not got_pg_lock:
                # Another replica owns the cross-process lock.
                raise RunInProgress(source_id)

            stats = await self._ledger.start_run(source_id, trigger, full)
            log = logger.bind(
                run_id=stats.run_id,
                source_id=source_id,
                trigger=trigger.value,
                full=full,
            )
            log.info("run.start")
            try:
                await self._run_body(source, stats, full, log, limit)
            except Exception as exc:  # noqa: BLE001 — infra failure fails the run
                stats.error = repr(exc)
                log.error("run.failed", error=str(exc), exc_info=True)
                raise
            finally:
                try:
                    await self._ledger.finish_run(stats)
                finally:
                    await self._ledger.release_source_lock(source_id)
                log.info(
                    "run.finish",
                    discovered=stats.docs_discovered,
                    changed=stats.docs_changed,
                    embedded=stats.docs_embedded,
                    failed=stats.docs_failed,
                    deleted=stats.docs_deleted,
                    chunks=stats.chunks_upserted,
                    error=stats.error,
                )
            return stats

    # ----- run body --------------------------------------------------------
    async def _run_body(
        self,
        source: Source,
        stats: RunStats,
        full: bool,
        log: structlog.stdlib.BoundLogger,
        limit: Optional[int] = None,
    ) -> None:
        source_id = stats.source_id

        # Where to start the discover from. Full runs enumerate everything (since=None)
        # so set-difference deletion is safe; incremental runs only pull changes after
        # the last successful run.
        since = None if full else await self._last_success_at(source_id)

        # Materialize the discover. We need the full list anyway to compute the
        # deletion set, and discover yields cheap DocRefs (no payloads), so this is
        # bounded by the doc *count*, not their content.
        discovered: list[DocRef] = []
        async for ref in source.discover(since):
            discovered.append(ref)
            # `limit` is for proof/test runs only. It caps discovery, so it is NOT
            # an exhaustive enumeration — delete-detection must stay off (the caller
            # uses full=False for limited runs, which the guard already requires).
            if limit and len(discovered) >= limit:
                log.info("run.discover_limited", limit=limit)
                break
        stats.docs_discovered = len(discovered)
        log.info("run.discovered", count=len(discovered), since=str(since))

        known_ids = await self._ledger.list_known_ids(source_id)
        ledger_states = await self._load_states(source_id, discovered, known_ids)

        plan = classify(known_ids, discovered, ledger_states)
        log.info(
            "run.classified",
            new=len(plan.new),
            changed=len(plan.changed),
            unchanged=len(plan.unchanged),
            delete_candidates=len(plan.deleted),
        )

        # Inline, source-signalled deletes (e.g. D360 status != published). These are
        # explicit and bypass the full-run guard — the source told us to remove them.
        await self._handle_signalled_deletes(discovered, stats, log)

        # Process new + changed with bounded parallelism.
        await self._process_docs(source, plan, stats, log)

        # Guarded set-difference deletions (full runs only, above the seen-ratio guard).
        await self.handle_deletions(plan, known_ids, full, stats, log)

    async def _last_success_at(self, source_id: str):
        """Last successful run boundary for incremental discover.

        The ledger owns run history; we ask it for the high-water mark. If the ledger
        exposes a typed accessor we use it, otherwise an incremental run with no prior
        success falls back to a full enumeration (since=None) to self-heal.
        """
        getter = getattr(self._ledger, "last_success_at", None)
        if getter is None:
            return None
        return await getter(source_id)

    async def _load_states(
        self,
        source_id: str,
        discovered: Sequence[DocRef],
        known_ids: set[str],
    ) -> Mapping[str, DocState]:
        """Fetch DocState for every discovered doc the ledger already knows.

        Prefer a batch accessor (``get_doc_states``) to avoid N round-trips; fall back
        to per-doc ``get_doc_state`` if only that exists. Docs unknown to the ledger
        simply have no entry and are classified as new.
        """
        wanted = [r.doc_id for r in discovered if r.doc_id in known_ids]
        if not wanted:
            return {}

        batch = getattr(self._ledger, "get_doc_states", None)
        if batch is not None:
            states = await batch(source_id, wanted)
            return dict(states)

        single = getattr(self._ledger, "get_doc_state", None)
        if single is None:
            # No way to read prior state -> treat everything known as changed by
            # returning empty (classify reprocesses non-INDEXED / hash-moved docs).
            return {}
        out: dict[str, DocState] = {}
        for doc_id in wanted:
            state = await single(doc_id)
            if state is not None:
                out[doc_id] = state
        return out

    # ----- doc processing --------------------------------------------------
    async def _process_docs(
        self,
        source: Source,
        plan: Plan,
        stats: RunStats,
        log: structlog.stdlib.BoundLogger,
    ) -> None:
        to_process = plan.to_process
        stats.docs_changed = len(to_process)
        if not to_process:
            return

        doc_sem = asyncio.Semaphore(max(1, self._settings.MAX_DOC_CONCURRENCY))

        async def _guarded(ref: DocRef) -> None:
            async with doc_sem:
                await self.process_doc(source, ref, stats, log)

        # return_exceptions=True so one task crashing can't cancel its siblings; per-doc
        # isolation is also enforced inside process_doc, this is a belt-and-suspenders
        # against truly unexpected failures (e.g. cancellation, OOM in a callback).
        results = await asyncio.gather(
            *(_guarded(ref) for ref in to_process),
            return_exceptions=True,
        )
        for ref, result in zip(to_process, results):
            if isinstance(result, BaseException) and not isinstance(result, asyncio.CancelledError):
                # process_doc already marked the ledger + counter for handled errors;
                # this only catches anything that escaped its try/except.
                log.error("run.doc.unhandled", doc_id=ref.doc_id, error=repr(result))

    async def process_doc(
        self,
        source: Source,
        ref: DocRef,
        stats: RunStats,
        log: structlog.stdlib.BoundLogger,
    ) -> None:
        """Fetch → re-hash/recheck → parse → chunk → embed → upsert → mark ledger.

        Strict ordering matters:

        * Milvus is written BEFORE the ledger is marked ``INDEXED`` (vector store is
          the truth; a crash in between just re-does an idempotent doc).
        * Upsert is delete-then-insert by ``doc_id`` so re-indexing never duplicates
          and stale chunks of a shrunken doc are removed.

        Any failure is caught, marked ``ERROR`` in the ledger, counted, and swallowed
        so the run continues.
        """
        dlog = log.bind(doc_id=ref.doc_id, title=ref.title)
        try:
            await self._ledger.upsert_doc_state(ref, DocStatus.PROCESSING)

            fetched = await source.fetch(ref)

            # Touched-but-identical short-circuit: when discover couldn't give us a
            # cheap content_hash, the change may be a no-op mtime bump. Compute the
            # authoritative hash now and, if it equals what we already indexed, skip
            # the expensive parse/embed and just refresh the ledger state.
            content_hash = ref.content_hash
            if content_hash is None:
                payload = self._hashable_payload(fetched)
                if payload is not None:
                    content_hash = content_sha256(payload)
                    if await self._unchanged_after_fetch(ref, content_hash):
                        dlog.info("run.doc.skip_identical")
                        await self._ledger.upsert_doc_state(
                            ref, DocStatus.INDEXED, content_hash=content_hash
                        )
                        return

            # CPU-bound parse + chunk go to a thread so the event loop stays free for
            # other docs' I/O. The parser guarantees no base64 in Section text.
            sections = await asyncio.to_thread(self._parser_router.parse, fetched)

            # Persist artifacts (AI-ready markdown + raw source) to MinIO and let
            # their URLs ride on every chunk so chat can "view source". Best-effort:
            # an artifact failure must never fail indexing.
            base_meta = self._base_metadata(ref)
            if self._artifact_store is not None:
                base_meta = {**base_meta, **await self._store_artifacts(ref, fetched, sections)}

            chunks = await asyncio.to_thread(
                self._chunk, ref.doc_id, sections, base_meta
            )
            if not chunks:
                dlog.warning("run.doc.no_chunks")
                # Nothing to index, but the doc still exists: drop any stale vectors
                # and record it as indexed-with-zero so we don't reprocess forever.
                await self._sink.delete_doc(ref.doc_id)
                await self._ledger.upsert_doc_state(
                    ref, DocStatus.INDEXED, chunk_count=0, content_hash=content_hash
                )
                return

            embedded = await self._embed_chunks(chunks)

            # ---- WRITE ORDER: Milvus first, ledger second ----
            inserted = await self._sink.upsert_doc(ref.doc_id, embedded)
            milvus_ids = [ec.chunk.chunk_id for ec in embedded]
            await self._ledger.upsert_doc_state(
                ref,
                DocStatus.INDEXED,
                chunk_count=inserted,
                milvus_chunk_ids=milvus_ids,
                content_hash=content_hash,
            )

            stats.docs_embedded += 1
            stats.chunks_upserted += inserted
            dlog.info("run.doc.indexed", chunks=inserted)

        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — isolate per-doc failure
            stats.docs_failed += 1
            dlog.error("run.doc.error", error=repr(exc), exc_info=True)
            try:
                await self._ledger.mark_error(ref.doc_id, repr(exc))
            except Exception as mark_exc:  # noqa: BLE001
                dlog.error("run.doc.mark_error_failed", error=repr(mark_exc))
            # Swallow: one doc must not fail the run.

    async def _embed_chunks(self, chunks: Sequence[Chunk]) -> list[EmbeddedChunk]:
        """Embed chunk texts in batches, throttled by the shared embed semaphore.

        Batches at ``EMBED_BATCH`` and serializes outbound calls through
        ``self._embed_sem`` so the GPU is never hit by more than ``EMBED_CONCURRENCY``
        requests across all in-flight docs. The returned vector length is asserted to
        equal ``MILVUS_DIM`` — a dim divergence silently destroys recall, so we fail
        the doc loudly instead.
        """
        batch_size = max(1, self._settings.EMBED_BATCH)
        dim = self._settings.MILVUS_DIM
        out: list[EmbeddedChunk] = []
        for start in range(0, len(chunks), batch_size):
            window = chunks[start : start + batch_size]
            texts = [c.text for c in window]
            async with self._embed_sem:
                vectors = await self._embedder.embed_passages(texts)
            if len(vectors) != len(window):
                raise ValueError(
                    f"embedder returned {len(vectors)} vectors for {len(window)} texts"
                )
            for chunk, vec in zip(window, vectors):
                if len(vec) != dim:
                    raise ValueError(
                        f"embedding dim {len(vec)} != expected {dim} for chunk "
                        f"{chunk.chunk_id}"
                    )
                out.append(EmbeddedChunk(chunk=chunk, embedding=vec))
        return out

    def _chunk(
        self,
        doc_id: str,
        sections: Sequence[Section],
        base_metadata: Mapping[str, object],
    ) -> list[Chunk]:
        return list(self._chunker.chunk(doc_id, sections, base_metadata))

    @staticmethod
    def _hashable_payload(fetched: FetchedDoc) -> Optional[str]:
        """The best text representation to hash for change detection.

        Prefer plain text, then HTML, then a marker derived from raw bytes length so
        binary docs still get a stable-ish signal. Returns None if there is genuinely
        nothing to hash (caller then proceeds without the short-circuit).
        """
        if fetched.text:
            return fetched.text
        if fetched.html:
            return fetched.html
        if fetched.content is not None:
            # Hash the bytes directly via content_sha256 over a length+repr marker is
            # wrong for binaries; instead signal "use bytes" by returning None so the
            # caller skips the text short-circuit. We keep binary change detection in
            # the source's content_hash (etag/size), which is the right layer.
            return None
        return None

    async def _unchanged_after_fetch(self, ref: DocRef, content_hash: str) -> bool:
        """Re-check the ledger after computing the authoritative hash post-fetch."""
        getter = getattr(self._ledger, "get_doc_state", None)
        if getter is None:
            return False
        state = await getter(ref.doc_id)
        if state is None:
            return False
        return (
            state.status is DocStatus.INDEXED
            and state.content_hash is not None
            and state.content_hash == content_hash
        )

    @staticmethod
    def _base_metadata(ref: DocRef) -> dict[str, object]:
        """Chunk metadata carried into Milvus for every chunk of this doc.

        ACLs and visibility ride along so the retrieval side can filter; we never put
        secrets or SAS query strings here (the uri is already scrubbed on the ref).
        """
        extra = dict(ref.extra or {})
        meta: dict[str, object] = {
            "doc_id": ref.doc_id,
            "source_id": ref.source_id,
            "uri": ref.uri,
            "title": ref.title,
            "access_teams": list(ref.acl.access_teams),
            "visibility": ref.acl.visibility.value,
        }
        # Lifecycle/governance metadata (retrieval-time filterable via Milvus
        # dynamic fields — no schema migration). Sources that surface a hidden /
        # published / build_version signal put it in DocRef.extra; anything the
        # source omits defaults to the safe value (visible + published).
        meta["hidden"] = bool(extra.get("hidden", False))
        meta["published"] = bool(extra.get("published", extra.get("status") == 3 if "status" in extra else True))
        meta["build_version"] = str(extra.get("build_version") or extra.get("version") or "")
        # Full D360 category breadcrumb ("Product Support > Escalations > ...").
        # Stored as a dynamic field so knowledge-space scoping is a native
        # Milvus prefix filter, and prepended to the chunk header so a thin
        # chunk ("## Features") still says which product area it belongs to.
        meta["category_path"] = str(extra.get("category_path") or "")
        return meta

    @staticmethod
    def _assemble_ai_ready(ref: DocRef, sections: Sequence[Section]) -> str:
        """Build the AI-ready markdown for a doc: a small provenance header plus the
        cleaned, OCR-enriched section text — exactly what is chunked + embedded."""
        body = "\n\n".join(s.text for s in sections if s.text)
        return (
            f"# {ref.title}\n\n"
            f"> Source: {ref.uri}\n"
            f"> doc_id: {ref.doc_id}  ·  sections: {len(sections)}  ·  "
            f"access_teams: {list(ref.acl.access_teams)}  ·  "
            f"visibility: {ref.acl.visibility.value}\n\n"
            f"---\n\n{body}\n"
        )

    async def _store_artifacts(
        self, ref: DocRef, fetched: FetchedDoc, sections: Sequence[Section]
    ) -> dict[str, object]:
        """Store the AI-ready markdown + raw source in MinIO; return their URLs.

        Best-effort: any failure is logged and yields empty URLs so indexing
        proceeds (the vectors are the source of truth; artifacts are auxiliary).
        """
        try:
            ai_ready = self._assemble_ai_ready(ref, sections)
            artifact_url = await self._artifact_store.put_ai_ready(ref, ai_ready)
            source_url = await self._artifact_store.put_source(ref, fetched)
            return {"artifact_url": artifact_url, "source_url": source_url}
        except Exception as exc:  # noqa: BLE001 — artifacts must never break a doc
            logger.warning("run.artifacts.failed", doc_id=ref.doc_id, error=repr(exc))
            return {}

    # ----- deletions -------------------------------------------------------
    async def _handle_signalled_deletes(
        self,
        discovered: Sequence[DocRef],
        stats: RunStats,
        log: structlog.stdlib.BoundLogger,
    ) -> None:
        """Apply explicit, source-signalled deletions (e.g. D360 status != 3).

        These don't need the full-run guard: the source emitted the doc but flagged it
        unpublished/archived, which is an explicit instruction to remove it. We honor
        the source's configured ``published_status`` if it exposes one.
        """
        published = self._settings.D360_INCLUDE_STATUS
        signalled = source_signalled_deletes(discovered, published_status=published)
        for ref in signalled:
            try:
                await self._sink.delete_doc(ref.doc_id)
                await self._ledger.mark_deleted(ref.doc_id)
                stats.docs_deleted += 1
                log.info("run.delete.signalled", doc_id=ref.doc_id)
            except Exception as exc:  # noqa: BLE001 — isolate
                log.error(
                    "run.delete.signalled.error", doc_id=ref.doc_id, error=repr(exc)
                )

    async def handle_deletions(
        self,
        plan: Plan,
        known_ids: set[str],
        full: bool,
        stats: RunStats,
        log: structlog.stdlib.BoundLogger,
    ) -> None:
        """Apply guarded set-difference deletions (tombstone vanished docs).

        Only runs on a FULL discover above the seen-ratio guard — a thin/partial
        discover must never mass-delete. For each candidate we delete the Milvus
        vectors first, then tombstone the ledger row.
        """
        if not plan.deleted:
            return

        seen_ratio = compute_seen_ratio(known_ids, plan)
        if not guard_ok(seen_ratio, self._settings, full=full):
            log.warning(
                "run.delete.guard_blocked",
                candidates=len(plan.deleted),
                seen_ratio=round(seen_ratio, 4),
                threshold=self._settings.DELETE_GUARD_MIN_SEEN_RATIO,
                full=full,
            )
            return

        log.info(
            "run.delete.applying",
            count=len(plan.deleted),
            seen_ratio=round(seen_ratio, 4),
        )
        for doc_id in plan.deleted:
            try:
                await self._sink.delete_doc(doc_id)
                await self._ledger.mark_deleted(doc_id)
                stats.docs_deleted += 1
                log.info("run.delete.applied", doc_id=doc_id)
            except Exception as exc:  # noqa: BLE001 — isolate per-doc
                log.error("run.delete.error", doc_id=doc_id, error=repr(exc))
