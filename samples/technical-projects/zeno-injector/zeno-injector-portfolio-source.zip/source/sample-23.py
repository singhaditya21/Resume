"""
Standalone image parser.

A document whose payload *is* an image (png/jpg/webp/gif/bmp/tiff) becomes a
single :class:`~zeno_injector.contracts.Section` whose text is the VLM caption
ONLY — never the bytes, never base64. If no :class:`OcrClient` was injected, the
section degrades to a ``[image]`` placeholder so downstream chunking still sees a
deterministic, non-empty document rather than nothing.

The caption is produced in ``describe`` mode (extract visible text / UI / steps /
diagram flow), which is what the retrieval side expects for screenshots and
diagrams in the knowledge base.
"""
from __future__ import annotations

from typing import Optional

import structlog

from zeno_injector.contracts import FetchedDoc, OcrClient, Section

from ._ocr_bridge import run_caption
from .html_parser import strip_base64

logger = structlog.get_logger(__name__)

_PLACEHOLDER = "[image]"


class ImageParser:
    """Caption a standalone image into a single Section."""

    def __init__(self, ocr: Optional[OcrClient] = None) -> None:
        self._ocr = ocr

    def parse(self, doc: FetchedDoc) -> list[Section]:
        image_bytes = doc.content
        title = doc.ref.title or ""

        if not image_bytes:
            logger.warning("image_parser.no_bytes", doc_id=doc.ref.doc_id)
            return [Section(order=0, text=_PLACEHOLDER, heading=title, section_path=title)]

        caption = _PLACEHOLDER
        if self._ocr is not None:
            try:
                result = run_caption(self._ocr, image_bytes, mode="describe")
            except Exception as exc:
                # Degrade, never abort: a failed VLM call must not kill the run.
                logger.warning("image_parser.ocr_failed", doc_id=doc.ref.doc_id, error=str(exc))
                result = ""
            result = strip_base64(result or "").strip()
            if result:
                caption = result
        else:
            logger.info("image_parser.no_ocr_placeholder", doc_id=doc.ref.doc_id)

        return [Section(order=0, text=caption, heading=title, section_path=title)]


__all__ = ["ImageParser"]
