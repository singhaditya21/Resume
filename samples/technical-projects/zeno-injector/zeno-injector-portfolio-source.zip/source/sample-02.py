"""
MilvusSink — the only writer into the injector's vector collection.

The collection uses an EXPLICIT schema (see :func:`store.schema.build_collection_schema`):
``text`` and the per-chunk metadata (``doc_id``, ``source_id``, ``uri``, ``title``,
``access_teams``, ``visibility``, ``ordinal``) are REAL columns — not buried inside
LlamaIndex's opaque ``_node_content`` JSON. That makes the chunk text a first-class,
visible field in Attu and makes ``access_teams`` filterable server-side for
role-based retrieval.

Responsibilities
----------------
* ``ensure_collection`` — CREATE the collection with the explicit schema if it does
  not exist (idempotent), else validate the live shape against
  :mod:`zeno_injector.store.schema` and load it. Never drops an existing collection.
* ``upsert_doc`` — *delete-then-insert* every chunk for a ``doc_id`` so re-indexing
  converges instead of duplicating. Rows are plain dicts matching the schema.
* ``delete_doc`` / ``count`` / ``list_doc_ids`` — via the raw ``MilvusClient``.

Security: a ``doc_id`` is NEVER f-stringed straight into a Milvus filter. Every
``doc_id`` is first matched against a strict allowlist regex; only the narrow
``[a-z0-9_]``/hex alphabet is permitted, which is closed under Milvus expression
quoting, so the resulting ``doc_id == "..."`` expression cannot be injected.
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Optional, Sequence

import structlog

from zeno_injector.config import Settings, get_settings
from zeno_injector.contracts import EmbeddedChunk, VectorSink
from zeno_injector.store import schema as store_schema

logger = structlog.get_logger(__name__)

# Strict allowlist for a doc_id: "<source>:<16 hex>" exactly as make_doc_id emits.
# Anchored, no metacharacters survive — safe to embed in a Milvus boolean expr.
_DOC_ID_RE = re.compile(r"^[a-z0-9_]+:[0-9a-f]{16}$")


def _validate_doc_id(doc_id: str) -> str:
    """Return ``doc_id`` unchanged iff it matches the strict allowlist, else raise.

    This is the single chokepoint every code path that builds a Milvus filter must
    pass through. Because the permitted alphabet is ``[a-z0-9_:]`` only, the value
    is inert inside a double-quoted Milvus expression string.
    """
    if not isinstance(doc_id, str) or not _DOC_ID_RE.match(doc_id):
        raise ValueError(
            f"refusing to build a Milvus filter for an invalid doc_id: {doc_id!r} "
            r"(must match ^[a-z0-9_]+:[0-9a-f]{16}$)"
        )
    return doc_id


def _clip(value: object, limit: int) -> str:
    """Coerce to str and clip to ``limit`` characters (VARCHAR ceiling guard)."""
    s = "" if value is None else str(value)
    return s[:limit]


class MilvusSink(VectorSink):
    """Delete-then-insert writer over the explicit-schema Milvus collection."""

    def __init__(self, settings: Optional[Settings] = None) -> None:
        self._settings = settings or get_settings()
        self._uri = self._settings.MILVUS_URI
        self._collection = self._settings.MILVUS_COLLECTION
        self._db = getattr(self._settings, "MILVUS_DB", "default") or "default"
        self._dim = self._settings.MILVUS_DIM
        self._metric = self._settings.MILVUS_METRIC
        # Lazily constructed blocking client; we drive it from a thread.
        self._client: Any = None  # pymilvus MilvusClient
        self._lock = asyncio.Lock()

    # ---- lazy client construction (blocking ctor -> run in executor) --------
    def _build_client(self) -> Any:
        from pymilvus import MilvusClient

        # Ensure the target database exists (Milvus databases are namespaces;
        # a client opened on a missing db fails). Bootstrap on the default db,
        # create ours if absent, then open the real client scoped to it.
        if self._db and self._db != "default":
            boot = MilvusClient(uri=self._uri)
            try:
                if self._db not in boot.list_databases():
                    boot.create_database(self._db)
            finally:
                try:
                    boot.close()
                except Exception:
                    pass
            return MilvusClient(uri=self._uri, db_name=self._db)
        return MilvusClient(uri=self._uri)

    async def _get_client(self) -> Any:
        if self._client is None:
            async with self._lock:
                if self._client is None:
                    self._client = await asyncio.to_thread(self._build_client)
        return self._client

    # ---- schema introspection / drift guard --------------------------------
    def _read_live_schema(self, client: Any) -> store_schema.LiveSchema:
        """Read the live collection's fields + vector dim via MilvusClient."""
        desc = client.describe_collection(self._collection)
        fields = desc.get("fields", []) or []
        field_names = tuple(f.get("name", "") for f in fields)

        dim = 0
        for f in fields:
            if f.get("name") == store_schema.EMBEDDING_FIELD:
                params = f.get("params", {}) or {}
                raw = params.get("dim", 0)
                try:
                    dim = int(raw)
                except (TypeError, ValueError):
                    dim = 0
                break
        return store_schema.LiveSchema(
            collection=self._collection,
            dim=dim,
            field_names=field_names,
        )

    def _create_collection_blocking(self, client: Any) -> None:
        """Create the explicit-schema collection + FLAT/IP index, then load it."""
        schema, index_params = store_schema.build_collection_schema(
            client, dim=self._dim, metric=self._metric, enable_dynamic=True,
        )
        client.create_collection(
            collection_name=self._collection,
            schema=schema,
            index_params=index_params,
        )
        client.load_collection(self._collection)

    def _ensure_blocking(self, client: Any) -> tuple[bool, store_schema.LiveSchema]:
        """Create-if-missing; return (created, live_schema). Never drops."""
        if not client.has_collection(self._collection):
            self._create_collection_blocking(client)
            created = True
        else:
            created = False
            # Make sure an existing collection is queryable/searchable.
            client.load_collection(self._collection)
        return created, self._read_live_schema(client)

    async def ensure_collection(self) -> None:
        """Create the collection with the explicit schema if missing, else validate
        the live shape against the retrieval contract and load it. Idempotent and
        non-destructive (never drops or overwrites an existing collection)."""
        client = await self._get_client()
        created, live = await asyncio.to_thread(self._ensure_blocking, client)
        problems = store_schema.schema_matches_retrieval(
            live,
            expect_collection=self._collection,
            expect_dim=self._dim,
        )
        if problems:
            logger.error(
                "milvus.schema_drift",
                collection=self._collection,
                problems=problems,
                live_fields=list(live.field_names),
                live_dim=live.dim,
            )
            raise RuntimeError(
                "Milvus schema drift vs retrieval contract: " + "; ".join(problems)
            )
        logger.info(
            "milvus.ensure_collection.ok",
            collection=self._collection,
            created=created,
            dim=live.dim,
            fields=list(live.field_names),
        )

    # ---- row construction ---------------------------------------------------
    def _build_rows(self, doc_id: str, embedded: Sequence[EmbeddedChunk]) -> list[dict[str, Any]]:
        """Build explicit-schema row dicts carrying the embedding + metadata columns.

        ``id`` is the deterministic chunk_id so re-inserts converge on the same
        primary key. ``doc_id`` is authoritative (it is the delete key) regardless
        of what the chunk metadata carried.
        """
        rows: list[dict[str, Any]] = []
        for ec in embedded:
            chunk = ec.chunk
            vec = list(ec.embedding)
            if len(vec) != self._dim:
                raise ValueError(
                    f"embedding for chunk {chunk.chunk_id} has dim {len(vec)}, "
                    f"expected {self._dim}"
                )
            md = dict(chunk.metadata or {})

            teams = md.get("access_teams") or ["all"]
            if isinstance(teams, str):
                teams = [teams]
            teams = [_clip(t, store_schema.MAX_TEAM_LEN) for t in teams][: store_schema.MAX_TEAMS_CAP]
            if not teams:
                teams = ["all"]

            rows.append(
                {
                    store_schema.PRIMARY_FIELD: _clip(chunk.chunk_id, store_schema.MAX_ID_LEN),
                    store_schema.DOC_ID_FIELD: doc_id,  # validated by caller
                    store_schema.TEXT_FIELD: _clip(chunk.text, store_schema.MAX_TEXT_LEN),
                    store_schema.EMBEDDING_FIELD: vec,
                    store_schema.SOURCE_ID_FIELD: _clip(
                        md.get("source_id") or doc_id.split(":", 1)[0], store_schema.MAX_SOURCE_ID_LEN
                    ),
                    store_schema.URI_FIELD: _clip(md.get("uri"), store_schema.MAX_URI_LEN),
                    store_schema.TITLE_FIELD: _clip(md.get("title"), store_schema.MAX_TITLE_LEN),
                    store_schema.ACCESS_TEAMS_FIELD: teams,
                    store_schema.VISIBILITY_FIELD: _clip(
                        md.get("visibility") or "internal", store_schema.MAX_VISIBILITY_LEN
                    ),
                    store_schema.ORDINAL_FIELD: int(getattr(chunk, "ordinal", 0) or 0),
                    store_schema.ARTIFACT_URL_FIELD: _clip(
                        md.get("artifact_url"), store_schema.MAX_URL_LEN
                    ),
                    store_schema.SOURCE_URL_FIELD: _clip(
                        md.get("source_url"), store_schema.MAX_URL_LEN
                    ),
                    # F-1/F-2 governance + structure metadata. The collection has
                    # enable_dynamic_field=True, so these ride as filterable dynamic
                    # columns without a schema migration. Serving reads them for the
                    # hidden/published gate and intent-matched (content_type) ranking.
                    "content_type": _clip(md.get("content_type") or "prose", 32),
                    "heading_path": _clip(md.get("heading_path") or md.get("section_path") or "", store_schema.MAX_TITLE_LEN),
                    "section_path": _clip(md.get("section_path") or "", store_schema.MAX_TITLE_LEN),
                    "hidden": bool(md.get("hidden", False)),
                    "published": bool(md.get("published", True)),
                    "build_version": _clip(str(md.get("build_version") or ""), 64),
                    # Full D360 breadcrumb — lets a knowledge-space filter be an
                    # exact prefix match on a small column instead of scanning text.
                    "category_path": _clip(str(md.get("category_path") or ""), store_schema.MAX_TITLE_LEN),
                }
            )
        return rows

    # ---- delete-then-insert -------------------------------------------------
    def _delete_filter(self, doc_id: str) -> str:
        """Build a validated Milvus boolean expression deleting one doc's rows."""
        safe = _validate_doc_id(doc_id)
        # safe is constrained to [a-z0-9_:] so it cannot escape the quotes below.
        return f'{store_schema.DOC_ID_FIELD} == "{safe}"'

    def _delete_rows_blocking(self, client: Any, doc_id: str) -> None:
        client.delete(collection_name=self._collection, filter=self._delete_filter(doc_id))

    def _insert_rows_blocking(self, client: Any, rows: list[dict[str, Any]]) -> None:
        client.insert(collection_name=self._collection, data=rows)

    async def upsert_doc(self, doc_id: str, embedded: Sequence[EmbeddedChunk]) -> int:
        """Atomically replace a document's vectors (delete every matching row, then
        insert the new chunks). Returns the number of chunks inserted."""
        safe_doc_id = _validate_doc_id(doc_id)
        client = await self._get_client()

        # 1) Delete existing rows for this doc_id (validated filter).
        await asyncio.to_thread(self._delete_rows_blocking, client, safe_doc_id)

        # 2) Insert the new chunks (if any). An empty embedded set is a pure delete.
        rows = self._build_rows(safe_doc_id, embedded)
        if rows:
            await asyncio.to_thread(self._insert_rows_blocking, client, rows)

        logger.info(
            "milvus.upsert_doc",
            doc_id=safe_doc_id,
            chunks=len(rows),
            collection=self._collection,
        )
        return len(rows)

    async def delete_doc(self, doc_id: str) -> None:
        """Delete every row whose doc_id matches (validated filter)."""
        safe_doc_id = _validate_doc_id(doc_id)
        client = await self._get_client()
        await asyncio.to_thread(self._delete_rows_blocking, client, safe_doc_id)
        logger.info("milvus.delete_doc", doc_id=safe_doc_id, collection=self._collection)

    # ---- counts / introspection --------------------------------------------
    def _count_blocking(self, client: Any) -> int:
        stats = client.get_collection_stats(self._collection)
        raw = stats.get("row_count", 0) if isinstance(stats, dict) else 0
        try:
            return int(raw)
        except (TypeError, ValueError):
            return 0

    async def count(self) -> int:
        """Approximate row count via collection stats."""
        client = await self._get_client()
        return await asyncio.to_thread(self._count_blocking, client)

    def _list_doc_ids_blocking(self, client: Any, batch: int) -> set[str]:
        """Scan the collection and return the distinct set of doc_ids.

        Used by the ledger's reconcile to seed ``documents`` rows for vectors that
        already exist in Milvus but predate the ledger.
        """
        field = store_schema.DOC_ID_FIELD
        doc_ids: set[str] = set()

        iterator = None
        if hasattr(client, "query_iterator"):
            try:
                iterator = client.query_iterator(
                    collection_name=self._collection,
                    filter="",
                    output_fields=[field],
                    batch_size=batch,
                )
            except Exception:  # noqa: BLE001 - fall back to bounded query below
                iterator = None

        if iterator is not None:
            try:
                while True:
                    page = iterator.next()
                    if not page:
                        break
                    for row in page:
                        val = row.get(field)
                        if isinstance(val, str) and val:
                            doc_ids.add(val)
            finally:
                close = getattr(iterator, "close", None)
                if callable(close):
                    close()
            return doc_ids

        rows = client.query(
            collection_name=self._collection,
            filter="",
            output_fields=[field],
            limit=batch,
        )
        for row in rows or []:
            val = row.get(field)
            if isinstance(val, str) and val:
                doc_ids.add(val)
        return doc_ids

    async def list_doc_ids(self, batch: int = 1000) -> set[str]:
        """Return the distinct set of doc_ids currently present in Milvus."""
        client = await self._get_client()
        ids = await asyncio.to_thread(self._list_doc_ids_blocking, client, batch)
        logger.info("milvus.list_doc_ids", count=len(ids), collection=self._collection)
        return ids

    async def close(self) -> None:
        """Best-effort release of the underlying client."""
        client, self._client = self._client, None
        if client is not None:
            close = getattr(client, "close", None)
            if callable(close):
                await asyncio.to_thread(close)
