"""
Parser router.

Dispatches a :class:`~zeno_injector.contracts.FetchedDoc` to the correct concrete
parser based on its MIME type (with a filename-extension fallback), then runs
:func:`~zeno_injector.parsing.html_parser.strip_base64` over EVERY output
section's text as a final, parser-agnostic guard so base64/raw bytes can never
reach embeddings or Milvus — even if a future parser forgets to scrub.

Routing table
-------------
* ``text/html`` (and ``application/xhtml+xml``)        -> :class:`HtmlParser`
* PDF                                                  -> :class:`PdfParser`
* Word / Excel / PowerPoint (OOXML + legacy)           -> :class:`OfficeParser`
* ``image/*``                                          -> :class:`ImageParser`
* ``text/plain`` / ``text/markdown`` / unknown         -> :class:`TextParser`

The single injected :class:`OcrClient` (or ``None``) is threaded into every
parser that can use it, so OCR configuration lives in exactly one place.

The router itself implements the synchronous
:class:`~zeno_injector.contracts.Parser` Protocol, so the orchestrator can treat
it as just another ``Parser``.
"""
from __future__ import annotations

from typing import Optional

import structlog

from zeno_injector.contracts import FetchedDoc, OcrClient, Parser, Section

from .html_parser import HtmlParser, strip_base64
from .image_parser import ImageParser
from .office_parser import OfficeParser
from .pdf_parser import PdfParser
from .text_parser import TextParser

logger = structlog.get_logger(__name__)


# Substrings that identify each family. Checked against the lowercased MIME and,
# as a fallback, the URI/title extension.
_HTML_HINTS = ("text/html", "application/xhtml")
_PDF_HINTS = ("application/pdf", ".pdf")
_OFFICE_HINTS = (
    "officedocument", "msword", "ms-excel", "ms-powerpoint",
    "wordprocessingml", "spreadsheetml", "presentationml",
    ".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt",
)
_IMAGE_HINTS = ("image/", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff")
_HTML_EXT = (".html", ".htm", ".aspx", ".xhtml")


class ParserRouter:
    """Selects and runs the right parser for a fetched document."""

    def __init__(self, ocr: Optional[OcrClient] = None) -> None:
        self._ocr = ocr
        # Concrete parsers, each sharing the one injected OCR client.
        _mirror = None
        try:
            from zeno_injector.config import get_settings
            if get_settings().IMAGE_MIRROR_ENABLED:
                from zeno_injector.store.image_mirror import ImageMirror
                _mirror = ImageMirror()
        except Exception:
            _mirror = None  # mirror is an enhancement — parsing must work without it
        self._html = HtmlParser(ocr=ocr, mirror=_mirror)
        self._pdf = PdfParser(ocr=ocr)
        self._office = OfficeParser(ocr=ocr)
        self._image = ImageParser(ocr=ocr)
        self._text = TextParser(ocr=ocr)

    # -- public API --------------------------------------------------------
    def parse(self, doc: FetchedDoc) -> list[Section]:
        parser = self._select(doc)
        parser_name = type(parser).__name__
        try:
            sections = list(parser.parse(doc))
        except Exception as exc:
            # A parser blowing up must not kill the run; log and yield nothing so
            # the orchestrator can mark the doc errored and move on.
            logger.error(
                "router.parse_failed",
                doc_id=doc.ref.doc_id,
                parser=parser_name,
                mime=doc.mime,
                error=str(exc),
            )
            return []

        # Final guard: scrub base64 from EVERY section's text, drop empties, and
        # renumber order so it's contiguous regardless of what the parser did.
        guarded: list[Section] = []
        order = 0
        for s in sections:
            clean = strip_base64(s.text or "").strip()
            if not clean:
                continue
            guarded.append(
                Section(order=order, text=clean, heading=s.heading, section_path=s.section_path)
            )
            order += 1

        logger.info(
            "router.parsed",
            doc_id=doc.ref.doc_id,
            parser=parser_name,
            mime=doc.mime,
            sections=len(guarded),
        )
        return guarded

    def parser_for(self, mime: Optional[str]) -> Parser:
        """Return the parser that would handle a given MIME (extension-free).

        Exposed for diagnostics/tests; routing for a real doc uses :meth:`_select`
        which also consults the document's URI/title extension.
        """
        return self._by_mime(mime or "", "")

    # -- selection ---------------------------------------------------------
    def _select(self, doc: FetchedDoc) -> Parser:
        mime = (doc.mime or doc.ref.mime or "").lower()
        ext_hay = f"{doc.ref.uri or ''} {doc.ref.title or ''}".lower()
        return self._by_mime(mime, ext_hay)

    def _by_mime(self, mime: str, ext_hay: str) -> Parser:
        mime = mime.lower()
        hay = f"{mime} {ext_hay}".lower()

        # HTML first (Document360's primary payload).
        if any(h in mime for h in _HTML_HINTS) or any(e in ext_hay for e in _HTML_EXT):
            return self._html
        if any(h in hay for h in _PDF_HINTS):
            return self._pdf
        if any(h in hay for h in _OFFICE_HINTS):
            return self._office
        if any(h in hay for h in _IMAGE_HINTS):
            return self._image
        # text/plain, text/markdown, application/octet-stream, unknown -> text.
        return self._text


__all__ = ["ParserRouter", "strip_base64"]
