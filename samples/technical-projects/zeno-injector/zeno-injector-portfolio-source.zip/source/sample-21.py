"""
Parsing module group for the Zeno injection pipeline.

Public surface:

* :class:`ParserRouter` — dispatches a ``FetchedDoc`` to the right parser by MIME
  / extension and runs a final base64 guard over all output.
* The concrete parsers (``HtmlParser``, ``PdfParser``, ``OfficeParser``,
  ``ImageParser``, ``TextParser``) for direct use / testing.
* :func:`strip_base64` — the shared guard that removes ``data:`` URIs and long
  base64 blobs from any text (imported by the router and the tests).
"""
from __future__ import annotations

from .html_parser import HtmlParser, strip_base64
from .image_parser import ImageParser
from .office_parser import OfficeParser
from .pdf_parser import PdfParser
from .router import ParserRouter
from .text_parser import TextParser

__all__ = [
    "ParserRouter",
    "HtmlParser",
    "PdfParser",
    "OfficeParser",
    "ImageParser",
    "TextParser",
    "strip_base64",
]
