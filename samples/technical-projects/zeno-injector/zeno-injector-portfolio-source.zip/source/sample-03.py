"""
Token-based, section-aware chunker.

Goal: produce chunks that line up with what the retrieval pipeline indexed, so a
query and the passages it should match land in the same token neighborhoods. The
retrieval side used a LlamaIndex ``SentenceSplitter`` with ``chunk_size=1024`` and
``chunk_overlap=128`` counted in the embedding model's tokens, so we mirror that
budget here (``settings.CHUNK_TOKENS`` / ``settings.CHUNK_OVERLAP_TOKENS``) using
the *same* tokenizer (see :mod:`zeno_injector.processing.tokenizer`).

Strategy, in order:

1.  **Respect section boundaries.** Parsers hand us ordered :class:`Section`s
    (clean text, never base64). We never merge text across unrelated headings,
    because that pollutes a chunk with two topics and hurts recall.
2.  **Merge tiny sections** (< ``CHUNK_MIN_MERGE_TOKENS``, default 80) into the
    running buffer *only while* they share the same parent heading — a list of
    one-line bullets under "Prerequisites" becomes one coherent chunk instead of
    a dozen near-empty vectors.
3.  **One chunk per section** when the (possibly merged) buffer fits the budget.
4.  **Sliding window** when a single section is larger than the budget: slice its
    token ids into ``CHUNK_TOKENS`` windows stepping by
    ``CHUNK_TOKENS - CHUNK_OVERLAP_TOKENS``, then ``decode`` each window back to
    text. The 128-token overlap preserves context across the cut.

Every chunk gets a deterministic ``chunk_id`` (``make_chunk_id(doc_id, ordinal)``)
so re-indexing the same document converges on the same primary keys instead of
duplicating. All chunks carry the document's base metadata plus their own
``ordinal``, ``section_path`` and ``content_hash``. Empty/whitespace chunks are
dropped.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import structlog

from zeno_injector.config import get_settings
from zeno_injector.contracts import (
    Chunk,
    Section,
    content_sha256,
    make_chunk_id,
)
from zeno_injector.processing.tokenizer import (
    count_tokens,
    decode,
    encode,
    ids_per_token,
)

logger = structlog.get_logger(__name__)

# Markdown-structure detectors for content-type classification.
_TABLE_RX = re.compile(r"^\s*\|.*\|\s*$", re.M)
_NUM_STEP_RX = re.compile(r"^\s*\d+[.)]\s+\S", re.M)
_BULLET_RX = re.compile(r"^\s*[-*+]\s+\S", re.M)


def _classify_content_type(text: str) -> str:
    """Label a chunk so retrieval/generation can prefer procedures for how-to
    queries and complete lists for enumeration queries (RCA: content_type is the
    high-leverage field — one signal serves F1/F5a/F5b).

    procedure > table > list > prose, decided by the dominant structure.
    """
    t = text or ""
    if len(_NUM_STEP_RX.findall(t)) >= 2:
        return "procedure"
    if len(_TABLE_RX.findall(t)) >= 2:          # header + at least one row
        return "table"
    if len(_BULLET_RX.findall(t)) >= 3:
        return "list"
    return "prose"


def _split_blocks(text: str) -> list[str]:
    """Split section text into STRUCTURAL blocks that must never be cut.

    A block is: a contiguous run of numbered steps (with their indented
    continuation lines), a contiguous markdown table, a contiguous bullet
    list, or a prose paragraph. The oversize splitter packs whole blocks
    into windows — so a procedure/table/list never breaks mid-way (CUG:
    "steps truncated / see other document").
    """
    lines = (text or "").splitlines()
    blocks: list[list[str]] = []
    cur: list[str] = []
    cur_kind = ""

    def kind_of(line: str) -> str:
        if re.match(r"^\s*\d+[.)]\s+\S", line):
            return "step"
        if re.match(r"^\s*\|.*\|\s*$", line):
            return "table"
        if re.match(r"^\s*[-*+]\s+\S", line):
            return "bullet"
        if not line.strip():
            return "blank"
        return "prose"

    def flush():
        nonlocal cur, cur_kind
        if cur and "\n".join(cur).strip():
            blocks.append(cur)
        cur, cur_kind = [], ""

    for ln in lines:
        k = kind_of(ln)
        if k == "blank":
            # blank ends a prose paragraph but NOT a structural run (numbered
            # procedures often have blank lines between steps).
            if cur_kind in ("", "prose"):
                flush()
            else:
                cur.append(ln)
            continue
        if not cur:
            cur, cur_kind = [ln], ("prose" if k == "prose" else k)
            continue
        if cur_kind in ("step", "table", "bullet"):
            # continuation: same structure, or an indented detail line under a step
            if k == cur_kind or (cur_kind == "step" and (ln.startswith(("   ", "\t")) or k == "prose" and ln[:1].isspace())):
                cur.append(ln)
                continue
            if cur_kind == "step" and k in ("table", "bullet"):
                # sub-table / sub-bullets inside a step stay with the procedure
                cur.append(ln)
                continue
            flush()
            cur, cur_kind = [ln], ("prose" if k == "prose" else k)
            continue
        # cur is prose
        if k == "prose":
            cur.append(ln)
            continue
        flush()
        cur, cur_kind = [ln], k
    flush()
    return ["\n".join(b).strip() for b in blocks if "\n".join(b).strip()]


def _common_breadcrumb(a: str, b: str) -> str:
    """Shared breadcrumb prefix of two section paths — a PACKED chunk is
    labelled by what its members share ("Planner > Features"), never by one
    member's deep path (mislabels the rest)."""
    pa = [p.strip() for p in (a or "").split(">") if p.strip()]
    pb = [p.strip() for p in (b or "").split(">") if p.strip()]
    common = []
    for x, y in zip(pa, pb):
        if x != y:
            break
        common.append(x)
    return " > ".join(common) if common else (pa[0] if pa else (pb[0] if pb else ""))


def _parent_heading(section: Section) -> str:
    """The heading a section lives under, used to gate merging.

    Prefer the first component of ``section_path`` (the breadcrumb root, e.g.
    "Configuration" in "Configuration > SLA Service Setting"); fall back to the
    section's own ``heading``. Two sections may merge only if these agree.
    """
    if section.section_path:
        return section.section_path.split(">", 1)[0].strip()
    return (section.heading or "").strip()


@dataclass()
class _Buffer:
    """A growing run of small same-parent sections awaiting emit."""
    texts: list[str]
    parent: str
    section_path: str
    token_estimate: int

    @classmethod
    def empty(cls) -> "_Buffer":
        return cls(texts=[], parent="", section_path="", token_estimate=0)

    def is_empty(self) -> bool:
        return not self.texts

    def text(self) -> str:
        return "\n\n".join(t for t in self.texts if t).strip()


class TokenChunker:
    """Token-based, section-aware :class:`~zeno_injector.contracts.Chunker`."""

    def __init__(self) -> None:
        settings = get_settings()
        self._budget = settings.CHUNK_TOKENS
        self._overlap = settings.CHUNK_OVERLAP_TOKENS
        self._min_merge = settings.CHUNK_MIN_MERGE_TOKENS
        self._pack = getattr(settings, "CHUNK_PACK_SECTIONS", True)
        self._ctx_prefix = getattr(settings, "CHUNK_CONTEXT_PREFIX", True)
        self._pack_target = min(
            getattr(settings, "CHUNK_PACK_TARGET_TOKENS", 600), self._budget
        )
        if self._overlap >= self._budget:
            # config.validate_invariants also guards this; assert defensively so a
            # mis-wired test can't produce a zero/negative stride.
            raise ValueError("CHUNK_OVERLAP_TOKENS must be < CHUNK_TOKENS")
        self._stride = self._budget - self._overlap

    # -- public API --------------------------------------------------------
    def chunk(
        self,
        doc_id: str,
        sections: Sequence[Section],
        base_metadata: Mapping[str, Any],
    ) -> list[Chunk]:
        """Turn ordered sections into token-bounded chunks. See module docstring."""
        chunks: list[Chunk] = []
        ordinal = 0
        buffer = _Buffer.empty()

        # Process sections in their declared order so chunk ordinals are stable.
        ordered = sorted(sections, key=lambda s: s.order)

        for section in ordered:
            text = (section.text or "").strip()
            if not text:
                continue  # drop empty sections outright

            n_tokens = REDACTED_SECRET
            parent = _parent_heading(section)

            # Oversized section: flush whatever is buffered, then sliding-window it.
            if n_tokens > self._budget:
                ordinal = self._flush_buffer(doc_id, buffer, base_metadata, chunks, ordinal)
                buffer = _Buffer.empty()
                ordinal = self._emit_sliding_window(
                    doc_id, section, text, base_metadata, chunks, ordinal
                )
                continue

            # Small section: try to accumulate it with same-parent neighbors.
            if n_tokens < self._min_merge:
                same_parent = buffer.is_empty() or buffer.parent == parent
                fits = buffer.token_estimate + n_tokens <= self._pack_target
                if same_parent and fits:
                    if buffer.is_empty():
                        buffer.parent = parent
                        buffer.section_path = section.section_path or section.heading
                    else:
                        buffer.section_path = _common_breadcrumb(
                            buffer.section_path, section.section_path or section.heading)
                    buffer.texts.append(text)
                    buffer.token_estimate += n_tokens
                    continue
                # Different parent or would overflow: flush then start fresh.
                ordinal = self._flush_buffer(doc_id, buffer, base_metadata, chunks, ordinal)
                buffer = _Buffer.empty()
                buffer.parent = parent
                buffer.section_path = section.section_path or section.heading
                buffer.texts.append(text)
                buffer.token_estimate = REDACTED_SECRET
                continue

            # Normal-sized section (>= min_merge, <= budget).
            # F-2 packing: instead of one-chunk-per-section (the 17-chunks/doc
            # micro-drift), PACK consecutive same-parent sections up to the
            # budget. Same-parent gating keeps a chunk single-topic; the budget
            # keeps it retrievable. Packing off → original one-per-section.
            if self._pack:
                same_parent = buffer.is_empty() or buffer.parent == parent
                fits = buffer.token_estimate + n_tokens <= self._pack_target
                if same_parent and fits:
                    if buffer.is_empty():
                        buffer.parent = parent
                        buffer.section_path = section.section_path or section.heading
                    else:
                        buffer.section_path = _common_breadcrumb(
                            buffer.section_path, section.section_path or section.heading)
                    buffer.texts.append(text)
                    buffer.token_estimate += n_tokens
                    continue
                # different parent or would overflow → flush, start new buffer
                ordinal = self._flush_buffer(doc_id, buffer, base_metadata, chunks, ordinal)
                buffer = _Buffer.empty()
                buffer.parent = parent
                buffer.section_path = section.section_path or section.heading
                buffer.texts.append(text)
                buffer.token_estimate = REDACTED_SECRET
                continue
            ordinal = self._flush_buffer(doc_id, buffer, base_metadata, chunks, ordinal)
            buffer = _Buffer.empty()
            ordinal = self._emit_single(
                doc_id,
                text,
                section.section_path or section.heading,
                base_metadata,
                chunks,
                ordinal,
            )

        # Flush any trailing buffered small sections.
        self._flush_buffer(doc_id, buffer, base_metadata, chunks, ordinal)

        logger.debug(
            "chunker.done",
            doc_id=doc_id,
            sections=len(ordered),
            chunks=len(chunks),
        )
        return chunks

    # -- emitters ----------------------------------------------------------
    def _flush_buffer(
        self,
        doc_id: str,
        buffer: _Buffer,
        base_metadata: Mapping[str, Any],
        chunks: list[Chunk],
        ordinal: int,
    ) -> int:
        if buffer.is_empty():
            return ordinal
        return self._emit_single(
            doc_id, buffer.text(), buffer.section_path, base_metadata, chunks, ordinal
        )

    def _emit_single(
        self,
        doc_id: str,
        text: str,
        section_path: str,
        base_metadata: Mapping[str, Any],
        chunks: list[Chunk],
        ordinal: int,
    ) -> int:
        text = (text or "").strip()
        if not text:
            return ordinal  # never emit an empty chunk
        chunks.append(self._make_chunk(doc_id, ordinal, text, section_path, base_metadata))
        return ordinal + 1

    def _emit_sliding_window(
        self,
        doc_id: str,
        section: Section,
        text: str,
        base_metadata: Mapping[str, Any],
        chunks: list[Chunk],
        ordinal: int,
    ) -> int:
        """Chunk an oversized section WITHOUT breaking structural units.

        F-2: split the section into structural blocks (procedures, tables,
        lists, prose paragraphs) and pack whole blocks into <=budget chunks —
        so a numbered procedure or a table is never cut mid-way (the old
        token-sliding-window did exactly that: "steps truncated / see other
        doc"). A single block that alone exceeds the budget (a huge table)
        falls back to the token window for that block only, as a last resort.
        """
        section_path = section.section_path or section.heading
        blocks = _split_blocks(text)
        if not blocks:
            return ordinal

        buf: list[str] = []
        buf_tokens = REDACTED_SECRET
        for block in blocks:
            bt = count_tokens(block)
            if bt > self._budget:
                # flush what we have, then window this one oversized block alone
                if buf:
                    ordinal = self._emit_single(doc_id, "\n\n".join(buf), section_path, base_metadata, chunks, ordinal)
                    buf, buf_tokens = [], 0
                ordinal = self._window_ids(doc_id, block, section_path, base_metadata, chunks, ordinal)
                continue
            if buf and buf_tokens + bt > self._budget:
                ordinal = self._emit_single(doc_id, "\n\n".join(buf), section_path, base_metadata, chunks, ordinal)
                buf, buf_tokens = [], 0
            buf.append(block)
            buf_tokens += bt
        if buf:
            ordinal = self._emit_single(doc_id, "\n\n".join(buf), section_path, base_metadata, chunks, ordinal)
        return ordinal

    def _window_ids(
        self, doc_id, text, section_path, base_metadata, chunks, ordinal
    ) -> int:
        """Last-resort token window for a SINGLE block that exceeds the budget."""
        ids = encode(text)
        if not ids:
            return ordinal
        factor = max(1, ids_per_token())
        window = self._budget * factor
        stride = self._stride * factor
        start, n = 0, len(ids)
        while start < n:
            piece = decode(ids[start : start + window]).strip()
            if piece:
                chunks.append(self._make_chunk(doc_id, ordinal, piece, section_path, base_metadata))
                ordinal += 1
            if start + window >= n:
                break
            start += stride
        return ordinal

    # -- chunk construction ------------------------------------------------
    def _make_chunk(
        self,
        doc_id: str,
        ordinal: int,
        text: str,
        section_path: str,
        base_metadata: Mapping[str, Any],
    ) -> Chunk:
        # content_hash + content_type are computed on the RAW text (change signal
        # and structure classification must not see the injected prefix).
        metadata = self._build_metadata(doc_id, ordinal, text, section_path, base_metadata)
        stored = text
        if self._ctx_prefix:
            title = str(base_metadata.get("title") or "").strip()
            crumb = " › ".join(p.strip() for p in str(section_path or "").split(">") if p.strip())
            # category breadcrumb first: it is what disambiguates same-named
            # sections across docs ("Features" exists in dozens of articles)
            cat = " › ".join(p.strip() for p in str(base_metadata.get("category_path") or "").split(">") if p.strip())
            header = " › ".join(x for x in (cat, title, crumb) if x)
            if header and not text.lstrip().startswith("["):
                stored = f"[{header}]\n{text}"
        return Chunk(
            chunk_id=make_chunk_id(doc_id, ordinal),
            doc_id=doc_id,
            ordinal=ordinal,
            text=stored,
            metadata=metadata,
        )

    @staticmethod
    def _build_metadata(
        doc_id: str,
        ordinal: int,
        text: str,
        section_path: str,
        base_metadata: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Carry the doc's base metadata, then stamp per-chunk fields on top.

        The base metadata is expected to carry (from the source/parser layer):
        ``source_id, uri, title, slug, source_modified_at, access_team,
        category_id``. We add/override ``doc_id``, ``ordinal``, ``section_path``
        and a per-chunk ``content_hash`` (the authoritative text-change signal).
        """
        metadata: dict[str, Any] = dict(base_metadata)
        metadata["doc_id"] = doc_id
        metadata["ordinal"] = ordinal
        metadata["section_path"] = section_path or ""
        metadata["content_hash"] = content_sha256(text)
        # Structure/governance metadata for retrieval-time filtering and
        # intent-matched ranking. heading_path is a filter-friendly alias of
        # section_path; content_type drives how-to/enumeration preference. The
        # lifecycle fields (hidden/published/build_version) ride in from the
        # source layer via base_metadata; defaulted here so every chunk is
        # self-describing even for sources that don't set them yet.
        metadata["heading_path"] = section_path or ""
        metadata["content_type"] = _classify_content_type(text)
        metadata.setdefault("hidden", bool(base_metadata.get("hidden", False)))
        metadata.setdefault("published", bool(base_metadata.get("published", True)))
        metadata.setdefault("build_version", base_metadata.get("build_version", ""))
        return metadata
