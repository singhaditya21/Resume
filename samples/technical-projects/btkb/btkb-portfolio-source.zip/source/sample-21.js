'use client';

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || '';

import { useEffect } from 'react';

// The separate admin login was removed. Admins now sign in through the single
// main login (/) like everyone else; the dashboard is reachable from the chat
// UI's profile menu (shown only to admins). This route just forwards there so
// old bookmarks/links don't 404.
export default function AdminLoginRedirect() {
    useEffect(() => {
        window.location.replace(`${BASE_PATH}/`);
    }, []);
    return null;
}
