"""
LLM Client — Groq-only.

This deployment uses Groq Cloud exclusively (company tie-up, fastest
inference). Cerebras and local llama.cpp fallbacks have been removed.

Usage:
    from app.llm_client import get_llm, get_embed_model, record_llm_usage

    llm = get_llm()                # returns the Groq LLM
    response = llm.complete(prompt)
    record_llm_usage(len(str(response)) // 4)  # approximate token count
"""
import os
import random
import time
from typing import Optional

import httpx

from app.config import settings


# ---------------------------------------------------------------------------
# Cached instances
# ---------------------------------------------------------------------------
_groq_llm = None
_embed_instance = None
_groq_limiter = None

# Always Groq in this build (kept for status reporting compatibility).
_active_provider = "groq"

# ---------------------------------------------------------------------------
# Embedding HTTP transport (pooled) + lightweight circuit breaker
# ---------------------------------------------------------------------------
# A single pooled httpx client reused across embedding calls — keep-alive
# avoids a fresh TCP/TLS handshake per request to the .201 gateway, and the
# bounded timeouts/limits prevent a slow gateway from pinning the whole app.
_EMBED_HTTP = httpx.Client(
    timeout=httpx.Timeout(
        connect=3.0,
        read=float(os.environ.get("EMBED_TIMEOUT_S", "8")),
        write=5.0,
        pool=3.0,
    ),
    limits=httpx.Limits(max_connections=64, max_keepalive_connections=32),
)

# Minimal in-process circuit breaker for the embedding gateway. After
# EMBED_BREAKER_THRESHOLD consecutive failures we fail fast for
# EMBED_BREAKER_COOLDOWN_S seconds instead of hammering a dead backend; any
# success resets the counter.
_EMBED_BREAKER_THRESHOLD = 5
_EMBED_BREAKER_COOLDOWN_S = 30.0
_embed_consecutive_failures = 0
_embed_breaker_open_until = 0.0


def _get_groq_llm():
    """Get or create the Groq Cloud LLM instance."""
    global _groq_llm
    if _groq_llm is not None:
        return _groq_llm

    if not settings.GROQ_API_KEY:
        raise RuntimeError("GROQ_API_KEY is not configured — this build is Groq-only.")

    from llama_index.llms.openai_like import OpenAILike

    _groq_llm = OpenAILike(
        model=settings.GROQ_MODEL,
        api_base=settings.GROQ_BASE_URL,
        api_key=REDACTED_SECRET
        is_chat_model=True,
        is_function_calling_model=False,
        timeout=settings.LLM_REQUEST_TIMEOUT,
        context_window=settings.GROQ_CONTEXT_WINDOW,
        max_tokens=REDACTED_SECRET
        temperature=settings.GEN_TEMPERATURE,  # 0 = deterministic, grounded-RAG default
    )
    print(f"✓ Groq Cloud LLM ready: {settings.GROQ_MODEL} @ {settings.GROQ_BASE_URL}")
    return _groq_llm


def _get_groq_limiter():
    """Get or create the Groq rate limiter (for usage tracking / status)."""
    global _groq_limiter
    if _groq_limiter is not None:
        return _groq_limiter

    from app.rate_limiter import CerebrasRateLimiter
    _groq_limiter = CerebrasRateLimiter(
        settings.GROQ_RPM, settings.GROQ_RPH, settings.GROQ_RPD,
        settings.GROQ_TPM, settings.GROQ_TPH, settings.GROQ_TPD,
    )
    print(f"✓ Groq rate limiter initialized "
          f"(RPM={settings.GROQ_RPM}, TPM={settings.GROQ_TPM})")
    return _groq_limiter


def get_llm(
    model: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
    context_window: Optional[int] = None,
):
    """
    Return the Groq LLM instance.

    Args:
        model, base_url, timeout, context_window: Legacy params (ignored;
            kept for backward compatibility).
    """
    global _active_provider
    _get_groq_limiter()          # ensure limiter exists for usage tracking
    _active_provider = "groq"
    return _get_groq_llm()


_alt_gen_llm = None
def get_gen_llm(alt: str = ""):
    """Generation-LLM override for A/B tests. alt='' -> default Groq generator;
    alt set -> an alternate OpenAI-compatible backend (e.g. NVIDIA qwen3.5-122b)
    configured from GEN_ALT_BASE / GEN_ALT_MODEL / GEN_ALT_KEY env. Generation only;
    retrieval/Settings.llm are untouched, and production (no override) stays on Groq."""
    import os
    global _alt_gen_llm
    if not alt:
        return get_llm()
    if _alt_gen_llm is None:
        from llama_index.llms.openai_like import OpenAILike
        _alt_gen_llm = OpenAILike(
            model=os.environ.get("GEN_ALT_MODEL", "qwen/qwen3.5-122b-a10b"),
            api_base=os.environ.get("GEN_ALT_BASE", "https://example.invalid"),
            api_key=os.environ.get("GEN_ALT_KEY", ""),
            is_chat_model=True,
            is_function_calling_model=False,
            timeout=settings.LLM_REQUEST_TIMEOUT,
            context_window=32000,
            max_tokens=REDACTED_SECRET
            temperature=0.1,
        )
        print(f"✓ Alt generation LLM ready: {os.environ.get('GEN_ALT_MODEL','qwen/qwen3.5-122b-a10b')}")
    return _alt_gen_llm


def record_llm_usage(tokens: int = 0):
    """Record token usage after a Groq completion."""
    if settings.GROQ_API_KEY:
        _get_groq_limiter().record_usage(tokens)


def groq_can_request() -> bool:
    """Whether the Groq limiter currently allows a request.

    Degrades open: any error in the limiter must never hard-block traffic, so
    on any exception we return True rather than propagating.
    """
    try:
        return _get_groq_limiter().can_request()
    except Exception:
        return True


def get_embed_model(model_name: Optional[str] = None):
    """
    Get or create the embedding model.

    Embeddings are served by the OpenAI-compatible gateway (EMBED_BASE_URL +
    EMBED_MODEL, e.g. qwen3-embed / 4096-d on the DGX). The query embedding MUST
    match the model + dimension the Milvus collection was built with.
    """
    global _embed_instance
    if _embed_instance is not None:
        return _embed_instance

    provider = os.environ.get("EMBED_PROVIDER", "gateway").lower()

    if provider in ("gateway", "openai", "litellm", "vllm"):
        # OpenAI-compatible /v1/embeddings: LiteLLM/vLLM gateway serving
        # qwen3-embed (Qwen3-Embedding-8B, 4096-d) on the DGX. EMBED_BASE_URL
        # points at the gateway (e.g. .201:4000/v1).
        from llama_index.core.embeddings import BaseEmbedding
        from pydantic import Field

        base = os.environ.get("EMBED_BASE_URL", "http://localhost:4000/v1").rstrip("/")
        mdl = model_name or os.environ.get("EMBED_MODEL", "qwen3-embed")
        key = os.environ.get("EMBED_API_KEY", "")

        class _OpenAIEmbedding(BaseEmbedding):
            base_url: str = Field(default=base)
            model: str = Field(default=mdl)
            api_key: str = Field(default=key)

            def _embed_batch(self, texts):
                global _embed_consecutive_failures, _embed_breaker_open_until

                # Circuit breaker: fail fast while the gateway is presumed down.
                now = time.time()
                if _embed_breaker_open_until and now < _embed_breaker_open_until:
                    raise RuntimeError(
                        "Embedding gateway circuit breaker is open "
                        f"(cooling down for {_embed_breaker_open_until - now:.1f}s)"
                    )

                url = self.base_url + "/embeddings"
                payload = {"model": self.model, "input": texts}
                headers = {"Content-Type": "application/json"}
                if self.api_key:
                    headers["Authorization"] = "Bearer " + self.api_key

                last_exc = None
                # 1 initial attempt + up to 2 retries on transient transport errors.
                for attempt in range(3):
                    try:
                        resp = _EMBED_HTTP.post(url, json=payload, headers=headers)
                        resp.raise_for_status()
                        data = resp.json()["data"]
                        result = [
                            d["embedding"]
                            for d in sorted(data, key=lambda x: x.get("index", 0))
                        ]
                        # Success — reset breaker state.
                        _embed_consecutive_failures = 0
                        _embed_breaker_open_until = 0.0
                        return result
                    except (httpx.TimeoutException, httpx.TransportError) as exc:
                        last_exc = exc
                        if attempt < 2:
                            # Tiny exponential backoff with jitter.
                            backoff = (0.2 * (2 ** attempt)) + random.uniform(0, 0.2)
                            time.sleep(backoff)
                            continue

                # All attempts exhausted — record failure and maybe trip breaker.
                _embed_consecutive_failures += 1
                if _embed_consecutive_failures >= _EMBED_BREAKER_THRESHOLD:
                    _embed_breaker_open_until = time.time() + _EMBED_BREAKER_COOLDOWN_S
                raise last_exc

            def _get_query_embedding(self, query):
                return self._embed_batch([query])[0]

            def _get_text_embedding(self, text):
                return self._embed_batch([text])[0]

            def _get_text_embeddings(self, texts):
                return self._embed_batch(texts)

            async def _aget_query_embedding(self, query):
                return self._embed_batch([query])[0]

            async def _aget_text_embedding(self, text):
                return self._embed_batch([text])[0]

        _embed_instance = _OpenAIEmbedding()
        print(f"✓ Embeddings via gateway (OpenAI API): {mdl} @ {base}")
        return _embed_instance

    raise RuntimeError(
        f"Unsupported EMBED_PROVIDER={provider!r}; embeddings are served via the "
        "OpenAI-compatible gateway (set EMBED_PROVIDER=gateway)."
    )


def health_check() -> dict:
    """Check Groq LLM provider status."""
    result = {
        "active_provider": _active_provider,
        "groq": {"status": "not_configured"},
    }

    if settings.GROQ_API_KEY:
        groq_limiter = _get_groq_limiter()
        result["groq"] = {
            "status": "ok" if groq_limiter.can_request() else "rate_limited",
            "model": settings.GROQ_MODEL,
            "url": settings.GROQ_BASE_URL,
            "rate_limits": groq_limiter.get_status(),
        }
        if not groq_limiter.can_request():
            result["groq"]["limiting_window"] = groq_limiter.limiting_window()

    return result
