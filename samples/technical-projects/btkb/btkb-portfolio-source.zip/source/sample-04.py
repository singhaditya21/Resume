"""
Agentic RAG Module
Implements ReAct (Reason + Act) pattern for multi-step reasoning with tool use.
"""
import re
import json
from typing import List, Dict, Any, Callable, Optional
from dataclasses import dataclass


@dataclass
class Tool:
    """Definition of a tool the agent can use."""
    name: str
    description: str
    function: Callable
    parameters: Dict[str, str]  # param_name: description


REACT_SYSTEM_PROMPT = """You are an intelligent research agent with access to tools. 
Use the ReAct pattern: Thought → Action → Observation → Thought → ... → Final Answer

Available Tools:
{tool_descriptions}

When you need to use a tool, output in this EXACT format:
Thought: [Your reasoning about what to do next]
Action: [tool_name]
Action Input: [input for the tool]

After receiving an Observation, continue reasoning until you have enough information.

When you have the final answer, output:
Thought: I now have enough information to answer.
Final Answer: [Your complete answer]

IMPORTANT:
- Think step-by-step
- Use tools when you need more information
- Don't make up information - use tools to verify
- Cite your sources when giving the final answer
"""


REACT_PROMPT = """Question: {question}

Begin your reasoning. Remember to use tools when you need information.

Thought:"""


class AgenticRAG:
    """
    ReAct-style agentic RAG system.
    
    The agent can:
    1. Search documents for information
    2. Refine queries for better retrieval
    3. Compare multiple sources
    4. Summarize long content
    5. Answer with citations
    """
    
    def __init__(self, llm, retriever, max_iterations: int = 5):
        self.llm = llm
        self.retriever = retriever
        self.max_iterations = max_iterations
        self.tools = self._create_tools()
        self.execution_trace = []
        # Per-request ACL scope; set by run()/run_streaming(). None = unrestricted.
        # EVERY internal retrieve() must pass acl=self.acl so agentic mode cannot
        # route around folder/team authorization.
        self.acl = None
    
    def _create_tools(self) -> Dict[str, Tool]:
        """Create available tools for the agent."""
        return {
            "search_documents": Tool(
                name="search_documents",
                description="Search the knowledge base for relevant documents. Use this to find information about a specific topic.",
                function=self._tool_search,
                parameters={"query": "The search query to find relevant documents"}
            ),
            "refine_query": Tool(
                name="refine_query",
                description="Reformulate a query to get better search results. Use when initial search didn't find good results.",
                function=self._tool_refine_query,
                parameters={"original_query": "The original query", "context": "What you're looking for"}
            ),
            "compare_sources": Tool(
                name="compare_sources",
                description="Compare information from multiple documents to find differences or agreements.",
                function=self._tool_compare,
                parameters={"topic": "The topic to compare across sources"}
            ),
            "summarize": Tool(
                name="summarize",
                description="Summarize a long piece of text into key points.",
                function=self._tool_summarize,
                parameters={"text": "The text to summarize"}
            ),
            "extract_facts": Tool(
                name="extract_facts",
                description="Extract specific facts or data points from retrieved documents.",
                function=self._tool_extract_facts,
                parameters={"query": "What facts to look for"}
            )
        }
    
    def _tool_search(self, query: str) -> str:
        """Search documents tool."""
        try:
            nodes, confidence = self.retriever.retrieve(query, top_k=3, acl=self.acl)
            if not nodes:
                return "No relevant documents found."
            
            results = []
            for i, node in enumerate(nodes):
                meta = node.node.metadata or {}
                source = meta.get("source_path", meta.get("file_path", "Unknown"))
                text = node.node.text[:400]
                results.append(f"[Source {i+1}: {source}]\n{text}")
            
            return "\n\n".join(results)
        except Exception as e:
            return f"Search failed: {e}"
    
    def _tool_refine_query(self, original_query: str, context: str = "") -> str:
        """Refine query for better results."""
        prompt = f"""Reformulate this search query to get better results.
        
Original query: {original_query}
What we're looking for: {context}

Write 3 alternative search queries:
1."""
        
        response = str(self.llm.complete(prompt))
        return f"Alternative querie/opt/portfolio/project"
    
    def _tool_compare(self, topic: str) -> str:
        """Compare sources on a topic."""
        nodes, _ = self.retriever.retrieve(topic, top_k=5, acl=self.acl)

        if not nodes:
            return "No documents found to compare."
        
        # Get unique sources
        sources = {}
        for node in nodes:
            meta = node.node.metadata or {}
            source = meta.get("source_path", meta.get("file_path", "Unknown"))
            if source not in sources:
                sources[source] = node.node.text[:300]
        
        comparison = [f"## {src}\n{text}" for src, text in sources.items()]
        return "Sources foun/opt/portfolio/project" + "\n\n".join(comparison)
    
    def _tool_summarize(self, text: str) -> str:
        """Summarize text."""
        prompt = f"Summarize this in 3-4 bullet point/opt/portfolio/project"
        return str(self.llm.complete(prompt))
    
    def _tool_extract_facts(self, query: str) -> str:
        """Extract specific facts."""
        nodes, _ = self.retriever.retrieve(query, top_k=3, acl=self.acl)

        if not nodes:
            return "No relevant documents found."
        
        context = "\n\n".join([n.node.text for n in nodes])
        prompt = f"""Extract specific facts related to "{query}" from this context:

{context[:2500]}

Facts (bullet points):"""
        
        return str(self.llm.complete(prompt))
    
    def _get_tool_descriptions(self) -> str:
        """Format tool descriptions for the prompt."""
        descriptions = []
        for name, tool in self.tools.items():
            params = ", ".join([f"{k}: {v}" for k, v in tool.parameters.items()])
            descriptions.append(f"- {name}({params}): {tool.description}")
        return "\n".join(descriptions)
    
    def _parse_action(self, text: str) -> Optional[tuple]:
        """Parse action and action input from LLM response."""
        # Look for Action: and Action Input: patterns
        action_match = re.search(r'Actio/opt/portfolio/project', text, re.IGNORECASE)
        input_match = re.search(r'Action Inpu/opt/portfolio/project', text, re.IGNORECASE | re.DOTALL)
        
        if action_match and input_match:
            return action_match.group(1).strip(), input_match.group(1).strip()
        return None
    
    def _parse_final_answer(self, text: str) -> Optional[str]:
        """Parse final answer from LLM response."""
        match = re.search(r'Final Answe/opt/portfolio/project', text, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
        return None
    
    def execute_tool(self, tool_name: str, tool_input: str) -> str:
        """Execute a tool and return the result."""
        tool_name_lower = tool_name.lower()
        
        if tool_name_lower not in self.tools:
            return f"Unknown tool: {tool_name}. Available tools: {list(self.tools.keys())}"
        
        tool = self.tools[tool_name_lower]
        
        try:
            # Handle different parameter patterns
            if tool_name_lower == "refine_query":
                # Parse two parameters
                parts = tool_input.split(",", 1)
                if len(parts) == 2:
                    return tool.function(parts[0].strip(), parts[1].strip())
                return tool.function(tool_input, "")
            else:
                return tool.function(tool_input)
        except Exception as e:
            return f"Tool error: {e}"
    
    def run(self, question: str, acl=None) -> Dict[str, Any]:
        """
        Run the ReAct loop to answer a question. `acl` (None = unrestricted) scopes
        EVERY tool retrieval so agentic mode honors the same folder/team ACL as the
        primary path.

        Returns:
            {
                "answer": Final answer,
                "trace": List of (thought, action, observation) tuples,
                "iterations": Number of iterations,
                "success": bool
            }
        """
        self.acl = acl
        self.execution_trace = []
        
        # Build the initial prompt
        system = REACT_SYSTEM_PROMPT.format(tool_descriptions=self._get_tool_descriptions())
        user_prompt = REACT_PROMPT.format(question=question)
        
        # Keep conversation history
        conversation = f"{system}\n\n{user_prompt}"
        
        for iteration in range(self.max_iterations):
            # Get LLM response
            response = str(self.llm.complete(conversation))
            
            # Check for final answer
            final_answer = self._parse_final_answer(response)
            if final_answer:
                self.execution_trace.append({
                    "type": "final",
                    "content": final_answer
                })
                return {
                    "answer": final_answer,
                    "trace": self.execution_trace,
                    "iterations": iteration + 1,
                    "success": True
                }
            
            # Parse action
            action_result = self._parse_action(response)
            if not action_result:
                # No action found, try to get answer
                conversation += f"\n{response}\n\nThought: I should provide a final answer based on what I know.\nFinal Answer:"
                continue
            
            tool_name, tool_input = action_result
            
            # Log the thought and action
            thought_match = re.search(r'Though/opt/portfolio/project', response, re.IGNORECASE | re.DOTALL)
            thought = thought_match.group(1).strip() if thought_match else ""
            
            self.execution_trace.append({
                "type": "step",
                "thought": thought,
                "action": tool_name,
                "action_input": tool_input
            })
            
            # Execute tool
            observation = self.execute_tool(tool_name, tool_input)
            
            self.execution_trace.append({
                "type": "observation",
                "content": observation[:1000]  # Truncate long observations
            })
            
            # Add to conversation
            conversation += f"\n{response}\nObservation: {observation}\n\nThought:"
        
        # Max iterations reached
        return {
            "answer": "I was unable to find a complete answer within the allowed steps.",
            "trace": self.execution_trace,
            "iterations": self.max_iterations,
            "success": False
        }
    
    async def run_streaming(self, question: str, acl=None):
        """
        Stream the ReAct execution. `acl` (None = unrestricted) scopes all retrieval.

        Yields:
            {"type": "thought" | "action" | "observation" | "answer", "content": str}
        """
        # Run synchronously but yield results
        result = self.run(question, acl=acl)
        
        for step in result["trace"]:
            if step["type"] == "step":
                yield {"type": "thought", "content": step["thought"]}
                yield {"type": "action", "content": f"{step['action']}({step['action_input']})"}
            elif step["type"] == "observation":
                yield {"type": "observation", "content": step["content"][:500] + "..."}
            elif step["type"] == "final":
                yield {"type": "answer", "content": step["content"]}
        
        if not result["success"]:
            yield {"type": "answer", "content": result["answer"]}
