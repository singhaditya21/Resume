"""
Advanced Retrieval Module
Implements hosted Qwen3-Reranker reranking, HyDE query expansion, hybrid BM25+vector
search, synonym-aware query expansion, and persistent caching.
"""
import os
import re
import json
import sqlite3
import time as _time
import random as _random
import pickle
import httpx
import logging
from typing import List, Dict, Any, Tuple, Optional
from app.config import settings

_logger = logging.getLogger(__name__)

# Reranking is the hosted Qwen3-Reranker (DGX vLLM); its result cache is _rerank_cache below.

# Confidence GATE (RCA + deep-research): the reranker orders candidates well but is
# NOT a reliable answer/refuse gate — the hosted Qwen3-Reranker over-scores
# irrelevant queries (~0.97). The dense embedder cleanly
# separates in-domain queries from junk, so we gate on it: confidence = dense top-sim
# remapped through [LO, HI] -> [0, 1]. These bounds are DATA-DEPENDENT (they shift with
# the embedding setup + corpus). RE-CALIBRATED for the full re-ingested zeno_rag (~32k
# rows, vLLM qwen3-embed): in-domain top-sim ranges ~0.65–0.95 (median 0.86), out-of-
# domain ~0.50–0.72 (they OVERLAP, so no threshold is perfect). MEASURED (2026-06-24): real
# RECALIBRATED for the F-2 structure-aware corpus (2026-07-19). The old corpus mixed junk
# and in-domain queries in one 0.55-0.65 band, forcing a permissive LO=0.40. The F-2 corpus
# (contextual [Title > breadcrumb] prefixes) separates them cleanly — measured: junk tops out
# ~0.62 (cricket 0.43, France 0.54, helicopter 0.56, iphone 0.59, out-of-corpus title 0.62)
# while every in-domain query lands >=0.70 (weakest observed: entity-definition 0.70; redis/
# autoflow/campaign saturate at 0.75+). BUT terse release/alias queries ("what is r3",
# thin policy docs) sit ~0.58-0.65 — LO=0.55 (refuse line at sim ~0.61) false-refused that
# whole class on the stage golden. LO=0.50 keeps them answering (release ~0.60 -> conf ~0.40,
# shown as low relevance) while junk still hard-refuses (helicopter 0.56 -> conf 0.24 < 0.30).
# Old corpus? Set DENSE_GATE_LO=0.40 via env — display/gate scaling only.
DENSE_GATE_LO = float(os.environ.get("DENSE_GATE_LO", "0.50"))
# HI was 0.90 — but well-answered queries in this corpus dense-match ~0.65-0.72, so they
# displayed a pessimistic 45-56% confidence (eval judges flagged "too low for a correct
# answer"). Lower HI so a correct answer (~0.68 dense) reads ~0.80. Only the DISPLAY / gate
# scaling changes; the refuse decision (confidence < 0.30) stays source-bounded-generation
# backed. Revert via DENSE_GATE_HI=0.90.
DENSE_GATE_HI = float(os.environ.get("DENSE_GATE_HI", "0.75"))


def _calib_display(dense_sim: float, rerank_score: float) -> float:
    """One-scale source-chip score: calibrated dense sim (the same remap the
    answer-confidence gate uses), with the reranker fallback capped at 0.70 so
    a sigmoid-saturated rerank score can never out-shout calibrated dense.
    Revert to the legacy max(dense, rerank) via MATCH_DISPLAY_CALIB=0."""
    if os.environ.get("MATCH_DISPLAY_CALIB", "1") != "1":
        return max(dense_sim or 0.0, rerank_score or 0.0)
    span = max(1e-6, DENSE_GATE_HI - DENSE_GATE_LO)
    dcal = max(0.0, min(1.0, ((dense_sim or 0.0) - DENSE_GATE_LO) / span)) if dense_sim else 0.0
    return max(dcal, min(rerank_score or 0.0, 0.70))

# Retrieval RECALL knobs (2026-07-02, eval RCA): the dominant surviving failure was
# "the exact expected doc never entered a too-narrow dense pool" → generic answer or a
# false refuse (e.g. DMS Settings had a full config table but wasn't retrieved). Widen
# the CANDIDATE FUNNEL so the reranker + title-boost can pick the right doc; the FINAL
# answer top_k is deliberately NOT raised (A/B runs #19-24: top_k=3 beats 5 — more
# context = more hallucination). Revert via env (RETRIEVAL_DENSE_K=20, POOL_CAP=35).
RETRIEVAL_DENSE_K = int(os.environ.get("RETRIEVAL_DENSE_K", "40"))
RETRIEVAL_POOL_CAP = int(os.environ.get("RETRIEVAL_POOL_CAP", "50"))

# ── Persistent Query Cache (SQLite-backed) ──────────────────────
_CACHE_DB_PATH = os.path.join(settings.WORKSPACE_DIR, "query_cache.db")

def _init_cache_db():
    """Create the cache table if it doesn't exist."""
    conn = sqlite3.connect(_CACHE_DB_PATH)
    # Durability under concurrent reads/writes: WAL lets readers and a writer
    # proceed without locking each other out, and a busy_timeout backs off
    # instead of raising 'database is locked' on contention. Best-effort.
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
    except Exception:
        pass
    conn.execute("""
        CREATE TABLE IF NOT EXISTS query_cache (
            cache_key TEXT PRIMARY KEY,
            result BLOB,
            created_at REAL,
            query_text TEXT
        )
    """)
    conn.commit()
    conn.close()

_init_cache_db()

def _cache_get(key: str) -> Optional[Any]:
    """Get a cached result by key. Returns None if expired or missing."""
    try:
        conn = sqlite3.connect(_CACHE_DB_PATH)
        row = conn.execute(
            "SELECT result, created_at FROM query_cache WHERE cache_key = ?",
            (key,)
        ).fetchone()
        conn.close()
        if row:
            result_blob, created_at = row
            if _time.time() - created_at < settings.QUERY_CACHE_TTL:
                return pickle.loads(result_blob)
            # Expired — delete
            _cache_delete(key)
    except Exception:
        pass
    return None

def _cache_put(key: str, result: Any, query_text: str = ""):
    """Store a result in the persistent cache."""
    try:
        conn = sqlite3.connect(_CACHE_DB_PATH)
        blob = pickle.dumps(result)
        conn.execute(
            "INSERT OR REPLACE INTO query_cache (cache_key, result, created_at, query_text) VALUES (?, ?, ?, ?)",
            (key, blob, _time.time(), query_text[:200])
        )
        # Enforce max size
        count = conn.execute("SELECT COUNT(*) FROM query_cache").fetchone()[0]
        if count > settings.QUERY_CACHE_MAX_SIZE:
            conn.execute("""
                DELETE FROM query_cache WHERE cache_key IN (
                    SELECT cache_key FROM query_cache ORDER BY created_at ASC LIMIT ?
                )
            """, (count - settings.QUERY_CACHE_MAX_SIZE,))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[QueryCache] Write error: {e}")

def _cache_delete(key: str):
    try:
        conn = sqlite3.connect(_CACHE_DB_PATH)
        conn.execute("DELETE FROM query_cache WHERE cache_key = ?", (key,))
        conn.commit()
        conn.close()
    except Exception:
        pass

# ── Synonym Dictionary (loaded from training data) ──────────────
_synonym_dict = None

def _load_synonyms() -> Dict[str, List[str]]:
    """Load synonym mappings from training data if available."""
    global _synonym_dict
    if _synonym_dict is not None:
        return _synonym_dict
    _synonym_dict = {}
    syn_file = os.path.join(settings.TRAINING_DIR, "master_synonyms.json")
    if os.path.exists(syn_file):
        try:
            with open(syn_file, "r", encoding="utf-8") as f:
                synonyms = json.load(f)
            for entry in synonyms:
                term = entry.get("term", "").lower().strip()
                syns = entry.get("synonyms", [])
                if term and syns:
                    _synonym_dict[term] = [s.lower() for s in syns]
                    # Also map synonyms back to term
                    for s in syns:
                        _synonym_dict[s.lower().strip()] = [term]
            print(f"[Synonyms] Loaded {len(_synonym_dict)} synonym mappings")
        except Exception as e:
            print(f"[Synonyms] Could not load: {e}")
    return _synonym_dict

def expand_query_with_synonyms(query: str) -> str:
    """Expand query with synonyms for better retrieval."""
    synonyms = _load_synonyms()
    if not synonyms:
        return query
    words = query.lower().split()
    expansions = []
    for word in words:
        if word in synonyms:
            expansions.extend(synonyms[word][:3])  # Max 3 per term
    if expansions:
        return f"{query} {' '.join(set(expansions))}"
    return query


# ── Brand-token normalization (retrieval query only) ────────────
# "businessnext" (and spelling variants) appears in nearly every document, so it
# carries almost no discriminating signal — but appended to a query ("how caching
# works IN BUSINESSNEXT") it drags the dense embedding toward the generic brand
# centroid AND lets a short doc whose title merely echoes the brand outrank the real,
# content-rich article. We strip these tokens from the RETRIEVAL query only (the LLM
# prompt still shows the user's original words). Product names (CUSTOMERNEXT /
# DATANEXT / ORIGINATIONNEXT / MARKETINGNEXT / CRMNEXT) ARE discriminating and are
# deliberately NOT matched here.
_BRAND_PAT = re.compile(r"\b(?:business\s*next|b\s*\.?\s*next|bnext)\b", re.IGNORECASE)
_BRAND_RESIDUAL_STOP = {
    "how", "what", "is", "are", "am", "do", "does", "did", "the", "a", "an", "in",
    "on", "of", "for", "to", "and", "or", "i", "me", "my", "we", "our", "you",
    "your", "this", "that", "it", "work", "works", "working", "explain", "tell",
    "about", "please", "with", "can", "could", "would", "show", "give", "need", "want",
}


def normalize_retrieval_query(query: str) -> str:
    """Strip ubiquitous brand tokens from the dense/BM25 retrieval query. Falls back
    to the ORIGINAL when the brand word is essentially the whole subject (e.g.
    'what is businessnext') so brand-overview queries still retrieve correctly."""
    if not query or not _BRAND_PAT.search(query):
        return query
    s = _BRAND_PAT.sub(" ", query)
    s = re.sub(r"\s+", " ", s).strip()
    # drop a now-dangling trailing preposition/article + trailing punctuation
    s = re.sub(r"(?i)[\s,]*\b(?:in|on|for|of|at|with|the|a|an)\b[\s?.!,]*$", "", s)
    s = s.strip(" ?.!,")
    substantive = [w for w in re.findall(r"[a-z0-9]+", s.lower())
                   if len(w) > 2 and w not in _BRAND_RESIDUAL_STOP]
    if not substantive:
        return query  # brand WAS the subject — keep it
    return s


import hashlib as _hashlib

# ── Retrieval profile fingerprint ───────────────────────────────
# A 12-hex digest over every knob that changes WHAT the retriever returns or HOW it
# ranks. Folded into the persistent cache key so a config/profile change (model, dim,
# chunking, HyDE/rerank toggles, gate bounds, reranker identity) can never serve a
# result computed under a different profile. NEVER includes the reranker api_key.
_profile_fp_cache = None


def retrieval_profile_fingerprint() -> str:
    """12-hex md5 over the retrieval profile (collection/dim/embed model, chunking,
    HyDE/rerank toggles, dense-gate bounds, brand-normalize, reranker identity). Cached
    module-level; reset inside clear_retrieval_caches(). Reranker identity = model name
    + configured bool ONLY (never the api_key)."""
    global _profile_fp_cache
    if _profile_fp_cache is not None:
        return _profile_fp_cache
    try:
        r_url, r_model, r_key = _rerank_cfg()
    except Exception:
        r_url, r_model, r_key = None, None, None
    parts = [
        f"collection={getattr(settings, 'MILVUS_COLLECTION', '')}",
        f"dim={getattr(settings, 'MILVUS_DIM', '')}",
        f"embed={getattr(settings, 'EMBED_MODEL', '')}",
        f"chunk_size={getattr(settings, 'CHUNK_SIZE', '')}",
        f"chunk_overlap={getattr(settings, 'CHUNK_OVERLAP', '')}",
        f"hyde={getattr(settings, 'ENABLE_HYDE', '')}",
        f"rerank={getattr(settings, 'ENABLE_RERANKING', '')}",
        f"initial_k_mult={getattr(settings, 'RETRIEVAL_INITIAL_K_MULTIPLIER', '')}",
        f"gate_lo={DENSE_GATE_LO}",
        f"gate_hi={DENSE_GATE_HI}",
        f"brand_norm={os.environ.get('BRAND_NORMALIZE', '1')}",
        f"stitch={os.environ.get('NEIGHBOR_STITCH', '1')}",
        f"stitch_maxlen={os.environ.get('STITCH_STUB_MAXLEN', '200')}",
        f"rerank_model={r_model or ''}",
        f"rerank_configured={bool(r_url)}",
    ]
    _profile_fp_cache = _hashlib.md5("|".join(parts).encode()).hexdigest()[:12]
    return _profile_fp_cache


# Reranking cache — avoids re-scoring same query + same chunks
_rerank_cache = {}  # {(query_hash, chunk_ids_hash): (ranked_nodes, timestamp)}
RERANK_CACHE_TTL = 1800  # 30 min
RERANK_CACHE_MAX = 200


# ── Pooled rerank HTTP client + circuit breaker ─────────────────
# The rerank call to the .201 gateway is an ENHANCEMENT, never a hard dependency.
# A module-level pooled httpx client reuses TCP/keepalive (no fresh handshake per
# query) and bounds the read with RERANK_TIMEOUT_S. A minimal consecutive-failure
# breaker opens for RERANK_BREAKER_OPEN_S after RERANK_BREAKER_FAILS straight fails
# so a flapping/slow reranker can't pile up latency on every query — callers fall
# back to the pre-rerank candidate order.
_RERANK_TIMEOUT_S = float(os.environ.get("RERANK_TIMEOUT_S", "8"))
_RERANK_MAX_RETRIES = int(os.environ.get("RERANK_MAX_RETRIES", "2"))
_RERANK_BREAKER_FAILS = int(os.environ.get("RERANK_BREAKER_FAILS", "5"))
_RERANK_BREAKER_OPEN_S = float(os.environ.get("RERANK_BREAKER_OPEN_S", "30"))

_rerank_http_client = None
_rerank_breaker = {"fails": 0, "open_until": 0.0}


def _get_rerank_client():
    """Lazily build the pooled httpx client for rerank calls. Read timeout is
    RERANK_TIMEOUT_S (default 8), connect 3s; bounded connection pool with keepalive
    so repeated reranks reuse sockets to the gateway."""
    global _rerank_http_client
    if _rerank_http_client is None:
        _rerank_http_client = httpx.Client(
            timeout=httpx.Timeout(_RERANK_TIMEOUT_S, connect=3.0),
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32),
        )
    return _rerank_http_client


def _rerank_breaker_open() -> bool:
    """True while the breaker is open (skip the network call, fall back)."""
    return _time.time() < _rerank_breaker["open_until"]


def _rerank_record_success():
    _rerank_breaker["fails"] = 0
    _rerank_breaker["open_until"] = 0.0


def _rerank_record_failure():
    _rerank_breaker["fails"] += 1
    if _rerank_breaker["fails"] >= _RERANK_BREAKER_FAILS:
        _rerank_breaker["open_until"] = _time.time() + _RERANK_BREAKER_OPEN_S
        print(f"[Rerank] breaker OPEN after {_rerank_breaker['fails']} consecutive "
              f"failures; skipping reranker for {_RERANK_BREAKER_OPEN_S:.0f}s")
        # Page on a real in-traffic failure: the hosted reranker is down and we are
        # now serving the (un-reranked) retrieval order. Deduped + fail-open.
        try:
            from app.alerting import alert
            alert("reranker_down",
                  f"hosted reranker failed {_rerank_breaker['fails']}x; breaker open "
                  f"{_RERANK_BREAKER_OPEN_S:.0f}s — serving retrieval order",
                  dedup_key="reranker_breaker_open")
        except Exception:
            pass


def _rerank_cfg():
    """Hosted reranker config: env first, then an on-disk file (hot-patch/testing).
    Returns (url, model, api_key), or (None, None, None) if not configured (reranking is then skipped)."""
    url = os.environ.get("RERANK_URL")
    if url:
        return url, os.environ.get("RERANK_MODEL", "qwen3-rerank"), os.environ.get("RERANK_API_KEY", "")
    try:
        with open("/app/INTELLIGENCE/rerank.json") as f:
            c = json.load(f)
        if c.get("url"):
            return c["url"], c.get("model", "qwen3-rerank"), c.get("api_key", "")
    except Exception:
        pass
    return None, None, None


def _hosted_rerank(url, model, key, query, texts):
    """Call an OpenAI/Jina-style hosted reranker (vLLM Qwen3-Reranker on the DGX)
    via the pooled httpx client. Bounded by RERANK_TIMEOUT_S with up to
    RERANK_MAX_RETRIES jittered retries; records breaker success/failure. Raises on
    exhausted retries (caller falls back to the pre-rerank order — reranking is an
    enhancement, never a hard dependency).
    Returns [(orig_index, relevance_score), ...] sorted by relevance desc."""
    payload = {"model": model, "query": query, "documents": texts}
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    client = _get_rerank_client()
    last_exc = None
    for attempt in range(_RERANK_MAX_RETRIES + 1):
        try:
            resp = client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            _rerank_record_success()
            return [(res["index"], float(res.get("relevance_score", 0.0)))
                    for res in data.get("results", [])]
        except Exception as e:
            last_exc = e
            if attempt < _RERANK_MAX_RETRIES:
                # jittered backoff before retry; keeps a transient blip from failing the call
                _time.sleep(min(1.0, 0.15 * (attempt + 1)) + _random.uniform(0.0, 0.15))
    _rerank_record_failure()
    raise last_exc


def _redact_url(url: Optional[str]) -> Optional[str]:
    """Strip any userinfo / query / fragment from a URL so a credential embedded in it
    is never surfaced by a health endpoint. Returns scheme://host[:port]/path only."""
    if not url:
        return url
    try:
        from urllib.parse import urlsplit, urlunsplit
        s = urlsplit(url)
        host = s.hostname or ""
        if s.port:
            host = f"{host}:{s.port}"
        return urlunsplit((s.scheme, host, s.path, "", ""))
    except Exception:
        return url


def reranker_health(probe: bool = False) -> dict:
    """Report hosted-reranker config + (optionally) live reachability. NEVER exposes the
    api_key. url is redacted (no userinfo/query). source tells where config came from
    ('env' | 'rerank.json' | None). When probe=True, fires a tiny ['a','b'] rerank and
    records reachable / latency_ms / error / degraded."""
    url, model, key = _rerank_cfg()
    source = None
    if os.environ.get("RERANK_URL"):
        source = "env"
    elif url:
        source = "rerank.json"
    out = {
        "enabled": bool(getattr(settings, "ENABLE_RERANKING", False)),
        "configured": bool(url),
        "model": model,
        "url": _redact_url(url),
        "source": source,
        "reachable": None,
        "degraded": False,
    }
    if probe and url:
        t0 = _time.time()
        try:
            results = _hosted_rerank(url, model, key, "a", ["a", "b"])
            out["reachable"] = True
            out["latency_ms"] = round((_time.time() - t0) * 1000.0, 1)
            if not results:
                out["degraded"] = True
                out["error"] = "empty results"
        except Exception as e:
            out["reachable"] = False
            out["degraded"] = True
            out["latency_ms"] = round((_time.time() - t0) * 1000.0, 1)
            out["error"] = str(e)
    elif probe and not url:
        # Reranking enabled but nothing configured to probe → degraded if enabled.
        out["degraded"] = bool(out["enabled"])
    return out


# CANONICAL fields the production retriever actually reads back from Milvus.
# NOTE: workers/storer/worker.py writes a DIFFERENT raw schema — its vector field is
# named 'vector' (not 'embedding') and it adds source_folder/chunk_id. That naming is
# INCOMPATIBLE with what this retriever joins on; if those drift fields ever appear in a
# live collection we flag drift so the mismatch surfaces before it silently breaks recall.
_EXPECTED_MILVUS_FIELDS = {"id", "doc_id", "text", "embedding", "uri", "title", "source_url",
                           "access_teams", "visibility"}  # ACL fields the retriever fail-closes on
# When the postmortem retrieval flags are on, the dense store requests these
# node fields on EVERY search — a collection missing them must fail loud here
# (health drift) instead of erroring on every query (review B1). With flags
# OFF they are not expected, so legacy collections report healthy unchanged.
if (os.environ.get("HYBRID_ID_FIX", "0") == "1"
        or os.environ.get("RERANK_DOC_FORMAT", "body") == "f4"):
    _EXPECTED_MILVUS_FIELDS = _EXPECTED_MILVUS_FIELDS | {"heading_path", "content_type"}
_DRIFT_MILVUS_FIELDS = {"vector", "source_folder", "chunk_id"}


def milvus_schema_health() -> dict:
    """NON-DESTRUCTIVE describe_collection on the live collection. Reports which expected
    fields are present, the vector dim vs settings.MILVUS_DIM, and whether the schema has
    drifted (missing expected fields OR a dim mismatch OR the incompatible storer/worker
    field naming)."""
    out = {
        "collection": getattr(settings, "MILVUS_COLLECTION", None),
        "fields_present": [],
        "vector_dim": None,
        "expected_dim": getattr(settings, "MILVUS_DIM", None),
        "dim_ok": False,
        "missing_expected_fields": sorted(_EXPECTED_MILVUS_FIELDS),
        "drift": True,
    }
    try:
        from data.milvus_store import get_milvus_client
        client = get_milvus_client()
        desc = client.describe_collection(collection_name=out["collection"])
        fields = desc.get("fields", []) if isinstance(desc, dict) else getattr(desc, "fields", [])
        present = []
        vector_dim = None
        for f in fields:
            name = f.get("name") if isinstance(f, dict) else getattr(f, "name", None)
            if not name:
                continue
            present.append(name)
            params = f.get("params") if isinstance(f, dict) else getattr(f, "params", None)
            _dim = None
            if isinstance(params, dict):
                _dim = params.get("dim")
            elif params is not None:
                _dim = getattr(params, "dim", None)
            if _dim is None:  # some clients expose dim directly on the field
                _dim = f.get("dim") if isinstance(f, dict) else getattr(f, "dim", None)
            if _dim is not None:
                try:
                    vector_dim = int(_dim)
                except Exception:
                    pass
        present_set = set(present)
        missing = sorted(_EXPECTED_MILVUS_FIELDS - present_set)
        drift_fields_seen = sorted(_DRIFT_MILVUS_FIELDS & present_set)
        dim_ok = (vector_dim is not None and out["expected_dim"] is not None
                  and int(vector_dim) == int(out["expected_dim"]))
        out.update({
            "fields_present": present,
            "vector_dim": vector_dim,
            "dim_ok": bool(dim_ok),
            "missing_expected_fields": missing,
            "drift_fields_seen": drift_fields_seen,
            "drift": bool(missing) or (not dim_ok) or bool(drift_fields_seen),
        })
    except Exception as e:
        out["error"] = str(e)
        out["drift"] = None  # unreachable / describe error ≠ drifted — distinct state
    return out


def fusion_identity(nws) -> str:
    """Stable identity for RRF fusion. With HYBRID_ID_FIX=1, prefer the Milvus
    primary key carried in node metadata (store output_fields) — node_id is a
    fresh UUID per read on this _node_content-less collection and can NEVER
    match the BM25 lane's Milvus ids (RCA E5, RETRIEVAL-POSTMORTEM-2026-07)."""
    if os.environ.get("HYBRID_ID_FIX", "0") == "1":
        mid = (getattr(nws.node, "metadata", None) or {}).get("id")
        if mid:
            return mid
    return nws.node.node_id


def format_rerank_doc(node, body: str) -> str:
    """Reranker document representation. RERANK_DOC_FORMAT=f4 prepends
    Title/Section/Type — measured win (E7): r3 rank 27→10, zero regressions."""
    if os.environ.get("RERANK_DOC_FORMAT", "body") != "f4":
        return body
    md = getattr(node, "metadata", None) or {}
    return (f"Title: {md.get('title') or ''}\n"
            f"Section: {md.get('heading_path') or ''}\n"
            f"Type: {md.get('content_type') or ''}\n\n{body}")


# Parsed ONCE at import with a safe fallback (review M2): parsing inside the
# hosted-rerank try block meant a malformed value raised per-query, was eaten
# by the broad except, and silently disabled the reranker on every request.
try:
    _RERANK_DEDUP_MAX = int(os.environ.get("RERANK_DOC_DEDUP_MAX", "2"))
except ValueError:
    print("[Rerank] invalid RERANK_DOC_DEDUP_MAX; using 2")
    _RERANK_DEDUP_MAX = 2


def dedup_doc_order(order, nodes, max_per_doc: int):
    """Document-level dedup over a reranked (idx, score) order: keep at most
    max_per_doc chunks per doc_id. Near-duplicate docs each still get a seat;
    one doc cannot flood the answer window (postmortem H9/E10)."""
    seen, kept = {}, []
    for idx, score in order:
        md = getattr(nodes[idx].node, "metadata", None) or {}
        d = md.get("doc_id") or md.get("id") or f"__idx{idx}"
        c = seen.get(d, 0)
        if c >= max_per_doc:
            continue
        seen[d] = c + 1
        kept.append((idx, score))
    return kept


def rerank_nodes(
    query: str,
    nodes: List[Any],
    top_k: int = 5,
) -> List[Any]:
    """
    Rerank retrieved nodes for precision via the HOSTED Qwen3-Reranker (vLLM on
    the DGX, configured by RERANK_URL / rerank.json) whose relevance scores are
    well-calibrated (~0.8 relevant / ~0.05 irrelevant). If the reranker is not
    configured or is unreachable, the original retrieval order is kept. Cached by
    (query, chunk_ids).
    """
    if len(nodes) == 0:
        return nodes[:top_k]

    # Chunk texts (shared by hosted + local + cache key)
    chunk_texts = []
    for node in nodes:
        text = node.node.text if hasattr(node.node, "text") else str(node.node)
        chunk_texts.append(format_rerank_doc(node.node, text[:512]))

    query_hash = _hashlib.md5(query.lower().strip().encode()).hexdigest()
    chunk_ids_hash = _hashlib.md5("||".join(sorted(t[:450] for t in chunk_texts)).encode()).hexdigest()
    cache_key = (query_hash, chunk_ids_hash)
    if cache_key in _rerank_cache:
        cached_nodes, timestamp = _rerank_cache[cache_key]
        if _time.time() - timestamp < RERANK_CACHE_TTL:
            return cached_nodes[:top_k]
        del _rerank_cache[cache_key]

    reranked = None

    # Hosted Qwen3-Reranker — relevance_score is already a calibrated 0-1.
    url, model, key = _rerank_cfg()
    if url and _rerank_breaker_open():
        # Breaker is open after repeated reranker failures — skip the network call
        # entirely and fall back to the pre-rerank candidate order (enhancement only).
        print("[Rerank] breaker open; keeping pre-rerank retrieval order")
    elif url:
        try:
            results = _hosted_rerank(url, model, key, query, chunk_texts)
            if results:
                order = [(i, sc) for i, sc in results if 0 <= i < len(nodes)]
                if os.environ.get("RERANK_DOC_DEDUP", "0") == "1":
                    order = dedup_doc_order(order, nodes, _RERANK_DEDUP_MAX)
                reranked = []
                for idx, score in order[:top_k]:
                    nodes[idx].score = score
                    reranked.append(nodes[idx])
                print(f"[Rerank] hosted {model}: top score "
                      f"{results[0][1]:.3f} for: {query[:36]}...")
        except Exception as e:
            print(f"[Rerank] hosted reranker failed ({e}); keeping retrieval order")
            reranked = None

    # No hosted reranker configured/reachable -> keep the original retrieval order.
    if reranked is None:
        return nodes[:top_k]

    _rerank_cache[cache_key] = (reranked, _time.time())
    if len(_rerank_cache) > RERANK_CACHE_MAX:
        oldest_key = min(_rerank_cache.keys(), key=lambda k: _rerank_cache[k][1])
        del _rerank_cache[oldest_key]
    return reranked


def expand_query_hyde(question: str, llm) -> str:
    """
    HyDE: Hypothetical Document Embeddings
    Generate a hypothetical answer to improve retrieval.
    
    The idea: embedding a hypothetical answer often retrieves better 
    results than embedding the question alone.
    """
    try:
        prompt = f"""Write a brief, factual paragraph that would answer this question. 
Be specific and include relevant details. Keep it under 100 words.

Question: {question}

Answer paragraph:"""
        
        response = llm.complete(prompt)
        hypothetical = str(response).strip()
        
        # Combine original query with hypothetical for robust retrieval
        combined = f"{question}\n\n{hypothetical}"
        return combined
    except Exception as e:
        print(f"HyDE expansion failed: {e}")
        return question


_meta_map = None
_text_ids = None   # {text_md5: [milvus_id, ...]} — ALL ids sharing a chunk text (dup stubs)
_title_index = None  # {normalized-title: [meta rows]} for exact-title candidate injection


_ENUM_Q = re.compile(r"^(what|which|list|name|give)\b", re.I)
_ENUM_NOUN = re.compile(r"\b(components?|elements?|types?|kinds?|stages?|parts?|modules?|features?)\b", re.I)


_ENUM_LEAD = re.compile(
    r"^\s*(components?|elements?|types?|kinds?|stages?|parts?|modules?|features?)\s+of\b", re.I)


def _is_enum_query(q):
    """Enumeration intent ('what are the components of X') — the answer's quality is
    COMPLETENESS, which one or two packed chunks of the authoritative doc rarely give.
    The planner REWRITES questions into noun-lead form ('components of data pipeline in
    DATANEXT'), which drops the leading interrogative — match that shape too, else the
    enum path silently misses every rewritten query (caught on the stage golden)."""
    q = (q or "").strip()
    return bool((_ENUM_Q.search(q) and _ENUM_NOUN.search(q)) or _ENUM_LEAD.match(q))


def _is_howto_query(q: str) -> bool:
    """Procedure intent — the one class (besides enumeration) whose answer quality
    IS completeness of steps. Mirrors the HOWTO_STEPS_FIRST prompt-directive regex.
    Quiz/question-generation asks are excluded: 'create 10 quiz questions' must stay
    a concise grounded generation, not a full-document dump."""
    import re
    ql = (q or "").lower()
    if re.search(r"\bquiz\b|\bquestions?\b", ql):
        return False
    return bool(
        re.search(r"\bhow\s+(?:to|do\s+i|can\s+i|do\s+you)\b", ql)
        or re.search(r"\b(?:steps?\s+to|configure|configuring|set\s*up|setting\s*up|enable|install)\b", ql)
        or re.search(r"\bkaise\b", ql)
    )


def _ordinal_rows(rows, n):
    """A doc's rows in ORDINAL (::NNNN) order, capped at n. How-to steps are
    sequential — unlike _lead_rows there is no content-richness filter, because a
    short 'Select Save.' chunk is exactly the kind of step the audits found missing."""
    def _ord(r):
        try:
            return int(str(r.get("id") or "").rsplit("::", 1)[1])
        except Exception:
            return 9999
    return sorted(rows or [], key=_ord)[:n]


def _lead_rows(rows, n):
    """Deterministic pick of a doc's most content-rich LEAD chunks. Milvus returns
    meta rows in NO guaranteed order (varies per process), so an unsorted [:n] slice
    injected different chunks after every restart — the same golden case flip-flopped
    pass/fail between app instances (release-r3, 2026-07-20). Sort by ordinal (chunk 0
    = intro/definition) and prefer body chunks over <200-char stubs."""
    def _ord(r):
        try:
            return int(str(r.get("id") or "").rsplit("::", 1)[1])
        except Exception:
            return 9999
    rows = sorted(rows or [], key=_ord)
    rich = [r for r in rows if len((r.get("text") or "").strip()) >= 200]
    return (rich or rows)[:n]
_doc_img_map = None


def _get_text_ids():
    """{text_md5: [milvus_id,...]} built alongside the meta map. Unlike _meta_map (which
    keeps only the LAST row per text), this keeps EVERY id sharing a text — needed to stitch
    a duplicated boilerplate stub, whose text collides across docs, to the RIGHT doc's
    continuation (we try all candidate docs and keep only the query-relevant sibling)."""
    _get_meta_map()
    return _text_ids or {}


def _get_meta_map():
    """Build {text_md5: {title,uri,...}} once from all rows. Needed because the
    ingestion schema has no llama-index _node_content blob, so MilvusVectorStore
    returns nodes with FRESH UUIDs (not the Milvus id) — a join-by-id is impossible,
    so we join by chunk text. Cached (rebuilt on restart / re-ingest)."""
    global _meta_map, _text_ids
    if _meta_map is not None:
        return _meta_map
    _meta_map = {}
    _text_ids = {}
    try:
        from data.milvus_store import get_milvus_client
        client = get_milvus_client()
        # access_teams + visibility carry the per-chunk ACL (see _chunk_authorized). They
        # must be in the meta map so _attach_metadata can surface them for ACL filtering.
        # `id` is the Milvus primary key ("<doc_base>::<zero-padded-index>"); it is carried
        # so retrieve() can recover a node's TRUE chunk id (dense nodes get fresh UUIDs for
        # node_id) and stitch its sequential same-doc siblings (::idx+1, ::idx+2).
        fields = ["id", "text", "title", "uri", "source_url", "doc_id", "access_teams", "visibility"]

        def _ingest(rows):
            for r in rows:
                t = r.get("text") or ""
                if t:
                    h = _hashlib.md5(t.encode()).hexdigest()
                    _meta_map[h] = r
                    rid = r.get("id")
                    if rid:
                        _text_ids.setdefault(h, []).append(rid)

        # The corpus can exceed Milvus's 16384 single-query window (e.g. 32k+
        # rows after a full re-ingest), so iterate over ALL rows — else only the
        # first 16384 get titles and the rest show "Source N" in the UI.
        try:
            it = client.query_iterator(
                collection_name=settings.MILVUS_COLLECTION, filter='id != ""',
                output_fields=fields, batch_size=16000)
            while True:
                batch = it.next()
                if not batch:
                    it.close()
                    break
                _ingest(batch)
        except Exception as ie:
            print(f"[Meta] query_iterator unavailable ({ie}); falling back to capped query")
            _ingest(client.query(collection_name=settings.MILVUS_COLLECTION,
                                 filter='id != ""', output_fields=fields, limit=16384))
        print(f"[Meta] metadata map built: {len(_meta_map)} rows")
    except Exception as e:
        print(f"[Meta] map build failed: {e}")
    return _meta_map


def _get_title_index():
    """{normalized-title: [meta rows]} built once from the meta map. Lets an exact-title
    query fetch the right doc even when its generic content buries it below dense/BM25
    competitors (the 'Web APIs' / 'Configuration' generic-title miss). Cached; rebuilt with
    the meta map on restart / re-ingest."""
    global _title_index
    if _title_index is not None:
        return _title_index
    idx = {}
    try:
        for row in (_get_meta_map() or {}).values():
            t = (row.get("title") or "").strip().lower()
            if t:
                idx.setdefault(t, []).append(row)
    except Exception as e:
        print(f"[TitleIndex] build failed: {e}")
    _title_index = idx
    return idx


# A knowledge space is a set of D360 root folders. The chunk header starts with
# the full breadcrumb ("[Product Support › Escalations › ...]"), so membership is a
# cheap prefix test. Anything that matches no space (videos, API docs, team
# uploads) belongs to the default "kb" space.
KB_SPACES = {
    "kb": {"label": "Knowledge Bot", "roots": [], "default": True,
           "hint": "Product docs, training, marketing, AcademyNext & videos"},
    "product_support": {"label": "Product Support", "roots": ["Product Support"],
                        "hint": "Support tickets, escalations & known issues",
                        "suggestions": [
                            "How do I fix LDAP authentication failures?",
                            "What solutions exist for email syndication errors?",
                            "How do I troubleshoot a failed synchronisation job?",
                            "Where are the CRMNEXT case solutions?",
                            "What are the known login issues and fixes?",
                            "How do I raise and track an escalation?",
                        ]},
    "us_delivery": {"label": "US Delivery", "roots": ["US Delivery Team"],
                    "hint": "US Knowledge Base & box configuration",
                    "suggestions": [
                        "What is US Box Configuration?",
                        "How does Member Onboarding work?",
                        "How is Complaints Management configured?",
                        "What does the US dashboard show?",
                        "How is Sales and Marketing set up in the US box?",
                        "What service workflows are configured for US?",
                    ]},
}
_NON_DEFAULT_ROOTS = [r for k, v in KB_SPACES.items() if not v.get("default") for r in v["roots"]]


def _chunk_roots(node) -> str:
    """First breadcrumb component of a chunk, from its '[Root > ...]' header."""
    try:
        t = (node.node.text or "").lstrip()
        if not t.startswith("["):
            return ""
        head = t[1:t.index("]")] if "]" in t[:400] else ""
        return head.split("\u203a")[0].split(">")[0].strip()
    except Exception:
        return ""


def _in_space(node, space: str) -> bool:
    """True if this chunk belongs to the requested space."""
    cfg = KB_SPACES.get(space)
    if not cfg:
        return True
    root = _chunk_roots(node)
    if cfg.get("default"):
        # default space = everything that is NOT claimed by another space
        return root not in _NON_DEFAULT_ROOTS
    return root in cfg["roots"]


def _inj_meta(row) -> dict:
    """Metadata for an injected ledger-row chunk — mirrors organic nodes so the
    source chip resolves a real title/link instead of 'Unknown' (prod screenshot
    2026-08-21: injected score-0 chunk surfaced as an Unknown/Low-relevance chip)."""
    return {k: row.get(k) for k in ("title", "doc_id", "uri", "source_url") if row.get(k)}


def _query_subject(q: str) -> str:
    """Strip the boilerplate framing from a question to recover the bare subject, so it can
    be matched against a doc title. 'What is Web APIs in BusinessNext and what is it used
    for?' -> 'web apis'."""
    s = (q or "").lower().strip()
    # multi-clause questions ("what are the X? share the list") — the subject lives in
    # the first clause; the trailing imperative is framing, not subject
    if "?" in s:
        _head = s.split("?", 1)[0].strip()
        if _head:
            s = _head
    s = s.rstrip("?.! ")
    for p in ("how to configure ", "how do i configure ", "how do i ", "how to ", "how does ",
              "how do ", "how can i ", "what is ", "what are ", "explain ", "describe ",
              "tell me about ", "configure ", "share the ", "share ", "give me the ",
              "give me ", "show me the ", "show me ", "list the ", "list ",
              "mujhe ", "batao "):
        if s.startswith(p):
            s = s[len(p):]
            break
    for suf in (" in businessnext and what is it used for", " in businessnext and how is it used",
                " and what is it used for", " and how is it used", " and how does it work",
                " in businessnext", " in business next", " used for", " used", " work",
                # Hinglish framings ("autodoc kya hota hai" must resolve to "autodoc" —
                # prod-audit 2026-08-21: English phrasing answered, Hinglish refused)
                " kya hota hai", " kya hoti hai", " kya hote hai", " kya hai", " kya h",
                " kaise kare", " kaise karen", " kaise banaye", " kaise banaen",
                " ke bare mein batao", " ke bare me batao", " ke baare mein batao",
                " ke bare mein", " ke bare me", " ke baare mein"):
        if s.endswith(suf):
            s = s[:-len(suf)]
            break
    s = s.strip(" ?.")
    for art in ("the ", "an ", "a "):
        if s.startswith(art):
            s = s[len(art):]
            break
    # trailing politeness/filler never belongs to a title
    _changed = True
    while _changed:
        _changed = False
        for suf in (" please", " with me", " to me", " for me", " kindly"):
            if s.endswith(suf):
                s = s[:-len(suf)].rstrip(" ?.")
                _changed = True
    return s


def _get_doc_img_map():
    """Build {doc_id: [rows-carrying-images]} once from the meta map. Lets retrieval
    attach a document's figures whenever that document is answered from: image chunks'
    text is mostly a VLM caption (UI labels) that rarely dense-matches a natural query,
    so without this the diagram is left behind even on a correct retrieval. Cached;
    rebuilt on restart / re-ingest alongside the meta map."""
    global _doc_img_map
    if _doc_img_map is not None:
        return _doc_img_map
    _doc_img_map = {}
    try:
        for r in _get_meta_map().values():
            t = r.get("text") or ""
            if "![" in t and "/img/" in t:
                did = r.get("doc_id")
                if did:
                    _doc_img_map.setdefault(did, []).append(r)
        print(f"[Figures] doc-image map: {len(_doc_img_map)} docs carry figures")
    except Exception as e:
        print(f"[Figures] map build failed: {e}")
    return _doc_img_map


def clear_retrieval_caches():
    """Invalidate every retrieval-side cache. Call after (re)indexing or an index
    reload so a corpus change can't be served stale results. Best-effort: each step
    is guarded so a failure to clear one cache never raises (and never blocks reload).
    Cleared: in-memory rerank cache, metadata map, doc→figure map, persistent
    query_cache SQLite table."""
    global _meta_map, _text_ids, _doc_img_map, _profile_fp_cache
    # 1) in-memory rerank cache
    try:
        _rerank_cache.clear()
    except Exception as e:
        print(f"[Cache] rerank-cache clear failed: {e}")
    # 2) metadata + figure maps (rebuilt lazily on next retrieval)
    _meta_map = None
    _text_ids = None
    _doc_img_map = None
    # 2b) retrieval profile fingerprint (recomputed lazily; reranker identity may change)
    _profile_fp_cache = None
    # 3) persistent query cache (SQLite) — table created at import, but guard anyway
    try:
        conn = sqlite3.connect(_CACHE_DB_PATH)
        conn.execute("DELETE FROM query_cache")
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[Cache] query_cache table clear failed: {e}")
    print("[Cache] retrieval caches cleared (rerank, meta, figures, query_cache)")


def _chunk_authorized(meta: dict, allowed: set) -> bool:
    """ACL gate for a single chunk's surfaced metadata.

    Public content is always authorized: visibility=='public' OR 'all' in access_teams.
    Otherwise the chunk's access_teams (TEAM tokens, lowercased) must intersect the
    caller's `allowed` authorization-token set. CONSERVATIVE: a chunk that carries NO
    access_teams metadata at all is treated as NOT authorized (fail closed) — better to
    drop an unlabeled chunk than to leak it. (Note: the current production corpus is
    100% public, so this passes everything today; it is forward-compatible for when
    team-restricted content is ingested.)"""
    if meta is None:
        return False
    # Governance gate (CUG: hidden/old-build articles leaked into search): a chunk
    # explicitly flagged hidden is never served. Chunks WITHOUT the flag (the
    # pre-governance corpus) stay visible — safe before the metadata re-ingest.
    if meta.get("hidden") is True or str(meta.get("hidden", "")).strip().lower() == "true":
        return False
    vis = meta.get("visibility")
    if isinstance(vis, str) and vis.strip().lower() == "public":
        return True
    teams = meta.get("access_teams")
    if isinstance(teams, str):
        teams = [teams]
    if not teams:
        # No ACL metadata surfaced → fail closed (unless public via visibility above).
        return False
    team_set = {str(t).strip().lower() for t in teams if str(t).strip()}
    if "all" in team_set:
        return True
    return bool(team_set & {str(a).strip().lower() for a in (allowed or set())})


def _milvus_string_literal(value: str) -> str:
    """Quote a value for a Milvus string expression."""
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _acl_token_variants(token: str) -> List[str]:
    """Common case variants for ACL tokens; the Python post-filter remains final."""
    raw = str(token).strip()
    if not raw:
        return []
    return sorted({raw, raw.lower(), raw.upper(), raw.title()})


def _acl_milvus_filter_expr(acl: Optional[dict]) -> Optional[str]:
    """Milvus pushdown for the same ACL policy enforced by _chunk_authorized().

    Pushdown is a recall/perf optimization for scoped users. The post-filter still
    runs after metadata attach so an adapter/schema that ignores this expression
    cannot leak unauthorized chunks.
    """
    # Governance pushdown (flip HIDDEN_FILTER_EXPR=1 ONLY after the corpus is
    # re-ingested with the F-1 metadata fields: an expr over a dynamic field
    # silently EXCLUDES rows that lack the field, which today is the whole
    # corpus). Until then the always-on Python gate in _chunk_authorized covers
    # hidden chunks (missing flag == visible).
    hidden_expr = "hidden != true" if os.environ.get("HIDDEN_FILTER_EXPR", "0") == "1" else None

    if acl is None:
        return hidden_expr

    terms = ['visibility == "public"']
    for tok in _acl_token_variants("all"):
        terms.append(f"ARRAY_CONTAINS(access_teams, {_milvus_string_literal(tok)})")

    allowed = acl.get("allowed") or set()
    seen = set()
    for token in sorted(str(a) for a in allowed if str(a).strip()):
        for variant in _acl_token_variants(token):
            if variant in seen:
                continue
            seen.add(variant)
            terms.append(f"ARRAY_CONTAINS(access_teams, {_milvus_string_literal(variant)})")

    acl_expr = "(" + " or ".join(terms) + ")"
    return (acl_expr + " and " + hidden_expr) if hidden_expr else acl_expr


def _attach_metadata(nodes):
    """Attach title/uri to node.metadata (join by text hash; see _get_meta_map) and
    map title->file_name, uri->url so the UI source chips show real titles + links.
    Also surfaces access_teams + visibility (the per-chunk ACL) so _chunk_authorized
    can gate the node after metadata is attached."""
    m = _get_meta_map()
    if not m:
        return
    for n in nodes:
        r = m.get(_hashlib.md5((n.node.text or "").encode()).hexdigest())
        if not r:
            continue
        title = r.get("title")
        # `uri` is a local file:// path (browser can't open it) and `source_url` points
        # at the decommissioned :9000 MinIO — neither is a usable link, so drop them.
        # The chat stream surfaces the real public Document360 URL (parsed from the text).
        _u = r.get("uri") or r.get("source_url")
        url = _u if (_u and not str(_u).startswith("file://") and ":9000/" not in str(_u)) else None
        md = dict(getattr(n.node, "metadata", None) or {})
        md.update({k: v for k, v in {
            "file_name": title, "title": title, "url": url,
        }.items() if v})
        # ACL fields are set unconditionally (even when empty/None) so the authorization
        # check reflects the chunk's TRUE ACL state — an absent access_teams must read as
        # "no teams" (fail closed), not be silently dropped by a falsy filter.
        # coerce to a plain list: Milvus ARRAY fields come back as a protobuf
        # RepeatedScalarContainer which is UNPICKLEABLE — leaving it here makes the whole
        # node.metadata unpickleable, so the query-cache's pickle silently STRIPS metadata
        # (title/uri/url) off the live nodes → sources lose their titles + D360 links.
        md["access_teams"] = list(r.get("access_teams") or [])
        md["visibility"] = r.get("visibility")
        # Preserve the RAW uri + source_url (set unconditionally, even when file:///
        # :9000 — i.e. unopenable). The naive `url` above is None for d360 file://
        # chunks; the server-side source-link resolver needs the raw uri to derive the
        # doc's real public Document360 URL (marker → doc-url map → template by stem).
        md["uri"] = r.get("uri")
        md["source_url"] = r.get("source_url")
        n.node.metadata = md


# ── Candidate-pool hygiene + neighbour stitching (corpus micro-chunking band-aid) ──
# The corpus is micro-chunked: ~33% of chunks are <120 chars (a heading / intro line /
# pure frontmatter with NO answer body). A doc's intro "Perform the following steps to
# create a new Lead:" is its OWN chunk; the actual steps are the NEXT chunk. The reranker
# scores that empty stub ~0.93 (perfect lexical match) so stubs dominate top_k and the real
# steps chunk (dense rank ~20) never reaches the LLM. These helpers (a) drop exact-duplicate
# stub texts + pure-frontmatter chunks from the candidate pool, and (b) after the final node
# set is chosen, stitch each node's sequential SAME-DOC siblings (::idx+1, ::idx+2) back in so
# the answer body travels with the intro. Chunk id format: "<doc_base>::<zero-padded-index>".
_FRONTMATTER_RE = re.compile(r"^\s*#[^\n]*\n(?:\s*_[A-Za-z0-9]+:\s?[^\n]*\n?)+\s*$")
_CHUNK_ID_RE = re.compile(r"^(?P<base>.+)::(?P<idx>\d+)$")


def _is_frontmatter_only(text: str) -> bool:
    """True for a pure-frontmatter chunk: a leading `# ...` title line followed by only
    `_key: value` metadata lines (e.g. `_URL: ...`, `_status: ...`) and no answer body.
    Such chunks carry a title's lexical tokens (so the reranker over-scores them) but zero
    content, so they must never occupy a top_k slot."""
    if not text:
        return True
    return bool(_FRONTMATTER_RE.match(text))


def _dedupe_and_drop_frontmatter(nodes):
    """Prune the candidate pool BEFORE reranking: drop exact-duplicate chunk texts (the same
    boilerplate intro appears verbatim across many docs) and pure-frontmatter chunks. Order-
    preserving; keeps the FIRST occurrence of each distinct text. Never empties the pool — if
    every candidate is a frontmatter/dup, the original list is returned unchanged (better a
    weak answer than a forced refusal)."""
    kept = []
    seen_text = set()
    for n in nodes:
        txt = (getattr(n.node, "text", None) or "")
        key = txt.strip()
        if key in seen_text:
            continue
        if _is_frontmatter_only(txt):
            continue
        seen_text.add(key)
        kept.append(n)
    return kept or nodes


_STITCH_STUB_MAXLEN = int(os.environ.get("STITCH_STUB_MAXLEN", "200"))


def _is_stub_anchor(text: str) -> bool:
    """Only chunks worth stitching a continuation onto: a SHORT heading / intro line whose
    answer body lives in the NEXT chunk (e.g. "Perform the following steps to create a new
    Lead:"). A content-rich anchor already carries its own answer, so we must NEVER stitch it —
    appending its ::idx+1 sibling would pull the NEXT (often unrelated) section into a good
    answer and let the generator blend it (the exact fabrication mode of the reverted RCA).
    Gate: short real-prose length OR an intro line ending in ':'."""
    if not text:
        return False
    t = text.strip()
    # Judge by real prose length with markdown images/links stripped, so an image-only or
    # link-heavy chunk is measured by its words, not its URL noise.
    prose = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)
    prose = re.sub(r"https?://\S+", "", prose).strip()
    if len(prose) <= _STITCH_STUB_MAXLEN:
        return True
    if t.rstrip().endswith(":"):
        return True
    return False


_STITCH_STOP = {
    "the", "a", "an", "of", "for", "to", "in", "on", "and", "or", "is", "are", "how",
    "do", "does", "did", "i", "we", "you", "your", "my", "me", "what", "when", "where",
    "which", "can", "with", "this", "that", "from", "by", "as", "at", "be", "will",
    "create", "creating", "created", "make", "making", "add", "adding", "new", "setup",
    "set", "configure", "configuring", "config", "use", "using", "steps", "step", "get",
    "want", "need", "please", "tell", "show", "explain", "about", "into", "via",
}


def _stitch_terms(s: str) -> set:
    """Salient (subject) terms of a string, minus generic stopwords/verbs. Used for the
    stitch relevance guard so a duplicated stub that resolves to the WRONG doc can't inject
    that doc's off-topic continuation."""
    return {w for w in re.findall(r"[a-z0-9]+", (s or "").lower())
            if len(w) > 2 and w not in _STITCH_STOP}


def _stitch_siblings(index, nodes, query: str = "", max_per_node: int = 2, context_cap: int = 12):
    """Reconstruct answer bodies fragmented by micro-chunking.

    Dense nodes come back with EMPTY metadata and a fresh-UUID node_id, so a node's true
    Milvus id ("<doc_base>::<idx>") can only be recovered from its TEXT. The catch: the same
    boilerplate intro ("Perform the following steps to create a new Lead:") is copied verbatim
    across DIFFERENT docs, so text→id is one-to-MANY. We therefore (1) gate to short intro/
    heading STUBS only, (2) look up ALL candidate ids sharing the stub's text (_get_text_ids),
    (3) fetch each candidate's next `max_per_node` same-doc siblings (::idx+1, ::idx+2) from
    Milvus via client.query — which returns full rows (id/doc_id/text/ACL), unlike
    vector_store.get_nodes which strips metadata — and (4) append a sibling ONLY if it shares
    a salient term with the QUERY. That relevance guard is what makes the many-candidates fetch
    safe: the wrong doc's continuation won't mention the query subject, so it is dropped (worst
    case = no stitch = no regression; it can never inject off-topic text, the reverted RCA's
    fabrication mode). Capped by `context_cap`; any failure leaves `nodes` untouched."""
    try:
        from llama_index.core.schema import NodeWithScore, TextNode
    except Exception:
        return nodes
    if not nodes:
        return nodes
    text_ids = _get_text_ids()
    if not text_ids:
        return nodes
    qterms = _stitch_terms(query)
    if not qterms:
        return nodes  # no subject to anchor relevance on → don't risk off-topic stitching

    def _cands(n):
        h = _hashlib.md5((getattr(n.node, "text", None) or "").encode()).hexdigest()
        return text_ids.get(h, [])

    # Ids/texts already present (dedupe target): every candidate id of every current node.
    present_ids = set()
    present_texts = set()
    for n in nodes:
        for cid in _cands(n):
            present_ids.add(cid)
        present_texts.add((getattr(n.node, "text", None) or "").strip())

    # Plan sibling fetches for STUB anchors across ALL their candidate docs.
    want = []            # sibling ids to fetch, in order
    want_base = {}       # sibling id -> parent doc base (== doc_id)
    seen_want = set()
    for n in nodes:
        # STUB-ONLY GATE: only reconstruct a continuation for short intro/heading stubs.
        # A content-rich anchor already carries its answer; stitching it would risk pulling
        # an unrelated next section (the reverted RCA's fabrication mode).
        if not _is_stub_anchor(getattr(n.node, "text", None) or ""):
            continue
        for cid in _cands(n):
            mobj = _CHUNK_ID_RE.match(cid)
            if not mobj:
                continue
            base = mobj.group("base")
            idx = int(mobj.group("idx"))
            width = len(mobj.group("idx"))  # preserve zero-padding (0015 -> 0016)
            for step in range(1, max_per_node + 1):
                sib_id = f"{base}::{str(idx + step).zfill(width)}"
                if sib_id in present_ids or sib_id in seen_want:
                    continue
                seen_want.add(sib_id)
                want.append(sib_id)
                want_base[sib_id] = base

    if not want:
        return nodes

    # Fetch siblings straight from Milvus WITH metadata (get_nodes returns bare text nodes
    # with empty metadata, which would break the same-doc + ACL guards below).
    try:
        from data.milvus_store import get_milvus_client
        client = get_milvus_client()
        expr = "id in [" + ",".join('"' + w.replace('"', '') + '"' for w in want) + "]"
        rows = client.query(
            collection_name=settings.MILVUS_COLLECTION, filter=expr,
            output_fields=["id", "doc_id", "text", "title", "uri", "source_url",
                           "access_teams", "visibility"])
    except Exception as e:
        print(f"[Stitch] sibling fetch failed: {e}")
        return nodes

    rows_by_id = {r.get("id"): r for r in (rows or [])}

    appended = 0
    for sib_id in want:               # planned order: doc-major, ::idx ascending
        if len(nodes) >= context_cap:
            break
        r = rows_by_id.get(sib_id)
        if not r:
            continue
        # Same-doc guard: the sibling must belong to the SAME doc as its anchor.
        if r.get("doc_id") and r["doc_id"] != want_base.get(sib_id):
            continue
        sib_text = (r.get("text") or "").strip()
        if not sib_text or sib_text in present_texts or _is_frontmatter_only(sib_text):
            continue
        # RELEVANCE GUARD — the crux of safety with one-to-many text→id: keep the sibling only
        # if it mentions the query subject (substring, so 'lead' matches 'Leads'). A wrong-doc
        # sibling (e.g. a Solutions doc that happens to share the intro line) won't mention it
        # and is dropped, so stitching can never inject off-topic content.
        low = sib_text.lower()
        if not any(qt in low for qt in qterms):
            continue
        # Carry id + doc_id + ACL so _attach_metadata / _chunk_authorized treat the sibling
        # exactly like any other node (no ACL bypass).
        md = {"id": r.get("id"), "doc_id": r.get("doc_id"), "title": r.get("title"),
              "uri": r.get("uri"), "source_url": r.get("source_url"),
              # plain list — Milvus ARRAY returns an unpickleable RepeatedScalarContainer
              # which would make node.metadata unpickleable and get stripped by the cache.
              "access_teams": list(r.get("access_teams") or []), "visibility": r.get("visibility")}
        tn = TextNode(text=sib_text, id_=sib_id, metadata=md)
        nodes.append(NodeWithScore(node=tn, score=0.0))
        present_ids.add(sib_id)
        present_texts.add(sib_text)
        appended += 1
    if appended:
        print(f"[Stitch] appended {appended} same-doc sibling chunk(s) to context")
    return nodes


_CMP_RE = [
    re.compile(r"difference between (.+?) and (.+?)\s*[\?\.!]*$", re.I),
    re.compile(r"\bcompare (.+?) (?:and|with|to) (.+?)\s*[\?\.!]*$", re.I),
    re.compile(r"^\s*(.+?)\s+(?:vs\.?|versus)\s+(.+?)\s*[\?\.!]*$", re.I),
    re.compile(r"(.+?) aur (.+?) (?:me|mein|m) .*?(?:difference|farak|antar|fark)", re.I),
]
_CMP_ART = ("a ", "an ", "the ")


def _comparison_entities(q):
    """For 'difference between A and B' / 'A vs B' (and Hindi 'A aur B me difference'),
    return (A, B) so retrieval can pull BOTH entities' chunks — otherwise retrieval favours
    one side and the answer only describes that one entity."""
    ql = (q or "").strip()
    if not ql:
        return None
    for rx in _CMP_RE:
        m = rx.search(ql)
        if m:
            a, b = m.group(1).strip(" .?!"), m.group(2).strip(" .?!")
            for art in _CMP_ART:
                if a.lower().startswith(art):
                    a = a[len(art):]
                if b.lower().startswith(art):
                    b = b[len(art):]
            a, b = a.strip(), b.strip()
            if a and b and 1 < len(a) < 60 and 1 < len(b) < 60:
                return (a, b)
    return None


# Enumeration lead-ins for _list_entities — a comma/and list only counts as a multi-entity
# ask when the sentence frames it as one ("descriptions of A, B and C", "briefly explain
# A, B and C") or puts the list after a colon. Plain "and" inside an instruction
# ("create a lead and assign it to a user") must NOT split.
_LIST_LEADIN = re.compile(
    r"(?:descriptions?\s+of|overviews?\s+of|explain|describe|about|between"
    r"|what\s+(?:do|are|is))\s+(.+)$", re.I)
_LIST_SPLIT = re.compile(r",|\band\b|\baur\b", re.I)


def _list_entities(q):
    """For an N-way enumeration ("one-line descriptions of A, B and C", "overview of each
    of these features: A, B, C, D and E"), return the 3-6 listed entities so retrieval can
    pull chunks for EACH — a single dense pass splits the pool across the topics and some
    entities get no chunks at all (the answer then skips or refuses them). Two-entity
    comparisons stay with _comparison_entities. Returns None for non-list queries."""
    ql = (q or "").strip()
    if not ql:
        return None
    if ":" in ql:
        tail = ql.split(":", 1)[1]
    else:
        m = _LIST_LEADIN.search(ql)
        if not m:
            return None
        tail = m.group(1)
    parts = []
    for p in _LIST_SPLIT.split(tail):
        p = p.strip(" .?!-")
        if not (1 < len(p) < 60):
            continue
        if len(p.split()) <= 6:
            parts.append(p)
            continue
        # Trailing-instruction bleed on the LAST entity ("Prompt each do? One line per
        # feature") — trim back to the longest corpus-title prefix, if any.
        words = p.split()
        for k in range(min(6, len(words) - 1), 0, -1):
            cand = " ".join(words[:k]).strip(" .?!-")
            if _get_title_index().get(cand.lower()):
                parts.append(cand)
                break
    if len(parts) < 3:
        return None
    return parts[:6]


class AdvancedRetriever:
    """
    Advanced retriever combining:
    - Vector similarity search
    - BM25 keyword search (via hybrid_search module)
    - Cross-encoder reranking
    - HyDE query expansion
    """
    
    def __init__(self, index, llm, use_hyde: bool = False, use_rerank: bool = True):
        """Initialize advanced retriever.
        
        Args:
            index: LlamaIndex index
            llm: Language model
            use_hyde: Enable HyDE (disabled by default for speed)
            use_rerank: Enable Qwen3-Reranker reranking
        """
        self.index = index
        self.llm = llm
        self.use_hyde = use_hyde
        self.use_rerank = use_rerank
        self._hybrid_searcher = None
        self._hybrid_init_attempted = False
        import threading as _threading
        self._hybrid_lock = _threading.Lock()
    
    def _get_hybrid_searcher(self):
        """Lazy load hybrid searcher from BM25 index. Lock: the startup warm-up
        thread and the first query race here — without it both build the
        ~10k-chunk BM25 index (double CPU burn on a cold boot)."""
        with self._hybrid_lock:
            return self._get_hybrid_searcher_locked()

    def _get_hybrid_searcher_locked(self):
        if self._hybrid_searcher is None and not self._hybrid_init_attempted:
            self._hybrid_init_attempted = True
            try:
                from reranker.hybrid_search import create_hybrid_searcher_from_index
                self._hybrid_searcher = create_hybrid_searcher_from_index(self.index)
                if self._hybrid_searcher:
                    print("\u2713 Hybrid BM25 searcher initialized")
            except Exception as e:
                print(f"[Hybrid] Could not create hybrid searcher: {e}")
        return self._hybrid_searcher
    
    def retrieve(
        self,
        question: str,
        top_k: int = 5,
        initial_k: int = 15,
        acl=None,
        enum_hint: bool = False,
        howto_hint: bool = False,
        space: str = "",
    ) -> Tuple[List[Any], float]:
        """
        Retrieve relevant nodes with advanced techniques.

        Pipeline:
          1. Check persistent cache
          2. Expand query with synonyms
          3. Optional HyDE expansion
          4. Vector retrieval (top initial_k)
          5. Hybrid BM25+vector fusion (if available)
          6. Cross-encoder reranking
          7. Compute confidence
          8. Cache result

        ACL:
            acl=None  → unrestricted (no per-chunk filtering; today's 100%-public corpus
                        and admin/service callers).
            acl={"allowed": set[str-lowercased], "folder": str|None} → after metadata is
                        attached, every node failing _chunk_authorized(meta, allowed) is
                        dropped; if filtering removes ALL nodes, confidence is forced to
                        0.0. The candidate pool is WIDENED (initial_k*2) up front so the
                        ACL drop does not silently lose recall. The persistent cache key
                        is scoped by profile fingerprint + an ACL token so results never
                        cross profile / folder / user boundaries.

        Returns:
            (reranked_nodes, confidence_score)
        """
        # The user's own words, before any expansion appends corpus phrasing. Alias/
        # synonym expansion is for dense+BM25 recall only — title/subject matching on
        # the EXPANDED text made the appended alias ("api" -> "Application Programming
        # Interface") outweigh the user's words and crown the same-titled ALM course
        # (Rajendra api-guide RCA 2026-08-20). Brand-normalized like the retrieval query.
        _user_q = question

        # Abbreviation expansion (launch-week finding 2026-07-30): users write task
        # shorthand ("convert lead to opp") that matches nothing — the corpus always
        # spells the full word. Expand a small allowlist of PROVEN abbreviations by
        # appending the full form, so both dense and BM25 see it. The original token
        # stays (harmless), r3/v11-class short codes are untouched (not in the map).
        if os.environ.get("QUERY_ABBREV_EXPAND", "1") == "1":
            _ABBREV = {"opp": "opportunity", "oppty": "opportunity", "opps": "opportunities",
                       "appt": "appointment", "appts": "appointments",
                       "acct": "account", "accts": "accounts", "mgmt": "management"}
            _expanded = re.sub(
                r"\b(" + "|".join(_ABBREV) + r")\b",
                lambda m: m.group(1) + " " + _ABBREV[m.group(1).lower()],
                question, flags=re.IGNORECASE)
            if _expanded != question:
                _logger.info(f"[AbbrevExpand] {question!r} -> {_expanded!r}")
                question = _expanded

        # Phrase-synonym expansion (launch-week findings 2026-08-04): users phrase a
        # task with words the corpus never uses ("log an activity" — docs only say
        # "create"). Append the corpus phrasing for a small PROVEN list so BM25 and
        # dense both see it; the original phrasing stays. Each pair traces to a real
        # missed question in the launch audit.
        if os.environ.get("QUERY_SYN_EXPAND", "1") == "1":
            _SYN_PHRASES = {
                "log an activity": "create activity",
                "log activity": "create activity",
                "assign case": "assignment rules",
                "case assign": "assignment rules",
                "dynamic queue": "manage queues",
                "email thread": "email thread control",
                "customer to case": "field mapping",
                "latest release": "What's New Release release notes",
                "naya feature": "What's New Release release notes",
                "new feature": "What's New Release release notes",
                "new ai feature": "What's New Release AGENTNEXT",
            }
            _q_low = question.lower()
            _adds = [full for part, full in _SYN_PHRASES.items()
                     if part in _q_low and full not in _q_low]
            if _adds:
                _logger.info(f"[SynExpand] {question!r} += {_adds!r}")
                question = question + " " + " ".join(_adds)

        # Acronym-alias expansion (A4, corpus-mined 55 aliases): "what is BER" ->
        # append "Business Enforcement Rules". Env-gated QUERY_ALIAS_EXPAND=1.
        if os.environ.get("QUERY_ALIAS_EXPAND", "1") == "1":
            try:
                global _QALIAS
                if "_QALIAS" not in globals():
                    import json as _j
                    _QALIAS = _j.load(open(os.environ.get("QUERY_ALIAS_MAP", "/app/INTELLIGENCE/query_aliases.json")))
                _al=[]
                for _tk in re.findall(r"[A-Za-z]+", question):
                    _f=_QALIAS.get(_tk.lower())
                    if _f and _f.lower() not in question.lower(): _al.append(_f)
                if _al:
                    _al=list(dict.fromkeys(_al))[:2]
                    _logger.info(f"[AliasExpand] {question!r} += {_al!r}")
                    question = question + " " + " ".join(_al)
            except Exception as _e:
                pass

        # --- ACL scoping: widen the funnel + derive a stable cache token ---
        # acl=None → '*' token (unrestricted). Otherwise a stable hash over the sorted
        # allowed-token set + folder, so two callers with the SAME authorization scope
        # share cache but different scopes never collide.
        if acl is not None:
            _allowed = sorted(str(a) for a in (acl.get("allowed") or set()))
            _folder = acl.get("folder") or ""
            acl_token = _hashlib.md5((";".join(_allowed) + "#" + _folder).encode()).hexdigest()[:12]
            # Widen the candidate pool so the post-rerank ACL drop doesn't lose recall.
            initial_k = initial_k * 2
        else:
            acl_token = REDACTED_SECRET
        # --- Step 0: Persistent cache lookup ---
        # Key is scoped by the retrieval profile fingerprint AND the ACL token so a
        # config/profile change or a different folder/user scope can never serve a
        # result computed under different conditions.
        cache_key = _hashlib.md5(
            f"{question}:{top_k}:{self.use_hyde}:{retrieval_profile_fingerprint()}:{acl_token}:{space}".encode()
        ).hexdigest()
        cached = _cache_get(cache_key)
        if cached is not None:
            print(f"[QueryCache] HIT for: {question[:40]}...")
            return cached

        # --- Brand-token normalization (retrieval only; LLM prompt keeps originals) ---
        # Strip the ubiquitous "businessnext" brand token that otherwise dilutes the
        # dense embedding and lets a brand-titled stub outrank the real article. Cache
        # key above is computed from the ORIGINAL question, so this never collides.
        if os.environ.get("BRAND_NORMALIZE", "1") == "1":
            q_norm = normalize_retrieval_query(question)
            if q_norm != question:
                print(f"[BrandNorm] retrieval query: {question!r} -> {q_norm!r}")
                question = q_norm
            _user_q = normalize_retrieval_query(_user_q)

        # A space filter drops most of the pool, so widen the funnel first —
        # otherwise a narrow space (66-article US Delivery Team) can end up with
        # almost nothing after filtering.
        if space:
            initial_k = max(initial_k * 3, 45)

        # --- Step 1: Query preprocessing ---
        query_for_retrieval = expand_query_with_synonyms(question)
        
        # --- Step 2: Optional HyDE expansion ---
        if self.use_hyde:
            query_for_retrieval = expand_query_hyde(query_for_retrieval, self.llm)
        
        # --- Step 3: Initial vector retrieval (wide funnel) ---
        # Pull a generous dense candidate set — the reranker is the final
        # arbiter, so more good candidates in => better top-k out.
        dense_k = max(initial_k, RETRIEVAL_DENSE_K)
        acl_filter_expr = _acl_milvus_filter_expr(acl)
        try:
            if acl_filter_expr:
                retriever = self.index.as_retriever(
                    similarity_top_k=dense_k,
                    vector_store_kwargs={"expr": acl_filter_expr},
                )
            else:
                retriever = self.index.as_retriever(similarity_top_k=dense_k)
            nodes = retriever.retrieve(query_for_retrieval)
        except Exception as e:
            if not acl_filter_expr:
                raise
            _logger.warning("acl_filter_pushdown_failed", extra={"error": str(e)})
            retriever = self.index.as_retriever(similarity_top_k=dense_k)
            nodes = retriever.retrieve(query_for_retrieval)
        # Capture the dense cosine similarity per node BEFORE fusion/rerank overwrite
        # n.score. The dense embedder is well-calibrated for this domain (correct doc
        # is rank-1 ~99% of the time); we use it to FLOOR confidence in step 6 so the
        # reranker cannot crush a well-retrieved doc to a near-zero score and
        # trigger a false refusal (the RCA's CLIFF_REFUSAL class).
        dense_sims = {n.node.node_id: (n.score or 0.0) for n in nodes}
        
        # --- Step 4: True hybrid BM25 + vector fusion (RRF) ---
        # BM25 searches the FULL corpus and can surface keyword-matched chunks the
        # dense retriever missed (product names, codes, exact phrases). Those
        # BM25-only chunks are fetched back as real nodes (with metadata) so they
        # survive into reranking and the source list — real recall, not just a
        # re-ordering of the dense hits.
        hybrid = self._get_hybrid_searcher()
        if hybrid and len(nodes) > 0:
            try:
                from llama_index.core.schema import NodeWithScore

                vector_results = []
                node_map = {}
                for n in nodes:
                    nid = fusion_identity(n)
                    vector_results.append((nid, n.score or 0.0))
                    node_map[nid] = n

                fused, bm25_hits = hybrid.fuse(
                    question, vector_results, top_k=max(initial_k, RETRIEVAL_DENSE_K),
                    vector_weight=0.6, keyword_weight=0.4,
                )

                # Fetch BM25-only chunks (absent from the dense set) as full nodes.
                bm25_only = [doc_id for doc_id, _ in bm25_hits if doc_id not in node_map]
                if bm25_only:
                    try:
                        extra = self.index.vector_store.get_nodes(node_ids=bm25_only)
                        for bn in extra:
                            # Fetched TextNodes can have unset metadata; ensure a dict so
                            # downstream metadata reads/writes never hit AttributeError.
                            if getattr(bn, "metadata", None) is None:
                                bn.metadata = {}
                            _bnws = NodeWithScore(node=bn, score=0.0)
                            # Key by the SAME identity the fused list uses, else the
                            # reassembly lookup below can never find these nodes.
                            node_map[fusion_identity(_bnws)] = _bnws
                    except Exception as e:
                        print(f"[Hybrid] BM25-only node fetch failed: {e}")

                # Build the RRF-ordered candidate pool (dense ∪ BM25).
                reordered = []
                for doc_id, rrf_score in fused:
                    n = node_map.get(doc_id)
                    if n is not None:
                        n.score = rrf_score
                        reordered.append(n)

                if reordered:
                    # Cap the pool handed to the reranker (it re-scores all).
                    nodes = reordered[:max(initial_k * 2, RETRIEVAL_POOL_CAP)]
                    print(f"[Hybrid] RRF fusion: {len(vector_results)} dense + "
                          f"{len(bm25_only)} BM25-only → {len(nodes)} candidates")
            except Exception as e:
                print(f"[Hybrid] Fusion failed, using vector-only: {e}")

        # --- Step 4a1b: KNOWLEDGE SPACE SCOPE (header switcher) ---
        # Keep only candidates whose doc belongs to the chosen space's D360 roots.
        # Applied to the POOL, before rerank, so the reranker only ever sees
        # in-space content.
        #
        # This fails CLOSED: if nothing in the pool belongs to the space we return
        # nothing, rather than falling back to the whole corpus. A user who picked
        # "Product Support" and gets a Product Documentation answer would have no
        # way to tell the scope was ignored — a wrong-scope answer is worse than
        # "not found", which is exactly the complaint that prompted this feature.
        if space:
            _pre = len(nodes)
            nodes = [n for n in nodes if _in_space(n, space)]
            print(f"[Space] '{space}': pool {_pre} -> {len(nodes)}")

        # --- Step 4a2: comparison dual-retrieve ---
        # For "difference between A and B" / "A vs B", ensure BOTH entities' chunks are in the
        # candidate pool — else retrieval favours one side and the answer only describes that
        # one entity (the reranker then can't contrast them). Env-gated; dedupe by text so
        # Step 4b hygiene stays a no-op on these.
        _multi_ents = None
        _ent_best = {}
        if os.environ.get("COMPARE_DUAL", "1") == "1":
            _cmp = _comparison_entities(question)
            # N-way enumeration ("descriptions of A, B and C", "overview of: A, B, C, D, E")
            # — same per-entity retrieve, 3-6 entities (env-gated separately). Without it the
            # pool splits across topics and some listed entities get no chunks at all.
            if not _cmp and os.environ.get("MULTI_ENTITY", "1") == "1":
                _cmp = _list_entities(question)
                if _cmp:
                    _multi_ents = list(_cmp)
            if _cmp:
                try:
                    from llama_index.core.schema import TextNode, NodeWithScore
                    _seen_txt = {(n.node.text or "").strip() for n in nodes}
                    _added = 0
                    _per_k = 6 if len(_cmp) == 2 else 4
                    # _ent_best: entity -> node_id of its strongest candidate (for the
                    # post-rerank guarantee; exact-title chunk wins over dense)
                    def _row_ord(r):
                        # Milvus id is "<doc_base>::<zero-padded-index>" — chunk 0 is the
                        # doc's intro/definition, exactly what a list-summary answer needs.
                        try:
                            return int(str(r.get("id") or "").rsplit("::", 1)[1])
                        except Exception:
                            return 9999
                    for _ent in _cmp:
                        # Exact-title chunk first — for a listed entity that names a corpus
                        # doc ("MDM Features", "Prompt") this is the doc the user means,
                        # and dense-on-entity-name alone can fetch a lookalike instead.
                        # Earliest content-rich chunks win: an unsorted pick surfaced tail
                        # stubs ("To learn more, review these resources") that made the
                        # generation call the entity "not covered".
                        _rows = sorted(_get_title_index().get(_ent.lower().strip()) or [],
                                       key=_row_ord)
                        _rows = ([r for r in _rows if len((r.get("text") or "").strip()) >= 200]
                                 or _rows)
                        for _r in _rows[:2]:
                            _txt = (_r.get("text") or "").strip()
                            if _txt and _txt not in _seen_txt:
                                _tn = NodeWithScore(node=TextNode(text=_txt, metadata=_inj_meta(_r)), score=0.0)
                                nodes.append(_tn); _seen_txt.add(_txt); _added += 1
                                _ent_best.setdefault(_ent, _tn.node.node_id)
                        for _e in self.index.as_retriever(similarity_top_k=_per_k).retrieve(_ent):
                            _t = (_e.node.text or "").strip()
                            if _t and _t not in _seen_txt:
                                nodes.append(_e); _seen_txt.add(_t); _added += 1
                                _ent_best.setdefault(_ent, _e.node.node_id)
                    print(f"[Compare] per-entity retrieve {_cmp} → +{_added} candidates (pool {len(nodes)})")
                except Exception as e:
                    print(f"[Compare] per-entity retrieve failed: {e}")

        # --- Step 4b: Candidate-pool hygiene (corpus micro-chunking band-aid) ---
        # Drop exact-duplicate chunk texts (the same boilerplate intro is copied verbatim
        # across many docs) and pure-frontmatter chunks (a `# title` + `_key: value` lines,
        # no body) BEFORE reranking — otherwise the reranker over-scores those empty stubs
        # (~0.93 lexical match) and they crowd the real answer chunk out of the top_k.
        _before_hygiene = len(nodes)
        nodes = _dedupe_and_drop_frontmatter(nodes)
        if len(nodes) != _before_hygiene:
            print(f"[Hygiene] pool {_before_hygiene} -> {len(nodes)} "
                  f"(dropped dup / frontmatter-only candidates)")

        # --- Step 4c: EXACT-TITLE candidate injection ---
        # A doc with generic CONTENT ("Web APIs", "Configuration") can dense/BM25-rank below
        # its similarly-named neighbours, so the reranker/title-boost never see it. If the
        # query's subject EXACTLY names a corpus doc title, drop that doc's chunk(s) into the
        # pool so they get a fair shot at the top_k. Additive only — the reranker still
        # decides relevance, so this can help but never displaces a better match. Env-gated.
        if os.environ.get("EXACT_TITLE_INJECT", "1") == "1":
            try:
                _subj = _query_subject(_user_q)
                _idx = _get_title_index()
                _rows = _idx.get(_subj) if _subj else None
                if not _rows and _subj:
                    # singular/plural tolerance: "apis" must find the doc titled "API"
                    for _v in (_subj.rstrip("s"), _subj + "s"):
                        if _v != _subj and _v in _idx:
                            _rows = _idx[_v]
                            break
                if not _rows and _subj and len(_subj) >= 4:
                    # unique PREFIX match: "autodoc" -> "autodoc homepage" — a subject
                    # that names a doc-family head still deserves the injection; tried
                    # over the plural variants too ("businessnext apis" -> "businessnext
                    # api references")
                    for _v in (_subj, _subj.rstrip("s"), _subj + "s"):
                        _pk = [k for k in _idx if k.startswith(_v + " ")]
                        if len(_pk) == 1:
                            _rows = _idx[_pk[0]]
                            break
                if _rows:
                    from llama_index.core.schema import TextNode, NodeWithScore
                    _have = {(n.node.text or "")[:120] for n in nodes}
                    _added = 0
                    for _r in _lead_rows(_rows, 3):
                        _txt = _r.get("text") or ""
                        if _txt and _txt[:120] not in _have:
                            nodes.append(NodeWithScore(node=TextNode(text=_txt, metadata=_inj_meta(_r)), score=0.0))
                            _have.add(_txt[:120]); _added += 1
                    if _added:
                        print(f"[ExactTitle] injected {_added} chunk(s) for exact title {_subj!r}")
                elif _subj and len(_subj) <= 24 and " " not in _subj:
                    # TERSE-ALIAS injection: a short single-token subject ("r3", "autodoc")
                    # that is a distinct TOKEN of a few doc titles almost certainly means
                    # those docs ("what is r3" -> "GA Release 2025-26 R3 ..."), but exact-
                    # title match can never fire and dense-on-2-chars retrieves noise
                    # (observed: Resolution Agent / Functional Architecture for "r3").
                    # Rare-token gate: inject ONLY when <=3 distinct docs match, so common
                    # words ("lead") never spray the pool. Additive; reranker still decides.
                    import re as _re3
                    _tok = _subj.lower()
                    _hits = {}
                    for _t, _trows in _get_title_index().items():
                        if _tok in _re3.findall(r"[a-z0-9]+", _t):
                            _hits[_t] = _trows
                        if len(_hits) > 3:
                            break
                    if _hits and len(_hits) <= 3:
                        from llama_index.core.schema import TextNode, NodeWithScore
                        _have = {(n.node.text or "")[:120] for n in nodes}
                        _added = 0
                        for _trows in _hits.values():
                            for _r in _lead_rows(_trows, 2):
                                _txt = _r.get("text") or ""
                                if _txt and _txt[:120] not in _have:
                                    nodes.append(NodeWithScore(node=TextNode(text=_txt, metadata=_inj_meta(_r)), score=0.0))
                                    _have.add(_txt[:120]); _added += 1
                        if _added:
                            print(f"[TerseAlias] injected {_added} chunk(s) for token {_tok!r} in {len(_hits)} title(s)")
            except Exception as e:
                print(f"[ExactTitle] failed: {e}")

        # --- Step 5: Rerank with Qwen3-Reranker ---
        # Set when title-boost surfaces an EXACT multi-term title match (best_score>=2);
        # used at the confidence gate to prevent a false refuse on a well-named doc.
        _title_boost_strong = False
        if self.use_rerank and len(nodes) > 0:
            pool_map = {n.node.node_id: n for n in nodes}
            nodes = rerank_nodes(question, nodes, top_k=top_k)
            # Dense floor on SELECTION: the reranker sometimes
            # buries the strongest dense matches out of the top-k — e.g. a diagram
            # chunk whose text is mostly an image caption (UI labels), which the
            # reranker scores low even though it's the dense rank-1. Force the top few
            # dense candidates back into the context so a well-retrieved doc — and any
            # inline ![](url) image it carries — is never lost to reranking.
            kept = {n.node.node_id for n in nodes}
            for did in sorted(dense_sims, key=dense_sims.get, reverse=True)[:3]:
                if did not in kept and dense_sims.get(did, 0.0) >= 0.65 and did in pool_map:
                    nodes.append(pool_map[did])
                    kept.add(did)

            # Multi-entity guarantee: for an N-way enumeration, every listed entity keeps
            # >=1 chunk in context — the reranker scores each chunk against the FULL list
            # question, so single-entity chunks all score mid and the top_k collapses onto
            # one entity (the answer then says "not covered" for the rest). Coverage check
            # is a PHRASE match (token overlap was satisfied by common words like
            # "features"). Falls back from the tracked per-entity best candidate to any
            # pool chunk carrying the phrase. Inserted right after the reranked winners so
            # the RAG_MAX_CONTEXT_NODES cap never trims them.
            if _multi_ents:
                def _covers(n, ent_l):
                    md_t = str((n.node.metadata or {}).get("title", "")).lower().strip()
                    if md_t == ent_l:
                        return True
                    # Multi-word phrase in the chunk text is real evidence; a single common
                    # word ("prompt", "comments") is not — only its own doc counts then.
                    # And the phrase must lead the chunk (or repeat): a single mention deep
                    # in another doc's text is a passing reference, not a description — it
                    # satisfied this check while the model answered "not covered" for the
                    # entity (multi-3doc: a release-note aside about Channel Provider
                    # blocked the real definition chunk from being re-guaranteed).
                    if " " not in ent_l:
                        return False
                    txt = (n.node.text or "").lower()
                    return ent_l in txt[:500] or txt.count(ent_l) >= 2
                for _ent in _multi_ents:
                    _el = _ent.lower().strip()
                    if len(_el) < 3 or any(_covers(n, _el) for n in nodes):
                        continue
                    _best = pool_map.get(_ent_best.get(_ent))
                    if _best is None or _best.node.node_id in kept:
                        _best = next((p for p in pool_map.values()
                                      if p.node.node_id not in kept and _covers(p, _el)), None)
                    if _best is not None:
                        nodes.insert(min(top_k, len(nodes)), _best)
                        kept.add(_best.node.node_id)
                        print(f"[MultiEntity] re-guaranteed a chunk for {_ent!r}")

            # --- Step 5c: TITLE-MATCH promotion (FIX 1 — thin-doc burial) ---
            # A strong title match is a high-precision intent signal the dense+rerank
            # stack misses for thin (1-2 chunk) docs, which get buried under content-
            # dense siblings (the dominant RCA cause: ~49% of eval failures). If a
            # candidate doc's title is largely covered by the query, promote it to the
            # front so the answer grounds in the right doc. High precision: needs >=2
            # distinct content terms AND the title almost wholly contained in the query.
            try:
                import re as _re2
                _STOP = {"the", "a", "an", "of", "for", "to", "in", "on", "and", "or",
                         "is", "are", "how", "do", "i", "what", "when", "where", "which",
                         "can", "you", "your", "my", "with", "does", "this", "that", "from",
                         "configure", "create", "creating", "setup", "set", "use", "using",
                         "up", "new", "add", "custom", "page", "screen", "view"}
                def _terms(s):
                    # singularize trivially (leads==lead) so plural titles still match
                    return {(w[:-1] if w.endswith("s") and len(w) > 3 else w)
                            for w in _re2.findall(r"[a-z0-9]+", (s or "").lower())
                            if len(w) > 2 and w not in _STOP}
                qset = _terms(_user_q)
                # Action-intent verbs are stopwords for SUBJECT matching, but an
                # action verb shared by query and title ("create a campaign" ->
                # "Create a New Campaign") is a strong intent signal (Rajendra RCA
                # 2026-07-10: the exactly-named how-to doc sat at #2 under a
                # tangential sibling). Tracked separately from qset.
                _ACT = {"create", "creating", "configure", "configuring", "setup",
                        "add", "adding", "enable", "disable", "execute", "run",
                        "delete", "update", "edit", "import", "export"}
                _qwords = set(_re2.findall(r"[a-z0-9]+", (_user_q or "").lower()))
                _q_act = _qwords & _ACT
                # Definitional/subject queries ("What are notifications used for?",
                # "How do I create a lead?"): when the framing-stripped subject
                # reduces to exactly a candidate's title terms, that doc should
                # LEAD, not sit at #2 (field RCA 2026-07-10).
                _subj_terms = _terms(_query_subject(_user_q))
                _meta_tb = _get_meta_map()
                if qset and pool_map and _meta_tb:
                    top_title = None
                    if nodes:
                        _r0 = _meta_tb.get(_hashlib.md5((nodes[0].node.text or "").encode()).hexdigest())
                        top_title = (_r0 or {}).get("title")
                    best = None; best_score = 0; best_title = ""
                    for _nid, _n in pool_map.items():
                        _r = _meta_tb.get(_hashlib.md5((_n.node.text or "").encode()).hexdigest())
                        tt = _terms((_r or {}).get("title"))
                        if not tt:
                            continue
                        inter = len(qset & tt)
                        # strong: a multi-term title largely covered by the query.
                        strong = inter >= 2 and inter >= len(tt) - 1
                        # short_full: a 1-2 word DISTINCTIVE title (generic words already
                        # dropped by _STOP) that the query FULLY contains — catches the
                        # authoritative single-topic article (e.g. title "Caching" for
                        # "how caching works") that rerank buries under tangential siblings.
                        short_full = (os.environ.get("TITLEBOOST_SHORT", "1") == "1"
                                      and 1 <= len(tt) <= 2 and inter == len(tt))
                        # action_lead: subject fully matched AND the query action verb
                        # appears in the title itself ("create ... campaign" vs title
                        # "Create a New Campaign") -> treat as strong (lead at #1).
                        _t_act = set(_re2.findall(r"[a-z0-9]+", str((_r or {}).get("title") or "").lower())) & _ACT
                        action_lead = (os.environ.get("TITLEBOOST_ACTION_LEAD", "1") == "1"
                                       and short_full and bool(_q_act & _t_act))
                        # subject_lead: the query's bare subject IS this title
                        # ("notifications" == "Notifications"). Revert via
                        # TITLEBOOST_SUBJECT_LEAD=0.
                        subject_lead = (os.environ.get("TITLEBOOST_SUBJECT_LEAD", "1") == "1"
                                        and short_full and bool(_subj_terms) and tt == _subj_terms)
                        # prefix_head: the subject uniquely NAMES this doc-family head
                        # ("autodoc" -> "Autodoc Homepage") — same signal the exact-title
                        # injector uses; without promotion the injected chunk still lost
                        # the top slots to dense noise (Autoflow/AVD for "What is Autodoc?")
                        _subj_q = _query_subject(_user_q)
                        _tl_full = str((_r or {}).get("title") or "").lower().strip()
                        prefix_head = (bool(_subj_q) and len(_subj_q) >= 4
                                       and _tl_full.startswith(_subj_q + " ")
                                       and len(tt) <= len(_subj_terms) + 1)
                        _rank = inter + (2 if (action_lead or subject_lead or prefix_head) else 0)
                        if (strong or short_full or prefix_head) and _rank > best_score:
                            best, best_score, best_title = _n, _rank, (_r or {}).get("title")
                    if best is not None and best_title != top_title:
                        # Give the title-matched doc a CALIBRATED score so it doesn't show
                        # a low reranker score for an exactly-named doc. Dense sim is the
                        # calibrated signal; floor by match strength.
                        _ds = dense_sims.get(best.node.node_id, 0.0) or 0.0
                        best.score = max(best.score or 0.0, _ds, 0.70 if best_score >= 2 else 0.55)
                        rest = [x for x in nodes if x.node.node_id != best.node.node_id]
                        if best_score >= 2:
                            # exact multi-term title match (the doc IS the query topic, e.g.
                            # "Swift Comparison" for "swift comparison") → LEAD with it so the
                            # answer grounds in it, not a generic sibling the reranker mis-ranked.
                            nodes = [best] + rest
                            _pos = 1
                            _title_boost_strong = True
                        else:
                            # single distinctive term → surface at #2 without displacing #1.
                            nodes = (rest[:1] + [best] + rest[1:]) if rest else [best]
                            _pos = 2
                        print(f"[TitleBoost] surfaced '{best_title}' at #{_pos} (match {best_score})")
            except Exception as e:
                print(f"[TitleBoost] failed: {e}")
        else:
            nodes = nodes[:top_k]

        # --- Step 5d: Neighbour stitching (corpus micro-chunking band-aid) ---
        # The final top_k is chosen, but a retrieved intro/heading chunk's ANSWER BODY lives
        # in the NEXT sequential same-doc chunk (::idx+1 / ::idx+2). Stitch those siblings in
        # — by each node's ACTUAL Milvus id, never by text — so the steps travel with the
        # intro. Runs AFTER rerank + dense-floor + title-promotion, BEFORE figure attachment
        # and the confidence gate. Guarded + capped; a failure leaves `nodes` untouched.
        # Env-gated (default ON) so it can be toggled off instantly without a rebuild if a
        # regression shows up. Stub-only gate inside keeps the blast radius tiny.
        if os.environ.get("NEIGHBOR_STITCH", "1") == "1":
            try:
                nodes = _stitch_siblings(self.index, nodes, query=question)
            except Exception as e:
                print(f"[Stitch] failed: {e}")

        # --- Step 5b: Doc-level figure attachment ---
        # A document's diagrams live in image chunks whose text is mostly a VLM
        # caption (UI labels); those rarely dense-match a natural-language query, so
        # the figure is left behind even when we answer from its parent doc. For each
        # doc we retrieved, pull its most query-relevant figure so the diagram travels
        # with the answer (the image-display prompt then inlines the ![](url)). Source
        # chips dedupe by title, so this adds the image to context WITHOUT a dup chip.
        try:
            import re as _re
            img_map = _get_doc_img_map()
            if img_map and nodes:
                from llama_index.core.schema import TextNode, NodeWithScore
                meta = _get_meta_map()
                qterms = {w for w in _re.findall(r"[a-z0-9]+", question.lower()) if len(w) > 2}
                def _ov(row):
                    ft = {w for w in _re.findall(r"[a-z0-9]+", (row.get("text") or "").lower()) if len(w) > 2}
                    return len(qterms & ft)
                seen = {(n.node.text or "")[:160] for n in nodes}
                ranked_docs = []
                for n in nodes:
                    r = meta.get(_hashlib.md5((n.node.text or "").encode()).hexdigest())
                    did = r.get("doc_id") if r else None
                    if did and did in img_map and did not in ranked_docs:
                        ranked_docs.append(did)
                added = 0
                for rank, did in enumerate(ranked_docs[:top_k]):
                    figs = img_map[did]
                    row = sorted(figs, key=_ov, reverse=True)[0]
                    # The top retrieved doc always contributes its best figure. A deeper
                    # doc contributes when EITHER its figure is query-relevant (lexical
                    # overlap) OR it is image-rich (>=3 figures) — a heavily visual doc
                    # that was retrieved as a source should show its diagram even when
                    # its caption (UI labels) does not lexically overlap a natural query.
                    # This closes the "image-rich doc buried at rank 4-5 never attaches"
                    # gap (the E2E ranking miss) without spamming text-only answers.
                    if rank > 0 and _ov(row) < 1 and len(figs) < 3:
                        continue
                    txt = row.get("text") or ""
                    if txt[:160] in seen:
                        continue
                    _fu = row.get("uri") or row.get("source_url")
                    if _fu and (str(_fu).startswith("file://") or ":9000/" in str(_fu)):
                        _fu = None  # file:// unopenable; :9000 MinIO decommissioned
                    nd = TextNode(text=txt, metadata={
                        "file_name": row.get("title"), "title": row.get("title"),
                        "url": _fu,
                    })
                    nodes.append(NodeWithScore(node=nd, score=0.0))
                    seen.add(txt[:160]); added += 1
                    if added >= 4:
                        break
                if added:
                    print(f"[Figures] attached {added} doc figure chunk(s) to context")
        except Exception as e:
            print(f"[Figures] attach failed: {e}")

        # --- Step 6: Compute confidence = retrieval-consensus gate ---
        # Gate the answer/refuse decision on the DENSE retrieval similarity (the
        # calibrated "is this query answerable from the corpus" signal), NOT the
        # reranker score. node.score keeps the reranker relevance (for ordering and
        # the source "% match"); confidence is the remapped dense top-sim so junk
        # queries (sim ~0.52) fall below the 0.30 gate while real ones (sim ~0.7) pass.
        # Best dense sim over ALL retrieved candidates (not just the final reranked
        # top-k): the reranker may drop the strongest-dense doc, but for the "is this
        # answerable from the corpus" gate what matters is whether a strong match was
        # RETRIEVED at all. (Fixes a false-refusal where rerank demoted the best doc.)
        top_dense = max(dense_sims.values(), default=0.0)
        span = max(1e-6, DENSE_GATE_HI - DENSE_GATE_LO)
        confidence = max(0.0, min(1.0, (top_dense - DENSE_GATE_LO) / span))
        print(f"[Confidence] dense top-sim {top_dense:.3f} -> gate conf {confidence:.3f}")

        # False-refusal guard (2026-07-02): an EXACT multi-term title match (title-boost
        # strong) is a high-precision "the right doc is here" signal the dense-sim gate can
        # miss for thin/generically-embedded docs (eval RCA: DMS Settings had a full config
        # table but a sub-gate dense sim → false refuse). Floor the gate confidence so the
        # source-bounded LLM answers from it. Env-gated; revert via TITLEBOOST_CONF_FLOOR=0.
        if _title_boost_strong and os.environ.get("TITLEBOOST_CONF_FLOOR", "1") == "1":
            _cf = float(os.environ.get("TITLEBOOST_CONF_FLOOR_VAL", "0.45"))
            if confidence < _cf:
                print(f"[TitleBoost] confidence {confidence:.3f} floored to {_cf:.2f} (exact title match)")
                confidence = _cf
        
        # Attach source metadata (title/uri) the ingestion schema doesn't expose to
        # llama-index, so the UI source chips show real titles + links.
        _attach_metadata(nodes)

        # --- ACL filtering (only when a scope is supplied) ---
        # Runs AFTER _attach_metadata so access_teams + visibility are present on each
        # node. Drops any node the caller isn't authorized to see. If this removes every
        # node, force confidence=0.0 so the generation layer refuses rather than answers
        # from an empty (or unauthorized) context.
        if acl is not None:
            allowed = acl.get("allowed") or set()
            before = len(nodes)
            nodes = [n for n in nodes
                     if _chunk_authorized(dict(getattr(n.node, "metadata", None) or {}), allowed)]
            if len(nodes) != before:
                print(f"[ACL] filtered {before} -> {len(nodes)} authorized nodes "
                      f"(folder={acl.get('folder')!r})")
            if not nodes:
                confidence = 0.0

        # --- Enumeration sibling expansion ---
        # F-2 packed chunks put an enumerated doc's list items across sections; top_k=5
        # then surfaces 1-2 of them and the "complete list" directive faithfully reports
        # a PARTIAL list (old-vs-new corpus A/B 2026-07-20: Data Pipeline components
        # dropped from full to 2 entries). For enumeration queries, pull the top-ranked
        # doc's REMAINING chunks into context — completeness needs the whole doc, and
        # MAX_CONTEXT_CHARS (26000) now has room. Appended at the tail: the H6 node cap
        # trims siblings first, never the reranked winners. Env: ENUM_SIBLING_EXPAND=0
        # disables; ENUM_SIBLING_MAX bounds the pull.
        # enum intent: the caller's hint (computed on the ORIGINAL user question) wins —
        # the planner's LLM rewrite varies shape run-to-run, so regexing only the
        # rewritten text made this path engage nondeterministically (batch golden).
        _enum_intent = enum_hint or _is_enum_query(question)
        if (os.environ.get("ENUM_SIBLING_EXPAND", "1") == "1"
                and nodes and _enum_intent):
            try:
                _top_doc = None
                for _n in nodes:
                    _top_doc = (getattr(_n.node, "metadata", None) or {}).get("doc_id")
                    if _top_doc:
                        break
                if _top_doc:
                    from llama_index.core.schema import TextNode, NodeWithScore
                    _sib_max = int(os.environ.get("ENUM_SIBLING_MAX", "6"))
                    _have = {(n.node.text or "").strip()[:120] for n in nodes}
                    _rows = [r for r in _get_meta_map().values()
                             if r.get("doc_id") == _top_doc
                             and (r.get("text") or "").strip()[:120] not in _have]
                    _added = 0
                    for _r in _lead_rows(_rows, _sib_max):
                        _txt = (_r.get("text") or "").strip()
                        _md = {k: _r.get(k) for k in
                               ("title", "uri", "source_url", "doc_id", "access_teams", "visibility")
                               if _r.get(k) is not None}
                        nodes.append(NodeWithScore(node=TextNode(text=_txt, metadata=_md), score=0.0))
                        _have.add(_txt[:120]); _added += 1
                    if _added:
                        print(f"[EnumExpand] +{_added} sibling chunk(s) of doc {_top_doc!r}")
            except Exception as e:
                print(f"[EnumExpand] failed: {e}")

        # --- HOW-TO doc completion (Task #3, measured 2026-07-26) ---
        # Line-by-line audits vs LIVE D360 sources showed how-to answers carry only
        # 6-47% of the source procedure (Kafka 47%, Prompts 30%, Email Agent 22%,
        # Policy 2.0 6%): the missing steps live in the LEAD doc's remaining chunks,
        # which top_k + the node cap never admit. For how-to intent, append the lead
        # doc's missing chunks IN ORDINAL ORDER (steps are sequential) after the
        # reranked winners. Same recipe as ENUM_SIBLING_EXPAND above — the one other
        # intent whose quality IS completeness; the how-to cap headroom below keeps
        # the total inside the token-budget invariant. HOWTO_DOC_COMPLETE=0 disables;
        # HOWTO_DOC_COMPLETE_MAX bounds the pull.
        _howto_expanded = False
        # hint computed on the ORIGINAL user question by the caller — the
        # planner rewrite often drops the "how to" phrasing (same lesson as enum).
        if (os.environ.get("HOWTO_DOC_COMPLETE", "1") == "1"
                and nodes and (howto_hint or _is_howto_query(question))):
            try:
                # Lead-doc id: node metadata carries doc_id only on the flags-ON
                # dense path — injected TextNodes (exact-title/TerseAlias) and ALL
                # nodes on flags-OFF prod lack it. Fall back to the meta-map join by
                # text hash (same recipe as figure attachment) so completion fires
                # everywhere.
                _mm = _get_meta_map()

                def _docof(_n):
                    _d = (getattr(_n.node, "metadata", None) or {}).get("doc_id")
                    if not _d and _mm:
                        _mr = _mm.get(_hashlib.md5((_n.node.text or "").encode()).hexdigest())
                        _d = _mr.get("doc_id") if _mr else None
                    return _d

                _top_doc = next((d for d in (_docof(n) for n in nodes) if d), None)
                if _top_doc and _mm:
                    from llama_index.core.schema import TextNode, NodeWithScore
                    _hmax = int(os.environ.get("HOWTO_DOC_COMPLETE_MAX", "12"))
                    _omax = int(os.environ.get("HOWTO_OTHER_DOCS_MAX", "2"))
                    _doc_rows = _ordinal_rows(
                        [r for r in _mm.values() if r.get("doc_id") == _top_doc], _hmax)
                    _by_txt = {(n.node.text or "").strip()[:120]: n for n in nodes}
                    _lead_nodes, _fresh = [], 0
                    for _r in _doc_rows:
                        _txt = (_r.get("text") or "").strip()
                        if not _txt:
                            continue
                        _ex = _by_txt.get(_txt[:120])
                        if _ex is not None:
                            _lead_nodes.append(_ex)
                        else:
                            _md = {k: _r.get(k) for k in
                                   ("title", "uri", "source_url", "doc_id", "access_teams", "visibility")
                                   if _r.get(k) is not None}
                            _lead_nodes.append(NodeWithScore(
                                node=TextNode(text=_txt, metadata=_md), score=0.0))
                            _fresh += 1
                    if _fresh and _lead_nodes:
                        _lead_in_top = sum(1 for n in nodes[:5] if _docof(n) == _top_doc)
                        if _lead_in_top >= 3:
                            # DOMINANT lead doc (the Kafka-class case): the procedure
                            # doc owns the answer — REBUILD as full doc in ordinal
                            # order + top non-lead winners. Appending instead lets the
                            # node cap trim the tail, cutting exactly the late-ordinal
                            # chunks (Input/Output Parameters, XPath tables).
                            _others = [n for n in nodes if _docof(n) != _top_doc][:_omax]
                            nodes = _lead_nodes + _others
                            print(f"[HowtoComplete] rebuilt: {len(_lead_nodes)} doc chunks "
                                  f"(+{_fresh} new) + {len(_others)} others for {_top_doc!r}")
                        else:
                            # MIXED winners (uncertain lead — the email-agent class):
                            # never drop reranked winners; append only the missing
                            # lead-doc chunks at the tail. The cap may trim some, but
                            # a wrongly-guessed lead can no longer evict the doc that
                            # actually carries the procedure.
                            _have2 = {(n.node.text or "").strip()[:120] for n in nodes}
                            _adds = [ln for ln in _lead_nodes
                                     if (ln.node.text or "").strip()[:120] not in _have2]
                            nodes = nodes + _adds
                            print(f"[HowtoComplete] appended {len(_adds)} chunk(s) of "
                                  f"{_top_doc!r} (lead-in-top5={_lead_in_top})")
                        _howto_expanded = True
            except Exception as e:
                print(f"[HowtoComplete] failed: {e}")

        # Calibrated display score for the UI "% match". The reranker score and dense
        # similarity are on different scales, so expose the DENSE similarity
        # (well-calibrated for this corpus) when it's higher, falling back to the
        # reranker score. The UI floors this so a cited source never reads near-zero.
        # One scale for every chip (Rajendra RCA 2026-07-10): raw reranker scores
        # sigmoid-saturate at ~1.0 on tangential docs, so max(dense, rerank) showed
        # "100% match" on documents that had nothing to do with the request while
        # the right doc read 80%. Display the CALIBRATED dense sim (same remap the
        # answer-confidence gate uses); the reranker fallback is capped at 0.70 so
        # a saturated rerank score can never out-shout a calibrated dense one.
        # Revert via MATCH_DISPLAY_CALIB=0.
        for _n in nodes:
            _ds2 = dense_sims.get(_n.node.node_id, 0.0) or 0.0
            _disp = _calib_display(_ds2, _n.score or 0.0)
            _md = dict(getattr(_n.node, "metadata", None) or {})
            _md["match_score"] = round(float(_disp), 4)
            _n.node.metadata = _md

        # --- H6: bound the answer-context NODE COUNT ---
        # rerank(top_k) then dense-floor + title-boost + neighbor-stitch + figure-attach
        # can grow this list to ~12-16. MAX_CONTEXT_CHARS caps context SIZE but never the
        # node COUNT, so a pileup of fragments can dilute the answer (the "more context =
        # more hallucination" the top_k A/B guards against). Cap the count — generous
        # default so normal 3-8 node answers are untouched; only the tail (excess
        # figures / deep dense-floor) is trimmed. Order is best-first (rerank/title-boost
        # lead), so trimming drops the least-relevant. Env-gated: RAG_MAX_CONTEXT_NODES=0
        # disables. Widening the candidate POOL (RETRIEVAL_DENSE_K) is unaffected — this
        # bounds only the FINAL context, not what reaches the reranker.
        # 10 default / 14 for ENUMERATION only. A blanket 14 fixed enum completeness
        # but DILUTED everything else — the same golden run gained the full component
        # list and lost compare-dual + core-document-ai to fresh refusals (zero API
        # errors logged: the model itself gets less decisive past ~10 chunks — exactly
        # what this cap exists to prevent). Enumeration is the one intent whose quality
        # IS completeness, so it alone gets the sibling headroom.
        _cap = int(os.environ.get("RAG_MAX_CONTEXT_NODES", "10"))
        if _enum_intent:
            _cap = max(_cap, int(os.environ.get("ENUM_CONTEXT_NODES", "14")))
        if _howto_expanded:
            # How-to completion earns the same sibling headroom as enumeration —
            # scoped to answers where chunks were actually appended, so ordinary
            # how-to answers (small docs, nothing added) keep the tight default cap.
            _cap = max(_cap, int(os.environ.get("HOWTO_CONTEXT_NODES", "14")))
        if _cap > 0 and len(nodes) > _cap:
            print(f"[ContextCap] {len(nodes)} -> {_cap} nodes (H6)")
            nodes = nodes[:_cap]

        # Metadata backstop: a context node with no identity renders downstream as
        # an "Unknown / Low relevance" source chip (docstore load strips metadata on
        # some nodes — the unpickleable-attribute warnings). Re-attach its ledger row
        # by content hash before the result leaves retrieval.
        try:
            _mm_fix = _get_meta_map()
            _fixed = 0
            for _n in nodes:
                _nm = getattr(_n.node, "metadata", None) or {}
                if not (_nm.get("title") or _nm.get("doc_id")):
                    _row = _mm_fix.get(_hashlib.md5((_n.node.text or "").encode()).hexdigest())
                    if _row:
                        _nm = {**_nm, **_inj_meta(_row)}
                        _fixed += 1
                # file_name drives chip-path resolution + dedupe — set it to the
                # title so appended doc chunks fold into their doc's existing chip
                # instead of surfacing a raw doc_id as a separate source
                if _nm.get("title") and not _nm.get("file_name"):
                    _nm["file_name"] = _nm["title"]
                # SANITIZE to plain picklable types: one exotic value (Milvus array
                # in access_teams) makes llama_index strip the ENTIRE metadata attr
                # during cache pickling — IN PLACE — so the returned nodes lose their
                # identity and the source chip renders "Unknown".
                _clean = {}
                for _k, _v in _nm.items():
                    if isinstance(_v, (str, int, float, bool)) or _v is None:
                        _clean[_k] = _v
                    elif isinstance(_v, (list, tuple, set)):
                        _clean[_k] = [str(_x) for _x in _v]
                    else:
                        _clean[_k] = str(_v)
                _n.node.metadata = _clean
            if _fixed:
                print(f"[MetaFix] re-attached identity on {_fixed} node(s)")
        except Exception as _e:
            print(f"[MetaFix] failed: {_e}")

        # --- Step 7: Cache result ---
        result = (nodes, confidence)
        _cache_put(cache_key, result, query_text=question)

        return result


# Reranking uses the hosted Qwen3-Reranker (DGX vLLM) — a remote call, so there is
# no local model to preload.
