"""
BTKB Application Package
FastAPI backend for Biztech RAG Chatbot.
"""
