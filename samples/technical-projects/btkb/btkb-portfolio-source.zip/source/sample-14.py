"""
Core RAG Engine
Retrieval, reasoning, and answer generation modules.
"""
