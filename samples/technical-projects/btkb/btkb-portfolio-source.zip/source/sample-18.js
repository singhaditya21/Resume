import { redirect } from 'next/navigation';

// The bot-selection hub was removed — everything lives under the KB chat now.
// Kept as a redirect so old bookmarks and links still work.
export default function BotsPage() {
    redirect('/user');
}
