"""
Self-Reflection Module
Implements answer verification, critique, and iterative refinement for improved accuracy.
"""
from typing import Tuple, Optional


CRITIQUE_PROMPT = """You are a critical reviewer. Analyze this answer for accuracy and completeness.

## Question Asked
{question}

## Answer Given
{answer}

## Available Context
{context_summary}

## Critique Checklist

1. **Relevance**: Does the answer directly address the question?
   - Score (1-5): 
   - Issues: 

2. **Accuracy**: Is everything stated supported by the context?
   - Score (1-5):
   - Unsupported claims:

3. **Completeness**: Is anything important missing?
   - Score (1-5):
   - Missing points:

4. **Clarity**: Is the answer clear and well-structured?
   - Score (1-5):
   - Clarity issues:

## Overall Assessment
- Total Score (out of 20):
- Needs Refinement: [YES/NO]
- Suggested Improvements:
"""


REFINEMENT_PROMPT = """Improve this answer based on the critique provided.

## Original Question
{question}

## Original Answer
{answer}

## Critique
{critique}

## Context Available
{context}

## Improved Answer
Write a better answer that addresses all the issues identified:
"""


HALLUCINATION_CHECK_PROMPT = """Check if this answer contains any hallucinations (claims not supported by the context).

Context:
{context}

Answer to check:
{answer}

For each factual claim in the answer, indicate:
- SUPPORTED: Claim is in the context
- UNSUPPORTED: Claim is NOT in the context (hallucination)
- UNCERTAIN: Cannot determine from context

Hallucination Analysis:
"""


class SelfReflector:
    """
    Implements self-reflection and answer refinement loop.
    """
    
    def __init__(self, llm, max_refinements: int = 2):
        self.llm = llm
        self.max_refinements = max_refinements
    
    def critique_answer(
        self, 
        question: str, 
        answer: str, 
        context: str
    ) -> Tuple[str, float, bool]:
        """
        Critique an answer for quality issues.
        
        Returns:
            (critique_text, score_out_of_20, needs_refinement)
        """
        context_summary = context[:1500] + "..." if len(context) > 1500 else context
        
        prompt = CRITIQUE_PROMPT.format(
            question=question,
            answer=answer,
            context_summary=context_summary
        )
        
        critique = str(self.llm.complete(prompt))
        
        # Parse score
        score = 15.0  # Default moderate score
        try:
            import re
            score_match = re.search(r'Total Score.*?(\d+)', critique)
            if score_match:
                score = float(score_match.group(1))
        except:
            pass
        
        # Check if refinement needed
        needs_refinement = "YES" in critique.upper() and score < 16
        
        return critique, score, needs_refinement
    
    def refine_answer(
        self, 
        question: str, 
        answer: str, 
        critique: str, 
        context: str
    ) -> str:
        """Refine answer based on critique."""
        prompt = REFINEMENT_PROMPT.format(
            question=question,
            answer=answer,
            critique=critique,
            context=context[:3000]
        )
        
        refined = str(self.llm.complete(prompt))
        return refined
    
    def check_hallucinations(self, answer: str, context: str) -> Tuple[str, bool]:
        """
        Check for hallucinations in the answer.
        
        Returns:
            (analysis, has_hallucinations)
        """
        prompt = HALLUCINATION_CHECK_PROMPT.format(
            context=context[:3000],
            answer=answer
        )
        
        analysis = str(self.llm.complete(prompt))
        has_hallucinations = "UNSUPPORTED" in analysis.upper()
        
        return analysis, has_hallucinations
    
    def reflect_and_refine(
        self, 
        question: str, 
        initial_answer: str, 
        context: str
    ) -> dict:
        """
        Full reflection and refinement loop.
        
        Returns dict with:
            - final_answer: The refined answer
            - iterations: Number of refinement iterations
            - critiques: List of critiques
            - scores: List of scores per iteration
            - hallucination_check: Hallucination analysis
        """
        result = {
            "final_answer": initial_answer,
            "iterations": 0,
            "critiques": [],
            "scores": [],
            "hallucination_check": None,
            "had_hallucinations": False
        }
        
        current_answer = initial_answer
        
        for i in range(self.max_refinements):
            # Critique
            critique, score, needs_refinement = self.critique_answer(
                question, current_answer, context
            )
            
            result["critiques"].append(critique)
            result["scores"].append(score)
            result["iterations"] = i + 1
            
            if not needs_refinement or score >= 18:
                # Good enough
                result["final_answer"] = current_answer
                break
            
            # Refine
            current_answer = self.refine_answer(
                question, current_answer, critique, context
            )
            result["final_answer"] = current_answer
        
        # Final hallucination check
        analysis, has_hallucinations = self.check_hallucinations(
            result["final_answer"], context
        )
        result["hallucination_check"] = analysis
        result["had_hallucinations"] = has_hallucinations
        
        return result
    
    async def reflect_streaming(
        self, 
        question: str, 
        answer: str, 
        context: str
    ):
        """
        Stream the reflection process.
        
        Yields:
            {"type": "critique" | "refinement" | "final", "content": str}
        """
        yield {
            "type": "status",
            "content": "🔍 Analyzing answer quality..."
        }
        
        critique, score, needs_refinement = self.critique_answer(
            question, answer, context
        )
        
        yield {
            "type": "critique",
            "content": f"Score: {score}/20\n{critique[:500]}..."
        }
        
        if needs_refinement:
            yield {
                "type": "status", 
                "content": "✏️ Refining answer..."
            }
            
            refined = self.refine_answer(question, answer, critique, context)
            
            yield {
                "type": "refinement",
                "content": refined
            }
            
            yield {
                "type": "final",
                "content": refined
            }
        else:
            yield {
                "type": "final",
                "content": answer
            }


def quick_reflect(question: str, answer: str, context: str, llm) -> str:
    """
    Quick reflection helper - returns refined answer if needed.
    """
    reflector = SelfReflector(llm, max_refinements=1)
    result = reflector.reflect_and_refine(question, answer, context)
    return result["final_answer"]
